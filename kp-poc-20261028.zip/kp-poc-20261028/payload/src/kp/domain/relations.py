"""The seven link relations and the item types each one may connect."""

from __future__ import annotations

from enum import StrEnum

from kp.domain.enums import ItemType


class Relation(StrEnum):
    """A directed, named connection between two items. Edges point as the phrase reads."""

    SPECIFIED_BY = "specified_by"  # Story is specified by Spec
    DERIVED_FROM = "derived_from"  # Spec is derived from Requirement or Clause
    USES_TEMPLATE = "uses_template"  # Spec uses Template
    CONSTRAINED_BY = "constrained_by"  # Requirement is constrained by Clause
    RESOLVES_TO = "resolves_to"  # Clause resolves to Schema field
    IMPLEMENTED_BY = "implemented_by"  # Spec is implemented by Code
    VERIFIED_BY = "verified_by"  # Code is verified by Test

    @property
    def allowed_pairs(self) -> frozenset[tuple[ItemType, ItemType]]:
        """All ``(from_type, to_type)`` pairs this relation may connect."""
        return _ALLOWED_PAIRS[self]

    def allows(self, from_type: ItemType, to_type: ItemType) -> bool:
        """Tell whether the relation may connect the two item types.

        :param from_type: Type of the item the edge starts at
        :param to_type: Type of the item the edge ends at
        :return: True when the pair is part of the model
        """
        return (from_type, to_type) in _ALLOWED_PAIRS[self]


_ALLOWED_PAIRS: dict[Relation, frozenset[tuple[ItemType, ItemType]]] = {
    Relation.SPECIFIED_BY: frozenset({(ItemType.STORY, ItemType.SPEC)}),
    Relation.DERIVED_FROM: frozenset(
        {(ItemType.SPEC, ItemType.REQUIREMENT), (ItemType.SPEC, ItemType.CLAUSE)}
    ),
    Relation.USES_TEMPLATE: frozenset({(ItemType.SPEC, ItemType.TEMPLATE)}),
    Relation.CONSTRAINED_BY: frozenset({(ItemType.REQUIREMENT, ItemType.CLAUSE)}),
    Relation.RESOLVES_TO: frozenset({(ItemType.CLAUSE, ItemType.SCHEMA_FIELD)}),
    Relation.IMPLEMENTED_BY: frozenset({(ItemType.SPEC, ItemType.CODE)}),
    Relation.VERIFIED_BY: frozenset({(ItemType.CODE, ItemType.TEST)}),
}
