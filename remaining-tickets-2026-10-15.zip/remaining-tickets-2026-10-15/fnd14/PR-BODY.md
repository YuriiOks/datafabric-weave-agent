> [!IMPORTANT]
> **Pre-production only, and blocked end to end by two source registrations.** The integration is complete and off by default, but on `main` no real job can reach a validated candidate yet: the skills registration declares its ordering unknown, and both registrations claim the skill-content collection. Both are listed under "Not in this PR" with the decision each one needs. Until they change, the new path is proven by unit tests only.

## Problem

The refresh job framework can admit, lease, fence, seal and activate a candidate, but nothing connects it to the real sources. No concrete configuration, authority, source adapter, status or catalogue port exists in the application, nothing persists a canonical catalogue snapshot outside tests, and nothing starts the worker loop. With refresh enabled, startup refuses ("refresh enabled without configured authority and ports"), so the status page and the refresh button have nothing behind them.

## Solution

**One refresh over the registered sources.** When refresh is enabled in pre-production with the new pre-production authority flag, startup composes the runtime itself:

- **Configuration.** The configuration `ppd-catalogue` names the two registered sources (the Agent Hub workbook export and the skills repository) and carries a digest of their full registrations. A job runs only against the registrations it was admitted with: if one changes in between, the job stops as "source configuration changed". Paths, remotes and credentials stay out of the snapshot.
- **Sources.** Each registered source is captured through the existing acquisition service into a private, per-attempt staging directory. A refused, failed, incomplete or too-old source fails the job at the fetch stage ("source failed" or "source incomplete"); nothing downstream sees it.
- **Catalogue.** The publisher's catalogue port builds the canonical catalogue from exactly the captured artifacts: the workbook through the export reader, the skills tree through the skill parser, then the registry adapters and one identity catalogue. The adapters' batches are re-issued under the manifest each source was actually captured with (completeness, freshness, deletion semantics and the revision of every collection), keeping the build's own content hash that every record is bound to. Only a `validated` snapshot is persisted and handed to the publisher; anything else refuses the candidate with the build's own reason (for example `source_ordering_unestablished`), and the job ends as "publication rejected" with that reason. The port also checks that the stored manifests match the captured revision vector, which the publisher leaves to this wiring, and refuses a candidate that reuses a source it did not capture. Absence never retires anything: the registered sources capture with `absence_is_not_deletion`.
- **Authority.** Until the operator authority service exists, an explicit operator allow-list (`RECSYS_REFRESH_PREPRODUCTION_OPERATORS`) decides who may submit, inspect, cancel and retry. Before every activation it re-checks that the initiating operator is still listed, that the configuration is unchanged and that the candidate belongs to the lease's fence. It refuses to start in production.
- **Status.** Status reports the publication the pointer actually marks active in the scope, not the last job.
- **Worker.** With the worker flag also set, startup starts the worker loop and shutdown stops it and waits for it; a crashed loop is logged when it happens instead of at shutdown.

Unchanged: with the new flag off (the default) startup behaves exactly as before, including the fail-closed refusal. Production cannot enable it. The hub's startup file, the job framework, the publisher, the catalogue builder, the registrations and every existing route are untouched; registry reads still answer `registry_authorization_unavailable`.

## How to verify

1. Unit tests: `tests/recsys/refresh/test_integration_*.py` (configuration digest and drift, allow-list and activation re-checks, acquisition refusals and their safe reasons, batch attestation, revision-vector check, staging cleanup, status, startup gate and worker lifecycle). CI runs them.
2. Startup gate: with `RECSYS_REFRESH_ENABLED=true`, `RECSYS_REFRESH_PREPRODUCTION_AUTHORITY_ENABLED=true` and `RECSYS_REFRESH_ENVIRONMENT=prod`, the app refuses to start with "refused outside ppd" and never opens a database connection.
3. Default: with the new flag unset, `RECSYS_REFRESH_ENABLED=true` still refuses with "refresh enabled without configured authority and ports".
4. Pre-production, once the two registrations below are fixed: set the flags, the operator list and `RECSYS_REFRESH_WORKSPACE_ROOT`, start the app with `RECSYS_REFRESH_WORKER_ENABLED=true`, submit `ppd-catalogue` as a listed operator. Status shows fetched, validated, sealed and activated separately, and the current publication is the new catalogue. Remove the operator from the list and restart before activation: the job ends as "authorization revoked". Move the workbook away after startup: the next submission is refused as a configuration change (409).
5. Today, before those fixes, step 4 ends at the validation stage as "publication rejected" with reason `capture_disagreement` (both captures claim skill content). That is the expected, truthful outcome.

## Not in this PR

- **Skills ordering (registration).** The skills registration declares ordering `unknown` at revision 0, so any catalogue built from it stays `captured` (`source_ordering_unestablished`), and a second commit would reuse revision 0 with new content. The source owner has to choose a monotonic revision for the skills repository.
- **Skill-content ownership (registration).** The workbook registration claims every collection, including skill content, which the skills registration also claims. The publisher refuses one collection from two authorities by design, while the catalogue policy requires skill content from both the export and the repository. One of the two has to change, and that is an ownership decision, not an integration one.
- **Workbook revision.** The workbook registration pins one revision for every export, so a changed workbook at the same revision is refused at activation as "revision reused with different content". Safe, but every new export needs a new registration.
- **Export reader in the deployed image.** The image ships the CSV reader only; the acquired `.xlsx` is refused as `export_reader_unavailable` there. It works where the optional workbook reader is installed.
- **Previous candidate.** No loader returns the previous validated candidate, so the build runs without one: no reuse and no retirement proposals. Ordering against the active publication is still enforced at activation.
- **Reads.** The publication reads are not mounted and registry reads stay refused; the read policy port has no implementation yet.
- **Owner reference rules.** The build uses the server-tool cells from the export only; the owner rule file is not part of the configuration yet.
- **Production authority.** The operator authority service replaces the allow-list; production stays refused until then.

## Review focus

- The batch attestation in `refresh/integration/catalogue_version.py`: the batch keeps the build's content hash and takes completeness, freshness, ordering and revisions from the capture. Is that the right split?
- The status port reports the catalogue manifest digest as the current publication's `snapshot_id`, because the descriptor has no configuration digest. Should status instead join the job that activated the publication?
- Staging is in-process and per attempt; a restarted process acquires again. Earlier attempts of the same job and anything older than an hour are dropped when the next capture starts.
- Exception translation: the worker maps only refresh port errors, so every adapter and catalogue failure leaves as one, with the error type logged and the message not (it can carry paths or source rows).

## CI

- The checks posted on this head are the result.
