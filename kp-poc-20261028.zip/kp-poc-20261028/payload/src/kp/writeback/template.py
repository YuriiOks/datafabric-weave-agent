"""Reading governed templates and splitting markdown into sections."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

import yaml

from kp.domain import Template
from kp.errors import TemplateNotFoundError

_FRONT_MATTER = re.compile(r"\A---[ \t]*\n(?P<header>.*?)\n---[ \t]*(?:\n|\Z)", re.DOTALL)
_HEADING = re.compile(r"^(?P<marks>#{1,6})[ \t]+(?P<title>.+?)[ \t]*#*[ \t]*$")
_VARIABLE = re.compile(r"\{\{\s*(?P<name>\w+)\s*\}\}")


def split_front_matter(text: str) -> tuple[str, str]:
    """Separate a leading ``---`` block from the body.

    :param text: Markdown, possibly starting with front matter
    :return: The header text (empty when there is none) and the remaining body
    """
    match = _FRONT_MATTER.match(text)
    if match is None:
        return "", text
    return match["header"], text[match.end() :]


def _scalar_fields(header: str) -> dict[str, str]:
    """Read ``key: value`` pairs of the front matter with every scalar kept as its text.

    Resolving scalars to numbers would turn ``version: 1.10`` into ``1.1``.
    """
    try:
        root = yaml.compose(header, Loader=yaml.SafeLoader) if header else None
    except yaml.YAMLError as exc:
        raise TemplateNotFoundError("Template front matter is not valid") from exc
    if not isinstance(root, yaml.MappingNode):
        raise TemplateNotFoundError("Template has no front matter")
    return {
        key.value: value.value
        for key, value in root.value
        if isinstance(key, yaml.ScalarNode) and isinstance(value, yaml.ScalarNode)
    }


def parse_template(text: str) -> Template:
    """Read a governed template file.

    :param text: The template file: front matter with ``template_id``, ``version`` and
        ``spec_type`` followed by the body
    :return: The template; its digest is taken over the whole file
    :raises kp.errors.TemplateNotFoundError: If the front matter is absent, invalid or
        incomplete
    """
    header, body = split_front_matter(text)
    fields = _scalar_fields(header)
    try:
        template_id, version, spec_type = (
            fields[key] for key in ("template_id", "version", "spec_type")
        )
    except KeyError as exc:
        raise TemplateNotFoundError("Template front matter lacks id, version or type") from exc
    return Template(
        template_id=template_id,
        version=version,
        spec_type=spec_type,
        body=body,
        content_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
    )


@dataclass(frozen=True, slots=True)
class Section:
    """A heading and the lines below it, up to the next heading.

    :ivar level: Number of ``#`` marks; 0 for text before the first heading.
    """

    level: int
    title: str
    lines: tuple[str, ...]


def split_sections(markdown: str) -> list[Section]:
    """Split markdown into sections at ATX headings, ignoring headings inside code fences.

    :param markdown: A document body without front matter
    :return: The sections in order; text before the first heading is a level-0 section
    """
    sections: list[Section] = []
    level, title, lines = 0, "", []
    in_fence = False
    for line in markdown.splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
        heading = None if in_fence else _HEADING.match(line)
        if heading is None:
            lines.append(line)
            continue
        if level or title or any(item.strip() for item in lines):
            sections.append(Section(level, title, tuple(lines)))
        level, title, lines = len(heading["marks"]), heading["title"], []
    sections.append(Section(level, title, tuple(lines)))
    return sections


def substitute_variables(text: str, variables: dict[str, str]) -> str:
    """Replace ``{{name}}`` placeholders; unknown names stay visible.

    :param text: Template text
    :param variables: Values by placeholder name
    :return: The text with known placeholders replaced
    """
    return _VARIABLE.sub(lambda match: variables.get(match["name"], match[0]), text)
