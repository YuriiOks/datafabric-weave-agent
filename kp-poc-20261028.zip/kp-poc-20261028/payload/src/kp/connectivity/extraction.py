"""Client of the document extraction service (synchronous REST).

The request carries identity, a storage reference, the caller-declared media type and the
source type. It never carries the file bytes: the service reads the raw object from storage
itself. The answer must name an extractor version; without one the call is an error.
"""

from __future__ import annotations

import logging

import httpx
from pydantic import ValidationError

from kp.connectivity.errors import (
    ExtractionError,
    ExtractionUnavailableError,
    MissingExtractorVersionError,
)
from kp.connectivity.http_status import (
    BAD_REQUEST,
    RATE_LIMITED,
    REQUEST_TIMEOUT,
    SERVER_ERROR,
    UNAUTHORIZED,
)
from kp.connectivity.models import ExtractionRequest, ExtractionResponse
from kp.connectivity.tokens import AccessToken, TokenProvider
from kp.errors import SourceAuthRefusedError

logger = logging.getLogger(__name__)

_RETRY_LATER = (REQUEST_TIMEOUT, RATE_LIMITED)


def ensure_extractor_version(response: ExtractionResponse) -> ExtractionResponse:
    """Reject a response that does not name the extractor version that produced it.

    :param response: What the service answered
    :return: The same response
    :raises kp.connectivity.errors.MissingExtractorVersionError: If the version is missing or blank
    """
    if not response.extractor_version.strip():
        raise MissingExtractorVersionError(
            f"Extraction response for {response.item_id} names no extractor version"
        )
    return response


class ExtractionClient:
    """POSTs extraction requests to the service.

    :param http: The HTTP client; its transport decides what is real
    :param endpoint: The extraction endpoint
    :param tokens: Optional caller-identity token source
    :param identity_header: Header name for the token; required when ``tokens`` is given
    """

    def __init__(
        self,
        *,
        http: httpx.Client,
        endpoint: str,
        tokens: TokenProvider | None = None,
        identity_header: str | None = None,
    ) -> None:
        if tokens is not None and identity_header is None:
            raise ValueError("identity_header is required when tokens are given")
        self._http = http
        self._endpoint = endpoint
        self._tokens = tokens
        self._identity_header = identity_header

    def extract(self, request: ExtractionRequest) -> ExtractionResponse:
        """Ask the service to convert one stored object.

        :param request: Identity, storage reference, declared media type and source type
        :return: Where the outputs are and which extractor version produced them
        :raises kp.connectivity.errors.ExtractionError: If the service rejects or garbles it
        :raises kp.connectivity.errors.MissingExtractorVersionError: If the answer lacks a version
        :raises kp.connectivity.errors.ExtractionUnavailableError: If the service is down
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after one renewal
        """
        response = self._post(request)
        if response.status_code >= SERVER_ERROR or response.status_code in _RETRY_LATER:
            raise ExtractionUnavailableError(
                f"Extraction service could not take the request now ({response.status_code})"
            )
        if response.status_code == UNAUTHORIZED:
            raise SourceAuthRefusedError("Extraction service refused the caller credential")
        if response.status_code >= BAD_REQUEST:
            raise ExtractionError(
                f"Extraction service rejected the object ({response.status_code})"
            )
        parsed = self._parse(response)
        logger.info(
            "Extraction finished",
            extra={"item_id": request.item_id, "extractor_version": parsed.extractor_version},
        )
        return ensure_extractor_version(parsed)

    def _post(self, request: ExtractionRequest) -> httpx.Response:
        tokens = self._tokens
        if tokens is None:
            return self._send(request, None)
        grant = tokens.acquire()
        response = self._send(request, grant.token)
        if response.status_code != UNAUTHORIZED:
            return response
        return self._send(request, tokens.force_refresh(grant.token).token)

    def _send(self, request: ExtractionRequest, token: AccessToken | None) -> httpx.Response:
        try:
            return self._http.post(
                self._endpoint,
                json=request.model_dump(mode="json"),
                headers=self._headers(token.value.get_secret_value() if token else None),
            )
        except httpx.HTTPError as exc:
            raise ExtractionUnavailableError("Extraction service could not be reached") from exc

    def _headers(self, token: str | None) -> dict[str, str]:
        if token is None or self._identity_header is None:
            return {}
        if self._identity_header.lower() == "authorization":
            token = f"Bearer {token}"
        return {self._identity_header: token}

    @staticmethod
    def _parse(response: httpx.Response) -> ExtractionResponse:
        try:
            payload = response.json()
        except ValueError as exc:
            raise ExtractionError("Extraction service answered with malformed JSON") from exc
        if not isinstance(payload, dict):
            raise ExtractionError("Extraction service answered with something other than an object")
        known = {name: payload[name] for name in ExtractionResponse.model_fields if name in payload}
        try:
            return ExtractionResponse.model_validate(known)
        except ValidationError as exc:
            raise ExtractionError("Extraction service answered with an unusable object") from exc
