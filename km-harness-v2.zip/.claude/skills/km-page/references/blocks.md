# Page blocks

The template styles these blocks and nothing else. Use them as shown.

| Need | Markup |
|---|---|
| Paragraph | `<p>text</p>` |
| Sub-heading | `<h3>text</h3>`, at most one level, only inside a section |
| Bullets | `<ul><li>text</li></ul>`; numbered steps: `<ol class="list">` |
| Aside | `<div class="note"><p>text</p></div>` for one caveat or one decision |
| Evidence label | `<span class="lab">Observed</span>` after the claim it labels |
| Code or path | `<code>kb/base/search.md</code>` |
| Table | `<div class="table-wrap"><table>` with caption (what, source), thead, tbody |
| Number tiles | the `<ul class="tiles">` block in the template, two to four items |
| Diagram | the `<figure class="fig">` block in the template |
| Section | `<section id="s3"><h2>finding as a sentence</h2> ... </section>` |

## Rules
- Section ids run s1, s2, s3 in order; the last section keeps id `sources`.
- The first two sentences of "In short" carry the answer; numbers there match the body.
- Every number in a tile or table names its source in the tile, the caption or the Sources
  section. A number without a source is left out.
- Evidence labels: put one on each claim that is not Observed. A page where everything is
  Observed needs only the legend in the Sources section.
- Number columns get `class="num"` on both th and td.
- Tables: at most 6 columns and 12 rows. More goes to an annex page or the twin only.
- Long quotes are not used. Quote at most one line, with its source.
- Open questions: a section of its own near the end, at most two per role, each with what it
  blocks and the recommended answer.
- The twin follows the same order. Table rows become a Markdown table; tiles become a bullet
  list; the diagram becomes a link to its twin under designs/diagrams/.
