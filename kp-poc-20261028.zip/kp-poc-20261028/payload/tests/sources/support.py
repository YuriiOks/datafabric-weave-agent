"""Helpers shared by the source reader tests."""

from __future__ import annotations

import json
from pathlib import Path

from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.sources import ChangedItem, SourceReader


def drain(
    reader: SourceReader, cursor: str | None = None, *, limit: int = 100
) -> tuple[list[ChangedItem], str | None]:
    """Page through ``list_changed`` until the source is exhausted.

    :param reader: The reader under test
    :param cursor: Where to start
    :param limit: Page size to ask for
    :return: Every reported item and the final cursor
    """
    items: list[ChangedItem] = []
    while True:
        batch = reader.list_changed(cursor, limit=limit)
        items.extend(batch.items)
        cursor = batch.next_cursor
        if batch.exhausted:
            return items, cursor


def ids(items: list[ChangedItem]) -> set[tuple[str, str]]:
    """Reduce changes to ``(item_id, version)`` pairs.

    :param items: Reported changes
    :return: The pairs, ignoring deletions' other fields
    """
    return {(item.key.item_id, item.key.version) for item in items}


def key(source: SourceKind, item_id: str, version: str) -> ItemKey:
    """Shorthand for building an :class:`ItemKey`.

    :param source: Source kind
    :param item_id: Item identity
    :param version: Version
    :return: The key
    """
    return ItemKey(source=source, item_id=item_id, version=version)


def write_json(path: Path, payload: object) -> None:
    """Write ``payload`` as JSON, creating folders.

    :param path: Destination
    :param payload: A JSON-serialisable value
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
