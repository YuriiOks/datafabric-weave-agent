"""Relation keys, evidence and ledger outcomes survive a real PostgreSQL write.

Database tier: runs only against the disposable test database the catalogue tests
use, and removes exactly the version it wrote.
"""

from __future__ import annotations

import tempfile
import unittest
from datetime import UTC, datetime
from pathlib import Path

import asyncpg

from app.recsys.contracts import LinkType, ResolutionOutcome
from app.recsys.db.schema import ensure_schema
from app.recsys.ingest import read_skills_repo
from app.recsys.registry.catalogue_build import build_components
from app.recsys.registry.excel_reader import read_export
from app.recsys.registry.flags import apply_flags
from app.recsys.registry.links import build_links
from app.recsys.registry.writer import build_summary, write_version
from tests.recsys.catalogue._postgres import assert_disposable_database, recsys_test_dsn
from tests.recsys.registry._fixtures import SKILLS_REPO, write_export_dir
from tests.recsys.registry.relations._builds import (
    SCOPE,
    WIDGET_HELPER,
    agent_usage,
    widget_row,
)

CODE_VERSION = "relation-store-test"
SHA256_HEX = r"^[0-9a-f]{64}$"


class RelationStoreTests(unittest.IsolatedAsyncioTestCase):
    """A written version carries one evidence set per relation."""

    async def asyncSetUp(self) -> None:
        self.pool = await asyncpg.create_pool(recsys_test_dsn(), min_size=1, max_size=4)
        async with self.pool.acquire() as conn:
            await assert_disposable_database(conn)
        await ensure_schema(self.pool)
        self.scratch = tempfile.TemporaryDirectory()
        export = write_export_dir(
            Path(self.scratch.name) / "export",
            agent_usage(widget_row("alpha-helper,alpha-helper,no-such-skill")),
        )
        tables = read_export(str(export))
        skills, repo_input = read_skills_repo(SKILLS_REPO)
        self.build = build_components(tables, skills, SCOPE, code_version=CODE_VERSION)
        self.links = build_links(self.build.catalogue, self.build.rows).links
        apply_flags(self.build.rows)
        self.summary = build_summary(
            rows=self.build.rows,
            links=self.links,
            inputs=[*tables.inputs, repo_input],
            unconsumed_keys=self.build.unconsumed_keys,
            merge_stats=self.build.merge_stats,
            ledger_counts=self.build.ledger.counts(),
            ledger_reasons=self.build.ledger.reason_histogram(),
            snapshot_state=self.build.catalogue.snapshot.state.value,
            snapshot_reason=self.build.catalogue.snapshot.diagnostic_reason,
            created_at=datetime.now(tz=UTC),
            ingest_code_version=CODE_VERSION,
        )
        await self._write()

    async def _write(self) -> None:
        async with self.pool.acquire() as conn:
            await write_version(
                conn,
                summary=self.summary,
                rows=self.build.rows,
                links=self.links,
                ledger_entries=[entry.as_dict() for entry in self.build.ledger.entries],
                force=True,
            )

    async def asyncTearDown(self) -> None:
        async with self.pool.acquire() as conn:
            for statement in (
                "DELETE FROM recsys_review_ledger_entry WHERE catalogue_version = $1",
                "DELETE FROM recsys_component_link WHERE catalogue_version = $1",
                "DELETE FROM recsys_component WHERE catalogue_version = $1",
                "DELETE FROM recsys_catalogue_version WHERE version = $1",
            ):
                await conn.execute(statement, self.summary.version)
        await self.pool.close()
        self.scratch.cleanup()

    async def _evidence_count(self) -> int:
        async with self.pool.acquire() as conn:
            return await conn.fetchval(
                "SELECT count(*) FROM recsys_relation_evidence WHERE catalogue_version = $1",
                self.summary.version,
            )

    async def test_every_link_row_has_its_key_digest_and_evidence(self):
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT l.relation_key, l.evidence_digest, count(e.entry_ordinal) AS entries
                FROM recsys_component_link l
                LEFT JOIN recsys_relation_evidence e
                  ON e.catalogue_version = l.catalogue_version
                 AND e.src_id = l.src_id
                 AND e.dst_id = l.dst_id
                 AND e.link_type = l.link_type
                WHERE l.catalogue_version = $1
                GROUP BY l.relation_key, l.evidence_digest
                """,
                self.summary.version,
            )
        self.assertEqual(len(rows), len(self.links))
        for row in rows:
            with self.subTest(row=dict(row)):
                self.assertRegex(row["relation_key"], SHA256_HEX)
                self.assertRegex(row["evidence_digest"], SHA256_HEX)
                self.assertGreaterEqual(row["entries"], 1)

    async def test_a_repeated_declaration_is_one_link_with_two_evidence_rows(self):
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT entry_ordinal, token_ordinal FROM recsys_relation_evidence "
                "WHERE catalogue_version = $1 AND src_id = $2 AND dst_id = $3 "
                "AND link_type = $4 ORDER BY entry_ordinal",
                self.summary.version,
                WIDGET_HELPER,
                "skill:alpha-helper",
                LinkType.uses_skill.value,
            )
        self.assertEqual([row["token_ordinal"] for row in rows], [0, 1])

    async def test_a_forced_rewrite_keeps_exactly_one_evidence_set(self):
        expected = sum(len(link.evidence) for link in self.links)
        self.assertEqual(await self._evidence_count(), expected)
        await self._write()
        self.assertEqual(await self._evidence_count(), expected)

    async def test_unresolved_references_carry_outcome_owner_and_link_type(self):
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT raw_value, resolution_outcome, owner_component_id, link_type "
                "FROM recsys_review_ledger_entry "
                "WHERE catalogue_version = $1 AND kind = 'reference'",
                self.summary.version,
            )
        unknown = [row for row in rows if row["raw_value"] == "no-such-skill"]
        self.assertEqual(len(unknown), 1)
        self.assertEqual(unknown[0]["resolution_outcome"], ResolutionOutcome.missing.value)
        self.assertEqual(unknown[0]["owner_component_id"], WIDGET_HELPER)
        self.assertEqual(unknown[0]["link_type"], LinkType.uses_skill.value)

    async def test_only_closed_link_types_are_persisted(self):
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT DISTINCT link_type FROM recsys_relation_evidence "
                "WHERE catalogue_version = $1",
                self.summary.version,
            )
        self.assertLessEqual(
            {row["link_type"] for row in rows}, {item.value for item in LinkType}
        )


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
