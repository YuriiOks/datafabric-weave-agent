"""The guessed-link score: 0.50 search agreement, 0.30 shared schema fields, 0.20 shared terms."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from typing import Annotated, Final, Self

from pydantic import Field

from kp.domain import DomainModel, ItemRef
from kp.links.errors import SimilarityPortError
from kp.links.guessed.similarity import TermOverlapSimilarity
from kp.links.guessed.terms import schema_fields_in, significant_terms
from kp.links.ports import SimilarityPort

WEIGHT_SEARCH_AGREEMENT: Final = 0.50
WEIGHT_SHARED_SCHEMA_FIELDS: Final = 0.30
WEIGHT_SHARED_TERMS: Final = 0.20

_SCORE_DECIMALS = 4
_EVIDENCE_TERMS = 8

UnitFloat = Annotated[float, Field(ge=0, le=1)]


class GuessItem(DomainModel):
    """An item as the scorer sees it: where it is, what it says, which schema fields it names."""

    ref: ItemRef
    text: str
    schema_fields: frozenset[str] = frozenset()

    @classmethod
    def from_text(cls, ref: ItemRef, text: str, known_fields: Iterable[str]) -> Self:
        """Build an item whose schema fields are the known fields its text mentions.

        :param ref: The item endpoint
        :param text: The item's text
        :param known_fields: Field names of the schemas in play
        :return: The item
        """
        return cls(ref=ref, text=text, schema_fields=schema_fields_in(text, known_fields))


class LinkScore(DomainModel):
    """A score with its three parts and the evidence sentence stored with the link."""

    score: UnitFloat
    search_agreement: UnitFloat
    shared_schema_fields: UnitFloat
    shared_terms: UnitFloat
    evidence: str


def _overlap(left: frozenset[str], right: frozenset[str]) -> float:
    """Share of the smaller set found in the other; 0 when either set is empty."""
    if not left or not right:
        return 0.0
    return len(left & right) / min(len(left), len(right))


def _jaccard(left: frozenset[str], right: frozenset[str]) -> float:
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


class LinkScorer:
    """Scores how likely two items are linked.

    ``score = 0.50 * search agreement + 0.30 * shared schema fields + 0.20 * shared terms``,
    each part in 0-1. Search agreement comes from the :class:`SimilarityPort` and is
    rescaled by its ``max_score``; shared schema fields is the share of the item naming
    fewer fields whose fields the other also names; shared terms is the Jaccard overlap of
    the significant terms. An item with no schema fields scores 0 on that part.

    :param similarity: Search agreement; defaults to local term overlap
    """

    def __init__(self, similarity: SimilarityPort | None = None) -> None:
        self._similarity: SimilarityPort = (
            similarity if similarity is not None else TermOverlapSimilarity()
        )

    def score_all(self, source: GuessItem, targets: Sequence[GuessItem]) -> list[LinkScore]:
        """Score a source item against several targets.

        :param source: The item the link would start at
        :param targets: The items it might link to
        :return: One score per target, in order
        :raises SimilarityPortError: If the port misreports its scale or its result count
        """
        if not targets:
            return []
        scale = self._similarity.max_score
        if scale <= 0:
            raise SimilarityPortError("The similarity port must report a positive max_score")
        raw = self._similarity.agreement(source.text, [target.text for target in targets])
        if len(raw) != len(targets):
            raise SimilarityPortError("The similarity port returned the wrong number of scores")
        source_terms = significant_terms(source.text)
        return [
            self._combine(source, target, source_terms, min(max(value, 0.0) / scale, 1.0))
            for target, value in zip(targets, raw, strict=True)
        ]

    def score(self, source: GuessItem, target: GuessItem) -> LinkScore:
        """Score one pair.

        :param source: The item the link would start at
        :param target: The item it might link to
        :return: The score
        """
        return self.score_all(source, [target])[0]

    @staticmethod
    def _combine(
        source: GuessItem, target: GuessItem, source_terms: frozenset[str], agreement: float
    ) -> LinkScore:
        shared_fields = source.schema_fields & target.schema_fields
        field_part = _overlap(source.schema_fields, target.schema_fields)
        target_terms = significant_terms(target.text)
        term_part = _jaccard(source_terms, target_terms)
        total = round(
            WEIGHT_SEARCH_AGREEMENT * agreement
            + WEIGHT_SHARED_SCHEMA_FIELDS * field_part
            + WEIGHT_SHARED_TERMS * term_part,
            _SCORE_DECIMALS,
        )
        shared_terms = sorted(source_terms & target_terms)[:_EVIDENCE_TERMS]
        evidence = (
            f"search agreement {agreement:.2f}; "
            f"shared schema fields {', '.join(sorted(shared_fields)) or 'none'}; "
            f"shared terms {', '.join(shared_terms) or 'none'}"
        )
        return LinkScore(
            score=min(total, 1.0),
            search_agreement=round(agreement, _SCORE_DECIMALS),
            shared_schema_fields=round(field_part, _SCORE_DECIMALS),
            shared_terms=round(term_part, _SCORE_DECIMALS),
            evidence=evidence,
        )
