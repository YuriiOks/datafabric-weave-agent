"""``kp serve-read`` and ``kp serve-write``: parsing, wiring errors and a stdio session."""

from __future__ import annotations

import argparse
import io
import json
from pathlib import Path

import pytest
from mcp_fixtures import *  # noqa: F403 - pytest fixtures
from pydantic import SecretStr

from kp.config import Mode, Settings
from kp.mcp import ServeWiring, add_parser, handle_serve_read, handle_serve_write
from kp.store import Database, create_engine_for_url
from kp.tools import AuditStore, ReadPorts, WriteToolPort
from kp.tools.testing import FakeWritePort

ENV = {"KP_CALLER": "user-full-access", "KP_AGENT": "spec-agent", "KP_SESSION_ID": "sess-cli"}
CALL = json.dumps(
    {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/call",
        "params": {"name": "search", "arguments": {"query": "currency"}},
    }
)


def build_parser(wiring: ServeWiring | None = None) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True), wiring=wiring)
    return parser


@pytest.fixture
def settings(tmp_path: Path, committed_fixtures_dir: Path) -> Settings:
    return Settings(
        _env_file=None,
        mode=Mode.LOCAL,
        database_url=SecretStr(f"sqlite+pysqlite:///{tmp_path / 'kp.db'}"),
        identity_mapping_file=committed_fixtures_dir / "identity" / "identity-mapping.yaml",
    )


def test_us16_both_commands_are_registered_with_stdio_as_the_default() -> None:
    parser = build_parser()

    read = parser.parse_args(["serve-read"])
    write = parser.parse_args(["serve-write", "--http", "8123", "--host", "0.0.0.0"])  # noqa: S104

    assert (read.command, read.http, read.host) == ("serve-read", None, "127.0.0.1")
    assert (write.command, write.http, write.host) == ("serve-write", 8123, "0.0.0.0")  # noqa: S104
    assert callable(read.handler)
    assert callable(write.handler)


def test_us16_serving_without_wired_ports_exits_with_a_configuration_error(
    settings: Settings, capsys: pytest.CaptureFixture[str]
) -> None:
    args = build_parser().parse_args(["serve-read"])

    status = handle_serve_read(args, None, settings=settings, stdin=io.StringIO(""), environ=ENV)

    assert status == 2
    assert "serve-read" in capsys.readouterr().err


def test_us17_serving_without_an_identity_mapping_exits_with_a_configuration_error(
    ports: ReadPorts, capsys: pytest.CaptureFixture[str]
) -> None:
    args = build_parser().parse_args(["serve-read"])
    no_mapping = Settings(_env_file=None, mode=Mode.LOCAL, identity_mapping_file=None)

    status = handle_serve_read(
        args, ServeWiring(read_ports=lambda _s, _d: ports), settings=no_mapping, environ=ENV
    )

    assert status == 2
    assert "KP_IDENTITY_MAPPING_FILE" in capsys.readouterr().err


def test_us17_a_broken_identity_mapping_exits_with_a_configuration_error(
    ports: ReadPorts, tmp_path: Path
) -> None:
    broken = tmp_path / "mapping.yaml"
    broken.write_text("version: 7\n", encoding="utf-8")
    args = build_parser().parse_args(["serve-read"])
    cfg = Settings(_env_file=None, mode=Mode.LOCAL, identity_mapping_file=broken)

    status = handle_serve_read(
        args, ServeWiring(read_ports=lambda _s, _d: ports), settings=cfg, environ=ENV
    )

    assert status == 2


def test_us16_serve_read_runs_a_stdio_session_and_records_the_call_in_the_database(
    ports: ReadPorts, settings: Settings
) -> None:
    wiring = ServeWiring(read_ports=lambda _s, _d: ports)
    args = build_parser(wiring).parse_args(["serve-read"])
    stdout = io.StringIO()

    status = handle_serve_read(
        args, wiring, settings=settings, stdin=io.StringIO(CALL + "\n"), stdout=stdout, environ=ENV
    )

    assert status == 0
    reply = json.loads(stdout.getvalue())
    assert reply["result"]["isError"] is False
    engine = create_engine_for_url(settings.database_url.get_secret_value())
    try:
        with Database(engine).transaction() as connection:
            (record,) = AuditStore(connection).list_for_session("sess-cli")
    finally:
        engine.dispose()
    assert (record.caller, record.tool, record.refused) == ("user-full-access", "search", False)


def test_us16_the_installed_handler_runs_the_same_session(
    ports: ReadPorts, settings: Settings, monkeypatch: pytest.MonkeyPatch
) -> None:
    wiring = ServeWiring(read_ports=lambda _s, _d: ports)
    args = build_parser(wiring).parse_args(["serve-read"])
    stdout = io.StringIO()
    configured: list[str] = []
    monkeypatch.setattr("kp.mcp.cli.configure_logging", configured.append)
    monkeypatch.setattr("sys.stdin", io.StringIO(CALL + "\n"))
    monkeypatch.setattr("sys.stdout", stdout)
    for name, value in ENV.items():
        monkeypatch.setenv(name, value)
    for name, value in {
        "KP_MODE": "local",
        "KP_DATABASE_URL": settings.database_url.get_secret_value(),
        "KP_IDENTITY_MAPPING_FILE": str(settings.identity_mapping_file),
    }.items():
        monkeypatch.setenv(name, value)

    assert args.handler(args) == 0
    assert json.loads(stdout.getvalue())["id"] == 2
    assert configured == ["INFO"]


def test_us22_serve_write_serves_only_the_write_tools(settings: Settings) -> None:
    write: WriteToolPort = FakeWritePort()
    wiring = ServeWiring(write_port=lambda _s, _d: write)
    args = build_parser(wiring).parse_args(["serve-write"])
    stdout = io.StringIO()
    listing = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})

    status = handle_serve_write(
        args,
        wiring,
        settings=settings,
        stdin=io.StringIO(listing + "\n"),
        stdout=stdout,
        environ=ENV,
    )

    assert status == 0
    tools = json.loads(stdout.getvalue())["result"]["tools"]
    assert [t["name"] for t in tools] == ["publish_spec"]


def test_us16_http_mode_binds_the_requested_host_and_port_and_stops_cleanly(
    ports: ReadPorts, settings: Settings, monkeypatch: pytest.MonkeyPatch
) -> None:
    events: list[object] = []

    class FakeHttpServer:
        def serve_forever(self) -> None:
            events.append("serving")
            raise KeyboardInterrupt

        def server_close(self) -> None:
            events.append("closed")

    def fake_create(gateway: object, host: str, port: int) -> FakeHttpServer:
        events.append((host, port))
        return FakeHttpServer()

    monkeypatch.setattr("kp.mcp.cli.create_http_server", fake_create)
    wiring = ServeWiring(read_ports=lambda _s, _d: ports)
    args = build_parser(wiring).parse_args(["serve-read", "--http", "8765"])

    status = handle_serve_read(args, wiring, settings=settings, environ=ENV)

    assert status == 0
    assert events == [("127.0.0.1", 8765), "serving", "closed"]


class _StoppingHttpServer:
    def serve_forever(self) -> None:
        raise KeyboardInterrupt

    def server_close(self) -> None:
        return None


def test_us17_a_non_loopback_host_is_refused_without_a_trusted_proxy(
    ports: ReadPorts,
    settings: Settings,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    bound: list[str] = []

    def fake_create(gateway: object, host: str, port: int) -> _StoppingHttpServer:
        bound.append(host)
        return _StoppingHttpServer()

    monkeypatch.setattr("kp.mcp.cli.create_http_server", fake_create)
    wiring = ServeWiring(read_ports=lambda _s, _d: ports)
    args = build_parser(wiring).parse_args(
        ["serve-read", "--http", "8765", "--host", "0.0.0.0"]  # noqa: S104
    )

    status = handle_serve_read(args, wiring, settings=settings, environ=ENV)

    assert status == 2
    assert bound == []
    assert "--trusted-proxy" in capsys.readouterr().err


@pytest.mark.parametrize(
    ("extra", "host"),
    [
        ([], "127.0.0.1"),
        ([], "localhost"),
        ([], "::1"),
        (["--trusted-proxy"], "0.0.0.0"),  # noqa: S104
        (["--trusted-proxy"], "10.1.2.3"),
    ],
)
def test_us17_loopback_or_trusted_proxy_hosts_are_bound(
    ports: ReadPorts,
    settings: Settings,
    monkeypatch: pytest.MonkeyPatch,
    extra: list[str],
    host: str,
) -> None:
    bound: list[str] = []

    def fake_create(gateway: object, host: str, port: int) -> _StoppingHttpServer:
        bound.append(host)
        return _StoppingHttpServer()

    monkeypatch.setattr("kp.mcp.cli.create_http_server", fake_create)
    wiring = ServeWiring(read_ports=lambda _s, _d: ports)
    args = build_parser(wiring).parse_args(["serve-read", "--http", "8765", "--host", host, *extra])

    assert handle_serve_read(args, wiring, settings=settings, environ=ENV) == 0
    assert bound == [host]
