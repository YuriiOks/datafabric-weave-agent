"""US-17: a user without access is refused; domain always comes from the identity."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import JsonValue
from tools_fixtures import *  # noqa: F403 - pytest fixtures

from kp.errors import AccessForbiddenError
from kp.tools import (
    Caller,
    IdentityMapping,
    IdentityMappingError,
    InvalidToolArgumentsError,
    ToolRegistry,
    build_caller,
)
from kp.tools.testing import FakeSearch, InMemoryAudit

SEARCH_ARGS: dict[str, JsonValue] = {"query": "currency"}
ALL_TOOLS: list[tuple[str, dict[str, JsonValue]]] = [
    ("search", SEARCH_ARGS),
    ("links", {"item_type": "clause", "key": "2026.1:4.2.1"}),
    ("template", {"spec_type": "functional"}),
    ("rule_as_at", {"number": "4.2.1"}),
    ("coverage", {}),
]


def caller(user: str | None) -> Caller:
    return build_caller(user=user, agent="spec-agent", session_id="session-1")


def test_us17_user_without_access_is_forbidden_not_empty(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    with pytest.raises(AccessForbiddenError):
        registry.call(caller("user-no-access"), "search", SEARCH_ARGS)

    (record,) = audit.records
    assert record.refused is True
    assert record.items_returned == 0
    assert record.domains_applied == ()


@pytest.mark.parametrize(("tool", "arguments"), ALL_TOOLS)
def test_us17_every_tool_refuses_a_user_without_access(
    registry: ToolRegistry, audit: InMemoryAudit, tool: str, arguments: dict[str, JsonValue]
) -> None:
    with pytest.raises(AccessForbiddenError):
        registry.call(caller("user-no-access"), tool, arguments)

    assert [record.refused for record in audit.records] == [True]
    assert audit.records[0].tool == tool


def test_us17_unknown_user_is_forbidden(registry: ToolRegistry) -> None:
    with pytest.raises(AccessForbiddenError):
        registry.call(caller("someone-not-in-the-mapping"), "search", SEARCH_ARGS)


def test_us17_unauthenticated_caller_is_forbidden_and_recorded(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    with pytest.raises(AccessForbiddenError):
        registry.call(caller(None), "search", SEARCH_ARGS)

    assert audit.records[0].caller == "anonymous"
    assert audit.records[0].refused is True


def test_us17_one_domain_user_sees_only_that_domain_and_the_filtered_count(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    result = registry.call(caller("user-one-domain"), "search", SEARCH_ARGS)

    hits = result.payload["hits"]
    assert isinstance(hits, list)
    assert {hit["domain"] for hit in hits if isinstance(hit, dict)} == {"payments"}
    # The cards passage and the unlabelled one are counted, never shown.
    assert result.payload["filtered_out"] == 2
    assert "cards:limit" not in json.dumps(result.payload)
    assert "unlabelled" not in json.dumps(result.payload)
    assert audit.records[0].filtered_count == 2
    assert audit.records[0].domains_applied == ("payments",)


def test_us17_full_access_user_sees_both_domains(registry: ToolRegistry) -> None:
    result = registry.call(caller("user-full-access"), "search", SEARCH_ARGS)

    hits = result.payload["hits"]
    assert isinstance(hits, list)
    assert {hit["domain"] for hit in hits if isinstance(hit, dict)} == {"payments", "cards"}
    assert result.payload["filtered_out"] == 1  # only the unlabelled passage


def test_us17_user_without_payments_access_is_refused_a_payments_rule(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    with pytest.raises(AccessForbiddenError):
        registry.call(caller("user-no-payments-access"), "rule_as_at", {"number": "4.2.1"})

    assert audit.records[0].refused is True
    assert audit.records[0].domains_applied == ("cards",)


def test_us17_user_without_payments_access_search_hides_payments(registry: ToolRegistry) -> None:
    result = registry.call(caller("user-no-payments-access"), "search", SEARCH_ARGS)

    hits = result.payload["hits"]
    assert isinstance(hits, list)
    assert [hit["domain"] for hit in hits if isinstance(hit, dict)] == ["cards"]
    assert result.payload["filtered_out"] == 2  # the payments clause and the unlabelled one


def test_us17_domain_always_comes_from_identity_not_arguments(
    registry: ToolRegistry, search: FakeSearch
) -> None:
    with pytest.raises(InvalidToolArgumentsError):
        registry.call(caller("user-one-domain"), "search", {"query": "currency", "domain": "cards"})

    registry.call(caller("user-one-domain"), "search", SEARCH_ARGS)
    assert search.calls == [frozenset({"payments"})]


def test_us17_no_tool_accepts_a_domain_argument(registry: ToolRegistry) -> None:
    for definition in registry.definitions():
        properties = definition.input_schema.get("properties", {})
        assert isinstance(properties, dict)
        assert "domain" not in properties
        assert "domains" not in properties
        assert definition.input_schema["additionalProperties"] is False


def test_us17_unlabelled_items_are_hidden_from_everyone(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    # The only match is unlabelled, so nothing may be shown: refused, as for any hidden match.
    with pytest.raises(AccessForbiddenError):
        registry.call(caller("user-full-access"), "search", {"query": "unlabelled"})

    assert audit.records[0].refused is True


def test_us17_search_matching_only_hidden_domains_is_forbidden_not_empty(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    # user-no-payments-access holds cards only; this text exists in payments only.
    with pytest.raises(AccessForbiddenError):
        registry.call(
            caller("user-no-payments-access"), "search", {"query": "inbound credit transfer"}
        )

    (record,) = audit.records
    assert record.refused is True
    assert record.refusal_reason is not None
    assert record.error_class == "AccessForbiddenError"
    assert record.domains_applied == ("cards",)
    assert record.items_returned == 0


def test_us17_search_with_no_match_at_all_is_an_empty_result_not_forbidden(
    registry: ToolRegistry,
) -> None:
    result = registry.call(caller("user-no-payments-access"), "search", {"query": "zzzzz"})

    assert result.payload["hits"] == []
    assert result.payload["filtered_out"] == 0


def test_us17_identity_mapping_loads_the_committed_test_users(mapping: IdentityMapping) -> None:
    assert mapping.domains_for("user-full-access") == {"cards", "payments"}
    assert mapping.domains_for("user-one-domain") == {"payments"}
    assert mapping.domains_for("user-no-access") == frozenset()
    assert mapping.domains_for("nobody") == frozenset()


@pytest.mark.parametrize(
    "content",
    [
        "version: 2\nusers: {}\n",
        "version: 1\nusers:\n  a: {domains: payments}\n",
        "version: 1\nusers:\n  anonymous: {domains: [payments]}\n",
        "version: 1\nusers: {}\nextra: 1\n",
        ": : not yaml : [",
    ],
)
def test_us17_malformed_identity_mapping_is_rejected(tmp_path: Path, content: str) -> None:
    path = tmp_path / "mapping.yaml"
    path.write_text(content, encoding="utf-8")

    with pytest.raises(IdentityMappingError):
        IdentityMapping.from_file(path)


def test_us17_missing_identity_mapping_is_rejected(tmp_path: Path) -> None:
    with pytest.raises(IdentityMappingError):
        IdentityMapping.from_file(tmp_path / "absent.yaml")


@pytest.mark.parametrize("claim", ["", "has space", "x" * 200, "new\nline", "a;b"])
def test_us17_malformed_user_claim_becomes_anonymous(claim: str) -> None:
    built = build_caller(user=claim, agent="a", session_id="s")

    assert built.authenticated is False
    assert built.user == "anonymous"


def test_us17_malformed_audit_labels_fall_back_to_defaults() -> None:
    built = build_caller(user="user-one-domain", agent="bad agent", session_id="x y", spec_id="z z")

    assert built.authenticated is True
    assert built.agent == "unknown-agent"
    assert built.spec_id is None
    assert built.session_id.isalnum()
