#!/bin/bash
# Apply the skills-repository link change to a checkout and run the checks for it.
# usage: bash apply.sh <checkout root>
#   PY=<python for the edit script>  BPY=<backend venv python, default: the main checkout's>
# edit_links.py checks every anchor first and writes nothing unless all of them hold.
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
cd "${1:?checkout root}" || exit 1
ROOT=$(pwd)
BPY="${BPY:-$ROOT/../../backend/.venv/bin/python}"
"${PY:-python3}" "$HERE/edit_links.py" || exit 1
git diff --stat | tail -2
git status --short | grep -c "??"
(cd backend && "$BPY" -m pytest tests/recsys/api/test_source_links.py tests/recsys/contracts \
  tests/recsys/api/test_router.py tests/recsys/api/test_repository.py \
  tests/recsys/api/test_openapi_and_mounting.py -q -p no:cacheprovider 2>&1 | tail -10)
echo PYTEST_DONE
cd frontend || exit 1
npx eslint src/features/recsys 2>&1 | tail -10
echo ESLINT_DONE
npx tsc -b --force > /tmp/tsc.log 2>&1
echo "TSC=$?"
tail -6 /tmp/tsc.log
npx vitest run src/features/recsys 2>&1 | grep -E "Test Files|Tests |FAIL|AssertionError|Error:" | head -12
