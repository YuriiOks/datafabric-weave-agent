---
pack_id: "bpc-sep26-v1"
local_id: "CORE-06"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Add a shared refresh and evidence status interface"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-15"
planned_due: "2026-09-16"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-06"
architecture_sections: ["source-refresh","read-contract"]
---

# Add a shared refresh and evidence status interface

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-06** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-15 → 2026-09-16 (D5–D6)**.
- Recommendation extension: **2026-09-15 → 2026-09-16 (D5–D6)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Let an authorised user inspect source freshness and request a guarded refresh without misreading fetched data as an activated catalogue.

## Scope and contract

Use the existing frontend surface established by reconciliation. Implement against frozen mock DTOs first, then integrate CORE-05 and CORE-04. One shared shell serves all three types; no three independent refresh buttons or status stores.

## Implementation sequence

1. Map the current status/explorer components and use existing application design and generated API types.
2. Display current publication separately from latest job, source fetch time/freshness, actual completed stages and safe counts.
3. Implement explicit unsupported, unavailable, queued, running, succeeded, failed and cancelled states with current-policy-safe messages.
4. Wire refresh/retry/cancel eligibility to server responses and idempotency keys; disable repeat clicks without treating browser state as server concurrency protection.
5. Use polling first where supported; optional SSE is not required for the first delivery. If enabled, require bounded history/cursor and policy revalidation.
6. Integrate the real job/read services before acceptance and verify keyboard/accessibility and failure views.

## Acceptance criteria

- [ ] No fabricated progress percentage or success inference from 202, fetch completion or terminal job state.
- [ ] Users cannot see private source inventory or diagnostics through errors/status.
- [ ] UI refresh control is unavailable until the backend capability is proven and authorized.
- [ ] Page reload or another replica can retrieve current durable status.
- [ ] One shared UI component handles all three source domains.

## Verification

- UI/contract cases cover double click, denied status, stale publication, failed latest refresh, expired event cursor if used and retry eligibility change.
- Demonstrate the connected flow with real authorised backend responses; screenshots of mocks alone are insufficient.

## Evidence to attach

- UI recording/screenshots, real request/status traces, generated type check and relevant CI.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

CORE-02 allows mock-contract work before backend completion. The final integration/acceptance handoff depends on CORE-04 and CORE-05 and is checked in CORE-09. No browser-held Git credential or arbitrary repository input.

## Completion handoff

The scheduled task produces a tested contract-driven UI shell. Live enablement is not accepted or reported complete until CORE-09 demonstrates the connected CORE-04/05/13 services and current authorization. Keep controls disabled while backend capability is unavailable.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `source-refresh`, `read-contract`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
