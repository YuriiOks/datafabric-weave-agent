---
pack_id: "bpc-sep26-v1"
local_id: "CORE-09"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Qualify integrated source-to-result behavior and release readiness"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-25"
planned_due: "2026-09-25"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-04","CORE-05","CORE-06","CORE-07","CORE-11","CORE-12","SKL-04","MCP-04","AGT-04","CORE-13","CORE-15"]
recommendation_dependencies: ["CORE-08","SKL-05","MCP-06","AGT-05"]
jira_marker: "bpc-sep26-core-09"
architecture_sections: ["validation-gates","acceptance","evaluation","operations"]
---

# Qualify integrated source-to-result behavior and release readiness

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-09** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-25 → 2026-09-25 (D13–D13)**.
- Recommendation extension: **2026-09-28 → 2026-09-29 (D14–D15)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Produce actual acceptance evidence for the integrated implementation, including failures, before any wider enablement or parent completion.

## Scope and contract

Cover graph’s 19 acceptance scenarios, controlled refresh and shared AI contracts. If recommendation mode is selected, add CORE-08 and every per-type recommendation acceptance task as required dependencies and run per-type quality gates. Tests and peer review already count in component estimates; this task covers integration and final evidence synthesis.

## Implementation sequence

1. Collect immutable source/code/config manifests and exact expected graph facts for the approved scope.
2. Run the approved CI/integration and fault cases, including cross-source references, bad input, policy change, replay, worker loss and rollback.
3. Measure the deployed minimum workload plus approved growth/high-degree and policy-selectivity stress, including reads during refresh and active/candidate/retained generations.
4. Run the frozen task-specific replay/evaluation; show all planned outcomes and denominators. Domain reviewers own labels and risk thresholds fixed before seeing results.
5. Rehearse shadow or controlled-cohort enablement under shared budgets, rollback and current-policy preservation.
6. Record pass/fail per requirement with CI/run references; retain blockers and prevent parent completion on missing evidence.

## Acceptance criteria

- [ ] Every committed requirement has observable evidence or an explicit blocker; no unexecuted case is marked passed.
- [ ] Zero observed access/fabricated-ID/mixed-publication regressions and approved latency/freshness/resource budgets are required for enablement.
- [ ] Quality is reported by task/type with coverage, latency and cost; a small aggregate cannot hide weak types.
- [ ] Rollout/rollback configuration is compatible and source/model/policy versions are recorded.

## Verification

- Use the approved bank CI/runtime, not synthetic screenshots or local laptop results.
- Use a separate held-out split for release claims; a test-driven tuning change requires a new held-out acceptance set.

## Evidence to attach

- Acceptance matrix, CI IDs, paired evaluation report, fault/load report and rollout/rollback rehearsal.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Numeric quality and capacity limits require named domain/platform owners before the run. A failed gate means a blocked capability or agreed replan, not automatic scope reduction with a green parent.

## Delayed source regression case

Execute the architecture A18 case: activate a newer source collection that retires a fact, then submit an older but complete snapshot. Activation must reject the regressing vector and the retired fact must remain absent. Include carried-source age preservation and ambiguous ordering refusal in the recorded result.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [CORE-05](CORE-05.md) must finish its stated contract boundary before this task starts.
- [CORE-06](CORE-06.md) must finish its stated contract boundary before this task starts.
- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.
- [CORE-11](CORE-11.md) must finish its stated contract boundary before this task starts.
- [CORE-12](CORE-12.md) must finish its stated contract boundary before this task starts.
- [SKL-04](SKL-04.md) must finish its stated contract boundary before this task starts.
- [MCP-04](MCP-04.md) must finish its stated contract boundary before this task starts.
- [AGT-04](AGT-04.md) must finish its stated contract boundary before this task starts.
- [CORE-13](CORE-13.md) must finish its stated contract boundary before this task starts.
- [CORE-15](CORE-15.md) must finish its stated contract boundary before this task starts.
- In recommendation mode, additionally require [CORE-08](CORE-08.md), [SKL-05](SKL-05.md), [MCP-06](MCP-06.md), [AGT-05](AGT-05.md).

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `validation-gates`, `acceptance`, `evaluation`, `operations`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
