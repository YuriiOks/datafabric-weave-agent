"""The items a knowledge version publishes, and whether each one can name its source."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol

from sqlalchemy import Connection, Table, and_, select
from sqlalchemy.sql.elements import ColumnElement

from kp.domain import DomainModel, ItemRef, ItemType, SourceKind
from kp.store.schema import clause, edition, passage, requirement, source_item, story

KIND_CLAUSE = "clause"
KIND_REQUIREMENT = "requirement"
KIND_STORY = "story"
KIND_PASSAGE = "passage"


class CatalogItem(DomainModel):
    """One published item.

    ``ref`` is the link endpoint of the item, or ``None`` for items that links never
    connect (passages). ``has_source`` is True when the item can name the source item
    version it was read from.
    """

    kind: str
    key: str
    ref: ItemRef | None
    has_source: bool


class ItemCatalogPort(Protocol):
    """Lists what a knowledge version would publish. Replaceable by the integrator."""

    def items(self) -> Sequence[CatalogItem]:
        """List the items.

        :return: Every item the version would publish
        """
        ...


def _same_version(table: Table) -> ColumnElement[bool]:
    """Join condition from a table with ``source``, ``item_id`` and ``version`` columns."""
    return and_(
        source_item.c.source == table.c.source,
        source_item.c.item_id == table.c.item_id,
        source_item.c.version == table.c.version,
    )


class DatabaseItemCatalog:
    """Reads the published items from the tables.

    * clauses and requirements: the source item version their edition or register row
      points at;
    * stories: any loaded version of the story's tracker item;
    * passages: the source item version they were cut from.

    Specs and templates are outputs and governance records, not sourced knowledge, so they
    are not listed. Code, tests and schema fields exist only as link endpoints.

    :param connection: A connection inside the caller's unit of work
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def items(self) -> list[CatalogItem]:
        """List clauses, requirements, stories and passages.

        :return: Every item with its source flag, in a stable order
        """
        return [*self._clauses(), *self._requirements(), *self._stories(), *self._passages()]

    def _clauses(self) -> list[CatalogItem]:
        statement = (
            select(clause.c.edition, clause.c.number, source_item.c.item_id.label("found"))
            .select_from(
                clause.join(edition, clause.c.edition == edition.c.label).outerjoin(
                    source_item, _same_version(edition)
                )
            )
            .order_by(clause.c.edition, clause.c.number)
        )
        return [
            CatalogItem(
                kind=KIND_CLAUSE,
                key=f"{row.edition}:{row.number}",
                ref=ItemRef(item_type=ItemType.CLAUSE, key=f"{row.edition}:{row.number}"),
                has_source=row.found is not None,
            )
            for row in self._connection.execute(statement)
        ]

    def _requirements(self) -> list[CatalogItem]:
        statement = (
            select(requirement.c.requirement_id, source_item.c.item_id.label("found"))
            .select_from(requirement.outerjoin(source_item, _same_version(requirement)))
            .order_by(requirement.c.requirement_id)
        )
        return [
            CatalogItem(
                kind=KIND_REQUIREMENT,
                key=row.requirement_id,
                ref=ItemRef(item_type=ItemType.REQUIREMENT, key=row.requirement_id),
                has_source=row.found is not None,
            )
            for row in self._connection.execute(statement)
        ]

    def _stories(self) -> list[CatalogItem]:
        tracked = {
            row.item_id
            for row in self._connection.execute(
                select(source_item.c.item_id).where(source_item.c.source == SourceKind.JIRA.value)
            )
        }
        keys = self._connection.execute(
            select(story.c.story_key).distinct().order_by(story.c.story_key)
        ).scalars()
        return [
            CatalogItem(
                kind=KIND_STORY,
                key=key,
                ref=ItemRef(item_type=ItemType.STORY, key=key),
                has_source=key in tracked,
            )
            for key in keys
        ]

    def _passages(self) -> list[CatalogItem]:
        statement = (
            select(passage.c.passage_id, source_item.c.item_id.label("found"))
            .select_from(passage.outerjoin(source_item, _same_version(passage)))
            .order_by(passage.c.passage_id)
        )
        return [
            CatalogItem(
                kind=KIND_PASSAGE, key=row.passage_id, ref=None, has_source=row.found is not None
            )
            for row in self._connection.execute(statement)
        ]
