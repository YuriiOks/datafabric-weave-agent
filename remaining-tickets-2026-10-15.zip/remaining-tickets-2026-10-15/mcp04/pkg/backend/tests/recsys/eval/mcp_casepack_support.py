"""A synthetic MCP corpus and a case pack covering every required MCP scenario."""

from __future__ import annotations

from app.recsys.contracts import ComponentType
from app.recsys.contracts.catalogue import QualityFlag
from app.recsys.contracts.sources import SourceAuthority, SourceCollection
from app.recsys.eval.casepack.cases import (
    EvaluationCase,
    EvidenceKind,
    EvidenceRequirement,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.casepack.corpus import CorpusManifest
from app.recsys.eval.casepack.lineage import CasePackLineage

from . import casepack_support as support

EXPORT_REVISION = "export-7"
EXPORT_CONFIGURATION = "registered-export-1"


def mcp_id(number: int) -> str:
    """:return: The component id of synthetic MCP ``number`` (ids from 11 up)."""
    return support.component_id(10 + number)


def mcp_record(number: int, **values):
    """:return: A synthetic published MCP record."""
    evidence = support.evidence(
        10 + number,
        authority=SourceAuthority.agent_hub_export,
        revision=EXPORT_REVISION,
        configuration=EXPORT_CONFIGURATION,
        collection=SourceCollection.mcp_records,
    )
    values.setdefault("name", f"Synthetic server {number}")
    values.setdefault("description", "Answers made-up lookups for a synthetic team.")
    return support.record(
        10 + number,
        component_type=ComponentType.mcp,
        evidence_items=[evidence],
        **values,
    )


def mcp_corpus(*, access_policy_revision: str | None = "read-policy-1") -> CorpusManifest:
    """:return: Six published MCPs; number 3 has an empty description."""
    records = [
        mcp_record(1),
        mcp_record(2),
        mcp_record(3, description="", flags=(QualityFlag.empty_description,)),
        mcp_record(4),
        mcp_record(5),
        mcp_record(6),
    ]
    return support.corpus(
        records,
        component_type=ComponentType.mcp,
        access_policy_revision=access_policy_revision,
    )


def _case(number: int, lineage: CasePackLineage, **values) -> EvaluationCase:
    values.setdefault("group", "g-final" if number <= 2 else f"g-dev-{number}")
    return support.case(
        number, lineage=lineage, prefix="mcp", component_type=ComponentType.mcp, **values
    )


def mcp_cases(lineage: CasePackLineage) -> list[EvaluationCase]:
    """:return: One case per required MCP scenario, the first two judged."""
    return [
        _case(
            1,
            lineage,
            adjudication=support.judged({mcp_id(1): RelevanceLabel.relevant}),
        ),
        _case(
            2,
            lineage,
            scenario=Scenario.partial,
            adjudication=support.judged({mcp_id(2): RelevanceLabel.partially_relevant}),
        ),
        _case(3, lineage, scenario=Scenario.hard_negative, forbidden=[mcp_id(4)]),
        _case(
            4,
            lineage,
            scenario=Scenario.valid_empty,
            expected=ExpectedOutcome.valid_empty,
        ),
        _case(
            5,
            lineage,
            scenario=Scenario.duplicate_alias,
            required_evidence=[
                EvidenceRequirement(
                    kind=EvidenceKind.duplicate_identity,
                    subject_id=mcp_id(5),
                    related_id=mcp_id(6),
                )
            ],
        ),
        _case(
            6,
            lineage,
            scenario=Scenario.unresolved_dependency,
            required_evidence=[
                EvidenceRequirement(kind=EvidenceKind.unresolved_reference, subject_id=mcp_id(1))
            ],
        ),
        _case(
            7,
            lineage,
            scenario=Scenario.access_restricted,
            expected=ExpectedOutcome.access_filtered,
            forbidden=[mcp_id(4)],
        ),
        _case(
            8,
            lineage,
            scenario=Scenario.unknown_prerequisite,
            required_evidence=[
                EvidenceRequirement(kind=EvidenceKind.prerequisite_unknown, subject_id=mcp_id(2))
            ],
        ),
        _case(
            9,
            lineage,
            scenario=Scenario.conflict,
            required_evidence=[
                EvidenceRequirement(kind=EvidenceKind.source_conflict, subject_id=mcp_id(4))
            ],
        ),
    ]
