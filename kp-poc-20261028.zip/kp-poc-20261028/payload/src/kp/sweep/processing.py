"""The content processor used until the parsers are connected."""

from __future__ import annotations

from sqlalchemy import Connection

from kp.domain import SourceItemVersion


class NullContentProcessor:
    """Accepts every version and does nothing with it."""

    def fingerprint(
        self,
        version: SourceItemVersion,  # noqa: ARG002 - port signature
        content: bytes,  # noqa: ARG002 - port signature
    ) -> str | None:
        """Report that no version is semantically comparable.

        :param version: Ignored
        :param content: Ignored
        :return: Always ``None``, so every new version counts as work
        """
        return None

    def process(
        self,
        connection: Connection,
        version: SourceItemVersion,
        content: bytes,
    ) -> None:
        """Do nothing.

        :param connection: Ignored
        :param version: Ignored
        :param content: Ignored
        """
