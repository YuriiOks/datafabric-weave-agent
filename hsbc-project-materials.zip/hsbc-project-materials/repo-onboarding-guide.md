# DMC Workspace Complete Onboarding Guide

Author: GitHub Copilot (GPT-5.3-Codex)

Date: 2026-07-06 (updated 2026-07-07 with dtas-api-gateway)

## 1. What this workspace is

[certain] This workspace contains **four** related products:

- **dtas-api-gateway**: Flask API gateway — authenticates all inbound requests and reverse-proxies them to backend services. This is the network entry point every UI talks to.
- **data-controls-automation-api**: Python FastAPI backend for Data Controls automation and CDAO tag governance. This is the primary upstream of the gateway.
- **data-controls-automation-ui**: React SPA that sends requests through the gateway on port 8082.
- **data-management-centre**: Newer TanStack Start rewrite (frontend + server functions) for Data Management Center workflows.

Evidence:

- workspace-context.md
- data-controls-automation-api/main.py
- data-controls-automation-ui/src/main.tsx
- data-management-centre/src/router.tsx

[likely] Current strategy appears to be evolution from the older automation UI toward the newer DMC app, while keeping old services and domain logic active.

Evidence:

- data-management-centre/PRD.md
- data-management-centre/PLAN.md
- data-controls-automation-ui/DATA_CONTROLS_JOURNEY_README.md

## 2. Business domain in plain language

### 2.1 Core business problem

[certain] The platform helps application owners and governance users prove that application data controls are in place and auditable.

Functional areas:

- Data Movement controls (DMOV): document integrations and integrity evidence.
- Data Use controls (DUSE): metadata harvesting, scoping, and data quality.
- CDAO governance: assign and approve tags (for SoR/GDC style governance metadata).
- DMS Governance approvals: second-line approvals for regulated/PRA scope changes.

Evidence:

- data-controls-automation-ui/DATA_CONTROLS_JOURNEY_README.md
- data-management-centre/PRD.md
- data-controls-automation-api/automation_api/routers/cdao_tags.py

### 2.2 Personas and permissions

[certain] The new DMC explicitly models six personas:

- itso
- itso_delegate
- collaborator
- cdao
- dms_governance
- read_only

And a permission matrix maps each persona to edit/approve capabilities.

Evidence:

- data-management-centre/src/lib/personas.ts
- data-management-centre/src/types/auth.ts

## 3. How the 4 repos connect

## 3.1 System-level picture

[certain]

1. User authenticates via DSP (ForgeRock/OpenAM) and receives an AMToken cookie or Bearer token.
2. UI sends all API requests to the **dtas-api-gateway** (port 8082).
3. Gateway performs E2E JWT auth, then reverse-proxies to the correct upstream backend.
4. Backend service reads/writes DB and external systems; returns response back through the gateway.
5. Governance actions are recorded and often require approval flow in the backend.

Legacy path (automation UI -> gateway -> API):

- Browser -> React app -> fetchService (Authorization Bearer AMToken) -> dtas-api-gateway:8082 -> data-controls-automation-api.

Gateway routing rules:

- /* (catch-all) -> DTAS_API_SERVICE (data-controls-automation-api)
- /dq-app/* -> DQ_API_SERVICE (separate DQ service)
- /aris/* -> ARIS_API_SERVICE (separate ARIS service)

New DMC path (does not currently route through gateway):

- Browser -> TanStack Router pages -> TanStack Query hooks -> TanStack createServerFn handlers -> mock or server data sources.

Evidence:

- dtas-api-gateway/README.md ("DTAS UI expects API to be on port 8082")
- dtas-api-gateway/app.py
- dtas-api-gateway/apis/api_gateway.py
- dtas-api-gateway/settings/base_config.py
- data-controls-automation-api/auth.py ("APIKeyHeader(name=\"X-HSBC-E2E-Trust-Token\")")
- data-controls-automation-ui/src/services/fetchService.ts
- data-management-centre/src/queries/applications.ts

[likely] Both UI systems can co-exist in environment while rewrite matures. DMC will eventually wire to same or equivalent backend gateway.

Evidence:

- Both repos actively contain complete runtime entrypoints and domain pages.

## 4. Repo 1: dtas-api-gateway (Flask API Gateway)

## 4.1 Technical architecture

### What it does

[certain] Flask app that acts as a transparent reverse proxy. Every inbound request is:

1. Authenticated (AM token -> E2E JWT, or direct E2E trust token for IB2B callers).
2. Forwarded verbatim to the correct upstream service.
3. The upstream response is streamed back to the caller.

Evidence:

- dtas-api-gateway/app.py
- dtas-api-gateway/apis/api_gateway.py
- dtas-api-gateway/models/api_service.py

### Upstream routing table

[certain]

| URL prefix | Upstream config key | Default URL |
|---|---|---|
| /* (catch-all) | DTAS_API_SERVICE | http://localhost:5000/ |
| /dq-app/* | DQ_API_SERVICE | http://localhost:8001/ |
| /aris/* | ARIS_API_SERVICE | http://localhost:8080/ |

Evidence:

- dtas-api-gateway/apis/api_gateway.py (three Blueprint routes)
- dtas-api-gateway/settings/base_config.py

### Configuration and environments

[certain] Environment selected via `ENV_STATE` env var; config factory returns the matching class:

- dev: DSP at `cmb-staff-dsp-dev.hk.hsbc:8443`
- uat: DSP at `cmb-staff-dsp-uat.systems.uk.hsbc:8443`
- prod: DSP at `cmb-staff-dsp.systems.uk.hsbc:8443`

Evidence:

- dtas-api-gateway/settings/__init__.py
- dtas-api-gateway/settings/dev.py / uat.py / prod.py

## 4.2 Authentication pipeline

[certain] The `AuthenticationTask` runs before every proxy call:

1. Check for `X-HSBC-E2E-Trust-Token` header — if present, use it directly (IB2B / service-to-service caller).
2. Else extract AM session token from `AMToken` cookie or `Authorization: Bearer` header.
3. POST to DSP token translator endpoint to exchange AM token for an E2E JWT.
4. Validate the JWT: parse it, check expiry with ±2s clock skew, verify RSA-SHA256 signature against PKMS manifest public keys.
5. If valid: inject `X-HSBC-E2E-Trust-Token` header and call upstream.
6. If invalid: return 401 “Failed to authenticate user”.

Evidence:

- dtas-api-gateway/models/authentication.py
- dtas-api-gateway/models/gateway_tasks.py
- dtas-api-gateway/e2e_verifier/e2e_driver.py
- dtas-api-gateway/e2e_verifier/token_verifier.py
- dtas-api-gateway/e2e_verifier/token_validator.py
- dtas-api-gateway/e2e_verifier/manifest_verifier.py

### PKMS manifest key caching

[certain] The JWT public key manifest is fetched from a remote URL and cached in-process. On cache miss or signature change it refetches. The manifest includes multiple key versions (`kid` lookup with fallback to `old` key) to support key rotation without downtime.

Evidence:

- dtas-api-gateway/e2e_verifier/manifest_verifier.py

## 4.3 Business logic

[certain] The gateway encapsulates no domain logic. Its sole purpose is:

- Security enforcement (all traffic must carry a valid HSBC E2E JWT).
- Transparent routing without modifying request/response payloads.

## 4.4 Component inventory (gateway repo)

- apis/api_gateway.py: Flask Blueprint with three catch-all proxy routes.
- apis/__init__.py: Flask app factory.
- models/api_service.py: BaseApiService with get_response + call_api proxy logic.
- models/authentication.py: AM+E2E token exchange and validation orchestration.
- models/gateway_tasks.py: AuthenticationTask base class and implementation.
- models/dtas_api_service.py / dq_api_service.py / aris_api_service.py: per-upstream specializations.
- e2e_verifier/e2e_driver.py: JWTE2EVerifier wrapping full validation flow.
- e2e_verifier/token_verifier.py: JWT parsing and expiry check.
- e2e_verifier/token_validator.py: RSA signature verification.
- e2e_verifier/manifest_verifier.py: PKMS manifest fetch/cache/key lookup.
- settings/: environment config factory (dev/uat/prod).
- utils/errors.py: AuthenticationError exception.
- pytests/: pytest coverage for gateway, auth, token parsing.

## 5. Repo 2: data-controls-automation-api (Python backend)

## 4.1 Technical architecture

### Entrypoint and middleware

[certain] `main.py` builds FastAPI app with:

- global auth dependency (`Depends(get_user)`)
- gzip middleware
- correlation id middleware
- structured logging middleware
- exception handlers
- routers: health_check, application, cdao_tags
- sqladmin setup

Evidence:

- data-controls-automation-api/main.py
- data-controls-automation-api/admin.py

### Configuration and secrets

[certain] Settings are loaded from env/.env via pydantic-settings and include:

- DB connection string
- Collibra credentials
- LDAP credentials
- CXO/GCP integration settings

Evidence:

- data-controls-automation-api/automation_api/settings.py

### Dependency injection layer

[certain]

- DB session dependency provides AsyncSession.
- Collibra client dependency provides async client context.
- Worker service dependency provides LDAP lookup utilities.

Evidence:

- data-controls-automation-api/automation_api/dependencies/database.py
- data-controls-automation-api/automation_api/dependencies/collibra.py
- data-controls-automation-api/automation_api/dependencies/worker.py

### Data model layer

[certain] SQLAlchemy models cover:

- Application
- ApplicationTag
- ApplicationTagAssociation
- ApplicationTagChangeRequest
- ApplicationDatabase
- ETL/cache/value-stream related entities
- common audit-style base fields (created/updated/deleted by/at)

Evidence:

- data-controls-automation-api/automation_api/database/data_control_scope.py
- data-controls-automation-api/automation_api/database/base.py
- data-controls-automation-api/automation_api/database/__init__.py

## 4.2 Functional logic

#### A) Application listing and enrichment

[certain] Application service composes DTOs by joining value stream info, app table, tag associations, and user tag context.

Evidence:

- data-controls-automation-api/automation_api/services/application.py
- data-controls-automation-api/automation_api/routers/application.py

#### B) CDAO tags CRUD

[certain] CDAO tag service supports:

- create/update tag definitions
- list tags
- fetch app-tag details
- fetch default app-tag based on current user AD groups

Evidence:

- data-controls-automation-api/automation_api/services/cdao_tags.py
- data-controls-automation-api/automation_api/routers/cdao_tags.py

#### C) Change request workflow

[certain] Tag updates/deletes are not always direct writes. They create change requests and can go through multi-stage approval.

Workflow highlights:

1. User raises request (create/update/delete).
2. System checks permission and duplicate pending request.
3. Request may auto-approve in strict conditions.
4. Else it stays pending for primary CDAO and/or DMS governance.
5. Approval applies association updates and stores change history.
6. Rejection/revoke paths exist.

Evidence:

- data-controls-automation-api/automation_api/services/cdao_tags_change_request.py
- data-controls-automation-api/automation_api/database/data_control_scope.py

## 4.3 Business logic in backend

[certain] The following business rules are implemented in code:

- Tag edit rights depend on AD group membership.
- Pending request deduplication: one active pending request per app/tag/requestor.
- PRA-related apps can require DMS governance second-line approval.
- Primary CDAO status affects approval authority.

Evidence:

- data-controls-automation-api/automation_api/services/cdao_tags_change_request.py
- data-controls-automation-api/automation_api/services/application.py
- data-controls-automation-api/auth.py

## 4.4 Batch/orchestration components

[certain] Prefect flows schedule sync jobs for data quality rules and value streams.

[certain] DataSync base pattern:

- starts ETLJob record
- reads BigQuery in batches
- upserts into DB
- marks finished/error status

Evidence:

- data-controls-automation-api/flows.py
- data-controls-automation-api/dags/import_jobs.py
- data-controls-automation-api/dags/queries.py

## 4.5 Component inventory (API repo)

Top-level components and purpose:

- automation_api/collibra: external Collibra client/conditions/entities.
- automation_api/constants: static constants and enums.
- automation_api/database: ORM entities and DB base engine.
- automation_api/dependencies: FastAPI DI providers (db, worker, cxo/collibra).
- automation_api/dto: transport schemas between service and API layers.
- automation_api/routers: HTTP route definitions.
- automation_api/services: business logic and orchestration per domain.
- dags: scheduled ETL/synchronization logic.
- alembic: database migrations.
- k8s/docker/deploy: runtime deployment definitions.
- tests: pytest coverage (currently minimal in visible sample).

## 6. Repo 3: data-controls-automation-ui (legacy React SPA)

## 5.1 Technical architecture

[certain] The UI is React 19 + react-router-dom + TanStack Query + BDL components.

Entry stack:

- BrowserRouter with basename /dmc/
- QueryClientProvider
- NotificationProvider
- AppContextProvider
- AuthWrapper

Evidence:

- data-controls-automation-ui/src/main.tsx
- data-controls-automation-ui/package.json

[certain] Networking is centralized via useFetchService:

- prepends base API URL
- injects Authorization bearer token from app context
- sets JSON content-type by default

Evidence:

- data-controls-automation-ui/src/services/fetchService.ts

## 5.2 Functional logic

### Main route shell

[certain] App.tsx defines visible routes:

- / -> LandingPage
- /applications -> HomePage
- /cdao -> CDAO page
- /data-control-scope/:id? -> DataContract page

Evidence:

- data-controls-automation-ui/src/App.tsx

### HomePage

[certain] HomePage is a data-heavy operations screen with:

- application list query and pagination
- advanced filter query building
- CDAO tagging actions through modal
- multiple API-backed dropdown/filter datasets
- grouped application rows by BUSINESS_APPLICATION_ID

Evidence:

- data-controls-automation-ui/src/pages/Home/HomePage.tsx

### CDAO workspace

[certain] CDAO page exposes tabbed governance views:

- My Tagged Apps
- Pending Approvals
- My Requests

Tabs are permission-aware and counts are user-driven.

Evidence:

- data-controls-automation-ui/src/pages/CDAO/CDAO.tsx
- data-controls-automation-ui/src/types/types.ts
- data-controls-automation-ui/src/hooks/useUserPermissions.ts

### Auth and session bootstrap

[certain] AuthWrapper:

- resolves user/token via DSP auth hooks
- supports bypass auth for local dev
- resolves permissions and stores them in context
- gates rendering until session resolution

Evidence:

- data-controls-automation-ui/src/AuthWrapper.tsx

## 5.3 Business logic visible in UI

[certain]

- UI adapts by permissions (can_tag_applications, pending counts, tag lists).
- CDAO tagging actions are separated from generic browsing.
- Journey docs in repo describe DMOV/DUSE workflow and required backend endpoints.

Evidence:

- data-controls-automation-ui/src/pages/CDAO/CDAO.tsx
- data-controls-automation-ui/API_ENDPOINTS_SUMMARY.md
- data-controls-automation-ui/DATA_CONTROLS_JOURNEY_README.md

## 5.4 Component inventory (UI repo)

Major component families under src:

- api: endpoint-specific wrappers (auth, tags, health).
- components: reusable UI blocks (table, modal, tags, notification, graph, layout).
- context: app-wide state and providers.
- hooks: auth, debouncing, recent apps, user profile/permissions.
- pages: feature screens (Home, CDAO, DataContract, metadata and DQ areas, etc.).
- services: fetch and infrastructure services.
- helpers/types/mocks/icons: utility and typing support.

[likely] This repo is feature-rich but organically grown, with many pages and route-specific widgets.

Evidence:

- data-controls-automation-ui/src/pages contains 100+ TSX files in listing.

## 7. Repo 4: data-management-centre (new TanStack Start app)

## 6.1 Technical architecture

[certain] Stack is modern full-stack React architecture:

- TanStack Start + TanStack Router file routes
- TanStack Query for data orchestration
- server functions via createServerFn
- optional MSW mock layer for local dev
- Drizzle schema/config for DB evolution

Evidence:

- data-management-centre/package.json
- data-management-centre/src/router.tsx
- data-management-centre/src/routes/__root.tsx
- data-management-centre/src/server/*.ts

[certain] Root shell composes:

- Query client provider
- auth context
- sidebar and top header layout
- session cache in sessionStorage
- router context sync with session

Evidence:

- data-management-centre/src/routes/__root.tsx

## 6.2 Route and domain model

[certain] Visible route domains include:

- dashboard/index
- applications registry and command centre
- app-level pages: access, audit, scope, data movement, data quality, data storage, data intelligence, integration manifest, metadata harvesting
- cdao workspace
- governance
- dia

Evidence:

- data-management-centre/src/routes/**
- data-management-centre/PRD.md

## 6.3 Data access pattern (critical for understanding)

[certain] Query files call server functions directly, not raw fetch from components.

Pattern:

- UI route/component -> queryOptions/useMutation in src/queries -> createServerFn in src/server -> mocks/data or backing services.

Evidence:

- data-management-centre/src/queries/applications.ts
- data-management-centre/src/queries/tags.ts
- data-management-centre/src/server/applications.ts
- data-management-centre/src/server/tags.ts

This is a cleaner architecture than directly fetching in page components.

## 6.4 Business logic in DMC

### Persona/authorization model

[certain] DMC has explicit persona and permission matrix controlling edit/manage/approve behavior.

Evidence:

- data-management-centre/src/lib/personas.ts
- data-management-centre/src/lib/guards.ts

### Governance/tag workflow

[certain] Tag governance supports:

- tag change request creation
- BU/DataOrg queue retrieval
- requester queue retrieval
- approve/reject with audit entry write

Evidence:

- data-management-centre/src/server/tags.ts

### Product intent

[certain] DMC PRD positions this app as orchestration layer that aggregates outputs from specialized control systems rather than executing scan engines itself.

Evidence:

- data-management-centre/PRD.md

## 6.5 Component inventory (DMC repo)

Top-level src components:

- components: UI building blocks (AppSidebar, SiteHeader, Grid, IntegrationGraph, SlideDrawer, ActivityTimeline, and ui primitives).
- containers: larger feature composites (for example profile form).
- db: Drizzle schema and DB-adjacent definitions.
- lib: auth/session/persona guards and shared helpers.
- machines: XState process/state machine definitions.
- mocks: normalized mock data, sample JSON, MSW handlers.
- queries: TanStack Query hooks/options by domain.
- routes: file-based route pages.
- server: createServerFn backend handlers.
- types: shared domain types.

## 8. End-to-end business workflows

## 8.1 CDAO tag change workflow (cross-cutting)

Legacy backend authoritative workflow (API repo):

[certain]

1. User calls cdao-tag endpoint.
2. Service validates AD group permissions.
3. Creates change request.
4. Auto-approve only when strict checks pass.
5. Else wait for primary CDAO and/or DMS governance approvals.
6. Approved request mutates tag association and app governance fields.

Evidence:

- data-controls-automation-api/automation_api/routers/cdao_tags.py
- data-controls-automation-api/automation_api/services/cdao_tags_change_request.py

DMC equivalent workflow (new repo):

[likely]

- Implemented with in-memory/mock-first server functions that model request/approve/reject and audit logging behavior, intended to be swapped to persistent backend.

Evidence:

- data-management-centre/src/server/tags.ts
- data-management-centre/src/mocks/handlers.ts
- data-management-centre/PLAN.md

## 8.2 Application command centre workflow (DMC)

[certain]

- Route loads app detail, repos, DQ, integrations, tags, timeline.
- Computes profile completeness and domain status summaries.
- Exposes profile edit drawer and links to domain pages.

Evidence:

- data-management-centre/src/routes/applications/$appId/index.tsx

## 8.3 Journey workflow (legacy UI docs)

[likely] The automation-ui docs define a 4-step guided control journey (DMOV, metadata scan, scope creation, DQ) and required backend contracts.

Evidence:

- data-controls-automation-ui/DATA_CONTROLS_JOURNEY_README.md
- data-controls-automation-ui/API_ENDPOINTS_SUMMARY.md

## 9. Runtime and operations view

## 9.1 Gateway operations

[certain]

- Flask app runs on port 8082 (`app.run(port=8082)`).
- Container deployed on IKP (HSBC internal Kubernetes).
- CORS is open (`origins=['*']`).
- Log rotation via `TimedRotatingFileHandler` when running on Linux.
- Upstream URLs overridable via env vars at runtime.

Evidence:

- dtas-api-gateway/app.py
- dtas-api-gateway/README.md

## 9.2 API repo operations

[certain]

- FastAPI runtime via main.py
- Alembic migrations for DB changes
- Prefect schedule for sync jobs
- Docker/K8s manifests included

Evidence:

- data-controls-automation-api/main.py
- data-controls-automation-api/alembic/
- data-controls-automation-api/flows.py
- data-controls-automation-api/docker/
- data-controls-automation-api/k8s/

## 9.3 UI and DMC operations

[certain]

- automation-ui uses Vite scripts and environment-driven API base URL.
- DMC uses Vite + TanStack Start scripts and supports test/lint/build flows.

Evidence:

- data-controls-automation-ui/package.json
- data-management-centre/package.json

## 10. What is certain vs uncertain

## Certain

- Gateway is the entry point for the legacy UI; all /application and /cdao-tag traffic passes through it.
- Gateway enforces authentication before any call reaches the Python API.
- Python API reads `X-HSBC-E2E-Trust-Token` injected by the gateway to derive user identity and AD groups.
- Core repo boundaries and runtime entrypoints.
- API CDAO change-request/approval code path.
- DMC persona and route structure.
- Legacy UI fetch/query architecture.

## Likely

- DMC does not currently route through the gateway (server functions bypass HTTP layer in current mock mode).
- Strategic migration path from automation-ui toward DMC.
- DMC currently mock-first for several domains while backend integration is staged.
- DQ API and ARIS API are separate services — not in this workspace but reachable via the gateway.

## Guessing

- None used in this guide where direct evidence was unavailable.

## 11. New-joiner learning path (recommended)

If you are new, learn in this order:

1. Read this file completely once.
2. Read the gateway README to understand the network entry point.
3. Read PRD + PLAN in DMC to understand target product state.
4. Read gateway auth pipeline: models/authentication.py -> models/gateway_tasks.py -> e2e_verifier/e2e_driver.py.
5. Read API CDAO flow code path:
   - automation_api/routers/cdao_tags.py
   - automation_api/services/cdao_tags_change_request.py
   - automation_api/database/data_control_scope.py
6. Read legacy UI Home and CDAO pages to understand current user journeys.
7. Read DMC command centre route and matching query/server files to understand new architecture.
8. Finally inspect deployment/runtime files (Docker, k8s, Alembic, Prefect).

## 12. Glossary

- DTAS API Gateway: Flask reverse proxy that authenticates and routes traffic from all UIs to backend services.
- IB2B: Application-to-application call pattern where the caller already holds an E2E trust token.
- PKMS: Public Key Management Service — HSBC service hosting the JWT signing key manifest.
- E2E JWT: End-to-end trust token used internally at HSBC for service-to-service authentication.
- AMToken: ForgeRock/OpenAM session cookie from DSP authentication.
- DSP: Digital Security Platform (ForgeRock-based SSO provider).
- ARIS: Separate application risk/intelligence service proxied at /aris/*.
- DMC: Data Management Centre.
- CDAO: Chief Data and Analytics Office governance domain.
- DMS Governance: second-line governance approver role.
- SoR: System of Record.
- GDC: Group Data Categories.
- PRA scope: regulated scope requiring stronger approval controls.
- DMOV: Data Movement controls.
- DUSE: Data Use controls.

## 13. If you want true line-by-line mastery

[certain] A companion deep-dive with Mermaid flowcharts, full component maps, and cross-repo sequence diagrams is available at REPO_ONBOARDING_FULL_DEPTH.md — updated with the gateway repo.
