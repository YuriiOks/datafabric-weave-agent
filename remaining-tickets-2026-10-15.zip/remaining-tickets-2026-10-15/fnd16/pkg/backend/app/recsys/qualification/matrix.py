"""Typed acceptance matrix: requirements, evidence, blockers, and no recorded pass.

A row says what must be observed, which evidence will show it and who owns it. Its status
is one of ``planned`` (the evidence does not exist yet), ``not_run`` (the evidence exists
but no run against the integrated candidate is recorded) or ``blocked`` (named blockers stop
it from running). There is deliberately no passing status: a pass is a CI or rehearsal run
reference kept with the release evidence, so an unexecuted case can never read as passed.
"""

from __future__ import annotations

import re
from collections import Counter
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, model_validator

#: The architecture's acceptance scenarios, all of which the matrix must carry.
ARCHITECTURE_SCENARIOS: tuple[str, ...] = tuple(f"A{number:02d}" for number in range(1, 20))

#: The controlled-refresh acceptance cases, all of which the matrix must carry.
REFRESH_CASES: tuple[str, ...] = tuple(f"R{number:02d}" for number in range(1, 8))

#: The delayed-source regression extensions recorded beside A18.
DELAYED_SOURCE_CASES: tuple[str, ...] = ("A18-age", "A18-order")

REQUIREMENT_ID_RE = re.compile(r"^(A(0[1-9]|1[0-9])(-[a-z]+)?|R0[1-7]|G0[1-9])$")
BLOCKER_ID_RE = re.compile(r"^[A-Z][0-9]{1,2}$")
TEST_REFERENCE_RE = re.compile(r"^tests/[a-z0-9_/]+\.py$")


class RequirementSource(str, Enum):
    """Where a requirement comes from."""

    architecture_scenario = "architecture_scenario"
    refresh_case = "refresh_case"
    release_gate = "release_gate"


class AcceptanceMode(str, Enum):
    """Which delivery a requirement belongs to."""

    graph = "graph"
    recommendation = "recommendation"


class OwnerRole(str, Enum):
    """Who answers for a requirement's evidence."""

    contracts_owner = "contracts_owner"
    adapters_owner = "adapters_owner"
    source_owner = "source_owner"
    platform_owner = "platform_owner"
    domain_reviewers = "domain_reviewers"


class EvidenceKind(str, Enum):
    """What kind of evidence will show a requirement."""

    existing_test = "existing_test"
    ci_job = "ci_job"
    fault_run = "fault_run"
    load_run = "load_run"
    evaluation_report = "evaluation_report"
    manual_rehearsal = "manual_rehearsal"


class RowStatus(str, Enum):
    """Where a requirement stands. There is no passing state."""

    planned = "planned"
    not_run = "not_run"
    blocked = "blocked"


class Blocker(BaseModel):
    """One named reason a requirement cannot run, and who has to decide it."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    blocker_id: str = Field(pattern=BLOCKER_ID_RE.pattern)
    summary: str = Field(min_length=1, max_length=300)
    decision: str = Field(min_length=1, max_length=300)
    owner_role: OwnerRole


class AcceptanceRow(BaseModel):
    """One committed requirement and the evidence it needs."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    requirement_id: str = Field(pattern=REQUIREMENT_ID_RE.pattern)
    source: RequirementSource
    mode: AcceptanceMode = AcceptanceMode.graph
    title: str = Field(min_length=1, max_length=200)
    observable_result: str = Field(min_length=1, max_length=600)
    owner_role: OwnerRole
    evidence_kind: EvidenceKind
    evidence_reference: str | None = Field(default=None, min_length=1, max_length=200)
    gap: str | None = Field(default=None, min_length=1, max_length=300)
    status: RowStatus
    blocked_by: tuple[str, ...] = ()

    @model_validator(mode="after")
    def _status_matches_evidence(self) -> AcceptanceRow:
        """Check that the status, blockers and evidence reference agree.

        :return: The row.
        :raises ValueError: When a blocked row names no blocker, an unblocked row names
            one, a row that is not planned has no evidence reference, or a test reference
            is not a test path.
        """
        if (self.status is RowStatus.blocked) != bool(self.blocked_by):
            raise ValueError("a row names blockers exactly when it is blocked")
        if len(set(self.blocked_by)) != len(self.blocked_by):
            raise ValueError("a row names each blocker once")
        if self.status is RowStatus.not_run and self.evidence_reference is None:
            raise ValueError("a row that is ready to run names its evidence")
        reference = self.evidence_reference
        if self.evidence_kind is EvidenceKind.existing_test and reference is not None:
            if not TEST_REFERENCE_RE.match(reference):
                raise ValueError("a test reference is a path under tests/")
        return self


class AcceptanceMatrix(BaseModel):
    """Every committed requirement, each exactly once, with the blockers they cite."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    rows: tuple[AcceptanceRow, ...] = Field(min_length=1)
    blockers: tuple[Blocker, ...] = ()

    @model_validator(mode="after")
    def _complete_and_consistent(self) -> AcceptanceMatrix:
        """Check that the matrix covers every required case and cites known blockers.

        :return: The matrix.
        :raises ValueError: When a requirement or blocker repeats, a required case is
            missing, or a row cites an unknown blocker.
        """
        ids = [row.requirement_id for row in self.rows]
        repeated = sorted(key for key, count in Counter(ids).items() if count > 1)
        if repeated:
            raise ValueError(f"requirements listed twice: {', '.join(repeated)}")
        known = [blocker.blocker_id for blocker in self.blockers]
        if len(set(known)) != len(known):
            raise ValueError("a blocker is listed twice")
        required = ARCHITECTURE_SCENARIOS + REFRESH_CASES + DELAYED_SOURCE_CASES
        missing = [key for key in required if key not in set(ids)]
        if missing:
            raise ValueError(f"required cases missing: {', '.join(missing)}")
        cited = {key for row in self.rows for key in row.blocked_by}
        unknown = sorted(cited - set(known))
        if unknown:
            raise ValueError(f"rows cite unknown blockers: {', '.join(unknown)}")
        return self

    def row(self, requirement_id: str) -> AcceptanceRow:
        """Return one requirement.

        :param requirement_id: The requirement id.
        :return: The row.
        :raises KeyError: When the matrix does not list it.
        """
        for item in self.rows:
            if item.requirement_id == requirement_id:
                return item
        raise KeyError(requirement_id)

    def blocked_rows(self, blocker_id: str) -> tuple[str, ...]:
        """Return the requirements one blocker stops.

        :param blocker_id: The blocker id.
        :return: The ids of the rows that cite it, in matrix order.
        """
        return tuple(row.requirement_id for row in self.rows if blocker_id in row.blocked_by)

    def cited_tests(self) -> tuple[str, ...]:
        """Return every existing-test path the matrix cites, once each and sorted.

        :return: Paths relative to the backend root.
        """
        return tuple(
            sorted(
                {
                    row.evidence_reference
                    for row in self.rows
                    if row.evidence_kind is EvidenceKind.existing_test
                    and row.evidence_reference is not None
                }
            )
        )


def status_counts(
    matrix: AcceptanceMatrix, mode: AcceptanceMode | None = None
) -> dict[RowStatus, int]:
    """Count rows by status.

    :param matrix: The matrix.
    :param mode: Count only this delivery's rows (recommendation mode includes the graph
        rows); every row when omitted.
    :return: A count for every status, zero included.
    """
    selected = set(AcceptanceMode) if mode is None else {AcceptanceMode.graph, mode}
    counts = dict.fromkeys(RowStatus, 0)
    for row in matrix.rows:
        if row.mode in selected:
            counts[row.status] += 1
    return counts


def completion_blockers(
    matrix: AcceptanceMatrix, mode: AcceptanceMode = AcceptanceMode.graph
) -> tuple[str, ...]:
    """List why the parent delivery cannot complete on this matrix alone.

    Every row of the selected delivery is listed, because the matrix records no pass: a
    blocked row names its blockers, a planned row has no evidence yet, and a row that is
    ready to run still has no recorded run.

    :param matrix: The matrix.
    :param mode: The delivery being completed; recommendation mode includes graph rows.
    :return: One reason per row, in matrix order.
    """
    selected = {AcceptanceMode.graph, mode}
    reasons: list[str] = []
    for row in matrix.rows:
        if row.mode not in selected:
            continue
        if row.status is RowStatus.blocked:
            reasons.append(f"{row.requirement_id} blocked by {', '.join(row.blocked_by)}")
        elif row.status is RowStatus.planned:
            reasons.append(f"{row.requirement_id} has no evidence yet")
        else:
            reasons.append(f"{row.requirement_id} has no recorded run")
    return tuple(reasons)
