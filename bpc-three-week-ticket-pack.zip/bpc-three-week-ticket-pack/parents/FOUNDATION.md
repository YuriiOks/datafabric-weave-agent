---
pack_id: "bpc-sep26-v1"
local_id: "FOUNDATION"
kind: "parent"
existing_jira_key: null
operation: "create_parent"
summary: "Establish shared component graph and AI delivery foundation"
assignee_key: "yurii"
planned_start: "2026-09-09"
planned_due: "2026-09-30"
dates_status: "start confirmed; task schedule conditional on reuse/availability"
jira_epic_key: null
jira_marker: "bpc-sep26-foundation"
---

# Establish shared component graph and AI delivery foundation

Create the shared contracts, governed catalogue, safe graph/read path, controlled refresh and measured Hub AI hardening used by the three existing recommendation stories. PostgreSQL and FalkorDB remain in place. The reported PoC is reconciled before reuse and estimates; no source/API/auth/worker capability is presumed verified. A lexical component baseline is separately scope-gated. Completion requires the integrated evidence gate and operator handoff, not only merged code.

## Jira handling

Create one approved parent issue under the verified existing epic. FOUNDATION is a local reference, not a Jira issue key. Resolve project create metadata, allowed parent issue type and epic field; record the returned Jira key in the import map.

The screenshot shows no existing issue; it is not live state. Resolve Yurii to the unique active, assignable Jira identity before setting the assignee. Parent due date is 30 September 2026 as shown for the existing stories; new parent uses the same proposed milestone. A parent estimate must not duplicate its children’s estimates.

## Child scope

- [CORE-01 — Reconcile the working PoC, source access and delivery prerequisites](../subtasks/CORE-01.md) — Yurii; 4h; foundation.
- [CORE-02 — Define shared task, source, identity and publication contracts](../subtasks/CORE-02.md) — Yurii; 4h; foundation.
- [CORE-03 — Integrate the versioned catalogue and deterministic identity resolver](../subtasks/CORE-03.md) — Yurii; 6h; foundation.
- [CORE-04 — Publish isolated graph generations and enforce authorised bounded reads](../subtasks/CORE-04.md) — Yurii; 10h; foundation.
- [CORE-05 — Implement the durable refresh job framework and recovery contract](../subtasks/CORE-05.md) — Yurii; 5h; foundation.
- [CORE-06 — Add a shared refresh and evidence status interface](../subtasks/CORE-06.md) — Mayank; 6h; foundation.
- [CORE-07 — Instrument the existing Hub path with typed baseline observations](../subtasks/CORE-07.md) — Yurii; 6h; foundation.
- [CORE-08 — Deliver one authorised lexical recommendation baseline for all component types](../subtasks/CORE-08.md) — Yurii; 6h; conditional recommendation extension.
- [CORE-09 — Qualify integrated source-to-result behavior and release readiness](../subtasks/CORE-09.md) — Yurii; 6h; foundation.
- [CORE-10 — Complete the qualified demonstration and parent acceptance handoff](../subtasks/CORE-10.md) — Mayank; 1h; foundation.
- [CORE-11 — Apply evidence-state policy to the existing bounded Hub decision path](../subtasks/CORE-11.md) — Yurii; 6h; foundation.
- [CORE-12 — Enforce shared AI budgets, release lineage and operational controls](../subtasks/CORE-12.md) — Yurii; 4h; foundation.
- [CORE-13 — Implement bounded Git and whole-workbook acquisition adapters](../subtasks/CORE-13.md) — Mayank; 6h; foundation.
- [CORE-14 — Prepare operator runbook and demonstration evidence before qualification](../subtasks/CORE-14.md) — Mayank; 2h; foundation.
- [CORE-15 — Integrate the complete source set with refresh publication and status](../subtasks/CORE-15.md) — Yurii; 3h; foundation.

## Parent acceptance and closure

All selected children and cross-parent release dependencies require actual evidence. Foundation-mode graph delivery is a milestone toward the existing recommendation stories; it does not by itself satisfy or close a story whose live acceptance requires recommendations. In recommendation mode, the scope is an authorised lexical baseline only: verify that this satisfies the existing parent’s live acceptance with Joseph. Neither profile implements the full future LLM-assessed recommender. Do not transition any parent automatically from this pack. Missing platform/identity/source/model/reviewer prerequisites remain blockers, not implicit acceptance exceptions.

## Shared technical basis

Read [architecture contracts](../reference/ARCHITECTURE-CONTRACT.md), [execution calendar](../02-EXECUTION-CALENDAR.md) and [import instructions](../01-WORKSTATION-IMPORT.md). Relevant architecture anchors: `mandate`, `validation-gates`, `ai-contracts`, `source-refresh`, `operations`, `delivery`. Exact bank file mapping is produced by CORE-01; do not use laptop repository paths as the application implementation map.
