"""Command-line command of the publish package: ``kp publish``.

The integrator wires it into ``kp.cli`` by calling :func:`add_parser` on the subparsers
object; the subcommand stores its handler as ``args.handler`` and the caller runs
``args.handler(args)`` to get the exit status.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING

from kp.config import load_settings
from kp.domain import CheckResult, CheckSeverity
from kp.errors import KpError
from kp.publish.publisher import KnowledgePublisher, PublicationResult
from kp.store import Database

if TYPE_CHECKING:
    SubParsers = argparse._SubParsersAction[argparse.ArgumentParser]

EXIT_PUBLISHED = 0
EXIT_BLOCKED = 1
EXIT_FAILED = 2


def add_parser(subparsers: SubParsers) -> None:
    """Register ``publish`` on a subparsers object.

    :param subparsers: The result of ``ArgumentParser.add_subparsers``
    """
    parser = subparsers.add_parser(
        "publish", help="Run the publication checks and publish a knowledge version"
    )
    parser.add_argument("--run-id", help="Build run this version belongs to")
    parser.add_argument(
        "--dry-run", action="store_true", help="Run the checks only; stage and publish nothing"
    )
    parser.add_argument("--json", action="store_true", help="Write the result as JSON")
    parser.set_defaults(handler=run_publish)


def format_checks(checks: tuple[CheckResult, ...]) -> str:
    """Render check results, one line each.

    :param checks: The results
    :return: Text such as ``blocking  PASS  guessed_share  value=0.200 limit=0.500  ...``
    """
    lines = []
    for check in checks:
        value = "-" if check.value is None else f"{check.value:.3f}"
        limit = "-" if check.threshold is None else f"{check.threshold:.3f}"
        verdict = "PASS" if check.passed else "FAIL"
        lines.append(
            f"{check.severity.value:<8} {verdict}  {check.name}  value={value} limit={limit}  "
            f"{check.detail}"
        )
    return "\n".join(lines)


def format_result(result: PublicationResult) -> str:
    """Render a publication attempt.

    :param result: What happened
    :return: Multi-line text naming the outcome, the checks and the version now serving
    """
    serving = result.serving.version_id if result.serving is not None else "none"
    outcome = (
        f"Published knowledge version {result.version.version_id} "
        f"({result.version.item_count} items)."
        if result.published
        else f"Not published: knowledge version {result.version.version_id} is kept for "
        f"inspection. Still serving: {serving}."
    )
    return f"{outcome}\n{format_checks(result.version.checks)}"


@contextmanager
def _publisher() -> Iterator[KnowledgePublisher]:
    settings = load_settings()
    database = Database.from_settings(settings)
    try:
        database.ensure_schema(settings)
        with database.transaction() as connection:
            yield KnowledgePublisher(connection, thresholds=settings.thresholds)
    finally:
        database.dispose()


def run_publish(args: argparse.Namespace) -> int:
    """Run ``kp publish``.

    :param args: Parsed arguments with ``run_id``, ``dry_run`` and ``json``
    :return: 0 when published (or when a dry run passed), 1 when a blocking check failed,
        2 on a platform error
    """
    try:
        with _publisher() as publisher:
            if args.dry_run:
                checks = publisher.check()
                text = (
                    json.dumps([c.model_dump(mode="json") for c in checks], indent=2)
                    if args.json
                    else format_checks(checks)
                )
                blocked = any(not c.passed and c.severity is CheckSeverity.BLOCKING for c in checks)
            else:
                result = publisher.publish(args.run_id)
                text = (
                    json.dumps(result.model_dump(mode="json"), indent=2)
                    if args.json
                    else format_result(result)
                )
                blocked = not result.published
    except KpError as exc:
        sys.stderr.write(f"kp publish: {exc}\n")
        return EXIT_FAILED
    sys.stdout.write(f"{text}\n")
    return EXIT_BLOCKED if blocked else EXIT_PUBLISHED
