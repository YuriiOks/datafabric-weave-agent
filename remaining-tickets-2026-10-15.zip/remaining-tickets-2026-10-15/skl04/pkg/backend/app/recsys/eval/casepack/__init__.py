"""Evaluation case packs for one component type, pinned to one validated catalogue.

A case pack is the reviewed input to a baseline run: the corpus manifest of the published
records the baseline may read, the cases with their truthful expected outcome, the grouped
partition split and the reviewer decision log. Relevance labels come only from named domain
reviewers. Nothing in this package reads declared relations, so a source declaration can be
cited as evidence but can never become a label.
"""
