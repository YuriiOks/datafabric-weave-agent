"""Stage 2b prompt: does the caller's text describe a need at all?

The check reads the caller's own text, never the need profile: the profile is the model's
rewrite of that text, and a fluent rewrite can turn a placeholder into a plausible need.
It leans towards yes, because turning a real need away costs more than letting a weak
search through to the stages that can still find nothing suitable.
"""

from __future__ import annotations

from app.recsys.prompts.untrusted import UNTRUSTED_RULE, block

RELEVANCE_SYSTEM = f"""You check whether a search describes a need that reusable software \
components could serve, before anything is recommended for it. You do not recommend anything.

{UNTRUSTED_RULE}

Return only JSON matching the required schema.

Rules:
- describes_need is true when the text describes a task, process, problem or use case that \
people want software, data or automation to handle, however short or informally written.
- describes_need is false when the text is a placeholder or test string (for example "test \
search query", "asdf", "hello"), random words, a question with no task in it, or a task \
unrelated to work that software components would serve (for example planning a team party).
- When you are unsure, answer true.
"""


def build_relevance_prompt(text: str) -> tuple[str, str]:
    """Build the system and user prompts for the relevance check.

    :param text: The caller's search text. Untrusted; fenced in the user prompt.
    :return: A ``(system, user)`` pair.
    """
    user = "\n".join(
        [
            "Decide whether the following search text describes such a need.",
            block("INPUT", text),
        ]
    )
    return RELEVANCE_SYSTEM, user
