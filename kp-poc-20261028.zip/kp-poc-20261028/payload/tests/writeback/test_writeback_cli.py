"""``kp draft-spec <story-key> [--publish]`` end to end on the seeded synthetic data."""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path

import pytest
from sqlalchemy import func, select

from kp.clock import FixedClock
from kp.config import Settings
from kp.store import Database
from kp.store.schema import spec
from kp.writeback import (
    DraftSpecRuntime,
    InMemorySessionRetrievals,
    JiraSyncService,
    JiraTransientError,
    RetryPolicy,
    SpecPublishingService,
    WriteTools,
    add_parser,
    draft_spec,
    run,
)
from kp.writeback.cli import default_runtime
from writeback.writeback_support import (
    MemoryAudit,
    RecordingPublisher,
    ScriptedJira,
    Seeded,
)

AFTER_SWITCH = date(2026, 11, 20)


class Wiring:
    """A runtime whose writers are fakes, so the tests can inspect what was written."""

    def __init__(self, database: Database, settings: Settings, clock: FixedClock) -> None:
        self.publisher = RecordingPublisher()
        self.jira = ScriptedJira()
        self.audit = MemoryAudit()
        self.built = 0
        self.runtime = DraftSpecRuntime(
            database=database, settings=settings, tools_factory=self._tools, clock=clock
        )
        self._database, self._settings, self._clock = database, settings, clock

    def _tools(self, retrievals: InMemorySessionRetrievals) -> WriteTools:
        self.built += 1
        return WriteTools(
            publishing=SpecPublishingService(
                database=self._database,
                settings=self._settings,
                publisher=self.publisher,
                clock=self._clock,
            ),
            jira=JiraSyncService(
                database=self._database,
                settings=self._settings,
                jira=self.jira,
                retry=RetryPolicy(attempts=2, delay_seconds=0),
                sleep=lambda _seconds: None,
            ),
            retrievals=retrievals,
            audit=self.audit,
            clock=self._clock,
        )


@pytest.fixture
def wiring(database: Database, settings: Settings, clock: FixedClock, seeded: Seeded) -> Wiring:
    return Wiring(database, settings, clock)


def parse(*argv: str) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))
    return parser.parse_args(argv)


def test_us19_the_command_registers_with_the_main_parser() -> None:
    args = parse("draft-spec", "PAY-101", "--publish", "--as-at", "2026-11-20")

    assert (args.story_key, args.publish, args.as_at, args.spec_type) == (
        "PAY-101",
        True,
        AFTER_SWITCH,
        "functional",
    )
    assert args.handler is run


def test_us19_without_publish_the_draft_is_printed_and_nothing_is_written(
    wiring: Wiring, database: Database, capsys: pytest.CaptureFixture[str]
) -> None:
    status = run(parse("draft-spec", "PAY-101", "--as-at", "2026-11-20"), runtime=wiring.runtime)

    captured = capsys.readouterr()
    assert status == 0
    assert captured.out.startswith("# Acknowledge received credit transfers")
    assert "[ref: 2026.1:4.1.2]" in captured.out
    assert "3/3 valid, rate 100% against 95%" in captured.err
    assert "nothing was written" in captured.err
    assert wiring.built == 0
    assert wiring.publisher.requests == []
    with database.transaction() as connection:
        assert connection.execute(select(func.count()).select_from(spec)).scalar() == 0


def test_us19_publish_opens_the_pull_request_then_updates_jira(
    wiring: Wiring, capsys: pytest.CaptureFixture[str]
) -> None:
    status = run(
        parse("draft-spec", "PAY-101", "--publish", "--as-at", "2026-11-20"),
        runtime=wiring.runtime,
    )

    report = json.loads(capsys.readouterr().out)
    assert status == 0
    assert "markdown" not in report
    assert report["published"]["pr_url"] == "local-pr:1"
    assert report["published"]["citation_rate"] == 1.0
    assert report["jira"]["status"] == "Spec drafted"
    assert report["jira_error"] is None
    (request,) = wiring.publisher.requests
    assert request.branch == "spec/pay-101"
    assert "Citation rate: 100%" in request.pr_body
    assert [record.tool for record in wiring.audit.records] == ["publish_spec", "update_jira"]


def test_us19_publishing_the_same_story_twice_yields_one_pull_request(wiring: Wiring) -> None:
    for _ in range(2):
        draft_spec("PAY-101", runtime=wiring.runtime, publish=True, as_at=AFTER_SWITCH)

    assert wiring.publisher.pull_requests == {"spec/pay-101": 1}
    assert len(wiring.jira.updates) == 2


def test_us20_a_jira_failure_after_publishing_is_reported_and_the_pr_stands(
    wiring: Wiring, capsys: pytest.CaptureFixture[str]
) -> None:
    wiring.jira.failures = [JiraTransientError("down"), JiraTransientError("down")]

    status = run(parse("draft-spec", "PAY-101", "--publish"), runtime=wiring.runtime)

    report = json.loads(capsys.readouterr().out)
    assert status == 1
    assert report["published"]["pr_url"] == "local-pr:1"
    assert report["jira"] is None
    assert report["jira_error"]
    assert len(wiring.jira.updates) == 2
    assert wiring.publisher.pull_requests == {"spec/pay-101": 1}


def test_us20_a_misconfigured_jira_update_is_reported_and_the_pr_stays_in_the_report(
    database: Database,
    settings: Settings,
    clock: FixedClock,
    seeded: Seeded,
    capsys: pytest.CaptureFixture[str],
) -> None:
    misconfigured = Wiring(
        database, settings.model_copy(update={"jira_fields_allowed": ("status",)}), clock
    )

    status = run(parse("draft-spec", "PAY-101", "--publish"), runtime=misconfigured.runtime)

    report = json.loads(capsys.readouterr().out)
    assert status == 1
    assert report["published"]["pr_url"] == "local-pr:1"
    assert "KP_JIRA_FIELDS_ALLOWED" in report["jira_error"]
    assert misconfigured.jira.updates == []


def test_us21_proposed_links_are_marked_and_listed_as_open_items(wiring: Wiring) -> None:
    report = draft_spec("PAY-103", runtime=wiring.runtime, as_at=AFTER_SWITCH)

    assert "(proposed link)" in report.markdown
    assert any(item.startswith("Confirm the proposed link to") for item in report.open_items)
    assert report.flagged == 0


def test_us19_an_unknown_story_is_reported_and_exits_non_zero(
    wiring: Wiring, capsys: pytest.CaptureFixture[str]
) -> None:
    status = run(parse("draft-spec", "PAY-999"), runtime=wiring.runtime)

    assert status == 1
    assert "kp draft-spec:" in capsys.readouterr().err


def test_us19_a_missing_template_is_reported_and_exits_non_zero(
    wiring: Wiring, capsys: pytest.CaptureFixture[str]
) -> None:
    status = run(parse("draft-spec", "PAY-101", "--spec-type", "technical"), runtime=wiring.runtime)

    assert status == 1
    assert "No governed template" in capsys.readouterr().err


def test_us22_unset_write_targets_exit_non_zero_and_write_nothing(
    database: Database, clock: FixedClock, seeded: Seeded
) -> None:
    unset = Wiring(database, Settings(_env_file=None), clock)

    status = run(parse("draft-spec", "PAY-101", "--publish"), runtime=unset.runtime)

    assert status == 1
    assert unset.publisher.requests == []
    assert unset.jira.updates == []


def test_us19_default_runtime_publishes_to_a_local_repository_with_a_jira_dry_run(
    database: Database,
    settings: Settings,
    clock: FixedClock,
    seeded: Seeded,
    git_binary: str,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("KP_GIT_BINARY", git_binary)
    local = settings.model_copy(update={"data_dir": tmp_path})
    runtime = default_runtime(local, database)

    report = draft_spec("PAY-101", runtime=runtime, publish=True, as_at=AFTER_SWITCH)

    assert report.published is not None
    assert report.published.pr_url == "local-pr:1"
    assert report.jira is not None
    assert report.jira.dry_run is True
    assert (tmp_path / "spec-repo" / ".git").is_dir()
