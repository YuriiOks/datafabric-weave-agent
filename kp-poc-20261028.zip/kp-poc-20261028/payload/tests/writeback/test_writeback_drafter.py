"""The reference drafter: deterministic, template-driven, every sentence cited."""

from __future__ import annotations

from kp.domain import Story
from kp.writeback import (
    DraftRequest,
    EvidenceItem,
    Retrieval,
    TemplateDrafter,
    check_citations,
    extract_rule_statements,
)
from kp.writeback.drafter import cite_sentences
from writeback.writeback_support import Seeded

CLAUSE = EvidenceItem(
    reference="2026.1:4.1.2",
    text="A participant shall acknowledge every received credit transfer within five seconds.",
)
ROW = EvidenceItem(
    reference="register-1:Requirements:8",
    text="Acknowledge received transfers. Every received transfer is acknowledged quickly.",
)
STORY = Story(
    story_key="PAY-101",
    version="v1",
    summary="Acknowledge received credit transfers",
    description="Acknowledge each received transfer quickly.",
    acceptance_criteria="A received transfer is acknowledged within five seconds.\nNo duplicates.",
)


def request(seeded: Seeded, *evidence: EvidenceItem, **overrides: object) -> DraftRequest:
    values: dict[str, object] = {
        "story": STORY,
        "template": seeded.template,
        "retrieval": Retrieval(evidence=evidence),
    }
    values.update(overrides)
    return DraftRequest.model_validate(values)


def resolves_everything(reference: str) -> bool:
    return True


def test_us19_drafting_is_deterministic(seeded: Seeded) -> None:
    drafter = TemplateDrafter()

    first = drafter.draft(request(seeded, CLAUSE, ROW))

    assert first == drafter.draft(request(seeded, CLAUSE, ROW))
    assert first == TemplateDrafter().draft(request(seeded, CLAUSE, ROW))
    assert first.markdown.count("[ref: 2026.1:4.1.2]") >= 1


def test_us19_the_draft_follows_the_governed_template(seeded: Seeded) -> None:
    drafted = TemplateDrafter().draft(request(seeded, CLAUSE))

    headings = [line for line in drafted.markdown.splitlines() if line.startswith("#")]
    assert headings == [
        "# Acknowledge received credit transfers",
        "## Summary",
        "## Rules",
        "## Acceptance",
        "## Coverage",
        "## Open items",
    ]
    assert "{{" not in drafted.markdown
    assert "Every statement in this section cites" not in drafted.markdown
    assert (drafted.template_id, drafted.template_version) == ("functional-spec", "1.0.0")
    assert "- A received transfer is acknowledged within five seconds." in drafted.markdown
    assert "- No duplicates." in drafted.markdown


def test_us21_every_rule_sentence_carries_its_citation(seeded: Seeded) -> None:
    drafted = TemplateDrafter().draft(request(seeded, CLAUSE, ROW))

    statements = extract_rule_statements(drafted.markdown)
    assert len(statements) == 3
    assert all(statement.references for statement in statements)
    report = check_citations(
        drafted.markdown,
        resolves=resolves_everything,
        retrieved={CLAUSE.reference, ROW.reference},
        target=0.95,
    )
    assert report.rate == 1.0


def test_us21_a_multi_sentence_passage_is_cited_sentence_by_sentence() -> None:
    line = cite_sentences(ROW)

    assert line == (
        "Acknowledge received transfers [ref: register-1:Requirements:8]. "
        "Every received transfer is acknowledged quickly [ref: register-1:Requirements:8]."
    )


def test_us21_guessed_links_appear_as_proposed_in_the_text_and_open_items(
    seeded: Seeded,
) -> None:
    proposed = CLAUSE.model_copy(update={"proposed": True})

    drafted = TemplateDrafter().draft(request(seeded, proposed))

    assert "[ref: 2026.1:4.1.2] (proposed link)." in drafted.markdown
    assert "Confirm the proposed link to 2026.1:4.1.2." in drafted.open_items


def test_us21_stated_evidence_comes_before_proposed_evidence(seeded: Seeded) -> None:
    proposed = CLAUSE.model_copy(update={"proposed": True})

    drafted = TemplateDrafter().draft(request(seeded, proposed, ROW))

    rules = drafted.markdown.split("## Rules")[1].split("## Acceptance")[0]
    assert rules.index("register-1") < rules.index("2026.1:4.1.2")


def test_us19_coverage_lists_linked_tests_and_rules_without_one(seeded: Seeded) -> None:
    drafted = TemplateDrafter().draft(
        request(
            seeded,
            CLAUSE,
            ROW,
            tests_by_reference={CLAUSE.reference: ("test-a", "test-b")},
        )
    )

    assert "- 2026.1:4.1.2: test-a, test-b" in drafted.markdown
    assert "- register-1:Requirements:8: no linked test" in drafted.markdown
    assert drafted.coverage == {
        "rules": {CLAUSE.reference: ["test-a", "test-b"], ROW.reference: []},
        "rules_without_test": [ROW.reference],
    }
    assert "No test is linked to register-1:Requirements:8." in drafted.open_items
    assert "No test is linked to 2026.1:4.1.2." not in drafted.open_items


def test_us19_notes_from_retrieval_become_open_items(seeded: Seeded) -> None:
    retrieval = Retrieval(evidence=(CLAUSE,), notes=("Edition 2026.1 is not yet effective.",))

    drafted = TemplateDrafter().draft(request(seeded, retrieval=retrieval))

    assert drafted.open_items[0] == "Edition 2026.1 is not yet effective."
    assert "- Edition 2026.1 is not yet effective." in drafted.markdown


def test_us21_a_draft_without_evidence_says_so_and_is_flagged_not_waved_through(
    seeded: Seeded,
) -> None:
    drafted = TemplateDrafter().draft(request(seeded))
    story = STORY.model_copy(update={"acceptance_criteria": ""})
    bare = TemplateDrafter().draft(request(seeded, story=story))

    assert "No rule or register row was found for this story." in drafted.markdown
    assert "Find the rules or register rows this story rests on." in drafted.open_items
    assert "Add acceptance criteria to the story." in bare.open_items
    report = check_citations(
        drafted.markdown, resolves=resolves_everything, retrieved=set(), target=0.95
    )
    assert (report.rule_statements, report.rate) == (1, 0.0)


def test_us19_sections_the_drafter_does_not_know_keep_the_template_text(seeded: Seeded) -> None:
    template = seeded.template.model_copy(
        update={"body": seeded.template.body + "\n## Sign-off\n\nTo be completed by a person.\n"}
    )

    drafted = TemplateDrafter().draft(request(seeded, CLAUSE, template=template))

    assert drafted.markdown.rstrip().endswith("## Sign-off\n\nTo be completed by a person.")
