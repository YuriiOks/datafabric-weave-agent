"""Passage builders: turn clauses, pages, stories, register rows, code and schema fields into
searchable :class:`kp.domain.Passage` values.

Sizes follow SPEC 5.1 and are measured in whitespace-separated words (see
:mod:`kp.search.tokens`). Where a passage quotes a source file, its text is an exact slice of
that source and ``char_start``/``char_end`` locate the slice, so a result can always be checked
against the document.
"""

from __future__ import annotations

import ast
import bisect
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from itertools import pairwise
from typing import Final

from kp.domain import Clause, Edition, Passage, PassageType, Requirement, SourceKind, Story
from kp.search.chunking import LINE, PARAGRAPH, SENTENCE, Span, split_span, window_spans
from kp.search.pages import PageIndex, fill_missing_pages
from kp.search.tokens import count_tokens

# Sizes in words (SPEC 5.1): a clause longer than CLAUSE_SPLIT_THRESHOLD is cut into parts of
# about CLAUSE_PART_TOKENS; document windows are PAGE_TOKENS long and overlap by
# PAGE_OVERLAP_TOKENS; stories and code files are cut at STORY_TOKENS and CODE_TOKENS.
CLAUSE_SPLIT_THRESHOLD: Final = 1800
CLAUSE_PART_TOKENS: Final = 1200
PAGE_TOKENS: Final = 800
PAGE_OVERLAP_TOKENS: Final = 120
STORY_TOKENS: Final = 600
CODE_TOKENS: Final = 900

_SCALAR_TYPES = (str, int, float, bool)


@dataclass(frozen=True, slots=True)
class DocumentText:
    """A document whose text is cut into page-sized passages.

    :ivar source: Source of the document.
    :ivar item_id: Identity of the document.
    :ivar version: Version of the document.
    :ivar text: The full extracted text; passages are exact slices of it.
    :ivar domain: The document's domain, copied onto its passages.
    :ivar page_starts: Character offsets at which each page begins, in order; the first
        entry is page 1. Empty when the extraction kept no page markers, in which case
        passages carry no page number unless :func:`page_passages` is given a page index.
    """

    source: SourceKind
    item_id: str
    version: str
    text: str
    domain: str | None = None
    page_starts: Sequence[int] = field(default_factory=tuple)


@dataclass(frozen=True, slots=True)
class CodeFile:
    """A source code file whose text is cut into per-function passages.

    :ivar source: Source of the file.
    :ivar item_id: Identity of the repository or item the file belongs to.
    :ivar version: Version (revision) of the file.
    :ivar path: Path of the file inside the item; its extension chooses how it is cut.
    :ivar text: The file's content; passages are exact slices of it.
    :ivar domain: The file's domain, copied onto its passages.
    """

    source: SourceKind
    item_id: str
    version: str
    path: str
    text: str
    domain: str | None = None


@dataclass(frozen=True, slots=True)
class SchemaDocument:
    """A JSON schema whose fields each become one passage.

    :ivar source: Source of the schema.
    :ivar item_id: Identity of the schema document.
    :ivar version: Version of the schema document.
    :ivar schema: The parsed schema; nested ``properties`` are followed.
    :ivar domain: The document's domain, copied onto its passages.
    """

    source: SourceKind
    item_id: str
    version: str
    schema: Mapping[str, object]
    domain: str | None = None


def clause_passages(clause: Clause, edition: Edition, domain: str | None) -> list[Passage]:
    """Build the passages of one clause.

    A clause is one passage and is never merged with another. One over
    ``CLAUSE_SPLIT_THRESHOLD`` tokens is split at sub-paragraph (blank line) boundaries into
    parts of about ``CLAUSE_PART_TOKENS``, all keeping the clause reference as ``parent_ref``.

    :param clause: The clause with its position in the source
    :param edition: The edition it belongs to
    :param domain: The document's domain, copied onto the passages for filtering
    :return: One passage, or the ordered parts of a long clause
    """
    reference = clause.ref.format()
    if count_tokens(clause.text) <= CLAUSE_SPLIT_THRESHOLD:
        return [
            _clause_passage(
                clause, edition, domain, f"clause:{reference}", None, (0, len(clause.text))
            )
        ]
    spans = split_span(
        clause.text, (0, len(clause.text)), CLAUSE_PART_TOKENS, (PARAGRAPH, SENTENCE)
    )
    return [
        _clause_passage(clause, edition, domain, f"clause:{reference}#{index}", index, span)
        for index, span in enumerate(spans)
    ]


def _clause_passage(
    clause: Clause,
    edition: Edition,
    domain: str | None,
    passage_id: str,
    part_index: int | None,
    span: Span,
) -> Passage:
    text = clause.text[span[0] : span[1]]
    return Passage(
        passage_id=passage_id,
        passage_type=PassageType.CLAUSE,
        parent_ref=clause.ref.format(),
        source=edition.source,
        item_id=edition.item_id,
        version=edition.version,
        text=text,
        tokens=count_tokens(text),
        domain=domain,
        edition_label=edition.label,
        page=clause.page,
        char_start=clause.char_start + span[0],
        char_end=clause.char_start + span[1],
        part_index=part_index,
    )


def page_passages(document: DocumentText, page_index: PageIndex | None = None) -> list[Passage]:
    """Cut a document into overlapping page-sized passages.

    :param document: The document text and, if known, where its pages begin
    :param page_index: The page texts of the source file; used to number passages the
        document's own ``page_starts`` could not (see :func:`kp.search.pages.fill_missing_pages`)
    :return: Windows of ``PAGE_TOKENS`` words overlapping by ``PAGE_OVERLAP_TOKENS``
    """
    spans = window_spans(document.text, PAGE_TOKENS, PAGE_OVERLAP_TOKENS)
    key = f"{document.source.value}/{document.item_id}@{document.version}"
    passages = []
    for index, (start, end) in enumerate(spans):
        text = document.text[start:end]
        page = bisect.bisect_right(document.page_starts, start) or None
        passages.append(
            Passage(
                passage_id=f"page:{key}#{index}",
                passage_type=PassageType.PAGE,
                parent_ref=document.item_id,
                source=document.source,
                item_id=document.item_id,
                version=document.version,
                text=text,
                tokens=count_tokens(text),
                domain=document.domain,
                page=page,
                char_start=start,
                char_end=end,
                part_index=index,
            )
        )
    return passages if page_index is None else fill_missing_pages(passages, page_index)


def story_passages(story: Story) -> list[Passage]:
    """Build the passages of a tracker story.

    Summary and description form the story passages (about ``STORY_TOKENS`` words each); the
    acceptance criteria are kept apart as their own passages so that a question about
    behaviour does not drown in background text.

    :param story: The story
    :return: Story passages first, then acceptance-criteria passages
    """
    body = f"{story.summary.strip()}\n\n{story.description.strip()}".strip()
    return [
        *_story_parts(story, PassageType.STORY, body),
        *_story_parts(story, PassageType.ACCEPTANCE_CRITERIA, story.acceptance_criteria.strip()),
    ]


def _story_parts(story: Story, passage_type: PassageType, text: str) -> list[Passage]:
    if not text:
        return []
    spans = split_span(text, (0, len(text)), STORY_TOKENS, (PARAGRAPH, SENTENCE))
    prefix = "story" if passage_type is PassageType.STORY else "acceptance"
    return [
        Passage(
            passage_id=f"{prefix}:{story.story_key}@{story.version}#{index}",
            passage_type=passage_type,
            parent_ref=story.story_key,
            source=SourceKind.JIRA,
            item_id=story.story_key,
            version=story.version,
            text=text[start:end],
            tokens=count_tokens(text[start:end]),
            domain=story.domain,
            part_index=index,
        )
        for index, (start, end) in enumerate(spans)
    ]


def requirement_passage(requirement: Requirement) -> Passage:
    """Build the single passage of one register row.

    :param requirement: The register row
    :return: A passage listing ``column: value`` per non-empty field
    """
    text = "\n".join(
        f"{name}: {value.strip()}" for name, value in requirement.fields.items() if value.strip()
    )
    return Passage(
        passage_id=f"register-row:{requirement.requirement_id}",
        passage_type=PassageType.REGISTER_ROW,
        parent_ref=requirement.requirement_id,
        source=requirement.source,
        item_id=requirement.item_id,
        version=requirement.version,
        text=text,
        tokens=count_tokens(text),
        domain=requirement.domain,
    )


def schema_field_passages(document: SchemaDocument) -> list[Passage]:
    """Build one passage per field of a JSON schema, nested fields included.

    :param document: The schema
    :return: Passages in schema order; the text lists the field path and every scalar
        annotation (type, description, vendor extensions such as clause hints)
    """
    passages = []
    for path, definition in _walk_properties(document.schema, ""):
        lines = [f"field {path}"]
        lines += [
            f"{name}: {value}"
            for name, value in definition.items()
            if isinstance(value, _SCALAR_TYPES)
        ]
        text = "\n".join(lines)
        passages.append(
            Passage(
                passage_id=f"schema-field:{document.item_id}@{document.version}#{path}",
                passage_type=PassageType.SCHEMA_FIELD,
                parent_ref=f"{document.item_id}#{path}",
                source=document.source,
                item_id=document.item_id,
                version=document.version,
                text=text,
                tokens=count_tokens(text),
                domain=document.domain,
            )
        )
    return passages


def _walk_properties(
    schema: Mapping[str, object], prefix: str
) -> list[tuple[str, Mapping[str, object]]]:
    properties = schema.get("properties")
    if not isinstance(properties, Mapping):
        return []
    found: list[tuple[str, Mapping[str, object]]] = []
    for name, definition in properties.items():
        if not isinstance(definition, Mapping):
            continue
        path = f"{prefix}{name}"
        found.append((path, definition))
        found.extend(_walk_properties(definition, f"{path}."))
    return found


def code_passages(code: CodeFile) -> list[Passage]:
    """Cut a code file into passages by function.

    Python files are cut at every function, method and class header; each function is one
    passage, and one longer than ``CODE_TOKENS`` is cut at line boundaries. Other languages,
    and Python that does not parse, are cut at line boundaries into windows of about
    ``CODE_TOKENS``.

    :param code: The file
    :return: Passages in file order with exact character positions
    """
    spans: list[Span] = []
    for unit in _code_units(code):
        if count_tokens(code.text[unit[0] : unit[1]]) <= CODE_TOKENS:
            spans.append(unit)
        else:
            spans.extend(split_span(code.text, unit, CODE_TOKENS, (LINE,)))
    return [
        Passage(
            passage_id=f"code:{code.path}@{code.version}#{index}",
            passage_type=PassageType.CODE,
            parent_ref=code.path,
            source=code.source,
            item_id=code.item_id,
            version=code.version,
            text=code.text[start:end],
            tokens=count_tokens(code.text[start:end]),
            domain=code.domain,
            char_start=start,
            char_end=end,
            part_index=index,
        )
        for index, (start, end) in enumerate(spans)
    ]


def _code_units(code: CodeFile) -> list[Span]:
    whole = (0, len(code.text))
    if not code.path.endswith(".py"):
        return [whole]
    try:
        tree = ast.parse(code.text)
    except SyntaxError:
        return [whole]
    line_offsets = [0]
    for line in code.text.splitlines(keepends=True):
        line_offsets.append(line_offsets[-1] + len(line))
    starts = sorted({line_offsets[line - 1] for line in _definition_lines(tree.body)})
    cuts = [0, *(start for start in starts if start > 0), len(code.text)]
    units = []
    for start, end in pairwise(cuts):
        body = code.text[start:end].rstrip()
        if body.strip():
            units.append((start, start + len(body)))
    return units


def _definition_lines(body: Sequence[ast.stmt]) -> list[int]:
    """First line of every function and class reachable through class bodies."""
    lines: list[int] = []
    for node in body:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
            lines.append(min([node.lineno, *(d.lineno for d in node.decorator_list)]))
            if isinstance(node, ast.ClassDef):
                lines.extend(_definition_lines(node.body))
    return lines
