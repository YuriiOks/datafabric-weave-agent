---
pack_id: "bpc-sep26-v1"
local_id: "AGT-04"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1345"
summary: "Show Agent graph evidence while preserving unbound native-Hub status"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 5
scope: "foundation"
create_by_default: true
planned_start: "2026-09-21"
planned_due: "2026-09-22"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["AGT-02","AGT-03","CORE-04","CORE-06"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-agt-04"
architecture_sections: ["read evidence","security","acceptance"]
---

# Show Agent graph evidence while preserving unbound native-Hub status

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1345**. Local reference **AGT-04** is not a Jira key.
- Estimate: **5 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-21 → 2026-09-22 (D9–D10)**.
- Recommendation extension: **2026-09-21 → 2026-09-21 (D9–D9)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

An operator needs to inspect an Agent and understand exactly which source declarations support its Skill/MCP links. The reader must also make it impossible to mistake a component Agent for an existing native Hub Agent.

## Scope

- Extend the shared read-only evidence surface selected at G0 with Agent identity, graph status, resolved and unresolved relation summaries, provenance and source freshness/publication state.
- Render native binding as `unbound`, `verified`, `ambiguous` or `stale` only from the shared binding contract.
- Default to `unbound`; surface native Hub relationships only if G0 proves an existing exact, scoped binding adapter and current policy authorises the read.
- Reuse the current registry/graph view where practical; otherwise use the approved bounded-query/accessibility surface.

## Boundaries

Do not create or modify native Hub Agent nodes, `EMPLOYS_AGENT` edges or cross-graph edges. Do not attach by display name. Proposed route names in the architecture are contracts to map at G0, not existing paths to implement blindly.

## Technical steps

1. Map the chosen live read surface and its authorisation hooks after G0.
2. Present only the publication-pinned, policy-filtered Agent node and bounded declared relations from CORE-04.
3. Include evidence summaries and typed outcomes for missing, ambiguous, stale, unavailable and truncated data.
4. Integrate an existing exact binding adapter only if reconciliation proves it is reusable; otherwise explicitly preserve the unbound state.

## Acceptance criteria

- An authorised viewer can inspect an Agent's stable identity, source status and each resolved Skill/MCP declaration with provenance without seeing raw import payloads.
- An Agent with no native binding remains graph-valid and visibly `unbound`; the surface shows no inferred native relationship.
- Ambiguous or stale binding evidence cannot appear as verified, and a display-name coincidence never creates a binding.
- An unauthorised, revoked or wrong-scope reader cannot obtain the Agent, its evidence or its connecting paths through a detail view, graph traversal, cursor or cache.
- Missing graph data, source staleness and traversal limits render truthful typed states rather than an empty successful answer.

## Evidence to attach

Authorised and denied read captures, bounded graph/evidence output, unbound/ambiguous/stale state captures, and accessibility/manual walkthrough evidence for the selected surface.

## Dependencies / blockers

Requires AGT-02, AGT-03, CORE-04 and CORE-06. Optional verified-binding display also requires G0 proof of an exact existing adapter.

## Out of scope

New graph visualisation libraries, native binding creation, automatic component attachment, recommendation UI and any execution of Skills or MCP servers.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [AGT-02](AGT-02.md) must finish its stated contract boundary before this task starts.
- [AGT-03](AGT-03.md) must finish its stated contract boundary before this task starts.
- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [CORE-06](CORE-06.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `read evidence`, `security`, `acceptance`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
