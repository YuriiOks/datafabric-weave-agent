"""The two write operations: publish a spec as a pull request, and update the Jira story.

They are deliberately separate. Publishing records the pull request link on the spec row;
the Jira update reads that link back and never touches the publisher, so a Jira failure is
retried on its own and can never create a second pull request.
"""

from __future__ import annotations

import hashlib
import logging
import time
from collections.abc import Callable
from collections.abc import Set as AbstractSet
from typing import Annotated

from pydantic import Field
from sqlalchemy import Connection
from sqlalchemy.exc import IntegrityError

from kp.clock import Clock, SystemClock
from kp.config import Settings
from kp.domain import Citation, DomainModel, Spec, SpecState
from kp.store import Database
from kp.writeback.citations import CitationReport, check_citations
from kp.writeback.errors import (
    JiraTransientError,
    SpecNotDraftableError,
    SpecNotDraftedError,
    SpecNotFoundError,
    StoryDomainNotPermittedError,
)
from kp.writeback.limits import WriteGuard, require_story_key, spec_id_for_story
from kp.writeback.models import (
    SPEC_DRAFTED_STATUS,
    JiraApplied,
    JiraStoryUpdate,
    PublishRequest,
    PublishResult,
    PublishSpecArguments,
    UpdateJiraArguments,
)
from kp.writeback.ports import JiraUpdater, SpecPublisher
from kp.writeback.rendering import (
    commit_message,
    render_pr_body,
    render_spec_file,
    spec_title,
)
from kp.writeback.retrieval import load_story
from kp.writeback.store import DatabaseReferenceResolver, SpecRepository, TemplateRepository

logger = logging.getLogger(__name__)


def _require_permitted_story(
    connection: Connection, story_key: str, domains: AbstractSet[str]
) -> None:
    """Check that the story exists and that the caller may write for its domain.

    :raises kp.writeback.errors.StoryNotFoundError: If the story is not in the store
    :raises kp.writeback.errors.StoryDomainNotPermittedError: If the story carries no domain
        label (access fails closed, as it does for reading), or one the caller may not read
    """
    story = load_story(connection, story_key)
    if story.domain is None or story.domain not in domains:
        raise StoryDomainNotPermittedError(
            "The story belongs to a domain the caller may not write for"
        )


class PublishOutcome(DomainModel):
    """What publishing produced: the stored spec, the citation check and the publisher result."""

    spec: Spec
    report: CitationReport
    result: PublishResult


class RetryPolicy(DomainModel):
    """How a failing Jira update is retried.

    :ivar attempts: Total tries, including the first.
    :ivar delay_seconds: Wait before the second try.
    :ivar backoff: Factor applied to the wait after each further failure.
    """

    attempts: Annotated[int, Field(ge=1)] = 3
    delay_seconds: Annotated[float, Field(ge=0)] = 1.0
    backoff: Annotated[float, Field(ge=1)] = 2.0


class JiraOutcome(DomainModel):
    """What the Jira update did and how many tries it took."""

    spec_id: str
    update: JiraStoryUpdate
    applied: JiraApplied
    attempts: Annotated[int, Field(ge=1)]


class SpecPublishingService:
    """Publishes drafted specs as pull requests, within the server-side write limits.

    :param database: Where templates, specs and citations live
    :param settings: Platform settings; the write targets and the citation target
    :param publisher: Where the branch and pull request are created
    :param clock: Time source
    """

    def __init__(
        self,
        *,
        database: Database,
        settings: Settings,
        publisher: SpecPublisher,
        clock: Clock | None = None,
    ) -> None:
        self._database = database
        self._settings = settings
        self._publisher = publisher
        self._clock = clock or SystemClock()
        self._guard = WriteGuard(settings)

    def check(self, markdown: str, retrieved: AbstractSet[str]) -> CitationReport:
        """Run the citation check without publishing.

        :param markdown: The drafted spec
        :param retrieved: References the session retrieved
        :return: The citation report
        """
        with self._database.transaction() as connection:
            return check_citations(
                markdown,
                resolves=DatabaseReferenceResolver(connection).resolves,
                retrieved=retrieved,
                target=self._settings.thresholds.citation_rate_target,
            )

    def publish(
        self,
        arguments: PublishSpecArguments,
        *,
        retrieved: AbstractSet[str],
        domains: AbstractSet[str],
    ) -> PublishOutcome:
        """Check citations, commit the spec to its branch and open (or find) its pull request.

        Publishing the same story twice yields the same branch and the same pull request.

        :param arguments: The agent's arguments
        :param retrieved: References the agent retrieved in this session
        :param domains: The domains the caller may read, from the caller's identity
        :return: The stored spec, the citation report and the publisher result
        :raises kp.errors.WriteNotPermittedError: If the request aims at another repository,
            path or branch, or the story is in a domain the caller may not read (nothing is
            written)
        :raises kp.writeback.errors.StoryNotFoundError: If the story is not in the store
        :raises kp.errors.TemplateNotFoundError: If the template version is not governed
        :raises kp.writeback.errors.SpecNotDraftableError: If the spec was already merged, or the
            story already has a merged spec
        :raises kp.writeback.errors.PublishError: If the publisher fails
        """
        target = self._guard.authorise_publish(
            arguments.story_key,
            repository=arguments.repository,
            path=arguments.path,
            branch=arguments.branch,
        )
        spec_id = spec_id_for_story(arguments.story_key)
        with self._database.transaction() as connection:
            _require_permitted_story(connection, arguments.story_key, domains)
            template = TemplateRepository(connection).get(
                arguments.template_id, arguments.template_version
            )
            specs = SpecRepository(connection)
            existing = specs.get_by_branch(target.branch)
            merged_spec = specs.merged_spec_id(arguments.story_key)
            resolver = DatabaseReferenceResolver(connection)
            report = check_citations(
                arguments.spec_markdown,
                resolves=resolver.resolves,
                retrieved=retrieved,
                target=self._settings.thresholds.citation_rate_target,
            )
            withdrawn = {
                reference: since
                for check in report.checks
                for reference in check.references
                if (since := resolver.withdrawn_since(reference)) is not None
            }
        if existing is not None and existing.state is not SpecState.DRAFTED:
            raise SpecNotDraftableError("The spec on this branch is already merged or closed")
        if merged_spec is not None:
            raise SpecNotDraftableError("The story already has a merged spec")
        content = render_spec_file(
            arguments.spec_markdown,
            story_key=arguments.story_key,
            template_id=template.template_id,
            template_version=template.version,
        )
        result = self._publisher.publish(
            PublishRequest(
                repository=target.repository,
                branch=target.branch,
                path=target.path,
                content=content,
                commit_message=commit_message(
                    story_key=arguments.story_key,
                    template_id=template.template_id,
                    template_version=template.version,
                ),
                pr_title=spec_title(arguments.spec_markdown, arguments.story_key),
                pr_body=render_pr_body(
                    story_key=arguments.story_key,
                    path=target.path,
                    template_id=template.template_id,
                    template_version=template.version,
                    report=report,
                    coverage=arguments.coverage,
                    open_items=arguments.open_items,
                    withdrawn=withdrawn,
                ),
            )
        )
        spec = Spec(
            spec_id=spec_id,
            story_key=arguments.story_key,
            path=target.path,
            template_id=template.template_id,
            template_version=template.version,
            branch=target.branch,
            pr_identity=result.pr_url,
            state=SpecState.DRAFTED,
            machine_authored=True,
            coverage={
                **arguments.coverage,
                "citations": {
                    "rule_statements": report.rule_statements,
                    "valid": report.valid_statements,
                    "flagged": len(report.flagged),
                    "rate": report.rate,
                    "target": report.target,
                },
            },
            open_items=arguments.open_items,
            content_sha256=hashlib.sha256(content.encode("utf-8")).hexdigest(),
            created_at=existing.created_at if existing is not None else self._clock.now(),
        )
        self._save(spec, report.to_citations(spec_id))
        logger.info(
            "Spec published",
            extra={
                "spec_id": spec_id,
                "pr_created": result.created,
                "committed": result.committed,
                "citation_rate": report.rate,
                "flagged": len(report.flagged),
            },
        )
        return PublishOutcome(spec=spec, report=report, result=result)

    def _save(self, spec: Spec, citations: tuple[Citation, ...]) -> None:
        """Store the spec; if a concurrent publish inserted the row first, update it instead."""
        try:
            with self._database.transaction() as connection:
                SpecRepository(connection).save(spec, citations)
        except IntegrityError:
            logger.info(
                "Spec row created concurrently, updating it", extra={"spec_id": spec.spec_id}
            )
            with self._database.transaction() as connection:
                SpecRepository(connection).save(spec, citations)


class JiraSyncService:
    """Moves the story of a published spec to "Spec drafted" and links the pull request.

    :param database: Where the spec and its pull request link are read from
    :param settings: Platform settings; the two writable Jira fields
    :param jira: The updater (REST client or dry run)
    :param retry: How a transient failure is retried
    :param sleep: Waits between tries; replaced in tests
    """

    def __init__(
        self,
        *,
        database: Database,
        settings: Settings,
        jira: JiraUpdater,
        retry: RetryPolicy | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._database = database
        self._jira = jira
        self._retry = retry or RetryPolicy()
        self._sleep = sleep
        self._guard = WriteGuard(settings)

    def update(self, arguments: UpdateJiraArguments, *, domains: AbstractSet[str]) -> JiraOutcome:
        """Update the Jira story of an already published spec.

        :param arguments: The story, and optionally the agent's view of the fields
        :param domains: The domains the caller may read, from the caller's identity
        :return: What was applied and after how many tries
        :raises kp.errors.WriteNotPermittedError: If a field other than the two agreed ones
            (or a value other than the agreed one) was requested, or the story is in a domain
            the caller may not read; nothing is written
        :raises kp.writeback.errors.StoryNotFoundError: If the story is not in the store
        :raises kp.writeback.errors.SpecNotFoundError: If the story has no published spec
        :raises kp.writeback.errors.SpecNotDraftedError: If the spec was already merged or
            closed
        :raises kp.writeback.errors.JiraTransientError: If every try failed transiently
        :raises kp.writeback.errors.JiraUpdateError: If Jira refused the update
        """
        require_story_key(arguments.story_key)
        target = self._guard.authorise_jira_fields(arguments.story_key, arguments.fields)
        with self._database.transaction() as connection:
            _require_permitted_story(connection, arguments.story_key, domains)
            spec = SpecRepository(connection).get_by_story(arguments.story_key)
        if spec is None or spec.pr_identity is None:
            raise SpecNotFoundError("No published spec exists for this story")
        if spec.state is not SpecState.DRAFTED:
            raise SpecNotDraftedError(
                "The spec is already merged or closed; the story is left as it is"
            )
        self._guard.verify_jira_values(target, arguments.fields, link=spec.pr_identity)
        update = JiraStoryUpdate(
            story_key=arguments.story_key,
            status=SPEC_DRAFTED_STATUS,
            link_field=target.link_field,
            link_value=spec.pr_identity,
        )
        applied, attempts = self._apply_with_retry(update)
        return JiraOutcome(spec_id=spec.spec_id, update=update, applied=applied, attempts=attempts)

    def _apply_with_retry(self, update: JiraStoryUpdate) -> tuple[JiraApplied, int]:
        delay = self._retry.delay_seconds
        attempt = 1
        while True:
            try:
                return self._jira.apply(update), attempt
            except JiraTransientError:
                if attempt >= self._retry.attempts:
                    raise
                logger.warning(
                    "Jira update failed, retrying",
                    extra={
                        "story_key": update.story_key,
                        "attempt": attempt,
                        "wait_seconds": delay,
                    },
                )
            self._sleep(delay)
            delay *= self._retry.backoff
            attempt += 1
