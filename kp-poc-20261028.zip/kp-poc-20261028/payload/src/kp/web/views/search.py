"""Search: a question, optionally as at a date, answered with the exact clause and its position."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from pydantic import JsonValue

from kp.errors import KpError
from kp.tools.search import SearchOutput
from kp.web.errors import Problem, problem_from
from kp.web.identity import Viewer
from kp.web.query import QueryForm
from kp.web.state import WebState


@dataclass(frozen=True, slots=True)
class SearchView:
    """The search page.

    :ivar question: What was asked (empty before the first search).
    :ivar as_at: The date typed, if any.
    :ivar output: The tool's answer; ``None`` before a search and when the search was refused.
    """

    question: str = ""
    as_at: date | None = None
    output: SearchOutput | None = None
    problem: Problem | None = None

    @property
    def searched(self) -> bool:
        """True once a question has been put."""
        return bool(self.question)


def read_search(state: WebState, viewer: Viewer, form: QueryForm) -> SearchView:
    """Answer the question of the page, as the viewer.

    :param state: The shared state
    :param viewer: Who is asking
    :param form: The query string of the request
    :return: The view; a refusal is a ``forbidden`` problem, never an empty result
    """
    question = ""
    as_at: date | None = None
    try:
        question = form.text("q")
        as_at = form.day("as_at", "As at")
        if not question:
            # Nothing is asked, so nothing is recorded; but the form is not for everyone.
            state.require_access(viewer)
            return SearchView(as_at=as_at)
        arguments: dict[str, JsonValue] = {"query": question, "limit": state.settings.result_limit}
        if as_at is not None:
            arguments["as_at"] = as_at.isoformat()
        payload = state.call(viewer, "search", arguments)
        return SearchView(question, as_at, SearchOutput.model_validate(payload))
    except KpError as exc:
        return SearchView(question, as_at, problem=problem_from(exc))
