"""Jira-like reader: JSON exports of a project's stories, read incrementally by updated time.

Rules of this route:

* The cursor is a position on the ``updated`` time. Between sweeps it is the newest updated
  time seen; the next sweep starts ``overlap`` earlier (60 s by default) so an issue written
  while the previous sweep ran is not missed. The sweep drops the repeats, because an item
  version is identified by issue key plus updated time and a known version is a no-op.
* Inside one sweep the cursor is an exact position (updated time, issue key), so pages never
  repeat and a stopped run continues where it stopped, whatever the overlap.
* A page holds at most ``page_size`` issues (100 by default).
* The item content is the issue as exported, with the acceptance criteria kept in their own
  field, not folded into the description. The attributes carry status, parent, links, labels
  and ``story_fingerprint``, the hash that ignores status. A board move changes the updated
  time and the status but not the fingerprint; a change to the summary, description,
  acceptance criteria, links or parent changes it. The sweep compares fingerprints to decide
  what to reprocess.

An export path may be one file or a folder of files. When an issue appears more than once, the
copy with the newest updated time is the current state, as a live tracker would report it, so
only the current version of an issue can be fetched.

The reader keeps the issues of its last listing, so fetching a page of issues does not parse
the exports again for each one. A fetch re-reads the file the issue was listed from and checks
the issue still has the listed updated time; a newer copy of the issue in a different file
that appeared after the listing is not noticed until the next listing.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, JsonValue

from kp.domain.content import Story, StoryLink
from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.errors import ConfigurationError, SourceItemNotFoundError, SourceUnavailableError
from kp.sources import attributes as attr
from kp.sources.base import ChangeBatch, ChangedItem, FetchedItem, ItemMetadata
from kp.sources.errors import InvalidCursorError
from kp.sources.files import parse_file, walk_files
from kp.sources.paging import require_limit

logger = logging.getLogger(__name__)

DEFAULT_OVERLAP_SECONDS = 60
DEFAULT_PAGE_SIZE = 100
_PREFIX = "jira1:"
_COMPLETE = "c"
_PARTIAL = "p"
_CURSOR_PARTS = 3
_DOMAIN_LABEL_PREFIX = "domain:"


class _Named(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    name: str


class _KeyRef(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    key: str


class _IssueLink(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    type: str
    key: str


class _Fields(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    summary: str
    description: str | None = None
    acceptance_criteria: str | None = None
    status: _Named | None = None
    parent: _KeyRef | None = None
    issuelinks: list[_IssueLink] = Field(default_factory=list)
    labels: list[str] = Field(default_factory=list)
    updated: AwareDatetime


class _Issue(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    key: str
    fields: _Fields


class _Export(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    project: str | None = None
    issues: list[dict[str, JsonValue]] = Field(default_factory=list)


@dataclass(frozen=True)
class _Record:
    """One issue as currently exported: the raw record and its parsed form."""

    raw: dict[str, JsonValue]
    issue: _Issue
    path: Path

    @property
    def key(self) -> str:
        return self.issue.key

    @property
    def updated(self) -> datetime:
        return self.issue.fields.updated.astimezone(UTC)

    @property
    def version(self) -> str:
        return self.updated.isoformat()


@dataclass(frozen=True)
class _Position:
    complete: bool
    updated: datetime
    key: str


class JiraExportReader:
    """Read stories from JSON exports of a Jira-like tracker.

    :param path: One export file, or a folder of export files
    :param project_key: Only issues of this project are read; ``None`` reads every issue
    :param overlap_seconds: How far before the saved position the next sweep starts
    :param page_size: Maximum issues per page, whatever limit the caller asks for
    """

    def __init__(
        self,
        path: Path,
        *,
        project_key: str | None = None,
        overlap_seconds: int = DEFAULT_OVERLAP_SECONDS,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> None:
        if page_size < 1:
            raise ConfigurationError("The Jira page size must be at least 1")
        if overlap_seconds < 0:
            raise ConfigurationError("The Jira overlap must not be negative")
        self._path = path
        self._project_key = project_key
        self._overlap = timedelta(seconds=overlap_seconds)
        self._page_size = page_size
        self._current: dict[str, _Record] | None = None

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves.

        :return: Jira
        """
        return SourceKind.JIRA

    def list_changed(self, cursor: str | None, *, limit: int = DEFAULT_PAGE_SIZE) -> ChangeBatch:
        """List issue versions updated since ``cursor``.

        :param cursor: The saved position, or ``None`` for a first sweep
        :param limit: Maximum items per page; never more than the configured page size
        :return: A page ordered by updated time; its cursor is valid once the page is processed
        :raises kp.sources.errors.InvalidReadRequestError: If ``limit`` is below one
        :raises kp.sources.errors.InvalidCursorError: If the cursor is foreign or corrupt
        :raises kp.errors.SourceUnavailableError: If the export cannot be read
        :raises kp.sources.errors.MalformedSourceDataError: If an issue has the wrong shape
        """
        require_limit(limit)
        position = _decode(cursor)
        candidates = self._candidates(self._load_records(), position)
        size = min(limit, self._page_size)
        page = candidates[:size]
        exhausted = len(candidates) <= size
        logger.info(
            "Change listing built",
            extra={
                "source": self.kind.value,
                "candidates": len(candidates),
                "returned": len(page),
                "exhausted": exhausted,
            },
        )
        return ChangeBatch(
            items=tuple(
                ChangedItem(
                    key=self._key(record),
                    title=record.issue.fields.summary,
                    modified_at=record.updated,
                )
                for record in page
            ),
            next_cursor=_next_cursor(position, page, exhausted=exhausted),
            exhausted=exhausted,
        )

    def fetch(self, key: ItemKey) -> FetchedItem:
        """Fetch one issue version.

        :param key: Issue key plus the updated time it was listed with
        :return: The issue as exported, with its approval signals
        :raises kp.errors.SourceItemNotFoundError: If the issue is gone or has been updated since
        :raises kp.errors.SourceUnavailableError: If the export cannot be read
        :raises kp.sources.errors.MalformedSourceDataError: If an issue has the wrong shape
        """
        listed = self._listed(key)
        record = _newest([r for r in _read_export(listed.path) if r.key == listed.key])
        if record is None or record.version != key.version:
            raise SourceItemNotFoundError(f"Item version changed or gone since listing: {key}")
        return FetchedItem(
            key=key,
            content=_content(record),
            metadata=_metadata(record, self._project_key),
        )

    def _listed(self, key: ItemKey) -> _Record:
        """The issue as last listed, after one fresh read if the cache does not hold the key."""
        listed = (self._current or {}).get(key.item_id)
        if listed is None or listed.version != key.version:
            self._load_records()
            listed = (self._current or {}).get(key.item_id)
        if listed is None or listed.version != key.version:
            raise SourceItemNotFoundError(f"No such item version: {key}")
        return listed

    def _key(self, record: _Record) -> ItemKey:
        return ItemKey(source=self.kind, item_id=record.key, version=record.version)

    def _candidates(self, records: list[_Record], position: _Position | None) -> list[_Record]:
        if position is None:
            return records
        if position.complete:
            floor = position.updated - self._overlap
            return [record for record in records if record.updated >= floor]
        return [
            record
            for record in records
            if (record.updated, record.key) > (position.updated, position.key)
        ]

    def _load_records(self) -> list[_Record]:
        if not self._path.exists():
            raise SourceUnavailableError("Source export is not available")
        files = (
            [self._path]
            if self._path.is_file()
            else [path for path in walk_files(self._path) if path.suffix == ".json"]
        )
        current: dict[str, _Record] = {}
        for path in files:
            for record in _read_export(path):
                if self._project_key and not record.key.startswith(f"{self._project_key}-"):
                    continue
                previous = current.get(record.key)
                if previous is None or record.updated >= previous.updated:
                    current[record.key] = record
        self._current = current
        return sorted(current.values(), key=lambda record: (record.updated, record.key))


def _read_export(path: Path) -> list[_Record]:
    def parse(data: bytes) -> list[_Record]:
        export = _Export.model_validate_json(data)
        return [
            _Record(raw=raw, issue=_Issue.model_validate(raw), path=path) for raw in export.issues
        ]

    return parse_file(path, parse, "Issue export")


def _newest(records: list[_Record]) -> _Record | None:
    newest: _Record | None = None
    for record in records:
        if newest is None or record.updated >= newest.updated:  # later copy wins a tie
            newest = record
    return newest


def _content(record: _Record) -> bytes:
    return (json.dumps(record.raw, indent=2, sort_keys=True, ensure_ascii=True) + "\n").encode(
        "ascii"
    )


def _metadata(record: _Record, project_key: str | None) -> ItemMetadata:
    fields = record.issue.fields
    status = fields.status.name if fields.status else ""
    parent_key = fields.parent.key if fields.parent else None
    domain = next(
        (
            label.removeprefix(_DOMAIN_LABEL_PREFIX)
            for label in fields.labels
            if label.startswith(_DOMAIN_LABEL_PREFIX)
        ),
        None,
    )
    links = tuple(StoryLink(link_type=link.type, target_key=link.key) for link in fields.issuelinks)
    story = Story(
        story_key=record.key,
        version=record.version,
        summary=fields.summary,
        description=fields.description or "",
        acceptance_criteria=fields.acceptance_criteria or "",
        links=links,
        parent_key=parent_key,
        status=status,
        domain=domain,
    )
    link_values: list[JsonValue] = [
        {"link_type": link.link_type, "target_key": link.target_key} for link in links
    ]
    label_values: list[JsonValue] = [*sorted(set(fields.labels))]
    return ItemMetadata(
        native_id=record.key,
        media_type="application/json",
        title=fields.summary,
        modified_at=record.updated,
        attributes={
            attr.STATUS: status,
            attr.PARENT_KEY: parent_key,
            attr.LINKS: link_values,
            attr.LABELS: label_values,
            attr.DOMAIN: domain,
            attr.STORY_FINGERPRINT: story.fingerprint(),
            attr.PROJECT: project_key or record.key.rsplit("-", 1)[0],
        },
    )


def _next_cursor(position: _Position | None, page: list[_Record], *, exhausted: bool) -> str | None:
    if not page and position is None:
        return None
    if not exhausted:
        last = page[-1]
        return _encode(_Position(complete=False, updated=last.updated, key=last.key))
    newest = [record.updated for record in page]
    if position is not None:
        newest.append(position.updated)
    return _encode(_Position(complete=True, updated=max(newest), key=""))


def _encode(position: _Position) -> str:
    mode = _COMPLETE if position.complete else _PARTIAL
    return f"{_PREFIX}{mode}|{position.updated.isoformat()}|{position.key}"


def _decode(cursor: str | None) -> _Position | None:
    if cursor is None:
        return None
    if not cursor.startswith(_PREFIX):
        raise InvalidCursorError("Cursor was not issued by the Jira reader")
    parts = cursor[len(_PREFIX) :].split("|", 2)
    if len(parts) != _CURSOR_PARTS or parts[0] not in {_COMPLETE, _PARTIAL}:
        raise InvalidCursorError("Cursor is corrupt")
    try:
        updated = datetime.fromisoformat(parts[1])
    except ValueError as exc:
        raise InvalidCursorError("Cursor is corrupt") from exc
    if updated.tzinfo is None:
        raise InvalidCursorError("Cursor is corrupt")
    return _Position(complete=parts[0] == _COMPLETE, updated=updated, key=parts[2])


__all__ = ["DEFAULT_OVERLAP_SECONDS", "DEFAULT_PAGE_SIZE", "JiraExportReader"]
