"""US-21: uncited statements are flagged; every citation resolves to a clause or row."""

from __future__ import annotations

from datetime import date

import pytest

from kp.store import Database
from kp.store.schema import edition
from kp.writeback import (
    DatabaseReferenceResolver,
    Problem,
    canonical_reference,
    check_citations,
    extract_references,
    extract_rule_statements,
)
from writeback.writeback_support import Seeded

KNOWN = {"2026.1:4.1.2", "2026.1:4.2.1", "register-1:Requirements:8"}
SPEC = """\
---
story: PAY-101
---
# Title

## Summary

Acknowledge each received transfer quickly. The scheme prefers speed.

## Rules

- A participant shall acknowledge every transfer [ref: 2026.1:4.1.2].
- The currency may be euro. [ref: 2026.1:4.2.1]
- A creditor account exists.

## Acceptance

The account must be checked. A transfer is acknowledged within five seconds.

```
A fenced sentence that must be ignored.
```
"""


def resolves(reference: str) -> bool:
    return reference in KNOWN


def test_us21_rule_statements_are_rules_section_sentences_plus_keyword_sentences() -> None:
    texts = [statement.text for statement in extract_rule_statements(SPEC)]

    assert texts == [
        "A participant shall acknowledge every transfer [ref: 2026.1:4.1.2].",
        "The currency may be euro. [ref: 2026.1:4.2.1]",
        "A creditor account exists.",
        "The account must be checked.",
    ]


@pytest.mark.parametrize(
    "sentence",
    [
        "The field must be set.",
        "The field must not be empty.",
        "A participant SHALL reply.",
        "A reference is required.",
        "A malformed message is rejected.",
    ],
)
def test_us21_each_keyword_makes_a_sentence_a_rule_statement(sentence: str) -> None:
    statements = extract_rule_statements(f"## Notes\n\n{sentence}\n")

    assert [statement.text for statement in statements] == [sentence]


def test_us21_a_sentence_without_keyword_outside_the_rules_section_is_not_a_rule() -> None:
    assert extract_rule_statements("## Notes\n\nThe field may be set. Mustard is yellow.\n") == ()


def test_us21_a_marker_after_the_full_stop_belongs_to_its_sentence() -> None:
    (statement,) = extract_rule_statements(
        "## Rules\n\nThe currency may be euro. [ref: 2026.1:4.2.1]\n"
    )

    assert statement.references == ("2026.1:4.2.1",)


def test_us21_citations_are_markers_or_the_spoken_form() -> None:
    text = "See 2026.1 clause 4.2.1 and [ref: reg-1:Sheet:3] and the clause 4.2 of nothing."

    assert extract_references(text) == ("reg-1:Sheet:3", "2026.1:4.2.1")
    assert canonical_reference("2026.1 clause 4.2.1") == "2026.1:4.2.1"
    assert canonical_reference(" reg-1:Sheet:3 ") == "reg-1:Sheet:3"


def test_us21_cited_resolving_retrieved_statements_are_valid() -> None:
    markdown = "## Rules\n\n- The currency may be euro [ref: 2026.1:4.2.1].\n"

    report = check_citations(markdown, resolves=resolves, retrieved={"2026.1:4.2.1"}, target=0.95)

    assert report.rate == 1.0
    assert report.meets_target
    assert report.flagged == ()


def test_us21_an_uncited_statement_is_flagged() -> None:
    report = check_citations(
        "## Rules\n\n- A bare claim.\n", resolves=resolves, retrieved=set(), target=0.95
    )

    (check,) = report.flagged
    assert check.problems == (Problem.UNCITED,)
    assert report.rate == 0.0
    assert not report.meets_target


def test_us21_a_citation_that_does_not_exist_is_flagged() -> None:
    report = check_citations(
        "## Rules\n\n- A claim [ref: 2026.1:9.9.9].\n",
        resolves=resolves,
        retrieved={"2026.1:9.9.9"},
        target=0.95,
    )

    (check,) = report.flagged
    assert check.problems == (Problem.UNRESOLVED,)
    assert check.unresolved == ("2026.1:9.9.9",)


def test_us21_a_citation_not_retrieved_in_the_session_is_flagged() -> None:
    report = check_citations(
        "## Rules\n\n- A claim [ref: 2026.1:4.2.1].\n",
        resolves=resolves,
        retrieved=set(),
        target=0.95,
    )

    (check,) = report.flagged
    assert check.problems == (Problem.NOT_RETRIEVED,)


def test_us21_spoken_retrieved_form_matches_canonical_retrieval() -> None:
    report = check_citations(
        "## Rules\n\n- A claim 2026.1 clause 4.2.1.\n",
        resolves=resolves,
        retrieved={"2026.1 clause 4.2.1"},
        target=0.95,
    )

    assert report.rate == 1.0


def test_us21_rate_is_reported_against_the_target() -> None:
    cited = "- A claim [ref: 2026.1:4.2.1].\n" * 19
    at_target = check_citations(
        f"## Rules\n\n{cited}- A bare claim.\n",
        resolves=resolves,
        retrieved=KNOWN,
        target=0.95,
    )
    below = check_citations(
        f"## Rules\n\n{cited}- A bare claim.\n- Another bare claim.\n",
        resolves=resolves,
        retrieved=KNOWN,
        target=0.95,
    )

    assert (at_target.rule_statements, at_target.rate, at_target.meets_target) == (20, 0.95, True)
    assert (below.rule_statements, below.meets_target) == (21, False)


def test_us21_no_rule_statements_is_a_full_rate_not_a_division_by_zero() -> None:
    report = check_citations(
        "# Title\n\nNothing binding here.\n", resolves=resolves, retrieved=set(), target=0.95
    )

    assert (report.rule_statements, report.rate, report.meets_target) == (0, 1.0, True)


def test_us21_citation_rows_keep_the_first_broken_reference() -> None:
    markdown = "## Rules\n\n- Both [ref: 2026.1:4.2.1] and [ref: 2026.1:9.9] apply.\n- Bare.\n"

    report = check_citations(
        markdown, resolves=resolves, retrieved=KNOWN | {"2026.1:9.9"}, target=0.95
    )
    first, second = report.to_citations("spec-1")

    assert (first.reference, first.resolved, first.retrieved_in_session) == (
        "2026.1:9.9",
        False,
        True,
    )
    assert not first.is_valid
    assert (second.reference, second.resolved, second.is_valid) == (None, False, False)
    assert first.citation_id == "spec-1:0"


def test_us21_reference_resolver_finds_clauses_and_register_rows(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        resolver = DatabaseReferenceResolver(connection)

        assert resolver.resolves("2026.1:4.2.1")
        assert resolver.resolves("2025.2:4.2.1")
        assert resolver.resolves(seeded.requirement_id)
        assert not resolver.resolves("2026.1:9.9.9")
        assert not resolver.resolves("register-1:Requirements:99")
        assert not resolver.resolves("not a reference")


def test_us21_a_withdrawn_clause_still_resolves(database: Database, seeded: Seeded) -> None:
    with database.transaction() as connection:
        connection.execute(
            edition.update()
            .where(edition.c.label == "2025.2")
            .values(withdrawn_from=date(2026, 1, 1))
        )
        assert DatabaseReferenceResolver(connection).resolves("2025.2:4.2.1")
