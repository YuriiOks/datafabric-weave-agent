"""The demo's HTML report and JSON summary."""

from __future__ import annotations

import json

from kp.demo.model import (
    Check,
    ConnectivityTable,
    CriterionRow,
    DemoOutcome,
    LineResult,
    PipelineFacts,
)
from kp.demo.report import render_html, render_json

ACCENTED_E = chr(0xE9)  # kept out of the source so the file stays ASCII


def _outcome(*, passed: bool = True, evidence: str = "all <good> & well") -> DemoOutcome:
    lines = tuple(
        LineResult(line_id, (Check("a check", passed, evidence),)) for line_id in ("W1", "W2", "W3")
    )
    return DemoOutcome(
        lines=lines,
        facts=PipelineFacts(
            "2026-11-20", "dry_run", (("Sweep", "ok"),), (("blocking", "n", "PASS"),)
        ),
        connectivity=ConnectivityTable(
            "local only", (CriterionRow("X-01", "route", "INCONCLUSIVE", "none"),)
        ),
        notes=("a note",),
    )


def test_text_is_escaped_in_the_html_and_the_page_is_ascii() -> None:
    page = render_html(_outcome(evidence=f"caf{ACCENTED_E}" + " <b>bold</b> & more"))

    page.encode("ascii")
    assert "&lt;b&gt;bold&lt;/b&gt;" in page
    assert "<b>bold</b>" not in page
    assert "&amp; more" in page
    assert "&#233;" in page  # the accented letter is written as a numeric reference


def test_the_page_names_each_line_and_the_verdict() -> None:
    page = render_html(_outcome(passed=False))

    assert page.count("FAIL") >= 4
    assert "at least one line fails" in page
    assert "X-01" in page


def test_the_summary_is_ascii_json_with_the_verdict_and_every_line() -> None:
    text = render_json(_outcome(evidence=f"caf{ACCENTED_E}"))

    text.encode("ascii")
    summary = json.loads(text)
    assert summary["passed"] is True
    assert [line["id"] for line in summary["lines"]] == ["W1", "W2", "W3"]
    assert summary["lines"][0]["checks"][0]["evidence"] == f"caf{ACCENTED_E}"
    assert summary["connectivity"]["criteria"][0]["id"] == "X-01"


def test_an_outcome_needs_all_three_lines_to_pass() -> None:
    passing = _outcome()

    assert passing.passed
    assert not DemoOutcome(passing.lines[:2], passing.facts, passing.connectivity).passed
    assert not LineResult("W1", ()).passed
