# Install on the workstation

This guide takes the package from a zip to a working demo, then to real data. It uses no
internet: every package comes from the internal package mirror that `pip` is already set up for.

## What you need

| Need | Notes |
|---|---|
| Python 3.11 or newer | `python3 --version` |
| `pip` set up against the package mirror | `pip config list` should show the mirror |
| Docker | Optional. Nothing here needs it. |
| PostgreSQL | Not needed for the demo and the tests (a local SQLite file). Needed for real data: `KP_MODE=real` refuses a SQLite file. |

The package builds with `hatchling`. If the mirror does not carry it, install it first and add
`--no-build-isolation` to the `pip install -e` lines below.

## 1. Unzip and verify

```bash
unzip kp-poc-<YYYYMMDD>.zip
cd kp-poc-<YYYYMMDD>
sha256sum -c SHA256SUMS            # every line must say OK
python3 install.py --inspect --target ~/kp-poc    # lists what would be written; writes nothing
python3 install.py --target ~/kp-poc              # writes the project tree
cd ~/kp-poc
```

`install.py` checks the checksums itself before it does anything, refuses a target folder that
is not empty (use `--force` to override), and prints the next steps. `README-PACKAGE.txt` in the
zip lists the output to expect from `--inspect`.

## 2. Create the environment and install

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[web,dev]'
```

`.[web]` adds the web page (section 4) and `.[dev]` adds the test and check tools. For a run
without either, `pip install -e .` is enough. The real route needs two more extras, installed
when you get to that step: `pip install -e '.[cloud,postgres]'`.

`.[dev]` also pulls in `httpx2` (the test client of the web page tests) and `fpdf2` (it only
generates the synthetic PDF files). Neither is needed to run the demo or the web page, so if the
mirror lacks one of them, `pip install -e '.[web]'` is enough and `scripts/check.sh` has to wait.
Ask the platform team to confirm both are on the mirror before the install.

## 3. Run the demo on the bundled synthetic data

```bash
.venv/bin/kp demo
```

The demo reads the five sources (all synthetic), parses, indexes and links them, publishes a
knowledge version, drives the agent tools, and runs the connectivity job against stand-ins. It
prints three "done when" lines as PASS or FAIL with evidence and ends with `Result: PASS` (exit
status 0). It writes `kp-demo/report.html` (one self-contained page) and `kp-demo/summary.json`.
Rows marked INCONCLUSIVE in the connectivity table are expected: they need the real route.

The demo builds its database and working data fresh on every run. Running it again replaces
`kp-demo`; nothing has to be removed first. Only an explicit `--db PATH` that already exists is
refused, so a database you care about is never overwritten.

On the way, a person's step is played for you: one spec is already merged before the first
sweep, and the demo merges and then edits a drafted spec to show it coming back as knowledge.
The `Result` line says which spec publisher was used (`local_git` when `git` works, otherwise
`dry_run`); both give the same answers.

## 4. Open the web page

```bash
.venv/bin/kp web --port 8090 --db kp-demo/kp-demo.db --today 2026-11-20
```

`--today` is the date on the first line of the demo output ("Demo as at ..."): the synthetic
data lies after today's real date, so the page treats that day as today. The page shows the demo
database: overview and publication checks, search, a rule as at a date,
impact, coverage, specs, the connectivity table and the audit trail. It binds to the loopback
address only. In the editor open the Ports view, forward port 8090, and open the forwarded
address. In local mode the page offers the demo users in a drop-down, so you can see what a user
without access to a domain does not get. Stop the server with Ctrl+C.

If you only want the static report, serve its folder instead:

```bash
python3 -m http.server 8091 --bind 127.0.0.1 --directory kp-demo
```

and forward port 8091.

## 5. Run the agent tool servers

The demo leaves a database and an identity mapping behind. Point the servers at them:

```bash
export KP_DATABASE_URL=sqlite+pysqlite:///kp-demo/kp-demo.db
export KP_IDENTITY_MAPPING_FILE=kp-demo/data/identity/identity-mapping.yaml
export KP_CALLER=user-full-access          # who is calling (one of the users in the mapping)

.venv/bin/kp serve-read                    # read tools, JSON-RPC on stdin and stdout
.venv/bin/kp serve-write                   # write tools (local stand-in targets in local mode)
```

For a server on a port, add `--http 8092` (read) or `--http 8093` (write). They bind to the
loopback address only; forward the port in the editor to reach it. Messages are posted to the
path `/mcp`. In HTTP mode the caller comes from the `X-KP-Caller` header, not from `KP_CALLER`.
Do not expose either server beyond the
loopback address unless a proxy that authenticates users sets that header.

The read server offers search, links, template, rule-as-at-date and coverage. The write server
publishes a spec as a pull request and updates the story status; its targets are fixed by
settings, never by the caller.

## 6. Run the tests

```bash
scripts/check.sh            # lint, format check, types, then all tests
.venv/bin/pytest -q         # tests only
```

The tests need no network, no real systems and no secrets. `scripts/check.sh` needs the `dev` extra.

## 7. Switching to real data

Local mode (`KP_MODE=local`, the default) is what you ran above. Real data is a configuration
change, not a code change. All settings are environment variables with the `KP_` prefix; the
file `.env.example` lists every one with a `<placeholder>`. Copy it to `.env`, fill in only what
you need, and load it with `set -a; . ./.env; set +a`. Never commit `.env` and never put a
secret in it that the secret store should hold: read secrets from the secret store into the
environment when you start a process.

With `KP_MODE=real` the program refuses to start while a required value is missing or still a
`<placeholder>`, and it names the setting (never the value). Real mode also refuses a SQLite
database, and it never creates tables on its own: `kp init-db` does that once.

### Settings per part

| Part | Settings to fill | Needs |
|---|---|---|
| Document library | `KP_DOCUMENT_LIBRARY_ROOT` (folder of the library, or a mounted copy) | Nothing from the platform team |
| Regulatory repository | `KP_REGULATORY_REPO_PATH` (a checkout; only merged editions are read) | Nothing from the platform team |
| Wiki | `KP_TOOL_NAMESPACE_CONFLUENCE`, `KP_SOURCE_TOKEN_CONFLUENCE`, `KP_CONFLUENCE_APPROVED_LABEL` | D-01 to D-06, D-10 |
| Tickets | `KP_TOOL_NAMESPACE_JIRA`, `KP_SOURCE_TOKEN_JIRA`, `KP_JIRA_PROJECT_KEY` | D-01 to D-06, D-10 |
| Code repository | `KP_TOOL_NAMESPACE_GITHUB`, `KP_SOURCE_TOKEN_GITHUB` | D-01 to D-06, D-10 |
| Gateway | `KP_GATEWAY_BASE_URL`, `KP_GATEWAY_TOKEN_URL`, `KP_GATEWAY_CLIENT_ID`, `KP_GATEWAY_CLIENT_SECRET`, `KP_GATEWAY_TOKEN_HEADER`, `KP_SOURCE_TOKEN_HEADER`, `KP_USE_CASE_ID` | D-01, D-02, D-03, D-10 |
| Extraction service | `KP_EXTRACTION_BASE_URL`; if it has its own credential, `KP_EXTRACTION_AUTH_HEADER` and `KP_EXTRACTION_TOKEN` together | D-07 |
| Storage | `KP_RAW_BUCKET`, `KP_MARKDOWN_BUCKET`; install the extra with `pip install -e '.[cloud]'` | D-08 |
| Database | `KP_DATABASE_URL` set to a PostgreSQL address (see below) | D-08 |
| Connectivity sample | `KP_SAMPLE_ITEMS_FILE` (the nine agreed items; default is the bundled synthetic file) | D-09 |
| Write targets | `KP_SPEC_REPO`, `KP_SPEC_PATH`, `KP_JIRA_FIELDS_ALLOWED` | D-01 to D-06 |
| Access | `KP_IDENTITY_MAPPING_FILE` (written mapping of users to access domains) | The platform team's list of users and domains |
| Web page | `KP_WEB_IDENTITY_HEADER` (the header that carries the signed-in user), `KP_WEB_RESULT_LIMIT`, `KP_WEB_AUDIT_LIMIT` | A proxy that signs users in and sets that header |

The exact shape of the answers is only known after the first live discovery (step 3 below). The
header names and tool namespaces are not: the first discovery cannot start without them, because
the gateway needs them to be asked at all. They come from D-05, D-06 and D-10.

### PostgreSQL

Set `KP_DATABASE_URL` to the PostgreSQL address (in SQLAlchemy form, for example
`postgresql+psycopg://<user>@<host>/<database>`, with the password supplied from the secret
store). A PostgreSQL driver is not part of the default install: add it from the mirror with
`pip install -e '.[postgres]'`. Then create the tables once:

```bash
.venv/bin/kp init-db
```

The schema uses only dialect-neutral SQL, so the same code runs on SQLite and PostgreSQL. Real
mode needs the database before the first discovery, because the connectivity job records what
it sees in it. Without D-08 only local mode runs (sections 1 to 6).

Only `kp init-db` creates or changes tables in real mode. Every other command expects them to
exist and fails with a database error if they do not. `KP_DATABASE_URL` is a secret as soon as
it holds a password: it is never printed or logged, and the settings object hides it.

### Order of the real run

1. Before the first discovery, `kp connectivity discover` needs every value below set to a real
   (not `<placeholder>`) value, because real mode refuses to start otherwise and the job cannot
   reach the gateway without them. It is more than the gateway:

   | Group | Settings | Where the value comes from |
   |---|---|---|
   | Gateway | `KP_GATEWAY_BASE_URL`, `KP_GATEWAY_TOKEN_URL`, `KP_GATEWAY_CLIENT_ID`, `KP_GATEWAY_CLIENT_SECRET`, `KP_GATEWAY_TOKEN_HEADER`, `KP_SOURCE_TOKEN_HEADER`, `KP_USE_CASE_ID` | D-01, D-02, D-03, D-10 |
   | Tool servers | `KP_TOOL_NAMESPACE_CONFLUENCE`, `KP_TOOL_NAMESPACE_JIRA`, `KP_TOOL_NAMESPACE_GITHUB` | D-06 |
   | Source credentials | `KP_SOURCE_TOKEN_CONFLUENCE`, `KP_SOURCE_TOKEN_JIRA`, `KP_SOURCE_TOKEN_GITHUB` | D-05 |
   | Database | `KP_DATABASE_URL` (PostgreSQL), tables created with `kp init-db` | D-08 |
   | Not used by discovery, but required | `KP_EXTRACTION_BASE_URL`, `KP_RAW_BUCKET`, `KP_MARKDOWN_BUCKET`, `KP_SPEC_REPO`, `KP_SPEC_PATH`, and a non-empty `KP_JIRA_FIELDS_ALLOWED` | D-07, D-08, or a stand-in |

   Until D-07 and D-08 and the write targets are known, any non-placeholder value will do for the
   last row (for example `extraction-not-yet`, `bucket-not-yet`, `org/repository`, `specs` and
   `'["status"]'`). Discovery never touches them. Replace them before step 4.

   Then run `.venv/bin/kp connectivity discover`. This is the first contact with the real
   route. It lists and keeps the tool signatures of the three source servers. A route that is
   not open (D-01) or a refused sign-in (D-03, D-04) is reported as blocking, so fix those
   before going on.
2. Fill the sample file, then run `.venv/bin/kp connectivity run --skip-extraction`. It fetches
   the nine sample items and stores the raw copies.
3. Check the answers. If the source tools return source fields, the shape matches the stand-ins.
   If they return summaries instead, stop and tell the platform team: the later steps would be
   wasted.
4. Fill the real extraction and storage settings (D-07, D-08) and run
   `.venv/bin/kp connectivity run`.
5. Run `.venv/bin/kp connectivity report`. It scores the eleven exit criteria as PASS, FAIL or
   INCONCLUSIVE. Only a run on the real route can turn the INCONCLUSIVE rows into PASS.

What `kp sweep` does in real mode. The wiki, tickets and code are read through the gateway by
the same three adapters the connectivity job proved, and their raw copies go to the raw bucket.
Those adapters read the nine sample items of step 2 and report the current version of each,
without change tracking: a full feed per source needs the shapes that step 3 confirms. The
library and the regulatory repository read their folders in both modes. The links to code and
tests are built from the code items the sweep stored, so no checkout folder is needed.

Writing a spec as a pull request and updating the story are not available in real mode yet:
`kp draft-spec --publish`, `kp serve-write` and `kp merge-spec` refuse with a message that says
so, instead of sending a request the gateway would answer with an unexplained error. The
vector side of search (`KP_SEARCH_VECTOR_ENABLED`) is refused in real mode until a real
embedding model is connected.

### The ten dependencies

| ID | What it is | Settings it unblocks |
|---|---|---|
| D-01 | A network route from the workstation to the gateway (blocking) | `KP_GATEWAY_BASE_URL` |
| D-02 | Onboarding of this use case on the agent platform | `KP_USE_CASE_ID` |
| D-03 | A service identity for the platform | `KP_GATEWAY_CLIENT_ID`, `KP_GATEWAY_CLIENT_SECRET`, `KP_GATEWAY_TOKEN_URL` |
| D-04 | Group entitlement so that identity may call the source servers | No setting; shown by the sign-in check |
| D-05 | Per-source access credentials for the wiki, tickets and code (needed before discovery) | `KP_SOURCE_TOKEN_CONFLUENCE`, `KP_SOURCE_TOKEN_JIRA`, `KP_SOURCE_TOKEN_GITHUB`, the two header names |
| D-06 | Subscriptions to the three source servers (needed before discovery: they give the namespaces) | `KP_TOOL_NAMESPACE_CONFLUENCE`, `KP_TOOL_NAMESPACE_JIRA`, `KP_TOOL_NAMESPACE_GITHUB` |
| D-07 | The document extraction endpoint, agreed contract | `KP_EXTRACTION_BASE_URL`, `KP_EXTRACTION_AUTH_HEADER`, `KP_EXTRACTION_TOKEN` |
| D-08 | The two buckets and PostgreSQL (the database is needed before discovery) | `KP_RAW_BUCKET`, `KP_MARKDOWN_BUCKET`, `KP_DATABASE_URL` |
| D-09 | The agreed sample scopes (the nine items) | `KP_SAMPLE_ITEMS_FILE` |
| D-10 | The values for the region of the gateway | `KP_GATEWAY_BASE_URL`, `KP_GATEWAY_TOKEN_URL`, the header names |

Without D-01 nothing on the real route runs. D-03, D-05, D-06, D-08 and D-10 all have to be in
place before the first discovery can start. Everything in sections 1 to 6 works without any of
them.

## 8. Keep agents away from the sources and the database

The read tools are the only way an agent reaches knowledge. The program has no tool that reaches a
source or the database, but "refused" for a direct connection is the job of the environment, not
of the code. Set it up before agents are connected:

- The environment the agents run in has no network route to the wiki, the ticket tracker, the code
  host or the database. Only the platform host reaches them.
- The two tool servers connect to the database with their own role, not with the role that owns
  the tables. A starting point for PostgreSQL, to be adapted by the database owner:

  ```sql
  CREATE ROLE <tool-server-role> LOGIN;
  GRANT SELECT ON ALL TABLES IN SCHEMA public TO <tool-server-role>;
  GRANT INSERT ON tool_call, session_retrieval TO <tool-server-role>;
  GRANT INSERT, UPDATE ON spec, citation TO <tool-server-role>;   -- write server only
  ```

  The read server needs no more than the first three lines (it records every call and what each
  session was shown). Give the write server a second role with the last line as well.
- A server on a port sits behind a proxy that authenticates users and sets the identity header.
  Send `X-KP-Session` from a client that runs several sessions at once; without it a user's and
  an agent's requests share one session, which is what lets a spec published after reading be
  checked against what was read.

## Troubleshooting

| Symptom | Cause and fix |
|---|---|
| `pip` cannot find a package | The mirror lacks it. Ask for it to be added; nothing else can fetch it. |
| `KP_MODE=real requires real values for: ...` | The named settings are unset or still `<placeholder>`. |
| `KP_IDENTITY_MAPPING_FILE is required to serve agents` | Set it to the mapping file (step 5). |
| `kp demo` ends with `Result: FAIL` | Keep `kp-demo/summary.json` and the printed lines; they name the failed check. |
| Port 8090 does not open in the browser | The port is not forwarded yet; forward it in the editor's Ports view. |
| `kp web: the UI libraries are missing` | Install the extra: `pip install -e '.[web]'`. |
| `kp demo` says `<file> already exists` | Only with an explicit `--db PATH` that exists: the demo never overwrites a database you named. Choose another path, or leave `--db` out; a plain `kp demo` replaces `kp-demo` by itself. |
| `pip install -e '.[web,dev]'` fails on `httpx2` or `fpdf2` | Both are for the tests and the synthetic PDFs only. Use `pip install -e '.[web]'` to run the demo and the web page. |
| `KP_MODE=real requires real values for: KP_DATABASE_URL` | Real mode needs PostgreSQL. A SQLite address is refused (section 7). |
| A database error such as a missing table in real mode | Real mode never creates tables. Run `kp init-db` once. |
| `kp merge-spec` or `kp draft-spec --publish` refuses in real mode | Writing is not available in real mode yet (section 7). |
