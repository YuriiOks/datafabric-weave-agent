"""Artifact staging: references, digest binding and cleanup of dead attempts."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from uuid import uuid4

from app.recsys.refresh.integration.staging import (
    ArtifactStaging,
    StagedArtifactMismatch,
    StagedArtifactMissing,
)


class _Clock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


class ArtifactStagingTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.base = Path(self._tmp.name) / "staging"
        self.clock = _Clock()
        self.staging = ArtifactStaging(self.base, monotonic=self.clock, stale_after_seconds=60)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def _stage(self, job_id, attempt_id, source_id: str, digest: str = "a" * 64) -> str:
        root = self.staging.root_for(attempt_id, source_id)
        self.assertFalse(root.exists())
        root.mkdir()
        return self.staging.register(
            job_id=job_id,
            attempt_id=attempt_id,
            source_id=source_id,
            acquired=object(),
            digest=digest,
        )

    def test_reference_returns_the_artifact_only_with_its_digest(self) -> None:
        reference = self._stage(uuid4(), uuid4(), "workbook")

        self.assertEqual(self.staging.get(reference, "a" * 64).source_id, "workbook")
        with self.assertRaises(StagedArtifactMismatch):
            self.staging.get(reference, "b" * 64)
        with self.assertRaises(StagedArtifactMissing):
            self.staging.get("staged-artifact:unknown/workbook", "a" * 64)

    def test_discarding_every_source_removes_the_attempt_directory(self) -> None:
        attempt_id = uuid4()
        job_id = uuid4()
        first = self._stage(job_id, attempt_id, "workbook")
        second = self._stage(job_id, attempt_id, "skills")

        self.staging.discard([first])
        self.assertTrue((self.base / str(attempt_id)).exists())
        self.staging.discard([second])
        self.assertFalse((self.base / str(attempt_id)).exists())

    def test_prune_drops_earlier_attempts_of_the_job_and_stale_entries(self) -> None:
        job_id = uuid4()
        earlier = self._stage(job_id, uuid4(), "workbook")
        other_job_stale = self._stage(uuid4(), uuid4(), "workbook")
        self.clock.now += 30
        other_job_recent = self._stage(uuid4(), uuid4(), "skills")
        self.clock.now += 45

        self.staging.prune(job_id=job_id, attempt_id=uuid4())

        with self.assertRaises(StagedArtifactMissing):
            self.staging.get(earlier, "a" * 64)
        with self.assertRaises(StagedArtifactMissing):
            self.staging.get(other_job_stale, "a" * 64)
        self.assertEqual(self.staging.get(other_job_recent, "a" * 64).source_id, "skills")

    def test_clear_removes_everything(self) -> None:
        reference = self._stage(uuid4(), uuid4(), "workbook")

        self.staging.clear()

        self.assertFalse(self.base.exists())
        with self.assertRaises(StagedArtifactMissing):
            self.staging.get(reference, "a" * 64)
