---
pack_id: "bpc-sep26-v1"
local_id: "AGT-01"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1345"
summary: "Reconcile the approved Agent workbook contract and integration seams"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 5
scope: "foundation"
create_by_default: true
planned_start: "2026-09-15"
planned_due: "2026-09-15"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-01"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-agt-01"
architecture_sections: ["ingestion","controlled refresh","read evidence"]
---

# Reconcile the approved Agent workbook contract and integration seams

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1345**. Local reference **AGT-01** is not a Jira key.
- Estimate: **5 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-15 → 2026-09-15 (D5–D5)**.
- Recommendation extension: **2026-09-15 → 2026-09-15 (D5–D5)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

The reported Agent workflow is workbook-based, but its current file location, exact sheets and headers, authority, source completeness and existing bank-code seams are not available in this checkout. Produce the reconciled Agent source contract that lets the shared catalogue ingest only an approved, accountable snapshot.

## Scope

- Inspect the approved workbook and the reconciled bank checkout; record actual module and surface locations only after inspection.
- Record the Agent collection's source authority, environment/partition, capture time, file hash, schema/version evidence, completeness declaration, row counts and accepted/quarantined reasons using the shared manifest contract.
- Map the exact fields used for source Agent identity, display metadata, lifecycle/status and declared Skill/MCP references. Record unknown or unsupported fields instead of silently consuming them.
- Identify whether an existing registry/parser/read surface can be safely extended, and document the smallest integration seam.

## Boundaries

Do not invent workbook headers, filesystem paths, Agent Hub APIs, an authenticated refresh endpoint or a durable worker. Do not ingest Knowledge Sources or execute source content. This task maps and validates the source; it does not publish a graph.

## Technical steps

1. Obtain the approved workbook reference and verify it belongs to the authorised scope.
2. Compare actual Agent sheets/columns with the shared source contract; classify each required field as present, absent, ambiguous or owner-decision-required.
3. Map current checkout modules, policies and diagnostics that can host the adapter; record evidence as repository path and revision only after direct inspection.
4. Define dry-run outcomes for missing required sheets, missing identity fields, schema drift and incomplete snapshots.
5. Hand the typed field map and unresolved questions to AGT-02 and AGT-03.

## Acceptance criteria

- A reviewed Agent source-contract record identifies the approved snapshot, scope, exact required fields, field authority and completeness behaviour.
- The implementation seam is recorded from the live checkout, or its absence is an explicit blocker; no guessed path or route appears in the result.
- A dry run can demonstrate that a missing required sheet/header, ambiguous identity field or non-approved snapshot creates a typed quarantine/failure and leaves the active publication unchanged.
- Unsupported columns and unresolved source semantics are visible to the source owner.

## Evidence to attach

Redacted manifest/schema summary, dry-run output for each failure class, current-checkout seam mapping, and a list of owner decisions.

## Dependencies / blockers

Requires CORE-01 and access to an approved workbook plus its source owner. Blocks AGT-02 and AGT-03.

## Out of scope

Workbook acquisition automation, Agent Hub API integration, publishing, native Hub binding, recommendation ranking and UI redesign.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-01](CORE-01.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `ingestion`, `controlled refresh`, `read evidence`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
