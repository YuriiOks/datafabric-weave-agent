"""A fictional "Payments Rulebook" from "Example Scheme", in two editions, as PDF and Markdown.

The text is invented. Clause 4.2.1 (currency of inbound credit transfers) differs between the
editions, clause 4.2.4 exists only in the later one, and clause 6.3.2 is deliberately very
long (over 1,800 words; with no tokenizer dependency, whitespace-split words are the size
proxy, and a real tokenizer yields at least as many tokens) to exercise clause splitting.

Requires the ``dev`` extra (fpdf2). PDF creation date and metadata are fixed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import UTC, date, datetime
from pathlib import Path

import yaml
from fpdf import FPDF

from kp.domain.clause_ref import ClauseRef
from kp.testing.dataset import ClauseTruth, EditionTruth

PUBLISHER = "Example Scheme"
RULEBOOK_TITLE = "Payments Rulebook"
RULEBOOK_STEM = "payments-rulebook"
CURRENCY_CLAUSE = "4.2.1"
LONG_CLAUSE = "6.3.2"
_PDF_CREATED = datetime(2026, 1, 1, tzinfo=UTC)


@dataclass(frozen=True)
class EditionSpec:
    """Parameters of one generated edition."""

    label: str
    effective_date: date
    superseded_from: date | None


EDITION_2025_2 = EditionSpec("2025.2", date(2025, 6, 2), date(2026, 11, 16))
EDITION_2026_1 = EditionSpec("2026.1", date(2026, 11, 16), None)
EDITIONS = (EDITION_2025_2, EDITION_2026_1)


@dataclass(frozen=True)
class ClauseSource:
    """A clause before rendering."""

    number: str
    title: str
    text: str

    @property
    def depth(self) -> int:
        """Nesting level of the number."""
        return self.number.count(".") + 1


_SECTIONS: dict[str, str] = {
    "1": "Scope and definitions",
    "1.1": "Scope",
    "1.2": "Defined terms",
    "2": "Participants",
    "2.1": "Eligibility",
    "2.2": "Obligations",
    "3": "Message formats",
    "3.1": "Credit transfer message",
    "3.2": "Identifiers",
    "4": "Inbound credit transfers",
    "4.1": "Receipt",
    "4.2": "Validation",
    "4.3": "Settlement",
    "5": "Outbound credit transfers",
    "5.1": "Initiation",
    "5.2": "Rejections and returns",
    "6": "Operational resilience",
    "6.1": "Availability",
    "6.2": "Incident reporting",
    "6.3": "Message validation",
}

# Leaf clauses of the earlier edition: number -> (title, text).
_BASE_LEAVES: dict[str, tuple[str, str]] = {
    "1.1.1": (
        "Transfers in scope",
        "This rulebook applies to credit transfers exchanged between participants of "
        "Example Scheme in the payments domain.",
    ),
    "1.1.2": (
        "Transfers out of scope",
        "Card payments, direct debits and cheques are outside the scope of this rulebook.",
    ),
    "1.2.1": (
        "Participant",
        "A participant is an institution admitted to Example Scheme under the rules of section 2.",
    ),
    "1.2.2": (
        "Credit transfer",
        "A credit transfer is an instruction to move funds from a debtor account to a "
        "creditor account.",
    ),
    "2.1.1": (
        "Admission",
        "An institution is admitted once the scheme operator confirms that it meets the "
        "criteria published with this rulebook.",
    ),
    "2.1.2": (
        "Suspension",
        "The scheme operator may suspend a participant that repeatedly breaches this rulebook.",
    ),
    "2.2.1": (
        "Contact details",
        "Each participant shall keep its operational contact details current with the "
        "scheme operator.",
    ),
    "2.2.2": (
        "Record keeping",
        "Each participant shall keep records of all credit transfers for at least seven years.",
    ),
    "3.1.1": (
        "Mandatory elements",
        "Every credit transfer message must carry a message identifier, an instructed amount, "
        "a debtor account and a creditor account.",
    ),
    "3.1.2": (
        "Optional elements",
        "A credit transfer message may carry a remittance reference of up to 140 characters.",
    ),
    "3.2.1": (
        "Account identifiers",
        "Accounts are identified by an international account number of at most 34 characters.",
    ),
    "4.1.1": (
        "Timing of receipt",
        "A credit transfer is received when the gateway of the participant accepts the "
        "complete message.",
    ),
    "4.1.2": (
        "Acknowledgement",
        "A participant shall acknowledge every received credit transfer within five seconds.",
    ),
    CURRENCY_CLAUSE: (
        "Currency of inbound credit transfers",
        "An inbound credit transfer shall be denominated in euro only. A credit transfer "
        "denominated in any other currency shall be rejected with reason code CUR01.",
    ),
    "4.2.2": (
        "Amount limits",
        "An inbound credit transfer shall not exceed the per-transfer limit published by "
        "the scheme operator.",
    ),
    "4.2.3": (
        "Beneficiary account checks",
        "The receiving participant shall confirm that the creditor account exists and can "
        "receive funds.",
    ),
    "4.3.1": (
        "Settlement cycle",
        "Accepted credit transfers are settled in the next settlement cycle after receipt.",
    ),
    "4.3.2": ("Settlement currency", "Settlement takes place in euro."),
    "5.1.1": (
        "Currency of outbound transfers",
        "An outbound credit transfer may be initiated in euro only.",
    ),
    "5.1.2": (
        "Cut-off times",
        "The initiating participant shall submit outbound credit transfers before the daily "
        "cut-off time.",
    ),
    "5.2.1": (
        "Reason codes",
        "A rejected credit transfer shall carry exactly one reason code from the published "
        "list, for example CUR01.",
    ),
    "5.2.2": (
        "Return timing",
        "A returned credit transfer shall be sent back within two business days.",
    ),
    "6.1.1": (
        "Service availability target",
        "A participant shall keep its credit transfer service available at least 99.5 "
        "percent of each calendar month.",
    ),
    "6.2.1": (
        "Notification timing",
        "A participant shall notify the scheme operator of a major incident within four hours.",
    ),
    "6.3.1": (
        "Schema validation",
        "Every message shall validate against the published message schema before it is processed.",
    ),
}

# Changes made by the later edition: same number replaces; a new number adds.
_LATER_LEAVES: dict[str, tuple[str, str]] = {
    "2.2.2": (
        "Record keeping",
        "Each participant shall keep records of all credit transfers for at least ten years.",
    ),
    CURRENCY_CLAUSE: (
        "Currency of inbound credit transfers",
        "An inbound credit transfer may be denominated in euro or in pounds sterling. A "
        "credit transfer denominated in any other currency shall be rejected with reason "
        "code CUR01. The currency is carried in the currency element of the message.",
    ),
    "4.2.4": (
        "Reference format",
        "The remittance reference of an inbound credit transfer shall not contain control "
        "characters.",
    ),
    "4.3.2": (
        "Settlement currency",
        "Settlement takes place in the currency of the credit transfer.",
    ),
    "6.1.1": (
        "Service availability target",
        "A participant shall keep its credit transfer service available at least 99.9 "
        "percent of each calendar month.",
    ),
}

_ELEMENTS = (
    "message identifier",
    "instructed amount",
    "currency",
    "debtor account",
    "creditor account",
    "remittance reference",
    "settlement date",
    "charge bearer code",
    "purpose code",
    "creditor name",
    "debtor name",
    "end-to-end identifier",
)
_CONDITIONS = (
    "must be present",
    "must not be empty",
    "must not exceed thirty-five characters",
    "must contain only characters from the permitted set",
    "must match the pattern published with the message schema",
    "must agree with the value in the group header",
    "must not contain leading or trailing spaces",
    "must be expressed in upper case",
)
_REASON_CODES = tuple(f"MSG{number:02d}" for number in range(1, 13))


def _paragraph_label(index: int) -> str:
    letters = "abcdefghijklmnopqrstuvwxyz"
    return (
        letters[index] if index < len(letters) else letters[index // 26 - 1] + letters[index % 26]
    )


def _long_clause_text(seed: int, paragraph_count: int) -> str:
    """Build the sub-paragraphs of the long clause; a larger count extends the same text."""
    rng = random.Random(seed)
    paragraphs = []
    for index in range(paragraph_count):
        element = rng.choice(_ELEMENTS)
        condition = rng.choice(_CONDITIONS)
        code = rng.choice(_REASON_CODES)
        paragraphs.append(
            f"({_paragraph_label(index)}) The {element} element {condition}. A message that "
            f"fails this rule shall be rejected with reason code {code}, and the receiving "
            "participant shall record the failure together with the message identifier and "
            "the time of receipt so that the sending participant can correct and resubmit "
            "the message."
        )
    return "\n\n".join(paragraphs)


def build_clauses(edition: EditionSpec, seed: int) -> tuple[ClauseSource, ...]:
    """Assemble every clause of an edition in reading order.

    :param edition: Which edition to build
    :param seed: Seed for the long clause
    :return: Clauses sorted by clause number
    """
    leaves = dict(_BASE_LEAVES)
    long_paragraphs = 48
    if edition.label == EDITION_2026_1.label:
        leaves.update(_LATER_LEAVES)
        long_paragraphs += 2
    leaves[LONG_CLAUSE] = (
        "Detailed validation rules",
        _long_clause_text(seed, long_paragraphs),
    )
    clauses = [
        ClauseSource(
            number=number,
            title=title,
            text=f"This {'section' if '.' not in number else 'subsection'} covers {title.lower()}.",
        )
        for number, title in _SECTIONS.items()
    ]
    clauses += [ClauseSource(number, title, text) for number, (title, text) in leaves.items()]
    return tuple(sorted(clauses, key=lambda clause: ClauseRef(edition.label, clause.number)))


def _render_pdf(
    edition: EditionSpec, clauses: tuple[ClauseSource, ...], pages: dict[str, int]
) -> tuple[bytes, dict[str, int]]:
    """Render the PDF; ``pages`` fills the table of contents, the result maps clause pages."""
    pdf = FPDF(unit="mm", format="A4")
    pdf.set_creation_date(_PDF_CREATED)
    pdf.set_title(f"{RULEBOOK_TITLE} {edition.label}")
    pdf.set_author(PUBLISHER)
    pdf.set_auto_page_break(auto=True, margin=18)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 24)
    pdf.cell(0, 30, RULEBOOK_TITLE, new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 14)
    for line in (
        PUBLISHER,
        f"Edition {edition.label}",
        f"Effective {edition.effective_date.strftime('%d %B %Y')}",
    ):
        pdf.cell(0, 9, line, new_x="LMARGIN", new_y="NEXT")

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "Table of Contents", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    for clause in clauses:
        indent = 4 * (clause.depth - 1)
        pdf.set_x(pdf.l_margin + indent)
        pdf.cell(150 - indent, 5, f"{clause.number} {clause.title}")
        pdf.cell(0, 5, str(pages.get(clause.number, 0)), align="R", new_x="LMARGIN", new_y="NEXT")

    found: dict[str, int] = {}
    pdf.add_page()
    for clause in clauses:
        if pdf.will_page_break(30):
            pdf.add_page()
        found[clause.number] = pdf.page_no()
        pdf.set_font("Helvetica", "B", 13 - clause.depth)
        pdf.cell(0, 8, f"{clause.number} {clause.title}", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 10)
        for paragraph in clause.text.split("\n\n"):
            pdf.multi_cell(0, 5, paragraph, new_x="LMARGIN", new_y="NEXT")
            pdf.ln(1)
        pdf.ln(2)
    return bytes(pdf.output()), found


def _render_markdown(
    edition: EditionSpec, clauses: tuple[ClauseSource, ...], pages: dict[str, int]
) -> tuple[str, tuple[ClauseTruth, ...]]:
    """Render the Markdown and record where each clause body sits in it."""
    lines = [
        f"# {RULEBOOK_TITLE}",
        "",
        f"Publisher: {PUBLISHER}",
        f"Edition: {edition.label}",
        f"Effective date: {edition.effective_date.isoformat()}",
        "",
        "## Table of Contents",
        "",
    ]
    lines += [
        f"{'  ' * (clause.depth - 1)}- {clause.number} {clause.title} ... {pages[clause.number]}"
        for clause in clauses
    ]
    lines.append("")
    text = "\n".join(lines) + "\n"
    truths = []
    for clause in clauses:
        text += f"{'#' * (clause.depth + 1)} {clause.number} {clause.title}\n\n"
        start = len(text)
        text += clause.text
        truths.append(
            ClauseTruth(
                number=clause.number,
                title=clause.title,
                depth=clause.depth,
                page=pages[clause.number],
                text=clause.text,
                md_char_start=start,
                md_char_end=len(text),
            )
        )
        text += "\n\n"
    return text, tuple(truths)


def write_edition(edition: EditionSpec, root: Path, seed: int) -> EditionTruth:
    """Write one edition (PDF, Markdown and ``edition.yaml``) under ``root``.

    Files land in ``<root>/regulatory_repo/<edition label>/``, the layout of a regulatory
    repository where a reviewed pull request adds one directory per edition.

    :param edition: Which edition to write
    :param root: Dataset root; directories are created as needed
    :param seed: Seed for the long clause
    :return: Ground truth for the written edition, with paths relative to ``root``
    """
    clauses = build_clauses(edition, seed)
    relative = Path("regulatory_repo") / edition.label
    directory = root / relative
    directory.mkdir(parents=True, exist_ok=True)
    # Two passes: the table of contents has a fixed length, so page numbers found in the
    # first pass are valid for the second.
    _, first_pass = _render_pdf(edition, clauses, {})
    pdf_bytes, pages = _render_pdf(edition, clauses, first_pass)
    markdown, truths = _render_markdown(edition, clauses, pages)

    pdf_path = directory / f"{RULEBOOK_STEM}.pdf"
    md_path = directory / f"{RULEBOOK_STEM}.md"
    pdf_path.write_bytes(pdf_bytes)
    md_path.write_text(markdown, encoding="utf-8", newline="\n")
    (directory / "edition.yaml").write_text(
        yaml.safe_dump(
            {
                "edition": edition.label,
                "effective_date": edition.effective_date.isoformat(),
                "merged": True,
                "domain": "payments",
            },
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    return EditionTruth(
        label=edition.label,
        effective_date=edition.effective_date,
        superseded_from=edition.superseded_from,
        markdown_path=(relative / md_path.name).as_posix(),
        pdf_path=(relative / pdf_path.name).as_posix(),
        toc_clause_count=len(clauses),
        clauses=truths,
    )
