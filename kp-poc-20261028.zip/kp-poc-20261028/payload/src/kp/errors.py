"""Typed exception hierarchy shared by every lane.

Every error raised on purpose by ``kp`` derives from :class:`KpError`. Catch the narrowest
type that has a recovery strategy; otherwise let it propagate.
"""

from __future__ import annotations


class KpError(Exception):
    """Base class of every deliberate ``kp`` error."""


class ConfigurationError(KpError):
    """Settings are missing, malformed or inconsistent with the selected mode."""


class InvalidClauseRefError(KpError, ValueError):
    """A clause reference or clause number could not be parsed."""


class SourceError(KpError):
    """Base class of failures while talking to a content source."""


class SourceUnavailableError(SourceError):
    """The source could not be reached or answered with a server-side failure."""


class SourceRateLimitedError(SourceError):
    """The source asked the caller to slow down.

    :param retry_after_seconds: How long the source asked the caller to wait.
    """

    def __init__(self, retry_after_seconds: float) -> None:
        super().__init__("Source rate limit reached")
        self.retry_after_seconds = retry_after_seconds


class SourceAuthRefusedError(SourceError):
    """The source or gateway refused the credential even after one forced renewal."""


class SourceItemNotFoundError(SourceError):
    """The requested item version does not exist in the source."""


class AccessForbiddenError(KpError):
    """The caller's identity grants no access to the requested domain.

    Distinct from an empty result: a refusal must never look like "nothing found".
    """


class TemplateNotFoundError(KpError):
    """No governed template exists for the requested spec type. There is no fallback."""


class WriteNotPermittedError(KpError):
    """A write targeted a repository, path or field outside the server-side allow-list."""


class PublicationBlockedError(KpError):
    """A blocking publication check failed, so the previous knowledge version keeps serving."""
