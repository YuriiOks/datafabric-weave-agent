"""The ``publish`` command, run against a database file."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

import pytest

from kp.domain import SourceKind
from kp.publish import KnowledgeVersionStore
from kp.publish.cli import add_parser
from kp.store import Database, create_engine_for_url
from links.seed import insert_passage, insert_run, insert_source_item


@pytest.fixture
def database_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """An empty SQLite file selected through the environment."""
    path = tmp_path / "kp.db"
    url = f"sqlite+pysqlite:///{path}"
    monkeypatch.setenv("KP_DATABASE_URL", url)
    monkeypatch.setenv("KP_MODE", "local")
    database = Database(create_engine_for_url(url))
    database.create_all()
    database.dispose()
    return path


def _add_orphan_passage(path: Path) -> None:
    database = Database(create_engine_for_url(f"sqlite+pysqlite:///{path}"))
    with database.transaction() as connection:
        insert_run(connection)
        insert_passage(connection, "p-orphan", "no-such-item")
    database.dispose()


def _add_sourced_passage(path: Path) -> None:
    database = Database(create_engine_for_url(f"sqlite+pysqlite:///{path}"))
    with database.transaction() as connection:
        insert_run(connection)
        insert_source_item(connection, SourceKind.REGULATORY_REPO, "item-1")
        insert_passage(connection, "p-1", "item-1")
    database.dispose()


def _run(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))
    args = parser.parse_args(argv)
    return int(args.handler(args))


def test_us15_publish_publishes_when_the_checks_pass(
    database_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _add_sourced_passage(database_file)

    status = _run(["publish"])

    output = capsys.readouterr().out
    assert status == 0
    assert output.startswith("Published knowledge version kv-")
    assert "blocking PASS  model_conformance" in output
    assert "warning  PASS  items_without_links" in output
    assert "report   PASS  stories_without_requirement_or_clause" in output


@pytest.mark.usefixtures("database_file")
def test_us15_publish_blocks_an_empty_database(capsys: pytest.CaptureFixture[str]) -> None:
    status = _run(["publish"])

    output = capsys.readouterr().out
    assert status == 1
    assert "blocking FAIL  has_items" in output
    assert "Still serving: none." in output


def test_us15_publish_exits_1_and_keeps_the_failed_run_when_a_check_blocks(
    database_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _add_orphan_passage(database_file)

    status = _run(["publish", "--run-id", "build-7"])

    output = capsys.readouterr().out
    assert status == 1
    assert "Not published" in output
    assert "kept for inspection. Still serving: none." in output
    assert "blocking FAIL  items_have_source" in output
    database = Database(create_engine_for_url(f"sqlite+pysqlite:///{database_file}"))
    with database.transaction() as connection:
        (kept,) = KnowledgeVersionStore(connection).all()
    database.dispose()
    assert kept.run_id == "build-7"
    assert kept.state.value == "failed_kept"


def test_us15_publish_dry_run_writes_nothing(
    database_file: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _add_orphan_passage(database_file)

    status = _run(["publish", "--dry-run", "--json"])

    checks = json.loads(capsys.readouterr().out)
    assert status == 1
    assert {c["name"]: c["passed"] for c in checks}["items_have_source"] is False
    database = Database(create_engine_for_url(f"sqlite+pysqlite:///{database_file}"))
    with database.transaction() as connection:
        assert KnowledgeVersionStore(connection).all() == []
    database.dispose()


def test_us15_publish_writes_json(database_file: Path, capsys: pytest.CaptureFixture[str]) -> None:
    _add_sourced_passage(database_file)

    status = _run(["publish", "--json"])

    document = json.loads(capsys.readouterr().out)
    assert status == 0
    assert document["published"] is True
    assert document["version"]["state"] == "published"
    assert document["serving"]["version_id"] == document["version"]["version_id"]
