# km-read base

Goal: record how BASE_REPO works today, as labelled facts with sources, so that S1 (status
table) and S2 (risk register) can be written and S3 to S6 have a factual base.
Input: BASE_REPO, read only. Output: /home/user/km/kb/base/. Do not run, build or test it.
Docs and comments are Reported; code decides.

## Pick the mode
- Gap mode when /home/user/km/kb/private/claims.md exists. An earlier full read of this repo is
  summarised there as claims. Do not re-read what it covers.
- Full mode when it is absent. Map the whole repo by slices.

Every file below ends with Weak points seen (path:line, one line each; /km-risks reads them)
and then Open questions. A file with Status rows gives one row per S1 component, as
`| component | level | evidence path:line | label |`, level = working, partial or missing.
The S1 components: relational store, ontology, object storage, search, graph, tool server,
catalogue versions, deployment. A missing component gets the paths searched as evidence.

## Output files, their headings, and the Status rows they carry
- data-model.md. Entities and keys; Domains, sub-domains, projects, sources; Owners and admin
  definition (mechanism only); Versions and history; Migrations.
  Status rows: relational store, catalogue versions.
- access-and-roles.md. Identity into the service; Roles as coded; Check per route group
  (table); Sessions. No Status rows.
- storage.md. Backends; Bucket and key layout; Naming rules; Versioning; Who reads and writes;
  Distance from a path by domain, sub-domain, namespace, product. Status rows: object storage.
- search-and-ai.md. Path from question to answer; Stores queried; Models called; Filters by
  domain or user; Citations. Status rows: search.
- ontology.md. Upload and formats; Validation; Storage and versions; Refresh job (trigger,
  steps, status store); Every failure path; Status values and what sets them; Viewer.
  Status rows: ontology.
- graph.md. Graph sources and routing; Query path and guards; Swap and refresh; Isolation;
  Caps and limits. Status rows: graph.
- api-surface.md. Route groups (prefix, purpose, sign-in needed); Tool server (tools, read or
  write); Background jobs. Status rows: tool server.
- frontend.md. Screens and routes; Role handling per screen; API calls; State and mocked data.
- deployment.md. Image and build; Manifests; Config names (names only); Services needed;
  Developer start steps (not run); Scale assumptions. Status rows: deployment.
- tests.md. Test folders; What each covers; How run (not run); Not covered; Last commit date and
  branches. km-reader has no shell: before this slice the main session runs
  `git -C <clone> log -1 --format=%cs` and `git -C <clone> branch -a` and pastes the output
  into the reader task Inputs line.
- docs-vs-code.md. Table: document, claim, what code or kb shows, label. For the large design
  documents in the repo.

## Full mode
Slices: config and readme first, then one or more slices per file above (backend by module,
then frontend, deployment, tests). docs-vs-code.md last: its inputs are the design documents
and the kb/base files already written. A topic over the size limit continues in <name>-2.md.
Batches of 3: data-model, storage, search-and-ai; ontology, graph, access-and-roles;
api-surface, frontend, deployment; tests, docs-vs-code. At most 16 reader calls.

## Gap mode
1. Read the "Not read yet" section at the end of /home/user/km/kb/private/claims-2.md
   (claims.md has none). If there is none, treat frontend, tests, deployment, api-surface,
   the context PDFs and the design folder as the gap.
2. Cover only those items, one slice per item group:
   - frontend screens and role handling: frontend.md;
   - tests: tests.md;
   - remaining backend files: api-surface.md, then backend-more-<n>.md (default reader headings);
   - deployment files: deployment.md;
   - the PDFs in the context folder: one file per PDF, context-<n>.md. Headings: Summary;
     Facts by page; Decisions stated; Open questions. The reader uses the Read tool with page
     ranges of at most 20 pages; one reader per PDF or per 40 pages;
   - the design folder: design-folder.md.
3. The other files (data-model, access-and-roles, storage, search-and-ai, ontology, graph,
   docs-vs-code) restate what is already known, short, and only after /km-verify has confirmed
   it. Find the verifier output through the kb/index.d/ entries of a km-verify run. None listed:
   do not write them, tell the owner "run /km-verify all first". Otherwise one km-reader per
   file, inputs = the verifier output and the Confirmed and Narrowed claims, no code reading,
   Observed only with the verifier's path:line; Status rows come from those claims.
4. Budget: at most 30 reader calls, in this order: frontend, tests, api-surface and
   backend-more, deployment, design-folder, the PDFs (one per PDF), then the restated files.
   Stop at the budget and list what is left in the log and the summary.

## Done when
- Each planned file exists with Date, Task, Status and labelled lines.
- Each S1 component has a Status row in some file, or the log says why not.
- Every statement about a failure cause names path:line.
- Run record and kb-lint.sh PASS as in the method; summary printed.

## Stop
- Code for a topic is absent: write "missing" and the searches run, do not guess.
- A reader returns partial twice for one topic: leave the rest in Open questions.
