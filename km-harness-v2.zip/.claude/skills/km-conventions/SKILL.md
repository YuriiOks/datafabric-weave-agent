---
name: km-conventions
description: Use before the first plan or build to record how the code is written. Argument a layer (backend, frontend, data, infra, ai) or all; add capture to cover CAPTURE_REPO.
argument-hint: backend|frontend|data|infra|ai|all [capture]
disable-model-invocation: true
---

# km-conventions

Goal: builders and reviewers get the repo's own rules from the kb, not from this harness.
Output: kb/conventions/layers.md and one kb/conventions/<layer>.md per layer. Facts come from
the code and the repo's own config and docs. Nothing in the harness states them.

Arguments: $0 is a layer name or all, else print "usage: /km-conventions <layer>|all [capture]"
and stop. $1 is capture or empty. Empty = BASE_REPO, files in kb/conventions/. capture =
CAPTURE_REPO, files in kb/conventions/capture/. Run id: km-conventions-$0-<date>.

## 1 Layer map: kb/conventions/layers.md
- If it exists, read it and go to step 2. If it does not, run one km-reader on the whole clone
  (a whole-tree search: nothing else runs beside it). Task in canon form: goal, map which
  folders and files of the clone belong to which layer; inputs, the clone path; output,
  layers.md with the headings below; skip, env and credential files, vendored or generated
  folders, lock files; reply as the reader agent says.
- Headings: Layers (table: Layer | Paths | Evidence), Shared (paths several layers touch, and
  which layer owns each), Risky areas (paths for access control, migrations, data deletion,
  model calls), Not code (docs, generated, vendored), Open questions. A layer the clone does
  not have gets the path "none"; it gets no layer file.
- Layers: backend (routes, services), frontend (UI, client calls), data (schema, migrations,
  queries), infra (containers, pipeline, deploy configuration), ai (prompts, retrieval, model
  calls, tool definitions). Evidence is a path:line or a config file that shows the folder's role.
- Read the file yourself. A path in two layers, or in none that holds code: fix the table or
  list it under Open questions. Builders get disjoint paths from this table.

## 2 Layer files: kb/conventions/<layer>.md
- Layers to do: $0, or every layer whose paths in layers.md are not none. Skip a layer whose
  file exists and say so. At most 3 km-reader at once, one layer each, separate slices.
- Task for each reader, in canon form. Goal: write what a builder of this layer must know to
  change the code the way the repo does. Inputs: the clone path; the layer's paths from
  layers.md pasted in the task; the repo's root and layer-folder docs and config (readme,
  contributing, lint, type check, test, build, pipeline and container files). Output: the
  layer file with the headings below. Skip: env, key and credential files. Reply: as the
  reader agent says.
- Headings for every layer: Folders (path, purpose), Commands, Running checks in a fresh work
  tree, Patterns, Errors and logging, Configuration, Access checks, Repo docs demand, Open
  questions.
- Commands: the exact lint, type check and test commands, as found in the repo's own config,
  with the working directory, the way to run one file or one named test, services or
  environment they need, and the config line they come from. A command not found is written
  as "not found", never guessed. The reader does not run anything.
- Running checks in a fresh work tree (required): a git work tree holds tracked files only, no
  installed dependencies, no build output, no env files, and installs need approval. Write the
  dependencies the commands need, the services they need, the env variable names (never
  values), and how the checks run without installing, for example the clone's existing virtual
  environment or node_modules reached by absolute path (found by listing the clone, not by
  running anything). If none of this works, write "needs install" and what to install.
- Patterns: naming and structure, each with a path:line example of the real thing.
- Layer headings added after Repo docs demand: backend: routes and services layout, input
  validation, how an access check is attached to a route. frontend: components, state, the
  API client, loading and error states, accessibility. data: schema and migration tooling,
  how a migration is reversed, naming, indexes, deletion. infra: containers, pipeline and
  deploy files, which settings reach a shared environment. ai: prompts, retrieval, model
  calls, tool definitions, where evaluation cases live, cost and latency settings.
- Reader replies carry file lists only. Read each file written; do not read the sources.

## 3 Finish
- Write kb/index.d/<run>.txt and kb/log.d/<run>.txt. Run
  `bash /home/user/km/.claude/bin/kb-lint.sh`; on FAIL fix the named file.
- Print at most 10 lines: files written, per layer the lint, type and test commands in one
  line each (or "not found"), layers marked "needs install", the Open questions that block a
  build.
- A missing clone path, or a reader that finds no code: log it, tell the owner in two lines, stop.
