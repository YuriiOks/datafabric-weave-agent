"""Seam: the source readers of the real route, built from the gateway adapters.

In real mode the wiki, the ticket tracker and the code host are read through the agent platform
gateway. The connectivity harness already proved the three adapters that do it, so this module
only wires them to the settings and hands them to the reader factory
(:class:`kp.sources.factory.RealReaderBuilder`), which makes real mode a configuration switch.

The adapters read the sample items of the connectivity job: the current version of each
configured item, without change tracking. A full change feed per source needs the tool shapes
that the first live ``kp connectivity discover`` run confirms; until then a real-mode sweep reads
exactly the items named in the sample file (``KP_SAMPLE_ITEMS_FILE``) and says so in the log.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Mapping
from functools import partial

import httpx
from pydantic import SecretStr

from kp.clock import Clock
from kp.config import Settings
from kp.connectivity.adapters import (
    ConfluenceAdapter,
    GatewayToolAdapter,
    GitHubAdapter,
    JiraAdapter,
)
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.models import Route
from kp.connectivity.samples import default_sample_items_path, load_sample_items
from kp.connectivity.tokens import ClientCredentialsTokenProvider
from kp.connectivity.wiring import namespaces_for, required_secret, required_setting
from kp.domain import SourceKind
from kp.sources.base import SourceReader

logger = logging.getLogger(__name__)

_HTTP_TIMEOUT_SECONDS = 60.0
_GATEWAY_SOURCES: tuple[SourceKind, ...] = (
    SourceKind.CONFLUENCE,
    SourceKind.JIRA,
    SourceKind.GITHUB,
)


class RealRoute:
    """The gateway client and the readers built on it. Built on first use.

    :param settings: Platform settings (real mode)
    :param clock: Time source for token lifetimes
    :param http: The HTTP client to use; one is created when omitted, and then closed by
        :meth:`close` (tests pass a client over a mock transport)
    :param sleep: Used to wait out a rate limit
    """

    def __init__(
        self,
        settings: Settings,
        clock: Clock,
        *,
        http: httpx.Client | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._settings = settings
        self._clock = clock
        self._sleep = sleep
        self._http = http
        self._owns_http = http is None
        self._readers: dict[SourceKind, SourceReader] = {}

    def reader(self, kind: SourceKind) -> SourceReader:
        """Return the gateway-backed reader of one source.

        :param kind: Confluence, Jira or GitHub
        :return: The reader; the same one on every call
        :raises kp.errors.ConfigurationError: If a gateway setting, namespace or source token
            is missing
        """
        if kind not in self._readers:
            self._readers = self._build()
        return self._readers[kind]

    def close(self) -> None:
        """Release the HTTP client when this object created it."""
        if self._owns_http and self._http is not None:
            self._http.close()
            self._http = None

    def _build(self) -> dict[SourceKind, SourceReader]:
        settings = self._settings
        if self._http is None:
            self._http = httpx.Client(timeout=_HTTP_TIMEOUT_SECONDS)
        tokens = ClientCredentialsTokenProvider(
            http=self._http,
            token_url=required_setting("KP_GATEWAY_TOKEN_URL", settings.gateway_token_url),
            client_id=required_setting("KP_GATEWAY_CLIENT_ID", settings.gateway_client_id),
            client_secret=required_secret(
                "KP_GATEWAY_CLIENT_SECRET", settings.gateway_client_secret
            ),
            clock=self._clock,
            refresh_fraction=settings.token_refresh_fraction,
        )
        credentials: dict[SourceKind, SecretStr] = {
            SourceKind.CONFLUENCE: required_secret(
                "KP_SOURCE_TOKEN_CONFLUENCE", settings.source_token_confluence
            ),
            SourceKind.JIRA: required_secret("KP_SOURCE_TOKEN_JIRA", settings.source_token_jira),
            SourceKind.GITHUB: required_secret(
                "KP_SOURCE_TOKEN_GITHUB", settings.source_token_github
            ),
        }
        client = GatewayClient(
            http=self._http,
            base_url=required_setting("KP_GATEWAY_BASE_URL", settings.gateway_base_url),
            tokens=tokens,
            identity_header=required_setting(
                "KP_GATEWAY_TOKEN_HEADER", settings.gateway_token_header
            ),
            source_header=required_setting("KP_SOURCE_TOKEN_HEADER", settings.source_token_header),
            source_credentials=credentials,
            clock=self._clock,
            use_case_id=settings.use_case_id,
            sleep=self._sleep,
        )
        samples = load_sample_items(settings.sample_items_file or default_sample_items_path())
        routes = {
            kind: Route(namespace=name, source=kind)
            for kind, name in namespaces_for(settings).items()
        }
        adapters: dict[SourceKind, GatewayToolAdapter] = {
            SourceKind.CONFLUENCE: ConfluenceAdapter(
                client, routes[SourceKind.CONFLUENCE], samples.for_source(SourceKind.CONFLUENCE)
            ),
            SourceKind.JIRA: JiraAdapter(
                client, routes[SourceKind.JIRA], samples.for_source(SourceKind.JIRA)
            ),
            SourceKind.GITHUB: GitHubAdapter(
                client, routes[SourceKind.GITHUB], samples.for_source(SourceKind.GITHUB)
            ),
        }
        logger.warning(
            "Real-route readers cover the configured sample items only, without change tracking"
        )
        return dict(adapters)


def real_reader_builders(
    route: RealRoute,
) -> Mapping[SourceKind, Callable[[Settings], SourceReader]]:
    """Make the builders the reader factory consults in real mode.

    :param route: The shared gateway route
    :return: One builder per gateway-only source
    """
    return {kind: partial(_reader_of, route, kind) for kind in _GATEWAY_SOURCES}


def _reader_of(route: RealRoute, kind: SourceKind, _settings: Settings) -> SourceReader:
    return route.reader(kind)
