"""Text of the committed spec file, the commit message and the pull request description."""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import date

from pydantic import JsonValue

from kp.writeback.citations import CitationReport, Problem
from kp.writeback.limits import spec_id_for_story
from kp.writeback.template import split_front_matter

MACHINE_AUTHOR_NAME = "Spec drafter (machine-authored)"
MACHINE_AUTHOR_EMAIL = "spec-drafter@machine.invalid"
MACHINE_TRAILER = "Machine-Authored: true"

_MAX_TITLE = 120
_MAX_STATEMENT = 160
_MAX_OPEN_ITEM = 400
_MAX_OPEN_ITEMS_SHOWN = 30
_MAX_COVERAGE_VALUE = 500
_MAX_FLAGGED_SHOWN = 100
MAX_BODY_CHARS = 60_000
_TRUNCATION_NOTE = "\n\n(The description was shortened to fit the size limit.)\n"
_MARKDOWN_ACTIVE = str.maketrans(
    {"@": "&#64;", "`": "\\`", "|": "\\|", "[": "\\[", "]": "\\]", "<": "&lt;", ">": "&gt;"}
)


def render_spec_file(
    markdown: str, *, story_key: str, template_id: str, template_version: str
) -> str:
    """Build the file committed to the spec path.

    A front matter block names the story, the spec and the template, and marks the file
    machine-authored, so loading it back as knowledge does not trigger a new draft. Front matter
    the agent supplied is replaced.

    :param markdown: The drafted spec
    :param story_key: The story it belongs to
    :param template_id: The governed template used
    :param template_version: The template version used
    :return: The file content, ending in a newline
    """
    body = split_front_matter(markdown)[1].strip("\n")
    header = (
        f"---\nstory: {story_key}\nspec: {spec_id_for_story(story_key)}\n"
        f"template: {template_id}@{template_version}\nmachine_authored: true\n---\n"
    )
    return f"{header}{body}\n"


def spec_title(markdown: str, story_key: str) -> str:
    """Pick the pull request title: the spec's first heading, tagged with the story key.

    :param markdown: The drafted spec
    :param story_key: The story it belongs to
    :return: ``[KEY] heading``, or ``[KEY] Draft spec`` when there is no heading
    """
    for line in split_front_matter(markdown)[1].splitlines():
        if line.startswith("# ") and line[2:].strip():
            return f"[{story_key}] {line[2:].strip()}"[:_MAX_TITLE]
    return f"[{story_key}] Draft spec"


def commit_message(*, story_key: str, template_id: str, template_version: str) -> str:
    """Build the commit message, marked machine-authored by a trailer.

    :param story_key: The story the spec belongs to
    :param template_id: The governed template used
    :param template_version: The template version used
    :return: The message
    """
    return (
        f"Draft spec for {story_key}\n\n"
        f"Template: {template_id}@{template_version}\n{MACHINE_TRAILER}\n"
    )


def _cell(text: str, limit: int = _MAX_STATEMENT) -> str:
    """Flatten, shorten and neutralise agent text: no mentions, links, tags or table breaks."""
    flat = " ".join(text.split())
    shortened = flat if len(flat) <= limit else f"{flat[: limit - 3]}..."
    return shortened.translate(_MARKDOWN_ACTIVE)


def _reason(
    problems: tuple[Problem, ...], unresolved: tuple[str, ...], unretrieved: tuple[str, ...]
) -> str:
    parts: list[str] = []
    if Problem.UNCITED in problems:
        parts.append("no citation")
    if Problem.UNRESOLVED in problems:
        parts.append(f"does not resolve: {', '.join(unresolved)}")
    if Problem.NOT_RETRIEVED in problems:
        parts.append(f"not retrieved in this session: {', '.join(unretrieved)}")
    return "; ".join(parts)


def _coverage_lines(coverage: Mapping[str, JsonValue]) -> list[str]:
    if not coverage:
        return ["No coverage information was supplied."]
    lines = []
    for key, value in sorted(coverage.items()):
        text = json.dumps(value, sort_keys=True, ensure_ascii=True)
        if len(text) > _MAX_COVERAGE_VALUE:
            text = f"{text[: _MAX_COVERAGE_VALUE - 3]}..."
        lines.append(f"- {_cell(key)}: `{text.replace('`', chr(39))}`")
    return lines


def render_pr_body(
    *,
    story_key: str,
    path: str,
    template_id: str,
    template_version: str,
    report: CitationReport,
    coverage: Mapping[str, JsonValue],
    open_items: tuple[str, ...],
    withdrawn: Mapping[str, date] | None = None,
) -> str:
    """Build the pull request description.

    :param story_key: The story the spec belongs to
    :param path: Where the spec file lives in the repository
    :param template_id: The governed template used
    :param template_version: The template version used
    :param report: The citation check
    :param coverage: Coverage supplied with the draft
    :param open_items: Open items supplied with the draft
    :param withdrawn: Cited references whose edition is withdrawn, with the withdrawal date. They
        still resolve, so they are not flagged; the reviewer is told since when they are out of use.
    :return: Markdown for the pull request body
    """
    verdict = "meets" if report.meets_target else "is below"
    lines = [
        f"Draft spec for {story_key}, machine-authored. A person reviews and merges it.",
        "",
        "## Spec",
        f"- File: `{path}`",
        f"- Template: `{template_id}` version `{template_version}`",
        "",
        "## Citations",
        f"- Rule statements: {report.rule_statements}",
        f"- Cited and valid: {report.valid_statements}",
        f"- Citation rate: {report.rate:.0%} ({verdict} the {report.target:.0%} target)",
        "- Guessed links appear in the spec text as proposed.",
    ]
    if not report.checks:
        lines.append("- No rule statements were found in the spec.")
    if report.flagged:
        lines += ["", "### Flagged statements", "", "| # | Statement | Problem |", "|---|---|---|"]
        lines += [
            f"| {check.index} | {_cell(check.statement)} | "
            f"{_cell(_reason(check.problems, check.unresolved, check.unretrieved))} |"
            for check in report.flagged[:_MAX_FLAGGED_SHOWN]
        ]
        if len(report.flagged) > _MAX_FLAGGED_SHOWN:
            lines.append(f"\n{len(report.flagged) - _MAX_FLAGGED_SHOWN} more flagged statements.")
    if withdrawn:
        lines += ["", "### Withdrawn material", ""]
        lines += [
            f"- {_cell(reference)} is in an edition withdrawn on {since.isoformat()}; the "
            "citation still resolves."
            for reference, since in sorted(withdrawn.items())
        ]
    lines += ["", "## Coverage", *_coverage_lines(coverage), "", "## Open items"]
    lines += [f"- {_cell(item, _MAX_OPEN_ITEM)}" for item in open_items[:_MAX_OPEN_ITEMS_SHOWN]]
    if len(open_items) > _MAX_OPEN_ITEMS_SHOWN:
        lines.append(f"- {len(open_items) - _MAX_OPEN_ITEMS_SHOWN} more open items not shown.")
    if not open_items:
        lines.append("None.")
    body = "\n".join(lines) + "\n"
    if len(body) > MAX_BODY_CHARS:
        body = body[: MAX_BODY_CHARS - len(_TRUNCATION_NOTE)] + _TRUNCATION_NOTE
    return body
