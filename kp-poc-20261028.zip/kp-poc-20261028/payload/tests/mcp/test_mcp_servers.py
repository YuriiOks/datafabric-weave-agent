"""Read and write are separate servers with separate tool sets."""

from __future__ import annotations

from mcp_fixtures import *  # noqa: F403 - pytest fixtures
from pydantic import JsonValue

from kp.mcp import ErrorCode, McpServer
from kp.tools import build_caller
from kp.tools.testing import InMemoryAudit

CALLER = build_caller(user="user-full-access", agent="spec-agent", session_id="s")


def names(server: McpServer) -> set[str]:
    response = server.handle({"jsonrpc": "2.0", "id": 1, "method": "tools/list"}, CALLER)
    assert response is not None
    result = response["result"]
    assert isinstance(result, dict)
    tools = result["tools"]
    assert isinstance(tools, list)
    return {str(t["name"]) for t in tools if isinstance(t, dict)}


def call(server: McpServer, name: str, arguments: dict[str, JsonValue]) -> dict[str, JsonValue]:
    message: dict[str, JsonValue] = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": name, "arguments": arguments},
    }
    response = server.handle(message, CALLER)
    assert response is not None
    return response


def test_us16_read_and_write_servers_have_disjoint_tool_sets(
    read_server: McpServer, write_server: McpServer
) -> None:
    assert names(read_server) == {"search", "links", "template", "rule_as_at", "coverage"}
    assert names(write_server) == {"publish_spec"}
    assert read_server.name == "kp-read"
    assert write_server.name == "kp-write"


def test_us16_the_read_server_cannot_write(read_server: McpServer) -> None:
    response = call(read_server, "publish_spec", {"spec_id": "s", "path": "specs/s.md"})

    error = response["error"]
    assert isinstance(error, dict)
    assert error["code"] == ErrorCode.INVALID_PARAMS


def test_us16_the_write_server_cannot_read(write_server: McpServer) -> None:
    response = call(write_server, "search", {"query": "currency"})

    error = response["error"]
    assert isinstance(error, dict)
    assert error["code"] == ErrorCode.INVALID_PARAMS


def test_us22_a_write_outside_the_agreed_place_is_refused_through_the_transport(
    write_server: McpServer, audit: InMemoryAudit
) -> None:
    response = call(write_server, "publish_spec", {"spec_id": "s", "path": "other-repo/x.md"})

    error = response["error"]
    assert isinstance(error, dict)
    assert error["code"] == ErrorCode.WRITE_NOT_PERMITTED
    assert error["data"] == {"kind": "write_not_permitted"}
    assert audit.records[0].refused is True


def test_us18_a_write_through_the_transport_is_recorded_with_its_spec(
    write_server: McpServer, audit: InMemoryAudit
) -> None:
    response = call(write_server, "publish_spec", {"spec_id": "spec-3", "path": "specs/spec-3.md"})

    assert "result" in response
    assert audit.records[0].spec_id == "spec-3"
    assert audit.records[0].tool == "publish_spec"
