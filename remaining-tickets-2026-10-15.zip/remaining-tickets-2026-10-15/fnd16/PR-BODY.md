> [!IMPORTANT]
> **This PR does not qualify the release.** It records every committed requirement, the evidence each one needs and what blocks it. No requirement is marked passed, and the matrix has no passing status to mark one with. The integrated, fault, load, evaluation and rehearsal runs need an approved run on the bank CI and runtime. Most of them cannot start until the two source registrations change. Stacked on the pull request that carries the refresh integration (DTAA-1487): its base is that pull request's branch, so retarget this PR to `main` after that merges.

## Problem

Release readiness has no single, checked list of what must be observed before wider enablement. The architecture's nineteen acceptance scenarios, the seven controlled-refresh cases, the delayed-source regression case and the release gates live in prose. Nothing stops a case that never ran from being reported as done, or a parent from completing while evidence is missing.

## Solution

A typed acceptance matrix in a new qualification package:

- **Rows.** One row per requirement, with:
  - the observable result;
  - an owner role;
  - the kind of evidence (an existing test, a CI job, a fault run, a load run, an evaluation report or a manual rehearsal);
  - where that evidence lives when it exists;
  - the gap the cited evidence still leaves.
- **Status without a pass.** A row is planned (no evidence yet), not run (evidence exists, no recorded run) or blocked (named blockers stop it). There is no passing status: a pass is a recorded CI or rehearsal run kept with the release evidence, so an unexecuted case cannot read as passed.
- **Completeness.** The matrix refuses to build when an architecture scenario, a refresh case or a delayed-source extension is missing, when a requirement repeats, or when a row cites an unknown blocker. A test checks that every test file the matrix cites exists.
- **Blockers.** Ten named blockers, each with the decision it needs and an owner role: the source registrations, the export reader in the deployed image, the previous-candidate loader, unmounted reads, owner rules, production authority, unowned numeric limits and unjudged case packs. Every row that needs a validated candidate from a real refresh is blocked by the registrations and the export reader.
- **Delayed source.** The A18 case is recorded with its two extensions: a carried source keeps its original age, and ambiguous ordering is refused, not guessed.
- **Completion.** Parent completion lists one reason per row of the selected delivery. A Markdown renderer produces the matrix for the release evidence and ends by saying that no requirement is marked passed.

Today the matrix holds 35 requirements: 7 planned, 4 not run and 24 blocked. Two of them (per-type quality and the held-out claim) apply only if the recommendation delivery is selected.

Unchanged: no runtime code, route, setting, publication or refresh behaviour. The package is read only by its own test and by whoever renders it.

## How to verify

1. Unit tests: `tests/recsys/qualification/test_acceptance_matrix.py`. CI runs them.
2. Render the matrix with `render_matrix(ACCEPTANCE_MATRIX)`. Every architecture scenario and refresh case appears once, the blocker table shows which rows each blocker stops, and the last line states that no requirement is marked passed.
3. Negative case: give any row the status `passed`. Construction refuses it.

## Not in this PR

- **The runs.** CI, fault, load, evaluation and enablement rehearsal on the approved bank runtime need an explicit go and, for most rows, the registration decisions first.
- **Registration decisions.** Skills ordering, skill-content ownership and the workbook revision belong to the source owners.
- **Numeric limits.** Latency, freshness and capacity limits need named owners before any load run.
- **Covering tests not yet mapped.** A01, A02, A04, A12, A13 and R02 have no test reference yet. Mapping them to the current checkout is the next step, and each stays planned until then.

## Review focus

- Blocking every candidate-dependent row on the export reader as well: is the CI image the same as the deployed one?
- The difference between planned and not run, and whether the four not-run references are the right evidence for their rows.
- Owner roles per row and per blocker.

## CI

- The checks posted on this head are the result.
