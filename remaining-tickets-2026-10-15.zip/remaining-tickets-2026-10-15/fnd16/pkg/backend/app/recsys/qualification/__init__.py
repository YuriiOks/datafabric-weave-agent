"""Release qualification: the acceptance matrix and what still blocks each requirement.

The matrix lists every committed requirement with the evidence it needs, its owner and the
blockers that stop it from running. It records no result: a requirement passes only through
a recorded CI or rehearsal run, never through this package.
"""
