# BPC PR Preview Environments — Design Proposal

**Status:** proposal for team review · **Date:** 2026-08-06 · **Author:** Yurii Oksamytnyi
**Audience:** BPC developers (2 today, 4 next week, more later), product/governance reviewers, platform approvers.
**Companion:** `architecture-improvement-review.md` v3.1 (single-replica constraint §3.5; SEC-001/SEC-002 hygiene).

---

## 1. Why now

- The team is doubling within a week and will keep growing; one shared environment becomes contended immediately.
- Non-developers (product, governance, new joiners) need a **clickable URL** to test a pull request — not a local Docker setup and not screenshots that go stale after the next push.
- Visual/UX review of the React SPA is the main review bottleneck today; per-PR previews turn it into a link in the PR thread.

## 2. What we get

One URL per pull request — `https://pr-<n>.bpc-preview.<internal-domain>` — serving that branch build with its own FalkorDB/PostgreSQL/Redis, a seeded corpus, and read-only viewer mode. Add a label → get the link in a bot comment within ~5 minutes. Close the PR → the environment disappears.

## 3. Target design

**Flow:** label `preview` on a PR → CI builds the backend+SPA image `pr-<n>-<sha>` (digest-pinned bases) → push to Nexus / Artifact Registry → apply templated manifests into namespace `bpc-pr-<n>` (backend, falkordb, postgres, redis — **1 replica each**) → Ingress route `pr-<n>.bpc-preview.<domain>` → bot comment with URL, deployed SHA, and timestamp.

### Lifecycle events

| Event | Action |
| --- | --- |
| Label added | Deploy from scratch; post bot comment with URL + SHA. |
| Push to a labeled PR | Rebuild and rolling-replace; update the bot comment. Concurrency group per PR, cancel-in-progress, deploy the last SHA only. |
| PR closed or merged | Delete the namespace; clean registry tags. |
| Label removed | Delete the namespace. |
| Nightly reaper | Delete every `bpc-pr-*` namespace without a matching open labeled PR; enforce a TTL cap (for example 7 days without pushes) for abandoned-but-open PRs; delete orphaned registry tags. |

### Preview composition

| Container | Memory | Notes |
| --- | --- | --- |
| backend (FastAPI + built SPA) | 512 Mi | single origin, replicas=1, no HPA |
| falkordb | 256 Mi | corpus is ~2.4k nodes — tiny |
| postgres | 256 Mi | `bpc_logs` + app tables, emptyDir |
| redis | 128 Mi | cache/sessions, emptyDir |

~1.2 GiB per preview; ten concurrent previews fit on one small node. Storage is emptyDir — ephemeral by design; a pod restart re-seeds.

### Data seeding — no live embedding run per deploy

A nightly/master CI job runs full ingestion once and stores a **FalkorDB RDB snapshot + Postgres dump as artifacts**. A preview boots from the snapshot, then diff-ingests only the cards changed in the branch (a few Gateway calls or zero). Fallback when the snapshot is missing or incompatible: full ingest — needs Gateway credentials, takes minutes, costs tokens, and must be flagged in the bot comment.

### Auth model

`READ_ONLY_MODE=true`: anonymous viewer, no per-host DSP SSO registration needed, all mutations return 403. Admin analytics stay reachable behind `ADMIN_PASSCODE` (**VERIFY** that the passcode gate works in read-only mode).

## 4. Pitfalls — what can hurt us

### Group A — approvals that can kill or stall the whole thing

1. **Wildcard DNS + wildcard TLS — the big one.** We need `*.bpc-preview.<domain>` DNS plus a wildcard certificate. If security only issues per-host certificates, ephemerality dies (a cert request per PR takes days). Ask network/security **first**; everything else can proceed in parallel. Fallbacks if denied: a fixed pool of pre-certified hosts (`preview-1..preview-8.<domain>` assigned to PRs), or path-based routing — which has real costs, see B4.
2. **CI → cluster deploy rights.** The Actions runner needs a network path and an identity for the GKE API. Bank clusters often mandate deployment through an approved CD tool, not kubectl-from-CI — that can force re-platforming the deploy step. Verify early.
3. **Dynamic namespace creation may be denied by cluster policy** (OPA/Gatekeeper). Fallback: a pre-provisioned namespace pool `bpc-pr-slot-{1..N}` that PRs borrow and return.
4. **Registry constraints.** Push credentials, storage quota, retention policy for ephemeral `pr-*` tags, and mandatory image scanning that can add minutes per deploy or block unscanned images outright.
5. **GAIP credentials in preview namespaces.** A secret copy in every namespace plus cost-cap questions. Snapshot seeding minimizes the need; decide explicitly whether live search in previews gets a shared low-quota key or a stub.
6. **Data classification.** The corpus and admin analytics become visible on an intranet URL reachable bank-wide. Read-only internal data is likely fine — but get the sign-off in writing once, before the first URL circulates.

### Group B — technical traps

1. **Read-only mode blocks the seeding API.** `POST /api/ingest/run` is a mutation → 403 under `READ_ONLY_MODE`. Seed at container start (the `run.py --load` path, before serving) or via a one-shot init job — never rely on the API for boot seeding.
2. **Single replica only.** The async search job registry and admission counters are per-process (review §3.5): more than one replica breaks job polling with owner-scoped 404s that look like data loss. Pin `replicas: 1`, no HPA in preview manifests.
3. **Ingress provisioning latency.** A fresh load-balancer Ingress per PR can take 5–15 minutes to become routable — it silently kills the preview-in-minutes promise. Use one shared ingress/gateway with host-based routing for all `pr-*` hosts, or an in-cluster ingress controller. Target: apply → routable in under a minute.
4. **Path-based routing fallback is worse than it looks.** `bpc_session` / `bpc_visitor` cookies collide between PRs on one host; the Vite asset base path and SPA router basename must become configurable. Subdomains avoid all three problems — this is the technical argument for the wildcard ask in A1.
5. **Embedding-space mismatch.** If a branch changes the embedding model or dimensions, the master snapshot is unusable (mixed vector spaces). The deploy job must compare embedding config against the snapshot manifest and fall back to full ingest — or refuse with a clear bot comment. Never boot a preview on mismatched vectors.
6. **Secrets multiplication.** Generate a per-namespace `POSTGRES_PASSWORD` — never reuse the compose default (SEC-001). The auto-generated session secret is acceptable in previews (sessions dying on restart is fine there).
7. **Stale-preview confusion for non-developers.** A reviewer opens the link right after a push and sees the old build mid-redeploy. The bot comment must show deployed SHA + time + status, and the app should expose the build SHA (health endpoint or footer) so the question of which version am I looking at is answerable.
8. **Telemetry pollution.** Preview `bpc_logs` live in the preview Postgres (isolated — good), but set `APP_ENV=preview` anyway so preview analytics can never be mistaken for real usage, now or after any future log centralization.
9. **Reaper edge cases.** Missed close events (failed workflow run) orphan namespaces. The reaper must reconcile actual cluster state against open labeled PRs on a schedule — not only react to events — and also clean registry tags.
10. **Racing deploys.** Two rapid pushes race each other: concurrency group per PR with cancel-in-progress; deploy only the latest SHA.
11. **Fork PRs get no secrets.** Internal repo, likely no forks — but keep the label as the human approval gate for deploys regardless.

### Group C — scope limits (what a preview cannot prove)

- DSP SSO login flows (previews are anonymous read-only).
- Role-gated mutations and admin write paths (403 by design).
- Multi-replica behavior, HPA, scale characteristics.
- Real Gateway latency and cost, unless a preview key is provisioned.
- Production-scale data volumes.

Put this list into the PR template so a non-developer knows exactly what tested-on-preview does and does not mean.

## 5. Approvals checklist — start these first, they own the calendar

| Ask | Owner | Blocks |
| --- | --- | --- |
| Wildcard DNS + TLS for `*.bpc-preview.<domain>` | Network / Security | subdomain routing (A1) |
| CI deploy identity to the cluster, or the approved CD path | Platform / cluster admin | any automated deploy (A2) |
| Namespace policy: dynamic creation or a slot pool | Cluster admin | per-PR isolation (A3) |
| Registry credentials + retention for `pr-*` tags | Nexus / AR owner | image push (A4) |
| GAIP key for previews + cost cap (optional with snapshots) | Gateway owner | live search in previews (A5) |
| Data-classification sign-off for intranet previews | Data owner | first shared URL (A6) |

## 6. Rollout

| Phase | Content | Exit |
| --- | --- | --- |
| 0 — build in parallel with approvals | Templated manifests; workflow behind a repo variable; test against one manually created namespace | Deploy + teardown proven by hand |
| 1 — interim single slot | One fixed host `bpc-preview.<domain>` while the wildcard ask pends; same workflow; label as mutex | Non-devs click a link for the first time |
| 2 — per-PR | Wildcard live: `bpc-pr-<n>` namespaces, subdomains, reaper, bot comments | Label → URL in ≤5 min; close → gone in ≤10 min |
| 3 — polish | Snapshot seeding pipeline, build-SHA surfacing, preview scope note in the PR template | Zero orphans after a week of use |

**Acceptance:** a non-developer can open the URL with zero setup and click through search, playbooks, and insights; the bot comment always shows which SHA is live; the reaper leaves no orphans.

## 7. Cost and effort

- Runtime: ~1.2 GiB RAM and under 1 CPU per preview; ten concurrent previews ≈ one small node.
- Registry: one image per PR with a 7-day retention.
- Gateway: near zero with snapshot seeding (diff-only embedding calls).
- Engineering: **3–5 days of code** (workflow, manifest templates, reaper, bot comments, snapshot job). The calendar is owned by Group A approvals — start those asks immediately.

## 8. Relation to the architecture review

Delivery-infrastructure follow-on (Outcome C neighborhood). It changes no search behavior, so eval gates are unaffected. The single-replica constraint is a direct consequence of review §3.5; SCALE-001 removes it later, at which point previews may lift replicas: 1.
