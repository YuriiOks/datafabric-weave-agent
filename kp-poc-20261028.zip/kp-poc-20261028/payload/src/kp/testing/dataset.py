"""Ground truth that accompanies the synthetic data, so tests can check parsers against it."""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

GROUND_TRUTH_FILE = "ground_truth.json"


class _Truth(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class ClauseTruth(_Truth):
    """One clause as written. ``text`` equals ``markdown[md_char_start:md_char_end]``."""

    number: str
    title: str
    depth: Annotated[int, Field(ge=1)]
    page: Annotated[int, Field(ge=1)]
    text: str
    md_char_start: Annotated[int, Field(ge=0)]
    md_char_end: Annotated[int, Field(ge=0)]


class EditionTruth(_Truth):
    """One generated edition of the fictional rulebook, in both formats."""

    label: str
    effective_date: date
    superseded_from: date | None
    markdown_path: str
    pdf_path: str
    toc_clause_count: int
    clauses: tuple[ClauseTruth, ...]


class RegisterTruth(_Truth):
    """The generated requirements register.

    :ivar header_row: One-based row number of the header row on ``main_sheet``.
    :ivar headerless_sheet: Name of the sheet that has no recognisable header row.
    """

    path: str
    main_sheet: str
    headerless_sheet: str
    header_row: int
    data_row_count: int
    header: tuple[str, ...]


class StoryTruth(_Truth):
    """Which story changes between the two Jira-like exports."""

    first_export: str
    second_export: str
    story_count: int
    status_only_key: str
    criteria_changed_key: str


class ConfluenceTruth(_Truth):
    """Which Confluence-like page is approved, unlabelled, or has a newer draft."""

    approved_page: str
    unlabelled_page: str
    page_with_newer_draft: str


class GroundTruth(_Truth):
    """Everything a test needs to know about a generated dataset."""

    seed: int
    editions: tuple[EditionTruth, ...]
    requirements_register: RegisterTruth
    stories: StoryTruth
    confluence: ConfluenceTruth

    def edition(self, label: str) -> EditionTruth:
        """Return one edition's truth.

        :param label: Edition label, e.g. ``2026.1``
        :return: Its ground truth
        :raises KeyError: If no such edition was generated
        """
        for edition in self.editions:
            if edition.label == label:
                return edition
        raise KeyError(label)


class SyntheticDataset(_Truth):
    """A generated dataset: its root directory and the ground truth."""

    root: Path
    truth: GroundTruth

    def path(self, relative: str) -> Path:
        """Resolve a ground-truth relative path.

        :param relative: A path as stored in the ground truth
        :return: The absolute path under ``root``
        """
        return self.root / relative


def load_dataset(root: Path) -> SyntheticDataset:
    """Load an already generated dataset from ``root``.

    :param root: Directory containing ``ground_truth.json``
    :return: The dataset
    """
    raw = (root / GROUND_TRUTH_FILE).read_text(encoding="utf-8")
    return SyntheticDataset(root=root, truth=GroundTruth.model_validate(json.loads(raw)))
