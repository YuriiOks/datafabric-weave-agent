"""Stand-in retrieval, coverage and session ledger used by the reference client."""

from __future__ import annotations

from datetime import date

import pytest
from sqlalchemy import insert, update

from kp.domain import ItemType, LinkKind, LinkState, Story
from kp.store import Database
from kp.store.schema import link, requirement
from kp.store.schema import story as story_table
from kp.writeback import (
    DatabaseRetriever,
    InMemorySessionRetrievals,
    LinkGraphCoverage,
    StoryNotFoundError,
    load_story,
)
from writeback.writeback_support import NOW, Seeded

TODAY = date(2026, 11, 2)
AFTER_SWITCH = date(2026, 11, 20)


def test_us19_a_story_is_loaded_with_its_links(database: Database, seeded: Seeded) -> None:
    with database.transaction() as connection:
        story = load_story(connection, "PAY-101")

    assert story.summary == "Acknowledge received credit transfers"
    assert [(link.link_type, link.target_key) for link in story.links] == [
        ("implements", "REQ-004")
    ]


def test_us19_an_unknown_story_is_a_typed_error(database: Database, seeded: Seeded) -> None:
    with database.transaction() as connection, pytest.raises(StoryNotFoundError):
        load_story(connection, "PAY-999")


def test_us19_register_rows_named_by_story_links_and_the_rules_they_cite_are_evidence(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        story = load_story(connection, "PAY-101")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert [(item.reference, item.proposed) for item in retrieval.evidence] == [
        ("register-1:Requirements:8", False),
        ("2026.1:4.1.2", False),
    ]
    assert retrieval.evidence[1].text.startswith("A participant shall acknowledge")
    assert retrieval.notes == ()


def test_us19_rules_cited_in_the_story_text_are_evidence(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        story = load_story(connection, "PAY-102")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert [item.reference for item in retrieval.evidence] == ["2026.1:4.2.3"]


def test_us11_an_edition_not_in_force_on_the_date_is_reported(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        story = load_story(connection, "PAY-102")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=TODAY)

    assert retrieval.notes == ("Edition 2026.1 is not yet effective as at 2026-11-02.",)


def test_us21_a_story_that_cites_nothing_gets_proposed_clauses_from_the_edition_in_force(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        story = load_story(connection, "PAY-103")
        after = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)
        before = DatabaseRetriever(connection).retrieve(story, as_at=TODAY)

    assert all(item.proposed for item in after.evidence)
    assert after.evidence[0].reference == "2026.1:4.2.1"
    assert [item.reference for item in before.evidence] == ["2025.2:4.2.1"]


def test_us21_a_story_with_nothing_in_common_gets_no_evidence(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        story = load_story(connection, "PAY-103").model_copy(
            update={"summary": "Colourful dashboards", "description": "", "acceptance_criteria": ""}
        )
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert retrieval.evidence == ()


def test_us12_tests_are_found_up_to_three_steps_through_the_link_store(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        coverage = LinkGraphCoverage(connection)

        assert coverage.tests_for("2026.1:4.1.2") == ("test-a",)
        assert coverage.tests_for("2026.1:4.2.3") == ()


def test_us12_a_closed_link_no_longer_counts(database: Database, seeded: Seeded) -> None:
    with database.transaction() as connection:
        connection.execute(
            update(link).where(link.c.target_key == "code-a").values(valid_to=link.c.valid_from)
        )
        assert LinkGraphCoverage(connection).tests_for("2026.1:4.1.2") == ()


def test_us21_the_session_ledger_normalises_references() -> None:
    ledger = InMemorySessionRetrievals()

    ledger.record("s1", ["2026.1 clause 4.2.1", "register-1:Requirements:8"])

    assert ledger.references("s1", "anyone") == {"2026.1:4.2.1", "register-1:Requirements:8"}
    assert ledger.references("other", "anyone") == frozenset()


def add_story_version(database: Database, version: str) -> None:
    story = Story(story_key="PAY-101", version=version, summary=f"Summary {version}")
    values = story.model_dump()
    values["links"] = []
    values["fingerprint"] = story.fingerprint()
    with database.transaction() as connection:
        connection.execute(insert(story_table).values(**values))


def test_us19_the_latest_story_version_is_chosen_by_number_not_by_text(
    database: Database, seeded: Seeded
) -> None:
    for version in ("v9", "v10"):
        add_story_version(database, version)

    with database.transaction() as connection:
        story = load_story(connection, "PAY-101")

    assert (story.version, story.summary) == ("v10", "Summary v10")


def test_us19_a_value_carried_by_two_register_rows_resolves_to_the_same_row_every_time(
    database: Database, seeded: Seeded
) -> None:
    with database.transaction() as connection:
        connection.execute(
            insert(requirement).values(
                requirement_id="register-1:Requirements:12",
                source="document_library",
                item_id="register-1",
                version="v1",
                sheet="Requirements",
                row_number=12,
                header_confidence=1.0,
                domain="payments",
                fields={"Req ID": "REQ-004", "Title": "A later duplicate"},
            )
        )

    with database.transaction() as connection:
        story = load_story(connection, "PAY-101")
        references = [
            tuple(
                item.reference
                for item in DatabaseRetriever(connection)
                .retrieve(story, as_at=AFTER_SWITCH)
                .evidence
            )
            for _ in range(3)
        ]

    assert references[0] == references[1] == references[2]
    assert references[0][0] == "register-1:Requirements:12"


def add_derived_link(
    database: Database, target_type: ItemType, target_key: str, state: LinkState
) -> None:
    with database.transaction() as connection:
        connection.execute(
            insert(link).values(
                link_id=f"spec-pay-103->{target_key}",
                source_item_type=ItemType.SPEC.value,
                source_key="spec-pay-103",
                relation="derived_from",
                target_item_type=target_type.value,
                target_key=target_key,
                kind=(LinkKind.STATED if state is LinkState.STATED else LinkKind.GUESSED).value,
                state=state.value,
                score=None if state is LinkState.STATED else 0.8,
                evidence="",
                valid_from=NOW,
            )
        )


@pytest.mark.parametrize(
    ("state", "proposed"),
    [(LinkState.STATED, False), (LinkState.PROPOSED, True), (LinkState.REVIEW, True)],
)
def test_us21_evidence_reached_through_a_link_is_proposed_exactly_when_the_link_is_guessed(
    database: Database, seeded: Seeded, state: LinkState, proposed: bool
) -> None:
    add_derived_link(database, ItemType.CLAUSE, "2026.1:4.2.3", state)

    with database.transaction() as connection:
        story = load_story(connection, "PAY-103")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert [(item.reference, item.proposed) for item in retrieval.evidence] == [
        ("2026.1:4.2.3", proposed)
    ]


def test_us21_a_register_row_reached_through_a_guessed_link_brings_its_rules_as_proposed(
    database: Database, seeded: Seeded
) -> None:
    add_derived_link(database, ItemType.REQUIREMENT, "REQ-004", LinkState.PROPOSED)

    with database.transaction() as connection:
        story = load_story(connection, "PAY-103")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert [(item.reference, item.proposed) for item in retrieval.evidence] == [
        ("register-1:Requirements:8", True),
        ("2026.1:4.1.2", True),
    ]


def test_us21_a_dropped_link_adds_no_evidence(database: Database, seeded: Seeded) -> None:
    add_derived_link(database, ItemType.CLAUSE, "2026.1:4.2.3", LinkState.DROPPED)

    with database.transaction() as connection:
        story = load_story(connection, "PAY-103")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert "2026.1:4.2.3" not in [item.reference for item in retrieval.evidence]


def test_us21_a_stated_reference_stays_stated_when_a_guessed_link_names_it_too(
    database: Database, seeded: Seeded
) -> None:
    link_to_cited = ("spec-pay-102", "2026.1:4.2.3")
    with database.transaction() as connection:
        connection.execute(
            insert(link).values(
                link_id="guess",
                source_item_type="spec",
                source_key=link_to_cited[0],
                relation="derived_from",
                target_item_type="clause",
                target_key=link_to_cited[1],
                kind="guessed",
                state="proposed",
                score=0.7,
                evidence="",
                valid_from=NOW,
            )
        )
        story = load_story(connection, "PAY-102")
        retrieval = DatabaseRetriever(connection).retrieve(story, as_at=AFTER_SWITCH)

    assert [(item.reference, item.proposed) for item in retrieval.evidence] == [
        ("2026.1:4.2.3", False)
    ]


def add_coverage_link(
    database: Database,
    link_id: str,
    source: tuple[ItemType, str],
    relation: str,
    target: tuple[ItemType, str],
    state: LinkState,
) -> None:
    with database.transaction() as connection:
        connection.execute(
            insert(link).values(
                link_id=link_id,
                source_item_type=source[0].value,
                source_key=source[1],
                relation=relation,
                target_item_type=target[0].value,
                target_key=target[1],
                kind=(LinkKind.STATED if state is LinkState.STATED else LinkKind.GUESSED).value,
                state=state.value,
                score=None if state is LinkState.STATED else 0.6,
                evidence="",
                valid_from=NOW,
            )
        )


@pytest.mark.parametrize("state", [LinkState.PROPOSED, LinkState.REVIEW, LinkState.DROPPED])
def test_us12_guessed_links_do_not_count_as_test_coverage(
    database: Database, seeded: Seeded, state: LinkState
) -> None:
    add_coverage_link(
        database,
        "guess-spec-code",
        (ItemType.SPEC, "spec-pay-102"),
        "implemented_by",
        (ItemType.CODE, "code-b"),
        state,
    )
    add_coverage_link(
        database,
        "guess-code-test",
        (ItemType.CODE, "code-b"),
        "verified_by",
        (ItemType.TEST, "test-b"),
        state,
    )
    add_coverage_link(
        database,
        "stated-clause-spec",
        (ItemType.SPEC, "spec-pay-102"),
        "derived_from",
        (ItemType.CLAUSE, "2026.1:4.2.3"),
        LinkState.STATED,
    )

    with database.transaction() as connection:
        assert LinkGraphCoverage(connection).tests_for("2026.1:4.2.3") == ()


def test_us12_items_with_the_same_key_but_another_type_are_not_followed(
    database: Database, seeded: Seeded
) -> None:
    add_coverage_link(
        database,
        "other-type",
        (ItemType.CODE, "2026.1:4.1.2"),
        "verified_by",
        (ItemType.TEST, "test-z"),
        LinkState.STATED,
    )

    with database.transaction() as connection:
        assert LinkGraphCoverage(connection).tests_for("2026.1:4.1.2") == ("test-a",)
