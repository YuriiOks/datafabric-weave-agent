"""Every text file of the repository is ASCII only.

Typographic dashes, arrows, quotes, ellipses and non-breaking spaces break the places this code
is typed or copied through. The walk skips what the repository ignores and files that are
binary by design (the generated PDFs and spreadsheets).
"""

from __future__ import annotations

import fnmatch
from collections.abc import Iterator
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALWAYS_SKIPPED_FOLDERS = frozenset({".git", ".venv", "__pycache__"})
BINARY_SUFFIXES = frozenset({".pdf", ".xlsx", ".docx", ".db", ".pyc", ".png", ".zip"})


def _ignored_patterns() -> list[str]:
    lines = (ROOT / ".gitignore").read_text(encoding="utf-8").splitlines()
    return [line.strip() for line in lines if line.strip() and not line.startswith("#")]


def _is_ignored(path: Path, patterns: list[str]) -> bool:
    relative = path.relative_to(ROOT)
    for pattern in patterns:
        bare = pattern.rstrip("/")
        if any(fnmatch.fnmatch(part, bare) for part in relative.parts):
            return True
    return False


def text_files() -> Iterator[Path]:
    """Every file of the tree that git would track and that is not binary by design."""
    patterns = _ignored_patterns()
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or ALWAYS_SKIPPED_FOLDERS & set(path.relative_to(ROOT).parts):
            continue
        if path.suffix in BINARY_SUFFIXES or _is_ignored(path, patterns):
            continue
        yield path


def non_ascii_offences(path: Path) -> list[str]:
    """Describe every non-ASCII character in a file, with its line."""
    shown = path.relative_to(ROOT) if path.is_relative_to(ROOT) else path
    try:
        text = path.read_bytes().decode("utf-8")
    except UnicodeDecodeError:
        return [f"{shown}: not valid UTF-8"]
    return [
        f"{shown}:{number}: U+{ord(char):04X}"
        for number, line in enumerate(text.splitlines(), start=1)
        for char in line
        if ord(char) > 127
    ]


def test_the_walk_finds_the_code_the_docs_and_the_fixtures() -> None:
    names = {path.name for path in text_files()}

    assert {"cli.py", "ARCHITECTURE.md", "ground_truth.json", "pyproject.toml"} <= names
    assert "SPEC.md" not in names  # supplied separately and ignored by git


def test_every_text_file_is_ascii_only() -> None:
    offences = [offence for path in text_files() for offence in non_ascii_offences(path)]

    assert offences == []


def test_the_check_catches_a_typographic_dash(tmp_path: Path) -> None:
    sample = tmp_path / "sample.md"
    sample.write_bytes(b"a \xe2\x80\x93 b\n")  # an en dash in UTF-8

    assert non_ascii_offences(sample) == [f"{sample}:1: U+2013"]
