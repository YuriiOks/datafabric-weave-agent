---
name: km-review
description: One skeptical review pass, by the km-reviewer agent, of a story document under designs/ or of a diff. Use after a design is complete and before it is shown to the owner, or before a push. Prints the verdict and findings table; changes nothing unless asked.
argument-hint: <path | diff [clone]> [s1..s6]
---

# km-review

Arguments: $ARGUMENTS. The first word ($0) is a path (relative to /home/user/km, or absolute)
or the word `diff`; later words are read from the same line. Run name:
km-review-<slug of $0>-<date>. Exactly one km-reviewer call per run.

1. Resolve the item.
   - Path: it must exist. If not, log it, tell the owner in two lines, stop.
   - diff: the clone is the second word, else the one with commits ahead of its base (ask if
     two). Base is the upstream, else the remote default branch; if unknown, ask and stop. Run
     `git -C /home/user/km/<clone> diff <base>...HEAD > /home/user/km/work/km-review.diff`.
     Empty file: say so, stop. Item = that file. Note in the summary if the tree is dirty,
     because only committed changes are in the diff.
2. Story code: the last word if it is s1 to s6; else from the file name under designs/; else
   none.
3. Call km-reviewer once with: goal, review this item as the person who must sign it off;
   inputs, the item path and the story code; context, kb/private may be absent, then list what
   that leaves unverified; for a diff, apply the diff checks; output, your own reply format;
   limit, as your instructions say; skip, editing anything.
4. Print the reviewer's verdict and table unchanged. Do not start a second pass, even if the
   result looks thin; a further pass only when the owner asks.
5. Apply nothing unless the owner asks. If he asks, change only the file under designs/ (never
   a clone), one change per finding, and say which finding each change answers.
6. Record kb/log.d/<run>.txt: date, item, story, verdict, count of findings by severity.
   No knowledge file is written, so there is no index.d entry.

End with a summary of at most 4 lines: verdict, findings by severity, where the diff file is
(for diff), and the log path.
