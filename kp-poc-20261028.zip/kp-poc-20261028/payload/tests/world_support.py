"""A built world for tests that need the whole platform: staged data, a swept database."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from kp.app import Application, build_application
from kp.clock import FixedClock
from kp.config import Settings
from kp.demo.build import BuildRun, run_build
from kp.demo.runner import demo_settings
from kp.demo.staging import StagedData, find_dataset, stage


@dataclass(frozen=True)
class World:
    """The platform built on the committed synthetic data, as the demo builds it."""

    application: Application
    staged: StagedData
    build: BuildRun
    settings: Settings
    workdir: Path


def build_world(dataset_root: Path, workdir: Path) -> World:
    """Stage the dataset, build the application and run the build phases.

    :param dataset_root: A folder with the synthetic dataset
    :param workdir: An empty working folder
    :return: The world; the caller closes ``application``
    """
    staged = stage(find_dataset(dataset_root), workdir)
    settings = demo_settings(staged, workdir, workdir / "kp.db")
    application = build_application(
        settings, clock=FixedClock(staged.demo_instant()), sleeper=lambda _seconds: None
    )
    return World(application, staged, run_build(application, staged), settings, workdir)
