"""Release evidence for one case pack: what ran, what is decided and what is still open.

The record gathers the denominator report with the lineage, corpus, split and decision-log
digests and the approvals the pack depends on. It is evidence for a release decision taken
elsewhere by named owners; it never makes that decision and never claims promotion.
"""

from __future__ import annotations

from collections.abc import Sequence
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.recsys.contracts import ComponentType
from app.recsys.eval.casepack.corpus import CorpusManifest
from app.recsys.eval.casepack.decisions import ReviewDecision, check_decision_log
from app.recsys.eval.casepack.lineage import CasePackError, CasePackLineage, canonical_digest
from app.recsys.eval.casepack.pack import CasePack, validate_pack
from app.recsys.eval.casepack.profiles import CasePackProfile
from app.recsys.eval.casepack.report import (
    CaseObservation,
    DenominatorReport,
    build_report,
    render_report,
)
from app.recsys.eval.casepack.split import FeedbackEntry, SplitManifest, check_feedback


class ApprovalSubject(str, Enum):
    """What a case pack's results depend on before anyone may rely on them."""

    domain_reviewers = "domain_reviewers"
    shared_input_contract = "shared_input_contract"
    authorised_evidence = "authorised_evidence"
    access_and_privacy = "access_and_privacy"


#: Approvals without which a pack's results stay blocked.
REQUIRED_APPROVALS: frozenset[ApprovalSubject] = frozenset(
    {
        ApprovalSubject.domain_reviewers,
        ApprovalSubject.shared_input_contract,
        ApprovalSubject.authorised_evidence,
    }
)


class ApprovalState(str, Enum):
    """Where one approval stands."""

    open = "open"
    granted = "granted"
    refused = "refused"


class Approval(BaseModel):
    """One approval and, once decided, who decided it and where it is recorded."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    subject: ApprovalSubject
    state: ApprovalState = ApprovalState.open
    decided_by: str | None = Field(default=None, min_length=1, max_length=128)
    decision_reference: str | None = Field(default=None, min_length=1, max_length=256)

    @model_validator(mode="after")
    def _decision_is_named(self) -> Approval:
        """A decided approval names its decider and record; an open one names neither.

        :return: The approval.
        :raises ValueError: When state and names disagree.
        """
        named = self.decided_by is not None and self.decision_reference is not None
        unnamed = self.decided_by is None and self.decision_reference is None
        if self.state is ApprovalState.open and not unnamed:
            raise ValueError("an open approval names no decider and no record")
        if self.state is not ApprovalState.open and not named:
            raise ValueError("a decided approval names its decider and its record")
        return self


class ReleaseEvidence(BaseModel):
    """The evidence record of one run against one case pack."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    component_type: ComponentType
    pack_id: str
    run_reference: str = Field(min_length=1, max_length=256)
    lineage: CasePackLineage
    corpus_digest: str
    split_digest: str
    decision_log_digest: str
    denominators: DenominatorReport
    approvals: tuple[Approval, ...]
    open_approvals: tuple[ApprovalSubject, ...]
    refused_approvals: tuple[ApprovalSubject, ...]
    blockers: tuple[str, ...]
    promotion_claim: Literal[False] = False


def _approval_states(
    approvals: Sequence[Approval],
) -> tuple[tuple[Approval, ...], tuple[ApprovalSubject, ...], tuple[ApprovalSubject, ...]]:
    """Complete the approval list and split out the open and refused subjects.

    A required approval nobody recorded is open.

    :param approvals: The recorded approvals.
    :return: Every approval, the open subjects and the refused subjects.
    :raises CasePackError: When a subject is recorded twice.
    """
    by_subject: dict[ApprovalSubject, Approval] = {}
    for approval in approvals:
        if approval.subject in by_subject:
            raise CasePackError(f"approval {approval.subject.value} is recorded twice")
        by_subject[approval.subject] = approval
    for subject in REQUIRED_APPROVALS:
        by_subject.setdefault(subject, Approval(subject=subject))
    ordered = tuple(by_subject[key] for key in sorted(by_subject, key=lambda item: item.value))
    opened = tuple(item.subject for item in ordered if item.state is ApprovalState.open)
    refused = tuple(item.subject for item in ordered if item.state is ApprovalState.refused)
    return ordered, opened, refused


def build_release_evidence(
    pack: CasePack,
    corpus: CorpusManifest,
    split: SplitManifest,
    observations: Sequence[CaseObservation],
    decisions: Sequence[ReviewDecision],
    approvals: Sequence[Approval],
    profile: CasePackProfile,
    *,
    run_reference: str,
    feedback: Sequence[FeedbackEntry] = (),
) -> ReleaseEvidence:
    """Assemble the release evidence of one run.

    The pack must validate against its corpus and agree with the decision log; those are
    refused outright. Everything else that stands between the run and a reliable result is
    listed as a blocker: the denominator report's own blockers, feedback recorded against
    the final test, and open or refused approvals.

    :param pack: The case pack.
    :param corpus: The corpus manifest the pack pins.
    :param split: The grouped split.
    :param observations: The run's observations.
    :param decisions: The reviewer decision log.
    :param approvals: The recorded approvals.
    :param profile: The profile of the pack's type.
    :param run_reference: The CI or replay run that produced the observations.
    :param feedback: The tuning-feedback log.
    :return: The release evidence.
    :raises CasePackError: When the pack, corpus, decision log or approvals are inconsistent.
    """
    validate_pack(pack, corpus, profile)
    check_decision_log(pack.cases, decisions)
    denominators = build_report(pack, corpus, split, observations, profile)
    ordered, opened, refused = _approval_states(approvals)
    blockers = list(denominators.claim_blockers)
    try:
        check_feedback(feedback, pack.cases, split)
    except CasePackError as error:
        blockers.append(str(error))
    blockers.extend(f"approval open: {subject.value}" for subject in opened)
    blockers.extend(f"approval refused: {subject.value}" for subject in refused)
    log = sorted(decisions, key=lambda item: item.decision_id)
    return ReleaseEvidence(
        component_type=pack.component_type,
        pack_id=pack.pack_id,
        run_reference=run_reference,
        lineage=pack.lineage,
        corpus_digest=pack.corpus_digest,
        split_digest=split.digest(),
        decision_log_digest=canonical_digest([item.model_dump(mode="json") for item in log]),
        denominators=denominators,
        approvals=ordered,
        open_approvals=opened,
        refused_approvals=refused,
        blockers=tuple(blockers),
    )


def render_release_evidence(evidence: ReleaseEvidence) -> str:
    """Render the release evidence as Markdown.

    :param evidence: The release evidence.
    :return: The Markdown, ending with the explicit no-promotion statement.
    """
    lines = [
        f"# Release evidence: {evidence.pack_id}",
        "",
        f"- Run: `{evidence.run_reference}`",
        f"- Catalogue: `{evidence.lineage.catalogue_id}`",
        f"- Lineage: `{evidence.lineage.digest()}`",
        f"- Corpus: `{evidence.corpus_digest}`",
        f"- Split: `{evidence.split_digest}`",
        f"- Decision log: `{evidence.decision_log_digest}`",
        "",
        "| Approval | State | Decided by | Record |",
        "|---|---|---|---|",
    ]
    for item in evidence.approvals:
        lines.append(
            f"| {item.subject.value} | {item.state.value} | {item.decided_by or '-'} "
            f"| {item.decision_reference or '-'} |"
        )
    lines.append("")
    if evidence.blockers:
        lines.append("Blocked:")
        lines.extend(f"- {blocker}" for blocker in evidence.blockers)
    else:
        lines.append("No blocker recorded.")
    lines.extend(["", render_report(evidence.denominators).rstrip("\n"), ""])
    lines.append("No promotion claim: this record is evidence for a decision taken elsewhere.")
    return "\n".join(lines) + "\n"
