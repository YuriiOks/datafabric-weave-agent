"""Ports: the capabilities this package needs from other lanes, as small protocols.

The integrator wires real implementations (for example one backed by the search lane);
tests use fakes. Nothing here imports another lane's package.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime
from typing import TYPE_CHECKING, Protocol

from kp.domain import Link

if TYPE_CHECKING:
    from kp.links.store import LinkStatistics


class SimilarityPort(Protocol):
    """How strongly a query text agrees with candidate texts, as a search would rank them.

    A search-backed implementation returns its raw ranking scores; the scorer rescales them
    to 0-1 with :attr:`max_score` before weighting.
    """

    @property
    def max_score(self) -> float:
        """The largest raw score the implementation can return; always positive."""
        ...

    def agreement(self, query: str, candidates: Sequence[str]) -> Sequence[float]:
        """Score candidate texts against a query text.

        :param query: The text of the item the link starts at
        :param candidates: The texts of the items it might link to
        :return: One raw score per candidate, in order, from 0 to :attr:`max_score`
        """
        ...


class LinkReader(Protocol):
    """Read access to the links in use. The SQL store is the PostgreSQL stand-in.

    A graph database, if approved, would implement the same methods. The queries and the
    publication checks read links only through this interface.
    """

    def in_use_links(self, as_at: datetime | None = None) -> list[Link]:
        """List the stated and proposed links that apply at an instant.

        :param as_at: A timezone-aware instant; ``None`` means now
        :return: The links in force
        """
        ...

    def statistics(self) -> LinkStatistics:
        """Count the open links, including the guessed share.

        :return: Counts over stated, proposed and review links
        """
        ...
