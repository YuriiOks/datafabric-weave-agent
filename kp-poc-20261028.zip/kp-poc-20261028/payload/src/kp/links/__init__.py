"""Links between items: the link store, stated and guessed links, impact and coverage queries.

The public entry point is :class:`LinkService`. Loaders in :mod:`kp.links.stated` turn what
sources state into links; :mod:`kp.links.guessed` scores the rest. Other lanes' capabilities
enter through the ports in :mod:`kp.links.ports`.
"""

from kp.links.candidate import LinkCandidate, conformance_violation
from kp.links.coverage import (
    CoverageEvidence,
    CoverageReport,
    RuleCoverage,
    RulesWithoutTests,
)
from kp.links.errors import (
    LinkError,
    LinkModelViolationError,
    LinkNotFoundError,
    NoEditionInForceError,
    SimilarityPortError,
    UnknownClauseError,
    UnknownEditionError,
)
from kp.links.graph import LinkGraph
from kp.links.guessed import (
    GuessedLinkProposer,
    GuessItem,
    GuessReport,
    LinkScore,
    LinkScorer,
    TermOverlapSimilarity,
)
from kp.links.impact import IMPACT_MAX_STEPS, ImpactItem, ImpactReport, ImpactStep
from kp.links.ports import LinkReader, SimilarityPort
from kp.links.refs import (
    clause_item,
    code_item,
    find_clause_refs,
    schema_field_item,
    source_path_of,
    unit_test_item,
)
from kp.links.rules import Rule, RuleCatalog
from kp.links.service import LinkService, SyncReport
from kp.links.stated import (
    KeyIndex,
    RejectedLink,
    RepositoryScan,
    RepositoryScanner,
    StatedLinkSet,
    register_link_set,
    story_link_set,
)
from kp.links.store import AssertedLink, AssertOutcome, LinkStatistics, SqlLinkStore

__all__ = [
    "IMPACT_MAX_STEPS",
    "AssertOutcome",
    "AssertedLink",
    "CoverageEvidence",
    "CoverageReport",
    "GuessItem",
    "GuessReport",
    "GuessedLinkProposer",
    "ImpactItem",
    "ImpactReport",
    "ImpactStep",
    "KeyIndex",
    "LinkCandidate",
    "LinkError",
    "LinkGraph",
    "LinkModelViolationError",
    "LinkNotFoundError",
    "LinkReader",
    "LinkScore",
    "LinkScorer",
    "LinkService",
    "LinkStatistics",
    "NoEditionInForceError",
    "RejectedLink",
    "RepositoryScan",
    "RepositoryScanner",
    "Rule",
    "RuleCatalog",
    "RuleCoverage",
    "RulesWithoutTests",
    "SimilarityPort",
    "SimilarityPortError",
    "SqlLinkStore",
    "StatedLinkSet",
    "SyncReport",
    "TermOverlapSimilarity",
    "UnknownClauseError",
    "UnknownEditionError",
    "clause_item",
    "code_item",
    "conformance_violation",
    "find_clause_refs",
    "register_link_set",
    "schema_field_item",
    "source_path_of",
    "story_link_set",
    "unit_test_item",
]
