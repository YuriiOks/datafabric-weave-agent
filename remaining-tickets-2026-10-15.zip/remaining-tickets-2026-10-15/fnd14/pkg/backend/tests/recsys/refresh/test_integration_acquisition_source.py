"""Acquisition-backed source adapter: captures, refusals and safe reasons."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from app.recsys.acquisition.models import AcquisitionRefusal, ActivationState, RefusalCode
from app.recsys.contract_fixtures import COMPLETE_MANIFEST, digest
from app.recsys.refresh.integration.acquisition_source import AcquisitionSourceAdapter
from app.recsys.refresh.integration.staging import ArtifactStaging
from app.recsys.refresh.models import SafeReason
from app.recsys.refresh.ports import SourceCaptureFailed

from . import protocol_fixtures as fixtures

SOURCE_ID = fixtures.SNAPSHOT.adapter_ids[0]
MANIFEST = COMPLETE_MANIFEST.model_copy(update={"scope": fixtures.SCOPE})
TREE_DIGEST = digest("acquired-tree")


class _Service:
    def __init__(self, outcome) -> None:
        self.outcome = outcome
        self.calls: list[tuple[tuple[str, ...], Path]] = []

    def acquire(self, source_ids, staging_root):
        self.calls.append((source_ids, staging_root))
        if isinstance(self.outcome, Exception):
            raise self.outcome
        return self.outcome


def _batch(*, acquired=True, activation=ActivationState.eligible, code=None):
    found = SimpleNamespace(manifest=MANIFEST, content_hash=TREE_DIGEST)
    evidence = SimpleNamespace(code=code) if code is not None else None
    return SimpleNamespace(
        records=(SimpleNamespace(source_id=SOURCE_ID, evidence=evidence),),
        acquired={SOURCE_ID: found} if acquired else {},
        activation=activation,
    )


class AcquisitionSourceAdapterTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.staging = ArtifactStaging(Path(self._tmp.name) / "staging")

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def _adapter(self, outcome, source_id: str = SOURCE_ID) -> AcquisitionSourceAdapter:
        return AcquisitionSourceAdapter(
            source_id=source_id,
            service=_Service(outcome),
            staging=self.staging,
        )

    async def _reason(self, adapter: AcquisitionSourceAdapter) -> str:
        with self.assertRaises(SourceCaptureFailed) as raised:
            await adapter.capture(fixtures.SNAPSHOT, fixtures.LEASE)
        return raised.exception.reason

    async def test_capture_names_the_staged_artifact_by_reference_and_digest(self) -> None:
        adapter = self._adapter(_batch())

        capture = await adapter.capture(fixtures.SNAPSHOT, fixtures.LEASE)

        self.assertEqual(capture.adapter_id, SOURCE_ID)
        self.assertEqual(capture.manifest, MANIFEST)
        self.assertEqual(capture.artifact_digest, TREE_DIGEST)
        staged = self.staging.get(capture.artifact_reference, TREE_DIGEST)
        self.assertEqual(staged.attempt_id, fixtures.LEASE.attempt_id)
        ((source_ids, root),) = adapter._service.calls
        self.assertEqual(source_ids, (SOURCE_ID,))
        self.assertEqual(root.parent.name, str(fixtures.LEASE.attempt_id))

    async def test_stale_or_incomplete_refusal_reports_incomplete(self) -> None:
        stale = AcquisitionRefusal(RefusalCode.source_stale, SOURCE_ID, "acquire")

        self.assertEqual(
            await self._reason(self._adapter(stale)), SafeReason.source_incomplete.value
        )
        self.assertEqual(
            await self._reason(
                self._adapter(_batch(acquired=False, code=RefusalCode.source_incomplete))
            ),
            SafeReason.source_incomplete.value,
        )

    async def test_other_refusals_and_errors_report_failed(self) -> None:
        refused = AcquisitionRefusal(RefusalCode.host_not_allowed, SOURCE_ID, "fetch")

        for outcome in (refused, ValueError("askpass missing"), OSError("disk")):
            with self.subTest(outcome=type(outcome).__name__):
                self.assertEqual(
                    await self._reason(self._adapter(outcome)), SafeReason.source_failed.value
                )

    async def test_acquired_but_blocked_source_is_not_captured(self) -> None:
        adapter = self._adapter(_batch(activation=ActivationState.blocked))

        self.assertEqual(await self._reason(adapter), SafeReason.source_incomplete.value)

    async def test_source_outside_the_snapshot_is_refused_before_acquiring(self) -> None:
        adapter = self._adapter(_batch(), source_id="unregistered-source")

        self.assertEqual(
            await self._reason(adapter), SafeReason.source_configuration_changed.value
        )
        self.assertEqual(adapter._service.calls, [])
