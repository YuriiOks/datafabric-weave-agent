> [!IMPORTANT]
> **Format and contract only.** Every case in this PR is synthetic and unjudged. No quality statement can be made from it until domain reviewers judge real cases, the publication reads are mounted and the partition weights are agreed. The report says so itself.

## Problem

The shared lexical baseline cannot say what it was measured against or how many cases actually measured something. The existing golden set pins no publication, carries no reviewed relevance judgement and has no grouping that keeps related needs out of the held-out cases. It also cannot tell a measured empty result from a failed run, a disabled feature, an access-filtered result or a missing source. A suggestion could look good on a set it was tuned against.

## Solution

A case-pack format beside the existing evaluation, pinned end to end:

- **Corpus manifest.** Built only from the canonical records of a validated catalogue snapshot. It pins the catalogue, manifest digest, scope, policy and code versions, and exactly one revision per source authority. For every published Skill it records whether the name and the description are present, missing or malformed, a digest of the text (never the text), and the source occurrence the text came from. Components that are not baseline input are listed with their graph or eligibility reason. A field-availability report counts present, missing and malformed fields over baseline input. Triggers, tools and tags are listed as not carried by the canonical publication, and nothing synthesises them.
- **Cases.** Each case names a scenario, a truthful expected outcome (ranked, valid empty, access filtered or source unavailable), forbidden components, typed required evidence and an adjudication. The adjudication is either explicitly unjudged or judged by a named reviewer with a decision reference. Scenario rules hold at construction:
  - a hard negative and an access case name a forbidden component;
  - a valid-empty case carries no relevant label;
  - a judged ranked case needs a relevant or partially relevant label;
  - a declared prerequisite can be cited as evidence, never as a label, and it only counts once the suggested Skill itself is judged relevant.

  A draft labeller cannot sign a judgement, and free-text needs must be marked synthetic.
- **Split.** Groups are assigned to development, validation, calibration and final-test partitions by a seeded hash with explicit weights. The same need in two groups is refused, and so is a duplicate set spread over groups. The final test is frozen by digest. A change after the freeze is refused and needs a new held-out set, and so is tuning feedback that touches a final-test case.
- **Decision log.** Reviewer decisions are applied through the same validation. A pack whose labels differ from its latest logged decision is refused.
- **Denominators.** Every planned case lands in exactly one bucket: not run, lineage mismatch, failed, disabled, blocked or completed. Completed cases split further into measured ranked, measured empty, valid empty, access filtered and source unavailable. Judged and unjudged cases, reduced input coverage, forbidden hits, unpublished ids and excluded ids are counted separately. A failed run is never a valid empty. A quality statement is supported only when all of these hold:
  - the frozen final test is complete and judged;
  - the required scenarios are present;
  - the read policy is pinned;
  - nothing forbidden, unpublished or excluded came back.

  The report never claims promotion.

Unchanged: the existing golden set, runner and metrics, every route, the catalogue and the publication. Nothing calls a model or reads a live publication.

## How to verify

1. Unit tests: `tests/recsys/eval/test_casepack_*.py`. CI runs them.
2. Build the synthetic pack from the test support and render its denominator report. A case observed as failed shows under Failed, never as Valid empty, and the last line says no promotion is claimed.
3. Negative case: change a final-test case after freezing the split. Verification refuses it as "changed after the freeze".

## Not in this PR

- **Adjudicated labels.** Every case is unjudged; judging is the domain reviewers' work, recorded through the decision log.
- **Live corpus.** Publication reads are not mounted, so the manifest builder works on records the caller supplies.
- **Component ids.** Cases name components by canonical component id text, as the publication emits them. The existing runner keys components by type and slug, so joining the two is the shared baseline's integration point.
- **Lexical fields.** Name and description only. Triggers, tools and tags are not published, and nothing derives them.
- **Partition weights.** A required input with no default. The final test is frozen only after adjudication.
- **Access cases.** Not measurable until a read policy revision is pinned in the lineage.

## Review focus

- The prerequisite rule: declared prerequisite evidence counts only after its subject is judged relevant. Is that strict enough?
- Field states: a blank text or an empty-description flag is missing; a raw-YAML or missing-frontmatter flag, or control characters, is malformed. Does that match how the catalogue flags them?
- A returned component that is published but excluded from baseline input blocks the quality statement, the same as an unpublished id.

## CI

- The checks posted on this head are the result.
