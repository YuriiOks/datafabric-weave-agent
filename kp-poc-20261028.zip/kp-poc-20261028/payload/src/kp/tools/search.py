"""The ``search`` tool: passages with reference, page, position and version."""

from __future__ import annotations

import logging
from datetime import date
from typing import Annotated

from pydantic import Field

from kp.domain import DomainModel, ItemRef, ItemType, PassageType
from kp.errors import AccessForbiddenError
from kp.tools.access import ToolContext
from kp.tools.errors import LinkStoreUnavailableError
from kp.tools.ports import LinkCounts, LinkPort, SearchHit, SearchPort
from kp.tools.registry import RegisteredTool, ToolArguments, ToolOutcome, define_tool

logger = logging.getLogger(__name__)

NAME = "search"
LINKS_UNAVAILABLE_NOTICE = (
    "The link store is unavailable: these results come from passages only and carry no link counts."
)


class SearchArguments(ToolArguments):
    """Arguments of ``search``. There is deliberately no domain argument."""

    query: Annotated[str, Field(min_length=1, max_length=500, description="Question or keywords")]
    limit: Annotated[int, Field(ge=1, le=50, description="Maximum number of hits")] = 10
    as_at: Annotated[
        date | None, Field(description="Read the rules as at this date; default is today")
    ] = None


class SearchHitView(DomainModel):
    """One hit as shown to the agent.

    Link counts cover clause hits only, and are ``None`` for any other passage (not linkable
    here) and for every hit when the link store is down.
    """

    passage_id: str
    passage_type: PassageType
    reference: str
    text: str
    page: int | None
    char_start: int | None
    char_end: int | None
    version: str
    domain: str | None
    score: float | None
    stated_links: int | None
    guessed_links: int | None


class SearchOutput(DomainModel):
    """The ``search`` result."""

    hits: tuple[SearchHitView, ...]
    filtered_out: int
    links_available: bool
    notice: str | None


def search_tool(search: SearchPort, links: LinkPort) -> RegisteredTool:
    """Build the ``search`` tool.

    :param search: Passage search
    :param links: Link store, used only to add link counts; search works without it
    :return: The registrable tool
    """

    def handle(context: ToolContext, arguments: SearchArguments) -> ToolOutcome:
        as_at = arguments.as_at or context.clock.today()
        response = search.search(
            arguments.query, domains=context.domains, as_at=as_at, limit=arguments.limit
        )
        visible, hidden = context.split_visible(response.hits, lambda hit: hit.domain)
        visible = visible[: arguments.limit]
        if not visible and response.filtered_out + hidden:
            raise AccessForbiddenError(
                "Every match lies in a domain the caller may not read; nothing can be shown"
            )
        counts = _link_counts(links, visible, context.domains)
        output = SearchOutput(
            hits=tuple(_view(hit, counts) for hit in visible),
            filtered_out=response.filtered_out + hidden,
            links_available=counts is not None,
            notice=None if counts is not None else LINKS_UNAVAILABLE_NOTICE,
        )
        return ToolOutcome(
            payload=output.model_dump(mode="json"),
            items_returned=len(output.hits),
            filtered_count=output.filtered_out,
        )

    return define_tool(
        NAME,
        "Search the knowledge base. Returns passages with reference, page, character position "
        "and version, limited to the domains of the caller's identity; the number of matches "
        "hidden by that limit is reported. Clause hits carry the count of stated and guessed "
        "links to items the caller may read. When matches exist but all lie outside the "
        "caller's domains the call is refused as forbidden rather than answered with nothing.",
        SearchArguments,
        handle,
    )


def _clause_item(hit: SearchHit) -> ItemRef | None:
    if hit.passage_type is not PassageType.CLAUSE:
        return None
    return ItemRef(item_type=ItemType.CLAUSE, key=hit.reference)


def _link_counts(
    links: LinkPort, hits: list[SearchHit], domains: frozenset[str]
) -> dict[ItemRef, LinkCounts] | None:
    """Fetch link counts for the clause hits, or ``None`` when the link store is down."""
    items = sorted(
        {item for hit in hits if (item := _clause_item(hit)) is not None}, key=lambda i: i.key
    )
    if not items:
        return {}
    try:
        return dict(links.link_counts(items, domains=domains))
    except LinkStoreUnavailableError:
        logger.warning("Link store unavailable; search answers from passages only")
        return None


def _view(hit: SearchHit, counts: dict[ItemRef, LinkCounts] | None) -> SearchHitView:
    item = _clause_item(hit)
    found = None if counts is None or item is None else counts.get(item, LinkCounts())
    return SearchHitView(
        passage_id=hit.passage_id,
        passage_type=hit.passage_type,
        reference=hit.reference,
        text=hit.text,
        page=hit.page,
        char_start=hit.char_start,
        char_end=hit.char_end,
        version=hit.version,
        domain=hit.domain,
        score=hit.score,
        stated_links=None if found is None else found.stated,
        guessed_links=None if found is None else found.guessed,
    )
