# DMC Workspace Full-Depth Analysis

Date: 2026-07-06 (updated 2026-07-07 with dtas-api-gateway)

## How to use this document

This is a deep technical + functional + business analysis for all three repositories in this workspace. It complements REPO_ONBOARDING_GUIDE.md and focuses on executable flow understanding.

Confidence labels:
- [certain]: directly evidenced by code inspected.
- [likely]: strongly implied by multiple files but may depend on environment wiring.
- [guessing]: no direct evidence found.

---

## 1. Whole-workspace architecture

[certain] The workspace is a multi-repo platform with a dedicated API gateway, two UI generations, and one core backend service.

- **dtas-api-gateway**: Flask reverse proxy - all legacy UI traffic passes through it. Authenticates users and routes to downstream services.
- data-controls-automation-api: FastAPI + SQLAlchemy + Prefect + BigQuery + Collibra + LDAP. Primary upstream of the gateway.
- data-controls-automation-ui: legacy React SPA talking to the gateway on port 8082.
- data-management-centre: newer TanStack Start app using server functions and query layer, currently mock-first in many domains.

### Architecture map

```mermaid
flowchart LR
  U[User Browser]

  subgraph LegacyUI[data-controls-automation-ui]
    LMain[React app + BrowserRouter]
    LQuery[TanStack Query hooks in pages]
    LFetch[useFetchService port 8082]
  end

  subgraph Gateway[dtas-api-gateway :8082]
    GAuth[AuthenticationTask]
    GProxy[BaseApiService proxy]
    GRoutes[Route switch]
  end

  subgraph API[data-controls-automation-api]
    APIRoutes[FastAPI routers]
    APIServices[Service layer]
    APIDB[PostgreSQL via SQLAlchemy]
    Collibra[Collibra]
    BQ[BigQuery/CXO]
    LDAP[LDAP Worker lookup]
  end

  subgraph Upstreams[External upstream services]
    DQ[DQ API :8001]
    ARIS[ARIS API :8080]
  end

  subgraph DMC[data-management-centre]
    DRoutes[TanStack file routes]
    DQueries[queries/*.ts]
    DServer[server/*.ts createServerFn]
    DMocks[mocks/data + MSW]
  end

  subgraph DSP[HSBC DSP / ForgeRock]
    AMAuth[Session / AMToken]
    TokenTrans[Token Translator]
    PKMS[PKMS Key Manifest]
  end

  U --> LMain --> LQuery --> LFetch --> GAuth
  GAuth -->|valid| GRoutes
  GAuth -->|invalid| LFetch
  GRoutes -->|*| GProxy --> APIRoutes
  GRoutes -->|/dq-app/*| DQ
  GRoutes -->|/aris/*| ARIS
  APIRoutes --> APIServices --> APIDB
  APIServices --> Collibra
  APIServices --> LDAP
  APIServices --> BQ
  GAuth -->|get token| TokenTrans
  TokenTrans -->|E2E JWT| GAuth
  GAuth -->|validate sig| PKMS
  U --> DRoutes --> DQueries --> DServer --> DMocks
```

Evidence:
- data-controls-automation-api/main.py
- data-controls-automation-api/automation_api/services/application.py
- data-controls-automation-ui/src/main.tsx
- data-controls-automation-ui/src/services/fetchService.ts
- dtas-api-gateway/app.py
- dtas-api-gateway/apis/api_gateway.py
- dtas-api-gateway/models/api_service.py
- dtas-api-gateway/models/authentication.py
- data-management-centre/src/routes/__root.tsx
- data-management-centre/src/queries/applications.ts
- data-management-centre/src/server/applications.ts

---

## 2. Repository deep dives

## 2.0 dtas-api-gateway

### 2.0.1 Technical logic

[certain] Flask app, port 8082, with three catch-all Blueprint routes:

| Route pattern | Handler | Upstream |
|---|---|---|
| `/<path:path>` catch-all | `index()` | DTAS_API_SERVICE (data-controls-automation-api) |
| `/dq-app/<path:path>` | `index_dq()` | DQ_API_SERVICE |
| `/aris/<path:path>` | `index_aris()` | ARIS_API_SERVICE |

Evidence:
- dtas-api-gateway/apis/api_gateway.py
- dtas-api-gateway/app.py

[certain] Before every upstream call, `AuthenticationTask.process()` runs. It returns either `(True, {e2e_token})` (proceed) or `(False, Response 401)` (block).

Evidence:
- dtas-api-gateway/models/gateway_tasks.py
- dtas-api-gateway/models/api_service.py

### 2.0.2 E2E token authentication pipeline detail

```mermaid
flowchart TD
  Req[Inbound HTTP request]
  CheckE2E{Has X-HSBC-E2E-Trust-Token?}
  UseE2E[Use it directly IB2B path]
  GetAM[Extract AMToken cookie or Authorization Bearer]
  NoAM{AM token found?}
  Fail401[Return 401]
  Translate[POST DSP token translator\nAM token -> E2E JWT]
  Validate[JWTE2EVerifier.validate_token]
  ParseJWT[Parse JWT header+payload+signature]
  CheckExpiry[Verify exp/iat with 2s clock skew]
  GetKey[Look up kid in PKMS manifest]
  CacheMiss{Key in cache?}
  RefetchManifest[Re-fetch manifest from PKMS URL]
  VerifySig[RSA-SHA256 verify signature]
  OldKey{Try old key?}
  TokenValid[Token valid]
  InjectHeader[Add X-HSBC-E2E-Trust-Token to upstream request]
  CallUpstream[Proxy to upstream service]

  Req --> CheckE2E
  CheckE2E -->|yes| UseE2E --> Validate
  CheckE2E -->|no| GetAM
  GetAM --> NoAM
  NoAM -->|no| Fail401
  NoAM -->|yes| Translate --> Validate
  Validate --> ParseJWT --> CheckExpiry
  CheckExpiry -->|expired| Fail401
  CheckExpiry -->|valid| GetKey --> CacheMiss
  CacheMiss -->|miss| RefetchManifest --> VerifySig
  CacheMiss -->|hit| VerifySig
  VerifySig -->|fail| OldKey
  OldKey -->|found| VerifySig
  OldKey -->|not found| Fail401
  VerifySig -->|pass| TokenValid --> InjectHeader --> CallUpstream
```

Evidence:
- dtas-api-gateway/models/authentication.py
- dtas-api-gateway/e2e_verifier/e2e_driver.py
- dtas-api-gateway/e2e_verifier/token_verifier.py
- dtas-api-gateway/e2e_verifier/token_validator.py
- dtas-api-gateway/e2e_verifier/manifest_verifier.py

### 2.0.3 How gateway connects to data-controls-automation-api

[certain] The connection is a direct HTTP protocol contract:
- Gateway injects `X-HSBC-E2E-Trust-Token` as a header.
- `data-controls-automation-api/auth.py` reads that exact header name via FastAPI `APIKeyHeader`.
- It then JWT-decodes the token to extract `sub` (username) and `grp` AD groups (or fetches groups via `gru` URL in token).
- Those AD groups drive all permission decisions in services.

```mermaid
sequenceDiagram
  participant UI as Legacy UI
  participant GW as dtas-api-gateway :8082
  participant DSP as DSP token translator
  participant PKMS as PKMS manifest
  participant API as data-controls-automation-api

  UI->>GW: GET /application (Authorization: Bearer AMToken)
  GW->>DSP: POST tokenTranslator (AMToken)
  DSP-->>GW: E2E JWT
  GW->>PKMS: GET manifest.json
  PKMS-->>GW: public key manifest
  GW->>GW: Verify JWT signature with kid key
  GW->>API: GET /application (X-HSBC-E2E-Trust-Token: JWT)
  API->>API: decode JWT -> sub + grp
  API-->>GW: ApplicationDTO list
  GW-->>UI: proxied response
```

Evidence:
- dtas-api-gateway/models/authentication.py
- dtas-api-gateway/models/api_service.py (call_api injects header)
- data-controls-automation-api/auth.py

### 2.0.4 PKMS manifest caching logic

[certain] Manifest caching is in-process, module-level global state:
- On first call: fetch manifest JSON from URL.
- On subsequent calls: return cached unless `.sig` file changed (checked on each request).
- Manifest contains `keys[]` with `kid`, `key` (current), and optional `old.key` with `old.expiry` for rotation.

Evidence:
- dtas-api-gateway/e2e_verifier/manifest_verifier.py

### 2.0.5 Business logic

[certain] Gateway implements no domain logic. It enforces a security boundary:
- No unauthenticated traffic reaches the backend.
- Token identity is passed to the backend, which applies its own permission model.
- DQ and ARIS traffic is kept separated from DTAS traffic at the route level.

### 2.0.6 Component inventory

| File | Purpose |
|---|---|
| app.py | App factory, service singletons, CORS, logging, port 8082 |
| apis/api_gateway.py | Blueprint with 3 catch-all proxy routes |
| models/api_service.py | BaseApiService: auth task + proxy call |
| models/authentication.py | AM→E2E token exchange, JWTE2EVerifier invocation |
| models/gateway_tasks.py | AuthenticationTask base class |
| models/dtas_api_service.py | Specializes BaseApiService for DTAS upstream |
| models/dq_api_service.py | Specializes for DQ upstream |
| models/aris_api_service.py | Specializes for ARIS upstream |
| models/const.py | DSP request headers constant |
| e2e_verifier/e2e_driver.py | JWTE2EVerifier: orchestrates full JWT validation |
| e2e_verifier/token_verifier.py | JWT base64 parse + expiry check |
| e2e_verifier/token_validator.py | RSA-SHA256 signature verify (pycryptodome) |
| e2e_verifier/manifest_verifier.py | PKMS manifest fetch, cache, key lookup, cert chain verify |
| settings/base_config.py | GlobalConfig pydantic model with defaults |
| settings/dev&124;uat&124;prod.py | Environment-specific DSP URLs and manifest URLs |
| settings/__init__.py | FactoryConfig: picks config class from ENV_STATE |
| utils/errors.py | AuthenticationError exception |
| pytest/ | pytest coverage for routes, auth tasks, token parsing |

---

## 2.1 data-controls-automation-api

Auth reads `X-HSBC-E2E-Trust-Token` injected by the gateway, decodes it to get username and AD groups.
- Correlation ID and structured logging middleware wrap every request.
- Custom exception handlers map domain exceptions to HTTP responses.
- Routers are mounted for health-check, application, and CDAO-tag domains.

Evidence:
- data-controls-automation-api/main.py

[certain] Dependency injection architecture:
- DB session per request via async sessionmaker.
- BigQuery CXO client dependency.
- Collibra async client dependency.
- WorkerService for LDAP lookups.

Evidence:
- data-controls-automation-api/automation_api/dependencies/database.py
- data-controls-automation-api/automation_api/dependencies/cxo.py
- data-controls-automation-api/automation_api/dependencies/collibra.py
- data-controls-automation-api/automation_api/dependencies/worker.py

[certain] Data model spine:
- Base model carries audit-style columns for created/updated/deleted metadata.
- Application, tag, association, and change-request entities implement governance workflow persistence.

Evidence:
- data-controls-automation-api/automation_api/database/base.py
- data-controls-automation-api/automation_api/database/data_control_scope.py

### 2.1.2 Functional logic

[certain] Application endpoint:
- GET `/application` returns ApplicationDTO list via ApplicationService.
- Service joins value stream cache + tags + application state.
- If an app is missing, it can be synced from Collibra by external ID.

Evidence:
- data-controls-automation-api/automation_api/routers/application.py
- data-controls-automation-api/automation_api/services/application.py
- data-controls-automation-api/automation_api/dto/application.py

[certain] CDAO tag endpoints cover complete lifecycle:
- create/list tags
- tag/untag application
- request approve/reject/revoke
- get pending/my requests
- get tag history

Evidence:
- data-controls-automation-api/automation_api/routers/cdao_tags.py

### 2.1.3 Business logic

[certain] Key policy rules in code:
- Users can manage only tags mapped to their AD groups.
- Duplicate pending requests for same app/tag/user are blocked.
- Request can auto-approve only under strict consistency checks.
- PRA-like flow can escalate to DMS governance approval step.
- Primary CDAO status changes who can approve/reject.

Evidence:
- data-controls-automation-api/automation_api/services/cdao_tags_change_request.py
- data-controls-automation-api/automation_api/services/cdao_tags.py
- data-controls-automation-api/auth.py

### 2.1.4 Request sequence for CDAO tag change

```mermaid
sequenceDiagram
  participant User
  participant Router as cdao_tags router
  participant CR as CDAO Tag Change Request Service
  participant AppSvc as ApplicationService
  participant TagSvc as CDAO Tag Service
  participant DB as PostgreSQL

  User->>Router: POST /cdao-tag/{application_id}/tag/{tag_name}
  Router->>CR: create_change_request(application_id, tag_name, payload)
  CR->>AppSvc: get_application()
  CR->>TagSvc: get_tag()
  CR->>CR: check permissions + pending duplicate
  CR->>CR: evaluate auto-approve and PRA conditions

  alt auto-approve path
    CR->>CR: apply() mutate association + changes
    CR->>DB: commit APPROVED_APPLIED
  else pending path
    CR->>DB: commit PENDING_PRIMARY_CDAO or PENDING_DMS_GOV
  end

  CR-->>Router: GetCDAOTagChangeRequestDTO
  Router-->>User: HTTP response
```

### 2.1.5 Approval state machine

```mermaid
stateDiagram-v2
  [*] --> pending_primary_cdao
  pending_primary_cdao --> pending_dms_gov: Approved by primary CDAO and requires line2
  pending_primary_cdao --> approved_applied: Approved and applied
  pending_primary_cdao --> rejected_by_primary_cdao: Rejected line1

  pending_dms_gov --> approved_applied: Approved by DMS Gov
  pending_dms_gov --> rejected_by_dms_gov: Rejected line2

  pending_primary_cdao --> revoked: Revoked by issuer
  pending_dms_gov --> revoked: Revoked by issuer

  approved_applied --> [*]
  rejected_by_primary_cdao --> [*]
  rejected_by_dms_gov --> [*]
  revoked --> [*]
```

### 2.1.6 Batch sync pipeline

[certain] Prefect deployments trigger periodic sync jobs.

```mermaid
flowchart TD
  Cron[Cron schedules in flows.py] --> Deploy[Prefect deployment run]
  Deploy --> SyncJob[DataSync.default_run]
  SyncJob --> StartETL[Insert ETLJob status=started]
  StartETL --> QueryBQ[Read BigQuery batches]
  QueryBQ --> Upsert[Domain-specific upsert_values]
  Upsert --> Finish[Commit ETLJob status=Finished]
  QueryBQ --> ErrorPath[On exception rollback]
  ErrorPath --> MarkErr[Commit ETLJob status=Error]
```

Evidence:
- data-controls-automation-api/flows.py
- data-controls-automation-api/dags/import_jobs.py
- data-controls-automation-api/dags/queries.py

---

## 2.2 data-controls-automation-ui

### 2.2.1 Technical logic

[certain] App boot chain:
- BrowserRouter basename `/dmc/`
- QueryClientProvider
- NotificationProvider
- AppContextProvider
- AuthWrapper
- App routes

Evidence:
- data-controls-automation-ui/src/main.tsx

[certain] State architecture:
- Global AppContext stores app selection, user, token, permissions, flow mode, step data, and caches.
- Page-level data is mostly fetched with TanStack Query in components/pages.

Evidence:
- data-controls-automation-ui/src/context/AppContext.tsx
- data-controls-automation-ui/src/pages/Home/HomePage.tsx

[certain] API access model:
- useFetchService prepends API base URL and injects bearer token.
- DSP token and user profile are fetched from DSP endpoints.

Evidence:
- data-controls-automation-ui/src/services/fetchService.ts
- data-controls-automation-ui/src/hooks/useAuth.ts
- data-controls-automation-ui/src/api/auth.ts

### 2.2.2 Functional logic

[certain] Core routes:
- landing
- applications
- cdao
- data-control-scope

Evidence:
- data-controls-automation-ui/src/App.tsx

[certain] Home page responsibilities include:
- application discovery
- filtering + pagination
- app details fetch
- CDAO tagging actions
- filter option hydration from dedicated endpoints

Evidence:
- data-controls-automation-ui/src/pages/Home/HomePage.tsx

[certain] CDAO page:
- tabbed workspace with permission-dependent visibility.
- my tagged apps / pending approvals / my requests pattern.

Evidence:
- data-controls-automation-ui/src/pages/CDAO/CDAO.tsx
- data-controls-automation-ui/src/hooks/useUserPermissions.ts

### 2.2.3 Business logic in legacy UI

[certain]
- User capability flags from `/dcs/user` drive what can be seen/acted on.
- Journey docs define orchestrated DMOV/DUSE path and backend API needs.

Evidence:
- data-controls-automation-ui/src/hooks/useUserPermissions.ts
- data-controls-automation-ui/DATA_CONTROLS_JOURNEY_README.md
- data-controls-automation-ui/API_ENDPOINTS_SUMMARY.md

### 2.2.4 Legacy auth + API call flow (showing gateway)

```mermaid
sequenceDiagram
  participant Browser
  participant AuthHook as useAuth/AuthWrapper
  participant DSP as DSP endpoints
  participant Context as AppContext
  participant Page as Home/CDAO page
  participant Fetch as useFetchService :8082
  participant GW as dtas-api-gateway
  participant API as data-controls-automation-api

  Browser->>AuthHook: app load
  AuthHook->>DSP: fetchToken() POST dspAuthenticate.jsp
  DSP-->>AuthHook: AMToken / tokenId
  AuthHook->>DSP: fetchUserInfo() POST getSessionInfo
  DSP-->>AuthHook: user profile
  AuthHook->>Context: set token/user

  Page->>Fetch: request data endpoint
  Fetch->>GW: Authorization Bearer AMToken
  GW->>DSP: translate AMToken to E2E JWT
  DSP-->>GW: E2E JWT
  GW->>GW: verify JWT signature (PKMS)
  GW->>API: X-HSBC-E2E-Trust-Token JWT
  API->>API: decode JWT -> username + AD groups
  API-->>GW: domain response JSON
  GW-->>Fetch: proxied response
  Fetch-->>Page: parsed response
```

---

## 2.3 data-management-centre (DMC)

### 2.3.1 Technical logic

[certain] App architecture is route-query-server layered:
- file-based routes
- TanStack Query options and mutations
- server functions created with `createServerFn`
- Drizzle schema/config context for durable data
- MSW-backed mock handlers and normalized mock data
- XState machines for stateful page workflows

Evidence:
- data-management-centre/src/routes/__root.tsx
- data-management-centre/src/queries/applications.ts
- data-management-centre/src/server/applications.ts
- data-management-centre/src/mocks/data.ts
- data-management-centre/src/mocks/server.ts
- data-management-centre/src/machines/*.ts
- data-management-centre/src/db/schema.ts

[certain] The root route is the DMC composition boundary. It provides session/auth context, global shell, navigation, and the route outlet; child routes select query and server-function work for their domain.

[certain] The application detail route is parameterized by `$appId`. It loads route data through the query layer, renders domain components, and delegates writes to server functions rather than placing persistence logic in the route component.

### 2.3.2 Functional logic

[certain] DMC is organized around command-centre screens rather than the legacy UI's single large application page:
- application list and application detail
- CDAO tagging workspace
- data-control scope
- persona/permission-dependent navigation
- server-side domain actions with query invalidation after mutations

[certain] Query modules expose the read and mutation contract used by routes. Server modules own the server-side implementation and currently use a mixture of mock data, in-memory state, and Drizzle-ready boundaries depending on domain.

[likely] The intended migration shape is to preserve route/query contracts while replacing mock implementations behind server functions with real API or database integrations. This keeps UI composition stable while the integration boundary moves.

### 2.3.3 Business logic and persona model

[certain] DMC declares an explicit e-persona model:
- itso
- itso_delegate
- collaborator
- cdao
- dms_governance
- read_only

Persona and permission utilities determine which routes, tabs, actions, and data are visible. This is a separate UI authorization surface from the AD-group enforcement in the Python API.

[certain] CDAO tagging is modeled as a query/server-function workflow:
- list tag changes by data organization
- request a tag change
- approve or reject a tag change
- write an audit entry

### 2.3.4 DMC route/query/server/session flow

```mermaid
sequenceDiagram
  participant Browser
  participant Root as __root route
  participant Session as session.ts
  participant Route as application/$appId route
  participant Query as queries/*.ts
  participant Server as server/*.ts
  participant DB as Drizzle / mock data
  participant MSW as MSW handlers

  Browser->>Root: navigate /dmc/applications/:appId
  Root->>Session: load session and persona
  Session-->>Root: user, persona, auth context
  Root->>Route: render child route
  Route->>Query: get application query options
  Query->>Server: invoke server function
  Server->>DB: read or mutate domain state
  DB-->>Server: application/tags/session data
  Server-->>Query: typed result
  Query-->>Route: cached data
  Route-->>Browser: page + action controls

  Browser->>Route: request CDAO tag change
  Route->>Query: mutation
  Query->>Server: requestTagChange()
  Server->>MSW: mock handler in current iteration
  MSW-->>Server: change request result
  Server-->>Query: updated request
  Query-->>Route: invalidate and refetch tags
```

[certain] Session helpers provide the bridge between request context, persona, and route-level authorization. The new app's server functions are therefore the place to inspect when an action's actual authorization or persistence behavior is unclear.

Evidence:
- data-management-centre/src/routes/__root.tsx
- data-management-centre/src/routes/applications/$appId/index.tsx
- data-management-centre/src/queries/tags.ts
- data-management-centre/src/server/tags.ts
- data-management-centre/src/lib/session.ts
- data-management-centre/src/lib/personas.ts
- data-management-centre/src/mocks/server.ts
- data-management-centre/src/machines/*.ts

[likely] The DMC server-function boundary is intended to make mock-to-real integration an implementation swap behind stable query contracts.
- Mock handlers provide the current iteration's response shape.
- Query invalidation keeps the route view synchronized after a mutation.

---


## 3.0 Full request lifecycle (gateway to API)

[certain]

```mermaid
flowchart TD
  UI[Legacy UI React App]
  GW[dtas-api-gateway Flask :8082]
  Auth[AuthenticationTask]
  TokenExchange[DSP token translator]
  Validate[JWTE2EVerifier]
  Block[401 response]
  Proxy[BaseApiService.call_api]
  API[data-controls-automation-api FastAPI]
  AuthDecode[auth.py get_user]
  Service[Service layer]
  DB[(PostgreSQL)]

  UI -->|GET/POST Authorization Bearer| GW
  GW --> Auth
  Auth -->|extract AM token| TokenExchange
  TokenExchange --> Validate
  Validate -->|invalid| Block
  Validate -->|valid| Proxy
  Proxy -->|X-HSBC-E2E-Trust-Token JWT| API
  API --> AuthDecode
  AuthDecode -->|username + AD groups| Service
  Service --> DB
```

Evidence:
- dtas-api-gateway/apis/api_gateway.py
- dtas-api-gateway/models/api_service.py
- dtas-api-gateway/models/authentication.py
- data-controls-automation-api/auth.py
- data-controls-automation-api/automation_api/services/cdao_tags.py

## 3.1 Governance tagging workflow map

[certain] Current authoritative governance engine is stronger in Python API service (persistent model + approval states). DMC implements a parallel model using server functions and in-memory stores for current iteration.

```mermaid
flowchart TB
  UserAction[User requests tag change]

  subgraph LegacyGovernance[Python API governance]
    Req1[Create request]
    Policy1[AD group + pending checks]
    Approve1[Primary CDAO or DMS Gov approvals]
    Persist1[Persistent DB apply + history]
  end

  subgraph DMCGovernance[DMC governance]
    Req2[createServerFn requestTagChange]
    Queue2[listTagChangesByDataOrg]
    Approve2[approveTagChange rejectTagChange]
    Audit2[writeAuditEntry in-memory log]
  end

  UserAction --> Req1 --> Policy1 --> Approve1 --> Persist1
  UserAction --> Req2 --> Queue2 --> Approve2 --> Audit2
```

[likely] Integration convergence goal is to connect DMC governance UI directly to persistent backend workflows once migration is complete.

---

## 4. Component-by-component map

## 4.1 data-controls-automation-api component map

- automation_api/collibra: Collibra transport abstraction and query building.
- automation_api/constants: domain constants used by services/dto.
- automation_api/database: ORM entities and DB foundation.
- automation_api/dependencies: DI providers for infrastructure clients.
- automation_api/dto: API payload contracts.
- automation_api/routers: endpoint definitions and route docs.
- automation_api/services: business rules and orchestration.
- dags: scheduled data sync jobs from enterprise sources.
- alembic: schema evolution scripts.
- tests: pytest tests for service health and behavior.

## 4.2 data-controls-automation-ui component map

- src/api: endpoint wrappers for DSP and app health/tags.
- src/components: reusable visual and interaction widgets.
- src/context: global state container for active app/user/session.
- src/hooks: auth and utility hooks.
- src/pages: feature screens and workflow pages.
- src/services: infrastructure services, mainly fetch wrapper.
- src/helpers/types: utilities and shared typing.
- src/mocks: local stubs.

## 4.3 data-management-centre component map

- src/routes: file-route pages and page orchestration.
- src/queries: domain query options/mutations.
- src/server: server functions for each domain.
- src/mocks: normalized sample data and handlers.
- src/components: shell/layout + domain components.
- src/lib: auth/session/guards/personas/utilities.
- src/containers: larger page sections.
- src/db: Drizzle schema and migrations config context.
- src/machines: state machine models.
- src/types: domain and auth type contracts.

---

## 5. Risks, constraints, and migration reality

[certain]
- The legacy API has persistent governance logic; DMC currently models several areas in memory/mock.
- Documentation and plan files explicitly mark multiple TODO technical debt/mocked items.

Evidence:
- data-management-centre/PLAN.md
- data-management-centre/src/server/*.ts

[likely]
- Near-term engineering challenge is contract alignment between legacy API payloads and DMC server function types when replacing mocks with real integrations.

---

## 6. Deep ramp-up strategy for a new engineer

1. Read data-management-centre/PRD.md and PLAN.md fully.
2. Trace one workflow in old stack: cdao tag request in Python API.
3. Trace same workflow in DMC stack: tags query + server + audit.
4. Compare auth/session implementation in both UIs.
5. Validate external integration boundaries: Collibra, BigQuery, LDAP.
6. Review deployment and operational assets (Docker, k8s, Prefect, Alembic).

---

## 7. Appendix: high-value files to study first

Gateway repo:
- dtas-api-gateway/app.py
- dtas-api-gateway/apis/api_gateway.py
- dtas-api-gateway/models/authentication.py
- dtas-api-gateway/models/gateway_tasks.py
- dtas-api-gateway/e2e_verifier/e2e_driver.py
- dtas-api-gateway/e2e_verifier/manifest_verifier.py
- dtas-api-gateway/settings/__init__.py

API repo:
- data-controls-automation-api/main.py
- data-controls-automation-api/automation_api/services/cdao_tags_change_request.py
- data-controls-automation-api/automation_api/services/application.py
- data-controls-automation-api/automation_api/database/data_control_scope.py
- data-controls-automation-api/flows.py

Legacy UI repo:
- data-controls-automation-ui/src/main.tsx
- data-controls-automation-ui/src/App.tsx
- data-controls-automation-ui/src/pages/Home/HomePage.tsx
- data-controls-automation-ui/src/pages/CDAO/CDAO.tsx
- data-controls-automation-ui/src/AuthWrapper.tsx

DMC repo:
- data-management-centre/src/routes/__root.tsx
- data-management-centre/src/routes/applications/$appId/index.tsx
- data-management-centre/src/queries/tags.ts
- data-management-centre/src/server/tags.ts
- data-management-centre/src/lib/personas.ts
- data-management-centre/src/lib/session.ts
