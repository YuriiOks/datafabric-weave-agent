# Change packages, 20 Oct 2026

Built on the Mac from screenshots of a downloaded copy of `main` taken on 19-20 Oct. That copy
had no git metadata, so there is no base sha: every package checks its anchors against your
checkout instead. If `main` moved under one of them, the script refuses and writes nothing;
send the refusal lines and the package is rebuilt.

None of the files in this folder are committed: not this README, not `install.py`,
`applylib.py`, `ORDER.json`, `packages/` or `bodies/`.

## Contents

| PR | Packages, in order | Branch | Cut from | PR base |
|---|---|---|---|---|
| A | `rel1-usedby`, `rel2-unmatched` | `fix/component-relationship-disclosure` | `origin/main` | `main` |
| B | `b5-previous`, `b7-rules` | `feat/fnd-16-evidence-map` | exists, at `aafebfb` | `main` |
| C | `b6-reads` | `feat/fnd-16-publication-reads` | branch B after its last commit | branch B |
| D | `dtaa1968` | `fix/unrelated-search-suggestions` | `origin/main` | `main` |
| E | `flaky-poll` | `fix/recommendation-run-polling-test` | `origin/main` | `main` |

PR C is stacked because B and C change neighbouring lines of the release checklist; retarget it
to `main` once B merges. E can go first: it removes the intermittent frontend failure the other
gates would otherwise hit.

## Steps

```bash
sha256sum -c SHA256SUMS
python3 install.py --inspect          # read-only list of every package, branch and file

# one worktree per PR, for example PR A:
git -C <main checkout> fetch origin
git -C <main checkout> worktree add -b fix/component-relationship-disclosure <path> origin/main
python3 install.py rel1-usedby <path> --check
python3 install.py rel1-usedby <path>
git -C <path> add -A && git -C <path> commit -m "<message from the table below>"
python3 install.py rel2-unmatched <path> --check
python3 install.py rel2-unmatched <path>
git -C <path> add -A && git -C <path> commit -m "<message>"
```

Every script checks the branch, a clean worktree and every anchor before it writes. A second
run reports `ALREADY APPLIED`. Nothing is staged, committed, pushed or tested by the scripts.

## Commit messages

| Package | Message |
|---|---|
| `rel1-usedby` | Show only usage links under Used by on component pages |
| `rel2-unmatched` | Count declarations that matched no component on detail pages |
| `b5-previous` | Build each refresh against the active publication's catalogue |
| `b7-rules` | Make the owner reference rules part of the refresh configuration |
| `b6-reads` | Serve bounded publication reads behind a pre-production read policy |
| `dtaa1968` | Recommend nothing for searches that describe no need |
| `flaky-poll` | Wait for the running state in the recommendation run memory test |

## Pull requests

Titles carry the ticket tags that exist; bodies are in `bodies/`. Open each as a draft.

| PR | Title | Body |
|---|---|---|
| A | `Component pages: Used by shows users only; unmatched declarations are counted` | `bodies/component-relationships.md` |
| B | `[FND-16] [DTAA-1495] Release check: test evidence, previous candidate and owner rules` | `bodies/fnd16-step2.md` |
| C | `[FND-16] [DTAA-1495] Serve bounded publication reads behind a pre-production read policy` | `bodies/fnd16-reads.md` |
| D | `[DTAA-1968] Recommend nothing for searches that describe no need` | `bodies/unrelated-search.md` |
| E | `Wait for the running state in the recommendation run memory test` | `bodies/flaky-poll.md` |

A, D and E have no FND tag, and A and E have no ticket.

## Tests to expect in CI

| PR | Test files |
|---|---|
| A | `tests/recsys/api/` (detail endpoint) |
| B | `tests/recsys/qualification/`, `tests/recsys/refresh/test_integration_catalogue_version.py`, `tests/recsys/refresh/test_integration_configuration.py` |
| C | `tests/recsys/publication/test_preproduction_read_policy.py`, `tests/recsys/publication/test_publication_router.py`, `tests/recsys/qualification/`, `tests/recsys/api/test_router.py` (nine registered paths) |
| D | `tests/recsys/pipeline/test_relevance.py`, `tests/recsys/test_contracts.py` (five empty reasons), `tests/recsys/api/test_service.py` and `test_end_to_end.py` (prompt version 2); frontend `EmptyResult.test.tsx`, `SearchComponentsPanel.test.tsx` |
| E | frontend `useRecommendationRun.memory.test.tsx` |

## Settings introduced (B and C are off or empty by default; D's check is on in live mode)

| Setting | PR | Meaning |
|---|---|---|
| `RECSYS_REFRESH_REFERENCE_RULES` | B | Owner rule file, relative to the workspace root |
| `RECSYS_PUBLICATION_READS_ENABLED` | C | Serve publication reads in pre-production |
| `RECSYS_PUBLICATION_READERS` | C | Comma-separated principal ids allowed to read |
| `RECSYS_RELEVANCE_FLOOR` | D | Below this cosine a search describes no need (default 0.2); the check never runs with `RECSYS_LLM_MODE=off` |
| `RECSYS_RELEVANCE_CLEAR` | D | At or above this cosine no check is made (default 0.55) |
