"""Typed errors of the ingest package. All derive from :class:`kp.errors.KpError`."""

from __future__ import annotations

from kp.errors import KpError


class IngestError(KpError):
    """Base class of failures while parsing or persisting source content."""


class RulebookParseError(IngestError):
    """A rulebook file could not be read (corrupt PDF, undecodable Markdown, no pages)."""


class RegisterParseError(IngestError):
    """A register workbook could not be opened."""


class StoryParseError(IngestError):
    """A story record is malformed (not an object, no key, no summary)."""


class EditionConflictError(IngestError):
    """An edition label is already held by a different source item version."""


class MissingEffectiveDateError(IngestError):
    """An edition must be created for an item version that carries no effective date."""
