"""Command-line commands of the links package: ``kp impact`` and ``kp coverage``.

The integrator wires them into ``kp.cli`` by calling :func:`add_parser` on the subparsers
object; each subcommand stores its handler as ``args.handler`` and the caller runs
``args.handler(args)`` to get the exit status.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING

from kp.config import load_settings
from kp.errors import KpError
from kp.links.coverage import CoverageReport, RuleCoverage
from kp.links.impact import IMPACT_MAX_STEPS, ImpactReport, ImpactStep
from kp.links.service import LinkService
from kp.store import Database

if TYPE_CHECKING:
    SubParsers = argparse._SubParsersAction[argparse.ArgumentParser]

EXIT_OK = 0
EXIT_FAILED = 2


def _positive_int(text: str) -> int:
    value = int(text)
    if value < 1:
        raise argparse.ArgumentTypeError("must be at least 1")
    return value


def add_parser(subparsers: SubParsers) -> None:
    """Register ``impact`` and ``coverage`` on a subparsers object.

    :param subparsers: The result of ``ArgumentParser.add_subparsers``
    """
    impact = subparsers.add_parser("impact", help="Show what a changed rule affects")
    impact.add_argument(
        "clause", help="Clause reference, e.g. 2026.1:4.2.1 or '2026.1 clause 4.2.1'"
    )
    impact.add_argument(
        "--steps", type=_positive_int, default=IMPACT_MAX_STEPS, help="How many links away to look"
    )
    impact.add_argument("--json", action="store_true", help="Write the report as JSON")
    impact.set_defaults(handler=run_impact)

    coverage = subparsers.add_parser("coverage", help="List rules with no linked test")
    coverage.add_argument("--edition", help="Edition label; defaults to the edition in force")
    coverage.add_argument(
        "--all-clauses", action="store_true", help="Treat every numbered clause as a rule"
    )
    coverage.add_argument("--json", action="store_true", help="Write the report as JSON")
    coverage.set_defaults(handler=run_coverage)


def format_path(path: tuple[ImpactStep, ...]) -> str:
    """Write a path of links as text, arrows showing the direction each link was crossed.

    :param path: The steps from the changed clause to an item
    :return: For example ``2026.1:4.2.1 <-constrained_by- REQ-001``
    """
    return " ; ".join(
        f"{step.from_key} -{step.relation.value}-> {step.to_key}"
        if step.forward
        else f"{step.from_key} <-{step.relation.value}- {step.to_key}"
        for step in path
    )


def format_impact(report: ImpactReport) -> str:
    """Render an impact report for a terminal.

    :param report: The report
    :return: Multi-line text; names the reason when nothing is affected
    """
    lines = [f"Impact of clause {report.clause} (up to {report.max_steps} steps)"]
    if report.message is not None:
        lines.append(report.message)
        return "\n".join(lines)
    for item in report.items:
        lines.append(
            f"  {item.distance}  {item.ref.item_type.value:<12} {item.ref.key}  "
            f"[{item.kind.value}]  {format_path(item.path)}"
        )
    lines.append(f"{report.stated_count} stated, {report.guessed_count} guessed")
    return "\n".join(lines)


def _rule_line(rule: RuleCoverage) -> str:
    return (
        f"  {rule.reference}  stories={rule.story_count}  "
        f"links={rule.stated_links} stated/{rule.guessed_links} guessed  {rule.title}"
    )


def format_coverage(report: CoverageReport) -> str:
    """Render a coverage report for a terminal.

    :param report: The report
    :return: Multi-line text with the untested rules first
    """
    lines = [
        f"Coverage of edition {report.edition}: {report.total_rules} rules, "
        f"{len(report.with_tests)} with a test, {len(report.without_tests)} without",
        "Rules with no test:",
        *(_rule_line(rule) for rule in report.without_tests),
        f"The list rests on {report.stated_links + report.guessed_links} links "
        f"({report.stated_links} stated, {report.guessed_links} guessed).",
    ]
    stories = report.stories_without_requirement_or_clause
    lines.append(
        "Stories with no requirement or clause (report only): "
        + (", ".join(stories) if stories else "none")
    )
    return "\n".join(lines)


@contextmanager
def _service() -> Iterator[LinkService]:
    """Open a link service in one transaction on the configured database."""
    settings = load_settings()
    database = Database.from_settings(settings)
    try:
        database.ensure_schema(settings)
        with database.transaction() as connection:
            yield LinkService(connection, thresholds=settings.thresholds)
    finally:
        database.dispose()


def _fail(command: str, exc: KpError) -> int:
    sys.stderr.write(f"kp {command}: {exc}\n")
    return EXIT_FAILED


def run_impact(args: argparse.Namespace) -> int:
    """Run ``kp impact``.

    :param args: Parsed arguments with ``clause``, ``steps`` and ``json``
    :return: 0 on success (also when the clause has no links), 2 on a platform error
    """
    try:
        with _service() as service:
            report = service.impact(args.clause, max_steps=args.steps)
    except KpError as exc:
        return _fail("impact", exc)
    text = (
        json.dumps(report.model_dump(mode="json"), indent=2) if args.json else format_impact(report)
    )
    sys.stdout.write(f"{text}\n")
    return EXIT_OK


def run_coverage(args: argparse.Namespace) -> int:
    """Run ``kp coverage``.

    :param args: Parsed arguments with ``edition``, ``all_clauses`` and ``json``
    :return: 0 on success, 2 on a platform error
    """
    try:
        with _service() as service:
            report = service.coverage(edition=args.edition, leaf_only=not args.all_clauses)
    except KpError as exc:
        return _fail("coverage", exc)
    text = (
        json.dumps(report.model_dump(mode="json"), indent=2)
        if args.json
        else format_coverage(report)
    )
    sys.stdout.write(f"{text}\n")
    return EXIT_OK
