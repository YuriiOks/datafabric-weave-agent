## What changed

One frontend test waits for the run state instead of reading it once. The test "keeps polling a run that was still in progress when the page closed" now waits until the reopened run reports `running`.

## Why

`load()` sets the state to `running` and then polls. The test waited for the poll call and then read the state immediately, but the render that publishes the new state can land after that call, so the test sometimes saw `idle`. It failed on about 4 gate runs in 10 on 15-16 Oct, on branches that touch no frontend code, and it now fails the gate on `main` the same way.

## How to verify

1. `frontend`: run the vitest file `useRecommendationRun.memory.test.tsx` repeatedly; it passes every time.
2. Negative case: the assertion still fails when `load()` stops setting `running` (for example if it set `idle`), so the test still checks the behaviour.

## Review focus

- Only the assertion changed; the hook is untouched.
