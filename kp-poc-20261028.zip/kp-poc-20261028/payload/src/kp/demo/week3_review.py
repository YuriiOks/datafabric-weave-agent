"""Week 3, the review half: a person merges the drafted spec, and the platform learns from it.

The drafted spec is merged (the reviewer's step), the next sweep loads the merged file back as
knowledge (US-23), and the story is not drafted again. Then a person edits the merged spec, and
the next sweep replaces the machine version from the edit's merge date. Every step after the
person's own goes through the platform's real code path: the sweep, the approval gate, the
load-back and the draft and publish guards.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select

from kp.app import Application
from kp.clock import FixedClock
from kp.demo.model import Check
from kp.demo.reviewed_specs import person_edits_and_merges
from kp.domain import ItemType, Relation, SourceKind
from kp.store import schema
from kp.sweep import LoadedSpec
from kp.writeback import (
    CallContext,
    DraftSpecReport,
    MergeResult,
    PublishSpecArguments,
    SpecNotDraftableError,
    draft_spec,
)

_SPEC_TYPE = "functional"
_REVIEW_DAY = timedelta(days=1)
_ALTERNATIVES = ("2026.1:4.2.2", "2026.1:4.2.3", "2026.1:4.2.4")


def evaluate_review(
    application: Application, clock: FixedClock, report: DraftSpecReport
) -> tuple[Check, ...]:
    """Merge the drafted spec, load it back, then let a person edit it.

    :param application: The application
    :param clock: The demo's clock; it moves one day for each person's step
    :param report: The drafted and published spec of the first story
    :return: The two checks of the review half
    """
    published = report.published
    if published is None:
        return (Check("A merged spec is loaded back as knowledge", False, "nothing published"),)
    story = report.story_key
    merged = application.merge_spec(story)
    clock.set(clock.now() + _REVIEW_DAY)
    loaded = _sweep_loaded(application, story)
    first = _facts(application, published.spec_id)
    redraft = draft_spec(
        story,
        runtime=application.draft_runtime(),
        publish=True,
        spec_type=_SPEC_TYPE,
        as_at=clock.today(),
    )
    refused = _publish_is_refused(application, report)
    cited = loaded.clause_refs if loaded else ()
    load_back = Check(
        "A merged spec is loaded back as knowledge and does not ask for a new draft",
        loaded is not None
        and loaded.machine_authored
        and not loaded.triggers_draft
        and first.state == "merged"
        and bool(cited)
        and first.open_targets[Relation.DERIVED_FROM] >= set(cited)
        and first.story_links == 1
        and first.open_targets[Relation.USES_TEMPLATE] != set()
        and redraft.skipped is not None
        and redraft.published is None
        and refused,
        f"story {story}: pull request {published.pr_url} merged at "
        f"{merged.merged_at.isoformat()}; the sweep loaded {published.spec_id} back "
        f"(machine-authored: {'yes' if loaded and loaded.machine_authored else 'no'}), "
        f"linked it to the story, to {len(cited)} clause(s) and to its template; drafting the "
        f"story again is skipped ('{redraft.skipped}') and publishing it again is refused: "
        f"{'yes' if refused else 'NO'}",
    )
    return (load_back, _person_edit(application, clock, merged, loaded, first))


def _person_edit(
    application: Application,
    clock: FixedClock,
    merged: MergeResult,
    loaded: LoadedSpec | None,
    before: _Facts,
) -> Check:
    name = "A person's edit of the merged spec replaces it from the edit's merge date"
    if loaded is None or not loaded.clause_refs:
        return Check(name, False, "no spec was loaded back to edit")
    dropped = loaded.clause_refs[0]
    added = next(ref for ref in _ALTERNATIVES if ref not in loaded.clause_refs)
    clock.set(clock.now() + _REVIEW_DAY)
    edit = person_edits_and_merges(application, merged, replace=(dropped, added))
    clock.set(clock.now() + _REVIEW_DAY)
    after_loaded = _sweep_loaded(application, loaded.story_key)
    after = _facts(application, loaded.spec_key)
    closed_at = after.closed_at.get(dropped)
    opened_at = after.opened_at.get(added)
    ok = (
        after_loaded is not None
        and not after_loaded.machine_authored
        and not after_loaded.triggers_draft
        and after.state == "merged"
        and not after.machine_authored
        and added in after_loaded.clause_refs
        and dropped not in after_loaded.clause_refs
        and closed_at == edit.merged_at
        and opened_at == edit.merged_at
        and after.open_targets[Relation.DERIVED_FROM]
        == set(after_loaded.clause_refs) | set(after_loaded.requirement_ids)
        and after.story_links == 1
    )
    return Check(
        name,
        ok,
        f"edit merged at {edit.merged_at.isoformat()}: the link to {dropped} closed at "
        f"{closed_at.isoformat() if closed_at else '-'}, the link to {added} opened at "
        f"{opened_at.isoformat() if opened_at else '-'}; the spec is "
        f"{'no longer' if not after.machine_authored else 'still'} machine-authored; "
        f"{len(before.open_targets[Relation.DERIVED_FROM])} derived-from link(s) before, "
        f"{len(after.open_targets[Relation.DERIVED_FROM])} after, one link from the story",
    )


def _sweep_loaded(application: Application, story_key: str) -> LoadedSpec | None:
    """Sweep the code host (which holds the spec repository) and find the story's loaded spec."""
    summary = application.sweep([SourceKind.GITHUB])
    application.after_sweep()
    return next((item for item in summary.loaded_specs if item.story_key == story_key), None)


def _publish_is_refused(application: Application, report: DraftSpecReport) -> bool:
    published = report.published
    if published is None:
        return False
    context = CallContext(
        session_id="demo-merged-spec",
        caller="demo-agent",
        agent="demo-agent",
        domains=("payments",),
    )
    try:
        application.write_tools().publish_spec(
            context,
            PublishSpecArguments(
                story_key=report.story_key,
                spec_markdown=report.markdown,
                template_id=published.template_id,
                template_version=published.template_version,
            ),
        )
    except SpecNotDraftableError:
        return True
    return False


class _Facts:
    """What the database says about one spec: its row and its links."""

    def __init__(self) -> None:
        self.state = ""
        self.machine_authored = True
        self.story_links = 0
        self.open_targets: dict[Relation, set[str]] = {
            Relation.DERIVED_FROM: set(),
            Relation.USES_TEMPLATE: set(),
        }
        self.closed_at: dict[str, datetime] = {}
        self.opened_at: dict[str, datetime] = {}


def _facts(application: Application, spec_key: str) -> _Facts:
    facts = _Facts()
    with application.database.transaction() as connection:
        row = connection.execute(
            select(schema.spec.c.state, schema.spec.c.machine_authored).where(
                schema.spec.c.spec_id == spec_key
            )
        ).first()
        if row is not None:
            facts.state, facts.machine_authored = row.state, row.machine_authored
        links = connection.execute(
            select(schema.link).where(
                (
                    (schema.link.c.source_item_type == ItemType.SPEC.value)
                    & (schema.link.c.source_key == spec_key)
                )
                | (
                    (schema.link.c.target_item_type == ItemType.SPEC.value)
                    & (schema.link.c.target_key == spec_key)
                )
            )
        ).all()
    for link in links:
        relation = Relation(link.relation)
        if link.valid_to is None:
            if relation is Relation.SPECIFIED_BY:
                facts.story_links += 1
            elif relation in facts.open_targets:
                facts.open_targets[relation].add(link.target_key)
                facts.opened_at[link.target_key] = link.valid_from
        elif relation is Relation.DERIVED_FROM:
            facts.closed_at[link.target_key] = link.valid_to
    return facts
