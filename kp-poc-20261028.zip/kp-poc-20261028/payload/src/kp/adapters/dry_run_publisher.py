"""Seam: a spec publisher that writes no repository, for machines without a working git.

It keeps what the local git publisher keeps in its repository: one pull request record per
branch, a commit identity derived from the content, and "same branch, same pull request". The
records are a small JSON file, so the idempotence survives between runs. Nothing leaves the
machine and nothing is committed anywhere.

A record also keeps the spec file's path and text, so :meth:`DryRunSpecPublisher.merge` can mark
it merged and :meth:`DryRunSpecPublisher.merged_specs` can list the merged files for the spec
repository reader, exactly as the git publisher does from its base branch.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Final

from kp.clock import Clock, SystemClock
from kp.errors import KpError
from kp.sources.spec_repo import MergedSpecFile
from kp.writeback import (
    BranchNotPermittedError,
    MergeResult,
    PublishError,
    PublishRequest,
    PublishResult,
    RepositoryNotPermittedError,
)

DRY_RUN_SCHEME: Final = "dry-run-pr"
_OPEN: Final = "open"
_MERGED: Final = "merged"

_Record = dict[str, str | int]


class DryRunStateError(KpError):
    """The dry-run record file exists but is not readable."""


class DryRunSpecPublisher:
    """Records spec publications without a repository.

    :param state_path: JSON file holding the pull request records; created when first needed
    :param repository: The ``<owner>/<repository>`` the records stand for; another one is refused
    :param base_branch: The branch pull requests target; publishing to it is refused
    :param clock: Time source for merge dates
    """

    def __init__(
        self,
        state_path: Path,
        *,
        repository: str | None = None,
        base_branch: str = "main",
        clock: Clock | None = None,
    ) -> None:
        self._path = state_path
        self._repository = repository
        self._base = base_branch
        self._clock = clock or SystemClock()

    def publish(self, request: PublishRequest) -> PublishResult:
        """Record the spec on its branch and return the pull request record.

        :param request: A request that passed the write limits
        :return: The record; ``created`` only the first time a branch is published and
            ``committed`` only when the content differs from the last publication
        :raises kp.writeback.RepositoryNotPermittedError: If another repository is named
        :raises kp.writeback.BranchNotPermittedError: If the branch is the base branch
        :raises kp.writeback.PublishError: If the branch's pull request is no longer open
        :raises DryRunStateError: If the record file cannot be read
        """
        if (
            self._repository is not None
            and request.repository.casefold() != self._repository.casefold()
        ):
            raise RepositoryNotPermittedError("Repository is not the configured spec repository")
        if request.branch == self._base:
            raise BranchNotPermittedError(
                "Branch is the base branch; specs go through a pull request"
            )
        records = self._read()
        digest = hashlib.sha256(f"{request.path}\n{request.content}".encode()).hexdigest()
        commit_sha = digest[:40]
        existing = records.get(request.branch)
        if existing is None:
            number = max((int(record["number"]) for record in records.values()), default=0) + 1
            records[request.branch] = {
                "number": number,
                "commit_sha": commit_sha,
                "path": request.path,
                "content": request.content,
                "state": _OPEN,
            }
            created, committed = True, True
        else:
            if existing.get("state", _OPEN) != _OPEN:
                raise PublishError("The pull request for this branch is no longer open")
            number = int(existing["number"])
            committed = existing["commit_sha"] != commit_sha
            existing.update(commit_sha=commit_sha, path=request.path, content=request.content)
            created = False
        self._write(records)
        return PublishResult(
            branch=request.branch,
            pr_url=f"{DRY_RUN_SCHEME}:{number}",
            pr_number=number,
            commit_sha=commit_sha,
            created=created,
            committed=committed,
        )

    def merge(self, branch: str) -> MergeResult:
        """Mark the pull request of a branch merged, as of the clock's time.

        :param branch: The branch the spec was published on
        :return: The merge; ``merged`` is False when it was already merged
        :raises kp.writeback.PublishError: If the branch has no pull request record
        :raises DryRunStateError: If the record file cannot be read
        """
        records = self._read()
        record = records.get(branch)
        if record is None or "path" not in record:
            raise PublishError("There is no open pull request for this branch")
        merged = record.get("state", _OPEN) != _MERGED
        if merged:
            record.update(state=_MERGED, merged_at=self._clock.now().isoformat())
            self._write(records)
        return MergeResult(
            branch=branch,
            path=str(record["path"]),
            merged_at=datetime.fromisoformat(str(record["merged_at"])),
            commit_sha=str(record["commit_sha"]),
            merged=merged,
        )

    def merged_specs(self) -> list[MergedSpecFile]:
        """List the merged spec files, each with the date of its newest merge.

        :return: One entry per file path that a merged pull request wrote
        :raises DryRunStateError: If the record file cannot be read
        """
        newest: dict[str, _Record] = {}
        for record in self._read().values():
            path = str(record.get("path", ""))
            if record.get("state") != _MERGED or not path:
                continue
            held = newest.get(path)
            if held is None or str(record["merged_at"]) >= str(held["merged_at"]):
                newest[path] = record
        return [
            MergedSpecFile(
                path=path,
                content=str(record["content"]).encode("utf-8"),
                merged_at=datetime.fromisoformat(str(record["merged_at"])),
            )
            for path, record in sorted(newest.items())
        ]

    def _read(self) -> dict[str, _Record]:
        if not self._path.exists():
            return {}
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise DryRunStateError("The dry-run publication record is unreadable") from exc
        if not isinstance(data, dict):
            raise DryRunStateError("The dry-run publication record is malformed")
        return {str(branch): dict(record) for branch, record in data.items()}

    def _write(self, records: dict[str, _Record]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(records, sort_keys=True, indent=2) + "\n", encoding="utf-8"
        )
