"""Persistence of parsed content: editions, clauses, requirements, stories, review items.

Small classes that take a :class:`sqlalchemy.Connection` from ``Database.transaction()``.
Every ``save`` is idempotent: storing what is already there adds nothing (no ``ON CONFLICT``,
so the same code runs on SQLite and PostgreSQL).
"""

from __future__ import annotations

from collections.abc import Collection, Sequence
from datetime import date
from enum import StrEnum

from sqlalchemy import Connection, RowMapping, delete, insert, select

from kp.domain import (
    Clause,
    ClauseRef,
    Edition,
    ItemKey,
    Requirement,
    ReviewItem,
    ReviewState,
    Story,
    StoryLink,
)
from kp.ingest.errors import EditionConflictError
from kp.store.schema import clause, edition, requirement, review_item, story


class StoryChange(StrEnum):
    """How a stored story relates to the one before it."""

    NEW = "new"
    CHANGED = "changed"
    UNCHANGED = "unchanged"


class EditionStore:
    """Editions of the regulatory document.

    :param connection: An open connection inside a transaction
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def ensure(self, label: str, effective_date: date, key: ItemKey, title: str = "") -> bool:
        """Create the edition row unless the same source item version already created it.

        :param label: Edition label, the primary key
        :param effective_date: The date the edition takes effect
        :param key: The source item version the edition was read from
        :param title: Display title
        :return: True when a row was created; False when it already exists for this version
        :raises EditionConflictError: If the label belongs to a different source item or version,
            so loading these clauses would silently add nothing
        """
        exists = self._connection.execute(
            select(edition.c.source, edition.c.item_id, edition.c.version).where(
                edition.c.label == label
            )
        ).first()
        if exists is not None:
            if (exists.source, exists.item_id, exists.version) != (
                key.source.value,
                key.item_id,
                key.version,
            ):
                raise EditionConflictError("The edition label is held by another item version")
            return False
        self._connection.execute(
            insert(edition).values(
                label=label,
                effective_date=effective_date,
                title=title,
                source=key.source.value,
                item_id=key.item_id,
                version=key.version,
            )
        )
        return True

    def get(self, label: str) -> Edition | None:
        """Read one edition.

        :param label: Edition label
        :return: The edition, or ``None`` if unknown
        """
        row = self._connection.execute(select(edition).where(edition.c.label == label)).first()
        return Edition.model_validate(row._mapping) if row is not None else None


class ClauseStore:
    """Clauses of loaded editions.

    :param connection: An open connection inside a transaction
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def save(self, clauses: Sequence[Clause]) -> int:
        """Store clauses that are not stored yet.

        A clause number already stored for the edition is left alone; the caller guards the
        edition itself with :meth:`EditionStore.ensure`, which refuses a label held by another
        item version.

        :param clauses: Clauses of one or more editions whose edition rows exist
        :return: How many were inserted
        """
        stored = {
            (row.edition, row.number)
            for row in self._connection.execute(
                select(clause.c.edition, clause.c.number).where(
                    clause.c.edition.in_({item.ref.edition for item in clauses})
                )
            )
        }
        rows = [
            {
                "edition": item.ref.edition,
                "number": item.ref.number,
                "title": item.title,
                "page": item.page,
                "char_start": item.char_start,
                "char_end": item.char_end,
                "text": item.text,
                "structure_score": item.structure_score,
                "parent_number": item.parent_ref.number if item.parent_ref else None,
            }
            for item in clauses
            if (item.ref.edition, item.ref.number) not in stored
        ]
        if rows:
            self._connection.execute(insert(clause), rows)
        return len(rows)

    def list_for_edition(self, label: str) -> list[Clause]:
        """Read every clause of an edition in reading order.

        :param label: Edition label
        :return: The clauses sorted by clause number
        """
        rows = self._connection.execute(select(clause).where(clause.c.edition == label))
        return sorted((_to_clause(row._mapping) for row in rows), key=lambda item: item.ref)


def _to_clause(values: RowMapping) -> Clause:
    ref = ClauseRef(values["edition"], values["number"])
    parent = values["parent_number"]
    return Clause(
        ref=ref,
        title=values["title"],
        page=values["page"],
        char_start=values["char_start"],
        char_end=values["char_end"],
        text=values["text"],
        structure_score=values["structure_score"],
        parent_ref=ClauseRef(ref.edition, parent) if parent else None,
    )


class RequirementStore:
    """Requirements (register rows).

    :param connection: An open connection inside a transaction
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def replace_for_item(
        self,
        key: ItemKey,
        requirements: Sequence[Requirement],
        *,
        keep_sheets: Collection[str] = (),
    ) -> int:
        """Store the requirements of one register version.

        A requirement id is ``<item_id>:<sheet>:<row>`` without the version, so a newer
        version of the register replaces the rows of the older one. Rows of this version
        that are already stored are left alone. Sheets named in ``keep_sheets`` (those the
        newer version could not be read from) keep their rows from older versions, so knowledge
        that was serving is not dropped because its replacement was refused.

        :param key: The register version the requirements come from
        :param requirements: Its requirements
        :param keep_sheets: Sheets whose older-version rows must stay
        :return: How many were inserted
        """
        item = (requirement.c.source == key.source.value) & (requirement.c.item_id == key.item_id)
        older = item & (requirement.c.version != key.version)
        if keep_sheets:
            older = older & requirement.c.sheet.not_in(keep_sheets)
        self._connection.execute(delete(requirement).where(older))
        stored = set(
            self._connection.execute(select(requirement.c.requirement_id).where(item)).scalars()
        )
        rows = [
            row.model_dump(mode="json") for row in requirements if row.requirement_id not in stored
        ]
        if rows:
            self._connection.execute(insert(requirement), rows)
        return len(rows)

    def list_for_item(self, key: ItemKey) -> list[Requirement]:
        """Read the stored requirements of an item, ordered by sheet and row.

        :param key: Source and item id; the version is ignored (one version is kept)
        :return: The requirements
        """
        rows = self._connection.execute(
            select(requirement).where(
                (requirement.c.source == key.source.value) & (requirement.c.item_id == key.item_id)
            )
        )
        return sorted(
            (Requirement.model_validate(row._mapping) for row in rows),
            key=lambda item: (item.sheet, item.row_number),
        )


class StoryStore:
    """Stories with their change fingerprint.

    :param connection: An open connection inside a transaction
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def save(self, item: Story) -> StoryChange:
        """Store a story version and say whether it needs reprocessing.

        A version already stored changes nothing. Otherwise the new fingerprint is compared
        with the story's latest stored version (versions are ordered as text, which is
        chronological because the normaliser writes ``updated`` times as UTC ISO-8601; a
        version that is not a time, such as a fallback label, sorts by its text): equal means a
        status-only move or a re-export; different means the story must be reprocessed.

        :param item: The story
        :return: ``NEW`` for a first version, ``CHANGED`` for a changed fingerprint,
            ``UNCHANGED`` otherwise (the row is still stored when the version is new)
        """
        latest = self._connection.execute(
            select(story.c.version, story.c.fingerprint)
            .where(story.c.story_key == item.story_key)
            .order_by(story.c.version.desc())
        ).all()
        if any(row.version == item.version for row in latest):
            return StoryChange.UNCHANGED
        fingerprint = item.fingerprint()
        self._connection.execute(
            insert(story).values(
                story_key=item.story_key,
                version=item.version,
                summary=item.summary,
                description=item.description,
                acceptance_criteria=item.acceptance_criteria,
                links=[link.model_dump() for link in item.links],
                parent_key=item.parent_key,
                status=item.status,
                domain=item.domain,
                fingerprint=fingerprint,
            )
        )
        if not latest:
            return StoryChange.NEW
        return (
            StoryChange.UNCHANGED if latest[0].fingerprint == fingerprint else StoryChange.CHANGED
        )

    def get(self, story_key: str, version: str) -> Story | None:
        """Read one story version.

        :param story_key: The tracker key
        :param version: The version
        :return: The story, or ``None``
        """
        row = self._connection.execute(
            select(story).where((story.c.story_key == story_key) & (story.c.version == version))
        ).first()
        if row is None:
            return None
        values = dict(row._mapping)
        values.pop("fingerprint")
        values["links"] = tuple(StoryLink.model_validate(link) for link in values["links"])
        return Story.model_validate(values)


class ReviewStore:
    """Review items.

    :param connection: An open connection inside a transaction
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def add(self, item: ReviewItem) -> bool:
        """Store a review item unless its id exists (re-runs ask the same question once).

        :param item: The item
        :return: True when it was inserted
        """
        exists = self._connection.execute(
            select(review_item.c.review_id).where(review_item.c.review_id == item.review_id)
        ).first()
        if exists is not None:
            return False
        values = item.model_dump(mode="json", exclude={"created_at", "resolved_at"})
        self._connection.execute(
            insert(review_item).values(
                **values, created_at=item.created_at, resolved_at=item.resolved_at
            )
        )
        return True

    def get(self, review_id: str) -> ReviewItem | None:
        """Read one review item.

        :param review_id: The item's id
        :return: The item, or ``None`` if unknown
        """
        row = self._connection.execute(
            select(review_item).where(review_item.c.review_id == review_id)
        ).first()
        return ReviewItem.model_validate(row._mapping) if row is not None else None

    def list_open(self) -> list[ReviewItem]:
        """Read the open review items.

        :return: Open items, ordered by id
        """
        rows = self._connection.execute(
            select(review_item)
            .where(review_item.c.state == ReviewState.OPEN.value)
            .order_by(review_item.c.review_id)
        )
        return [ReviewItem.model_validate(row._mapping) for row in rows]
