"""``kp web``: what it starts, from which database, and that the other commands need no extra."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

import pytest
import uvicorn

from kp.cli import build_parser, main
from kp.config import Mode, Settings
from kp.errors import ConfigurationError
from kp.web.cli import plan_launch
from web.conftest import WebWorld

ALL_INTERFACES = "0.0.0.0"  # noqa: S104 - the address the guard must refuse


def _args(*arguments: str) -> argparse.Namespace:
    return build_parser().parse_args(["web", *arguments])


@pytest.fixture(autouse=True)
def clean_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    """Make the command independent of the KP_ variables of the machine running the tests."""
    for name in [name for name in os.environ if name.startswith("KP_")]:
        monkeypatch.delenv(name)


def test_the_command_is_registered_with_its_defaults() -> None:
    args = build_parser().parse_args(["web"])

    assert args.command == "web"
    assert args.host == "127.0.0.1"
    assert args.port == 8090
    assert args.db is None


def test_other_commands_start_without_the_web_libraries() -> None:
    code = (
        "import sys; import kp.cli; "
        "assert not {'fastapi', 'uvicorn', 'jinja2'} & set(sys.modules), sorted(sys.modules)"
    )

    result = subprocess.run(  # noqa: S603 - fixed arguments, the interpreter running the tests
        [sys.executable, "-I", "-c", code], capture_output=True, text=True, check=False
    )

    assert result.returncode == 0, result.stderr


def test_a_demo_database_brings_its_identity_mapping_and_connectivity_evidence(
    web_world: WebWorld,
) -> None:
    database = web_world.world.workdir / "kp.db"

    plan = plan_launch(_args("--db", str(database)))

    assert (
        plan.settings.database_url.get_secret_value() == f"sqlite+pysqlite:///{database.resolve()}"
    )
    assert plan.settings.identity_mapping_file == web_world.world.staged.identity_mapping.resolve()
    assert plan.connectivity is not None
    assert plan.connectivity.database_url.get_secret_value().endswith("connectivity.db")
    assert plan.connectivity.data_dir == web_world.world.workdir.resolve() / "connectivity"
    assert plan.clock is None
    assert (plan.host, plan.port) == ("127.0.0.1", 8090)


def test_a_fixed_today_can_be_given_for_a_database_built_on_future_dates(
    web_world: WebWorld,
) -> None:
    database = web_world.world.workdir / "kp.db"

    plan = plan_launch(_args("--db", str(database), "--today", "2026-11-20"))

    assert plan.clock is not None
    assert plan.clock.today().isoformat() == "2026-11-20"


def test_a_database_that_does_not_exist_is_refused_before_one_is_created(tmp_path: Path) -> None:
    missing = tmp_path / "nothing.db"

    with pytest.raises(ConfigurationError, match="No database file"):
        plan_launch(_args("--db", str(missing)))

    assert not missing.exists()


def test_an_address_other_than_loopback_needs_a_trusted_proxy() -> None:
    with pytest.raises(ConfigurationError, match="not a loopback address"):
        plan_launch(_args("--host", ALL_INTERFACES))

    real = Settings(_env_file=None).model_copy(update={"mode": Mode.REAL})
    plan = plan_launch(_args("--host", ALL_INTERFACES, "--trusted-proxy"), base=real)
    assert plan.host == ALL_INTERFACES


def test_a_trusted_proxy_is_refused_in_local_mode_where_any_client_chooses_who_it_is() -> None:
    with pytest.raises(ConfigurationError, match="needs KP_MODE=real"):
        plan_launch(
            _args("--host", ALL_INTERFACES, "--trusted-proxy"), base=Settings(_env_file=None)
        )


def test_the_command_reports_a_missing_database_and_exits_with_2(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    status = main(["web", "--db", str(tmp_path / "nothing.db")])

    assert status == 2
    assert "kp web: No database file" in capsys.readouterr().err


def test_the_command_serves_the_application_without_an_access_log(
    web_world: WebWorld, monkeypatch: pytest.MonkeyPatch
) -> None:
    started: dict[str, object] = {}

    def fake_run(app: object, **options: object) -> None:
        started.update(app=app, **options)

    monkeypatch.setattr(uvicorn, "run", fake_run)
    database = web_world.world.workdir / "kp.db"

    status = main(["web", "--db", str(database), "--port", "8123", "--today", "2026-11-20"])

    assert status == 0
    assert started["host"] == "127.0.0.1"
    assert started["port"] == 8123
    assert started["access_log"] is False  # the access log would print what people asked


def test_the_command_says_what_to_install_when_the_libraries_are_missing(
    web_world: WebWorld, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setitem(sys.modules, "uvicorn", None)  # makes `import uvicorn` fail

    status = main(["web", "--db", str(web_world.world.workdir / "kp.db")])

    assert status == 2
    assert "install the 'web' extra" in capsys.readouterr().err
