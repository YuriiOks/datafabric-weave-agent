"""``kp corrections add`` and ``kp corrections report``: the product owner's log (US-24)."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING

from sqlalchemy import Connection

from kp.clock import SystemClock
from kp.config import load_settings
from kp.corrections.report import build_report, format_report
from kp.corrections.store import CorrectionLog
from kp.errors import KpError
from kp.store import Database

if TYPE_CHECKING:
    SubParsers = argparse._SubParsersAction[argparse.ArgumentParser]

EXIT_OK = 0
EXIT_FAILED = 2


def add_parser(subparsers: SubParsers) -> None:
    """Register ``corrections`` on a subparsers object.

    :param subparsers: The result of ``ArgumentParser.add_subparsers``
    """
    parser = subparsers.add_parser(
        "corrections", help="Record what a product owner corrected in a spec, and report on it"
    )
    commands = parser.add_subparsers(dest="corrections_command", required=True)
    add = commands.add_parser("add", help="Record one correction of a drafted spec")
    add.add_argument("spec_id", help="Spec identity, e.g. spec-abc-123")
    add.add_argument("--correction", required=True, help="What was changed")
    add.add_argument("--reason", required=True, help="Why it was changed")
    add.add_argument(
        "--wrong-clause", action="store_true", help="The draft cited a clause that was wrong"
    )
    add.set_defaults(handler=run_add)
    report = commands.add_parser(
        "report", help="Citation rate, wrong-clause count and correction count per spec"
    )
    report.add_argument("--json", action="store_true", help="Write the report as JSON")
    report.set_defaults(handler=run_report)


@contextmanager
def _connection() -> Iterator[Connection]:
    settings = load_settings()
    database = Database.from_settings(settings)
    try:
        database.ensure_schema(settings)
        with database.transaction() as connection:
            yield connection
    finally:
        database.dispose()


def run_add(args: argparse.Namespace) -> int:
    """Run ``kp corrections add``.

    :param args: Parsed arguments (``spec_id``, ``correction``, ``reason``, ``wrong_clause``)
    :return: 0 when the correction was recorded, 2 otherwise
    """
    try:
        with _connection() as connection:
            stored = CorrectionLog(connection, SystemClock()).add(
                args.spec_id, args.correction, args.reason, wrong_clause=args.wrong_clause
            )
    except KpError as exc:
        sys.stderr.write(f"kp corrections: {exc}\n")
        return EXIT_FAILED
    sys.stdout.write(f"recorded correction {stored.correction_id} for {stored.spec_id}\n")
    return EXIT_OK


def run_report(args: argparse.Namespace) -> int:
    """Run ``kp corrections report``.

    :param args: Parsed arguments (``json``)
    :return: 0 on success, 2 on a platform error
    """
    try:
        with _connection() as connection:
            report = build_report(connection)
    except KpError as exc:
        sys.stderr.write(f"kp corrections: {exc}\n")
        return EXIT_FAILED
    text = (
        json.dumps(report.model_dump(mode="json"), indent=2) if args.json else format_report(report)
    )
    sys.stdout.write(f"{text}\n")
    return EXIT_OK
