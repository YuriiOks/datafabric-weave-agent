"""``kp connectivity discover|run|report``.

The integrator wires :func:`add_parser` into ``kp.cli``; each subcommand's handler is
:func:`handle`. :func:`main` runs the same command standalone.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from kp.config import load_settings
from kp.connectivity.models import ItemStatus, RunResult
from kp.connectivity.report import build_report, render_markdown
from kp.connectivity.wiring import Harness, build_harness
from kp.domain import ExitResult, RunOutcome
from kp.errors import KpError

COMMAND = "connectivity"


def add_parser(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Register ``connectivity`` and its three subcommands.

    :param subparsers: The subparsers action of the main parser
    :return: The ``connectivity`` parser, with :func:`handle` set as its ``handler`` default
    """
    parser = subparsers.add_parser(
        COMMAND, help="Run the connectivity job and exit-criteria report"
    )
    actions = parser.add_subparsers(dest="connectivity_command", required=True)
    actions.add_parser("discover", help="List and keep the tool signatures of the three servers")
    run = actions.add_parser("run", help="Fetch, store and extract the nine sample items")
    run.add_argument("--skip-extraction", action="store_true", help="Store raw objects only")
    run.add_argument(
        "--probe-errors",
        action="store_true",
        help="Afterwards provoke a bad credential and parameter",
    )
    report = actions.add_parser("report", help="Score the exit criteria from what the runs left")
    report.add_argument("--format", choices=("markdown", "json"), default="markdown")
    report.add_argument(
        "--output", type=Path, help="Write the report here instead of standard output"
    )
    parser.set_defaults(handler=handle)
    return parser


def handle(args: argparse.Namespace) -> int:
    """Run one ``connectivity`` subcommand.

    :param args: Parsed arguments from a parser built with :func:`add_parser`
    :return: The process exit status: 0 on success, 1 on a failed run, a failed criterion or a
        typed error
    """
    try:
        harness = build_harness(load_settings())
    except KpError as exc:
        _fail(exc)
        return 1
    try:
        if args.connectivity_command == "discover":
            return _discover(harness)
        if args.connectivity_command == "run":
            return _run(harness, skip_extraction=args.skip_extraction, probe=args.probe_errors)
        return _report(harness, args.format, args.output)
    except KpError as exc:
        _fail(exc)
        return 1
    finally:
        harness.close()


def main(argv: Sequence[str] | None = None) -> int:
    """Run ``connectivity`` as its own program.

    :param argv: Arguments after the program name; defaults to ``sys.argv[1:]``
    :return: The exit status
    """
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))
    args = parser.parse_args(argv)
    handler: object = args.handler
    assert callable(handler)  # noqa: S101 - set by add_parser
    status = handler(args)
    assert isinstance(status, int)  # noqa: S101 - handlers return a status
    return status


def _discover(harness: Harness) -> int:
    result = harness.job.discover()
    for namespace, count in sorted(result.tools_by_namespace.items()):
        print(f"{namespace}: {count} tools kept")
    print(f"Run {result.run_id}: {result.outcome.value}")
    return 0 if result.outcome is RunOutcome.SUCCEEDED else 1


def _run(harness: Harness, *, skip_extraction: bool, probe: bool) -> int:
    result = harness.job.run(skip_extraction=skip_extraction)
    _print_items(result)
    status = 0 if result.outcome is RunOutcome.SUCCEEDED else 1
    if probe:
        probed = harness.job.probe_errors()
        for name, error in sorted(probed.probes.items()):
            print(f"probe {name}: {error}")
        status = status or (0 if probed.outcome is RunOutcome.SUCCEEDED else 1)
    return status


def _print_items(result: RunResult) -> None:
    for item in result.items:
        extra = item.error_class or (item.extraction_status.value if item.extraction_status else "")
        print(f"{item.item_id}: {item.status.value} {extra}".rstrip())
    unchanged = sum(1 for item in result.items if item.status is ItemStatus.UNCHANGED)
    extracted = result.touched_count - result.stored_count
    print(
        f"Run {result.run_id}: {result.outcome.value}; stored {result.stored_count}, "
        f"extracted {extracted}, unchanged {unchanged}, failed {len(result.failed_items)}"
    )


def _report(harness: Harness, output_format: str, output: Path | None) -> int:
    report = build_report(harness.evidence())
    text = (
        render_markdown(report)
        if output_format == "markdown"
        else report.model_dump_json(indent=2) + "\n"
    )
    if output is None:
        sys.stdout.write(text)
    else:
        output.write_text(text, encoding="utf-8")
        print(f"Report written to {output}")
    return 1 if report.count(ExitResult.FAIL) else 0


def _fail(exc: KpError) -> None:
    print(f"kp connectivity: {exc}", file=sys.stderr)
