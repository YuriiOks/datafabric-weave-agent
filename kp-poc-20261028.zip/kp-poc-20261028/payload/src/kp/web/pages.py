"""The eight pages: each reads its view and draws its template."""

from __future__ import annotations

import logging
from collections.abc import Callable

from fastapi import FastAPI
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
from starlette.responses import HTMLResponse

from kp.web.errors import Problem
from kp.web.identity import Viewer
from kp.web.query import QueryForm
from kp.web.render import make_frame, render_page
from kp.web.state import WebState
from kp.web.views.audit import read_audit
from kp.web.views.connectivity import read_connectivity
from kp.web.views.coverage import read_coverage
from kp.web.views.impact import read_impact
from kp.web.views.overview import read_overview
from kp.web.views.rules import read_rule
from kp.web.views.search import read_search
from kp.web.views.specs import read_specs

logger = logging.getLogger(__name__)

SEARCH_TITLE = "Search the rules"


class Pages:
    """Registers the pages on an application.

    :param state: The shared state
    :param templates: The template set
    """

    def __init__(self, state: WebState, templates: Jinja2Templates) -> None:
        self._state = state
        self._templates = templates

    def register(self, app: FastAPI) -> None:
        """Add every page route.

        :param app: The application to add them to
        """
        for path, handler in self._routes():
            app.add_api_route(path, handler, methods=["GET"], response_class=HTMLResponse)

    def _routes(self) -> list[tuple[str, Callable[[Request], HTMLResponse]]]:
        return [
            ("/", self.overview),
            ("/search", self.search),
            ("/rule", self.rule),
            ("/impact", self.impact),
            ("/coverage", self.coverage),
            ("/specs", self.specs),
            ("/connectivity", self.connectivity),
            ("/audit", self.audit),
        ]

    def _draw(
        self,
        request: Request,
        viewer: Viewer,
        template: str,
        title: str,
        problem: Problem | None,
        **context: object,
    ) -> HTMLResponse:
        state = self._state
        frame = make_frame(
            request,
            viewer,
            state.identity.selectable_users,
            title=title,
            today=state.application.clock.today(),
        )
        response = render_page(self._templates, request, template, frame, problem, context)
        # The path and the status only: the query string holds what was asked.
        logger.info(
            "Page served",
            extra={"page": request.url.path, "status": response.status_code, "user": viewer.user},
        )
        return response

    def overview(self, request: Request) -> HTMLResponse:
        """The overview page."""
        viewer = self._state.viewer(request)
        view = read_overview(self._state, viewer)
        return self._draw(request, viewer, "overview.html", "Overview", view.problem, view=view)

    def search(self, request: Request) -> HTMLResponse:
        """The search page."""
        viewer = self._state.viewer(request)
        view = read_search(self._state, viewer, QueryForm(request.query_params))
        return self._draw(request, viewer, "search.html", SEARCH_TITLE, view.problem, view=view)

    def rule(self, request: Request) -> HTMLResponse:
        """The rule page."""
        viewer = self._state.viewer(request)
        view = read_rule(self._state, viewer, QueryForm(request.query_params))
        return self._draw(
            request, viewer, "rule.html", "A rule as at a date", view.problem, view=view
        )

    def impact(self, request: Request) -> HTMLResponse:
        """The impact page."""
        viewer = self._state.viewer(request)
        view = read_impact(self._state, viewer, QueryForm(request.query_params))
        return self._draw(
            request, viewer, "impact.html", "What a change affects", view.problem, view=view
        )

    def coverage(self, request: Request) -> HTMLResponse:
        """The coverage page."""
        viewer = self._state.viewer(request)
        view = read_coverage(self._state, viewer, QueryForm(request.query_params))
        return self._draw(
            request, viewer, "coverage.html", "Rules without tests", view.problem, view=view
        )

    def specs(self, request: Request) -> HTMLResponse:
        """The specs page."""
        viewer = self._state.viewer(request)
        view = read_specs(self._state, viewer, QueryForm(request.query_params))
        return self._draw(request, viewer, "specs.html", "Draft a spec", view.problem, view=view)

    def connectivity(self, request: Request) -> HTMLResponse:
        """The connectivity page."""
        viewer = self._state.viewer(request)
        view = read_connectivity(self._state, viewer)
        return self._draw(
            request, viewer, "connectivity.html", "Connectivity", view.problem, view=view
        )

    def audit(self, request: Request) -> HTMLResponse:
        """The audit page."""
        viewer = self._state.viewer(request)
        view = read_audit(self._state, viewer, QueryForm(request.query_params))
        return self._draw(request, viewer, "audit.html", "Audit trail", view.problem, view=view)
