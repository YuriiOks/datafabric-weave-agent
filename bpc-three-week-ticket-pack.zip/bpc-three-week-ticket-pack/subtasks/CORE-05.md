---
pack_id: "bpc-sep26-v1"
local_id: "CORE-05"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Implement the durable refresh job framework and recovery contract"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 5
scope: "foundation"
create_by_default: true
planned_start: "2026-09-22"
planned_due: "2026-09-22"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-05"
architecture_sections: ["source-refresh","publication","security"]
---

# Implement the durable refresh job framework and recovery contract

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-05** is not a Jira key.
- Estimate: **5 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-22 → 2026-09-22 (D10–D10)**.
- Recommendation extension: **2026-09-23 → 2026-09-23 (D11–D11)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Make a refresh request survive retries and worker loss without opening an unauthenticated write endpoint or running minutes of ingestion inside an HTTP request.

## Scope and contract

Proposed request/status/retry/cancel operations use current server identity and scope. Persist job intent before 202; recoverable outbox/dispatch closes enqueue gaps. One scope owner holds a lease/fence; stage evidence survives restarts. Source adapters are registered, never arbitrary client URLs.

## Implementation sequence

1. Reuse the approved identity and worker mechanism established by CORE-01; implement minimum durable Postgres job/outbox records if required by the reviewed schema path.
2. Bind idempotency to principal/scope/canonical payload/source-config version; replay returns the same job even after completion, and changed payload conflicts.
3. Implement a linked successor retry with a new key and the immutable predecessor configuration. Reject config drift and require a new top-level refresh.
4. Add replica-wide admission, pending-job age, lease/heartbeat and recoverable dispatch; stage resume never reuses an uncertain remote graph key.
5. Freeze source-adapter and publisher ports and verify their DTO, authorization and activation preconditions with protocol fixtures. CORE-15 performs the real source and CORE-04 publisher wiring. The contract requires reauthorization of the initiating operator/source configuration before activation; service credentials cannot replace operator authority.
6. Implement status/cancel/retry policies and safe failure categories. A cancellation is terminal only after future work stops and uncertain candidates are safely abandoned; activation outcome is resolved from authority.

## Acceptance criteria

- [ ] Duplicate requests, including terminal replays, have one logical job; incompatible payload or config drift cannot silently change its meaning.
- [ ] A crash between persistence and dispatch is recovered without losing accepted work.
- [ ] Protocol fixtures prove that revocation refuses the activation handoff; real job status/retry/cancel operations enforce current authorization. CORE-15 verifies the real publication integration.
- [ ] Source/publisher protocol fixtures prove that a failed source never issues activation or removal; CORE-15 verifies preservation of the actual active publication under its own freshness and policy.
- [ ] All entry points share admission and ownership rules; queued/running/failed/cancelled/succeeded states are truthful.

## Verification

- Test replay before/after completion, simultaneous retries, configuration drift, worker loss, lost remote acknowledgement, revocation before activation and cancellation races.
- Use approved real worker/DB integration checks; in-memory tasks cannot satisfy recovery acceptance.

## Evidence to attach

- Job lifecycle/transition tests, durable dispatch recovery trace, authorization evidence and sanitized DTO examples.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Implementing new corporate SSO or a new queue platform is outside the estimate. If no approved write identity/worker is available, refresh stays disabled and this ticket remains blocked; do not close it using a CLI-only workaround.

## Source adapter ownership

CORE-13 owns Git and whole-workbook acquisition. SKL/MCP/AGT tickets own parsing, typed identity mapping and source-specific evidence. The job orchestrates these interfaces; it does not reimplement their parsers. The scheduled job slice is complete at its recovery/contract boundary; real publication integration belongs to CORE-15; CORE-09 qualifies the integrated behavior before enablement.

## Split implementation boundary

This five-hour slice owns the reusable job framework and protocol tests with source/publisher adapters behind frozen interfaces. CORE-15 owns the separately estimated three-hour real source-set and publisher wiring. Verify activation interface obligations with protocol fixtures here; verify real services in CORE-15 and qualification in CORE-09. No real refresh control is enabled or declared operational from this slice alone.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `source-refresh`, `publication`, `security`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
