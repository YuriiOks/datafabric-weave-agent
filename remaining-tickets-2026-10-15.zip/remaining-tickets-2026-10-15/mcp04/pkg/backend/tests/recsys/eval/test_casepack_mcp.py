"""MCP case packs: the MCP profile, its scenarios and duplicate grouping."""

from __future__ import annotations

import unittest

from app.recsys.contracts import ComponentType
from app.recsys.eval.casepack.cases import (
    EvidenceKind,
    EvidenceRequirement,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.casepack.lineage import CasePackError
from app.recsys.eval.casepack.pack import coverage_gaps, validate_pack
from app.recsys.eval.casepack.profiles import MCP_PROFILE, SKILL_PROFILE, profile_for

from . import casepack_support as support
from . import mcp_casepack_support as mcp


class McpProfileTests(unittest.TestCase):
    def test_the_mcp_profile_is_registered(self) -> None:
        self.assertIs(profile_for(ComponentType.mcp), MCP_PROFILE)
        self.assertIs(profile_for(ComponentType.skill), SKILL_PROFILE)

    def test_mcp_requires_partial_prerequisite_and_conflict_cases(self) -> None:
        for scenario in (Scenario.partial, Scenario.unknown_prerequisite, Scenario.conflict):
            self.assertIn(scenario, MCP_PROFILE.required_scenarios)
            self.assertNotIn(scenario, SKILL_PROFILE.scenarios)


class McpPackTests(unittest.TestCase):
    def setUp(self) -> None:
        self.corpus = mcp.mcp_corpus()
        self.lineage = self.corpus.lineage
        self.cases = mcp.mcp_cases(self.lineage)

    def test_a_pack_covering_every_required_scenario_validates(self) -> None:
        pack = support.pack(self.cases, self.corpus)
        validate_pack(pack, self.corpus, MCP_PROFILE)
        self.assertEqual(coverage_gaps(pack, MCP_PROFILE), ())

    def test_a_skill_case_is_refused_in_an_mcp_pack(self) -> None:
        skill_case = support.case(20, lineage=self.lineage, scenario=Scenario.ambiguous)
        with self.assertRaises(ValueError):
            support.pack([*self.cases, skill_case], self.corpus)

    def test_a_judged_partial_case_needs_a_partial_label(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                20,
                lineage=self.lineage,
                prefix="mcp",
                component_type=ComponentType.mcp,
                scenario=Scenario.partial,
                adjudication=support.judged({mcp.mcp_id(1): RelevanceLabel.relevant}),
            )

    def test_a_declared_relation_does_not_make_an_mcp_suitable(self) -> None:
        case = support.case(
            20,
            lineage=self.lineage,
            prefix="mcp",
            component_type=ComponentType.mcp,
            scenario=Scenario.unknown_prerequisite,
            required_evidence=[
                EvidenceRequirement(
                    kind=EvidenceKind.prerequisite_unknown, subject_id=mcp.mcp_id(2)
                )
            ],
        )
        self.assertEqual(case.relevant_ids(), frozenset())
        self.assertEqual(case.partial_ids(), frozenset())

    def test_duplicate_mcps_cannot_leak_across_groups(self) -> None:
        leaking = support.case(
            20,
            lineage=self.lineage,
            prefix="mcp",
            component_type=ComponentType.mcp,
            group="g-other",
            adjudication=support.judged({mcp.mcp_id(6): RelevanceLabel.relevant}),
        )
        pack = support.pack([*self.cases, leaking], self.corpus)
        with self.assertRaisesRegex(CasePackError, "duplicate set"):
            validate_pack(pack, self.corpus, MCP_PROFILE)

    def test_an_empty_control_is_a_valid_empty_expectation(self) -> None:
        empty = next(case for case in self.cases if case.scenario is Scenario.valid_empty)
        self.assertIs(empty.expected_outcome, ExpectedOutcome.valid_empty)
        with self.assertRaises(ValueError):
            support.case(
                20,
                lineage=self.lineage,
                prefix="mcp",
                component_type=ComponentType.mcp,
                scenario=Scenario.valid_empty,
                expected=ExpectedOutcome.source_unavailable,
            )
