"""Injectable time source. Domain and service code never calls ``datetime.now`` directly."""

from __future__ import annotations

from datetime import UTC, date, datetime
from typing import Protocol


class Clock(Protocol):
    """A source of the current time."""

    def now(self) -> datetime:
        """Return the current time as a timezone-aware UTC datetime."""
        ...

    def today(self) -> date:
        """Return the current UTC calendar date."""
        ...


class SystemClock:
    """The real clock."""

    def now(self) -> datetime:
        """Return the current time as a timezone-aware UTC datetime.

        :return: The current instant in UTC
        """
        return datetime.now(UTC)

    def today(self) -> date:
        """Return the current UTC calendar date.

        :return: Today's date in UTC
        """
        return self.now().date()


class FixedClock:
    """A clock that returns a settable instant, for deterministic tests.

    :param instant: The instant to report; must be timezone-aware.
    :raises ValueError: If ``instant`` is naive.
    """

    def __init__(self, instant: datetime) -> None:
        self._instant = self._require_aware(instant)

    @staticmethod
    def _require_aware(instant: datetime) -> datetime:
        if instant.tzinfo is None:
            raise ValueError("FixedClock requires a timezone-aware datetime")
        return instant.astimezone(UTC)

    def set(self, instant: datetime) -> None:
        """Move the clock to ``instant``.

        :param instant: The new instant; must be timezone-aware
        :raises ValueError: If ``instant`` is naive
        """
        self._instant = self._require_aware(instant)

    def now(self) -> datetime:
        """Return the fixed instant.

        :return: The configured instant in UTC
        """
        return self._instant

    def today(self) -> date:
        """Return the date of the fixed instant.

        :return: The configured instant's UTC date
        """
        return self._instant.date()
