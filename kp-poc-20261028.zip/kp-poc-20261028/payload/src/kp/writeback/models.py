"""Value types of the write-back lane: tool arguments and results, publisher requests."""

from __future__ import annotations

import json
from typing import Annotated

from pydantic import AwareDatetime, Field, JsonValue, field_validator

from kp.domain import DomainModel

SPEC_DRAFTED_STATUS = "Spec drafted"
MAX_SPEC_CHARS = 200_000
MAX_OPEN_ITEMS = 50
MAX_OPEN_ITEM_CHARS = 1_000
MAX_COVERAGE_CHARS = 20_000


class CallContext(DomainModel):
    """Who is calling. Identity comes from the transport, never from the agent's arguments.

    :ivar domains: The domains the caller may read, derived from the caller's identity. A write
        for a story in any other domain is refused; the default (none) permits only stories
        that carry no domain label.
    """

    session_id: str
    caller: str
    agent: str
    domains: tuple[str, ...] = ()


class PublishSpecArguments(DomainModel):
    """Arguments of the ``publish_spec`` tool as an agent sends them.

    ``repository``, ``path`` and ``branch`` exist only so that an attempt to aim the write
    elsewhere is visible, refused and recorded; when omitted the server derives them.
    """

    story_key: str
    spec_markdown: Annotated[str, Field(max_length=MAX_SPEC_CHARS)]
    template_id: str
    template_version: str
    coverage: dict[str, JsonValue] = Field(default_factory=dict)
    open_items: Annotated[
        tuple[Annotated[str, Field(max_length=MAX_OPEN_ITEM_CHARS)], ...],
        Field(max_length=MAX_OPEN_ITEMS),
    ] = ()
    repository: str | None = None
    path: str | None = None
    branch: str | None = None

    @field_validator("coverage")
    @classmethod
    def _coverage_is_small(cls, value: dict[str, JsonValue]) -> dict[str, JsonValue]:
        if len(json.dumps(value, ensure_ascii=True)) > MAX_COVERAGE_CHARS:
            raise ValueError(f"coverage is larger than {MAX_COVERAGE_CHARS} characters")
        return value


class UpdateJiraArguments(DomainModel):
    """Arguments of the ``update_jira`` tool.

    ``fields`` is the agent's view of what to change. Every key must be one of the two agreed
    Jira fields and every value must equal what the server would write anyway.
    """

    story_key: str
    fields: dict[str, str] | None = None


class PublishRequest(DomainModel):
    """What a publisher is asked to do. Built only after the write limits were applied.

    :ivar commit_message: Carries the machine-authored trailer.
    """

    repository: str
    branch: str
    path: str
    content: str
    commit_message: str
    pr_title: str
    pr_body: str


class PublishResult(DomainModel):
    """What a publisher did.

    :ivar pr_url: The pull request link; stored as the spec's ``pr_identity``.
    :ivar created: True when this call opened the pull request.
    :ivar committed: True when this call added a commit (False for an identical re-publish).
    """

    branch: str
    pr_url: str
    pr_number: Annotated[int, Field(ge=1)]
    commit_sha: str
    created: bool
    committed: bool


class MergeResult(DomainModel):
    """What merging a spec branch did.

    :ivar merged: True when this call merged the branch; False when it was already merged.
    """

    branch: str
    path: str
    merged_at: AwareDatetime
    commit_sha: str
    merged: bool


class JiraStoryUpdate(DomainModel):
    """The only Jira change this lane ever makes: one status and one link field."""

    story_key: str
    status: str
    link_field: str
    link_value: str


class JiraApplied(DomainModel):
    """What a Jira updater did (or, in dry-run, would do)."""

    status_changed: bool
    link_set: bool
    dry_run: bool = False


class PublishSpecResult(DomainModel):
    """What ``publish_spec`` tells the agent."""

    spec_id: str
    story_key: str
    branch: str
    path: str
    pr_url: str
    pr_created: bool
    committed: bool
    commit_sha: str
    template_id: str
    template_version: str
    rule_statements: Annotated[int, Field(ge=0)]
    valid_citations: Annotated[int, Field(ge=0)]
    flagged: Annotated[int, Field(ge=0)]
    citation_rate: Annotated[float, Field(ge=0, le=1)]
    citation_target: Annotated[float, Field(ge=0, le=1)]
    meets_target: bool


class UpdateJiraResult(DomainModel):
    """What ``update_jira`` tells the agent."""

    spec_id: str
    story_key: str
    status: str
    link_field: str
    link: str
    status_changed: bool
    link_set: bool
    dry_run: bool
    attempts: Annotated[int, Field(ge=1)]
