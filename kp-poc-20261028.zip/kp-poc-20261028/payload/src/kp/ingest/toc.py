"""Table-of-contents extraction for PDF page texts and Markdown documents."""

from __future__ import annotations

import re
from collections.abc import Sequence

from kp.ingest.models import TocEntry
from kp.ingest.patterns import CLAUSE_NUMBER

_TOC_TITLE = re.compile(r"^(?:table\s+of\s+)?contents$", re.IGNORECASE)
_PDF_ENTRY = re.compile(
    rf"^\s*(?P<number>{CLAUSE_NUMBER})\.?\s+(?P<title>.+?)(?:\s*\.{{2,}}\s*|\s+)(?P<page>\d+)\s*$"
)
_MARKDOWN_ENTRY = re.compile(
    rf"^\s*(?:[-*+]\s+)?(?P<number>{CLAUSE_NUMBER})\.?\s+(?P<title>.+?)"
    r"(?:\s*\.{2,}\s*(?P<page>\d+))?\s*$"
)
_ANY_MARKDOWN_HEADING = re.compile(r"^#{1,6}\s+(?P<title>.*?)\s*#*\s*$")
# A page counts as part of the table of contents when most of its lines look like entries.
_TOC_PAGE_MIN_SHARE = 0.6


def _entry(match: re.Match[str]) -> TocEntry:
    page = match["page"]
    return TocEntry(
        number=match["number"], title=match["title"].strip(), page=int(page) if page else None
    )


def find_pdf_toc(pages: Sequence[str]) -> tuple[tuple[TocEntry, ...], frozenset[int]]:
    """Find the table of contents in the per-page texts of a PDF.

    The table starts on the first page whose first non-blank line is ``Contents`` or
    ``Table of Contents`` and continues over following pages while most of their lines are
    entries (``<number> <title> <page>``).

    :param pages: Extracted text of each page, in order
    :return: The entries and the zero-based indexes of the pages the table occupies; both
        empty when the document has no table of contents
    """
    start = next(
        (
            index
            for index, text in enumerate(pages)
            if (lines := _non_blank(text)) and _TOC_TITLE.match(lines[0])
        ),
        None,
    )
    if start is None:
        return (), frozenset()
    entries: list[TocEntry] = []
    toc_pages: set[int] = set()
    for index in range(start, len(pages)):
        lines = _non_blank(pages[index])
        if index == start:
            lines = lines[1:]
        matches = [match for line in lines if (match := _PDF_ENTRY.match(line))]
        if index > start and (not lines or len(matches) / len(lines) < _TOC_PAGE_MIN_SHARE):
            break
        entries.extend(_entry(match) for match in matches)
        toc_pages.add(index)
    return tuple(entries), frozenset(toc_pages)


def find_markdown_toc(text: str) -> tuple[TocEntry, ...]:
    """Find the table of contents of a Markdown document.

    The table is the list under a heading called ``Contents`` or ``Table of Contents``, up to
    the next heading. A page number is read only after a dotted leader (``... 3``).

    :param text: The Markdown source
    :return: The entries; empty when the document has no such heading
    """
    entries: list[TocEntry] = []
    inside = False
    for line in text.splitlines():
        heading = _ANY_MARKDOWN_HEADING.match(line)
        if heading:
            if inside:
                break
            inside = bool(_TOC_TITLE.match(heading["title"]))
        elif inside and (match := _MARKDOWN_ENTRY.match(line)):
            entries.append(_entry(match))
    return tuple(entries)


def _non_blank(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]
