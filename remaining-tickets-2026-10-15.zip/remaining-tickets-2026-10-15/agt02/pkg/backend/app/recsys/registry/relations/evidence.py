"""The evidence behind each relation: one entry per supporting source declaration.

A catalogue fact already aggregates repeated declarations into one relation and keeps
their reference occurrence ids. Those ids are build-local, so they do not survive a
rebuild. This module turns each supporting occurrence into an entry made only of
stable source facts: where the declaration sits, which field and token position it
came from, the original token, and how and by which rule it was resolved. The evidence
digest is taken over those entries in a canonical order, so it changes exactly when
the evidence changes.

Only accepted references produce entries. An unresolved reference has no relation to
support; it stays in the review ledger.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from app.recsys.contracts import AccountingOutcome, CatalogueBuildResult
from app.recsys.registry.ledger import redact
from app.recsys.registry.relations.keys import canonical_sha256
from app.recsys.registry.rule_stamps import stamp_for

#: Versioned namespace mixed into every evidence digest.
EVIDENCE_DIGEST_NAMESPACE = "bpc-relation-evidence-v1"


@dataclass(frozen=True, slots=True)
class EvidenceEntry:
    """One source declaration supporting one relation.

    Every field is a source fact or a resolution fact; none of them is build-local.
    """

    authority: str
    collection: str
    structural_locator: str
    field_name: str
    token_ordinal: int
    raw_token: str | None
    raw_token_digest: str | None
    resolution_outcome: str
    matched_index: str | None
    rule_id: str | None
    rule_version: str | None

    def sort_key(self) -> tuple[str, str, str, str, int]:
        """:return: The canonical position of this entry within its relation."""
        return (
            self.authority,
            self.collection,
            self.structural_locator,
            self.field_name,
            self.token_ordinal,
        )

    def digest_material(self) -> list[Any]:
        """Render the entry as the list the evidence digest covers.

        The token is digested in its raw form, so redaction at render time never
        changes a digest.

        :return: Every field, with absent values as empty strings.
        """
        return [
            self.authority,
            self.collection,
            self.structural_locator,
            self.field_name,
            self.token_ordinal,
            self.raw_token or "",
            self.raw_token_digest or "",
            self.resolution_outcome,
            self.matched_index or "",
            self.rule_id or "",
            self.rule_version or "",
        ]

    def as_dict(self) -> dict[str, Any]:
        """Render the entry for reports and persistence.

        The raw token passes through the review ledger's redaction, so a value that
        looks like a path, a credential, an address or a staff number is shown as a
        digest, exactly as it would be in the ledger.

        :return: A JSON-serialisable mapping.
        """
        value, redacted = redact(self.raw_token)
        return {
            "authority": self.authority,
            "collection": self.collection,
            "structural_locator": self.structural_locator,
            "field_name": self.field_name,
            "token_ordinal": self.token_ordinal,
            "raw_value": value,
            "raw_value_redacted": redacted,
            "raw_value_digest": self.raw_token_digest,
            "resolution_outcome": self.resolution_outcome,
            "matched_index": self.matched_index,
            "rule_id": self.rule_id,
            "rule_version": self.rule_version,
        }


def evidence_by_reference(catalogue: CatalogueBuildResult) -> dict[str, EvidenceEntry]:
    """Build one evidence entry per accepted reference occurrence.

    :param catalogue: The built catalogue candidate.
    :return: Reference occurrence id to its evidence entry.
    """
    outcomes = {
        evidence.reference_occurrence_id: evidence
        for evidence in catalogue.reference_outcomes
    }
    entries: dict[str, EvidenceEntry] = {}
    for batch in catalogue.source_batches:
        for record in batch.records:
            for reference in record.references:
                evidence = outcomes.get(reference.occurrence_id)
                if (
                    evidence is None
                    or evidence.accounting_outcome is not AccountingOutcome.accepted
                ):
                    continue
                stamp = stamp_for(evidence, catalogue)
                entries[reference.occurrence_id] = EvidenceEntry(
                    authority=batch.authority.value,
                    collection=record.locator.collection.value,
                    structural_locator=record.locator.structural_locator,
                    field_name=reference.field_name,
                    token_ordinal=reference.token_ordinal,
                    raw_token=reference.raw_identifier,
                    raw_token_digest=reference.raw_identifier_digest,
                    resolution_outcome=evidence.outcome.value,
                    matched_index=(
                        evidence.matched_index.value
                        if evidence.matched_index is not None
                        else None
                    ),
                    rule_id=stamp.rule_id if stamp is not None else None,
                    rule_version=stamp.rule_version if stamp is not None else None,
                )
    return entries


def ordered_evidence(entries: Iterable[EvidenceEntry]) -> list[EvidenceEntry]:
    """Put a relation's entries in their canonical order.

    :param entries: The entries supporting one relation, in any order.
    :return: The entries sorted by source position.
    """
    return sorted(entries, key=EvidenceEntry.sort_key)


def evidence_digest(entries: Iterable[EvidenceEntry]) -> str:
    """Digest one relation's evidence set, independent of input order.

    :param entries: The entries supporting one relation.
    :return: The lower-case hex sha256 of the namespaced, ordered entries.
    """
    return canonical_sha256(
        [
            EVIDENCE_DIGEST_NAMESPACE,
            *(entry.digest_material() for entry in ordered_evidence(entries)),
        ]
    )
