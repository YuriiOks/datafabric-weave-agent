"""Small filesystem helpers shared by the directory-backed readers."""

from __future__ import annotations

import hashlib
import os
from collections.abc import Callable, Iterable, Iterator
from pathlib import Path
from typing import TypeVar

from kp.errors import SourceItemNotFoundError, SourceUnavailableError
from kp.sources.errors import MalformedSourceDataError

T = TypeVar("T")

DEFAULT_MEDIA_TYPE = "application/octet-stream"

_MEDIA_TYPES: dict[str, str] = {
    ".md": "text/markdown",
    ".txt": "text/plain",
    ".csv": "text/csv",
    ".html": "text/html",
    ".json": "application/json",
    ".yaml": "application/yaml",
    ".yml": "application/yaml",
    ".py": "text/x-python",
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}


def sha256_hex(data: bytes) -> str:
    """Hash ``data``.

    :param data: The bytes to hash
    :return: Lower-case hexadecimal SHA-256
    """
    return hashlib.sha256(data).hexdigest()


def media_type_for(path: Path) -> str:
    """Pick a media type from the file suffix. It is declared, never guessed from content.

    :param path: Any path
    :return: A media type, or ``application/octet-stream`` for an unknown suffix
    """
    return _MEDIA_TYPES.get(path.suffix.lower(), DEFAULT_MEDIA_TYPE)


def require_directory(root: Path) -> None:
    """Check that a source directory is reachable.

    :param root: The directory
    :raises kp.errors.SourceUnavailableError: If it is missing or not a directory
    """
    if not root.is_dir():
        raise SourceUnavailableError("Source directory is not available")


def read_file(path: Path) -> bytes:
    """Read a whole file.

    :param path: The file
    :return: Its bytes, unaltered
    :raises kp.errors.SourceItemNotFoundError: If the file vanished since it was listed
    :raises kp.errors.SourceUnavailableError: If it cannot be read
    """
    try:
        return path.read_bytes()
    except FileNotFoundError as exc:
        raise SourceItemNotFoundError(f"Source file is gone: {path.name}") from exc
    except OSError as exc:
        raise SourceUnavailableError(f"Source file cannot be read: {path.name}") from exc


def parse_file(
    path: Path,
    parse: Callable[[bytes], T],
    description: str,
    *,
    errors: tuple[type[Exception], ...] = (ValueError,),
) -> T:
    """Read a file and parse it, turning a parse failure into a typed error.

    The default catches :class:`ValueError`, which covers JSON syntax, text decoding and
    pydantic validation errors.

    :param path: The file
    :param parse: Turns the file's bytes into a value
    :param description: What the file is, for the error message (for example ``Page export``)
    :param errors: The exception types that mean "the content has the wrong shape"
    :return: The parsed value
    :raises kp.sources.errors.MalformedSourceDataError: If ``parse`` raises one of ``errors``
    :raises kp.errors.SourceItemNotFoundError: If the file vanished since it was listed
    :raises kp.errors.SourceUnavailableError: If it cannot be read
    """
    data = read_file(path)
    try:
        return parse(data)
    except errors as exc:
        raise MalformedSourceDataError(f"{description} is invalid: {path.name}") from exc


def walk_files(root: Path, *, skip_directories: Iterable[str] = ()) -> Iterator[Path]:
    """Yield the regular files below ``root`` in a stable order.

    Hidden files and directories (leading dot), symbolic links and the named directories are
    left out, so a source can never be steered outside its root or into tooling caches.

    :param root: The directory to walk
    :param skip_directories: Directory names to prune anywhere in the tree
    :return: File paths, sorted by directory then name
    """
    skipped = frozenset(skip_directories)
    for directory, subdirectories, names in os.walk(root, followlinks=False):
        subdirectories[:] = sorted(
            name for name in subdirectories if not name.startswith(".") and name not in skipped
        )
        for name in sorted(names):
            path = Path(directory) / name
            if not name.startswith(".") and not path.is_symlink():
                yield path
