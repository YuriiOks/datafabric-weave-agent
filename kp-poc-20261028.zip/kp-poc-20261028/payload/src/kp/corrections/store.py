"""The corrections log: what a product owner changed in a drafted spec, and why (US-24)."""

from __future__ import annotations

import uuid

from sqlalchemy import Connection, insert, select

from kp.clock import Clock, SystemClock
from kp.corrections.errors import InvalidCorrectionError, UnknownSpecError
from kp.domain import SpecCorrection
from kp.store import schema

MAX_CORRECTION_CHARS = 4_000
MAX_REASON_CHARS = 2_000


class CorrectionLog:
    """Records and lists corrections on a connection the caller owns.

    :param connection: A connection inside a transaction
    :param clock: Time source for the recording time
    """

    def __init__(self, connection: Connection, clock: Clock | None = None) -> None:
        self._connection = connection
        self._clock = clock or SystemClock()

    def add(
        self, spec_id: str, correction: str, reason: str, *, wrong_clause: bool = False
    ) -> SpecCorrection:
        """Record one correction.

        :param spec_id: The spec that was corrected
        :param correction: What was changed
        :param reason: Why; required, because a correction without a reason cannot be learned from
        :param wrong_clause: True when the draft cited a clause that was wrong
        :return: The stored correction
        :raises kp.corrections.errors.InvalidCorrectionError: If the correction or the reason is
            empty or too long
        :raises kp.corrections.errors.UnknownSpecError: If the spec does not exist
        """
        text, why = correction.strip(), reason.strip()
        if not text or not why:
            raise InvalidCorrectionError("A correction needs both what changed and the reason")
        if len(text) > MAX_CORRECTION_CHARS or len(why) > MAX_REASON_CHARS:
            raise InvalidCorrectionError("The correction or its reason is too long")
        known = self._connection.execute(
            select(schema.spec.c.spec_id).where(schema.spec.c.spec_id == spec_id)
        ).first()
        if known is None:
            raise UnknownSpecError("No drafted spec has that identity")
        stored = SpecCorrection(
            correction_id=uuid.uuid4().hex,
            spec_id=spec_id,
            correction=text,
            reason=why,
            wrong_clause=wrong_clause,
            recorded_at=self._clock.now(),
        )
        self._connection.execute(insert(schema.spec_correction).values(**stored.model_dump()))
        return stored

    def for_spec(self, spec_id: str) -> tuple[SpecCorrection, ...]:
        """List the corrections of one spec, oldest first.

        :param spec_id: The spec
        :return: Its corrections
        """
        table = schema.spec_correction
        rows = self._connection.execute(
            select(table)
            .where(table.c.spec_id == spec_id)
            .order_by(table.c.recorded_at, table.c.correction_id)
        )
        return tuple(SpecCorrection.model_validate(dict(row._mapping)) for row in rows)
