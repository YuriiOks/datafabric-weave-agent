"""Synthetic stand-ins for every non-rulebook source: register, stories, pages, library, code.

All content is invented. Text files are written with sorted keys and fixed timestamps so the
same seed gives byte-identical output.
"""

from __future__ import annotations

import io
import json
import random
import re
import zipfile
from datetime import UTC, datetime
from pathlib import Path

import yaml
from openpyxl import Workbook

from kp.testing.dataset import ConfluenceTruth, RegisterTruth, StoryTruth

_FIXED_ZIP_TIME = (2026, 1, 1, 0, 0, 0)
_FIXED_DATETIME = datetime(2026, 1, 1, tzinfo=UTC)
_MODIFIED_RE = re.compile(rb"(<dcterms:modified[^>]*>)[^<]*(</dcterms:modified>)")
_FIXED_MODIFIED = rb"\g<1>2026-01-01T00:00:00Z\g<2>"

REGISTER_MAIN_SHEET = "Requirements"
REGISTER_NOTES_SHEET = "Notes"
REGISTER_HEADER_ROW = 4
REGISTER_HEADER = (
    "Req ID",
    "Title",
    "Description",
    "Rule reference",
    "Domain",
    "Priority",
    "Owner role",
)

# (title, description, rule reference, domain)
_REQUIREMENTS: tuple[tuple[str, str, str, str], ...] = (
    (
        "Accept inbound credit transfers in permitted currencies",
        "The platform accepts an inbound credit transfer only in a currency the rulebook allows.",
        "2026.1 clause 4.2.1",
        "payments",
    ),
    (
        "Enforce the per-transfer amount limit",
        "Inbound credit transfers above the published limit are rejected.",
        "2026.1 clause 4.2.2",
        "payments",
    ),
    (
        "Check the creditor account",
        "The receiving side confirms the creditor account exists before accepting funds.",
        "2026.1 clause 4.2.3",
        "payments",
    ),
    (
        "Acknowledge received transfers",
        "Every received credit transfer is acknowledged within five seconds.",
        "2026.1 clause 4.1.2",
        "payments",
    ),
    (
        "Reject malformed remittance references",
        "References containing control characters are rejected.",
        "2026.1 clause 4.2.4",
        "payments",
    ),
    (
        "Settle in the next cycle",
        "Accepted transfers are settled in the next settlement cycle.",
        "2026.1 clause 4.3.1",
        "payments",
    ),
    (
        "Retain transfer records",
        "Records of credit transfers are kept for the period the rulebook requires.",
        "2026.1 clause 2.2.2",
        "payments",
    ),
    (
        "Report major incidents",
        "Major incidents are reported to the scheme operator within four hours.",
        "2026.1 clause 6.2.1",
        "payments",
    ),
    (
        "Validate messages against the schema",
        "Every message is validated against the published schema before processing.",
        "2026.1 clause 6.3.1",
        "payments",
    ),
    (
        "Show card transfer status",
        "Card holders see the status of a card-funded transfer in their statement.",
        "",
        "cards",
    ),
    (
        "Mask card numbers in exports",
        "Exports show only the last four digits of a card number.",
        "",
        "cards",
    ),
    (
        "Keep contact details current",
        "Operational contact details are reviewed every quarter.",
        "2026.1 clause 2.2.1",
        "payments",
    ),
)

_NOTES_LINES = (
    "Free-form working notes. Not a table.",
    "Review the currency wording again after the next edition is published.",
    "Ask the owner whether card requirements belong in a separate register.",
    "Parked: ideas for later quarters, no particular order.",
)


def _deterministic_xlsx(workbook: Workbook) -> bytes:
    """Serialise ``workbook`` with fixed zip timestamps so the bytes are reproducible."""
    workbook.properties.created = _FIXED_DATETIME
    workbook.properties.modified = _FIXED_DATETIME
    raw = io.BytesIO()
    workbook.save(raw)
    out = io.BytesIO()
    with (
        zipfile.ZipFile(raw) as source,
        zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as target,
    ):
        for info in source.infolist():
            fixed = zipfile.ZipInfo(info.filename, date_time=_FIXED_ZIP_TIME)
            fixed.compress_type = zipfile.ZIP_DEFLATED
            content = source.read(info.filename)
            if info.filename == "docProps/core.xml":
                # openpyxl stamps the real save time into "modified" whatever we set.
                content = _MODIFIED_RE.sub(_FIXED_MODIFIED, content)
            target.writestr(fixed, content)
    return out.getvalue()


def write_register(root: Path, seed: int) -> RegisterTruth:
    """Write a register whose header row is not the first row, plus a headerless sheet.

    :param root: Dataset root
    :param seed: Seed for the priority column
    :return: Ground truth for the register
    """
    rng = random.Random(seed)
    workbook = Workbook()
    main = workbook.active
    assert main is not None  # a new workbook always has an active sheet  # noqa: S101
    main.title = REGISTER_MAIN_SHEET
    main["A1"] = "Payments Requirements Register (synthetic)"
    main["A2"] = "Maintained by Example Scheme business analysis. Exported 2026-10-01."
    main.append([])
    main.append(list(REGISTER_HEADER))
    for index, (title, description, reference, domain) in enumerate(_REQUIREMENTS, start=1):
        main.append(
            [
                f"REQ-{index:03d}",
                title,
                description,
                reference,
                domain,
                rng.choice(["Must", "Should"]),
                "Business analyst",
            ]
        )
    notes = workbook.create_sheet(REGISTER_NOTES_SHEET)
    for line in _NOTES_LINES:
        notes.append([line])

    relative = Path("register") / "requirements-register.xlsx"
    (root / relative).parent.mkdir(parents=True, exist_ok=True)
    (root / relative).write_bytes(_deterministic_xlsx(workbook))
    return RegisterTruth(
        path=relative.as_posix(),
        main_sheet=REGISTER_MAIN_SHEET,
        headerless_sheet=REGISTER_NOTES_SHEET,
        header_row=REGISTER_HEADER_ROW,
        data_row_count=len(_REQUIREMENTS),
        header=REGISTER_HEADER,
    )


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def _issue(
    key: str,
    summary: str,
    description: str,
    criteria: str,
    status: str,
    updated: str,
    *,
    parent: str | None,
    links: tuple[tuple[str, str], ...] = (),
    domain: str = "payments",
) -> dict[str, object]:
    return {
        "key": key,
        "fields": {
            "summary": summary,
            "description": description,
            "acceptance_criteria": criteria,
            "status": {"name": status},
            "parent": {"key": parent} if parent else None,
            "issuelinks": [{"type": kind, "key": target} for kind, target in links],
            "labels": [f"domain:{domain}"],
            "updated": updated,
        },
    }


def _stories(*, second_export: bool) -> list[dict[str, object]]:
    """Stories of the project; the second export holds a status-only and a criteria change."""
    status_102 = "In Progress" if second_export else "To Do"
    updated_102 = "2026-10-08T09:00:00+00:00" if second_export else "2026-10-01T09:00:00+00:00"
    criteria_104 = (
        "Given a transfer in an unlisted currency, it is rejected with reason code CUR01.\n"
        "Given a transfer in pounds sterling, it is accepted."
        if second_export
        else "Given a transfer in an unlisted currency, it is rejected with reason code CUR01."
    )
    updated_104 = "2026-10-08T10:00:00+00:00" if second_export else "2026-10-01T09:00:00+00:00"
    first = "2026-10-01T09:00:00+00:00"
    return [
        _issue(
            "PAY-100",
            "Inbound credit transfers",
            "Epic for inbound credit transfer handling.",
            "",
            "In Progress",
            first,
            parent=None,
        ),
        _issue(
            "PAY-101",
            "Acknowledge received credit transfers",
            "Acknowledge each received transfer quickly. Rule: 2026.1 clause 4.1.2.",
            "Given a received transfer, an acknowledgement is sent within five seconds.",
            "Done",
            first,
            parent="PAY-100",
            links=(("implements", "REQ-004"),),
        ),
        _issue(
            "PAY-102",
            "Check the creditor account of inbound transfers",
            "Confirm the creditor account exists. Rule: 2026.1 clause 4.2.3.",
            "Given an unknown creditor account, the transfer is rejected.",
            status_102,
            updated_102,
            parent="PAY-100",
            links=(("implements", "REQ-003"),),
        ),
        _issue(
            "PAY-103",
            "Enforce the per-transfer amount limit",
            "Reject transfers above the published limit. Rule: 2026.1 clause 4.2.2.",
            "Given an amount above the limit, the transfer is rejected.",
            "To Do",
            first,
            parent="PAY-100",
            links=(("implements", "REQ-002"), ("relates to", "PAY-102")),
        ),
        _issue(
            "PAY-104",
            "Accept permitted currencies on inbound transfers",
            "Restrict the currency of inbound transfers. Rule: 2026.1 clause 4.2.1.",
            criteria_104,
            "To Do",
            updated_104,
            parent="PAY-100",
            links=(("implements", "REQ-001"),),
        ),
        _issue(
            "PAY-105",
            "Reject malformed remittance references",
            "Reject references with control characters. Rule: 2026.1 clause 4.2.4.",
            "Given a reference with a control character, the transfer is rejected.",
            "To Do",
            first,
            parent="PAY-100",
            links=(("implements", "REQ-005"),),
        ),
        _issue(
            "PAY-106",
            "Show card transfer status in statements",
            "Show the status of card-funded transfers.",
            "Given a card-funded transfer, the statement shows its status.",
            "To Do",
            first,
            parent="PAY-100",
            domain="cards",
        ),
    ]


def write_stories(root: Path) -> StoryTruth:
    """Write two exports of one project: the second has one status-only change and one
    acceptance-criteria change relative to the first.

    :param root: Dataset root
    :return: Ground truth naming the two changed stories
    """
    first = Path("jira") / "export-1.json"
    second = Path("jira") / "export-2.json"
    for relative, is_second, exported in (
        (first, False, "2026-10-01T12:00:00+00:00"),
        (second, True, "2026-10-08T12:00:00+00:00"),
    ):
        _write_json(
            root / relative,
            {
                "project": "PAY",
                "exported_at": exported,
                "issues": _stories(second_export=is_second),
            },
        )
    return StoryTruth(
        first_export=first.as_posix(),
        second_export=second.as_posix(),
        story_count=len(_stories(second_export=False)),
        status_only_key="PAY-102",
        criteria_changed_key="PAY-104",
    )


def write_confluence(root: Path) -> ConfluenceTruth:
    """Write three pages: approved, without the approval label, and one with a newer draft.

    :param root: Dataset root
    :return: Ground truth naming the pages
    """

    def version(number: int, state: str, modified: str, body: str) -> dict[str, object]:
        return {"number": number, "state": state, "modified": modified, "body": body}

    pages = {
        "page-1001": {
            "title": "Inbound transfer operating notes",
            "labels": ["approved", "payments"],
            "versions": [
                version(1, "published", "2026-09-01T09:00:00+00:00", "# Operating notes\n\nv1."),
            ],
        },
        "page-1002": {
            "title": "Unreviewed working page",
            "labels": ["payments"],
            "versions": [
                version(1, "published", "2026-09-05T09:00:00+00:00", "# Working page\n\nv1."),
            ],
        },
        "page-1003": {
            "title": "Reconciliation procedure",
            "labels": ["approved", "payments"],
            "versions": [
                version(1, "published", "2026-08-01T09:00:00+00:00", "# Reconciliation\n\nv1."),
                version(2, "published", "2026-09-10T09:00:00+00:00", "# Reconciliation\n\nv2."),
                version(3, "draft", "2026-10-02T09:00:00+00:00", "# Reconciliation\n\nv3 draft."),
            ],
        },
    }
    for page_id, page in pages.items():
        _write_json(
            root / "confluence" / f"{page_id}.json",
            {"id": page_id, "space": "PAYDOCS", **page},
        )
    return ConfluenceTruth(
        approved_page="page-1001",
        unlabelled_page="page-1002",
        page_with_newer_draft="page-1003",
    )


_LIBRARY: dict[str, tuple[str, dict[str, str | None]]] = {
    "operating-guide.v2": (
        "# Operating guide\n\nVersion 2, approved.\n",
        {
            "item_id": "operating-guide",
            "version": "2",
            "approval_status": "approved",
            "modified_at": "2026-09-01T09:00:00+00:00",
            "document_type": "guide",
            "domain": "payments",
            "authority": "Example Scheme",
            "classification": "internal",
            "content_owner": "owner-role-payments",
        },
    ),
    "operating-guide.v3-draft": (
        "# Operating guide\n\nVersion 3, draft, newer than the approved version.\n",
        {
            "item_id": "operating-guide",
            "version": "3",
            "approval_status": "draft",
            "modified_at": "2026-10-02T09:00:00+00:00",
            "document_type": "guide",
            "domain": "payments",
            "authority": "Example Scheme",
            "classification": "internal",
            "content_owner": "owner-role-payments",
        },
    ),
    "escalation-note": (
        "# Escalation note\n\nThis document has no content owner.\n",
        {
            "item_id": "escalation-note",
            "version": "1",
            "approval_status": "approved",
            "modified_at": "2026-09-03T09:00:00+00:00",
            "document_type": "procedure",
            "domain": "payments",
            "authority": "Example Scheme",
            "classification": "internal",
            "content_owner": None,
        },
    ),
    "unclassified-memo": (
        "# Memo\n\nThis document has a document type the platform does not know.\n",
        {
            "item_id": "unclassified-memo",
            "version": "1",
            "approval_status": "approved",
            "modified_at": "2026-09-04T09:00:00+00:00",
            "document_type": "unrecognised-type",
            "domain": "cards",
            "authority": "Example Scheme",
            "classification": "internal",
            "content_owner": "owner-role-cards",
        },
    ),
}


def write_library(root: Path) -> None:
    """Write a small document library: approved plus newer draft, a missing detail, an
    unknown document type. Each document has a ``.meta.json`` sidecar.

    :param root: Dataset root
    """
    directory = root / "library"
    directory.mkdir(parents=True, exist_ok=True)
    for stem, (body, meta) in _LIBRARY.items():
        (directory / f"{stem}.md").write_text(body, encoding="utf-8", newline="\n")
        _write_json(directory / f"{stem}.meta.json", meta)


_CODE_FILES: dict[str, str] = {
    "README.md": "# Payments service (synthetic)\n\nFictional code used as test data.\n",
    "schema/credit_transfer.schema.json": json.dumps(
        {
            "title": "CreditTransfer",
            "type": "object",
            "properties": {
                "currency": {"type": "string", "x-clause": "2026.1:4.2.1"},
                "amount": {"type": "number", "x-clause": "2026.1:4.2.2"},
                "creditor_account": {"type": "string", "x-clause": "2026.1:4.2.3"},
                "debtor_account": {"type": "string", "x-clause": "2026.1:3.2.1"},
                "reference": {"type": "string", "x-clause": "2026.1:4.2.4"},
            },
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    "src/payments/inbound.py": '''"""Validation of inbound credit transfers (synthetic)."""

PERMITTED_CURRENCIES = {"EUR", "GBP"}
AMOUNT_LIMIT = 1_000_000


def validate_currency(currency: str) -> bool:
    """Return True when the currency is permitted. Implements 2026.1:4.2.1.

    Implements spec spec-pay-104.
    """
    return currency in PERMITTED_CURRENCIES


def validate_amount(amount: float) -> bool:
    """Return True when the amount is within the limit. Implements 2026.1:4.2.2."""
    return 0 < amount <= AMOUNT_LIMIT


def validate_creditor_account(account: str) -> bool:
    """Return True when the account looks valid. Implements 2026.1:4.2.3."""
    return 0 < len(account) <= 34
''',
    "tests/test_inbound.py": '''"""Tests for inbound validation (synthetic)."""

from payments.inbound import validate_amount, validate_currency


def test_unlisted_currency_is_rejected() -> None:
    """Verifies 2026.1:4.2.1."""
    assert not validate_currency("USD")


def test_amount_above_limit_is_rejected() -> None:
    """Verifies 2026.1:4.2.2."""
    assert not validate_amount(2_000_000)
''',
}


def write_code_repo(root: Path) -> None:
    """Write a tiny code-and-tests tree that references clauses and schema fields.

    Clauses 4.2.1 and 4.2.2 have a test; 4.2.3 has code but no test.

    :param root: Dataset root
    """
    for relative, content in _CODE_FILES.items():
        path = root / "code_repo" / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")


_SPEC_FILES: dict[str, str] = {
    "specs/spec-pay-104.md": """---
story: PAY-104
spec: spec-pay-104
template: functional-spec@1.0.0
---
# Accept permitted currencies on inbound transfers

## Summary

An inbound credit transfer is accepted only in a currency the rulebook lists.

## Rules

- An inbound credit transfer may be denominated only in a listed currency [ref: 2026.1:4.2.1].
- The register row REQ-001 states the same requirement and is met by this rule.

## Acceptance

- A transfer in an unlisted currency is rejected.
""",
}

SPEC_REPO_FOLDER = "spec_repo"


def write_spec_repo(root: Path) -> None:
    """Write the spec repository as it stands after a person merged one spec.

    The spec belongs to the currency story, cites clause 4.2.1 and the register row REQ-001, and
    is implemented by ``validate_currency`` (the code repository says so). With the test that
    verifies that function it makes clause 4.2.1 a rule that reaches a test: clause, spec, code
    and test. It has no ``machine_authored`` line, so it is a person's own spec.

    :param root: Dataset root
    """
    for relative, content in _SPEC_FILES.items():
        path = root / SPEC_REPO_FOLDER / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")


_TEMPLATE = """---
spec_type: functional
template_id: functional-spec
version: 1.0.0
---
# {{title}}

## Summary

One paragraph describing the change for the story.

## Rules

Every statement in this section cites a clause or a register row.

## Acceptance

Observable conditions, one per line.

## Coverage

Rules touched and the tests that verify them.

## Open items

Questions that remain.
"""


def write_template(root: Path) -> None:
    """Write the governed spec template.

    :param root: Dataset root
    """
    path = root / "templates" / "functional-spec.v1.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_TEMPLATE, encoding="utf-8", newline="\n")


def write_identity_mapping(root: Path) -> None:
    """Write the identity-to-domain mapping with four test users.

    :param root: Dataset root
    """
    mapping = {
        "version": 1,
        "users": {
            "user-full-access": {"domains": ["cards", "payments"]},
            "user-one-domain": {"domains": ["payments"]},
            "user-no-payments-access": {"domains": ["cards"]},
            "user-no-access": {"domains": []},
        },
    }
    path = root / "identity" / "identity-mapping.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(mapping, sort_keys=True), encoding="utf-8", newline="\n")
