"""``kp web``: serve the web UI.

The UI libraries are imported only when the server starts, so ``kp`` and its other commands run
without the ``web`` extra installed.
"""

from __future__ import annotations

import argparse
import ipaddress
import sys
from dataclasses import dataclass
from datetime import UTC, date, datetime, time
from pathlib import Path

from pydantic import SecretStr

from kp.app import build_application
from kp.clock import Clock, FixedClock
from kp.config import Mode, Settings, load_settings
from kp.errors import ConfigurationError, KpError
from kp.web.settings import DEFAULT_HOST, DEFAULT_PORT, WebSettings, load_web_settings

COMMAND = "web"
EXIT_FAILED = 2
# What `kp demo` leaves beside its database, which `kp web --db` finds on its own.
_DEMO_IDENTITY_MAPPING = Path("data") / "identity" / "identity-mapping.yaml"
_DEMO_CONNECTIVITY_DATABASE = "connectivity.db"
_DEMO_CONNECTIVITY_FOLDER = "connectivity"
_FIXED_HOUR = 9


@dataclass(frozen=True)
class LaunchPlan:
    """What ``kp web`` will start, decided before anything is opened.

    :ivar connectivity: Settings of the database the connectivity job used, when it is not the
        platform's own.
    :ivar clock: A fixed clock when ``--today`` was given, else the system clock.
    """

    settings: Settings
    web_settings: WebSettings
    connectivity: Settings | None
    clock: Clock | None
    host: str
    port: int


def add_parser(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Register ``web``.

    :param subparsers: The subparsers action of the ``kp`` parser
    """
    parser = subparsers.add_parser("web", help="Serve the web UI (needs the 'web' extra)")
    parser.add_argument("--host", default=DEFAULT_HOST, help=f"Address to bind ({DEFAULT_HOST})")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"Port ({DEFAULT_PORT})")
    parser.add_argument(
        "--db",
        type=Path,
        metavar="PATH",
        help="SQLite database to show, such as the one 'kp demo' made (default: KP_DATABASE_URL)",
    )
    parser.add_argument(
        "--identity-mapping",
        type=Path,
        metavar="PATH",
        help="Identity mapping file (default: KP_IDENTITY_MAPPING_FILE, else the one beside a "
        "demo database)",
    )
    parser.add_argument(
        "--connectivity-db",
        type=Path,
        metavar="PATH",
        help="Database of the last connectivity run (default: the one beside a demo database)",
    )
    parser.add_argument(
        "--today",
        type=date.fromisoformat,
        metavar="YYYY-MM-DD",
        help="Treat this date as today, for a database built on dates in the future",
    )
    parser.add_argument(
        "--trusted-proxy",
        action="store_true",
        help="Allow a non-loopback --host: only a proxy that authenticates users and sets the "
        "identity header may reach this port",
    )
    parser.set_defaults(handler=handle)


def plan_launch(args: argparse.Namespace, base: Settings | None = None) -> LaunchPlan:
    """Decide what to start from the arguments and the environment.

    :param args: Parsed arguments of ``kp web``
    :param base: The platform settings; read from the environment when omitted
    :return: The plan
    :raises kp.errors.ConfigurationError: If a file named is missing, the host is not safe, or a
        setting is invalid
    """
    if not _is_loopback(args.host) and not args.trusted_proxy:
        raise ConfigurationError(
            f"--host {args.host!r} is not a loopback address: the identity is not authenticated "
            "here, so a reachable port lets any client choose who it is; pass --trusted-proxy "
            "only behind a proxy that authenticates users"
        )
    settings = base if base is not None else load_settings()
    if args.trusted_proxy and settings.mode is Mode.LOCAL:
        # Local mode lets the caller pick any user with ?user=, and answers as the user with the
        # widest access when none is picked. Behind a proxy that would hand that identity to
        # every client, so the proxy setup is only allowed with the real identity header.
        raise ConfigurationError(
            "--trusted-proxy needs KP_MODE=real: in local mode any client can choose who it is. "
            "Set KP_MODE=real so the user is read from the identity header"
        )
    updates: dict[str, object] = {}
    if args.db is not None:
        updates["database_url"] = SecretStr(_sqlite_url(_existing(args.db, "database")))
    mapping = (
        args.identity_mapping
        or settings.identity_mapping_file
        or _beside(args.db, _DEMO_IDENTITY_MAPPING)
    )
    if mapping is not None:
        updates["identity_mapping_file"] = _existing(mapping, "identity mapping")
    connectivity = _connectivity(args, settings)
    clock = None
    if args.today is not None:
        clock = FixedClock(datetime.combine(args.today, time(_FIXED_HOUR), tzinfo=UTC))
    return LaunchPlan(
        settings=settings.model_copy(update=updates),
        web_settings=load_web_settings(),
        connectivity=connectivity,
        clock=clock,
        host=args.host,
        port=args.port,
    )


def handle(args: argparse.Namespace) -> int:
    """Run ``kp web``.

    :param args: Parsed arguments from :func:`add_parser`
    :return: 0 after a clean stop, 2 when the UI could not start
    """
    try:
        plan = plan_launch(args)
        return _serve(plan)
    except KpError as exc:
        sys.stderr.write(f"kp web: {exc}\n")
        return EXIT_FAILED


def _serve(plan: LaunchPlan) -> int:
    try:
        import uvicorn  # noqa: PLC0415 - only when serving, so the other commands need no extra

        from kp.web.app import create_app  # noqa: PLC0415 - imports the UI libraries
    except ImportError:
        sys.stderr.write("kp web: the UI libraries are missing; install the 'web' extra\n")
        return EXIT_FAILED
    application = build_application(plan.settings, clock=plan.clock)
    try:
        app = create_app(
            application,
            settings=plan.web_settings,
            connectivity=plan.connectivity,
            loopback_only=_is_loopback(plan.host),
        )
        # Our own structured log line per page replaces the access log, which holds the query.
        uvicorn.run(app, host=plan.host, port=plan.port, access_log=False, log_config=None)
    finally:
        application.close()
    return 0


def _connectivity(args: argparse.Namespace, settings: Settings) -> Settings | None:
    """Settings for the database the connectivity job left its evidence in, if not the main one."""
    path: Path | None = args.connectivity_db
    if path is None:
        path = _beside(args.db, Path(_DEMO_CONNECTIVITY_DATABASE))
    if path is None or settings.mode is Mode.REAL:
        return None
    database = _existing(path, "connectivity database")
    return settings.model_copy(
        update={
            "database_url": SecretStr(_sqlite_url(database)),
            "data_dir": database.parent / _DEMO_CONNECTIVITY_FOLDER,
        }
    )


def _beside(database: Path | None, name: Path) -> Path | None:
    """A file beside the database, when it exists."""
    if database is None:
        return None
    candidate = database.resolve().parent / name
    return candidate if candidate.is_file() else None


def _existing(path: Path, what: str) -> Path:
    if not path.is_file():
        raise ConfigurationError(f"No {what} file at {path}")
    return path.resolve()


def _sqlite_url(path: Path) -> str:
    return f"sqlite+pysqlite:///{path}"


def _is_loopback(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False
