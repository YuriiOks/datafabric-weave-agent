#!/usr/bin/env bash
# Apply the source-set integration package to a clean worktree, uncommitted.
# Usage: bash apply.sh <worktree-root>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:?worktree root}"
python3 "$HERE/apply_fnd14.py" "$ROOT" --check
python3 "$HERE/apply_fnd14.py" "$ROOT"
git -C "$ROOT" diff --stat
git -C "$ROOT" status -s
