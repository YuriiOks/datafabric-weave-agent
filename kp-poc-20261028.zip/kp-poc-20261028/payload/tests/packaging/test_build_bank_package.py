"""Behaviour of the package build: contents, checksums, the zip and the scrub."""

from __future__ import annotations

import hashlib
import io
import shutil
import zipfile
from pathlib import Path

import pytest
from package_world import (
    BUILD_DATE,
    PROJECT_ROOT,
    builder,
    installer,
    make_project,
    options_for,
    write_patterns,
)

PACKAGE = "kp-poc-20261028"
REAL_PROJECT_URL_EXCEPTIONS = ("invalid", "stand-in", "schemas.openxmlformats.org")
REAL_PROJECT_EMAIL_EXCEPTIONS = ("machine.invalid",)


@pytest.fixture
def project(tmp_path: Path) -> Path:
    return make_project(tmp_path / "project")


@pytest.fixture
def patterns(tmp_path: Path) -> Path:
    return write_patterns(tmp_path / "patterns.json")


@pytest.fixture
def out_root(tmp_path: Path) -> Path:
    return tmp_path / "out"


def _zip_names(zip_path: Path) -> set[str]:
    with zipfile.ZipFile(zip_path) as archive:
        return set(archive.namelist())


def _break(project: Path, name: str, data: bytes) -> None:
    (project / name).write_bytes(data)


# --- contents ----------------------------------------------------------------------------------


def test_the_build_makes_one_zip_with_the_agreed_layout(
    project: Path, patterns: Path, out_root: Path
) -> None:
    result = builder.build_package(options_for(project, out_root, patterns))

    assert result.zip_path == out_root / f"{PACKAGE}.zip"
    assert sorted(path.name for path in out_root.iterdir()) == [PACKAGE, f"{PACKAGE}.zip"]
    names = _zip_names(result.zip_path)
    assert {
        f"{PACKAGE}/install.py",
        f"{PACKAGE}/README-PACKAGE.txt",
        f"{PACKAGE}/SHA256SUMS",
        f"{PACKAGE}/payload/src/kp/__init__.py",
        f"{PACKAGE}/payload/.env.example",
        f"{PACKAGE}/payload/INSTALL-WORKSTATION.md",
        f"{PACKAGE}/payload/docs/guide.md",
        f"{PACKAGE}/payload/scripts/check.sh",
    } <= names
    assert result.payload_files == len([n for n in names if "/payload/" in n])


def test_caches_environments_the_requirements_and_env_files_stay_out(
    project: Path, patterns: Path, out_root: Path
) -> None:
    result = builder.build_package(options_for(project, out_root, patterns))

    names = _zip_names(result.zip_path)
    unwanted = ("__pycache__", ".pyc", ".mypy_cache", ".pytest_cache", "SPEC.md", "egg-info")
    assert [n for n in names if any(bit in n for bit in unwanted)] == []
    assert not any(n.endswith(("/.env", "/.env.local", ".db")) for n in names)
    assert not any("/var/" in n or "/.git/" in n for n in names)


def test_the_checksum_file_covers_every_other_file_and_verifies(
    project: Path, patterns: Path, out_root: Path
) -> None:
    result = builder.build_package(options_for(project, out_root, patterns))

    entries = installer.verify_package(result.package_dir)
    on_disk = {
        p.relative_to(result.package_dir).as_posix()
        for p in result.package_dir.rglob("*")
        if p.is_file() and p.name != "SHA256SUMS"
    }
    assert set(entries) == on_disk


def test_the_reported_size_and_checksum_are_those_of_the_zip(
    project: Path, patterns: Path, out_root: Path
) -> None:
    result = builder.build_package(options_for(project, out_root, patterns))

    data = result.zip_path.read_bytes()
    assert result.zip_size == len(data)
    assert result.zip_sha256 == hashlib.sha256(data).hexdigest()


def test_the_same_tree_and_date_give_the_same_zip(
    project: Path, patterns: Path, tmp_path: Path
) -> None:
    first = builder.build_package(options_for(project, tmp_path / "one", patterns))
    second = builder.build_package(options_for(project, tmp_path / "two", patterns))

    assert first.zip_sha256 == second.zip_sha256


def test_a_rebuild_replaces_the_earlier_build_of_the_same_day(
    project: Path, patterns: Path, out_root: Path
) -> None:
    builder.build_package(options_for(project, out_root, patterns))
    (project / "docs" / "second.md").write_bytes(b"# Second\n")

    result = builder.build_package(options_for(project, out_root, patterns))

    assert f"{PACKAGE}/payload/docs/second.md" in _zip_names(result.zip_path)
    assert (result.package_dir / "payload" / "docs" / "second.md").is_file()


def test_the_readme_states_the_counts_the_installer_prints(
    project: Path, patterns: Path, out_root: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    result = builder.build_package(options_for(project, out_root, patterns))
    readme = (result.package_dir / "README-PACKAGE.txt").read_text(encoding="ascii")

    args = installer.build_parser().parse_args(["--inspect", "--target", str(out_root / "t")])
    assert installer.run(result.package_dir, args) == 0
    printed = capsys.readouterr().out

    verified = printed.splitlines()[0]
    assert verified.startswith("CHECKSUMS OK")
    assert verified in readme
    assert f"PLAN {result.payload_files} files" in printed
    assert f"PLAN {result.payload_files} files" in readme


def test_the_patterns_file_is_not_copied_into_the_package(
    project: Path, patterns: Path, out_root: Path
) -> None:
    result = builder.build_package(options_for(project, out_root, patterns))

    with zipfile.ZipFile(result.zip_path) as archive:
        names = archive.namelist()
        blob = b"".join(archive.read(name) for name in names)
    assert b"acme-internal" not in blob
    assert b"STAFF" not in blob
    assert not any(name.endswith("patterns.json") for name in names)


def test_the_real_project_passes_the_scrub_and_builds(tmp_path: Path) -> None:
    # The neutral expression is split so that this file does not match its own pattern.
    neutral = write_patterns(
        tmp_path / "neutral.json",
        {"bank_hosts": [r"zzz-no-such-" + r"host-zzz"], "staff_ids": [r"\bZZZ[0-9]{9}\b"]},
    )

    result = builder.build_package(
        options_for(
            PROJECT_ROOT,
            tmp_path / "out",
            neutral,
            # The stand-in gateway and the reserved test domains of the synthetic data.
            extra_url_domains=REAL_PROJECT_URL_EXCEPTIONS,
            extra_email_domains=REAL_PROJECT_EMAIL_EXCEPTIONS,
        )
    )

    assert result.zip_path.is_file()
    assert result.payload_files > 100
    assert installer.verify_package(result.package_dir)


# --- the scrub ---------------------------------------------------------------------------------


def _violations(project: Path, patterns: Path, out_root: Path) -> tuple[builder.Violation, ...]:
    with pytest.raises(builder.ScrubFailedError) as caught:
        builder.build_package(options_for(project, out_root, patterns))
    return caught.value.violations


@pytest.mark.parametrize(
    ("content", "rule"),
    [
        (b"caf\xc3\xa9 is not ascii\n", "non-ascii"),
        (b"see the host acme-internal" + b".test for it\n", "bank-host-pattern"),
        (b"signed by STAFF" + b"12345\n", "staff-id-pattern"),
        (b"fetch http" + b"://other.invalid/path now\n", "url-not-allowed"),
        (b"fetch https" + b"://example.com.invalid/x\n", "url-not-allowed"),
        (b"mail a" + b"@" + b"b.org please\n", "email-not-allowed"),
        (b"key = ghp_" + b"a" * 36 + b"\n", "secret-shaped:code-host-token"),
        (b"-----BEGIN RSA " + b"PRIVATE KEY-----\n", "secret-shaped:private-key"),
    ],
)
def test_each_scrub_rule_stops_the_build_and_names_the_place(
    project: Path, patterns: Path, out_root: Path, content: bytes, rule: str
) -> None:
    _break(project, "docs/guide.md", b"# Guide\nclean line\n" + content)

    violations = _violations(project, patterns, out_root)

    assert violations == (builder.Violation("payload/docs/guide.md", 3, rule),)
    assert not out_root.exists()


@pytest.mark.parametrize(
    "content",
    [
        b"open http" + b"://localhost:8090/ and http" + b"://127.0.0.1:8091/\n",
        b"see https" + b"://example.com/a and https" + b"://docs.example.org/b\n",
        b"write to team" + b"@" + b"example.com\n",
        b"a decorator @pytest.fixture and a dot.name\n",
        b"template: functional-spec" + b"@" + b"1.0.0 is a version, not an address\n",
    ],
)
def test_allowed_addresses_pass(
    project: Path, patterns: Path, out_root: Path, content: bytes
) -> None:
    _break(project, "docs/guide.md", content)

    assert builder.build_package(options_for(project, out_root, patterns)).zip_path.is_file()


def test_a_finding_in_a_file_name_is_reported_against_the_path(
    project: Path, patterns: Path, out_root: Path
) -> None:
    (project / "docs" / "acmebank-notes.md").write_bytes(b"# Notes\n")

    violations = _violations(project, patterns, out_root)

    assert violations == (
        builder.Violation("payload/docs/acmebank-notes.md", 0, "bank-host-pattern"),
    )


def test_binary_files_are_not_checked_for_ascii_but_their_inner_text_is_scanned(
    project: Path, patterns: Path, out_root: Path
) -> None:
    (project / "fixtures" / "plain.pdf").write_bytes(b"%PDF \xe9\xe8 binary\n")
    sheet = io.BytesIO()
    with zipfile.ZipFile(sheet, "w") as archive:
        archive.writestr("xl/sharedStrings.xml", "<t>ok</t>\n<t>acme-internal" + ".test</t>\n")
    (project / "fixtures" / "register.xlsx").write_bytes(sheet.getvalue())

    violations = _violations(project, patterns, out_root)

    assert violations == (
        builder.Violation(
            "payload/fixtures/register.xlsx!xl/sharedStrings.xml", 2, "bank-host-pattern"
        ),
    )


def test_findings_are_listed_in_path_and_line_order(
    project: Path, patterns: Path, out_root: Path
) -> None:
    _break(project, "README.md", b"fine\nSTAFF" + b"00001\n")
    _break(project, "docs/guide.md", b"STAFF" + b"00002\n\nacmebank\n")

    violations = _violations(project, patterns, out_root)

    assert [(v.path, v.line) for v in violations] == [
        ("payload/README.md", 2),
        ("payload/docs/guide.md", 1),
        ("payload/docs/guide.md", 3),
    ]


def test_the_command_line_reports_places_never_the_matched_text(
    project: Path, patterns: Path, out_root: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _break(project, "docs/guide.md", b"the host is acme-internal" + b".test and STAFF" + b"12345\n")

    status = builder.main(
        [
            "--patterns",
            str(patterns),
            "--project-root",
            str(project),
            "--out-root",
            str(out_root),
            "--date",
            "20261028",
        ]
    )

    captured = capsys.readouterr()
    assert status == builder.EXIT_SCRUB_FAILED
    assert "payload/docs/guide.md:1: bank-host-pattern" in captured.err
    assert "payload/docs/guide.md:1: staff-id-pattern" in captured.err
    assert "acme-internal" not in captured.err + captured.out
    assert "12345" not in captured.err + captured.out
    assert not out_root.exists()


# --- the patterns file and the project -----------------------------------------------------------


@pytest.mark.parametrize(
    "document",
    [
        {"bank_hosts": [r"x"]},
        {"staff_ids": [r"x"]},
        {"bank_hosts": [], "staff_ids": [r"x"]},
        {"bank_hosts": [r"x"], "staff_ids": [""]},
        {"bank_hosts": [r"x"], "staff_ids": "x"},
        {"bank_hosts": [r"x"], "staff_ids": ["(unclosed-secret-word"]},
        ["not", "an", "object"],
    ],
)
def test_an_unusable_patterns_file_fails_closed_without_quoting_it(
    project: Path, tmp_path: Path, out_root: Path, document: object
) -> None:
    patterns = write_patterns(tmp_path / "bad.json", document)

    with pytest.raises(builder.PatternsError) as caught:
        builder.build_package(options_for(project, out_root, patterns))

    assert "unclosed-secret-word" not in str(caught.value)
    assert not out_root.exists()


def test_a_missing_or_malformed_patterns_file_fails_closed(
    project: Path, tmp_path: Path, out_root: Path
) -> None:
    broken = tmp_path / "broken.json"
    broken.write_text("{not json", encoding="utf-8")

    for path in (tmp_path / "absent.json", broken):
        with pytest.raises(builder.PatternsError):
            builder.build_package(options_for(project, out_root, path))
    assert not out_root.exists()


@pytest.mark.parametrize(
    "missing", ["pyproject.toml", "INSTALL-WORKSTATION.md", ".env.example", "docs", "src"]
)
def test_a_missing_deliverable_stops_the_build(
    project: Path, patterns: Path, out_root: Path, missing: str
) -> None:
    target = project / missing
    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink()

    with pytest.raises(builder.ProjectError):
        builder.build_package(options_for(project, out_root, patterns))
    assert not out_root.exists()


def test_the_command_line_requires_the_patterns_path(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as caught:
        builder.main([])

    assert caught.value.code == 2
    assert "--patterns" in capsys.readouterr().err


def test_the_command_line_prints_the_size_and_checksum(
    project: Path, patterns: Path, out_root: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    status = builder.main(
        [
            "--patterns",
            str(patterns),
            "--project-root",
            str(project),
            "--out-root",
            str(out_root),
            "--date",
            BUILD_DATE.strftime("%Y%m%d"),
        ]
    )

    out = capsys.readouterr().out
    zip_path = out_root / f"{PACKAGE}.zip"
    assert status == builder.EXIT_OK
    assert f"Size:           {zip_path.stat().st_size} bytes" in out
    assert hashlib.sha256(zip_path.read_bytes()).hexdigest() in out


def test_a_bad_input_exits_with_status_two(
    project: Path, tmp_path: Path, out_root: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    status = builder.main(
        [
            "--patterns",
            str(tmp_path / "absent.json"),
            "--project-root",
            str(project),
            "--out-root",
            str(out_root),
        ]
    )

    assert status == builder.EXIT_BAD_INPUT
    assert "BUILD FAILED" in capsys.readouterr().err


def test_a_named_exception_lets_a_reserved_domain_through_and_is_announced(
    project: Path, patterns: Path, out_root: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    _break(project, "docs/guide.md", b"api at https" + b"://svc.example.invalid/x\n")
    _break(project, "README.md", b"contact ops" + b"@" + b"machine.invalid\n")
    base = ["--patterns", str(patterns), "--project-root", str(project)]
    base += ["--out-root", str(out_root), "--date", "20261028"]

    strict = builder.main(base)
    capsys.readouterr()
    relaxed = builder.main(
        [*base, "--allow-url-host", "invalid", "--allow-email-domain", "machine.invalid"]
    )

    out = capsys.readouterr().out
    assert strict == builder.EXIT_SCRUB_FAILED
    assert relaxed == builder.EXIT_OK
    assert "NOTE scrub exception: URLs to invalid allowed" in out
    assert "NOTE scrub exception: email at machine.invalid allowed" in out
