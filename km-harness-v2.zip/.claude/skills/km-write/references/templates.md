# km-write templates

Replace <...>. Keep the order. The examples use an invented product and are only a model of
shape and tone.

## Sprint summary
Exactly three sentences. Merged work only, unless a clause says "planned".
```
<Who> can now <what a person can do>. <What was built, one plain clause, with a number>.
Next: <what comes next, or the one decision needed>.
```
Rule: when nothing changes for users, say so plainly and give a number from the evidence.
Example: "Nothing new for users this sprint; the import step now handles 3 times more files."
Before:
```
This sprint we merged 4 PRs covering the ingestion refactor and the cache layer, added 212
unit tests and fixed a flaky pipeline job. Tickets are mostly Done. We will probably look at
the embedding service next if time allows, and it would be good to align on the schema.
```
After:
```
Cooks can now save a recipe to a shopping list and see the list on their phone. Four changes
were finished: saving, the list page, quantity merging and list sharing. Next: sharing by
link; one decision is open, whether shared lists expire after 30 days.
```

## Status note
Outcome first, one line of state, then the single ask.
```
<Area>: <outcome in one line>.
State: <n> of <m> <units> done, <k> in review, <j> not started.
Next: <one line>.
Need from you: <one question, or "nothing">.
```
Before:
```
Things are going well on the import work, a lot of progress, some blockers around the
format parsing, will keep you posted, let me know if you have thoughts on priorities.
```
After:
```
Recipe import: photos and PDFs import; web pages do not yet.
State: 2 of 3 import types done, 1 in review, 0 not started.
Next: web pages, after the review of the second type.
Need from you: nothing.
```

## Decision card
One question, the recommended answer, the cost of waiting. No lettered option gallery.
```
<Title as a short phrase>
Why it matters: <one sentence in business terms>.
Question: <exactly one question>
Recommended: <the answer> - <one-sentence reason>.
If undecided: <what slips, and by how long>.
```
Before:
```
We need to decide between a relational schema with a join table, a document model, or a
hybrid with a search index. Options A, B and C each have trade-offs in consistency, latency
and migration effort. Thoughts?
```
After:
```
Where shared lists are stored
Why it matters: shared lists must open in under 2 seconds for 5,000 users.
Question: May we keep shared lists in the main database for now?
Recommended: Yes - it needs no new service and covers 5,000 users with room to spare.
If undecided: list sharing slips by about 1 week.
```

## Ticket text
```
Summary: <Product> - <Area>: <outcome in product language>
Parent: <TICKET-KEY of the parent>
Problem: <what a person experiences today, 1 to 3 short sentences>
Outcome: <what they can do afterwards>
Done when:
- <a check that can fail, in product terms>
- <a second check, with one case where it must be refused or must not change>
```
Before:
```
Summary: Fix bug in list service -- NPE in mapper
Description: mapper throws on null qty, see stack trace, refactor ListDto, add tests.
```
After:
```
Summary: Recipe Box - Shopping list: show lists with an empty quantity
Parent: <TICKET-KEY>
Problem: A list that holds an item without a quantity does not open; the cook sees an
  empty page.
Outcome: The list opens and shows such items with a dash instead of a quantity.
Done when:
- A list with 3 items, one without a quantity, opens and shows all 3.
- A list with a negative quantity is still refused with a clear message.
```
