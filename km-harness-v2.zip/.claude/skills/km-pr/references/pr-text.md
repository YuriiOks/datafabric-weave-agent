# Pull request text: checks

Read the draft title and body, then check each line below. Report only the failures.

- Title: follows the repository's title format (default `[<EPIC-KEY>] [<TICKET-KEY>] Title`,
  see pr-body.md). Ask the owner for the ticket tags. Never invent or guess a ticket key.
- Body sections follow pr-body.md; Self-review and Checks state only results that were
  really obtained, for the current head. No check is implied that was not run.
- Body: says what changed and why, in product language that a non-engineer follows. Short.
- Body has no session link, no attribution line typed by hand, no mention of harness files
  (canon, kb, designs, skills, agents, work folder) and no text copied from them.
- Body has no credential, key, token, staff id or email address, and no host name.
- If people see a change on screen, the body carries the proof the repository asks for. If you
  cannot tell what it asks for, ask the owner. Screenshots are the owner's to supply.
- The pull request is opened as a draft. Marking it ready is a separate go from the owner.
- One purpose per pull request. If the diff mixes unrelated changes, say so and stop.
- The branch is based on the main line unless the diff really depends on another open branch.
- Opening, editing or commenting on a pull request needs its own go. A go for a push does not
  cover it.
