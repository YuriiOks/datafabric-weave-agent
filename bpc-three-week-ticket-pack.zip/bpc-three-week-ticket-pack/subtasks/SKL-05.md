---
pack_id: "bpc-sep26-v1"
local_id: "SKL-05"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1169"
summary: "Prepare the Skill lexical-baseline corpus and adjudicated suggestion case pack"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 8
scope: "recommendations"
create_by_default: false
planned_start: "2026-09-24"
planned_due: "2026-09-25"
dates_profile: "recommendations"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["SKL-04","CORE-04","CORE-07","CORE-08"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-skl-05"
architecture_sections: ["validation-gates","read-contract","evaluation","delivery"]
---

# Prepare the Skill lexical-baseline corpus and adjudicated suggestion case pack

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1169**. Local reference **SKL-05** is not a Jira key.
- Estimate: **8 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **not scheduled; do not create by default**.
- Recommendation extension: **2026-09-24 → 2026-09-25 (D12–D13)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

The source graph can prove declared relationships but cannot prove whether a Skill is relevant to a need. Prepare the authorised, publication-pinned Skill input corpus and a domain-adjudicated case pack so CORE-08 can measure a lexical baseline and CORE-09 can report Skill results truthfully.

## Scope

Define the Skill-specific baseline input mapping from the authorised active publication, exposing only approved lexical fields and their provenance/completeness markers. Build the case and review format with domain owners, including positive Skill needs, hard negatives, legitimate empty needs, ambiguous requests, restricted visibility cases, prerequisite scenarios and degraded-source cases. Feed the shared replay, lexical baseline and evaluation contracts; do not implement a separate ranker or result surface.

## Boundaries, inputs and outputs

Inputs are authorised SKL-04 publication reads, CORE-07 baseline observation/replay contracts, CORE-08 lexical baseline interface and CORE-09 evaluation rules. Outputs are the Skill corpus manifest, field-availability report, adjudicated relevance labels, grouped split assignment, evaluation-case metadata and a reviewer decision log. A declared graph edge may be cited as factual prerequisite evidence, but it is never a relevance label or semantic score.

## Technical steps

1. Select the lexical fields from the authorised publication only after confirming their source provenance and missing/malformed-state treatment.
2. Pin every corpus and case to the same publication, policy context and source-manifest identifiers used by the shared baseline run.
3. Build a review queue that asks domain reviewers to label relevance independently of declared co-use, dependencies or portal status.
4. Include cases for relevant Skills, confusable Skills, correct empty results, duplicate/alias risk, inaccessible Skills, missing descriptions, unresolved dependencies and source-unavailable behaviour.
5. Group related needs before assigning development, validation and frozen final-test partitions to avoid leakage.
6. Define reporting denominators for planned, completed, judged, unjudged, inaccessible, unavailable and valid-empty cases; hand the result to CORE-08 and CORE-09.

## Acceptance criteria

- [ ] The lexical corpus references only authorised fields from a pinned publication and records each field's availability and provenance.
- [ ] Every relevance judgement has a named domain review outcome or remains explicitly unjudged; source declarations never supply the label.
- [ ] The case pack contains positive, hard-negative, valid-empty, access-restricted, incomplete-description and unavailable-source scenarios with expected truthful outcome classes.
- [ ] Related cases are kept in one partition and the final held-out partition has no tuning feedback recorded against it.
- [ ] Reporting distinguishes a measured empty result from failed, disabled, access-filtered, missing-source and unjudged cases.

## Meaningful verification cases

- A Skill with a declared MCP allowance is not judged relevant without independent reviewer evidence.
- A query with no authorised relevant Skill produces a valid empty expectation rather than a failure proxy.
- An inaccessible otherwise-relevant Skill cannot appear in the result set and is recorded as an access scenario.
- A malformed or absent description is reported as reduced input coverage, not silently treated as lexical non-relevance.
- A dependency prerequisite may be shown as source evidence only after the suggested Skill is independently judged relevant.

## Evidence to attach

Attach the corpus manifest, field-availability report, label and adjudication log, grouped split manifest, denominator definition and a baseline handoff report identifying all excluded or unmeasured cases.

## Blockers

This task requires confirmation that the shared lexical recommendation baseline is in scope, authorised publication reads, access/privacy approval for cases, and committed domain reviewers and acceptance targets. Without adjudication it can prepare the case format and corpus manifest but cannot support a quality claim.

## Out of scope

Embeddings, graph boosting, model assessment, automatic Skill attachment, recommendation UI, Skill execution, tool or MCP execution, external Agent Hub API work and a release decision.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [SKL-04](SKL-04.md) must finish its stated contract boundary before this task starts.
- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.
- [CORE-08](CORE-08.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `validation-gates`, `read-contract`, `evaluation`, `delivery`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
