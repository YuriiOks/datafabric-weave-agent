# Payments Rulebook

Publisher: Example Scheme
Edition: 2026.1
Effective date: 2026-11-16

## Table of Contents

- 1 Scope and definitions ... 3
  - 1.1 Scope ... 3
    - 1.1.1 Transfers in scope ... 3
    - 1.1.2 Transfers out of scope ... 3
  - 1.2 Defined terms ... 3
    - 1.2.1 Participant ... 3
    - 1.2.2 Credit transfer ... 3
- 2 Participants ... 3
  - 2.1 Eligibility ... 3
    - 2.1.1 Admission ... 3
    - 2.1.2 Suspension ... 3
  - 2.2 Obligations ... 3
    - 2.2.1 Contact details ... 3
    - 2.2.2 Record keeping ... 3
- 3 Message formats ... 3
  - 3.1 Credit transfer message ... 4
    - 3.1.1 Mandatory elements ... 4
    - 3.1.2 Optional elements ... 4
  - 3.2 Identifiers ... 4
    - 3.2.1 Account identifiers ... 4
- 4 Inbound credit transfers ... 4
  - 4.1 Receipt ... 4
    - 4.1.1 Timing of receipt ... 4
    - 4.1.2 Acknowledgement ... 4
  - 4.2 Validation ... 4
    - 4.2.1 Currency of inbound credit transfers ... 4
    - 4.2.2 Amount limits ... 4
    - 4.2.3 Beneficiary account checks ... 4
    - 4.2.4 Reference format ... 4
  - 4.3 Settlement ... 4
    - 4.3.1 Settlement cycle ... 5
    - 4.3.2 Settlement currency ... 5
- 5 Outbound credit transfers ... 5
  - 5.1 Initiation ... 5
    - 5.1.1 Currency of outbound transfers ... 5
    - 5.1.2 Cut-off times ... 5
  - 5.2 Rejections and returns ... 5
    - 5.2.1 Reason codes ... 5
    - 5.2.2 Return timing ... 5
- 6 Operational resilience ... 5
  - 6.1 Availability ... 5
    - 6.1.1 Service availability target ... 5
  - 6.2 Incident reporting ... 5
    - 6.2.1 Notification timing ... 5
  - 6.3 Message validation ... 5
    - 6.3.1 Schema validation ... 6
    - 6.3.2 Detailed validation rules ... 6

## 1 Scope and definitions

This section covers scope and definitions.

### 1.1 Scope

This subsection covers scope.

#### 1.1.1 Transfers in scope

This rulebook applies to credit transfers exchanged between participants of Example Scheme in the payments domain.

#### 1.1.2 Transfers out of scope

Card payments, direct debits and cheques are outside the scope of this rulebook.

### 1.2 Defined terms

This subsection covers defined terms.

#### 1.2.1 Participant

A participant is an institution admitted to Example Scheme under the rules of section 2.

#### 1.2.2 Credit transfer

A credit transfer is an instruction to move funds from a debtor account to a creditor account.

## 2 Participants

This section covers participants.

### 2.1 Eligibility

This subsection covers eligibility.

#### 2.1.1 Admission

An institution is admitted once the scheme operator confirms that it meets the criteria published with this rulebook.

#### 2.1.2 Suspension

The scheme operator may suspend a participant that repeatedly breaches this rulebook.

### 2.2 Obligations

This subsection covers obligations.

#### 2.2.1 Contact details

Each participant shall keep its operational contact details current with the scheme operator.

#### 2.2.2 Record keeping

Each participant shall keep records of all credit transfers for at least ten years.

## 3 Message formats

This section covers message formats.

### 3.1 Credit transfer message

This subsection covers credit transfer message.

#### 3.1.1 Mandatory elements

Every credit transfer message must carry a message identifier, an instructed amount, a debtor account and a creditor account.

#### 3.1.2 Optional elements

A credit transfer message may carry a remittance reference of up to 140 characters.

### 3.2 Identifiers

This subsection covers identifiers.

#### 3.2.1 Account identifiers

Accounts are identified by an international account number of at most 34 characters.

## 4 Inbound credit transfers

This section covers inbound credit transfers.

### 4.1 Receipt

This subsection covers receipt.

#### 4.1.1 Timing of receipt

A credit transfer is received when the gateway of the participant accepts the complete message.

#### 4.1.2 Acknowledgement

A participant shall acknowledge every received credit transfer within five seconds.

### 4.2 Validation

This subsection covers validation.

#### 4.2.1 Currency of inbound credit transfers

An inbound credit transfer may be denominated in euro or in pounds sterling. A credit transfer denominated in any other currency shall be rejected with reason code CUR01. The currency is carried in the currency element of the message.

#### 4.2.2 Amount limits

An inbound credit transfer shall not exceed the per-transfer limit published by the scheme operator.

#### 4.2.3 Beneficiary account checks

The receiving participant shall confirm that the creditor account exists and can receive funds.

#### 4.2.4 Reference format

The remittance reference of an inbound credit transfer shall not contain control characters.

### 4.3 Settlement

This subsection covers settlement.

#### 4.3.1 Settlement cycle

Accepted credit transfers are settled in the next settlement cycle after receipt.

#### 4.3.2 Settlement currency

Settlement takes place in the currency of the credit transfer.

## 5 Outbound credit transfers

This section covers outbound credit transfers.

### 5.1 Initiation

This subsection covers initiation.

#### 5.1.1 Currency of outbound transfers

An outbound credit transfer may be initiated in euro only.

#### 5.1.2 Cut-off times

The initiating participant shall submit outbound credit transfers before the daily cut-off time.

### 5.2 Rejections and returns

This subsection covers rejections and returns.

#### 5.2.1 Reason codes

A rejected credit transfer shall carry exactly one reason code from the published list, for example CUR01.

#### 5.2.2 Return timing

A returned credit transfer shall be sent back within two business days.

## 6 Operational resilience

This section covers operational resilience.

### 6.1 Availability

This subsection covers availability.

#### 6.1.1 Service availability target

A participant shall keep its credit transfer service available at least 99.9 percent of each calendar month.

### 6.2 Incident reporting

This subsection covers incident reporting.

#### 6.2.1 Notification timing

A participant shall notify the scheme operator of a major incident within four hours.

### 6.3 Message validation

This subsection covers message validation.

#### 6.3.1 Schema validation

Every message shall validate against the published message schema before it is processed.

#### 6.3.2 Detailed validation rules

(a) The currency element must be present. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(b) The debtor account element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(c) The instructed amount element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG01, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(d) The message identifier element must be expressed in upper case. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(e) The settlement date element must be present. A message that fails this rule shall be rejected with reason code MSG02, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(f) The end-to-end identifier element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(g) The charge bearer code element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG05, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(h) The settlement date element must not exceed thirty-five characters. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(i) The charge bearer code element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(j) The currency element must match the pattern published with the message schema. A message that fails this rule shall be rejected with reason code MSG06, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(k) The remittance reference element must not be empty. A message that fails this rule shall be rejected with reason code MSG01, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(l) The instructed amount element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG05, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(m) The creditor account element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG05, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(n) The instructed amount element must match the pattern published with the message schema. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(o) The purpose code element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG06, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(p) The creditor name element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG12, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(q) The creditor name element must not be empty. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(r) The creditor name element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG11, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(s) The remittance reference element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(t) The debtor name element must match the pattern published with the message schema. A message that fails this rule shall be rejected with reason code MSG10, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(u) The currency element must be present. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(v) The settlement date element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG05, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(w) The debtor account element must be present. A message that fails this rule shall be rejected with reason code MSG09, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(x) The debtor name element must be present. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(y) The message identifier element must be expressed in upper case. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(z) The purpose code element must not exceed thirty-five characters. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(aa) The creditor account element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG05, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ab) The creditor name element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG08, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ac) The debtor name element must not be empty. A message that fails this rule shall be rejected with reason code MSG10, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ad) The purpose code element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG09, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ae) The remittance reference element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(af) The end-to-end identifier element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG12, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ag) The remittance reference element must not be empty. A message that fails this rule shall be rejected with reason code MSG07, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ah) The remittance reference element must match the pattern published with the message schema. A message that fails this rule shall be rejected with reason code MSG08, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ai) The purpose code element must be present. A message that fails this rule shall be rejected with reason code MSG02, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(aj) The instructed amount element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG09, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ak) The charge bearer code element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG08, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(al) The message identifier element must not exceed thirty-five characters. A message that fails this rule shall be rejected with reason code MSG05, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(am) The message identifier element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(an) The debtor account element must not be empty. A message that fails this rule shall be rejected with reason code MSG09, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ao) The debtor account element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ap) The creditor name element must be expressed in upper case. A message that fails this rule shall be rejected with reason code MSG12, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(aq) The debtor name element must match the pattern published with the message schema. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ar) The debtor name element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG06, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(as) The end-to-end identifier element must contain only characters from the permitted set. A message that fails this rule shall be rejected with reason code MSG10, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(at) The message identifier element must match the pattern published with the message schema. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(au) The debtor name element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG09, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(av) The debtor name element must not contain leading or trailing spaces. A message that fails this rule shall be rejected with reason code MSG03, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(aw) The debtor account element must be present. A message that fails this rule shall be rejected with reason code MSG04, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

(ax) The remittance reference element must agree with the value in the group header. A message that fails this rule shall be rejected with reason code MSG02, and the receiving participant shall record the failure together with the message identifier and the time of receipt so that the sending participant can correct and resubmit the message.

