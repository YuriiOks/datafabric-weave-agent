"""The publication checks: blocking, warning and report-only."""

from __future__ import annotations

from typing import Final

from kp.config import Thresholds
from kp.domain import CheckResult, CheckSeverity
from kp.publish.measure import Measurements

HAS_ITEMS: Final = "has_items"
MODEL_CONFORMANCE: Final = "model_conformance"
GUESSED_SHARE: Final = "guessed_share"
ITEM_COUNT_CHANGE: Final = "item_count_change"
ITEMS_HAVE_SOURCE: Final = "items_have_source"
ITEMS_WITHOUT_LINKS: Final = "items_without_links"
CLAUSES_WITHOUT_FIELD_LINK: Final = "clauses_without_field_link"
AVERAGE_GUESSED_SCORE: Final = "average_guessed_score"
STORIES_WITHOUT_REQUIREMENT_OR_CLAUSE: Final = "stories_without_requirement_or_clause"

_LISTED_KEYS = 10


def _share(part: int, whole: int) -> float:
    return part / whole if whole else 0.0


def _item_count_change(measured: Measurements, thresholds: Thresholds) -> CheckResult:
    previous = measured.previous_item_count
    if not previous:
        return CheckResult(
            name=ITEM_COUNT_CHANGE,
            severity=CheckSeverity.BLOCKING,
            passed=True,
            value=0.0,
            threshold=thresholds.item_count_change_max,
            detail="No earlier version to compare with.",
        )
    change = abs(measured.item_count - previous) / previous
    return CheckResult(
        name=ITEM_COUNT_CHANGE,
        severity=CheckSeverity.BLOCKING,
        passed=change <= thresholds.item_count_change_max,
        value=change,
        threshold=thresholds.item_count_change_max,
        detail=f"{previous} items before, {measured.item_count} now.",
    )


def _average_guessed_score(measured: Measurements, thresholds: Thresholds) -> CheckResult:
    average = measured.links.average_guessed_score
    if average is None:
        return CheckResult(
            name=AVERAGE_GUESSED_SCORE,
            severity=CheckSeverity.WARNING,
            passed=True,
            threshold=thresholds.average_guessed_score_min,
            detail="No guessed links in use.",
        )
    return CheckResult(
        name=AVERAGE_GUESSED_SCORE,
        severity=CheckSeverity.WARNING,
        passed=average >= thresholds.average_guessed_score_min,
        value=average,
        threshold=thresholds.average_guessed_score_min,
        detail=f"{measured.links.guessed} guessed links in use.",
    )


def evaluate_checks(measured: Measurements, thresholds: Thresholds) -> tuple[CheckResult, ...]:
    """Judge a candidate version.

    Blocking: the candidate holds at least one item (an empty or failed load is never
    published); every stored link conforms to the model (100%); guessed share of the links in
    use at most the limit; item count within the allowed change of the serving version;
    every item names its source (100%). Warning: items with no links, clauses with no
    schema-field link, average guessed score. Report only: stories with no requirement or
    clause. Only blocking failures stop publication.

    :param measured: The measurements of the candidate
    :param thresholds: The limits
    :return: One result per check, blocking first
    """
    links = measured.links
    stories = measured.stories_without_requirement_or_clause
    listed = ", ".join(stories[:_LISTED_KEYS]) + (" ..." if len(stories) > _LISTED_KEYS else "")
    items_without_links = _share(measured.items_without_links, measured.linkable_items)
    clauses_without_field = _share(measured.clauses_without_field_link, measured.clauses)
    return (
        CheckResult(
            name=HAS_ITEMS,
            severity=CheckSeverity.BLOCKING,
            passed=measured.item_count > 0,
            value=float(measured.item_count),
            threshold=1.0,
            detail=f"{measured.item_count} items in the candidate.",
        ),
        CheckResult(
            name=MODEL_CONFORMANCE,
            severity=CheckSeverity.BLOCKING,
            passed=links.nonconforming == 0,
            value=links.model_conformance,
            threshold=1.0,
            detail=f"{links.nonconforming} of {links.checked} links break the model.",
        ),
        CheckResult(
            name=GUESSED_SHARE,
            severity=CheckSeverity.BLOCKING,
            passed=links.guessed_share <= thresholds.guessed_share_max,
            value=links.guessed_share,
            threshold=thresholds.guessed_share_max,
            detail=f"{links.guessed} guessed of {links.in_use} links in use.",
        ),
        _item_count_change(measured, thresholds),
        CheckResult(
            name=ITEMS_HAVE_SOURCE,
            severity=CheckSeverity.BLOCKING,
            passed=measured.items_without_source == 0,
            value=1.0 - _share(measured.items_without_source, measured.item_count),
            threshold=1.0,
            detail=(
                f"{measured.items_without_source} of {measured.item_count} items have no source."
            ),
        ),
        CheckResult(
            name=ITEMS_WITHOUT_LINKS,
            severity=CheckSeverity.WARNING,
            passed=items_without_links <= thresholds.items_without_links_max,
            value=items_without_links,
            threshold=thresholds.items_without_links_max,
            detail=(
                f"{measured.items_without_links} of {measured.linkable_items} items have no links."
            ),
        ),
        CheckResult(
            name=CLAUSES_WITHOUT_FIELD_LINK,
            severity=CheckSeverity.WARNING,
            passed=clauses_without_field <= thresholds.clauses_without_field_link_max,
            value=clauses_without_field,
            threshold=thresholds.clauses_without_field_link_max,
            detail=(
                f"{measured.clauses_without_field_link} of {measured.clauses} clauses "
                "have no schema-field link."
            ),
        ),
        _average_guessed_score(measured, thresholds),
        CheckResult(
            name=STORIES_WITHOUT_REQUIREMENT_OR_CLAUSE,
            severity=CheckSeverity.REPORT,
            passed=True,
            value=float(len(stories)),
            detail=f"{len(stories)} stories: {listed}" if stories else "Every story is tied.",
        ),
    )
