"""Reader factory: stand-in readers from settings, and the seam for the real route."""

from __future__ import annotations

from pathlib import Path

import pytest

from kp.config import Mode, Settings
from kp.domain.enums import SourceKind
from kp.errors import ConfigurationError
from kp.sources import (
    CodeRepoReader,
    ConfluenceExportReader,
    DocumentLibraryReader,
    JiraExportReader,
    RegulatoryRepoReader,
    SourceReader,
    StandInLocations,
    attributes,
    create_reader,
    create_readers,
)

from .support import drain


def _local(data_root: Path, **updates: object) -> Settings:
    """Local settings over the copied data; ``updates`` are applied without re-validation."""
    base = Settings(
        _env_file=None,
        mode=Mode.LOCAL,
        data_dir=data_root,
        document_library_root=data_root / "library",
        regulatory_repo_path=data_root / "regulatory_repo",
    )
    return base.model_copy(update=updates)


def _real(data_root: Path) -> Settings:
    return _local(data_root, mode=Mode.REAL)


def test_local_settings_build_the_stand_in_reader_of_each_route(data_root: Path) -> None:
    readers = create_readers(_local(data_root))

    assert {kind: type(reader) for kind, reader in readers.items()} == {
        SourceKind.DOCUMENT_LIBRARY: DocumentLibraryReader,
        SourceKind.CONFLUENCE: ConfluenceExportReader,
        SourceKind.JIRA: JiraExportReader,
        SourceKind.GITHUB: CodeRepoReader,
        SourceKind.REGULATORY_REPO: RegulatoryRepoReader,
    }
    assert all(isinstance(reader, SourceReader) for reader in readers.values())


def test_created_readers_read_the_configured_data(data_root: Path) -> None:
    readers = create_readers(_local(data_root))

    for reader in readers.values():
        items, _ = drain(reader)
        assert items


def test_the_agreed_label_comes_from_the_settings(data_root: Path) -> None:
    reader = create_reader(
        SourceKind.CONFLUENCE, _local(data_root, confluence_approved_label="reviewed")
    )
    items, _ = drain(reader)

    attrs = reader.fetch(items[0].key).metadata.attributes

    assert attrs[attributes.REQUIRED_LABEL] == "reviewed"
    assert attrs[attributes.HAS_REQUIRED_LABEL] is False


def test_jira_page_size_and_project_come_from_the_settings(data_root: Path) -> None:
    reader = create_reader(SourceKind.JIRA, _local(data_root, jira_page_size=2))

    batch = reader.list_changed(None)
    none = create_reader(SourceKind.JIRA, _local(data_root, jira_project_key="OTHER"))

    assert len(batch.items) == 2
    assert none.list_changed(None).items == ()


def test_explicit_locations_override_the_data_folder(data_root: Path, tmp_path: Path) -> None:
    elsewhere = tmp_path / "pages"
    (data_root / "confluence").rename(elsewhere)

    reader = create_reader(
        SourceKind.CONFLUENCE,
        _local(data_root / "nowhere"),
        locations=StandInLocations(confluence=elsewhere),
    )

    assert drain(reader)[0]


def test_unset_library_folder_is_a_configuration_error(data_root: Path) -> None:
    with pytest.raises(ConfigurationError, match="KP_DOCUMENT_LIBRARY_ROOT"):
        create_reader(SourceKind.DOCUMENT_LIBRARY, _local(data_root, document_library_root=None))


def test_missing_folder_is_a_configuration_error(data_root: Path) -> None:
    with pytest.raises(ConfigurationError, match="does not exist"):
        create_reader(SourceKind.GITHUB, _local(data_root / "nowhere"))


def test_real_mode_uses_the_registered_builder_without_reading_local_data(
    data_root: Path,
) -> None:
    built: list[Settings] = []
    sentinel = DocumentLibraryReader(data_root / "library")

    def builder(settings: Settings) -> SourceReader:
        built.append(settings)
        return sentinel

    reader = create_reader(
        SourceKind.JIRA, _real(data_root), real_builders={SourceKind.JIRA: builder}
    )

    assert reader is sentinel
    assert built[0].mode is Mode.REAL


def test_real_mode_without_a_builder_refuses_gateway_only_sources(data_root: Path) -> None:
    for kind in (SourceKind.CONFLUENCE, SourceKind.JIRA, SourceKind.GITHUB):
        with pytest.raises(ConfigurationError, match="No real-route reader"):
            create_reader(kind, _real(data_root))


def test_real_mode_keeps_reading_the_configured_library_and_repository_folders(
    data_root: Path,
) -> None:
    settings = _real(data_root)

    assert isinstance(create_reader(SourceKind.DOCUMENT_LIBRARY, settings), DocumentLibraryReader)
    assert isinstance(create_reader(SourceKind.REGULATORY_REPO, settings), RegulatoryRepoReader)


def test_builders_are_ignored_in_local_mode(data_root: Path) -> None:
    def builder(settings: Settings) -> SourceReader:
        raise AssertionError("must not be called in local mode")

    reader = create_reader(
        SourceKind.JIRA, _local(data_root), real_builders={SourceKind.JIRA: builder}
    )

    assert isinstance(reader, JiraExportReader)


def test_export_paths_in_the_settings_replace_the_folders_under_the_data_folder(
    data_root: Path, tmp_path: Path
) -> None:
    pages, issues, checkout = tmp_path / "pages", tmp_path / "issues", tmp_path / "checkout"
    for folder in (pages, issues, checkout):
        folder.mkdir()
    settings = _local(
        data_root.parent / "nowhere",
        confluence_export_path=pages,
        jira_export_path=issues,
        code_repo_path=checkout,
    )

    readers = create_readers(settings, [SourceKind.CONFLUENCE, SourceKind.JIRA, SourceKind.GITHUB])

    assert isinstance(readers[SourceKind.CONFLUENCE], ConfluenceExportReader)
    assert isinstance(readers[SourceKind.JIRA], JiraExportReader)
    assert isinstance(readers[SourceKind.GITHUB], CodeRepoReader)


def test_a_missing_export_folder_names_the_setting_that_points_at_it(
    data_root: Path, tmp_path: Path
) -> None:
    settings = _local(data_root, jira_export_path=tmp_path / "missing")

    with pytest.raises(ConfigurationError, match="KP_JIRA_EXPORT_PATH"):
        create_reader(SourceKind.JIRA, settings)
