"""Persistence of knowledge versions."""

from __future__ import annotations

from datetime import date

from sqlalchemy import Connection, RowMapping, delete, insert, select, update

from kp.domain import CheckResult, KnowledgeVersion, KnowledgeVersionState
from kp.publish.errors import UnknownKnowledgeVersionError
from kp.store.schema import knowledge_version


def _to_version(row: RowMapping) -> KnowledgeVersion:
    return KnowledgeVersion(
        version_id=row["version_id"],
        run_id=row["run_id"],
        state=KnowledgeVersionState(row["state"]),
        checks=tuple(CheckResult.model_validate(check) for check in row["checks"]),
        item_count=row["item_count"],
        created_at=row["created_at"],
        published_at=row["published_at"],
        retained_until=row["retained_until"],
    )


def _values(version: KnowledgeVersion) -> dict[str, object]:
    return {
        "run_id": version.run_id,
        "state": version.state.value,
        "checks": [check.model_dump(mode="json") for check in version.checks],
        "item_count": version.item_count,
        "created_at": version.created_at,
        "published_at": version.published_at,
        "retained_until": version.retained_until,
    }


class KnowledgeVersionStore:
    """Reads and writes ``knowledge_version`` rows.

    The version serving readers is the one in state ``published``; the publisher retires
    the one before in the same transaction that publishes the next, so within one unit of
    work there is never more than one. Two publishers working at the same time are not
    serialised here: run one publication at a time.

    :param connection: A connection inside the caller's unit of work
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def add(self, version: KnowledgeVersion) -> None:
        """Insert a new version.

        :param version: The version, normally in state ``staged``
        """
        self._connection.execute(
            insert(knowledge_version).values(version_id=version.version_id, **_values(version))
        )

    def save(self, version: KnowledgeVersion) -> None:
        """Write the current state of an existing version.

        :param version: The version with its new state, checks and dates
        :raises UnknownKnowledgeVersionError: If the version was never added
        """
        result = self._connection.execute(
            update(knowledge_version)
            .where(knowledge_version.c.version_id == version.version_id)
            .values(**_values(version))
        )
        if result.rowcount == 0:
            raise UnknownKnowledgeVersionError(f"No knowledge version {version.version_id}")

    def get(self, version_id: str) -> KnowledgeVersion:
        """Fetch one version.

        :param version_id: The version identity
        :return: The version
        :raises UnknownKnowledgeVersionError: If there is none
        """
        row = (
            self._connection.execute(
                select(knowledge_version).where(knowledge_version.c.version_id == version_id)
            )
            .mappings()
            .first()
        )
        if row is None:
            raise UnknownKnowledgeVersionError(f"No knowledge version {version_id}")
        return _to_version(row)

    def current(self) -> KnowledgeVersion | None:
        """Return the version now serving.

        :return: The published version, or ``None`` before the first publication
        """
        row = (
            self._connection.execute(
                select(knowledge_version)
                .where(knowledge_version.c.state == KnowledgeVersionState.PUBLISHED.value)
                .order_by(knowledge_version.c.published_at.desc())
                .limit(1)
            )
            .mappings()
            .first()
        )
        return None if row is None else _to_version(row)

    def all(self) -> list[KnowledgeVersion]:
        """List every version, newest first.

        :return: Published, retired, failed and staged versions
        """
        rows = self._connection.execute(
            select(knowledge_version).order_by(
                knowledge_version.c.created_at.desc(), knowledge_version.c.version_id
            )
        ).mappings()
        return [_to_version(row) for row in rows]

    def delete_retired_before(self, today: date) -> int:
        """Remove retired versions whose retention ended before a date.

        Failed versions are never removed here: they stay until someone has inspected them.

        :param today: The current date
        :return: How many versions were removed
        """
        result = self._connection.execute(
            delete(knowledge_version).where(
                knowledge_version.c.state == KnowledgeVersionState.RETIRED.value,
                knowledge_version.c.retained_until < today,
            )
        )
        return int(result.rowcount)
