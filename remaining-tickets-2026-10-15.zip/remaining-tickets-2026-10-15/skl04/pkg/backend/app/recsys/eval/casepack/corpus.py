"""The corpus manifest and field-availability report for one component type.

The manifest lists every published record of the type in one pinned catalogue: which lexical
fields it carries and in what state, the source evidence it was built from, and whether it is
baseline input. It keeps a digest of each field's text, never the text itself; the baseline
run reads the text from the same publication and can prove it read the same bytes.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable, Mapping, Sequence
from enum import Enum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.recsys.contracts import ComponentType
from app.recsys.contracts.catalogue import QualityFlag
from app.recsys.contracts.states import GraphStatus, RecommendationEligibility
from app.recsys.eval.casepack.lineage import (
    CasePackError,
    CasePackLineage,
    canonical_digest,
    enum_value,
    evidence_pin,
)

if TYPE_CHECKING:
    from app.recsys.contracts.resolution import CanonicalRecord

#: The lexical fields a canonical record carries. Nothing else is baseline text.
LEXICAL_FIELDS: tuple[str, ...] = ("name", "description")

#: Fields the legacy retrieval text concatenates that the canonical record does not carry.
#: They are reported as not published and are never synthesised.
NOT_PUBLISHED_FIELDS: tuple[str, ...] = ("triggers", "tools", "tags")

_MISSING_FLAGS: Mapping[str, frozenset[str]] = {
    "name": frozenset(),
    "description": frozenset({QualityFlag.empty_description.value}),
}
_MALFORMED_FLAGS: Mapping[str, frozenset[str]] = {
    "name": frozenset(),
    "description": frozenset(
        {QualityFlag.raw_yaml_description.value, QualityFlag.missing_frontmatter.value}
    ),
}
_CONTROL_CHARACTERS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


class FieldState(str, Enum):
    """Whether a lexical field can feed the baseline as published."""

    present = "present"
    missing = "missing"
    malformed = "malformed"


class FieldObservation(BaseModel):
    """The state of one lexical field of one record.

    ``precedence`` repeats the build policy's authority order for the field, when it has one.
    A canonical record does not say which authority supplied a field, so the manifest records
    the order and the entry's evidence instead of guessing.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str = Field(min_length=1, max_length=64)
    state: FieldState
    reasons: tuple[str, ...] = ()
    text_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    precedence: tuple[str, ...] = ()

    @model_validator(mode="after")
    def _digest_follows_state(self) -> FieldObservation:
        """A missing field has no text to digest; any other field has one.

        :return: The observation.
        :raises ValueError: When digest and state disagree.
        """
        if (self.state is FieldState.missing) != (self.text_digest is None):
            raise ValueError("a missing field has no text digest and every other field has one")
        return self


class EntryProvenance(BaseModel):
    """One piece of source evidence behind a record."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    authority: str = Field(min_length=1, max_length=64)
    collection: str = Field(min_length=1, max_length=64)
    source_configuration_version: str = Field(min_length=1, max_length=64)
    resolved_revision: str = Field(min_length=1, max_length=128)
    record_occurrence_id: str = Field(pattern=r"^[0-9a-f]{64}$")


class CorpusEntry(BaseModel):
    """One published record of the corpus type."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    component_id: str = Field(min_length=1, max_length=64)
    observations: tuple[FieldObservation, ...]
    quality_flags: tuple[str, ...] = ()
    graph_status: str
    recommendation_eligibility: str
    execution_permission: str
    baseline_input: bool
    exclusion_reason: str | None = None
    provenance: tuple[EntryProvenance, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def _exclusion_is_explained(self) -> CorpusEntry:
        """An excluded record says why; baseline input carries no exclusion reason.

        :return: The entry.
        :raises ValueError: When the two disagree.
        """
        if self.baseline_input == (self.exclusion_reason is not None):
            raise ValueError("an excluded record needs a reason and baseline input has none")
        return self

    def field_state(self, name: str) -> FieldState:
        """Return the state of one lexical field.

        :param name: A lexical field name.
        :return: That field's state.
        :raises CasePackError: When the manifest does not observe the field.
        """
        for observation in self.observations:
            if observation.name == name:
                return observation.state
        raise CasePackError(f"field {name} is not observed in this corpus")


class CorpusManifest(BaseModel):
    """Every published record of one type in one pinned catalogue."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    component_type: ComponentType
    lineage: CasePackLineage
    lexical_fields: tuple[str, ...] = LEXICAL_FIELDS
    not_published_fields: tuple[str, ...] = NOT_PUBLISHED_FIELDS
    entries: tuple[CorpusEntry, ...] = ()

    @model_validator(mode="after")
    def _entries_canonical(self) -> CorpusManifest:
        """Entries are unique and sorted by component id.

        :return: The manifest.
        :raises ValueError: When an entry repeats or the order is not canonical.
        """
        ids = [entry.component_id for entry in self.entries]
        if ids != sorted(set(ids)):
            raise ValueError("corpus entries must be unique and sorted by component id")
        return self

    def component_ids(self) -> frozenset[str]:
        """:return: Every published component id of the corpus type."""
        return frozenset(entry.component_id for entry in self.entries)

    def entry(self, component_id: str) -> CorpusEntry | None:
        """Look up one entry.

        :param component_id: A component id.
        :return: Its entry, or ``None`` when the corpus does not hold it.
        """
        for entry in self.entries:
            if entry.component_id == component_id:
                return entry
        return None

    def digest(self) -> str:
        """:return: The digest a case pack pins its corpus with."""
        return canonical_digest(self.model_dump(mode="json"))


def _assess(name: str, text: str, flags: frozenset[str]) -> tuple[FieldState, tuple[str, ...]]:
    """Decide the state of one lexical field.

    :param name: The field name.
    :param text: The field text as published.
    :param flags: The record's quality flag values.
    :return: The state and the reasons behind it.
    """
    missing = flags & _MISSING_FLAGS[name]
    malformed = flags & _MALFORMED_FLAGS[name]
    if not text.strip() or missing:
        return FieldState.missing, tuple(sorted(missing)) or ("empty",)
    if malformed:
        return FieldState.malformed, tuple(sorted(malformed))
    if _CONTROL_CHARACTERS.search(text):
        return FieldState.malformed, ("control_characters",)
    return FieldState.present, ()


def _observe(
    name: str, text: str, flags: frozenset[str], precedence: Mapping[str, Sequence[str]]
) -> FieldObservation:
    """Observe one lexical field without keeping its text.

    :param name: The field name.
    :param text: The field text as published.
    :param flags: The record's quality flag values.
    :param precedence: The build policy's authority order per field.
    :return: The observation.
    """
    state, reasons = _assess(name, text, flags)
    digest = None
    if state is not FieldState.missing:
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return FieldObservation(
        name=name,
        state=state,
        reasons=reasons,
        text_digest=digest,
        precedence=tuple(enum_value(item) for item in precedence.get(name, ())),
    )


def _provenance(record: CanonicalRecord, lineage: CasePackLineage) -> tuple[EntryProvenance, ...]:
    """Read a record's evidence and check it against the pinned source revisions.

    :param record: The canonical record.
    :param lineage: The pin.
    :return: The provenance, sorted.
    :raises CasePackError: When evidence names a revision the lineage does not pin.
    """
    pinned = lineage.pin_keys()
    items = []
    for evidence in record.source_evidence:
        if evidence_pin(evidence).key() not in pinned:
            raise CasePackError("record evidence names a source revision outside the lineage")
        items.append(
            EntryProvenance(
                authority=enum_value(evidence.authority),
                collection=enum_value(evidence.locator.collection),
                source_configuration_version=evidence.source_configuration_version,
                resolved_revision=evidence.resolved_revision,
                record_occurrence_id=evidence.record_occurrence_id,
            )
        )
    return tuple(sorted(items, key=lambda item: (item.authority, item.record_occurrence_id)))


def _exclusion(states: Any) -> str | None:
    """Decide whether a record is baseline input.

    Only graph-valid, recommendation-eligible records are baseline input. Execution permission
    is recorded but never filters: suggesting a component is not running it.

    :param states: The record's ``ComponentStates``.
    :return: ``None`` for baseline input, else the reason it is excluded.
    """
    graph = enum_value(states.graph_status)
    if graph != GraphStatus.graph_valid.value:
        return f"graph_status:{graph}"
    eligibility = enum_value(states.recommendation_eligibility)
    if eligibility != RecommendationEligibility.recommendation_eligible.value:
        return f"eligibility:{eligibility}"
    return None


def build_corpus_manifest(
    records: Iterable[CanonicalRecord],
    *,
    component_type: ComponentType,
    lineage: CasePackLineage,
    field_precedence: Mapping[str, Sequence[str]] | None = None,
) -> CorpusManifest:
    """Build the corpus manifest of one component type from one pinned catalogue.

    Records of other types are skipped. Field text is digested, never copied.

    :param records: The canonical records of the pinned catalogue.
    :param component_type: The type the corpus covers.
    :param lineage: The pin every record must match.
    :param field_precedence: The build policy's authority order per field, when known.
    :return: The manifest.
    :raises CasePackError: When a record belongs to another catalogue, a component appears
        twice, or evidence falls outside the lineage.
    """
    precedence = field_precedence or {}
    entries: dict[str, CorpusEntry] = {}
    for record in records:
        if enum_value(record.identity.component_type) != enum_value(component_type):
            continue
        if record.catalogue_id != lineage.catalogue_id:
            raise CasePackError("a record belongs to another catalogue than the lineage")
        component_id = str(record.identity.component_uuid)
        if component_id in entries:
            raise CasePackError(f"component {component_id} is published twice")
        flags = frozenset(enum_value(flag) for flag in record.quality_flags)
        exclusion = _exclusion(record.states)
        entries[component_id] = CorpusEntry(
            component_id=component_id,
            observations=(
                _observe("name", record.name, flags, precedence),
                _observe("description", record.description, flags, precedence),
            ),
            quality_flags=tuple(sorted(flags)),
            graph_status=enum_value(record.states.graph_status),
            recommendation_eligibility=enum_value(record.states.recommendation_eligibility),
            execution_permission=enum_value(record.states.execution_permission),
            baseline_input=exclusion is None,
            exclusion_reason=exclusion,
            provenance=_provenance(record, lineage),
        )
    return CorpusManifest(
        component_type=component_type,
        lineage=lineage,
        entries=tuple(entries[key] for key in sorted(entries)),
    )


class FieldAvailability(BaseModel):
    """How one lexical field is available across the baseline input."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    present: int = Field(ge=0)
    missing: int = Field(ge=0)
    malformed: int = Field(ge=0)
    reasons: dict[str, int] = Field(default_factory=dict)
    missing_ids: tuple[str, ...] = ()
    malformed_ids: tuple[str, ...] = ()


class FieldAvailabilityReport(BaseModel):
    """The field-availability report of one corpus manifest."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    component_type: ComponentType
    lineage_digest: str
    corpus_digest: str
    published: int = Field(ge=0)
    baseline_input: int = Field(ge=0)
    excluded: dict[str, int] = Field(default_factory=dict)
    availability: tuple[FieldAvailability, ...] = ()
    not_published_fields: tuple[str, ...] = ()
    access_filtering: str


def field_availability(manifest: CorpusManifest) -> FieldAvailabilityReport:
    """Count field states over the baseline input of a corpus manifest.

    :param manifest: The manifest.
    :return: The report. Excluded records are counted by reason, not by field.
    """
    baseline = [entry for entry in manifest.entries if entry.baseline_input]
    excluded: dict[str, int] = {}
    for entry in manifest.entries:
        if entry.exclusion_reason is not None:
            excluded[entry.exclusion_reason] = excluded.get(entry.exclusion_reason, 0) + 1
    availability = []
    for name in manifest.lexical_fields:
        counts = {state: 0 for state in FieldState}
        reasons: dict[str, int] = {}
        ids: dict[FieldState, list[str]] = {FieldState.missing: [], FieldState.malformed: []}
        for entry in baseline:
            observation = next(item for item in entry.observations if item.name == name)
            counts[observation.state] += 1
            for reason in observation.reasons:
                reasons[reason] = reasons.get(reason, 0) + 1
            if observation.state in ids:
                ids[observation.state].append(entry.component_id)
        availability.append(
            FieldAvailability(
                name=name,
                present=counts[FieldState.present],
                missing=counts[FieldState.missing],
                malformed=counts[FieldState.malformed],
                reasons=dict(sorted(reasons.items())),
                missing_ids=tuple(ids[FieldState.missing]),
                malformed_ids=tuple(ids[FieldState.malformed]),
            )
        )
    access = manifest.lineage.access_policy_revision
    return FieldAvailabilityReport(
        component_type=manifest.component_type,
        lineage_digest=manifest.lineage.digest(),
        corpus_digest=manifest.digest(),
        published=len(manifest.entries),
        baseline_input=len(baseline),
        excluded=dict(sorted(excluded.items())),
        availability=tuple(availability),
        not_published_fields=manifest.not_published_fields,
        access_filtering="not_applied" if access is None else f"read_policy:{access}",
    )


def render_field_availability(report: FieldAvailabilityReport) -> str:
    """Render the report as Markdown, without any field text.

    :param report: The report.
    :return: The Markdown.
    """
    lines = [
        f"# Field availability: {enum_value(report.component_type)}",
        "",
        f"- Lineage: `{report.lineage_digest}`",
        f"- Corpus: `{report.corpus_digest}`",
        f"- Published records: {report.published}; baseline input: {report.baseline_input}",
        f"- Access filtering: {report.access_filtering}",
        "",
        "| Field | Present | Missing | Malformed | Reasons |",
        "|---|---|---|---|---|",
    ]
    for item in report.availability:
        reasons = ", ".join(f"{key} {value}" for key, value in item.reasons.items()) or "-"
        lines.append(
            f"| {item.name} | {item.present} | {item.missing} | {item.malformed} | {reasons} |"
        )
    lines.append("")
    if report.excluded:
        lines.append("Excluded from baseline input:")
        lines.extend(f"- {reason}: {count}" for reason, count in report.excluded.items())
        lines.append("")
    if report.not_published_fields:
        names = ", ".join(report.not_published_fields)
        lines.append(f"Not carried by the canonical publication: {names}.")
    return "\n".join(lines) + "\n"
