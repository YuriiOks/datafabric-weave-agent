# Change package, 22 Oct 2026

Built on the Mac from the 20 Oct copy of `main`. There is no base sha: the package checks its anchors against your checkout. If `main` moved under one of them, the script refuses and writes nothing; send the refusal lines and the package is rebuilt.

None of the files in this folder are committed.

## Contents

| PR | Package | Branch | Cut from | PR base |
|---|---|---|---|---|
| G | `prod-ready` | `fix/no-sample-data-without-demo-mode` | `origin/main` | `main` |

## Steps

```bash
sha256sum -c SHA256SUMS
python3 install.py --inspect
git -C <main checkout> fetch origin
git -C <main checkout> worktree add -b fix/no-sample-data-without-demo-mode <path> origin/main
python3 install.py prod-ready <path> --check
python3 install.py prod-ready <path>
git -C <path> add -A && git -C <path> commit -m "Show sample components only in demo mode"
```

Every script checks the branch, a clean worktree and every anchor before it writes. A second run reports `ALREADY APPLIED`. Nothing is staged, committed, pushed or tested by the scripts.

## Pull request

| PR | Title | Body |
|---|---|---|
| G | `Show sample components only in demo mode` | `bodies/no-sample-data.md` |

## Tests to expect in CI

| PR | Test files |
|---|---|
| G | frontend `client.test.ts`, `CatalogueSourceBar.test.tsx` (new), and the existing `RegistryPage.test.tsx`, `RecommendPage.test.tsx`, `ComponentDetailPage.test.tsx`, `SuggestedComponentsPanel.test.tsx`, `SearchComponentsPanel.test.tsx` |
