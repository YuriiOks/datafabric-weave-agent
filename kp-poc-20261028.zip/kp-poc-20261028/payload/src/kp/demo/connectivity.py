"""The connectivity job against the local stand-ins, with its X-01..X-11 table.

It runs on a database and a data folder of its own: the job writes item and call rows for its
nine sample items, and those must not meet the swept items of the build.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import SecretStr

from kp.clock import Clock
from kp.config import Settings
from kp.connectivity import build_harness
from kp.connectivity.report import build_report
from kp.demo.model import ConnectivityTable, CriterionRow
from kp.domain import RunOutcome
from kp.errors import KpError

DATABASE_FILE = "connectivity.db"
DATA_FOLDER = "connectivity"


def run_connectivity(settings: Settings, clock: Clock, work: Path) -> ConnectivityTable:
    """Discover, run twice and score the exit criteria against the local stand-ins.

    The second run changes nothing (criterion X-09 needs it), and the error probe provokes a
    bad credential and a bad parameter (X-10).

    :param settings: The demo settings; the database and data folder are replaced
    :param clock: Time source
    :param work: The working folder; the job's files go below it
    :return: The criteria table, or the reason the job could not run
    """
    isolated = settings.model_copy(
        update={
            "database_url": SecretStr(f"sqlite+pysqlite:///{work / DATABASE_FILE}"),
            "data_dir": work / DATA_FOLDER,
        }
    )
    try:
        harness = build_harness(isolated, clock=clock)
    except KpError as exc:
        return ConnectivityTable(verdict="not run", rows=(), error=str(exc))
    try:
        harness.job.discover()
        first = harness.job.run()
        harness.job.run()
        harness.job.probe_errors()
        report = build_report(harness.evidence())
    except KpError as exc:
        return ConnectivityTable(verdict="failed", rows=(), error=str(exc))
    finally:
        harness.close()
    rows = tuple(
        CriterionRow(item.id, item.title, item.result.value, item.detail)
        for item in report.criteria
    )
    verdict = report.verdict
    if first.outcome is not RunOutcome.SUCCEEDED:
        verdict = f"first run {first.outcome.value}. {verdict}"
    return ConnectivityTable(verdict=verdict, rows=rows)
