"""Regenerate the committed fixtures: ``python -m kp.testing.regenerate [directory] [seed]``."""

from __future__ import annotations

import sys
from pathlib import Path

from kp.testing.synthetic import DEFAULT_SEED, generate

DEFAULT_TARGET = Path("fixtures/generated")


def main(argv: list[str] | None = None) -> int:
    """Regenerate the dataset.

    :param argv: Optional ``[directory, seed]``; defaults to ``fixtures/generated`` and the
        default seed
    :return: Process exit status
    """
    args = sys.argv[1:] if argv is None else argv
    target = Path(args[0]) if args else DEFAULT_TARGET
    seed = int(args[1]) if len(args) > 1 else DEFAULT_SEED
    dataset = generate(target, seed)
    sys.stdout.write(f"Wrote synthetic dataset to {dataset.root} (seed {seed})\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
