"""Apply the FND-14 change package to a clean worktree. Harness file: never committed.

Usage: python3 apply_fnd14.py <worktree-root> [--check]

Copies every file under ./pkg into the worktree (refusing to overwrite anything), then
applies anchored edits to existing files. Every anchor must occur exactly once. All
anchors are checked before anything is written; one miss writes nothing.

The package touches no file the AGT-02 package touches, so it applies on main or on
top of the AGT-02 branch. The branch must be named feat/fnd-14-* or be the AGT-02
branch (one combined PR).
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / "pkg"
BRANCH_PREFIXES = ("feat/fnd-14", "feat/agt-02-relations")

EDITS: list[tuple[str, str, str]] = []


def edit(path: str, old: str, new: str) -> None:
    EDITS.append((path, old, new))


# --------------------------------------------------------------------- recsys/config.py
C = "backend/app/recsys/config.py"
edit(
    C,
    """    recsys_refresh_partition: str = Field(
        default="shared",
        min_length=1,
        max_length=64,
        alias="RECSYS_REFRESH_PARTITION",
    )
""",
    """    recsys_refresh_partition: str = Field(
        default="shared",
        min_length=1,
        max_length=64,
        alias="RECSYS_REFRESH_PARTITION",
    )
    # Pre-production only: compose the refresh runtime over the registered sources,
    # with an explicit operator allow-list standing in for the operator authority
    # service. Refused at startup when the refresh environment is prod.
    recsys_refresh_preproduction_authority_enabled: bool = Field(
        default=False, alias="RECSYS_REFRESH_PREPRODUCTION_AUTHORITY_ENABLED"
    )
    # Comma-separated principal ids allowed to submit, inspect, cancel and retry.
    recsys_refresh_preproduction_operators: str = Field(
        default="", max_length=4096, alias="RECSYS_REFRESH_PREPRODUCTION_OPERATORS"
    )
    # Workspace that holds the registered workbook export.
    recsys_refresh_workspace_root: str = Field(
        default="", alias="RECSYS_REFRESH_WORKSPACE_ROOT"
    )
""",
)

# ------------------------------------------------------------ recsys/refresh/runtime.py
R = "backend/app/recsys/refresh/runtime.py"
edit(
    R,
    """from dataclasses import dataclass

from fastapi import HTTPException
""",
    """import asyncio
import logging
from collections.abc import Callable
from dataclasses import dataclass

from fastapi import HTTPException
""",
)
edit(
    R,
    """    service: RefreshService
    worker: RefreshWorker | None = None


_runtime: RefreshRuntime | None = None
""",
    """    service: RefreshService
    worker: RefreshWorker | None = None
    worker_task: asyncio.Task[None] | None = None
    on_close: Callable[[], None] | None = None


_runtime: RefreshRuntime | None = None
logger = logging.getLogger(__name__)
""",
)
edit(
    R,
    """    \"\"\"Initialize schema and validate explicit runtime composition when enabled.\"\"\"
    if not settings.recsys_refresh_enabled:
        return
    if _runtime is None:
        raise RuntimeError("refresh enabled without configured authority and ports")
    policy = refresh_admission_policy_from_settings(settings)
    await ensure_schema(resolve_pool(), refresh_policy=policy)
""",
    """    \"\"\"Initialize schema and validate explicit runtime composition when enabled.

    Without an explicitly configured runtime, the pre-production composition over the
    registered sources is used when its flag is set; it refuses production before
    anything is touched. The worker loop starts only when the worker flag is set.
    \"\"\"
    if not settings.recsys_refresh_enabled:
        return
    if _runtime is None and settings.recsys_refresh_preproduction_authority_enabled:
        from .integration.composition import compose_preproduction_runtime

        configure_refresh_runtime(compose_preproduction_runtime(settings, resolve_pool))
    if _runtime is None:
        raise RuntimeError("refresh enabled without configured authority and ports")
    policy = refresh_admission_policy_from_settings(settings)
    await ensure_schema(resolve_pool(), refresh_policy=policy)
    if settings.recsys_refresh_worker_enabled:
        _start_worker(_runtime)
""",
)
edit(
    R,
    """async def close_refresh_runtime() -> None:
    \"\"\"Stop the configured worker without swallowing shutdown failures.\"\"\"
    if _runtime is not None and _runtime.worker is not None:
        await _runtime.worker.stop()
""",
    """async def close_refresh_runtime() -> None:
    \"\"\"Stop the configured worker without swallowing shutdown failures.\"\"\"
    runtime = _runtime
    if runtime is None:
        return
    try:
        if runtime.worker is not None:
            await runtime.worker.stop()
        if runtime.worker_task is not None:
            await runtime.worker_task
    finally:
        runtime.worker_task = None
        if runtime.on_close is not None:
            runtime.on_close()


def _start_worker(runtime: RefreshRuntime) -> None:
    if runtime.worker is None or runtime.worker_task is not None:
        return
    task = asyncio.create_task(runtime.worker.run_forever(), name="recsys-refresh-worker")
    task.add_done_callback(_report_worker_exit)
    runtime.worker_task = task


def _report_worker_exit(task: asyncio.Task[None]) -> None:
    # A crashed loop leaves the worker's heartbeat to lapse, so submissions start
    # refusing; this makes the cause visible instead of waiting for shutdown.
    if task.cancelled():
        return
    error = task.exception()
    if error is not None:
        logger.error(
            "Refresh worker stopped unexpectedly",
            exc_info=(type(error), error, error.__traceback__),
        )
""",
)


def _diagnose(text: str, old: str) -> list[str]:
    """Show where an anchor nearly matched, so one screen fixes it.

    :param text: The file as it stands.
    :param old: The anchor that was not found exactly once.
    :return: Indented report lines.
    """
    report: list[str] = []
    anchor_lines = old.splitlines()
    first = next((line for line in anchor_lines if line.strip()), "")
    report.append(f"    expected first line: {first!r}")
    lines = text.splitlines()
    hits = [number for number, line in enumerate(lines) if first.strip() in line]
    if not hits:
        report.append("    first line not found anywhere")
    for number in hits[:4]:
        report.append(f"    L{number + 1}: {lines[number]!r}")
        offset = anchor_lines.index(first)
        for step, expected in enumerate(anchor_lines[offset:], start=0):
            actual = lines[number + step] if number + step < len(lines) else "<eof>"
            if actual != expected:
                column = next(
                    (i for i, (a, b) in enumerate(zip(actual, expected)) if a != b),
                    min(len(actual), len(expected)),
                )
                report.append(
                    f"      first difference at L{number + step + 1} col {column + 1}: "
                    f"file {actual[column:column + 24]!r} vs anchor "
                    f"{expected[column:column + 24]!r}"
                )
                break
        else:
            report.append("      every anchor line matches here (count problem only)")
    return report


def _git(root: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 2
    root = Path(argv[0]).resolve()
    check_only = "--check" in argv[1:]
    problems: list[str] = []

    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if not branch.startswith(BRANCH_PREFIXES):
        problems.append(f"branch is {branch}, expected one of {BRANCH_PREFIXES}")
    if _git(root, "status", "--porcelain"):
        problems.append("worktree is not clean")

    new_files: list[tuple[Path, bytes]] = []
    for source in sorted(PKG.rglob("*")):
        if source.is_dir() or "__pycache__" in source.parts:
            continue
        target = root / source.relative_to(PKG)
        if target.exists():
            problems.append(f"new file already exists: {source.relative_to(PKG)}")
        new_files.append((target, source.read_bytes()))

    texts: dict[str, str] = {}
    for rel, old, new in EDITS:
        if rel not in texts:
            path = root / rel
            if not path.is_file():
                problems.append(f"missing file: {rel}")
                texts[rel] = ""
                continue
            texts[rel] = path.read_text(encoding="utf-8")
        count = texts[rel].count(old)
        if count != 1:
            problems.append(f"{rel}: anchor found {count}x")
            problems.extend(_diagnose(texts[rel], old))
            continue
        texts[rel] = texts[rel].replace(old, new, 1)

    for rel, text in texts.items():
        if rel.endswith(".py") and text:
            try:
                compile(text, rel, "exec")
            except SyntaxError as error:
                problems.append(f"{rel}: edited text does not compile: {error}")
    for target, data in new_files:
        if target.suffix == ".py":
            try:
                compile(data.decode("utf-8"), str(target), "exec")
            except SyntaxError as error:
                problems.append(f"{target.name}: does not compile: {error}")

    if problems:
        print("NOTHING WRITTEN. Problems:")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print(f"OK: {len(new_files)} new files, {len(EDITS)} edits in {len(texts)} files")
    if check_only:
        return 0
    for target, data in new_files:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    for rel, text in texts.items():
        (root / rel).write_text(text, encoding="utf-8")
    print("written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
