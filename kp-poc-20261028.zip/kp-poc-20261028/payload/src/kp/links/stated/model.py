"""What a stated-link loader returns: links to assert, and what it could not express."""

from __future__ import annotations

from collections.abc import Iterable

from kp.domain import DomainModel, ItemRef, Relation
from kp.links.candidate import LinkCandidate, conformance_violation


class RejectedLink(DomainModel):
    """A reference found in a source that does not become a link, with the reason.

    Nothing is dropped silently: each one is counted and can be shown to a person.
    """

    origin: str
    reason: str


class StatedLinkSet(DomainModel):
    """The links one source states, plus the scope the loader fully enumerated.

    ``owned_sources`` and ``owned_targets`` name the items whose stated links of the given
    ``relations`` were all listed. ``owned_paths`` names repository files that were read in
    full: every stated link of those relations that starts or ends at a code, test or schema
    field in one of them is owned, whatever revision qualifies its key. A stated link in the
    store for an owned item that is no longer listed has been removed at the source, so
    applying the set closes it. A file deleted from the repository is not named by any scan;
    retire its items with ``LinkService.retire_item``.
    """

    links: tuple[LinkCandidate, ...] = ()
    rejected: tuple[RejectedLink, ...] = ()
    owned_sources: frozenset[ItemRef] = frozenset()
    owned_targets: frozenset[ItemRef] = frozenset()
    owned_paths: frozenset[str] = frozenset()
    relations: frozenset[Relation] = frozenset()


def keep_conforming(
    candidates: Iterable[tuple[str, LinkCandidate]],
) -> tuple[tuple[LinkCandidate, ...], tuple[RejectedLink, ...]]:
    """Split candidates into those that conform to the model and those that do not.

    The same fact stated twice is kept once.

    :param candidates: ``(origin, candidate)`` pairs; ``origin`` says where it was found
    :return: The conforming candidates and a rejection for each violation
    """
    kept: dict[tuple[ItemRef, Relation, ItemRef], LinkCandidate] = {}
    rejected: list[RejectedLink] = []
    for origin, candidate in candidates:
        violation = conformance_violation(candidate)
        if violation is not None:
            rejected.append(RejectedLink(origin=origin, reason=violation))
        else:
            kept.setdefault(candidate.fact, candidate)
    return tuple(kept.values()), tuple(rejected)
