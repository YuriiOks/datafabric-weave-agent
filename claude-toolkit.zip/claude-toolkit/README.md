# Toolkit additions for bp-card-matured — transfer package

Drafted 2026-08-05 against `architecture-improvement-review.md` v3.1. Copy into the repo on the work machine:

| File here | Target path |
|---|---|
| `agents/eval-gatekeeper.md` | `.claude/agents/eval-gatekeeper.md` |
| `commands/close-verify.md` | `.claude/commands/close-verify.md` |
| `rules/llm-boundaries.md` | `.claude/rules/llm-boundaries.md` |

Then add two rows to the CLAUDE.md *Highest-value invocations* table:

| `eval-gatekeeper` agent | Before any ship-readiness claim on `backend/app/(search,ingestion,gateway)` changes — blocks unmeasured quality claims (EVAL-001 gate). |
| `/close-verify <doc>` | Closes **VERIFY** markers in a review/spec against the source with file:line evidence. |

`rules/llm-boundaries.md` is always-on once placed under `.claude/rules/`.

Notes:
- The section references (§5, §6.4–6.6, §12) point at `architecture-improvement-review.md` v3.1 — keep a copy of that document in the repo `docs/` so the references resolve.
- If the eval harness lands somewhere other than `evals/`, update Step 1 of `eval-gatekeeper.md`.
