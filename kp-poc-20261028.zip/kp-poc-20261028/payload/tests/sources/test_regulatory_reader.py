"""Regulatory repository reader: US-02 (editions by reviewed pull request)."""

from __future__ import annotations

import shutil
from datetime import date
from pathlib import Path

import pytest
import yaml

from kp.domain.enums import SourceKind
from kp.errors import SourceItemNotFoundError
from kp.sources import MalformedSourceDataError, RegulatoryRepoReader
from kp.sources import attributes as attr
from kp.testing.dataset import SyntheticDataset

from .support import drain, ids, key

REGULATORY = SourceKind.REGULATORY_REPO
DOCUMENT = "payments-rulebook"


def _repo(data_root: Path) -> Path:
    return data_root / "regulatory_repo"


def _write_manifest(directory: Path, **fields: object) -> None:
    """Write a manifest saying ``merged: true`` unless told otherwise; ``merged=None`` omits it."""
    values = {key: value for key, value in {"merged": True, **fields}.items() if value is not None}
    (directory / "edition.yaml").write_text(yaml.safe_dump(values), encoding="utf-8")


def _add_unmerged_edition(data_root: Path, *, merged: bool) -> Path:
    """Copy 2026.1 as a new edition 2026.2, as a pull request branch would add it."""
    new = _repo(data_root) / "2026.2"
    shutil.copytree(_repo(data_root) / "2026.1", new)
    _write_manifest(new, edition="2026.2", effective_date="2027-03-01", merged=merged)
    return new


def test_us02_editions_with_effective_dates_are_listed(data_root: Path) -> None:
    reader = RegulatoryRepoReader(_repo(data_root))

    items, _ = drain(reader)

    assert ids(items) == {(DOCUMENT, "2025.2"), (DOCUMENT, "2026.1")}
    new = reader.fetch(key(REGULATORY, DOCUMENT, "2026.1")).metadata.attributes
    assert new[attr.EDITION_LABEL] == "2026.1"
    assert new[attr.EFFECTIVE_DATE] == "2026-11-16"
    assert new[attr.MERGED] is True


def test_us02_the_older_edition_stays_available_for_earlier_dates(
    data_root: Path, dataset: SyntheticDataset
) -> None:
    reader = RegulatoryRepoReader(_repo(data_root))

    older = reader.fetch(key(REGULATORY, DOCUMENT, "2025.2"))
    truth = dataset.truth.edition("2025.2")

    assert older.content == (dataset.root / truth.markdown_path).read_bytes()
    assert older.metadata.attributes[attr.EFFECTIVE_DATE] == truth.effective_date.isoformat()


def test_us02_new_edition_once_merged_is_loaded_on_the_next_sweep_and_the_old_one_is_not_touched(
    data_root: Path,
) -> None:
    reader = RegulatoryRepoReader(_repo(data_root))
    held_back = _repo(data_root).parent / "held-back"
    shutil.move(_repo(data_root) / "2026.1", held_back)
    first, cursor = drain(reader)

    shutil.move(held_back, _repo(data_root) / "2026.1")
    second, _ = drain(reader, cursor)

    assert ids(first) == {(DOCUMENT, "2025.2")}
    assert [(i.key.version, i.deleted) for i in second] == [("2026.1", False)]


def test_us02_pull_request_not_merged_means_nothing_is_listed_or_fetchable(
    data_root: Path,
) -> None:
    _add_unmerged_edition(data_root, merged=False)
    reader = RegulatoryRepoReader(_repo(data_root))

    items, _ = drain(reader)

    assert {item.key.version for item in items} == {"2025.2", "2026.1"}
    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(key(REGULATORY, DOCUMENT, "2026.2"))


def test_us02_edition_becomes_listed_when_its_pull_request_is_merged(data_root: Path) -> None:
    new = _add_unmerged_edition(data_root, merged=False)
    reader = RegulatoryRepoReader(_repo(data_root))
    _, cursor = drain(reader)

    _write_manifest(new, edition="2026.2", effective_date="2027-03-01", merged=True)
    items, _ = drain(reader, cursor)

    assert ids(items) == {(DOCUMENT, "2026.2")}
    assert reader.fetch(items[0].key).metadata.attributes[attr.EFFECTIVE_DATE] == "2027-03-01"


def test_us02_generated_manifests_say_they_are_merged_and_name_a_domain(data_root: Path) -> None:
    manifest = yaml.safe_load((_repo(data_root) / "2026.1" / "edition.yaml").read_text())

    assert manifest["merged"] is True
    reader = RegulatoryRepoReader(_repo(data_root))
    attributes = reader.fetch(key(REGULATORY, DOCUMENT, "2026.1")).metadata.attributes
    assert attributes[attr.DOMAIN] == "payments"


def test_us02_manifest_without_merged_flag_is_not_listed_or_fetchable(data_root: Path) -> None:
    _write_manifest(
        _repo(data_root) / "2026.1", edition="2026.1", effective_date="2026-11-16", merged=None
    )
    reader = RegulatoryRepoReader(_repo(data_root))

    items, _ = drain(reader)

    assert ids(items) == {(DOCUMENT, "2025.2")}
    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(key(REGULATORY, DOCUMENT, "2026.1"))


def test_us02_manifest_dates_for_supersession_are_reported(data_root: Path) -> None:
    _write_manifest(
        _repo(data_root) / "2025.2",
        edition="2025.2",
        effective_date="2025-06-02",
        superseded_from="2026-11-16",
    )

    attributes = (
        RegulatoryRepoReader(_repo(data_root))
        .fetch(key(REGULATORY, DOCUMENT, "2025.2"))
        .metadata.attributes
    )

    assert attributes[attr.SUPERSEDED_FROM] == date(2026, 11, 16).isoformat()
    assert attributes[attr.WITHDRAWN_FROM] is None


def test_us02_markdown_is_the_content_and_other_formats_are_named(data_root: Path) -> None:
    fetched = RegulatoryRepoReader(_repo(data_root)).fetch(key(REGULATORY, DOCUMENT, "2026.1"))

    assert fetched.metadata.media_type == "text/markdown"
    assert fetched.metadata.attributes[attr.FORMATS] == [".md", ".pdf"]
    assert fetched.content == (_repo(data_root) / "2026.1" / f"{DOCUMENT}.md").read_bytes()


def test_us02_pdf_only_edition_is_read_as_a_pdf(data_root: Path) -> None:
    (_repo(data_root) / "2026.1" / f"{DOCUMENT}.md").unlink()

    fetched = RegulatoryRepoReader(_repo(data_root)).fetch(key(REGULATORY, DOCUMENT, "2026.1"))

    assert fetched.metadata.media_type == "application/pdf"
    assert fetched.content.startswith(b"%PDF")


def test_us02_directory_without_a_manifest_is_not_listed(data_root: Path) -> None:
    (_repo(data_root) / "2025.2" / "edition.yaml").unlink()

    items, _ = drain(RegulatoryRepoReader(_repo(data_root)))

    assert ids(items) == {(DOCUMENT, "2026.1")}


def test_us02_manifest_label_must_match_its_directory(data_root: Path) -> None:
    _write_manifest(_repo(data_root) / "2026.1", edition="2026.9", effective_date="2026-11-16")

    with pytest.raises(MalformedSourceDataError):
        drain(RegulatoryRepoReader(_repo(data_root)))


def test_us02_unquoted_numeric_label_is_refused_because_it_would_lose_digits(
    data_root: Path,
) -> None:
    (_repo(data_root) / "2026.1" / "edition.yaml").write_text(
        "edition: 2026.1\neffective_date: 2026-11-16\n", encoding="utf-8"
    )

    with pytest.raises(MalformedSourceDataError):
        drain(RegulatoryRepoReader(_repo(data_root)))


def test_us02_manifest_without_an_effective_date_raises(data_root: Path) -> None:
    _write_manifest(_repo(data_root) / "2026.1", edition="2026.1", merged=True)

    with pytest.raises(MalformedSourceDataError):
        drain(RegulatoryRepoReader(_repo(data_root)))


def test_us04_withdrawn_from_date_is_reported_so_an_old_spec_citation_can_still_resolve(
    data_root: Path,
) -> None:
    _write_manifest(
        _repo(data_root) / "2025.2",
        edition="2025.2",
        effective_date="2025-06-02",
        withdrawn_from="2027-01-01",
    )

    fetched = RegulatoryRepoReader(_repo(data_root)).fetch(key(REGULATORY, DOCUMENT, "2025.2"))

    assert fetched.metadata.attributes[attr.WITHDRAWN_FROM] == "2027-01-01"
    assert fetched.metadata.attributes[attr.SUPERSEDED_FROM] is None
    assert fetched.content


def test_us02_edition_unmerged_after_the_listing_cannot_be_fetched(data_root: Path) -> None:
    reader = RegulatoryRepoReader(_repo(data_root))
    drain(reader)

    _write_manifest(
        _repo(data_root) / "2026.1", edition="2026.1", effective_date="2026-11-16", merged=False
    )

    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(key(REGULATORY, DOCUMENT, "2026.1"))
