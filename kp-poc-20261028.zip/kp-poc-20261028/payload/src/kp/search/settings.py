"""Search settings, read from ``KP_SEARCH_*`` environment variables.

They live here, not in :class:`kp.config.Settings`, so the search lane stays inside its own
package; the integrator may fold them into the main settings later.
"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from kp.domain import SourceKind
from kp.search.embedding import EMBEDDING_BATCH_SIZE
from kp.search.fusion import DEFAULT_AUTHORITY_WEIGHTS, RRF_CONSTANT, RRF_DEPTH


class SearchSettings(BaseSettings):
    """Tunables of search.

    :ivar vector_enabled: Whether the vector side takes part. Off by default: keyword search
        plus exact references is the whole of week 2 until an extension is approved.
    :ivar result_limit: How many hits a question returns.
    :ivar candidate_depth: How many results each ranked list contributes to fusion.
    :ivar rrf_constant: The reciprocal-rank-fusion smoothing constant.
    :ivar embedding_batch_size: Largest batch sent to the embedder.
    :ivar authority_weights: Multiplier per source applied after fusion.
    """

    model_config = SettingsConfigDict(env_prefix="KP_SEARCH_", extra="ignore", frozen=True)

    vector_enabled: bool = False
    result_limit: Annotated[int, Field(ge=1)] = 10
    candidate_depth: Annotated[int, Field(ge=1)] = RRF_DEPTH
    rrf_constant: Annotated[int, Field(ge=1)] = RRF_CONSTANT
    embedding_batch_size: Annotated[int, Field(ge=1)] = EMBEDDING_BATCH_SIZE
    authority_weights: dict[SourceKind, Annotated[float, Field(gt=0)]] = Field(
        default_factory=lambda: dict(DEFAULT_AUTHORITY_WEIGHTS)
    )
