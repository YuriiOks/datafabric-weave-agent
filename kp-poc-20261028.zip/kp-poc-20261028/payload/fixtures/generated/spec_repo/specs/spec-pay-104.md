---
story: PAY-104
spec: spec-pay-104
template: functional-spec@1.0.0
---
# Accept permitted currencies on inbound transfers

## Summary

An inbound credit transfer is accepted only in a currency the rulebook lists.

## Rules

- An inbound credit transfer may be denominated only in a listed currency [ref: 2026.1:4.2.1].
- The register row REQ-001 states the same requirement and is met by this rule.

## Acceptance

- A transfer in an unlisted currency is rejected.
