"""Per-attempt staging shared by the acquisition adapters and the catalogue port.

A source adapter acquires one registered source into a private directory and
registers the result under an opaque artifact reference. The catalogue port takes it
back by that reference, checks the digest the worker recorded in the capture, builds,
and discards the directory. Nothing here is durable: a restarted process starts a new
attempt and acquires again, so losing the registry loses nothing that matters.
"""

from __future__ import annotations

import logging
import shutil
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID

logger = logging.getLogger(__name__)

ARTIFACT_SCHEME = "staged-artifact"
STALE_AFTER_SECONDS = 3600.0


class StagedArtifactMissing(LookupError):
    """The reference names no artifact staged in this process."""


class StagedArtifactMismatch(ValueError):
    """The staged artifact's digest differs from the digest the capture recorded."""


@dataclass(frozen=True)
class StagedArtifact:
    """One acquired source, held until the catalogue port has built from it."""

    reference: str
    job_id: UUID
    attempt_id: UUID
    source_id: str
    acquired: object
    digest: str
    registered_at: float


class ArtifactStaging:
    """In-process registry of acquired artifacts, keyed by artifact reference."""

    def __init__(
        self,
        base_dir: Path,
        *,
        monotonic: Callable[[], float] = time.monotonic,
        stale_after_seconds: float = STALE_AFTER_SECONDS,
    ) -> None:
        """Create the registry over one private base directory.

        :param base_dir: Directory that holds one sub-directory per attempt.
        :param monotonic: Clock used to age entries; injectable for tests.
        :param stale_after_seconds: Age after which an unclaimed entry is dropped.
        """
        self._base = base_dir
        self._monotonic = monotonic
        self._stale_after = stale_after_seconds
        self._entries: dict[str, StagedArtifact] = {}
        self._lock = threading.Lock()

    @property
    def base_dir(self) -> Path:
        """Return the directory every attempt is staged under."""
        return self._base

    def root_for(self, attempt_id: UUID, source_id: str) -> Path:
        """Return a not-yet-existing directory for one acquisition.

        The acquisition service creates the directory itself and refuses one that
        exists, so a leftover from an interrupted run of the same attempt is removed.

        :param attempt_id: The lease attempt the acquisition belongs to.
        :param source_id: The registered source being acquired.
        :return: The staging root to hand to the acquisition service.
        """
        attempt_dir = self._base / str(attempt_id)
        attempt_dir.mkdir(parents=True, mode=0o700, exist_ok=True)
        root = attempt_dir / source_id
        if root.exists():
            shutil.rmtree(root)
        return root

    def register(
        self,
        *,
        job_id: UUID,
        attempt_id: UUID,
        source_id: str,
        acquired: object,
        digest: str,
    ) -> str:
        """Hold one acquired source and return the reference that names it.

        :param job_id: The refresh job the attempt belongs to.
        :param attempt_id: The lease attempt that acquired the source.
        :param source_id: The registered source, also the refresh adapter id.
        :param acquired: The acquisition result, kept as returned.
        :param digest: The artifact digest recorded in the capture.
        :return: The opaque artifact reference.
        """
        reference = f"{ARTIFACT_SCHEME}:{attempt_id}/{source_id}"
        entry = StagedArtifact(
            reference=reference,
            job_id=job_id,
            attempt_id=attempt_id,
            source_id=source_id,
            acquired=acquired,
            digest=digest,
            registered_at=self._monotonic(),
        )
        with self._lock:
            self._entries[reference] = entry
        return reference

    def get(self, reference: str, digest: str) -> StagedArtifact:
        """Return the staged artifact a capture names, after checking its digest.

        :param reference: The capture's artifact reference.
        :param digest: The capture's artifact digest.
        :return: The staged artifact.
        :raises StagedArtifactMissing: If nothing is staged under the reference.
        :raises StagedArtifactMismatch: If the staged digest differs.
        """
        with self._lock:
            entry = self._entries.get(reference)
        if entry is None:
            raise StagedArtifactMissing(reference)
        if entry.digest != digest:
            raise StagedArtifactMismatch(reference)
        return entry

    def discard(self, references: list[str]) -> None:
        """Drop the named artifacts and the attempt directories that held them.

        :param references: Artifact references to release.
        """
        with self._lock:
            removed = [self._entries.pop(ref) for ref in references if ref in self._entries]
        for attempt_id in {entry.attempt_id for entry in removed}:
            self._remove_attempt_dir_if_unused(attempt_id)

    def prune(self, *, job_id: UUID, attempt_id: UUID) -> None:
        """Drop artifacts no live attempt can still use.

        An earlier attempt of the same job lost its lease when this one started, and an
        entry older than the stale limit belongs to an attempt that never reached the
        build. Neither can be built from any more.

        :param job_id: The job of the attempt that is starting a capture.
        :param attempt_id: The attempt that is starting a capture.
        """
        now = self._monotonic()
        with self._lock:
            dead = [
                ref
                for ref, entry in self._entries.items()
                if entry.attempt_id != attempt_id
                and (entry.job_id == job_id or now - entry.registered_at > self._stale_after)
            ]
        if dead:
            logger.info("Discarding staged refresh artifacts", extra={"count": len(dead)})
            self.discard(dead)

    def clear(self) -> None:
        """Drop everything, including the base directory; used at shutdown."""
        with self._lock:
            self._entries.clear()
        shutil.rmtree(self._base, ignore_errors=True)

    def _remove_attempt_dir_if_unused(self, attempt_id: UUID) -> None:
        with self._lock:
            in_use = any(entry.attempt_id == attempt_id for entry in self._entries.values())
        if not in_use:
            shutil.rmtree(self._base / str(attempt_id), ignore_errors=True)
