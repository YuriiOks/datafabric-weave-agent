"""Mapping of typed tool failures to JSON-RPC errors."""

from __future__ import annotations

from kp.errors import (
    AccessForbiddenError,
    KpError,
    TemplateNotFoundError,
    WriteNotPermittedError,
)
from kp.mcp.jsonrpc import ErrorCode, JsonRpcError
from kp.tools import (
    AuditFailedError,
    InvalidToolArgumentsError,
    LinkStoreUnavailableError,
    NoEditionInForceError,
    RuleNotFoundError,
    UnknownToolError,
)

# (exception class, code, kind). The first match wins; messages of these classes are our own.
_KNOWN: tuple[tuple[type[KpError], ErrorCode, str], ...] = (
    (AccessForbiddenError, ErrorCode.FORBIDDEN, "forbidden"),
    (WriteNotPermittedError, ErrorCode.WRITE_NOT_PERMITTED, "write_not_permitted"),
    (UnknownToolError, ErrorCode.INVALID_PARAMS, "unknown_tool"),
    (InvalidToolArgumentsError, ErrorCode.INVALID_PARAMS, "invalid_arguments"),
    (TemplateNotFoundError, ErrorCode.NOT_FOUND, "template_not_found"),
    (NoEditionInForceError, ErrorCode.NOT_FOUND, "no_edition_in_force"),
    (RuleNotFoundError, ErrorCode.NOT_FOUND, "rule_not_found"),
    (LinkStoreUnavailableError, ErrorCode.UNAVAILABLE, "link_store_unavailable"),
    (AuditFailedError, ErrorCode.AUDIT_FAILED, "audit_failed"),
)


def to_jsonrpc_error(failure: KpError) -> JsonRpcError:
    """Translate a tool failure.

    Failures of an unknown class are reported with a fixed message: their text may come from a
    port and is not safe to show to an agent.

    :param failure: The typed failure raised by a tool call
    :return: The JSON-RPC error to send
    """
    for error_class, code, kind in _KNOWN:
        if isinstance(failure, error_class):
            return JsonRpcError(code, str(failure), kind)
    return JsonRpcError(ErrorCode.TOOL_FAILED, "The tool failed", "tool_failed")
