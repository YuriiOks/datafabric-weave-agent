"""The composition root: one application built from the settings."""

from __future__ import annotations

from pathlib import Path

import pytest

from kp.app import build_application, serve_wiring
from kp.errors import ConfigurationError
from kp.mcp import McpServer
from kp.store import Database
from kp.tools import build_caller
from world_support import World


def _tool_names(server: McpServer) -> list[str]:
    """List the tools the way an agent does, over JSON-RPC."""
    response = server.handle(
        {"jsonrpc": "2.0", "id": 1, "method": "tools/list"}, build_caller(user="user-full-access")
    )
    assert response is not None
    result = response["result"]
    assert isinstance(result, dict)
    tools = result["tools"]
    assert isinstance(tools, list)
    return [str(tool["name"]) for tool in tools if isinstance(tool, dict)]


def test_an_application_given_a_database_does_not_dispose_of_it(
    built_world: World, tmp_path: Path
) -> None:
    database = Database.from_settings(built_world.settings)
    application = build_application(built_world.settings, database=database)

    application.close()

    with database.transaction() as connection:
        assert connection is not None  # still usable: the caller owns the database
    database.dispose()


def test_the_read_server_serves_the_five_read_tools(built_world: World) -> None:
    server = built_world.application.read_server()
    names = [tool.name for tool in server._registry.definitions()]

    assert names == ["search", "links", "template", "rule_as_at", "coverage"]


def test_the_write_server_serves_exactly_the_two_write_tools(built_world: World) -> None:
    server = built_world.application.write_server()
    names = [tool.name for tool in server._registry.definitions()]

    assert names == ["publish_spec", "update_jira"]


def test_agent_servers_need_an_identity_mapping(built_world: World) -> None:
    without = build_application(
        built_world.settings.model_copy(update={"identity_mapping_file": None}),
        database=built_world.application.database,
    )

    with pytest.raises(ConfigurationError, match="KP_IDENTITY_MAPPING_FILE"):
        without.read_server()


def test_the_serve_wiring_builds_each_port_from_settings_and_a_database(built_world: World) -> None:
    wiring = serve_wiring()
    database = built_world.application.database

    assert wiring.read_ports is not None
    assert wiring.write_port is not None
    assert wiring.read_observer is not None
    assert wiring.read_ports(built_world.settings, database).search is not None
    assert wiring.write_port(built_world.settings, database).describe()
    assert callable(wiring.read_observer(built_world.settings, database))


def test_templates_are_loaded_from_a_folder_and_reloading_adds_nothing(
    built_world: World,
) -> None:
    loaded = built_world.application.load_templates(built_world.staged.templates)

    assert loaded == 1
    assert built_world.build.templates_loaded == 1
