"""Apply the MCP-04 change package to a clean worktree. Harness file: never committed.

Usage: python3 apply_mcp04.py <worktree-root> [--check]

Stacks on the SKL-04 branch: the shared case-pack package must already be committed
there. Copies every file under ./pkg (refusing to overwrite anything) and adds the MCP
profile to the profile table with one anchored edit. Every check runs before anything is
written; one problem writes nothing.

Branch: feat/mcp-04-*, cut from the committed SKL-04 branch.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / "pkg"
BRANCH_PREFIXES = ("feat/mcp-04",)
PROFILES = "backend/app/recsys/eval/casepack/profiles.py"

#: Files the SKL-04 package adds; their absence means this is not the stacked branch.
REQUIRED_FILES: tuple[str, ...] = (
    "backend/app/recsys/eval/casepack/cases.py",
    "backend/app/recsys/eval/casepack/corpus.py",
    "backend/app/recsys/eval/casepack/decisions.py",
    "backend/app/recsys/eval/casepack/pack.py",
    PROFILES,
    "backend/app/recsys/eval/casepack/report.py",
    "backend/app/recsys/eval/casepack/split.py",
    "backend/tests/recsys/eval/casepack_support.py",
)

OLD = """_PROFILES: Mapping[ComponentType, CasePackProfile] = MappingProxyType(
    {
        ComponentType.skill: SKILL_PROFILE,
    }
)
"""

NEW = """#: MCP cases. MCP adds partial matches, unknown prerequisites and source conflicts to the
#: shared scenarios; a non-match is a hard negative and an empty control a valid empty.
MCP_PROFILE = CasePackProfile(
    component_type=ComponentType.mcp,
    case_prefix="mcp",
    scenarios=frozenset(
        {
            Scenario.positive,
            Scenario.partial,
            Scenario.hard_negative,
            Scenario.valid_empty,
            Scenario.ambiguous,
            Scenario.access_restricted,
            Scenario.incomplete_description,
            Scenario.source_unavailable,
            Scenario.duplicate_alias,
            Scenario.unresolved_dependency,
            Scenario.unknown_prerequisite,
            Scenario.conflict,
        }
    ),
    required_scenarios=frozenset(
        {
            Scenario.positive,
            Scenario.partial,
            Scenario.hard_negative,
            Scenario.valid_empty,
            Scenario.access_restricted,
            Scenario.duplicate_alias,
            Scenario.unresolved_dependency,
            Scenario.unknown_prerequisite,
            Scenario.conflict,
        }
    ),
)

_PROFILES: Mapping[ComponentType, CasePackProfile] = MappingProxyType(
    {
        ComponentType.skill: SKILL_PROFILE,
        ComponentType.mcp: MCP_PROFILE,
    }
)
"""


def _git(root: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 2
    root = Path(argv[0]).resolve()
    check_only = "--check" in argv[1:]
    problems: list[str] = []

    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if not branch.startswith(BRANCH_PREFIXES):
        problems.append(f"branch is {branch}, expected one of {BRANCH_PREFIXES}")
    if _git(root, "status", "--porcelain"):
        problems.append("worktree is not clean")
    for rel in REQUIRED_FILES:
        if not (root / rel).is_file():
            problems.append(f"missing {rel}: apply on the committed SKL-04 branch")

    new_files: list[tuple[Path, bytes]] = []
    for source in sorted(PKG.rglob("*")):
        if source.is_dir() or "__pycache__" in source.parts:
            continue
        target = root / source.relative_to(PKG)
        if target.exists():
            problems.append(f"new file already exists: {source.relative_to(PKG)}")
        new_files.append((target, source.read_bytes()))
        if target.suffix == ".py":
            try:
                compile(source.read_text(encoding="utf-8"), str(target), "exec")
            except SyntaxError as error:
                problems.append(f"{target.name}: does not compile: {error}")

    edited = ""
    profiles = root / PROFILES
    if profiles.is_file():
        text = profiles.read_text(encoding="utf-8")
        count = text.count(OLD)
        if count != 1:
            problems.append(f"{PROFILES}: anchor found {count}x")
        else:
            edited = text.replace(OLD, NEW, 1)
            try:
                compile(edited, PROFILES, "exec")
            except SyntaxError as error:
                problems.append(f"{PROFILES}: edited text does not compile: {error}")

    if problems:
        print("NOTHING WRITTEN. Problems:")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print(f"OK: {len(new_files)} new files, 1 edit in {PROFILES}")
    if check_only:
        return 0
    for target, data in new_files:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    profiles.write_text(edited, encoding="utf-8")
    print("written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
