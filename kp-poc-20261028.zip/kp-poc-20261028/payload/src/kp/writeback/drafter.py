"""Reference drafter: deterministic spec drafting from a governed template and retrieved passages.

No model is involved. Every sentence taken from a retrieved passage is cited with the
passage's reference, and a passage that reached the story through a guessed link is marked
"proposed" in the text. A model-backed drafter plugs in behind the same
:class:`~kp.writeback.ports.Drafter` port.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

from pydantic import JsonValue

from kp.writeback.citations import CITATION_MARKER, split_sentences
from kp.writeback.ports import DraftedSpec, DraftRequest, EvidenceItem
from kp.writeback.template import Section, split_sections, substitute_variables

PROPOSED_NOTE = "(proposed link)"
_TERMINAL = ".!?"


def cite_sentences(item: EvidenceItem) -> str:
    """Quote a retrieved passage sentence by sentence, each sentence carrying its citation.

    :param item: The retrieved passage
    :return: One line; guessed links are marked as proposed after the citation
    """
    marker = CITATION_MARKER.format(reference=item.reference)
    suffix = f" {PROPOSED_NOTE}" if item.proposed else ""
    sentences = split_sentences(" ".join(item.text.split()))
    return " ".join(f"{sentence.rstrip(_TERMINAL)} {marker}{suffix}." for sentence in sentences)


class TemplateDrafter:
    """Fills the sections of a governed template. Unknown sections keep the template's text."""

    def draft(self, request: DraftRequest) -> DraftedSpec:
        """Draft a spec for a story.

        :param request: The story, the template, retrieved evidence and linked tests
        :return: Markdown following the template, with its coverage and open items
        """
        story = request.story
        evidence = sorted(request.retrieval.evidence, key=lambda item: item.proposed)
        tests = request.tests_by_reference
        untested = tuple(item.reference for item in evidence if not tests.get(item.reference))
        open_items = self._open_items(request, untested)
        handlers: dict[str, Callable[[], list[str]]] = {
            "summary": lambda: self._summary(request),
            "rules": lambda: self._rules(evidence),
            "acceptance": lambda: self._acceptance(request),
            "coverage": lambda: self._coverage(evidence, tests),
            "open items": lambda: [f"- {item}" for item in open_items] or ["None."],
        }
        variables = {"title": story.summary.strip(), "story_key": story.story_key}
        parts: list[str] = []
        for section in split_sections(request.template.body):
            handler = handlers.get(section.title.strip().casefold())
            lines = handler() if handler is not None else list(section.lines)
            parts.append(self._render(section, lines))
        markdown = substitute_variables("\n".join(parts), variables).strip() + "\n"
        coverage: dict[str, JsonValue] = {
            "rules": {item.reference: list(tests.get(item.reference, ())) for item in evidence},
            "rules_without_test": list(untested),
        }
        return DraftedSpec(
            template_id=request.template.template_id,
            template_version=request.template.version,
            markdown=markdown,
            coverage=coverage,
            open_items=open_items,
        )

    @staticmethod
    def _render(section: Section, lines: Sequence[str]) -> str:
        heading = f"{'#' * section.level} {section.title}" if section.level else ""
        body = "\n".join(lines).strip("\n")
        return "\n\n".join(part for part in (heading, body) if part) + "\n"

    @staticmethod
    def _summary(request: DraftRequest) -> list[str]:
        story = request.story
        text = " ".join(f"{story.summary.strip().rstrip(_TERMINAL)}. {story.description}".split())
        return [text]

    @staticmethod
    def _rules(evidence: Sequence[EvidenceItem]) -> list[str]:
        if not evidence:
            return ["No rule or register row was found for this story."]
        return [f"- {cite_sentences(item)}" for item in evidence]

    @staticmethod
    def _acceptance(request: DraftRequest) -> list[str]:
        lines = [line.strip() for line in request.story.acceptance_criteria.splitlines()]
        return [f"- {line}" for line in lines if line] or ["No acceptance criteria were given."]

    @staticmethod
    def _coverage(evidence: Sequence[EvidenceItem], tests: dict[str, tuple[str, ...]]) -> list[str]:
        if not evidence:
            return ["No rules are covered yet."]
        return [
            f"- {item.reference}: "
            + (", ".join(tests[item.reference]) if tests.get(item.reference) else "no linked test")
            for item in evidence
        ]

    @staticmethod
    def _open_items(request: DraftRequest, untested: tuple[str, ...]) -> tuple[str, ...]:
        items = list(request.retrieval.notes)
        if not request.retrieval.evidence:
            items.append("Find the rules or register rows this story rests on.")
        items.extend(
            f"Confirm the proposed link to {item.reference}."
            for item in request.retrieval.evidence
            if item.proposed
        )
        items.extend(f"No test is linked to {reference}." for reference in untested)
        if not request.story.acceptance_criteria.strip():
            items.append("Add acceptance criteria to the story.")
        return tuple(items)
