"""Typed errors of the connectivity harness. All derive from :class:`kp.errors.KpError`."""

from __future__ import annotations

from kp.errors import KpError


class ConnectivityError(KpError):
    """Base class of failures specific to the connectivity harness."""


class GatewayProtocolError(ConnectivityError):
    """The gateway answered, but not with a usable JSON-RPC 2.0 result.

    :param message: What was wrong with the answer
    :param code: The JSON-RPC error code, when the gateway returned an error object
    """

    def __init__(self, message: str, code: int | None = None) -> None:
        super().__init__(message)
        self.code = code


class FidelityError(ConnectivityError):
    """A tool returned a summary or prose where the source's own fields were needed (R-02).

    :param source: The source kind value (for example ``jira``)
    :param item_id: The sample item that could not be read faithfully
    :param reason: What was missing or malformed
    """

    def __init__(self, source: str, item_id: str, reason: str) -> None:
        super().__init__(f"Tool response lost source fields for {source}/{item_id}: {reason}")
        self.source = source
        self.item_id = item_id
        self.reason = reason


class ExtractionError(ConnectivityError):
    """The extraction service could not convert this object (a result about the object)."""


class MissingExtractorVersionError(ExtractionError):
    """An extraction response carried no extractor version, which the contract requires."""


class ExtractionUnavailableError(ConnectivityError):
    """The extraction service could not be reached or failed on its side."""


class ImmutableObjectError(ConnectivityError):
    """A write targeted an existing key with different bytes. Stored objects are never replaced."""


class InvalidObjectKeyError(ConnectivityError, ValueError):
    """An object key was empty, absolute or tried to leave the store."""


class BucketClientUnavailableError(ConnectivityError):
    """The cloud-bucket client library is not installed, so the bucket store cannot be used."""


class SampleItemsError(ConnectivityError):
    """The sample items file is missing, malformed or not the fixed 3 + 3 + 3 set."""


class GatewayForbiddenError(ConnectivityError):
    """The gateway authenticated the caller but its group entitlement does not allow the call."""
