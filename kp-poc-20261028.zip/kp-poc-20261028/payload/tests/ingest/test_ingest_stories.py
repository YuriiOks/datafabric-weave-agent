"""Story normaliser: US-05 (acceptance criteria kept separate; status is not a change)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from kp.domain import Story
from kp.ingest import StoryParseError, normalise_story, parse_story_export
from kp.testing.dataset import SyntheticDataset


def _export(dataset: SyntheticDataset, relative: str) -> dict[str, Story]:
    content = Path(dataset.path(relative)).read_bytes()
    return {s.story_key: s for s in parse_story_export(content, default_version="fallback")}


def _issue(**fields: object) -> dict[str, object]:
    return {"key": "PAY-1", "fields": {"summary": "A story", **fields}}


def test_us05_first_export_loads_every_story_with_all_fields(dataset: SyntheticDataset) -> None:
    stories = _export(dataset, dataset.truth.stories.first_export)
    assert len(stories) == dataset.truth.stories.story_count
    story = stories["PAY-103"]
    assert story.summary == "Enforce the per-transfer amount limit"
    assert "published limit" in story.description
    assert story.acceptance_criteria.startswith("Given an amount above the limit")
    assert [(link.link_type, link.target_key) for link in story.links] == [
        ("implements", "REQ-002"),
        ("relates to", "PAY-102"),
    ]
    assert story.parent_key == "PAY-100"
    assert story.status == "To Do"
    assert story.domain == "payments"
    assert stories["PAY-100"].parent_key is None
    assert stories["PAY-106"].domain == "cards"


def test_us05_acceptance_criteria_are_separate_from_the_description(
    dataset: SyntheticDataset,
) -> None:
    stories = _export(dataset, dataset.truth.stories.first_export)
    with_criteria = [story for story in stories.values() if story.acceptance_criteria]
    assert with_criteria
    for story in with_criteria:
        assert story.acceptance_criteria not in story.description
        assert "cceptance criteria" not in story.description
    assert stories["PAY-100"].acceptance_criteria == ""


def test_us05_status_only_change_keeps_the_fingerprint(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.stories
    first = _export(dataset, truth.first_export)
    second = _export(dataset, truth.second_export)
    before, after = first[truth.status_only_key], second[truth.status_only_key]
    assert before.status != after.status
    assert before.version != after.version
    assert before.fingerprint() == after.fingerprint()


def test_us05_criteria_change_alters_only_that_fingerprint(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.stories
    first = _export(dataset, truth.first_export)
    second = _export(dataset, truth.second_export)
    changed = {key for key in first if first[key].fingerprint() != second[key].fingerprint()}
    assert changed == {truth.criteria_changed_key}


def test_us05_version_is_the_updated_time_or_the_given_default() -> None:
    assert normalise_story(
        _issue(updated="2026-10-01T09:00:00+00:00"), default_version="d"
    ).version == ("2026-10-01T09:00:00+00:00")
    assert normalise_story(_issue(), default_version="d").version == "d"


@pytest.mark.parametrize(
    ("updated", "expected"),
    [
        ("2026-10-01T10:00:00.000+0100", "2026-10-01T09:00:00+00:00"),
        ("2026-10-01T09:30:00.000+0000", "2026-10-01T09:30:00+00:00"),
        ("2026-10-01T09:30:00Z", "2026-10-01T09:30:00+00:00"),
        ("2026-10-01T09:30:00", "2026-10-01T09:30:00+00:00"),
        ("not a time", "not a time"),
    ],
)
def test_us05_version_is_written_as_utc_so_text_order_is_time_order(
    updated: str, expected: str
) -> None:
    assert normalise_story(_issue(updated=updated), default_version="d").version == expected


def test_us05_versions_with_different_offsets_sort_by_the_moment_they_name() -> None:
    earlier = normalise_story(_issue(updated="2026-10-01T09:30:00.000+0000"), default_version="d")
    later = normalise_story(_issue(updated="2026-10-01T10:00:00.000+0100"), default_version="d")
    assert later.version < earlier.version  # 09:00Z is before 09:30Z, whatever the text says


def test_us05_criteria_section_is_split_out_of_the_description() -> None:
    description = (
        "Reject bad references.\n\nh3. Acceptance criteria\n"
        "Given a bad reference, it is rejected.\nGiven a good one, it is accepted.\n\n"
        "h3. Notes\nSee the rulebook."
    )
    story = normalise_story(_issue(description=description), default_version="1")
    assert story.acceptance_criteria == (
        "Given a bad reference, it is rejected.\nGiven a good one, it is accepted."
    )
    assert story.description == "Reject bad references.\n\nh3. Notes\nSee the rulebook."


def test_us05_markdown_style_criteria_heading_is_recognised() -> None:
    story = normalise_story(
        _issue(description="Intro.\n\n## Acceptance Criteria:\n- one\n- two"), default_version="1"
    )
    assert story.acceptance_criteria == "- one\n- two"
    assert story.description == "Intro."


def test_us05_criteria_field_wins_over_a_description_section() -> None:
    story = normalise_story(
        _issue(description="Intro.\n\nAcceptance criteria\nfrom text", acceptance_criteria="field"),
        default_version="1",
    )
    assert story.acceptance_criteria == "field"
    assert "from text" in story.description


def test_us05_rich_text_description_is_flattened() -> None:
    document = {
        "type": "doc",
        "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": "First line."}]},
            {
                "type": "paragraph",
                "content": [
                    {"type": "text", "text": "Second"},
                    {"type": "hardBreak"},
                    {"type": "text", "text": "line."},
                ],
            },
        ],
    }
    story = normalise_story(_issue(description=document), default_version="1")
    assert story.description == "First line.\nSecond\nline."


def test_us05_tracker_link_shapes_are_normalised() -> None:
    links = [
        {
            "type": {"name": "Relates", "outward": "relates to", "inward": "relates to"},
            "outwardIssue": {"key": "PAY-2"},
        },
        {
            "type": {"name": "Blocks", "outward": "blocks", "inward": "is blocked by"},
            "inwardIssue": {"key": "PAY-3"},
        },
        {"type": "implements", "key": "REQ-1"},
        {"type": "broken"},
        "not a link",
    ]
    story = normalise_story(_issue(issuelinks=links), default_version="1")
    assert [(link.link_type, link.target_key) for link in story.links] == [
        ("relates to", "PAY-2"),
        ("is blocked by", "PAY-3"),
        ("implements", "REQ-1"),
    ]


def test_us05_status_parent_and_domain_accept_plain_values() -> None:
    story = normalise_story(
        _issue(status="Done", parent="PAY-9", labels=["x", "domain:cards", "domain:payments"]),
        default_version="1",
    )
    assert (story.status, story.parent_key, story.domain) == ("Done", "PAY-9", "cards")


def test_us05_single_issue_record_is_accepted() -> None:
    stories = parse_story_export(json.dumps(_issue()).encode(), default_version="1")
    assert [story.story_key for story in stories] == ["PAY-1"]


@pytest.mark.parametrize(
    "content",
    [
        b"not json",
        b'{"issues": "no"}',
        b'{"issues": [1]}',
        b'{"key": "A-1"}',
        b'{"key": "A-1", "fields": {"summary": " "}}',
        b'{"fields": {"summary": "x"}}',
        b"[]",
    ],
)
def test_us05_malformed_records_are_typed_errors(content: bytes) -> None:
    with pytest.raises(StoryParseError):
        parse_story_export(content, default_version="1")


def test_us05_one_bad_issue_fails_the_export_and_the_error_names_its_position() -> None:
    good = _issue()
    bad = {"key": "PAY-2", "fields": {"summary": " "}}
    content = json.dumps({"issues": [good, good, bad]}).encode()
    with pytest.raises(StoryParseError, match="Issue 2 of the story export"):
        parse_story_export(content, default_version="1")
