"""The two server entry points. Read and write are separate servers because their risk differs."""

from __future__ import annotations

from typing import Final

from kp.clock import Clock
from kp.mcp.server import McpServer
from kp.tools import (
    AuditSink,
    DomainDirectory,
    ReadPorts,
    ToolObserver,
    WriteToolPort,
    build_read_registry,
    build_write_registry,
)

READ_SERVER_NAME: Final = "kp-read"
WRITE_SERVER_NAME: Final = "kp-write"


def build_read_server(
    ports: ReadPorts,
    directory: DomainDirectory,
    audit: AuditSink,
    *,
    clock: Clock | None = None,
    observer: ToolObserver | None = None,
) -> McpServer:
    """Build the read server: search, links, template, rule_as_at and coverage.

    :param ports: Search, links, rules, templates and coverage
    :param directory: Identity to allowed domains
    :param audit: Where call records go
    :param clock: Time source; defaults to the system clock
    :param observer: Told about every successful call, e.g. to remember what a session saw
    :return: The server
    """
    registry = build_read_registry(ports, directory, audit, clock=clock, observer=observer)
    return McpServer(
        registry,
        name=READ_SERVER_NAME,
        instructions="Read-only knowledge tools. Access follows the caller's identity.",
    )


def build_write_server(
    port: WriteToolPort,
    directory: DomainDirectory,
    audit: AuditSink,
    *,
    clock: Clock | None = None,
) -> McpServer:
    """Build the write server around the tools another lane provides.

    :param port: The write tools
    :param directory: Identity to allowed domains
    :param audit: Where call records go
    :param clock: Time source; defaults to the system clock
    :return: The server; it serves no read tool
    """
    registry = build_write_registry(port, directory, audit, clock=clock)
    return McpServer(
        registry,
        name=WRITE_SERVER_NAME,
        instructions="Write tools. Targets are fixed on the server; requests cannot change them.",
    )
