"""Grouped partition split, final-test freeze and the tuning-feedback check.

A group is the unit of assignment, so related needs can never straddle partitions. The
assignment hashes the seed and the group id; adding a group never moves an existing one.
The final-test partition is frozen by digest once its cases are decided, and no tuning
feedback may be recorded against it.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterable, Mapping, Sequence
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.recsys.eval.casepack.cases import (
    CASE_ID_RE,
    GROUP_ID_RE,
    POSITIVE_LABELS,
    EvaluationCase,
    EvidenceKind,
)
from app.recsys.eval.casepack.lineage import CasePackError, canonical_digest


class Partition(str, Enum):
    """The evaluation partitions, in assignment order."""

    development = "development"
    validation = "validation"
    calibration = "calibration"
    final_test = "final_test"


class SplitManifest(BaseModel):
    """The partition of every group, and the digest that froze the final test."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    seed: str = Field(min_length=1, max_length=64)
    weights: dict[Partition, int]
    assignments: dict[str, Partition] = Field(default_factory=dict)
    frozen_final_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")

    @field_validator("weights")
    @classmethod
    def _weights_usable(cls, value: dict[Partition, int]) -> dict[Partition, int]:
        """Refuse negative weights and an all-zero split.

        :param value: The weight of each partition.
        :return: The weights.
        :raises ValueError: When a weight is negative or all are zero.
        """
        if any(weight < 0 for weight in value.values()) or sum(value.values()) <= 0:
            raise ValueError("partition weights are non-negative and not all zero")
        return value

    @model_validator(mode="after")
    def _groups_named(self) -> SplitManifest:
        """Refuse malformed group ids.

        :return: The manifest.
        :raises ValueError: When a group id is malformed.
        """
        if any(not GROUP_ID_RE.match(group) for group in self.assignments):
            raise ValueError("group ids are lower-case words joined by hyphens")
        return self

    def partition_of(self, group_id: str) -> Partition:
        """Return the partition of one group.

        :param group_id: The group id.
        :return: Its partition.
        :raises CasePackError: When the split does not assign the group.
        """
        try:
            return self.assignments[group_id]
        except KeyError as error:
            raise CasePackError(f"group {group_id} has no partition") from error

    def digest(self) -> str:
        """:return: The digest a release record cites the split with."""
        return canonical_digest(self.model_dump(mode="json"))


def _bucket(seed: str, group_id: str, weights: Mapping[Partition, int]) -> Partition:
    """Place one group by hashing the seed and the group id.

    :param seed: The split seed.
    :param group_id: The group id.
    :param weights: The weight of each partition.
    :return: The partition.
    """
    digest = hashlib.sha256(f"{seed}\x1f{group_id}".encode()).hexdigest()
    point = int(digest[:16], 16) % sum(weights.values())
    for partition in Partition:
        point -= weights.get(partition, 0)
        if point < 0:
            return partition
    raise CasePackError("partition weights do not cover the hash range")


def assign_partitions(
    group_ids: Iterable[str], *, seed: str, weights: Mapping[Partition, int]
) -> SplitManifest:
    """Assign every group to one partition, deterministically.

    :param group_ids: The groups to place.
    :param seed: The split seed; one seed per pack.
    :param weights: The weight of each partition, chosen by the pack owner.
    :return: The split manifest, not yet frozen.
    """
    checked = SplitManifest(seed=seed, weights=dict(weights))
    assignments = {
        group: _bucket(seed, group, checked.weights) for group in sorted(set(group_ids))
    }
    return SplitManifest(seed=seed, weights=checked.weights, assignments=assignments)


class _DuplicateSets:
    """Union-find over component ids known to be duplicates or aliases of each other."""

    def __init__(self) -> None:
        """Start with no known duplicates."""
        self._parent: dict[str, str] = {}

    def known(self, item: str) -> bool:
        """Return whether a component belongs to any duplicate set.

        :param item: A component id.
        :return: ``True`` when it does.
        """
        return item in self._parent

    def root(self, item: str) -> str:
        """Return the representative of a component's duplicate set.

        :param item: A component id.
        :return: The representative id.
        """
        self._parent.setdefault(item, item)
        while self._parent[item] != item:
            self._parent[item] = self._parent[self._parent[item]]
            item = self._parent[item]
        return item

    def join(self, left: str, right: str) -> None:
        """Record two components as duplicates.

        :param left: A component id.
        :param right: Another component id.
        """
        self._parent[self.root(left)] = self.root(right)


def check_grouping(
    cases: Sequence[EvaluationCase], *, related: Iterable[Iterable[str]] = ()
) -> None:
    """Refuse related cases that sit in different groups.

    Two cases are related when they state the same need, or when components judged relevant
    to them (or named by duplicate evidence) belong to one duplicate set. Duplicate sets come
    from ``duplicate_identity`` evidence and from ``related``.

    :param cases: The cases of one pack.
    :param related: Further sets of components known to be duplicates or aliases.
    :raises CasePackError: When related cases sit in different groups.
    """
    duplicates = _DuplicateSets()
    for members in related:
        ordered = sorted(members)
        for item in ordered[1:]:
            duplicates.join(ordered[0], item)
    for case in cases:
        for evidence in case.required_evidence:
            if evidence.kind is EvidenceKind.duplicate_identity and evidence.related_id:
                duplicates.join(evidence.subject_id, evidence.related_id)
    by_need: dict[str, str] = {}
    by_set: dict[str, str] = {}
    for case in cases:
        need = case.input.card_id or f"text:{case.input.text}"
        if by_need.setdefault(need, case.group_id) != case.group_id:
            raise CasePackError(f"case {case.case_id} repeats a need from another group")
        touched = set(case.adjudication.ids_labelled(*POSITIVE_LABELS))
        for evidence in case.required_evidence:
            if evidence.kind is EvidenceKind.duplicate_identity:
                touched |= evidence.component_ids()
        for component_id in sorted(touched):
            if not duplicates.known(component_id):
                continue
            root = duplicates.root(component_id)
            if by_set.setdefault(root, case.group_id) != case.group_id:
                raise CasePackError(f"case {case.case_id} splits a duplicate set across groups")


def final_cases(cases: Sequence[EvaluationCase], split: SplitManifest) -> list[EvaluationCase]:
    """Select the final-test cases.

    :param cases: The cases of one pack.
    :param split: The split.
    :return: The final-test cases, sorted by case id.
    """
    chosen = [case for case in cases if split.partition_of(case.group_id) is Partition.final_test]
    return sorted(chosen, key=lambda case: case.case_id)


def final_digest(cases: Sequence[EvaluationCase], split: SplitManifest) -> str:
    """Digest the final-test cases, adjudication included.

    :param cases: The cases of one pack.
    :param split: The split.
    :return: The digest.
    """
    return canonical_digest([case.model_dump(mode="json") for case in final_cases(cases, split)])


def freeze_final(cases: Sequence[EvaluationCase], split: SplitManifest) -> SplitManifest:
    """Freeze the final-test partition as it stands.

    Freeze once the final-test cases are decided. A later change needs a new held-out set,
    not a re-freeze.

    :param cases: The cases of one pack.
    :param split: The split.
    :return: The split with the final-test digest recorded.
    :raises CasePackError: When the split is already frozen or the final test is empty.
    """
    if split.frozen_final_digest is not None:
        raise CasePackError("the final test is already frozen; a change needs a new held-out set")
    if not final_cases(cases, split):
        raise CasePackError("the final-test partition holds no case")
    return split.model_copy(update={"frozen_final_digest": final_digest(cases, split)})


def verify_final(cases: Sequence[EvaluationCase], split: SplitManifest) -> None:
    """Check that the final-test cases are exactly the frozen ones.

    :param cases: The cases of one pack.
    :param split: The split.
    :raises CasePackError: When the final test is not frozen or has changed since.
    """
    if split.frozen_final_digest is None:
        raise CasePackError("the final-test partition is not frozen")
    if final_digest(cases, split) != split.frozen_final_digest:
        raise CasePackError("the final-test cases changed after the freeze")


class FeedbackPurpose(str, Enum):
    """Why someone looked at case results while changing the system."""

    tuning = "tuning"
    threshold_selection = "threshold_selection"
    error_analysis = "error_analysis"


class FeedbackEntry(BaseModel):
    """One record of results consulted while changing the system or its thresholds."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    entry_id: str = Field(min_length=1, max_length=64)
    recorded_at: datetime
    actor: str = Field(min_length=1, max_length=128)
    purpose: FeedbackPurpose
    case_ids: tuple[str, ...] = Field(min_length=1)
    note: str = Field(default="", max_length=2000)

    @field_validator("case_ids")
    @classmethod
    def _case_ids_shape(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Refuse malformed case ids.

        :param value: The case ids.
        :return: The ids, checked.
        """
        if any(not CASE_ID_RE.match(item) for item in value):
            raise ValueError("case ids look like skl-0001")
        return value


def check_feedback(
    entries: Sequence[FeedbackEntry], cases: Sequence[EvaluationCase], split: SplitManifest
) -> None:
    """Refuse feedback recorded against the held-out final test.

    :param entries: The feedback log.
    :param cases: The cases of one pack.
    :param split: The split.
    :raises CasePackError: When an entry names an unknown or a final-test case.
    """
    partitions = {case.case_id: split.partition_of(case.group_id) for case in cases}
    seen: set[str] = set()
    for entry in entries:
        if entry.entry_id in seen:
            raise CasePackError(f"feedback entry {entry.entry_id} is recorded twice")
        seen.add(entry.entry_id)
        for case_id in entry.case_ids:
            if case_id not in partitions:
                raise CasePackError(f"feedback entry {entry.entry_id} names an unknown case")
            if partitions[case_id] is Partition.final_test:
                raise CasePackError(f"feedback entry {entry.entry_id} touches the final test")
