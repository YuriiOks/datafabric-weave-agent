---
spec_type: functional
template_id: functional-spec
version: 1.0.0
---
# {{title}}

## Summary

One paragraph describing the change for the story.

## Rules

Every statement in this section cites a clause or a register row.

## Acceptance

Observable conditions, one per line.

## Coverage

Rules touched and the tests that verify them.

## Open items

Questions that remain.
