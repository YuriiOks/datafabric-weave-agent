# Reference patterns from prior work, part 1 (patterns 1 to 8)

Design patterns from an earlier, unrelated product. Prose only: no code, no names.
Labels: the description of the prior work is Reported (a review of it, not checked against its
code). Every "Add" line is Proposed. "Design only" means written but never run live.
Use as a checklist for S1..S6: S1 review, S2 gaps, S3 product, S4 roles, S5 graph, S6 ingestion.
Each pattern: problem, how it works, invariants, what we add, stories served. Part 2: 9 to 15.

## 1. Access control and delegation
Problem: one place must answer "may this person do this action here".
How it works:
- One resolver answers for every endpoint. A list twin answers for many rows in one query.
- Three tiers: platform admin, resource owner, then explicit grant rows for everyone else.
- A grant row names resource, person, level and issuer. Owner and admin access is implicit.
- Only the owner or an admin may create, change or revoke grants on a resource.
Invariants:
- Deny by default. Inactive people get no access, even if grant rows remain.
- Access never crosses the outer boundary (tenant or namespace).
- Sharing changes run in one transaction with typed errors and a logged denial.
Add for our stories:
- Replace the two-level ladder with actions: create, view, update, delete, upload, approve, publish.
- Add scope (domain, then sub-domain, flowing down). Let the principal be a person or a group.
- Resolve identity once per request into one context object (person, admin flag, group ids).
Serves: S4, S2, S3.

## 2. Approval and lifecycle state machine
Problem: a product must move through reviewed steps and not skip one.
How it works:
- One table lists the allowed moves from each status. A validator rejects any other move.
- Each move writes a before-and-after row with the actor and the time.
- Core fields are locked once the record leaves the first review state.
- Approval locks the row, checks the move, stamps approver and time, then notifies after commit.
Invariants:
- Every status change goes through the one validator, under a row lock, so reviewers cannot race.
- No notification is sent for a rolled-back change. Approved content is not edited in place.
Add for our stories:
- Statuses: draft, in review, awaiting approval, approved, published, plus rejected and retired.
- A published product is immutable. An edit after publish creates a new version.
- Maker-checker (the prior work had none) and a role check on each move, not a general write check.
Serves: S3, S4, S2.

## 3. Review queue for machine proposals
Problem: a machine proposes a change, and a person must accept it before it counts.
How it works:
- A proposal holds the old value, the new value and a link to the source evidence.
- Statuses: pending, accepted, rejected, superseded. A newer proposal supersedes older pending ones.
- Accept and reject lock the row and refuse anything that is not pending.
- A pure decision function picks skip, apply, or send to review, with a reason code. Inputs are
  confidence, source priority and protected fields.
Invariants:
- A machine never overwrites a value that a person supplied.
- Rejected proposals stay visible in the field history. Reviewer and time are kept.
Add for our stories:
- One queue for extraction results, product metadata edits and re-extraction after a change.
- Route by role: steward approves, producer reviews. Extend from one field to a whole object.
Serves: S3, S5, S4.

## 4. Rules registry and validation gates
Problem: quality rules must run the same way every time and block a bad publish.
How it works:
- A closed registry lists small checkers. Each returns a finding or nothing.
- The registry, not the checker, sets rule type and priority.
- Findings replace the stored set inside one locked transaction per object.
- A person can waive a finding. The waiver ties to a versioned key and lapses when facts change.
- A gate returns a frozen verdict: passed, blocking findings, warnings. The verdict is logged.
Invariants:
- A rule that cannot run is reported as not measured. It is never counted as passed.
- The gate runs before approved and again before publish. Rules were code, not data.
Add for our stories:
- One checker per quality rule: owner set, purpose filled, sources reachable, freshness, coverage.
- Hold custom rules as data with a small expression language. This is new work.
Serves: S3, S2, S5.

## 5. Append-only audit
Problem: show who did what, and prove the record was not changed later.
How it works:
- Two events per call: one before any data is read, one with the exact output before release.
- Both share a correlation id and a sequence number.
- An event keeps actor and client snapshot, scopes, source address, redacted input, output,
  digests, sizes and duration. A database constraint keeps output, digest and size consistent.
- Reading or exporting the audit is itself audited.
Invariants:
- Fail closed. If the audit cannot be written, the call fails and returns no data.
- Update and delete are blocked by a database privilege or trigger, not by code checks.
- The audit table is global on purpose, so one query spans every namespace.
Add for our stories:
- Audit publish, approve, grant changes and every tool-server read. Record the namespace.
- Keep field-level history: which source set a property, and which person accepted it.
Serves: S2, S4, S6.

## 6. Tenant or namespace isolation with a database backstop
Problem: a forgotten filter must not leak one namespace into another.
How it works:
- Layer 1: a context variable holds the namespace and default queries filter by it.
- Layer 2: row policies in the database read a session setting for the namespace.
- Crossing namespaces needs an explicit call with a mandatory, logged reason.
- Every table declares a class: namespace-owned, global, link table, or undecided. A test walks
  all tables and the undecided count may only fall.
Invariants:
- An unset namespace shows no rows. Superuser access is an explicit, logged bypass.
- Pooled connections need settings scoped to the transaction.
- Design only: the runtime layers were written but not switched on.
Add for our stories:
- Replace the single tenant id with a set of domain ids the caller may see.
- Apply the same boundary to storage prefixes, graph names and vector collections.
- Present this to reviewers as a reviewed design, not as proven code.
Serves: S2, S4, S6.

## 7. Source connector contract and import provenance
Problem: many kinds of source must feed one pipeline and stay traceable.
How it works:
- A typed contract per source: search containers, get one, list documents with cursor paging,
  retrieve a document. Each source declares what it supports. A registry maps key to adapter.
- Every document carries a source identity and a fingerprint.
- A provenance record is written as pending before bytes move, then resolves to imported,
  aborted or superseded. A sweep resolves records left pending.
- The record keeps source, account scope, item id and version evidence with method and strength.
Invariants:
- Evidence never exists only in memory. Lineage survives deletion of the target.
- Method, value and strength are consistent, enforced by a database constraint.
Add for our stories:
- A dynamic registry (the prior one was static). Reuse the record as a product's upstream sources.
- Add database and file-share connectors. They did not exist.
Serves: S6, S3, S2.

## 8. Server-chosen storage keys and upload sessions
Problem: a client must not decide where a file lands.
How it works:
- One function builds the object key from server-controlled ids and an allowlisted extension.
- A prefix helper is the only source of prefixes, so ownership checks stay meaningful.
- The session row is committed before the upload grant is issued, so no orphan can exist.
- Uploads go to a staging area and are promoted after checks. A reconciler sweeps stuck sessions.
Invariants:
- No client string reaches the key. The user filename is a display name only.
- Path parts are ids or allowlisted values. Keys in the prior work were flat.
Add for our stories:
- Prefix by domain, sub-domain, namespace and product, all as server-controlled ids.
- Keep versions of an object under the same prefix. Port the grant step to the target store.
Serves: S6, S2, S1.
