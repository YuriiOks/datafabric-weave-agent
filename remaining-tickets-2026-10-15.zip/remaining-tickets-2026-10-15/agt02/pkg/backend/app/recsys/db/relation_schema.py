"""DDL for relation keys, relation evidence and the reference outcome on the ledger.

Kept out of :mod:`app.recsys.db.schema` so that module only gains a splice. Executed by
``ensure_schema`` in the same transaction, under the same advisory lock, after the
legacy tables and their earlier column additions.

Everything here is additive. ``recsys_component_link`` gains two nullable columns: rows
written before this change, and fixtures that insert only the original columns, stay
valid. The review ledger gains three nullable columns that stay ``NULL`` for record
entries. The evidence table hangs off a link by the link's own primary key and cascades
with it, matching the review-ledger precedent, so a test that removes its own version's
links does not have to know this table exists. The table name deliberately does not
start with ``recsys_component_link``: the writer's tests assert, by prefix, that no
statement deletes from the link table.

The human-only reversal is in ``docs/recsys/catalogue-reversal.sql``.
"""

from __future__ import annotations

RELATION_TABLE_NAMES: tuple[str, ...] = ("recsys_relation_evidence",)

#: Spelled out rather than generated from the enums, so the DDL is reviewable as
#: written; a test pins both lists to :class:`~app.recsys.contracts.LinkType` and
#: :class:`~app.recsys.contracts.ResolutionOutcome`.
LINK_TYPE_VALUES: tuple[str, ...] = (
    "USES_SKILL",
    "USES_MCP",
    "USES_KNOWLEDGE",
    "DEPENDS_ON_SKILL",
    "ALLOWS_MCP",
)
RESOLUTION_OUTCOME_VALUES: tuple[str, ...] = (
    "resolved_exact",
    "resolved_reviewed_mapping",
    "missing",
    "ambiguous",
    "invalid",
    "out_of_scope",
)

RELATION_ALTERS: list[str] = [
    "ALTER TABLE recsys_component_link ADD COLUMN IF NOT EXISTS relation_key TEXT "
    "CHECK (relation_key IS NULL OR relation_key ~ '^[0-9a-f]{64}$')",
    "ALTER TABLE recsys_component_link ADD COLUMN IF NOT EXISTS evidence_digest TEXT "
    "CHECK (evidence_digest IS NULL OR evidence_digest ~ '^[0-9a-f]{64}$')",
    "ALTER TABLE recsys_review_ledger_entry ADD COLUMN IF NOT EXISTS resolution_outcome "
    "TEXT CHECK (resolution_outcome IS NULL OR resolution_outcome IN ("
    "'resolved_exact', 'resolved_reviewed_mapping', 'missing', 'ambiguous', 'invalid', "
    "'out_of_scope'"
    "))",
    "ALTER TABLE recsys_review_ledger_entry ADD COLUMN IF NOT EXISTS owner_component_id "
    "TEXT CHECK (owner_component_id IS NULL OR char_length(owner_component_id) <= 512)",
    "ALTER TABLE recsys_review_ledger_entry ADD COLUMN IF NOT EXISTS link_type TEXT "
    "CHECK (link_type IS NULL OR link_type IN ("
    "'USES_SKILL', 'USES_MCP', 'USES_KNOWLEDGE', 'DEPENDS_ON_SKILL', 'ALLOWS_MCP'"
    "))",
]

RELATION_SCHEMA: list[str] = [
    """
    CREATE TABLE IF NOT EXISTS recsys_relation_evidence (
        catalogue_version TEXT NOT NULL,
        src_id TEXT NOT NULL,
        dst_id TEXT NOT NULL,
        link_type TEXT NOT NULL CHECK (link_type IN (
            'USES_SKILL', 'USES_MCP', 'USES_KNOWLEDGE', 'DEPENDS_ON_SKILL', 'ALLOWS_MCP'
        )),
        entry_ordinal INTEGER NOT NULL CHECK (entry_ordinal >= 0),
        relation_key TEXT NOT NULL CHECK (relation_key ~ '^[0-9a-f]{64}$'),
        authority TEXT NOT NULL CHECK (char_length(authority) BETWEEN 1 AND 64),
        collection TEXT NOT NULL CHECK (char_length(collection) BETWEEN 1 AND 64),
        structural_locator TEXT NOT NULL
            CHECK (char_length(structural_locator) BETWEEN 1 AND 512),
        field_name TEXT NOT NULL CHECK (char_length(field_name) BETWEEN 1 AND 128),
        token_ordinal INTEGER NOT NULL CHECK (token_ordinal >= 0),
        raw_value TEXT CHECK (raw_value IS NULL OR char_length(raw_value) <= 256),
        raw_value_redacted BOOLEAN NOT NULL DEFAULT FALSE,
        raw_value_digest TEXT
            CHECK (raw_value_digest IS NULL OR raw_value_digest ~ '^[0-9a-f]{64}$'),
        resolution_outcome TEXT NOT NULL CHECK (resolution_outcome IN (
            'resolved_exact', 'resolved_reviewed_mapping', 'missing', 'ambiguous',
            'invalid', 'out_of_scope'
        )),
        matched_index TEXT CHECK (matched_index IS NULL OR char_length(matched_index) <= 64),
        rule_id TEXT CHECK (rule_id IS NULL OR char_length(rule_id) <= 256),
        rule_version TEXT CHECK (rule_version IS NULL OR char_length(rule_version) <= 128),
        PRIMARY KEY (catalogue_version, src_id, dst_id, link_type, entry_ordinal),
        FOREIGN KEY (catalogue_version, src_id, dst_id, link_type)
            REFERENCES recsys_component_link (catalogue_version, src_id, dst_id, link_type)
            ON DELETE CASCADE,
        CHECK (raw_value IS NOT NULL OR raw_value_digest IS NOT NULL)
    )
    """,
]

RELATION_INDEXES: list[str] = [
    "CREATE INDEX IF NOT EXISTS idx_recsys_relation_evidence_key "
    "ON recsys_relation_evidence (catalogue_version, relation_key)",
]
