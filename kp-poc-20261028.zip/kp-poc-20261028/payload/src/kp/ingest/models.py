"""Result types of the parsers. Pure values; nothing here touches storage."""

from __future__ import annotations

from datetime import date
from enum import StrEnum
from typing import Annotated

from pydantic import Field

from kp.domain import Clause, Requirement
from kp.domain.base import DomainModel


class StructureDecision(StrEnum):
    """What the structure score allows: load, ask a person, or refuse."""

    PROCEED = "proceed"
    REVIEW = "review"
    BLOCK = "block"


class TocEntry(DomainModel):
    """One line of a table of contents.

    :ivar page: The page the table of contents gives for the clause, when it gives one.
    """

    number: str
    title: str
    page: Annotated[int, Field(ge=0)] | None = None


class ParsedRulebook(DomainModel):
    """A rulebook edition split into clauses, with the evidence about how well it split.

    :ivar edition: Edition label used in every clause reference: the one the source item
        carries when it was given, otherwise the one the document states.
    :ivar declared_edition: Edition label the document states about itself, if it does.
    :ivar declared_effective_date: Effective date the document states about itself, if it does.
    :ivar toc: Entries of the table of contents; empty when none was found.
    :ivar clauses: Clauses in reading order.
    :ivar structure_score: Confidence in the split, 0 to 1.
    :ivar decision: Outcome of the score thresholds, capped at review when the clause
        count does not match the table of contents or the document states another edition.
    :ivar toc_matches: True when the table of contents exists and lists exactly the
        numbered clauses found in the body.
    :ivar anomalies: Plain-language findings behind a lower score.
    :ivar text_extractor: What produced the text positions refer to, e.g. ``pypdf 6.2.1``.
    """

    edition: str
    declared_edition: str | None = None
    declared_effective_date: date | None = None
    toc: tuple[TocEntry, ...]
    clauses: tuple[Clause, ...]
    structure_score: Annotated[float, Field(ge=0, le=1)]
    decision: StructureDecision
    toc_matches: bool
    anomalies: tuple[str, ...] = ()
    text_extractor: str


class SheetReport(DomainModel):
    """What the register parser concluded about one sheet.

    :ivar header_row: One-based header row number; ``None`` when no row was chosen.
    :ivar header_confidence: Confidence in that choice, 0 to 1.
    :ivar data_row_count: Non-blank rows below the header (0 when refused).
    :ivar refused: True when the confidence is below the threshold, so no requirement came
        from this sheet.
    :ivar candidate_rows: Best-scoring row numbers, best first; offered to a reviewer.
    """

    sheet: str
    header_row: Annotated[int, Field(ge=1)] | None = None
    header_confidence: Annotated[float, Field(ge=0, le=1)]
    data_row_count: Annotated[int, Field(ge=0)] = 0
    refused: bool = False
    candidate_rows: tuple[int, ...] = ()


class ParsedRegister(DomainModel):
    """A workbook split into requirements, one per data row, plus per-sheet reports.

    :ivar requirements: The requirements of every accepted sheet, in sheet and row order.
    :ivar sheets: One report per sheet, refused or not, in workbook order.
    """

    requirements: tuple[Requirement, ...]
    sheets: tuple[SheetReport, ...]

    @property
    def refused_sheets(self) -> tuple[SheetReport, ...]:
        """Sheets that were refused because no header row was found with enough confidence."""
        return tuple(sheet for sheet in self.sheets if sheet.refused)
