"""Parsed content: register requirements, stories and searchable passages."""

from __future__ import annotations

import hashlib
import json
from typing import Annotated, Self

from pydantic import Field, model_validator

from kp.domain.base import DomainModel
from kp.domain.enums import PassageType, SourceKind

EMBEDDING_DIMENSIONS = 768


class Requirement(DomainModel):
    """One register row. ``requirement_id`` is stable: ``<item_id>:<sheet>:<row_number>``.

    :ivar row_number: One-based spreadsheet row number of the data row.
    :ivar header_confidence: Confidence that the sheet's header row was identified.
    """

    requirement_id: str
    source: SourceKind
    item_id: str
    version: str
    sheet: str
    row_number: Annotated[int, Field(ge=1)]
    header_confidence: Annotated[float, Field(ge=0, le=1)]
    domain: str | None = None
    fields: dict[str, str]


class StoryLink(DomainModel):
    """A link stated on a story by its tracker, e.g. ``relates to`` another issue."""

    link_type: str
    target_key: str


class Story(DomainModel):
    """A tracker story. ``status`` is deliberately outside the change fingerprint.

    A board move alters only ``status`` and must cause no reprocessing; a change to any
    fingerprinted field reprocesses exactly this story.
    """

    story_key: str
    version: str
    summary: str
    description: str = ""
    acceptance_criteria: str = ""
    links: tuple[StoryLink, ...] = ()
    parent_key: str | None = None
    status: str = ""
    domain: str | None = None

    def fingerprint(self) -> str:
        """Hash the fields whose change means the story must be reprocessed.

        Covers summary, description, acceptance criteria, links (order-insensitive) and
        parent. Excludes ``status`` and ``version``.

        :return: Lowercase hex SHA-256
        """
        canonical = {
            "summary": self.summary.strip(),
            "description": self.description.strip(),
            "acceptance_criteria": self.acceptance_criteria.strip(),
            "links": sorted((link.link_type, link.target_key) for link in self.links),
            "parent_key": self.parent_key,
        }
        encoded = json.dumps(canonical, sort_keys=True, ensure_ascii=True).encode("ascii")
        return hashlib.sha256(encoded).hexdigest()


class Passage(DomainModel):
    """A searchable unit of text.

    ``parent_ref`` names what the passage belongs to: a clause reference text for clause
    parts, a story key for story passages, and so on. Split parts of one long clause share
    that parent and carry distinct ``part_index`` values. ``embedding`` and ``model_version``
    are set together or not at all.
    """

    passage_id: str
    passage_type: PassageType
    parent_ref: str
    source: SourceKind
    item_id: str
    version: str
    text: str
    tokens: Annotated[int, Field(ge=0)]
    domain: str | None = None
    edition_label: str | None = None
    page: Annotated[int, Field(ge=1)] | None = None
    char_start: Annotated[int, Field(ge=0)] | None = None
    char_end: Annotated[int, Field(ge=0)] | None = None
    part_index: Annotated[int, Field(ge=0)] | None = None
    embedding: tuple[float, ...] | None = None
    model_version: str | None = None

    @model_validator(mode="after")
    def _embedding_complete(self) -> Self:
        if (self.embedding is None) != (self.model_version is None):
            raise ValueError("embedding and model_version must be set together")
        if self.embedding is not None and len(self.embedding) != EMBEDDING_DIMENSIONS:
            raise ValueError(f"embedding must have {EMBEDDING_DIMENSIONS} values")
        return self
