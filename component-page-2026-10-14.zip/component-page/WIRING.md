# Wiring the component page

`install.py` adds the new page as a self-contained folder,
`frontend/src/features/recsys/component-page/`. Nothing in the app uses it yet. Wiring is one
edit to the existing component page plus a small mapping function. It is kept by hand because
the field names of the registry detail response are only known on the workstation.

`python3 install.py --inspect` prints what you need for this: the current page file, its imports
and queries, and the detail and relation types.

## 1. Map the registry detail to the page model

The layout takes one prop, `model: ComponentPageModel` (see `model.ts`). Add a `toPageModel`
next to the current page. The names on the right are guesses, so use the real ones from the
detail type:

```ts
import { EMPTY_SOURCE, withDemoSample } from '@/features/recsys/component-page'
import type { ComponentPageModel, RelationGroup } from '@/features/recsys/component-page'

function group(items: RelatedLike[] | undefined, withheld: number | undefined): RelationGroup {
  return {
    items: (items ?? []).map((item) => ({
      id: item.component_id,
      name: item.name ?? item.component_id,
      type: item.component_type ?? null,
      summary: item.summary ?? null, // the registry summary, when the response carries it
    })),
    withheld: withheld ?? 0,
  }
}

export function toPageModel(detail: ComponentDetail, demo: boolean): ComponentPageModel {
  const model: ComponentPageModel = {
    id: detail.component_id,
    type: detail.component_type,
    name: detail.name,
    description: detail.description ?? null,
    version: detail.version ?? null,
    nativeBinding: detail.native_binding ?? null,
    tenants: detail.tenants ?? [],
    eligible: detail.eligible,
    qualityFlags: detail.quality_flags ?? [],
    triggers: detail.triggers ?? [],
    tools: detail.tools ?? [],
    tags: detail.tags ?? [],
    // Null until the catalogue carries the .md; the page then shows the description instead.
    definition: detail.definition_markdown
      ? { markdown: detail.definition_markdown, path: detail.definition_path ?? null }
      : null,
    source: {
      ...EMPTY_SOURCE,
      source: detail.source ?? null,
      sourceReference: detail.source_reference ?? null,
      externalIds: Object.entries(detail.external_ids ?? {}).map(([k, v]) => [k, String(v)]),
      catalogueVersion: detail.catalogue_version ?? null,
      // Provenance fields, once the API returns them:
      // originSystem, environment, path, revision, lastSynced, syncTrigger, pulledBy, url
    },
    relations: {
      usedBy: group(detail.used_by, detail.used_by_withheld),
      uses: group(detail.uses, detail.uses_withheld),
      dependsOn: group(detail.depends_on, detail.depends_on_withheld),
    },
  }
  return demo ? withDemoSample(model) : model
}
```

- `demo` is true when the page runs on the mock API (demo mode). In demo mode,
  `withDemoSample` adds the full definition and provenance to the alpha, epsilon and delta
  fixtures, so the whole page can be shown. In live mode it is never applied.
- If `@/` is not an alias in this repo, use a relative import of `../component-page`.

## 2. Replace the page body

Keep the current page's route, data loading, loading state and error state. Replace only the
JSX that renders a loaded component:

```tsx
import { ComponentDetailLayout } from '@/features/recsys/component-page'

const from = (location.state as { from?: string } | null)?.from
return (
  <ComponentDetailLayout
    model={toPageModel(detail, demo)}
    backTo={from ?? '/registry'}
    recommendTo={'/recommend?objective=' + encodeURIComponent(detail.description ?? detail.name)}
  />
)
```

- `backTo` keeps the current behaviour: back to the exact filtered registry view the reader came
  from. The cards already pass `state.from`.
- `recommendTo` should be the Recommend page with the need prefilled. Use the route and query
  parameter that page reads. If it has none, pass `onRecommend` with a `navigate(...)` call
  instead, or leave both out: the button is then hidden.
- Every link opens in the same tab.
- The layout switches at 900 px: two columns with tiles above, or one column below.

## 3. What the page needs from the backend (not in this bundle)

The page works with today's API. The parts below show once the API returns them:

- `definition_markdown` (and its path): the full SKILL.md, agent or MCP server .md.
- Provenance: origin system, environment, file path, revision, last sync time and trigger,
  "pulled by" and a link to the file.
- Ingestion: pull from the skills repository with the service account, and refresh from
  GitHub Actions on a push to that repository. From the GroupAI platform, ingest Prod only,
  so nothing untested is recommended.

The page already enforces the last rule: the "Recommend" action is shown only for an eligible
component that is either from a source without environments or from Prod. A component from any
other environment gets a warning instead.

## 4. Checks

`install.py` runs none of them. When you decide to:

```sh
cd frontend
npx eslint src/features/recsys/component-page
npx tsc --noEmit -p .
npx vitest run src/features/recsys/component-page
```

The four test files cover the Markdown reader (including unsafe links and HTML shown as text),
the viewer (toggle, On this page, Copy), the source card, and both layouts.
