"""Week 3, "agent access and write-back": one story goes end to end to a reviewed spec,
and a user without access is refused."""

from __future__ import annotations

import itertools
from datetime import date

from pydantic import JsonValue
from sqlalchemy import func, select

from kp.app import Application
from kp.clock import FixedClock
from kp.demo.build import BuildRun
from kp.demo.model import Check, LineResult
from kp.demo.week3_review import evaluate_review
from kp.domain import Story, ToolCallRecord
from kp.mcp import ErrorCode, McpServer
from kp.store import schema
from kp.tools import AuditStore, Caller, IdentityMapping, build_caller
from kp.writeback import (
    SPEC_DRAFTED_STATUS,
    DraftSpecReport,
    TemplateRepository,
    draft_spec,
    extract_references,
    load_story,
)

SPEC_TYPE = "functional"
FULL_ACCESS = "user-full-access"
ONE_DOMAIN = "user-one-domain"
NO_ACCESS = "user-no-access"
NO_PAYMENTS = "user-no-payments-access"
ALLOWED_DOMAIN = "payments"
OTHER_REPOSITORY = "other-owner/other-repository"
_ids = itertools.count(1)


def evaluate_week3(application: Application, build: BuildRun, clock: FixedClock) -> LineResult:
    """Judge the week 3 line.

    :param application: The application the build ran on
    :param build: What the build phases returned
    :param clock: The demo's clock; the review steps move it forward day by day
    :return: The line with its checks
    """
    day = application.clock.today()
    stories = _stories(application)
    first, second = _pick_stories(application, stories, day)
    report = draft_spec(
        first.story_key,
        runtime=application.draft_runtime(),
        publish=True,
        spec_type=SPEC_TYPE,
        as_at=day,
    )
    again = draft_spec(
        first.story_key,
        runtime=application.draft_runtime(),
        publish=True,
        spec_type=SPEC_TYPE,
        as_at=day,
    )
    directory = application.identity_mapping()
    checks = (
        *_end_to_end(application, build, report, again),
        *_agent_path(application, directory, second, day),
        *_access(application, directory),
        # Last, because it moves the clock: a person merges and edits on later days.
        *evaluate_review(application, clock, report),
    )
    return LineResult("W3", checks)


def _stories(application: Application) -> list[Story]:
    with application.database.transaction() as connection:
        keys = sorted(set(connection.execute(select(schema.story.c.story_key)).scalars()))
        return [load_story(connection, key) for key in keys]


def _pick_stories(application: Application, stories: list[Story], day: date) -> tuple[Story, Story]:
    """The payments stories whose drafts have the fewest uncited statements, best first.

    The first goes through the reference client, the second through the agent servers. A story
    that already has a merged spec is not drafted, so it is not a candidate.
    """
    runtime = application.draft_runtime()
    drafts = (
        (story, draft_spec(story.story_key, runtime=runtime, spec_type=SPEC_TYPE, as_at=day))
        for story in stories
        if story.domain == ALLOWED_DOMAIN and "clause" in story.description.casefold()
    )
    ranked = sorted(
        ((draft.flagged, story.story_key, story) for story, draft in drafts if not draft.skipped),
        key=lambda entry: entry[:2],
    )
    return ranked[0][2], ranked[1][2]


def _unretrieved(application: Application, spec_id: str) -> int:
    """Cited statements whose citation was not retrieved in the session that published them."""
    with application.database.transaction() as connection:
        return connection.execute(
            select(func.count())
            .select_from(schema.citation)
            .where(
                schema.citation.c.spec_id == spec_id,
                schema.citation.c.reference.is_not(None),
                schema.citation.c.retrieved_in_session.is_(False),
            )
        ).scalar_one()


def _end_to_end(
    application: Application, build: BuildRun, report: DraftSpecReport, again: DraftSpecReport
) -> tuple[Check, ...]:
    published = report.published
    repeated = again.published
    jira = report.jira
    if published is None or repeated is None:
        return (Check("Story drafted and published as a pull request", False, "not published"),)
    with application.database.transaction() as connection:
        spec = connection.execute(
            select(schema.spec).where(schema.spec.c.story_key == report.story_key)
        ).first()
        citations = connection.execute(
            select(func.count())
            .select_from(schema.citation)
            .where(schema.citation.c.spec_id == published.spec_id)
        ).scalar_one()
    recorded = spec is not None and spec.pr_identity == published.pr_url and spec.machine_authored
    return (
        Check(
            "One story goes end to end to a drafted spec published as a pull request",
            bool(published.pr_url) and published.pr_created and recorded and citations > 0,
            f"story {report.story_key}: spec {published.spec_id} on branch {published.branch}, "
            f"pull request record {published.pr_url} ({build.publisher.value} publisher), "
            f"template {published.template_id} v{published.template_version}, "
            f"machine-authored, {citations} citation rows stored",
        ),
        Check(
            "Citations: every rule statement cites retrieved, resolvable material",
            published.flagged == 0 and published.meets_target and published.rule_statements > 0,
            f"{published.valid_citations} of {published.rule_statements} rule statements valid, "
            f"citation rate {published.citation_rate:.0%} against {published.citation_target:.0%}, "
            f"{published.flagged} flagged",
        ),
        Check(
            "Publishing the same draft twice opens no second pull request",
            not repeated.pr_created and repeated.pr_url == published.pr_url,
            f"second publish: pull request {repeated.pr_url}, newly created: {repeated.pr_created}",
        ),
        Check(
            "The Jira story moves to 'Spec drafted' and links the pull request, nothing else",
            jira is not None
            and jira.status == SPEC_DRAFTED_STATUS
            and jira.link == published.pr_url,
            f"update on {report.story_key}: status {jira.status if jira else '-'}, "
            f"link field {jira.link_field if jira else '-'}, "
            f"dry run: {jira.dry_run if jira else '-'}",
        ),
    )


def _rpc(
    server: McpServer, caller: Caller, name: str, arguments: dict[str, JsonValue]
) -> dict[str, JsonValue]:
    """Call one tool the way an agent does, over the server's JSON-RPC interface."""
    message: dict[str, JsonValue] = {
        "jsonrpc": "2.0",
        "id": next(_ids),
        "method": "tools/call",
        "params": {"name": name, "arguments": arguments},
    }
    response = server.handle(message, caller)
    return response or {}


def _error(response: dict[str, JsonValue]) -> tuple[int | None, str]:
    error = response.get("error")
    if not isinstance(error, dict):
        return None, ""
    code = error.get("code")
    return (code if isinstance(code, int) else None), str(error.get("message", ""))


def _result(response: dict[str, JsonValue]) -> dict[str, JsonValue]:
    result = response.get("result")
    if isinstance(result, dict) and isinstance(result.get("structuredContent"), dict):
        return result["structuredContent"]  # type: ignore[return-value]  # narrowed above
    return {}


def _agent_path(
    application: Application, directory: IdentityMapping, story: Story, day: date
) -> tuple[Check, ...]:
    read = application.read_server(directory)
    write = application.write_server(directory)
    with application.database.transaction() as connection:
        template = TemplateRepository(connection).latest(SPEC_TYPE)
    markdown = draft_spec(
        story.story_key, runtime=application.draft_runtime(), spec_type=SPEC_TYPE, as_at=day
    ).markdown
    arguments: dict[str, JsonValue] = {
        "story_key": story.story_key,
        "spec_markdown": markdown,
        "template_id": template.template_id,
        "template_version": template.version,
    }
    blind = build_caller(user=FULL_ACCESS, agent="demo-agent", session_id="demo-blind-session")
    unread = _result(_rpc(write, blind, "publish_spec", arguments))
    spec_id = str(unread.get("spec_id", ""))
    not_retrieved = _unretrieved(application, spec_id)
    seeing = build_caller(user=FULL_ACCESS, agent="demo-agent", session_id="demo-reading-session")
    _rpc(read, seeing, "search", {"query": story.summary, "as_at": day.isoformat()})
    for number in _cited_numbers(markdown):
        _rpc(read, seeing, "rule_as_at", {"number": number, "as_at": day.isoformat()})
    _rpc(read, seeing, "template", {"spec_type": SPEC_TYPE})
    informed = _result(_rpc(write, seeing, "publish_spec", arguments))
    still_not_retrieved = _unretrieved(application, spec_id)
    elsewhere = _rpc(write, seeing, "publish_spec", {**arguments, "repository": OTHER_REPOSITORY})
    code, _ = _error(elsewhere)
    with application.database.transaction() as connection:
        calls = AuditStore(connection).list_for_session(seeing.session_id)
    refused = [call for call in calls if call.refused]
    return (
        Check(
            "The agent path (read server, then write server) cites what it retrieved",
            not_retrieved > 0 and still_not_retrieved == 0 and _statements(informed) > 0,
            f"story {story.story_key}: published from a session that read nothing, "
            f"{not_retrieved} cited statements are flagged as not retrieved in the session; "
            f"after reading the rules through the read server, {still_not_retrieved} are "
            f"({_statements(informed)} rule statements checked)",
        ),
        Check(
            "Writes only go where agreed: another repository is refused and recorded",
            code == ErrorCode.WRITE_NOT_PERMITTED and len(refused) == 1,
            f"request for another repository answered with code {code}; "
            f"{len(refused)} refusal record(s) in the session's audit trail "
            f"({len(calls)} calls recorded)",
        ),
    )


def _cited_numbers(markdown: str) -> list[str]:
    numbers = []
    for reference in extract_references(markdown):
        _, _, number = reference.partition(":")
        if number and number not in numbers:
            numbers.append(number)
    return numbers


def _statements(payload: dict[str, JsonValue]) -> int:
    value = payload.get("rule_statements")
    return value if isinstance(value, int) else 0


def _access(application: Application, directory: IdentityMapping) -> tuple[Check, ...]:
    read = application.read_server(directory)
    question = "which currency may an inbound credit transfer use?"
    nothing = build_caller(user=NO_ACCESS, agent="demo-agent", session_id="demo-no-access")
    refused_code, refused_message = _error(_rpc(read, nothing, "search", {"query": question}))
    partial = build_caller(user=NO_PAYMENTS, agent="demo-agent", session_id="demo-no-payments")
    partial_response = _rpc(read, partial, "search", {"query": question})
    partial_code, _ = _error(partial_response)
    partial_payload = _result(partial_response)
    one = build_caller(user=ONE_DOMAIN, agent="demo-agent", session_id="demo-one-domain")
    one_payload = _result(_rpc(read, one, "search", {"query": "card status"}))
    payments_for_other = _domains_of(partial_payload) - {"cards"}
    with application.database.transaction() as connection:
        trail = AuditStore(connection)
        recorded = _refusals(trail.list_for_session(nothing.session_id))
        recorded_partial = trail.list_for_session(partial.session_id)
    hidden = partial_payload.get("filtered_out")
    return (
        Check(
            "A user without access is refused (forbidden, not an empty answer) and it is recorded",
            refused_code == ErrorCode.FORBIDDEN and recorded == 1,
            f"{NO_ACCESS} searching: code {refused_code} '{refused_message}'; "
            f"{recorded} refusal record(s) in the audit trail",
        ),
        Check(
            "A user without payments access never sees payments material",
            (partial_code == ErrorCode.FORBIDDEN or not payments_for_other)
            and len(recorded_partial) == 1,
            f"{NO_PAYMENTS} asking a payments question: "
            + (
                f"refused (code {partial_code})"
                if partial_code
                else f"hits only from {sorted(_domains_of(partial_payload)) or 'none'}, "
                f"{hidden} matches hidden"
            ),
        ),
        Check(
            "Domain always comes from the identity: partial access shows a filtered count",
            _domains_of(one_payload) <= {ALLOWED_DOMAIN}
            and isinstance(one_payload.get("filtered_out"), int),
            f"{ONE_DOMAIN} sees only {sorted(_domains_of(one_payload)) or 'no'} domain(s); "
            f"{one_payload.get('filtered_out')} matches hidden from the answer",
        ),
    )


def _domains_of(payload: dict[str, JsonValue]) -> set[str]:
    hits = payload.get("hits")
    domains: set[str] = set()
    if isinstance(hits, list):
        for hit in hits:
            if isinstance(hit, dict) and isinstance(hit.get("domain"), str):
                domains.add(str(hit["domain"]))
    return domains


def _refusals(records: list[ToolCallRecord]) -> int:
    return sum(1 for record in records if record.refused)
