"""Gateway client: JSON-RPC 2.0 ``tools/list`` and ``tools/call`` over HTTP.

The gateway is stateless between calls and selects the tool server from the route. Every call
carries two credentials in headers whose names are settings: the caller-identity token for
the gateway and a per-source credential the tool server combines with the platform service
account. The client answers JSON and Server-Sent-Events framing alike, renews the identity
token inside the call path, retries once with a forced renewal after a 401, and records every
exchange as a :class:`~kp.connectivity.models.CallObservation` holding only a digest of the
request.

The route layout (``<base>/<namespace>``), the ``_meta`` use-case marker and the result
framing follow the design as transcribed; the first live ``discover`` run confirms or corrects
them (open question Q2).
"""

from __future__ import annotations

import itertools
import json
import logging
import threading
import time
from collections.abc import Callable, Mapping
from typing import Protocol

import httpx
from pydantic import JsonValue, SecretStr

from kp.clock import Clock
from kp.connectivity.digest import request_digest
from kp.connectivity.errors import GatewayForbiddenError, GatewayProtocolError
from kp.connectivity.http_status import (
    FORBIDDEN,
    NOT_FOUND,
    OK_MAX,
    RATE_LIMITED,
    SERVER_ERROR,
    UNAUTHORIZED,
)
from kp.connectivity.models import (
    CallObservation,
    JsonObject,
    Route,
    ToolResult,
    ToolSignature,
)
from kp.connectivity.tokens import AccessToken, TokenProvider
from kp.domain import SourceKind
from kp.errors import SourceAuthRefusedError, SourceRateLimitedError, SourceUnavailableError

logger = logging.getLogger(__name__)

_DEFAULT_RETRY_AFTER = 1.0
_MAX_LIST_PAGES = 20
_FIELD_DEPTH = 2


class CallSink(Protocol):
    """Receives one observation per HTTP exchange with the gateway."""

    def record(self, observation: CallObservation) -> None:
        """Keep an observation.

        :param observation: What was observed about one exchange
        """
        ...


class DiscardingSink:
    """A sink that keeps nothing."""

    def record(self, observation: CallObservation) -> None:
        """Drop the observation.

        :param observation: Ignored
        """


class ToolListing:
    """The tools one server lists.

    :param signatures: The parsed signatures
    :param raw_tools: The tool objects exactly as the gateway returned them
    """

    def __init__(
        self, signatures: tuple[ToolSignature, ...], raw_tools: tuple[JsonObject, ...]
    ) -> None:
        self.signatures = signatures
        self.raw_tools = raw_tools


class GatewayClient:
    """JSON-RPC client for the gateway. Safe to share between threads.

    :param http: The HTTP client; its transport decides what is real
    :param base_url: The gateway base
    :param tokens: Source of the caller-identity token
    :param identity_header: Name of the header carrying the caller-identity token
    :param source_header: Name of the header carrying the per-source credential
    :param source_credentials: The per-source credential values
    :param clock: Time source for the call timestamps
    :param sink: Where call observations go
    :param use_case_id: The issued use-case identifier, sent in the request metadata
    :param sleep: Used to wait out a rate limit; injectable for tests
    :param max_rate_limit_waits: How many times to wait and retry after a 429
    """

    def __init__(
        self,
        *,
        http: httpx.Client,
        base_url: str,
        tokens: TokenProvider,
        identity_header: str,
        source_header: str | None,
        source_credentials: Mapping[SourceKind, SecretStr],
        clock: Clock,
        sink: CallSink | None = None,
        use_case_id: str | None = None,
        sleep: Callable[[float], None] = time.sleep,
        max_rate_limit_waits: int = 2,
    ) -> None:
        self._http = http
        self._base_url = base_url.rstrip("/")
        self._tokens = tokens
        self._identity_header = identity_header
        self._source_header = source_header
        self._source_credentials = dict(source_credentials)
        self._clock = clock
        self._sink: CallSink = sink if sink is not None else DiscardingSink()
        self._use_case_id = use_case_id
        self._sleep = sleep
        self._max_rate_limit_waits = max_rate_limit_waits
        self._request_ids = itertools.count(1)
        self._id_lock = threading.Lock()

    def list_tools(self, route: Route) -> ToolListing:
        """List the tools of one server, following pagination.

        :param route: Which server
        :return: The signatures and the raw tool objects
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after one renewal
        :raises kp.errors.SourceRateLimitedError: If the rate limit outlasts the retries
        :raises kp.errors.SourceUnavailableError: If the gateway cannot be reached
        :raises kp.connectivity.errors.GatewayForbiddenError: If the group does not allow the call
        :raises kp.connectivity.errors.GatewayProtocolError: If the answer is not usable
        """
        raw_tools: list[JsonObject] = []
        cursor: str | None = None
        for _ in range(_MAX_LIST_PAGES):
            params: JsonObject = {} if cursor is None else {"cursor": cursor}
            result = self._rpc(route, "tools/list", params, tool_label="*")
            tools = result.get("tools")
            if not isinstance(tools, list):
                raise GatewayProtocolError("tools/list answered without a tools array")
            raw_tools.extend(tool for tool in tools if isinstance(tool, dict))
            next_cursor = result.get("nextCursor")
            if not isinstance(next_cursor, str) or not next_cursor:
                break
            cursor = next_cursor
        signatures = tuple(signature_from_tool(route.namespace, tool) for tool in raw_tools)
        return ToolListing(signatures, tuple(raw_tools))

    def call_tool(self, route: Route, name: str, arguments: JsonObject) -> ToolResult:
        """Call one tool.

        :param route: Which server
        :param name: The tool name as listed by the server
        :param arguments: The tool arguments
        :return: The parsed result; check ``is_error`` and ``structured``
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after one renewal
        :raises kp.errors.SourceRateLimitedError: If the rate limit outlasts the retries
        :raises kp.errors.SourceUnavailableError: If the gateway cannot be reached
        :raises kp.connectivity.errors.GatewayForbiddenError: If the group does not allow the call
        :raises kp.connectivity.errors.GatewayProtocolError: If the answer is not usable
        """
        result = self._rpc(route, "tools/call", {"name": name, "arguments": arguments}, name)
        return parse_tool_result(result)

    def _next_id(self) -> int:
        with self._id_lock:
            return next(self._request_ids)

    def _rpc(self, route: Route, method: str, params: JsonObject, tool_label: str) -> JsonObject:
        digest = request_digest(route.namespace, method, params)
        label = f"{route.namespace}/{tool_label}"
        grant = self._tokens.acquire()
        forced = False
        rate_limit_waits = 0
        while True:
            request_id = self._next_id()
            started = time.perf_counter()
            status: int | None = None
            error_class: str | None = None
            result: JsonObject = {}
            retry_after = _DEFAULT_RETRY_AFTER
            outcome: Exception | None = None
            try:
                response = self._post(route, method, params, request_id, grant.token)
                status = response.status_code
                retry_after = _retry_after(response)
                result = self._interpret(response, request_id)
            except (
                SourceAuthRefusedError,
                SourceRateLimitedError,
                SourceUnavailableError,
                GatewayForbiddenError,
                GatewayProtocolError,
            ) as exc:
                error_class = type(exc).__name__
                outcome = exc
            self._sink.record(
                self._observation(
                    label, method, digest, status, error_class, result, started, grant.refreshed
                )
            )
            if outcome is None:
                return result
            if isinstance(outcome, SourceAuthRefusedError) and not forced:
                forced = True
                grant = self._tokens.force_refresh(grant.token)
                continue
            if (
                isinstance(outcome, SourceRateLimitedError)
                and rate_limit_waits < self._max_rate_limit_waits
            ):
                rate_limit_waits += 1
                self._sleep(retry_after)
                grant = self._tokens.acquire()
                continue
            raise outcome

    def _post(
        self, route: Route, method: str, params: JsonObject, request_id: int, token: AccessToken
    ) -> httpx.Response:
        body: JsonObject = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": self._with_meta(params),
        }
        try:
            return self._http.post(
                f"{self._base_url}/{route.namespace}",
                content=json.dumps(body).encode("utf-8"),
                headers=self._headers(route, token),
            )
        except httpx.HTTPError as exc:
            raise SourceUnavailableError("Gateway could not be reached") from exc

    def _with_meta(self, params: JsonObject) -> JsonObject:
        if self._use_case_id is None:
            return params
        return {**params, "_meta": {"useCaseId": self._use_case_id}}

    def _headers(self, route: Route, token: AccessToken) -> dict[str, str]:
        value = token.value.get_secret_value()
        if self._identity_header.lower() == "authorization":
            value = f"Bearer {value}"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            self._identity_header: value,
        }
        credential = self._source_credentials.get(route.source)
        if self._source_header is not None and credential is not None:
            headers[self._source_header] = credential.get_secret_value()
        return headers

    def _interpret(self, response: httpx.Response, request_id: int) -> JsonObject:
        status = response.status_code
        if status == UNAUTHORIZED:
            raise SourceAuthRefusedError("Gateway refused the caller credential")
        if status == FORBIDDEN:
            raise GatewayForbiddenError("Caller is not entitled to this tool route")
        if status == RATE_LIMITED:
            raise SourceRateLimitedError(_retry_after(response))
        if status >= SERVER_ERROR:
            raise SourceUnavailableError("Gateway failed")
        if status == NOT_FOUND:
            raise GatewayProtocolError("Gateway has no such tool route")
        if status > OK_MAX:
            raise GatewayProtocolError(f"Gateway answered with status {status}")
        message = _rpc_message(response, request_id)
        error = message.get("error")
        if isinstance(error, dict):
            code = error.get("code")
            raise GatewayProtocolError(
                "Gateway returned a JSON-RPC error",
                code if isinstance(code, int) else None,
            )
        result = message.get("result")
        if not isinstance(result, dict):
            raise GatewayProtocolError("Gateway answered without a result object")
        return result

    def _observation(
        self,
        label: str,
        method: str,
        digest: str,
        status: int | None,
        error_class: str | None,
        result: JsonObject,
        started: float,
        refreshed: bool,
    ) -> CallObservation:
        latency_ms = (time.perf_counter() - started) * 1000.0
        object_count, truncated, fields = _describe(method, result)
        if error_class is None and method == "tools/call" and result.get("isError") is True:
            error_class = "ToolError"
        observation = CallObservation(
            tool=label,
            operation=method,
            request_digest=digest,
            http_status=status,
            error_class=error_class,
            object_count=object_count,
            truncated=truncated,
            latency_ms=latency_ms,
            token_refreshed=refreshed,
            surviving_fields=fields,
            called_at=self._clock.now(),
        )
        logger.info(
            "Gateway call finished",
            extra={
                "tool": label,
                "operation": method,
                "http_status": status,
                "error_class": error_class,
                "latency_ms": round(latency_ms, 1),
                "renewed": refreshed,
            },
        )
        return observation


def parse_tool_result(result: JsonObject) -> ToolResult:
    """Turn a ``tools/call`` result into a :class:`ToolResult`.

    An object is taken from ``structuredContent`` or from a single text part that holds a JSON
    object. Anything else is prose and leaves ``structured`` empty.

    :param result: The JSON-RPC ``result`` member
    :return: The parsed result
    """
    is_error = result.get("isError") is True
    structured = result.get("structuredContent")
    texts = _text_parts(result.get("content"))
    text = "\n".join(texts)
    if isinstance(structured, dict):
        return ToolResult(structured=structured, text=text, is_error=is_error)
    if len(texts) == 1:
        try:
            decoded = json.loads(texts[0])
        except ValueError:
            decoded = None
        if isinstance(decoded, dict):
            return ToolResult(structured=decoded, text=text, is_error=is_error)
    return ToolResult(structured=None, text=text, is_error=is_error)


def flatten_fields(value: JsonObject, depth: int = _FIELD_DEPTH) -> tuple[str, ...]:
    """List the field names present in an object, as dotted paths to a limited depth.

    :param value: The object to describe
    :param depth: How many levels of nesting to name
    :return: Sorted dotted names such as ``fields.summary``
    """
    names: set[str] = set()

    def walk(node: JsonObject, prefix: str, remaining: int) -> None:
        for key, child in node.items():
            path = f"{prefix}{key}"
            names.add(path)
            if isinstance(child, dict) and remaining > 1:
                walk(child, f"{path}.", remaining - 1)

    walk(value, "", depth)
    return tuple(sorted(names))


def _text_parts(content: JsonValue | None) -> list[str]:
    if not isinstance(content, list):
        return []
    parts: list[str] = []
    for part in content:
        if isinstance(part, dict) and part.get("type") == "text":
            text = part.get("text")
            if isinstance(text, str):
                parts.append(text)
    return parts


def _describe(method: str, result: JsonObject) -> tuple[int, bool, tuple[str, ...]]:
    if not result:
        return 0, False, ()
    if method == "tools/list":
        tools = result.get("tools")
        names = (
            [tool for tool in tools if isinstance(tool, dict)] if isinstance(tools, list) else []
        )
        fields = sorted({key for tool in names for key in tool})
        return len(names), bool(result.get("nextCursor")), tuple(fields)
    parsed = parse_tool_result(result)
    if parsed.structured is None:
        return 0, False, ()
    return 1, parsed.structured.get("truncated") is True, flatten_fields(parsed.structured)


def signature_from_tool(namespace: str, tool: JsonObject) -> ToolSignature:
    """Parse one listed tool.

    :param namespace: The server's route
    :param tool: The tool object as returned
    :return: Its signature
    :raises kp.connectivity.errors.GatewayProtocolError: If the tool has no name
    """
    name = tool.get("name")
    if not isinstance(name, str) or not name:
        raise GatewayProtocolError("tools/list returned a tool without a name")
    description = tool.get("description")
    schema = tool.get("inputSchema")
    return ToolSignature(
        namespace=namespace,
        name=name,
        description=description if isinstance(description, str) else "",
        input_schema=schema if isinstance(schema, dict) else {},
    )


def _retry_after(response: httpx.Response) -> float:
    raw = response.headers.get("retry-after")
    try:
        return max(0.0, float(raw)) if raw is not None else _DEFAULT_RETRY_AFTER
    except ValueError:
        return _DEFAULT_RETRY_AFTER


def _rpc_message(response: httpx.Response, request_id: int) -> JsonObject:
    content_type = response.headers.get("content-type", "")
    try:
        if "text/event-stream" in content_type:
            return _sse_message(response.text, request_id)
        decoded = response.json()
    except ValueError as exc:
        raise GatewayProtocolError("Gateway answered with malformed JSON") from exc
    if not isinstance(decoded, dict):
        raise GatewayProtocolError("Gateway answered with something other than a JSON-RPC object")
    return decoded


def _sse_message(body: str, request_id: int) -> JsonObject:
    for block in body.replace("\r\n", "\n").split("\n\n"):
        data = "\n".join(
            line.removeprefix("data:").removeprefix(" ")
            for line in block.split("\n")
            if line.startswith("data:")
        )
        if not data:
            continue
        message = json.loads(data)
        if isinstance(message, dict) and message.get("id") == request_id:
            return message
    raise GatewayProtocolError("Event stream ended without the response to the request")
