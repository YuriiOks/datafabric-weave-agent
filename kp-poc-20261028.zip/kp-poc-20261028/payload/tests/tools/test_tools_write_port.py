"""The write side: tools provided through a port get identity, access and audit from this layer."""

from __future__ import annotations

import pytest
from tools_fixtures import *  # noqa: F403 - pytest fixtures

from kp.errors import AccessForbiddenError, WriteNotPermittedError
from kp.tools import (
    IdentityMapping,
    InvalidToolArgumentsError,
    UnknownToolError,
    build_caller,
    build_write_registry,
)
from kp.tools.testing import FakeWritePort, InMemoryAudit


def test_us22_write_registry_serves_only_the_tools_the_port_describes(
    mapping: IdentityMapping, audit: InMemoryAudit
) -> None:
    registry = build_write_registry(FakeWritePort(), mapping, audit)

    assert [d.name for d in registry.definitions()] == ["publish_spec"]
    caller = build_caller(user="user-full-access", agent="a", session_id="s")
    with pytest.raises(UnknownToolError):
        registry.call(caller, "search", {"query": "x"})


def test_us22_identity_and_domains_reach_the_port_from_the_server_not_the_arguments(
    mapping: IdentityMapping, audit: InMemoryAudit
) -> None:
    port = FakeWritePort()
    registry = build_write_registry(port, mapping, audit)
    caller = build_caller(user="user-one-domain", agent="spec-agent", session_id="sess")

    result = registry.call(caller, "publish_spec", {"spec_id": "s1", "path": "specs/s1.md"})

    (call,) = port.calls
    assert (call.caller, call.agent, call.session_id) == ("user-one-domain", "spec-agent", "sess")
    assert call.domains == ("payments",)
    assert result.payload == {"branch": "spec/s1"}
    assert audit.records[0].spec_id == "s1"
    assert audit.records[0].items_returned == 1


def test_us22_a_write_outside_the_agreed_place_is_refused_and_recorded(
    mapping: IdentityMapping, audit: InMemoryAudit
) -> None:
    registry = build_write_registry(FakeWritePort(), mapping, audit)
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")

    with pytest.raises(WriteNotPermittedError):
        registry.call(caller, "publish_spec", {"spec_id": "s1", "path": "../elsewhere.md"})

    assert audit.records[0].refused is True
    assert audit.records[0].request == {"spec_id": "s1", "path": "../elsewhere.md"}


def test_us22_malformed_write_arguments_are_invalid_params(
    mapping: IdentityMapping, audit: InMemoryAudit
) -> None:
    registry = build_write_registry(FakeWritePort(), mapping, audit)
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")

    with pytest.raises(InvalidToolArgumentsError):
        registry.call(caller, "publish_spec", {"spec_id": 5})


def test_us22_a_caller_without_access_never_reaches_the_write_port(
    mapping: IdentityMapping, audit: InMemoryAudit
) -> None:
    port = FakeWritePort()
    registry = build_write_registry(port, mapping, audit)
    caller = build_caller(user="user-no-access", agent="spec-agent", session_id="s")

    with pytest.raises(AccessForbiddenError):
        registry.call(caller, "publish_spec", {"spec_id": "s1", "path": "specs/s1.md"})

    assert port.calls == []
    assert audit.records[0].refused is True
