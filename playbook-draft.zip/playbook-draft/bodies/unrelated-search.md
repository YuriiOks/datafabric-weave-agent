## What changed

- A search that describes no need, such as "test search query" or a plan for a team picnic, now gets no reusable-component suggestions. The run ends before anything is assessed, and the panel says "Nothing to suggest for this search" with a hint to reword it as a task. Real searches keep their current results.
- The decision is made in two steps. If even the closest catalogue component is far from the search, the run stops without a model call. If the search is borderline, one short model call reads the original search text and decides whether it describes a need. A search that is clearly close to the catalogue is not checked at all. If the check cannot be answered, the run goes on as before.
- When the live recommender cannot be reached, the reusable-components panel says the components are not available right now instead of showing sample suggestions. Sample data still appears when demo mode is switched on on purpose.

## Why

A placeholder search produced a fluent need description, and the scores computed from that description could not tell it from a real need, so the panel offered components for it. Where the recommender was unreachable, the panel also showed sample suggestions that read as answers to the search.

## How to verify

1. Unit tests: `tests/recsys/pipeline/test_relevance.py` (the decision, plus a service run with the check on and one with the model off); frontend `SearchComponentsPanel.test.tsx` and `EmptyResult.test.tsx`.
2. Search "test search query" with the live recommender: no suggestions, no near misses, and the message to reword. The run's empty reason is `no_relevant_need`.
3. Search a real objective such as triaging inbound support tickets: the same suggestions as before.
4. Negative case: with `RECSYS_LLM_MODE=off` the check never runs, because the embeddings are placeholders and there is no model to ask, so the existing demonstration behaves as before.
5. Open the home page where the recommender is not reachable and demo mode is off: the panel says reusable components are not available right now and shows no sample cards.

## Review focus

- The check reads the caller's own text, never the model-written summary, because that summary is what turned placeholders into plausible needs.
- The two thresholds are settings (`RECSYS_RELEVANCE_FLOOR`, default 0.2, and `RECSYS_RELEVANCE_CLEAR`, default 0.55, both cosine). They are first estimates and need tuning against real searches.
- Only candidates the vector signal actually scored count as distance. A candidate without an embedding scores exactly zero, so a catalogue without embeddings sends the decision to the model instead of rejecting every search.
- The prompt version moves to 2 because a prompt was added, so cached assessments from version 1 are not reused. The two tests that pin the version, and the contract test that lists the empty reasons, are updated with it.
- A card is curated playbook text, so card input is never checked.
- The playbook side of the same report is not part of this change.
