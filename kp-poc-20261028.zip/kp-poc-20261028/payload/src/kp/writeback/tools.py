"""The write tools as typed functions, for the write MCP server to expose.

:class:`WriteTools` is the whole write surface: ``publish_spec`` and ``update_jira`` as typed
methods, plus ``describe`` / ``invoke`` for a transport that dispatches by tool name. Every
call is audited, refusals included, and a refusal is raised after it has been recorded.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from collections.abc import Callable
from typing import TypeVar

from pydantic import BaseModel, JsonValue

from kp.clock import Clock, SystemClock
from kp.domain import ToolCallRecord
from kp.errors import WriteNotPermittedError
from kp.writeback.limits import require_story_key, spec_id_for_story
from kp.writeback.models import (
    CallContext,
    PublishSpecArguments,
    PublishSpecResult,
    UpdateJiraArguments,
    UpdateJiraResult,
)
from kp.writeback.ports import (
    AuditSink,
    SessionRetrievals,
    WriteToolCall,
    WriteToolDescriptor,
    WriteToolResult,
)
from kp.writeback.service import JiraSyncService, SpecPublishingService

logger = logging.getLogger(__name__)

PUBLISH_SPEC = "publish_spec"
UPDATE_JIRA = "update_jira"
_MAX_KEY = 255
_MILLISECONDS = 1000.0

_Result = TypeVar("_Result")

_DESCRIPTIONS = {
    PUBLISH_SPEC: (
        "Publish a drafted spec as a pull request on its own branch. The repository, path and "
        "branch are fixed by the server; the commit is machine-authored; publishing the same "
        "story again updates the same pull request. Rule statements without a valid citation "
        "to material retrieved in this session are flagged in the pull request."
    ),
    UPDATE_JIRA: (
        "Move the story of a published spec to 'Spec drafted' and set the pull request link. "
        "No other Jira field is touched. Safe to repeat; never creates a pull request."
    ),
}
_ARGUMENT_MODELS: dict[str, type[BaseModel]] = {
    PUBLISH_SPEC: PublishSpecArguments,
    UPDATE_JIRA: UpdateJiraArguments,
}


def _digest(request: dict[str, JsonValue]) -> str:
    canonical = json.dumps(request, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("ascii")).hexdigest()


class WriteTools:
    """The ``publish_spec`` and ``update_jira`` tools.

    :param publishing: Publishes specs within the write limits
    :param jira: Updates the Jira story of a published spec
    :param retrievals: What each session retrieved through the read tools
    :param audit: Where call records go; ``None`` when the transport already audits
    :param clock: Time source
    """

    def __init__(
        self,
        *,
        publishing: SpecPublishingService,
        jira: JiraSyncService,
        retrievals: SessionRetrievals,
        audit: AuditSink | None = None,
        clock: Clock | None = None,
    ) -> None:
        self._publishing = publishing
        self._jira = jira
        self._retrievals = retrievals
        self._audit = audit
        self._clock = clock or SystemClock()

    def publish_spec(
        self, context: CallContext, arguments: PublishSpecArguments
    ) -> PublishSpecResult:
        """Publish a drafted spec as a pull request.

        :param context: Caller, agent and session from the transport
        :param arguments: The agent's arguments
        :return: The pull request and the citation check
        :raises kp.errors.WriteNotPermittedError: If another repository, path or branch was
            requested, or the story is in a domain the caller may not read; the refusal is
            recorded first
        :raises Exception: For any other failure; recorded too, then raised unchanged
        """

        def run() -> PublishSpecResult:
            outcome = self._publishing.publish(
                arguments,
                retrieved=self._retrievals.references(context.session_id, context.caller),
                domains=frozenset(context.domains),
            )
            report, result, spec = outcome.report, outcome.result, outcome.spec
            return PublishSpecResult(
                spec_id=spec.spec_id,
                story_key=spec.story_key,
                branch=spec.branch,
                path=spec.path,
                pr_url=result.pr_url,
                pr_created=result.created,
                committed=result.committed,
                commit_sha=result.commit_sha,
                template_id=spec.template_id,
                template_version=spec.template_version,
                rule_statements=report.rule_statements,
                valid_citations=report.valid_statements,
                flagged=len(report.flagged),
                citation_rate=report.rate,
                citation_target=report.target,
                meets_target=report.meets_target,
            )

        return self._audited(context, PUBLISH_SPEC, arguments, arguments.story_key, run)

    def update_jira(self, context: CallContext, arguments: UpdateJiraArguments) -> UpdateJiraResult:
        """Move the story of a published spec to "Spec drafted" and link the pull request.

        :param context: Caller, agent and session from the transport
        :param arguments: The agent's arguments
        :return: What was written and after how many tries
        :raises kp.errors.WriteNotPermittedError: If another field or value was requested, or
            the story is in a domain the caller may not read; the refusal is recorded first
        :raises Exception: For any other failure; recorded too, then raised unchanged
        """

        def run() -> UpdateJiraResult:
            outcome = self._jira.update(arguments, domains=frozenset(context.domains))
            return UpdateJiraResult(
                spec_id=outcome.spec_id,
                story_key=outcome.update.story_key,
                status=outcome.update.status,
                link_field=outcome.update.link_field,
                link=outcome.update.link_value,
                status_changed=outcome.applied.status_changed,
                link_set=outcome.applied.link_set,
                dry_run=outcome.applied.dry_run,
                attempts=outcome.attempts,
            )

        return self._audited(context, UPDATE_JIRA, arguments, arguments.story_key, run)

    def describe(self) -> tuple[WriteToolDescriptor, ...]:
        """List the tools with their JSON input schemas.

        :return: One descriptor per tool
        """
        return tuple(
            WriteToolDescriptor(
                name=name,
                description=_DESCRIPTIONS[name],
                input_schema=model.model_json_schema(),
            )
            for name, model in _ARGUMENT_MODELS.items()
        )

    def invoke(self, call: WriteToolCall) -> WriteToolResult:
        """Run a tool by name for a transport that dispatches generically.

        :param call: The call, with identity taken from the transport
        :return: The result payload and the spec it concerned
        :raises ValueError: If the tool is unknown or the arguments are malformed; such a call
            is rejected before any tool runs, so the transport records it, not this class
        :raises kp.errors.WriteNotPermittedError: If the target is outside the allow-list
        """
        context = CallContext(
            session_id=call.session_id,
            caller=call.caller,
            agent=call.agent,
            domains=call.domains,
        )
        if call.tool == PUBLISH_SPEC:
            published = self.publish_spec(
                context, PublishSpecArguments.model_validate(call.arguments)
            )
            return WriteToolResult(
                payload=published.model_dump(mode="json"),
                items_returned=1,
                spec_id=published.spec_id,
            )
        if call.tool == UPDATE_JIRA:
            updated = self.update_jira(context, UpdateJiraArguments.model_validate(call.arguments))
            return WriteToolResult(
                payload=updated.model_dump(mode="json"), items_returned=1, spec_id=updated.spec_id
            )
        raise ValueError("Unknown write tool")

    def _audited(
        self,
        context: CallContext,
        tool: str,
        arguments: BaseModel,
        story_key: str,
        action: Callable[[], _Result],
    ) -> _Result:
        started = time.perf_counter()
        request: dict[str, JsonValue] = arguments.model_dump(mode="json")
        try:
            result = action()
        except WriteNotPermittedError as exc:
            self._record(
                context, tool, request, story_key, started, refusal=str(exc), error=type(exc)
            )
            raise
        except Exception as exc:
            self._record(context, tool, request, story_key, started, error=type(exc))
            raise
        self._record(context, tool, request, story_key, started)
        return result

    def _record(
        self,
        context: CallContext,
        tool: str,
        request: dict[str, JsonValue],
        story_key: str,
        started: float,
        *,
        refusal: str | None = None,
        error: type[Exception] | None = None,
    ) -> None:
        if refusal is not None:
            logger.warning(
                "Write tool call refused",
                extra={"tool": tool, "error_class": error.__name__ if error else ""},
            )
        if self._audit is None:
            return
        try:
            spec_id: str | None = spec_id_for_story(require_story_key(story_key))
        except WriteNotPermittedError:
            spec_id = None
        self._audit.record(
            ToolCallRecord(
                call_id=uuid.uuid4().hex,
                session_id=context.session_id[:_MAX_KEY],
                caller=context.caller[:_MAX_KEY],
                agent=context.agent[:_MAX_KEY],
                tool=tool,
                request=request,
                domains_applied=context.domains,
                request_digest=_digest(request),
                items_returned=0 if (refusal is not None or error is not None) else 1,
                latency_ms=(time.perf_counter() - started) * _MILLISECONDS,
                called_at=self._clock.now(),
                refused=refusal is not None,
                refusal_reason=refusal,
                error_class=error.__name__ if error is not None else None,
                spec_id=spec_id,
            )
        )
