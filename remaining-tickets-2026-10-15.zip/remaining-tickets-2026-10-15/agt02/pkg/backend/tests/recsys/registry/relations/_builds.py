"""Build synthetic catalogues for the relation tests.

Every export here is written by :func:`tests.recsys.registry._fixtures.write_export_dir`
or is the committed synthetic fixture; no row, name or description comes from the real
catalogue.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from app.recsys.contracts import PublicationScope, SourceEnvironment
from app.recsys.ingest import read_skills_repo
from app.recsys.registry.catalogue_build import BuildResult, build_components
from app.recsys.registry.excel_reader import read_export
from app.recsys.registry.flags import apply_flags
from app.recsys.registry.links import build_links
from app.recsys.registry.models import ComponentLink
from tests.recsys.registry._fixtures import EXPORT_DIR, SKILLS_REPO, write_export_dir

#: The scope every relation build runs under.
SCOPE = PublicationScope(environment=SourceEnvironment.ppd, partition="default")

#: The deterministic build-rule version stamped on every relation candidate.
CODE_VERSION = "relation-test-code-version"

#: The legacy id of the default export's only agent.
WIDGET_HELPER = "agent:tenant-one/widget-helper"

AGENT_USAGE_HEADER = (
    "Tenant,Agent Name,Description,Skill ID,MCP ID,Knowledgebase ID,Instruction\n"
)

#: The default agent row with its Skill and MCP cells left for the caller.
WIDGET_ROW = (
    "tenant-one,Widget Helper,Use when widgets are needed.,{skills},{mcps},kb-alpha,"
    "You build widgets."
)

#: A second agent, used to move the first one down a row.
OTHER_ROW = "tenant-two,Beta Helper,Use when beta things are needed.,,,kb-alpha,You help."


def widget_row(skills: str = "alpha-helper", mcps: str = "") -> str:
    """Render the default agent row with the given Skill and MCP cells.

    :param skills: The Skill ID cell; quoted when it holds a comma.
    :param mcps: The MCP ID cell; quoted when it holds a comma.
    :return: One CSV data row.
    """

    def cell(value: str) -> str:
        return f'"{value}"' if "," in value else value

    return WIDGET_ROW.format(skills=cell(skills), mcps=cell(mcps))


def agent_usage(*rows: str) -> dict[str, str]:
    """Build an override that replaces the Agent Usage sheet.

    :param rows: The CSV data rows, in order.
    :return: An override for :func:`write_export_dir`.
    """
    return {"agent_usage.csv": AGENT_USAGE_HEADER + "".join(f"{row}\n" for row in rows)}


def build(
    export: Path = EXPORT_DIR, skills_repo: Path = SKILLS_REPO
) -> tuple[BuildResult, list[ComponentLink]]:
    """Build components and links exactly as the ingest does.

    :param export: The export directory.
    :param skills_repo: The skills checkout.
    :return: The build and its links.
    """
    tables = read_export(export)
    skills, _ = read_skills_repo(skills_repo)
    result = build_components(tables, skills, SCOPE, code_version=CODE_VERSION)
    links = build_links(result.catalogue, result.rows).links
    apply_flags(result.rows)
    return result, links


def build_export(overrides: dict[str, str]) -> tuple[BuildResult, list[ComponentLink]]:
    """Write a minimal export with overrides and build it against the fixture repo.

    :param overrides: File name to full CSV text.
    :return: The build and its links.
    """
    with tempfile.TemporaryDirectory() as scratch:
        export = write_export_dir(Path(scratch) / "export", overrides)
        return build(export, SKILLS_REPO)


def relation(
    links: list[ComponentLink], src_id: str, dst_id: str
) -> list[ComponentLink]:
    """Select the links between two components.

    :param links: The produced links.
    :param src_id: The declaring component's legacy id.
    :param dst_id: The target's legacy id.
    :return: Every matching link.
    """
    return [link for link in links if link.src_id == src_id and link.dst_id == dst_id]
