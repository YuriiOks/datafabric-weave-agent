"""Story normaliser: Jira-like issue records to :class:`~kp.domain.Story`.

Acceptance criteria are kept apart from the description: they come from the
``acceptance_criteria`` field when the tracker has one, otherwise from an
``Acceptance criteria`` section of the description, which is then removed from the
description. The story version is the issue's ``updated`` time written as UTC ISO-8601, so
versions sort chronologically as text whatever offset the tracker used, and a board move (a
status change) is a new version with an unchanged fingerprint.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping
from datetime import UTC, datetime

from kp.domain import Story, StoryLink
from kp.ingest.errors import StoryParseError

_DOMAIN_LABEL_PREFIX = "domain:"
_CRITERIA_HEADING = re.compile(
    r"^\s*(?:h[1-6]\.|#{1,6})?\s*\*{0,2}acceptance criteria:?\*{0,2}:?\s*$", re.IGNORECASE
)
_ANY_HEADING = re.compile(r"^\s*(?:h[1-6]\.|#{1,6})\s+\S")
_BLANK_RUNS = re.compile(r"\n{3,}")
# Atlassian document nodes after which a line break belongs.
_BLOCK_NODES = frozenset({"paragraph", "heading", "listItem", "codeBlock", "blockquote"})


def parse_story_export(content: bytes, *, default_version: str) -> tuple[Story, ...]:
    """Read an export (``{"issues": [...]}``) or a single issue record.

    :param content: JSON bytes
    :param default_version: Version for issues that carry no ``updated`` time
    :return: The normalised stories, in export order
    :raises StoryParseError: If the JSON is invalid or an issue is malformed; one malformed
        issue fails the whole export (its page is then retried, not half loaded) and the
        message names the issue's position in the export
    """
    try:
        document = json.loads(content)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise StoryParseError("The story export is not valid JSON") from exc
    if isinstance(document, Mapping) and "issues" in document:
        issues = document["issues"]
        if not isinstance(issues, list):
            raise StoryParseError("The story export has no list of issues")
        return tuple(
            _normalise_issue(index, issue, default_version) for index, issue in enumerate(issues)
        )
    return (normalise_story(document, default_version=default_version),)


def _normalise_issue(index: int, issue: object, default_version: str) -> Story:
    try:
        return normalise_story(issue, default_version=default_version)
    except StoryParseError as exc:
        raise StoryParseError(f"Issue {index} of the story export is malformed: {exc}") from exc


def normalise_story(raw: object, *, default_version: str) -> Story:
    """Normalise one Jira-like issue record.

    :param raw: A mapping with ``key`` and ``fields`` (summary, description, status, parent,
        issuelinks, labels, updated and optionally acceptance_criteria)
    :param default_version: Version to use when the issue has no ``updated`` time
    :return: The story, with acceptance criteria separate from the description; its version is
        the ``updated`` time in UTC ISO-8601 (text that is not a time is kept as it is)
    :raises StoryParseError: If the record is not an object or lacks a key or a summary
    """
    if not isinstance(raw, Mapping):
        raise StoryParseError("A story record must be an object")
    key = raw.get("key")
    fields = raw.get("fields")
    if not isinstance(key, str) or not key.strip() or not isinstance(fields, Mapping):
        raise StoryParseError("A story record needs a key and fields")
    summary = _text(fields.get("summary")).strip()
    if not summary:
        raise StoryParseError("A story needs a summary")
    description, criteria = _split_criteria(
        _text(fields.get("description")), _text(fields.get("acceptance_criteria"))
    )
    return Story(
        story_key=key.strip(),
        version=_version(fields.get("updated"), default_version),
        summary=summary,
        description=description,
        acceptance_criteria=criteria,
        links=tuple(_links(fields.get("issuelinks"))),
        parent_key=_parent_key(fields.get("parent")),
        status=_status(fields.get("status")),
        domain=_domain(fields.get("labels")),
    )


def _version(updated: object, default_version: str) -> str:
    if not isinstance(updated, str) or not updated:
        return default_version
    try:
        moment = datetime.fromisoformat(updated)
    except ValueError:
        return updated
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=UTC)
    return moment.astimezone(UTC).isoformat()


def _split_criteria(description: str, criteria: str) -> tuple[str, str]:
    if criteria.strip():
        return description.strip(), criteria.strip()
    lines = description.splitlines()
    start = next((i for i, line in enumerate(lines) if _CRITERIA_HEADING.match(line)), None)
    if start is None:
        return description.strip(), ""
    end = next(
        (i for i in range(start + 1, len(lines)) if _ANY_HEADING.match(lines[i])), len(lines)
    )
    kept = [*lines[:start], *lines[end:]]
    return "\n".join(kept).strip(), "\n".join(lines[start + 1 : end]).strip()


def _text(value: object) -> str:
    """Plain text of a field that is a string, an Atlassian document or absent."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return _BLANK_RUNS.sub("\n\n", _document_text(value)).strip()


def _document_text(node: object) -> str:
    if not isinstance(node, Mapping):
        return ""
    node_type = node.get("type")
    if node_type == "text":
        text = node.get("text")
        return text if isinstance(text, str) else ""
    if node_type == "hardBreak":
        return "\n"
    children = node.get("content")
    inner = (
        "".join(_document_text(child) for child in children) if isinstance(children, list) else ""
    )
    return f"{inner}\n" if node_type in _BLOCK_NODES else inner


def _links(raw: object) -> Iterable[StoryLink]:
    if not isinstance(raw, list):
        return
    for item in raw:
        if not isinstance(item, Mapping):
            continue
        link_type, target = _link_parts(item)
        if link_type and target:
            yield StoryLink(link_type=link_type, target_key=target)


def _link_parts(item: Mapping[str, object]) -> tuple[str, str]:
    raw_type = item.get("type")
    target = item.get("key")
    if isinstance(raw_type, str):
        return raw_type, target if isinstance(target, str) else ""
    if not isinstance(raw_type, Mapping):
        return "", ""
    for side, label in (("outwardIssue", "outward"), ("inwardIssue", "inward")):
        issue = item.get(side)
        if isinstance(issue, Mapping) and isinstance(issue.get("key"), str):
            name = raw_type.get(label) or raw_type.get("name")
            return (name if isinstance(name, str) else ""), str(issue["key"])
    return "", ""


def _parent_key(raw: object) -> str | None:
    value = raw.get("key") if isinstance(raw, Mapping) else raw
    return value if isinstance(value, str) and value else None


def _status(raw: object) -> str:
    value = raw.get("name") if isinstance(raw, Mapping) else raw
    return value.strip() if isinstance(value, str) else ""


def _domain(raw: object) -> str | None:
    if not isinstance(raw, list):
        return None
    for label in raw:
        if isinstance(label, str) and label.startswith(_DOMAIN_LABEL_PREFIX):
            return label.removeprefix(_DOMAIN_LABEL_PREFIX).strip() or None
    return None
