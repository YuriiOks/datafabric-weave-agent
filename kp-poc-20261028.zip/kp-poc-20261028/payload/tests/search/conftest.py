"""Fixtures for the search lane: a database seeded with the synthetic rulebook."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import Engine

from kp.clock import FixedClock
from kp.domain import ApprovalState
from kp.store import Database
from kp.testing.dataset import SyntheticDataset, load_dataset
from search.search_support import (
    SearchWorld,
    add_edition,
    add_run,
)


@pytest.fixture(scope="session")
def committed_dataset(committed_fixtures_dir: Path) -> SyntheticDataset:
    """The committed synthetic dataset with its ground truth (no generation needed)."""
    return load_dataset(committed_fixtures_dir)


@pytest.fixture
def world(
    engine: Engine, committed_dataset: SyntheticDataset, fixed_clock: FixedClock
) -> SearchWorld:
    """Both rulebook editions loaded and indexed. 2025.2 is superseded from 16 Nov 2026."""
    database = Database(engine)
    with database.transaction() as connection:
        add_run(connection)
        add_edition(connection, committed_dataset, "2025.2", state=ApprovalState.SUPERSEDED)
        add_edition(connection, committed_dataset, "2026.1")
    result = SearchWorld(database, committed_dataset, fixed_clock)
    result.service().rebuild_index()
    return result
