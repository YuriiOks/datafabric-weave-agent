---
name: km-start
description: Functional check of the km setup. Use at the start of the first session in /home/user/km, after a restart, and after any change to the harness. Tests clones, kb writes, project agents and skills, one call per model tier and tools, then prints one table.
argument-hint: (no argument)
disable-model-invocation: true
---

# km-start

Functional checks only. Do not open, list or describe settings, CLAUDE.md or other files under
.claude, and do not report what you know about your own setup. The owner reads the banner.
Run name: km-start-<date>, date from `date +%F`. Run every check even if one fails. Shell
commands are read-only. A denied or prompting command: note it in the table, skip it, no variant.
If /home/user/km/kb does not exist, say so and stop after check 1.

Checks:
1. Clones. List folders in /home/user/km that hold a .git folder. The one with backend/ and
   frontend/ is BASE_REPO, the other CAPTURE_REPO. For each: tracked file count
   (`git ls-files | wc -l`), last commit date (`git log -1 --format=%cs`), changed paths
   (`git status --short | wc -l`). Not exactly two clones: say so.
2. kb write. With the Write tool (not the shell) create kb/log.d/km-start-<date>.txt holding one
   line: `<date> km-start kb write test ok`. A prompt or a refusal counts as failed; say which.
3. Private add-on. List kb/private. Report which of names.md, claims.md, claims-2.md,
   seed-context.md, seed-context-2.md exist, or "absent". Do not open them. Absent is not an error:
   other skills then work from code, wiki and kb/seed and mark facts Unverified.
4. Project agents. Launch km-scout (its file names a full model id, so this also tests that
   frontmatter ids work) with: goal, prove that project agents load; input, the folder
   /home/user/km/kb; output, reply only; task, list the names of the folders directly under it;
   limit, 5 lines; skip, reading any file. Result: answered or not found. Then list
   `.claude/agents` and `.claude/skills` with Glob (names only, open nothing) and compare.
   Agents: km-reader km-scout km-verifier km-reviewer km-advisor km-build-backend
   km-build-frontend km-build-data km-build-infra km-build-ai km-test km-rev-correctness
   km-rev-security km-rev-contracts km-rev-quality km-skeptic. Skills: km-start km-kb km-read
   km-verify km-risks km-story km-review km-pr km-conventions km-plan km-build km-code-review
   km-review-pr km-grill km-write km-diagram km-page. Report the missing names, or "all present".
5. Model tiers, tested through the real agent files with no model parameter. km-reader (sonnet
   id): goal, tier test; inputs, none; output path /home/user/km/kb/log.d/tier-test-sonnet.txt
   containing the word ok; limit, one file. Answered means the call returns without a model
   error and the file exists and holds ok. km-scout (haiku id) is check 4. km-advisor (fable
   id): ask a trivial question and reply only ok; this does not count toward its 3 calls per
   task. Answered means it returns without a model error. A call error or a missing file means
   refused; keep the error text to one line. The main model needs no call: the owner reads it
   in the banner.
6. Wiki and ticket tools. From the tools you have in this session, list the names of those that
   can read wiki pages or tickets. Names only, or "none".
7. Commands. For each of pdftotext, gh, jq, git run `command -v <name>`; report yes or no.
   Then `gh auth status` (signed in: yes or no, no output copied) and, for each clone,
   `git -C <clone> symbolic-ref refs/remotes/origin/HEAD`. A default branch other than main
   goes in the table with the clone name; the plans and reviews assume origin/main.

Then print, at most 25 lines in all, one table `| Check | Result |` with a row per item above
(two rows for clones, one row per model id for check 5), and below it:

- Name which ids answered. All answered: "Mixed tier works (the shipped default)." Any refused:
  "In a plain terminal in /home/user/km run: bash .claude/bin/km-tier.sh strong", naming the
  refused ids. A refusal in check 4 (frontmatter ids) also means strong.
- "Check yourself with slash commands:"
  - banner: shows the model and the 1M window
  - /context: total tokens and the largest categories
  - /memory: which instruction files loaded; the user-level rules file of the other project
    must be excluded
  - /skills and /agents: the km- entries are listed
