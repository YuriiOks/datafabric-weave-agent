---
pack_id: "bpc-sep26-v1"
local_id: "CORE-12"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Enforce shared AI budgets, release lineage and operational controls"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 4
scope: "foundation"
create_by_default: true
planned_start: "2026-09-23"
planned_due: "2026-09-24"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-07"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-12"
architecture_sections: ["operations","security","ai-contracts"]
---

# Enforce shared AI budgets, release lineage and operational controls

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-12** is not a Jira key.
- Estimate: **4 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-23 → 2026-09-24 (D11–D12)**.
- Recommendation extension: **2026-09-25 → 2026-09-28 (D13–D14)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Keep improved AI behavior bounded and diagnosable across retries and replicas, and make rollback a configuration operation with explicit compatibility.

## Scope and contract

One request deadline/token-cost reservation, classified retries/fallback, server-owned version configuration, current authorization and safe stage telemetry. Reuse approved gateway/admission mechanisms; no process-local semaphore claimed as service-wide protection.

## Implementation sequence

1. Map current gateway limits and distributed admission; enforce a bounded pending-job wait and explicit busy outcome on every path/retry.
2. Resolve approved model/provider/schema/prompt/decoding configuration at admission and validate compatibility at stages/cache reuse.
3. Classify authentication and invalid-request failures separately from retryable transient failures; retries/fallback never reset budgets.
4. Instrument approved stage/status/count/cost/configuration fields and audit existing raw-query logs rather than assuming new category-only telemetry removed them.
5. Version release configuration with compatible data/index generations; define controlled-cohort switches, alert owner and rollback triggers.

## Acceptance criteria

- [ ] Aggregate admission and budgets cover all replicas and retries using the verified service mechanism.
- [ ] Detected version drift blocks incompatible cache/evaluation reuse and is diagnosable without raw secrets.
- [ ] Shadow is authorized and budgeted, changes no user response and performs no business action.
- [ ] Rollback preserves current access/deletion policy and compatible data configuration.

## Verification

- Run quota/retry/budget exhaustion, version mismatch, provider truncation and error-classification cases.
- Verify stage telemetry redaction and operating alert/runbook ownership.

## Evidence to attach

- Gateway/admission configuration diff, runtime manifest samples, operational cases and rollback config.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Four total model attempts and 120 seconds are only the future component-engine experiment proposal, not hardcoded budgets for the Hub. New distributed coordination infrastructure or new embedding generation build is outside this estimate and triggers a separate slice.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `operations`, `security`, `ai-contracts`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
