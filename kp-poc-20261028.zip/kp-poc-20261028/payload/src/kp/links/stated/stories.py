"""Stated links from the issue links of stories."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

from kp.domain import DomainModel, ItemRef, ItemType, Relation, Requirement, Story
from kp.links.candidate import LinkCandidate
from kp.links.stated.model import RejectedLink, StatedLinkSet, keep_conforming


class StoryLinkRule(DomainModel):
    """Which relation an issue link of a given type and target type states.

    ``link_type`` is compared case-insensitively. When the model gains a relation that a
    tracker link type already expresses, adding a rule here is the only change needed.
    """

    link_type: str
    target_type: ItemType
    relation: Relation


DEFAULT_STORY_LINK_RULES: tuple[StoryLinkRule, ...] = (
    StoryLinkRule(
        link_type="is specified by", target_type=ItemType.SPEC, relation=Relation.SPECIFIED_BY
    ),
    StoryLinkRule(
        link_type="specified by", target_type=ItemType.SPEC, relation=Relation.SPECIFIED_BY
    ),
)


class KeyIndex(DomainModel):
    """The keys the loaded items are known by, to tell what an issue link points at."""

    requirements: frozenset[str] = frozenset()
    specs: frozenset[str] = frozenset()
    stories: frozenset[str] = frozenset()

    @classmethod
    def build(
        cls,
        *,
        requirements: Iterable[Requirement] = (),
        requirement_id_field: str = "Req ID",
        spec_keys: Iterable[str] = (),
        story_keys: Iterable[str] = (),
    ) -> KeyIndex:
        """Index loaded items by the keys trackers use for them.

        :param requirements: Register rows, indexed by ``requirement_id`` and by their own id column
        :param requirement_id_field: Header of the register's id column
        :param spec_keys: Spec identities
        :param story_keys: Story keys
        :return: The index
        """
        native = {
            row.fields[requirement_id_field]
            for row in requirements
            if requirement_id_field in row.fields
        }
        return cls(
            requirements=frozenset(native | {row.requirement_id for row in requirements}),
            specs=frozenset(spec_keys),
            stories=frozenset(story_keys),
        )

    def classify(self, key: str) -> ItemType | None:
        """Tell what kind of item a key names.

        :param key: A key from an issue link
        :return: The item type, or ``None`` when no loaded item has that key
        """
        if key in self.specs:
            return ItemType.SPEC
        if key in self.requirements:
            return ItemType.REQUIREMENT
        if key in self.stories:
            return ItemType.STORY
        return None


def story_link_set(
    stories: Iterable[Story],
    index: KeyIndex,
    rules: Iterable[StoryLinkRule] = DEFAULT_STORY_LINK_RULES,
) -> StatedLinkSet:
    """Turn the issue links of stories into stated links.

    An issue link becomes a link only when a rule maps its type and target type to a
    relation of the model. The model has no relation from a story to a requirement or to
    another story, so ``implements`` and ``relates to`` links are reported as rejected, not
    stored and not guessed.

    :param stories: Loaded stories
    :param index: What the link targets are
    :param rules: Mapping from issue link type to relation
    :return: The stated links, the rejected issue links and the scope enumerated
    """
    by_type: Mapping[tuple[str, ItemType], Relation] = {
        (rule.link_type.casefold(), rule.target_type): rule.relation for rule in rules
    }
    story_list = list(stories)
    candidates: list[tuple[str, LinkCandidate]] = []
    rejected: list[RejectedLink] = []
    for story in story_list:
        source = ItemRef(item_type=ItemType.STORY, key=story.story_key)
        for issue_link in story.links:
            origin = f"{story.story_key} {issue_link.link_type} {issue_link.target_key}"
            target_type = index.classify(issue_link.target_key)
            if target_type is None:
                rejected.append(RejectedLink(origin=origin, reason="target is not a loaded item"))
                continue
            relation = by_type.get((issue_link.link_type.casefold(), target_type))
            if relation is None:
                rejected.append(
                    RejectedLink(
                        origin=origin,
                        reason=f"no relation of the model links a story to a {target_type.value} "
                        f"as '{issue_link.link_type}'",
                    )
                )
                continue
            target = ItemRef(item_type=target_type, key=issue_link.target_key)
            candidates.append(
                (origin, LinkCandidate.stated(source, relation, target, evidence=origin))
            )
    links, violations = keep_conforming(candidates)
    return StatedLinkSet(
        links=links,
        rejected=tuple(rejected) + violations,
        owned_sources=frozenset(
            ItemRef(item_type=ItemType.STORY, key=story.story_key) for story in story_list
        ),
        relations=frozenset(by_type.values()),
    )
