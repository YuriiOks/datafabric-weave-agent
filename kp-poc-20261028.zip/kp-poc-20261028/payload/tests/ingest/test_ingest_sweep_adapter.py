"""SweepContentProcessor: the sweep's processor port, implemented without importing the sweep."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import pytest
from sqlalchemy import Connection, Engine, func, select

from ingest.ingest_support import XLSX, ItemFactory, store_item
from kp.clock import FixedClock
from kp.config import Thresholds
from kp.domain import SourceItemVersion, SourceKind
from kp.ingest import IngestProcessor, StoryParseError, SweepContentProcessor
from kp.store import Database
from kp.store.schema import clause, story
from kp.testing.dataset import SyntheticDataset

JSON = "application/json"


@runtime_checkable
class SweepPort(Protocol):
    """A copy of the sweep's content-processor port, with its exact signatures."""

    def fingerprint(self, version: SourceItemVersion, content: bytes) -> str | None: ...

    def process(
        self, connection: Connection, version: SourceItemVersion, content: bytes
    ) -> None: ...


@pytest.fixture
def adapter(thresholds: Thresholds, fixed_clock: FixedClock) -> SweepContentProcessor:
    return SweepContentProcessor(IngestProcessor(thresholds, fixed_clock))


def test_us05_adapter_fits_the_sweeps_port(adapter: SweepContentProcessor) -> None:
    port: SweepPort = adapter  # checked by mypy against the exact signatures
    assert isinstance(port, SweepPort)


def test_us05_criteria_change_alters_the_export_fingerprint_and_a_re_export_does_not(
    adapter: SweepContentProcessor, dataset: SyntheticDataset, make_item: ItemFactory
) -> None:
    truth = dataset.truth.stories
    first = make_item(item_id="export-1", source=SourceKind.JIRA, media_type=JSON)
    second = make_item(item_id="export-1", version="2", source=SourceKind.JIRA, media_type=JSON)
    original = dataset.path(truth.first_export).read_bytes()
    before = adapter.fingerprint(first, original)
    assert before is not None
    assert adapter.fingerprint(second, dataset.path(truth.second_export).read_bytes()) != before
    assert adapter.fingerprint(second, original) == before


def test_us05_status_move_alone_does_not_change_the_fingerprint(
    adapter: SweepContentProcessor, make_item: ItemFactory
) -> None:
    def export(status: str, updated: str) -> bytes:
        return (
            '{"issues": [{"key": "PAY-1", "fields": {"summary": "A story", '
            f'"status": "{status}", "updated": "{updated}"}}}}]}}'
        ).encode()

    item = make_item(item_id="export-1", source=SourceKind.JIRA, media_type=JSON)
    todo = adapter.fingerprint(item, export("To Do", "2026-10-01T09:00:00+00:00"))
    done = adapter.fingerprint(item, export("Done", "2026-10-08T09:00:00+00:00"))
    assert todo is not None
    assert todo == done


@pytest.mark.parametrize(
    ("source", "media_type"),
    [
        (SourceKind.REGULATORY_REPO, "application/pdf"),
        (SourceKind.DOCUMENT_LIBRARY, XLSX),
        (SourceKind.CONFLUENCE, JSON),
    ],
)
def test_us05_content_other_than_tracker_exports_has_no_fingerprint(
    adapter: SweepContentProcessor, make_item: ItemFactory, source: SourceKind, media_type: str
) -> None:
    item = make_item(source=source, media_type=media_type)
    assert adapter.fingerprint(item, b"anything") is None


def test_us05_unreadable_tracker_export_has_no_fingerprint_and_fails_when_processed(
    adapter: SweepContentProcessor,
    engine: Engine,
    make_item: ItemFactory,
) -> None:
    item = make_item(item_id="export-1", source=SourceKind.JIRA, media_type=JSON)
    assert adapter.fingerprint(item, b"not json") is None
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        with pytest.raises(StoryParseError):
            adapter.process(connection, item, b"not json")


def test_us05_process_stores_the_stories_through_the_ingest_processor(
    adapter: SweepContentProcessor,
    engine: Engine,
    dataset: SyntheticDataset,
    make_item: ItemFactory,
) -> None:
    item = make_item(item_id="export-1", source=SourceKind.JIRA, media_type=JSON)
    content = dataset.path(dataset.truth.stories.first_export).read_bytes()
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        adapter.process(connection, item, content)
        stored = connection.execute(select(func.count()).select_from(story)).scalar_one()
        assert stored == dataset.truth.stories.story_count


def test_us07_process_stores_a_rulebook_edition_through_the_ingest_processor(
    adapter: SweepContentProcessor,
    engine: Engine,
    dataset: SyntheticDataset,
    make_item: ItemFactory,
) -> None:
    truth = dataset.truth.edition("2026.1")
    item = make_item(version="2026.1")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        adapter.process(connection, item, dataset.path(truth.pdf_path).read_bytes())
        stored = connection.execute(select(func.count()).select_from(clause)).scalar_one()
        assert stored == truth.toc_clause_count
