# Payments service (synthetic)

Fictional code used as test data.
