"""Settings loading from the environment."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from kp.config import Mode, Settings, load_settings
from kp.errors import ConfigurationError


@pytest.fixture(autouse=True)
def _clean_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    """Remove ambient ``KP_`` variables so tests control the whole environment."""
    for name in [name for name in os.environ if name.startswith("KP_")]:
        monkeypatch.delenv(name)


def test_defaults_are_local_and_need_no_environment(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.chdir(tmp_path)  # keep a stray .env out of the way

    settings = load_settings()

    assert settings.mode is Mode.LOCAL
    assert settings.token_refresh_fraction == 0.8
    assert settings.thresholds.guessed_share_max == 0.5
    assert settings.thresholds.stale_after_hours == 6.0
    assert settings.jira_page_size == 100


def test_values_are_read_from_prefixed_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KP_DATABASE_URL", "postgresql+psycopg://<database-dsn>")
    monkeypatch.setenv("KP_GATEWAY_CLIENT_SECRET", "s3cret-value")
    monkeypatch.setenv("KP_JIRA_FIELDS_ALLOWED", '["status", "<link-field>"]')
    monkeypatch.setenv("KP_THRESHOLDS__GUESSED_SHARE_MAX", "0.4")
    monkeypatch.setenv("KP_SAMPLE_ITEMS_FILE", "samples/items.yaml")

    settings = load_settings()

    assert settings.database_url.get_secret_value().startswith("postgresql")
    assert settings.jira_fields_allowed == ("status", "<link-field>")
    assert settings.thresholds.guessed_share_max == 0.4
    assert settings.sample_items_file == Path("samples/items.yaml")
    assert settings.gateway_client_secret is not None
    assert settings.gateway_client_secret.get_secret_value() == "s3cret-value"


def test_secrets_never_appear_in_repr_or_dump(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KP_GATEWAY_CLIENT_SECRET", "s3cret-value")
    monkeypatch.setenv("KP_SOURCE_TOKEN_JIRA", "tok-123")

    settings = load_settings()

    rendered = repr(settings) + str(settings.model_dump()) + settings.model_dump_json()
    assert "s3cret-value" not in rendered
    assert "tok-123" not in rendered


def test_invalid_value_raises_typed_error_without_echoing_input(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("KP_TOKEN_REFRESH_FRACTION", "1.5")

    with pytest.raises(ConfigurationError, match="token_refresh_fraction"):
        load_settings()


def test_unordered_thresholds_are_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KP_THRESHOLDS__LINK_REVIEW_MIN", "0.9")

    with pytest.raises(ConfigurationError):
        load_settings()


def test_real_mode_lists_every_missing_setting(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KP_MODE", "real")
    monkeypatch.setenv("KP_GATEWAY_BASE_URL", "<gateway-base-url>")

    with pytest.raises(ConfigurationError) as caught:
        load_settings()

    message = str(caught.value)
    assert "KP_GATEWAY_BASE_URL" in message  # a placeholder counts as unset
    assert "KP_SPEC_REPO" in message
    assert "KP_JIRA_FIELDS_ALLOWED" in message


def test_real_mode_accepts_a_complete_configuration(monkeypatch: pytest.MonkeyPatch) -> None:
    complete = {
        "KP_MODE": "real",
        "KP_DATABASE_URL": "postgresql+psycopg://db-host/kp",
        "KP_GATEWAY_BASE_URL": "gateway-base-value",
        "KP_GATEWAY_TOKEN_URL": "token-endpoint-value",
        "KP_GATEWAY_CLIENT_ID": "client",
        "KP_GATEWAY_CLIENT_SECRET": "secret",
        "KP_GATEWAY_TOKEN_HEADER": "X-Caller",
        "KP_SOURCE_TOKEN_HEADER": "X-Source",
        "KP_USE_CASE_ID": "uc",
        "KP_EXTRACTION_BASE_URL": "extraction-endpoint-value",
        "KP_RAW_BUCKET": "raw",
        "KP_MARKDOWN_BUCKET": "md",
        "KP_SPEC_REPO": "org/repo",
        "KP_SPEC_PATH": "specs",
        "KP_JIRA_FIELDS_ALLOWED": '["status", "link"]',
    }
    for name, value in complete.items():
        monkeypatch.setenv(name, value)

    settings = load_settings()

    assert settings.mode is Mode.REAL
    assert settings.spec_repo == "org/repo"


def test_real_mode_refuses_a_local_sqlite_database(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KP_MODE", "real")
    monkeypatch.setenv("KP_DATABASE_URL", "sqlite+pysqlite:///kp-local.db")

    with pytest.raises(ConfigurationError) as caught:
        load_settings()

    assert "KP_DATABASE_URL" in str(caught.value)
    assert "PostgreSQL" in str(caught.value)


def test_a_database_password_never_shows_in_the_settings_repr(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("KP_DATABASE_URL", "postgresql+psycopg://user:pa55word-value@db-host/kp")

    settings = load_settings()

    assert "pa55word-value" not in repr(settings)
    assert "pa55word-value" not in str(settings)


@pytest.mark.parametrize("path", ["../outside", "/absolute", "specs/../../up", "specs/.git/hooks"])
def test_a_spec_path_cannot_leave_the_agreed_folder(
    monkeypatch: pytest.MonkeyPatch, path: str
) -> None:
    monkeypatch.setenv("KP_SPEC_PATH", path)

    with pytest.raises(ConfigurationError, match="KP_SPEC_PATH"):
        load_settings()


@pytest.mark.parametrize("repository", ["no-slash", "a/b/c", "owner/../x", "owner/repo name"])
def test_a_spec_repository_must_be_owner_and_name(
    monkeypatch: pytest.MonkeyPatch, repository: str
) -> None:
    monkeypatch.setenv("KP_SPEC_REPO", repository)

    with pytest.raises(ConfigurationError, match="KP_SPEC_REPO"):
        load_settings()


def test_settings_are_immutable(local_settings: Settings) -> None:
    with pytest.raises(ValueError, match="frozen"):
        local_settings.mode = Mode.REAL  # type: ignore[misc]  # deliberate: frozen settings


def test_new_settings_default_to_the_data_folder_and_the_known_document_types(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.chdir(tmp_path)  # keep a stray .env out of the way

    settings = load_settings()

    assert settings.confluence_export_path is None
    assert settings.jira_export_path is None
    assert settings.code_repo_path is None
    assert settings.git_binary is None
    assert {"register", "rulebook", "guide"} <= set(settings.document_types)


def test_export_paths_document_types_and_git_binary_come_from_the_environment(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("KP_CONFLUENCE_EXPORT_PATH", "exports/pages")
    monkeypatch.setenv("KP_JIRA_EXPORT_PATH", "exports/issues")
    monkeypatch.setenv("KP_CODE_REPO_PATH", "checkout")
    monkeypatch.setenv("KP_DOCUMENT_TYPES", '["register", "memo"]')
    monkeypatch.setenv("KP_GIT_BINARY", "tools/git")

    settings = load_settings()

    assert settings.confluence_export_path == Path("exports/pages")
    assert settings.jira_export_path == Path("exports/issues")
    assert settings.code_repo_path == Path("checkout")
    assert settings.document_types == ("register", "memo")
    assert settings.git_binary == "tools/git"


@pytest.mark.parametrize(
    "present",
    [
        {"KP_EXTRACTION_AUTH_HEADER": "X-Extraction"},
        {"KP_EXTRACTION_TOKEN": "extraction-credential"},
    ],
)
def test_the_extraction_credential_and_its_header_come_as_a_pair(
    monkeypatch: pytest.MonkeyPatch, present: dict[str, str]
) -> None:
    for name, value in present.items():
        monkeypatch.setenv(name, value)

    with pytest.raises(ConfigurationError, match="must be set together"):
        load_settings()


def test_the_extraction_credential_is_a_secret(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("KP_EXTRACTION_AUTH_HEADER", "X-Extraction")
    monkeypatch.setenv("KP_EXTRACTION_TOKEN", "extraction-credential")

    settings = load_settings()

    assert "extraction-credential" not in repr(settings) + settings.model_dump_json()
