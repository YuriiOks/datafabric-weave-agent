"""HTTP status codes the connectivity clients branch on, named once."""

from __future__ import annotations

OK_MAX = 299
BAD_REQUEST = 400
UNAUTHORIZED = 401
FORBIDDEN = 403
NOT_FOUND = 404
REQUEST_TIMEOUT = 408
RATE_LIMITED = 429
SERVER_ERROR = 500
