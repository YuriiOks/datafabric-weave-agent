"""Register parser: a workbook to one requirement per data row.

Every sheet is handled on its own. A sheet whose header row is found with a confidence below
``Thresholds.register_header_min_confidence`` is refused: it yields no requirement and the
report carries the candidate header rows for a reviewer. Otherwise each non-blank row below
the header becomes one :class:`~kp.domain.Requirement` keyed by sheet name and one-based row
number, so the requirement count equals the data-row count.
"""

from __future__ import annotations

import io
import logging
from collections.abc import Sequence
from datetime import date, datetime, time

from openpyxl import load_workbook

from kp.config import Thresholds
from kp.domain import ItemKey, Requirement
from kp.ingest.errors import RegisterParseError
from kp.ingest.models import ParsedRegister, SheetReport
from kp.ingest.register_header import detect_header

logger = logging.getLogger(__name__)

_DOMAIN_COLUMN = "domain"


def parse_register(
    content: bytes, *, key: ItemKey, thresholds: Thresholds, default_domain: str | None = None
) -> ParsedRegister:
    """Turn a register workbook into requirements.

    :param content: The ``.xlsx`` bytes
    :param key: Source, item and version the requirements belong to
    :param thresholds: Supplies the header confidence threshold
    :param default_domain: Domain for rows without a ``Domain`` cell
    :return: Requirements of all accepted sheets and a report for every sheet
    :raises RegisterParseError: If the workbook cannot be opened or read; whatever the
        spreadsheet library raises on a damaged file (truncated, bit-flipped) is reported this way
    """
    requirements: list[Requirement] = []
    reports: list[SheetReport] = []
    for title, rows in _read_sheets(content):
        report, found = _parse_sheet(title, rows, key, thresholds, default_domain)
        reports.append(report)
        requirements.extend(found)
    logger.info(
        "Register parsed",
        extra={
            "item_id": key.item_id,
            "sheets": len(reports),
            "requirements": len(requirements),
            "refused_sheets": sum(report.refused for report in reports),
        },
    )
    return ParsedRegister(requirements=tuple(requirements), sheets=tuple(reports))


def _read_sheets(content: bytes) -> list[tuple[str, list[list[str]]]]:
    """Read every sheet as ``(title, rows of text)``; all library failures become one error."""
    try:
        workbook = load_workbook(io.BytesIO(content), data_only=True)
        return [
            (
                sheet.title,
                [[_text(cell) for cell in row] for row in sheet.iter_rows(values_only=True)],
            )
            for sheet in workbook.worksheets
        ]
    except Exception as exc:
        raise RegisterParseError("The register workbook could not be opened") from exc


def _parse_sheet(
    title: str,
    rows: Sequence[Sequence[str]],
    key: ItemKey,
    thresholds: Thresholds,
    default_domain: str | None,
) -> tuple[SheetReport, list[Requirement]]:
    guess = detect_header(rows)
    if guess.row is None:
        return SheetReport(sheet=title, header_confidence=0.0), []
    if guess.confidence < thresholds.register_header_min_confidence:
        report = SheetReport(
            sheet=title,
            header_confidence=guess.confidence,
            refused=True,
            candidate_rows=guess.candidates,
        )
        return report, []
    requirements = _requirements(title, rows, guess.row, guess.confidence, key, default_domain)
    report = SheetReport(
        sheet=title,
        header_row=guess.row,
        header_confidence=guess.confidence,
        data_row_count=len(requirements),
        candidate_rows=guess.candidates,
    )
    return report, requirements


def _requirements(
    sheet: str,
    rows: Sequence[Sequence[str]],
    header_row: int,
    confidence: float,
    key: ItemKey,
    default_domain: str | None,
) -> list[Requirement]:
    data = list(enumerate(rows[header_row:], start=header_row + 1))
    width = max(len(row) for row in rows[header_row - 1 :])
    names = _column_names(rows[header_row - 1], width)
    requirements = []
    for number, row in data:
        if not any(row):
            continue
        cells = [*row, *[""] * (width - len(row))]
        fields = dict(zip(names, cells, strict=True))
        requirements.append(
            Requirement(
                requirement_id=f"{key.item_id}:{sheet}:{number}",
                source=key.source,
                item_id=key.item_id,
                version=key.version,
                sheet=sheet,
                row_number=number,
                header_confidence=confidence,
                domain=_domain(fields, default_domain),
                fields=fields,
            )
        )
    return requirements


def _column_names(header: Sequence[str], width: int) -> list[str]:
    names: list[str] = []
    for column in range(width):
        base = (header[column] if column < len(header) else "") or f"column_{column + 1}"
        name, suffix = base, 2
        while name in names:
            name, suffix = f"{base}_{suffix}", suffix + 1
        names.append(name)
    return names


def _domain(fields: dict[str, str], default_domain: str | None) -> str | None:
    for name, value in fields.items():
        if name.casefold() == _DOMAIN_COLUMN and value:
            return value
    return default_domain


def _text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    if isinstance(value, datetime) and value.time() == time():
        return value.date().isoformat()
    if isinstance(value, datetime | date | time):
        return value.isoformat()
    return str(value).strip()
