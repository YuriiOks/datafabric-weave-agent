"""Tests of the sweep lane."""
