# Change package, 23 Oct 2026 (H)

Hides "Suggested components" on finished playbooks. Anchors come from `main` at 27c65a245046. The page test was checked against that commit by byte count and sha256. The page itself was read from screenshots, so its two anchors are short plain lines: the `SECTION_LABELS` declaration and the panel mount line. There is no base sha: the package checks its anchors against your checkout. If an anchor is missing, the script refuses and writes nothing. Send the refusal lines and the package is rebuilt.

None of the files in this folder are committed.

## Contents

| PR | Package | Branch | Cut from | PR base |
|---|---|---|---|---|
| H | `finished-playbooks` | `fix/no-suggestions-on-finished-playbooks` (new) | `origin/main` | `main` |

## Steps

```bash
sha256sum -c SHA256SUMS
python3 install.py --inspect
python3 install.py finished-playbooks <new worktree> --check
python3 install.py finished-playbooks <new worktree>
git -C <path> add -A && git -C <path> commit -m "Hide suggested components on finished playbooks"
```

Every script checks the branch, a clean worktree and every anchor before it writes. A second run reports `ALREADY APPLIED`. Nothing is staged, committed, pushed or tested by the scripts.

## Expected result

2 edited files: `frontend/src/pages/CardViewerPage.tsx` (a 10-line helper and one changed mount line) and `frontend/src/pages/CardViewerPage.test.tsx` (the panel stub now renders a marker, and one new table test with 6 cases).

No new files.

## Pull request

| PR | Title | Body |
|---|---|---|
| H | `Hide suggested components on finished playbooks` | `bodies/finished-playbooks.md` |

## Tests to expect in CI

| PR | Test files |
|---|---|
| H | frontend `pages/CardViewerPage.test.tsx` (edited). Run the whole frontend suite before the gate: other files may render this page. |
