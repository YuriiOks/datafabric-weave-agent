"""The tool registry: transport-agnostic typed tools, access control and audit in one place.

A tool is a typed function ``(ToolContext, Arguments) -> ToolOutcome``. The registry turns a
raw call into: access check from the caller's identity, argument validation, the handler,
and one audit record, whatever the outcome. Transports (stdio, HTTP) only translate.
"""

from __future__ import annotations

import logging
import time
import uuid
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Annotated, TypeVar

from pydantic import BaseModel, ConfigDict, Field, JsonValue, ValidationError
from sqlalchemy.exc import SQLAlchemyError

from kp.clock import Clock, SystemClock
from kp.domain import DomainModel, ToolCallRecord
from kp.errors import AccessForbiddenError, KpError, WriteNotPermittedError
from kp.tools.access import Caller, DomainDirectory, ToolContext
from kp.tools.audit import AuditSink, clip_key, clip_request, request_digest
from kp.tools.errors import (
    AuditFailedError,
    InvalidToolArgumentsError,
    ToolExecutionError,
    UnknownToolError,
)

logger = logging.getLogger(__name__)

_MILLISECONDS = 1000.0


class ToolArguments(BaseModel):
    """Base class of tool argument models: unknown fields are rejected, never ignored.

    Rejecting extras is what keeps a ``domain`` argument from being silently accepted.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)


ArgumentsT = TypeVar("ArgumentsT", bound=ToolArguments)


class ToolOutcome(DomainModel):
    """What a handler returns.

    :ivar payload: The JSON result shown to the agent.
    :ivar items_returned: How many items the payload carries; recorded in the audit trail.
    :ivar filtered_count: Items hidden from the agent by the domain filter.
    :ivar spec_id: The spec the call acted on, when it is a spec-level call.
    """

    payload: dict[str, JsonValue]
    items_returned: Annotated[int, Field(ge=0)] = 0
    filtered_count: Annotated[int, Field(ge=0)] = 0
    spec_id: str | None = None


class ToolDefinition(DomainModel):
    """What ``tools/list`` shows for one tool."""

    name: str
    description: str
    input_schema: dict[str, JsonValue]


class ToolResult(DomainModel):
    """The outcome of a successful call, with the id of its audit record."""

    call_id: str
    payload: dict[str, JsonValue]


ToolObserver = Callable[[Caller, str, "ToolResult"], None]
"""Told about every successful call after its audit record is written: caller, tool, result.

An observer sees what the agent was shown. It must not raise; a failure is logged and the
call still returns, so an observer can never turn an answered call into an error.
"""


@dataclass(frozen=True, slots=True)
class RegisteredTool:
    """A tool ready to be registered: its definition and a validating runner.

    Build one with :func:`define_tool`.
    """

    definition: ToolDefinition
    run: Callable[[ToolContext, Mapping[str, JsonValue]], ToolOutcome]


def define_tool(
    name: str,
    description: str,
    arguments: type[ArgumentsT],
    handler: Callable[[ToolContext, ArgumentsT], ToolOutcome],
) -> RegisteredTool:
    """Define a tool whose arguments are validated against a pydantic model.

    Deriving from :class:`ToolArguments` makes an unexpected argument (such as a domain) an
    error instead of being silently ignored.

    :param name: The tool name agents call
    :param description: What the tool does, shown in ``tools/list``
    :param arguments: The model of the arguments; its JSON schema is the tool's input schema
    :param handler: The typed implementation
    :return: The registrable tool
    """
    schema = arguments.model_json_schema()
    schema.pop("title", None)

    def run(context: ToolContext, raw: Mapping[str, JsonValue]) -> ToolOutcome:
        try:
            parsed = arguments.model_validate(dict(raw))
        except ValidationError as exc:
            problems = "; ".join(
                f"{'.'.join(str(part) for part in err['loc']) or 'arguments'}: {err['msg']}"
                for err in exc.errors(include_input=False, include_url=False)
            )
            raise InvalidToolArgumentsError(f"Invalid arguments for {name}: {problems}") from exc
        return handler(context, parsed)

    return RegisteredTool(
        definition=ToolDefinition(name=name, description=description, input_schema=schema),
        run=run,
    )


class ToolRegistry:
    """Registers tools and runs calls with access control and audit.

    :param directory: Maps a user identity to the domains it may read
    :param audit: Where call records go
    :param clock: Time source for ``called_at`` and "today"
    :param monotonic: Seconds counter for latency measurement
    :param new_call_id: Produces unique call identifiers
    :param observer: Told about every successful call, after it is recorded
    """

    def __init__(
        self,
        directory: DomainDirectory,
        audit: AuditSink,
        *,
        clock: Clock | None = None,
        monotonic: Callable[[], float] = time.perf_counter,
        new_call_id: Callable[[], str] = lambda: uuid.uuid4().hex,
        observer: ToolObserver | None = None,
    ) -> None:
        self._directory = directory
        self._audit = audit
        self._clock = clock if clock is not None else SystemClock()
        self._monotonic = monotonic
        self._new_call_id = new_call_id
        self._observer = observer
        self._tools: dict[str, RegisteredTool] = {}

    def register(self, tool: RegisteredTool) -> None:
        """Add a tool.

        :param tool: The tool to add
        :raises ValueError: If a tool with that name is already registered
        """
        name = tool.definition.name
        if name in self._tools:
            raise ValueError(f"Tool {name!r} is already registered")
        self._tools[name] = tool

    def definitions(self) -> list[ToolDefinition]:
        """List the registered tools in registration order.

        :return: Their definitions
        """
        return [tool.definition for tool in self._tools.values()]

    def call(self, caller: Caller, name: str, arguments: Mapping[str, JsonValue]) -> ToolResult:
        """Run one tool call and record it, including when it is refused or fails.

        :param caller: The caller asserted by the transport
        :param name: The tool name
        :param arguments: The raw arguments as the agent sent them
        :return: The payload and the id of the audit record
        :raises kp.errors.AccessForbiddenError: If the caller has no access or the item is outside
            the caller's domains (recorded as a refusal)
        :raises kp.errors.WriteNotPermittedError: If a write targets a place outside the
            allow-list (recorded as a refusal)
        :raises kp.tools.errors.UnknownToolError: If no such tool exists
        :raises kp.tools.errors.InvalidToolArgumentsError: If the arguments do not validate
        :raises kp.tools.errors.ToolExecutionError: If the tool failed unexpectedly
        :raises kp.tools.errors.AuditFailedError: If the audit record could not be written
        :raises kp.errors.KpError: Any other typed failure of the tool, recorded with its class
        """
        call = _Call(
            call_id=self._new_call_id(),
            caller=caller,
            name=name,
            arguments=arguments,
            domains=(
                self._directory.domains_for(caller.user) if caller.authenticated else frozenset()
            ),
            started=self._monotonic(),
        )
        try:
            outcome = self._run(call)
        except Exception as exc:
            self._write_audit(call, outcome=None, failure=exc)
            if isinstance(exc, KpError):
                raise
            # No traceback: exception arguments (SQL parameters, validation input) may echo
            # the agent's request.
            logger.error(
                "Tool failed unexpectedly",
                extra={"tool": clip_key(name), "error_class": type(exc).__name__},
            )
            raise ToolExecutionError("The tool failed; see the server log") from exc
        self._write_audit(call, outcome=outcome, failure=None)
        result = ToolResult(call_id=call.call_id, payload=outcome.payload)
        self._notify(call, result)
        return result

    def _notify(self, call: _Call, result: ToolResult) -> None:
        if self._observer is None:
            return
        try:
            self._observer(call.caller, call.name, result)
        except Exception as exc:
            # The call is answered and recorded; an observer failure must not undo that. No
            # traceback or message: database errors repeat the parameters of the statement.
            logger.error(
                "Tool observer failed",
                extra={"tool": clip_key(call.name), "error_class": type(exc).__name__},
            )

    def _run(self, call: _Call) -> ToolOutcome:
        if not call.caller.authenticated:
            raise AccessForbiddenError("The transport supplied no usable caller identity")
        if not call.domains:
            raise AccessForbiddenError("The caller has no access to any domain")
        tool = self._tools.get(call.name)
        if tool is None:
            raise UnknownToolError(f"Unknown tool: {call.name[:80]}")
        context = ToolContext(caller=call.caller, domains=call.domains, clock=self._clock)
        return tool.run(context, call.arguments)

    def _write_audit(
        self, call: _Call, *, outcome: ToolOutcome | None, failure: Exception | None
    ) -> None:
        refused = isinstance(failure, AccessForbiddenError | WriteNotPermittedError)
        # A caller who is not authenticated, or was refused, can send as much as the transport
        # lets through. The digest still proves what was asked; the text is kept short.
        keep_all = call.caller.authenticated and not refused
        record = ToolCallRecord(
            call_id=call.call_id,
            session_id=call.caller.session_id,
            caller=call.caller.user,
            agent=call.caller.agent,
            tool=clip_key(call.name),
            request=dict(call.arguments) if keep_all else clip_request(call.arguments),
            request_digest=request_digest(call.arguments),
            domains_applied=tuple(sorted(call.domains)),
            items_returned=outcome.items_returned if outcome is not None else 0,
            filtered_count=outcome.filtered_count if outcome is not None else 0,
            latency_ms=(self._monotonic() - call.started) * _MILLISECONDS,
            called_at=self._clock.now(),
            refused=refused,
            refusal_reason=str(failure) if refused and failure is not None else None,
            error_class=type(failure).__name__ if failure is not None else None,
            spec_id=(outcome.spec_id if outcome is not None else None) or call.caller.spec_id,
        )
        try:
            self._audit.record(record)
        except SQLAlchemyError as exc:
            logger.error("Audit record could not be written", extra={"tool": record.tool})
            raise AuditFailedError("The call could not be recorded; no result is returned") from exc
        logger.info(
            "Tool call finished",
            extra={
                "tool": record.tool,
                "caller": record.caller,
                "agent": record.agent,
                "refused": record.refused,
                "error_class": record.error_class,
                "items_returned": record.items_returned,
                "filtered_count": record.filtered_count,
                "latency_ms": round(record.latency_ms, 3),
            },
        )


@dataclass(frozen=True, slots=True)
class _Call:
    """One call in flight."""

    call_id: str
    caller: Caller
    name: str
    arguments: Mapping[str, JsonValue]
    domains: frozenset[str]
    started: float
