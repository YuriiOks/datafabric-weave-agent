"""Errors specific to the sweep. All derive from :class:`kp.errors.KpError`."""

from __future__ import annotations

from kp.errors import KpError


class SweepError(KpError):
    """Base class of failures raised by the sweep itself."""


class SweepDeferredError(SweepError):
    """A source kept asking the sweep to wait; the rest of its work is left for a later run.

    This is not a failure: the saved position is intact and the next sweep continues from it.
    """


class RawStoreConflictError(SweepError):
    """Different bytes were offered for a raw location that already holds content."""
