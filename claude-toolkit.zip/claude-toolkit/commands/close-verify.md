---
description: Walk every **VERIFY** marker in a review/spec document, check each claim against the actual source, and produce an evidence table (CONFIRMED / REFUTED / UNCLEAR with file:line citations).
---

Target document: $ARGUMENTS — if no argument is given, find candidates with `grep -rl "VERIFY" docs/ specs/ --include="*.md"` and confirm which one to process before starting.

## Step 1: Extract the claims

Collect every inline **VERIFY** marker and every numbered item in a VERIFY checklist section. Restate each as one falsifiable sentence (for example: *BOUNDED_SEARCH_REASONING_ENABLED defaults to False*). Number them; keep the source line reference of each claim.

## Step 2: Verify each claim against the repo

Primary evidence order: config defaults (`backend/app/config.py`, `.env.example`, `docker-compose.yml`) → code (`backend/app/**`, `frontend/src/**`) → committed specs (`specs/*.md`). CLAUDE.md is documentation, not proof — cite it only as secondary evidence alongside a code citation.

Rules:

- Evidence means file path + line number + a quoted fragment. No quote, no verdict.
- Exactly three statuses: CONFIRMED / REFUTED / UNCLEAR. When torn, choose UNCLEAR — never round up to CONFIRMED.
- Claims that require executing something (index update behavior, live Gateway model catalogs, runner capabilities) are UNCLEAR by default; attach the exact experiment or owner question that would settle each one. Do not run live experiments with cost or side effects from this command.
- Claims about people, ownership, or policy (risk limits, review owners) are UNCLEAR with a named owner question — the repo cannot prove them.

## Step 3: Output the evidence table

| # | Claim | Status | Evidence (file:line) | Note |

Then two short lists:

- **REFUTED** → the corrected fact + which section of the target document must change.
- **UNCLEAR** → the exact command, experiment, or owner question that closes each one.

End with a one-line tally: `N confirmed / N refuted / N unclear of N total`.

## Step 4: Offer the document update

Do NOT edit the target document unprompted. Offer to: replace each closed VERIFY marker with its evidence reference, rewrite refuted statements, and leave UNCLEAR items marked. Apply only on explicit go-ahead.
