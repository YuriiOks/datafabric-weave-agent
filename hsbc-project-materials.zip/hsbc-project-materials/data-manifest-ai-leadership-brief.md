# Data Manifest AI - Leadership Brief

**Use case:** UC0004963  
**Product:** Data Management Centre (DMC)  
**Audience:** Leadership  
**Status date:** 2026-07-31  
**Companion detail:** `UC0004963 - Best Practice Card - Data Manifest AI Use Case.md`

## 1. Executive summary

HSBC runs thousands of applications and integrations. The evidence of what each data system holds, where it moves, what it means in business terms, and how it is controlled is captured in four "Data Manifest" files per application: `application.json`, `integration.json`, `techmetadata.json`, and `lineage.json`. Producing and maintaining these files by hand is slow and inconsistent. They can be stale within weeks, exposing the bank to BCBS 239, GDPR, and SOX obligations, slow incident response, and risky migrations.

The Data Manifest capability in DMC assembles these files from authoritative sources, uses AI to do the semantic work - mapping technical columns to governed business terms and suggesting data categories and quality rules - and routes every suggestion to ITSO/CDAO for approval before anything is committed. Nothing is straight-through: a human always vets AI output.

Crucially, the manifest is a living document, not a one-off onboarding artefact. Applications change constantly, and metadata can drift out of date with every release. The capability therefore watches each onboarded application's Change Requests, merged PRs, and Jira tickets, decides whether a change affects the manifest, and re-triggers the enrichment workflow so the files stay accurate for the entire lifetime of the application - again, with human approval before commit.

> **Honest status:** Today the platform is a working metadata-orchestration engine with the data plumbing and review UI in place. The AI layer (semantic suggestion and quality-rule generation) and the ADM enrichment integration are selected and designed, but not yet built. This brief separates what exists from what is planned.

## 2. The problem and why AI

| Without this capability | Why AI (not just rules) |
| --- | --- |
| Metadata is authored by hand, per application, and stale within weeks. | Mapping cryptically named columns such as `cust_nm` to the correct governed business term is semantic and ambiguous. Rules and regular expressions cannot resolve synonyms to one taxonomy term. |
| Data categories and quality controls are inconsistent across systems. | Governed vocabularies are large and scarce experts are the bottleneck. AI can propose; a human confirms. |
| Regulatory evidence for BCBS 239, GDPR, and SOX is manual and slow. | AI-assisted enrichment targets minutes per table rather than hours, at high first-pass accuracy, with human vetting. |

> Efficiency figures such as hours to minutes and 85-90% first-pass accuracy are programme targets, not independently benchmarked.

## 3. Overall architecture

The architecture has five layers:

- **Authoritative sources:** HBIM/GDC/CDM group business glossary, ADM, CxO Refinery (Google BigQuery), ServiceNow, application source code and database scans, and Collibra/DTAS Collibra Edge.
- **DMC backend:** manifest generation services, the AI enrichment orchestrator, and a validation engine for schema plus DMOV/DUSE controls.
- **AI enrichment (planned / in design):** Group AI Platform services for the LLM gateway, embeddings, privacy/ISR support, and DQ rule suggestions.
- **DMC frontend:** ITSO/CDAO review and vetting UI.
- **Downstream:** Git manifest repositories, DLAS propagation to ServiceNow and Collibra, and enterprise lineage or DataHub.

### How to read the architecture

Authoritative sources feed the DMC backend, which assembles each manifest file and calls AI enrichment services through the Group AI Platform to add business meaning and quality rules. Everything is validated and then surfaced to ITSO/CDAO in the DMC frontend. On approval, the manifest is committed to Git and propagated by DLAS to ServiceNow and Collibra.

### End-to-end onboarding workflow

1. A user onboards an application.
2. Integration retrieval and metadata harvesting run in parallel.
3. DCOS scopes the key metadata columns.
4. Scoped metadata is pushed to ADM for PBT enrichment and matching.
5. Results return to Collibra/CxO; DQ rule suggestions are produced in design.
6. ITSO/CDAO vets the proposal in DMC.
7. Approval commits the manifest to Git; DLAS propagates it to SNOW and Collibra. Reject/correct routes back to GDC and Business Context suggestions.

A user onboards an application; **integration retrieval and metadata harvesting run in parallel**. Harvested metadata is scoped into **DCOS (Data Control of Scope)** - the application owner's curated set of the most important columns. From there, scoped metadata is enriched through PBT matching on ADM, while the AI suggestors propose data categories, business context, and quality rules. All of it is gated by ITSO/CDAO vetting before commit.

### Manifests are living documents - the maintenance loop

Onboarding produces the first version of the manifest. Keeping it accurate for years is the harder problem. A **change-aware maintenance loop** monitors each onboarded application's activity and only re-runs enrichment when a change actually affects the manifest, avoiding both drift (stale files) and noise (unnecessary re-reviews).

## 4. The agents - functionality, input and output

The solution is **agentic but deliberately lean**: three components genuinely reason and suggest. The rest are ordinary tool or API calls, or a manual step, and are listed separately for honesty.

### 4.1 AI agents owned by this solution

#### Agent A - GDC and Business Context Suggestor

| Field | Detail |
| --- | --- |
| What it does | Recommends the correct **Group Data Category (GDC)** for applications and technical datasets, and refreshes an integration's **Business Context** when it lapses. |
| Input | Application or dataset metadata from CxO/BigQuery (GDCR analysis tables); governed GDC/CDM domains in Collibra surfaced via CxO; CxO reference tables for line-of-business validity; planned embeddings of the metadata. |
| Functionality / triggers | Fires when a new technical dataset is added, when retrieved data has no CDM associated, or when a Business Context has expired. It matches metadata to governed values; planned semantic ranking provides a confidence score and alternatives. |
| Output | Suggested GDC(s), planned, with confidence score and alternatives, plus refreshed Business Context presented to ITSO/CDAO for approval. |
| Status | **Partially built.** Data-driven GDC association and a CDAO tag auto-approve flow exist today. The AI/semantic ranking is UI-ready but **not yet built**. |

#### Agent B - Data Quality Rule Suggestor

| Field | Detail |
| --- | --- |
| What it does | Proposes **preventive, ingestion-time data-quality rules** for each field. |
| Input | Per-field code or DDL evidence from harvested metadata, plus a governed catalog of DQ Control Descriptions, each mapped to a Dimension. |
| Functionality | The LLM is constrained to the governed catalog and may not invent rules. It fills placeholder values, avoids contradictions, and classifies each rule under a Dimension: Completeness, Conformity, Uniqueness, or Referential Integrity. |
| Output | A list of `[Dimension, DQ Control Description]` values per field, for example `Conformity - Field must be formatted as YYYYMMDD`, human-vetted before use. |
| Status | **In design.** A prototype prompt and rule catalog exist (`DQRules.json`, `context.json`); functionality is not yet built. |

#### Agent C - Change-Aware Manifest Maintenance

Also called the **CR Watcher / Analyser**, this component keeps the manifest accurate for the whole life of the application by watching for changes and re-triggering enrichment only when the manifest is actually affected.

| Field | Detail |
| --- | --- |
| What it does | Watches application activity and produces a scoped re-enrichment decision rather than re-running the whole pipeline for every event. |
| Input | Active ServiceNow Change Requests retrieved through the KONG gateway, keyed by business unit and application ID; merged PRs; and Jira tickets for each onboarded application. |
| Functionality / triggers | Runs continuously per onboarded app. An LLM via GAIP reads CR, PR, and Jira content, decides whether the change is manifest-relevant - for example a schema change, new dataset, new integration, or control change - and triggers re-harvest and re-enrichment for the affected scope. Non-relevant changes are ignored to avoid review fatigue. |
| Output | A change-impact decision and, when relevant, a re-enrichment job that produces an updated manifest diff for ITSO/CDAO review. |
| Status | **In early build.** A dedicated `dmc-cr-extraction` service already retrieves ServiceNow CRs through KONG and has GAIP `gpt-5` chat plumbing. PR/Jira ingestion, relevance classification, and workflow triggering are not yet built. |

### 4.2 Supporting components (not agents)

| Component | Input | Output | Nature |
| --- | --- | --- | --- |
| Metadata Harvester | Application source code or database catalogue; metadata only - never row data | `techmetadata.json` | Existing API/workflow; auto-runs on application change |
| Application assembly | ServiceNow and CxO records | `application.json` | Existing API/workflow |
| Integration retrieval | CxO/BigQuery inbound integration IDs | `integration.json` | Existing query/workflow |
| HBIM PBT Mapping | Scoped metadata (DCOS) | PBT matches returned to Collibra/CxO | Owned by ADM; enrichment happens on the ADM side. Whether DMC surfaces results through an ADM API remains an open decision. |
| Privacy / ISR classification | User selection when adding a dataset | ISR level, from Non-HSBC through Highly Restricted | Manual today; future AI candidate |

## 5. Current status vs roadmap (honest view)

| Capability | Status |
| --- | --- |
| CxO/BigQuery sourcing (service account), Collibra integration | **Built** |
| DCOS scoping, manifest assembly, validation, ITSO/CDAO vetting UI | **Built** |
| GDC data association and CDAO tag auto-approve | **Built** |
| Manual ISR / privacy classification | **Built** |
| ServiceNow CR retrieval (KONG) and GAIP `gpt-5` plumbing | **Built** (`dmc-cr-extraction`) |
| AI semantic ranking of GDC/PBT candidates | **UI-ready, backend not built** |
| DQ Rule Suggestor (LLM plus governed catalog) | **In design** (prototype prompt exists) |
| Change-aware maintenance loop (CR/PR/Jira analysis and auto-trigger) | **In early build** (retrieval and GAIP exist; analyse-and-trigger not built) |
| ADM PBT enrichment integration | **Designed, not built** (needs ADM API discussion) |
| Semantic search / natural-language discovery | **Planned** (candidate: Elasticsearch) |
| `lineage.json` generation (OpenLineage) | **Future scope** |
| AI-assisted privacy / ISR classification | **Future roadmap** |

> **Verified against code:** no LLM, embedding, vector, or semantic-search libraries are present in the repositories yet. The AI models named below are selected, not integrated. Selected AI stack: embeddings `text-embedding-3-large/small`; LLM `gpt-5 / mini / batch` by use case; all through the Group AI Platform, with final routing to confirm.

## 6. Possible future extensions

1. **Full AI semantic ranking and natural-language discovery** - let owners find datasets and systems by plain-English query, such as "which systems hold customer credit exposure", rather than exact filters; a copilot for data governance.
2. **AI-assisted privacy and ISR classification** - auto-detect PII or sensitive fields and propose regulatory tags, which are currently manual.
3. **Lineage automation** - generate `lineage.json` using OpenLineage, add impact analysis for column changes, and support root-cause analysis for quality incidents.
4. **Learning from history** - feed approved and rejected suggestions back so accuracy improves over time; move high-confidence items to threshold-based auto-approval while reserving humans for low-confidence cases.
5. **Bulk and portfolio mapping** - enrich an entire application estate in one pass rather than table by table.
6. **DQ auto-remediation** - raise tickets or trigger workflows automatically when a preventive rule is breached.
7. **Native ADM PBT surfacing in DMC** - remove the context switch by displaying ADM enrichment results directly in the review UI.
8. **Extend to more control frameworks** - automate Data Privacy (DPRIV) and Data Storage (DSTO) controls alongside movement and usage.
9. **Deepen change-aware maintenance** - extend Agent C beyond ServiceNow CRs to full PR and Jira ingestion, add drift alerts to owners, and, once accuracy is proven, auto-approve low-risk manifest updates straight through.

## 7. Key dependencies and risks

- **Governed vocabularies must be readable by the AI.** Approved GDC/PBT terms, business-context validity (line of business by legal entity), and technical-pattern references are required. If the AI cannot read them, it can produce values that pass schema checks but fail control validation.
- **ADM ownership of PBT enrichment** is a critical external dependency. The DMC-versus-ADM boundary for surfacing results needs a leadership-level decision.
- **Change-relevance accuracy** matters. Agent C only re-triggers enrichment when it judges a CR, PR, or Jira change to be manifest-relevant. A false negative silently lets the manifest go stale; a false positive floods owners with needless reviews. The classifier needs measurement and a conservative default.
- **The AI layer is not yet built.** The value case depends on delivering the semantic suggestion and DQ modules; today the differentiator is the orchestration and review workflow.
- **Human-in-the-loop is a feature, not a gap.** It is the control that makes AI suggestions safe to adopt in a regulated environment.

## 8. Glossary (quick reference)

| Term | Meaning |
| --- | --- |
| DMC | Data Management Centre - the product delivering this capability |
| GDC / CDM | Group Data Category / Common Data Model - governed data-classification vocabularies |
| HBIM / PBT | HSBC Business Information Model / Preferred Business Term - canonical business meaning for a column |
| ADM | Advanced Data Management Platform - owns HBIM PBT enrichment and matching |
| CxO Refinery | HSBC's Google BigQuery warehouse; source of application, integration, GDC, and reference data |
| DCOS | Data Control of Scope - the owner-curated set of the most important metadata columns |
| TDS | Technical Data Set - a dataset within an inbound integration, carrying ISR and GDC |
| DLAS | Data Lineage Automation Service - propagates approved manifests to ServiceNow and Collibra |
| ITSO / CDAO | IT Service Owner / Chief Data and Analytics Office - the human approvers |
| ISR | Information Security classification level of a dataset |
| DMOV / DUSE | Control validations governing `integration.json` and `techmetadata.json` |
| CR | Change Request - a ServiceNow record describing a planned change to an application |
| GAIP | Group AI Platform - HSBC's governed gateway for LLM access, for example `gpt-5` |
| KONG | API gateway used to retrieve ServiceNow change-request data |
