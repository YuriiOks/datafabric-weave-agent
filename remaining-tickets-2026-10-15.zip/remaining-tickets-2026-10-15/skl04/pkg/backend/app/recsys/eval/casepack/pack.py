"""A case pack on disk, and its validation against the pinned corpus.

A pack directory holds ``pack.yaml`` (the header) and one ``<case_id>.yaml`` per case, the
same one-file-per-case layout as the golden set. The split, the decision log and the
feedback log are separate YAML documents read with :func:`load_document` and
:func:`load_documents`.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any, TypeVar

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.recsys.contracts import ComponentType
from app.recsys.eval.casepack.cases import EvaluationCase, Scenario
from app.recsys.eval.casepack.corpus import CorpusManifest, FieldState
from app.recsys.eval.casepack.lineage import CasePackError, CasePackLineage
from app.recsys.eval.casepack.profiles import CasePackProfile
from app.recsys.eval.casepack.split import check_grouping

PACK_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
PACK_HEADER = "pack.yaml"

_Model = TypeVar("_Model", bound=BaseModel)


class CasePack(BaseModel):
    """The cases of one component type, pinned to one lineage and one corpus manifest."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    pack_id: str
    component_type: ComponentType
    lineage: CasePackLineage
    corpus_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    cases: tuple[EvaluationCase, ...] = ()

    @field_validator("pack_id")
    @classmethod
    def _pack_id_shape(cls, value: str) -> str:
        """Refuse malformed pack ids.

        :param value: The pack id.
        :return: The id, checked.
        """
        if not PACK_ID_RE.match(value):
            raise ValueError("pack ids are lower-case words joined by hyphens")
        return value

    @model_validator(mode="after")
    def _cases_belong(self) -> CasePack:
        """Every case is unique, of the pack's type and pinned to the pack's lineage.

        :return: The pack.
        :raises ValueError: When a case breaks any of those.
        """
        ids = [case.case_id for case in self.cases]
        if ids != sorted(set(ids)):
            raise ValueError("case ids are unique and sorted")
        digest = self.lineage.digest()
        for case in self.cases:
            if case.component_type != self.component_type:
                raise ValueError(f"case {case.case_id} is of another component type")
            if case.lineage_digest != digest:
                raise ValueError(f"case {case.case_id} is pinned to another lineage")
        return self


def validate_pack(pack: CasePack, corpus: CorpusManifest, profile: CasePackProfile) -> None:
    """Check a pack against its pinned corpus manifest and its type profile.

    Every component a case names must be published in the pinned corpus: an id the corpus
    does not hold is refused here, before any run can count it.

    :param pack: The case pack.
    :param corpus: The corpus manifest the pack pins.
    :param profile: The profile of the pack's component type.
    :raises CasePackError: When the pack, corpus and profile disagree.
    """
    types = {pack.component_type, corpus.component_type, profile.component_type}
    if len(types) != 1:
        raise CasePackError("pack, corpus and profile cover different component types")
    if corpus.lineage.digest() != pack.lineage.digest():
        raise CasePackError("the corpus manifest is pinned to another lineage")
    if corpus.digest() != pack.corpus_digest:
        raise CasePackError("the corpus manifest is not the one the pack pins")
    published = corpus.component_ids()
    for case in pack.cases:
        prefix = profile.case_prefix
        if not case.case_id.startswith(f"{prefix}-"):
            raise CasePackError(f"case {case.case_id} does not carry the {prefix} prefix")
        if case.scenario not in profile.scenarios:
            raise CasePackError(f"case {case.case_id} uses a scenario this type does not allow")
        unknown = sorted(case.referenced_ids() - published)
        if unknown:
            raise CasePackError(f"case {case.case_id} names unpublished components")
        incomplete = case.scenario is Scenario.incomplete_description
        if incomplete and not _names_incomplete(case, corpus):
            raise CasePackError(f"case {case.case_id} names no component with a weak description")
    check_grouping(pack.cases)


def _names_incomplete(case: EvaluationCase, corpus: CorpusManifest) -> bool:
    """Return whether a case names a component whose description is not usable as published.

    :param case: The case.
    :param corpus: The corpus manifest.
    :return: ``True`` when one named component has a missing or malformed description.
    """
    for component_id in case.referenced_ids():
        entry = corpus.entry(component_id)
        if entry is not None and entry.field_state("description") is not FieldState.present:
            return True
    return False


def coverage_gaps(pack: CasePack, profile: CasePackProfile) -> tuple[Scenario, ...]:
    """List the required scenarios the pack does not cover yet.

    :param pack: The case pack.
    :param profile: The profile of its type.
    :return: The missing scenarios, sorted by value.
    """
    covered = {case.scenario for case in pack.cases}
    return tuple(sorted(profile.required_scenarios - covered, key=lambda item: item.value))


def _read_yaml(path: Path) -> Any:
    """Read one YAML document.

    :param path: The file.
    :return: The parsed document.
    :raises CasePackError: When the file cannot be read or parsed.
    """
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as error:
        raise CasePackError(f"{path.name} cannot be read as YAML") from error


def _validated(model: type[_Model], data: Any, name: str) -> _Model:
    """Validate parsed data as one model.

    :param model: The model type.
    :param data: The parsed data.
    :param name: The file name, for the error.
    :return: The model.
    :raises CasePackError: When the data does not validate.
    """
    try:
        return model.model_validate(data)
    except ValueError as error:
        raise CasePackError(f"{name} does not match {model.__name__}") from error


def load_document(path: Path, model: type[_Model]) -> _Model:
    """Load one YAML document as one model.

    :param path: The file.
    :param model: The model type.
    :return: The model.
    :raises CasePackError: When the file cannot be read or does not validate.
    """
    return _validated(model, _read_yaml(path), path.name)


def load_documents(path: Path, model: type[_Model]) -> list[_Model]:
    """Load one YAML list as a list of models.

    :param path: The file.
    :param model: The model type of each item.
    :return: The models; an empty file is an empty list.
    :raises CasePackError: When the file is not a list or an item does not validate.
    """
    data = _read_yaml(path)
    if data is None:
        return []
    if not isinstance(data, list):
        raise CasePackError(f"{path.name} is not a YAML list")
    return [_validated(model, item, path.name) for item in data]


def dump_document(model: BaseModel | Iterable[BaseModel]) -> str:
    """Render one model, or a list of models, as YAML.

    :param model: The model or models.
    :return: The YAML text.
    """
    if isinstance(model, BaseModel):
        data: Any = model.model_dump(mode="json")
    else:
        data = [item.model_dump(mode="json") for item in model]
    return yaml.safe_dump(data, sort_keys=False, allow_unicode=False)


def load_pack(pack_dir: Path) -> CasePack:
    """Load a pack directory.

    :param pack_dir: The directory holding ``pack.yaml`` and the case files.
    :return: The pack.
    :raises CasePackError: When a file cannot be read, a case file is misnamed, or the
        pack does not validate.
    """
    header = _read_yaml(pack_dir / PACK_HEADER)
    if not isinstance(header, dict) or "cases" in header:
        raise CasePackError(f"{PACK_HEADER} holds the pack header only")
    cases = []
    for path in sorted(pack_dir.glob("*.yaml")):
        if path.name == PACK_HEADER:
            continue
        case = _validated(EvaluationCase, _read_yaml(path), path.name)
        if case.case_id != path.stem:
            raise CasePackError(f"{path.name} holds case {case.case_id}")
        cases.append(case)
    return _validated(CasePack, {**header, "cases": cases}, PACK_HEADER)


def dump_pack(pack: CasePack) -> dict[str, str]:
    """Render a pack as the files of its directory.

    :param pack: The pack.
    :return: File name to YAML text, header first.
    """
    header = pack.model_dump(mode="json", exclude={"cases"})
    files = {PACK_HEADER: yaml.safe_dump(header, sort_keys=False, allow_unicode=False)}
    for case in pack.cases:
        files[f"{case.case_id}.yaml"] = dump_document(case)
    return files
