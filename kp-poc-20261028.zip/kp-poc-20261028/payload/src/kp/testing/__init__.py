"""Test support shipped with the package: synthetic data and its ground truth.

Needs the ``dev`` extra (fpdf2 for the PDF fixtures).
"""
