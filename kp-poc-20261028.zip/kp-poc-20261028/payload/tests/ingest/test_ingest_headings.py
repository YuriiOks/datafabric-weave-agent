"""Heading and table-of-contents detection (the building blocks of US-07)."""

from __future__ import annotations

import pytest

from kp.ingest.headings import find_markdown_headings, find_pdf_headings, is_successor, iter_lines
from kp.ingest.toc import find_markdown_toc, find_pdf_toc


@pytest.mark.parametrize(
    ("previous", "number", "expected"),
    [
        (None, "1", True),
        (None, "0", True),
        (None, "2", False),
        ("4.2.3", "4.2.3.1", True),
        ("4.2.3", "4.2.4", True),
        ("4.2.3", "4.3", True),
        ("4.2.3", "5", True),
        ("4.2.3", "4.2.5", False),
        ("4.2.3", "99.9", False),
        ("4.2.3", "4.2.3", False),
        ("4.2.3", "4.1", False),
        ("1", "1.1", True),
        ("1", "2", True),
    ],
)
def test_us07_successor_numbering(previous: str | None, number: str, expected: bool) -> None:
    assert is_successor(previous, number) is expected


def test_us07_iter_lines_gives_offsets_without_newlines() -> None:
    text = "ab\n\ncd\n"
    assert [text[start:end] for start, end in iter_lines(text)] == ["ab", "", "cd"]
    assert list(iter_lines("")) == []
    assert list(iter_lines("x")) == [(0, 1)]


def test_us07_wrapped_body_line_starting_with_a_figure_is_not_a_heading() -> None:
    page = (
        "1 Operational resilience\n"
        "1.1 Availability\n"
        "1.1.1 Service availability target\n"
        "A participant shall keep its service available at least\n"
        "99.9 percent of each calendar month.\n"
        "1.2 Incident reporting\n"
    )
    headings = find_pdf_headings([page], [0], set(), set())
    assert [heading.number for heading in headings] == ["1", "1.1", "1.1.1", "1.2"]


def test_us07_first_heading_must_start_the_numbering() -> None:
    page = "Edition 2026.1\n3 Something odd\n1 Scope\ntext\n1.1 Detail\n"
    headings = find_pdf_headings([page], [0], set(), set())
    assert [heading.number for heading in headings] == ["1", "1.1"]


def test_us07_toc_listed_clause_after_a_gap_is_still_found() -> None:
    page = "4.2.2 Amount limits\ntext\n4.2.4 Reference format\ntext\n"
    without = find_pdf_headings([page], [0], set(), set())
    with_toc = find_pdf_headings([page], [0], set(), {"4.2.4"})
    assert "4.2.4" not in [heading.number for heading in without]
    assert "4.2.4" in [heading.number for heading in with_toc]


def test_us07_table_of_contents_pages_are_skipped() -> None:
    pages = ["Contents\n1 Scope 2\n2 Terms 2\n", "1 Scope\ntext\n2 Terms\ntext\n"]
    toc, toc_pages = find_pdf_toc(pages)
    assert toc_pages == {0}
    headings = find_pdf_headings(pages, [0, len(pages[0]) + 1], toc_pages, {e.number for e in toc})
    assert [(heading.number, heading.page) for heading in headings] == [("1", 2), ("2", 2)]


def test_us07_toc_over_several_pages_is_read_until_the_body_starts() -> None:
    pages = [
        "Table of Contents\n1 Scope 3\n1.1 Aim 3\n",
        "2 Terms 3\n2.1 Words 3\n",
        "1 Scope\nThis is the first body page with prose.\nMore prose here.\n",
    ]
    toc, toc_pages = find_pdf_toc(pages)
    assert toc_pages == {0, 1}
    assert [entry.number for entry in toc] == ["1", "1.1", "2", "2.1"]
    assert [entry.page for entry in toc] == [3, 3, 3, 3]


def test_us07_pdf_without_table_of_contents_has_none() -> None:
    assert find_pdf_toc(["1 Scope\ntext\n"]) == ((), frozenset())


def test_us07_markdown_toc_pages_are_optional() -> None:
    toc = find_markdown_toc(
        "# T\n\n## Contents\n\n- 1 Scope ... 3\n  - 1.1 Aim\n\n## Body\n- 9 Late\n"
    )
    assert [(entry.number, entry.title, entry.page) for entry in toc] == [
        ("1", "Scope", 3),
        ("1.1", "Aim", None),
    ]


def test_us07_markdown_headings_inside_code_fences_are_ignored() -> None:
    text = "### 1 Scope\n\n```\n### 2 Not a heading\n```\n\n### 2 Terms\n"
    assert [heading.number for heading in find_markdown_headings(text)] == ["1", "2"]
    assert [heading.title for heading in find_markdown_headings(text)] == ["Scope", "Terms"]
