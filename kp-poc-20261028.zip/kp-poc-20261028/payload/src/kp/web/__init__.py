"""Server-rendered web UI of the knowledge platform (``kp web``).

Needs the ``web`` extra (``fastapi``, ``uvicorn``, ``jinja2``). This package is imported by the
command line without those installed, so nothing here imports them at import time; build the
application with :func:`kp.web.app.create_app`.

The pages read only through the application services and the read tools an agent uses, with the
signed-in user as the caller. See :mod:`kp.web.identity` for how the user is known.
"""
