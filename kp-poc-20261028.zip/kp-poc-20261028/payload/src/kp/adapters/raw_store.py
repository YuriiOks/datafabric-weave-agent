"""Seam: the sweep's raw store, backed by the mode's object storage.

The sweep keeps the exact bytes of every item version in a write-once store. Local mode uses a
folder under the data directory; the real route uses the raw bucket, through the same
write-once object store the connectivity harness proved. One function picks the store for the
mode, so every command that sweeps (and everything that reads a raw copy back) agrees.
"""

from __future__ import annotations

from kp.config import Mode, Settings
from kp.connectivity.errors import ImmutableObjectError
from kp.connectivity.ports import ObjectStore
from kp.connectivity.storage import BucketObjectStore, object_key
from kp.domain import ItemKey
from kp.errors import ConfigurationError
from kp.sweep import LocalRawStore, RawStore, RawStoreConflictError

RAW_FOLDER = "raw"


class ObjectRawStore:
    """The sweep's raw store port over a key-addressed object store.

    :param store: The object store (the raw bucket in the real route)
    """

    def __init__(self, store: ObjectStore) -> None:
        self._store = store

    def put(self, key: ItemKey, content: bytes) -> str:
        """Store the bytes once.

        :param key: The version the bytes belong to
        :param content: The raw bytes
        :return: The storage reference to record as the raw location
        :raises kp.sweep.RawStoreConflictError: If other bytes are already stored for the key
        :raises kp.connectivity.errors.InvalidObjectKeyError: If the key is not a safe path
        """
        name = object_key(key.source.value, key.item_id, key.version)
        try:
            self._store.put_if_absent(name, content)
        except ImmutableObjectError as exc:
            raise RawStoreConflictError("Raw location already holds different content") from exc
        return self._store.location(name)

    def get(self, location: str) -> bytes:
        """Read stored bytes back.

        :param location: A reference returned by :meth:`put`
        :return: The stored bytes
        :raises KeyError: If nothing is stored there
        """
        return self._store.get(self._store.key_of(location))


def choose_raw_store(settings: Settings, bucket: ObjectStore | None = None) -> RawStore:
    """Choose the raw store for the mode.

    :param settings: Platform settings
    :param bucket: The raw bucket's object store; built from ``KP_RAW_BUCKET`` when omitted
        (tests pass a stand-in)
    :return: The bucket in real mode, a folder under the data directory otherwise
    :raises kp.errors.ConfigurationError: If real mode has no raw bucket
    """
    if settings.mode is not Mode.REAL:
        return LocalRawStore(settings.data_dir / RAW_FOLDER)
    if bucket is not None:
        return ObjectRawStore(bucket)
    name = (settings.raw_bucket or "").strip()
    if not name:
        raise ConfigurationError("KP_RAW_BUCKET must be set in real mode")
    return ObjectRawStore(BucketObjectStore(name))
