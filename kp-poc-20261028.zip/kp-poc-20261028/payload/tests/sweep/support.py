"""Fakes and builders for the sweep tests: scripted readers, processor, raw store, sleeper."""

from __future__ import annotations

import json
from collections import deque
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import yaml
from pydantic import JsonValue
from sqlalchemy import Connection

from kp.domain import ItemKey, SourceItemVersion, SourceKind, Story, StoryLink
from kp.errors import SourceItemNotFoundError, SourceRateLimitedError, SourceUnavailableError
from kp.sources.base import ChangeBatch, ChangedItem, FetchedItem, ItemMetadata

JIRA_FIXTURE = "jira"


class ProcessorCrashError(RuntimeError):
    """Raised by the fake processor to simulate a run stopping halfway."""


def moment(text: str) -> datetime:
    """Parse an ISO timestamp, assuming UTC when it names no zone."""
    parsed = datetime.fromisoformat(text)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def entry(
    source: SourceKind,
    item_id: str,
    version: str,
    *,
    content: bytes | None = None,
    title: str | None = None,
    attributes: dict[str, JsonValue] | None = None,
    modified_at: str | None = None,
) -> tuple[ChangedItem, FetchedItem]:
    """Build one change and the item it fetches."""
    key = ItemKey(source=source, item_id=item_id, version=version)
    stamp = moment(modified_at) if modified_at else None
    body = content if content is not None else f"{item_id} v{version}".encode()
    metadata = ItemMetadata(
        native_id=item_id,
        media_type="text/markdown",
        title=title or item_id,
        modified_at=stamp,
        attributes=attributes or {},
    )
    return (
        ChangedItem(key=key, title=metadata.title, modified_at=stamp),
        FetchedItem(key=key, content=body, metadata=metadata),
    )


@dataclass
class ScriptedReader:
    """A source reader that serves a fixed script of changes in pages.

    :ivar honour_cursor: When False the reader ignores the cursor and lists everything
    :ivar faults: Exceptions raised, in order, by calls to ``list_changed``/``fetch``
    :ivar fault_after: Number of calls (of either kind) served normally before faults start
    """

    kind: SourceKind
    honour_cursor: bool = True
    entries: list[tuple[ChangedItem, FetchedItem | None]] = field(default_factory=list)
    faults: deque[Exception] = field(default_factory=deque)
    fault_after: int = 0
    list_calls: int = 0
    fetch_calls: int = 0

    def add(self, *entries: tuple[ChangedItem, FetchedItem]) -> None:
        """Append changes, as if the source changed after the last sweep."""
        self.entries.extend(entries)

    def add_deleted(self, source: SourceKind, item_id: str, version: str) -> None:
        """Append a removal notice."""
        key = ItemKey(source=source, item_id=item_id, version=version)
        self.entries.append((ChangedItem(key=key, deleted=True), None))

    def list_changed(self, cursor: str | None, *, limit: int = 100) -> ChangeBatch:
        """Serve the next page after ``cursor``."""
        self.list_calls += 1
        self._raise_fault()
        start = int(cursor) if cursor and self.honour_cursor else 0
        end = min(start + limit, len(self.entries))
        return ChangeBatch(
            items=tuple(change for change, _ in self.entries[start:end]),
            next_cursor=str(end),
            exhausted=end >= len(self.entries),
        )

    def fetch(self, key: ItemKey) -> FetchedItem:
        """Serve the content of one version."""
        self.fetch_calls += 1
        self._raise_fault()
        for _, fetched in reversed(self.entries):
            if fetched is not None and fetched.key == key:
                return fetched
        raise SourceItemNotFoundError("No such version")

    def fail_next(self, *errors: Exception, after_calls: int = 0) -> None:
        """Make calls raise ``errors`` in order, starting after ``after_calls`` more calls."""
        self.faults.extend(errors)
        self.fault_after = self.list_calls + self.fetch_calls + after_calls

    def _raise_fault(self) -> None:
        if self.faults and self.list_calls + self.fetch_calls > self.fault_after:
            raise self.faults.popleft()


def unavailable() -> SourceUnavailableError:
    """A source outage."""
    return SourceUnavailableError("Source unavailable")


def rate_limited(seconds: float) -> SourceRateLimitedError:
    """A request to wait ``seconds``."""
    return SourceRateLimitedError(seconds)


class MemoryRawStore:
    """Write-once raw store in memory."""

    def __init__(self) -> None:
        self.files: dict[str, bytes] = {}

    def put(self, key: ItemKey, content: bytes) -> str:
        """Store once; return the location."""
        location = f"{key.source.value}/{key.item_id}/{key.version}"
        self.files.setdefault(location, content)
        return location

    def get(self, location: str) -> bytes:
        """Read back."""
        return self.files[location]


class RecordingSleeper:
    """Records the waits it was asked for instead of sleeping."""

    def __init__(self) -> None:
        self.waits: list[float] = []

    def __call__(self, seconds: float) -> None:
        """Remember the wait."""
        self.waits.append(seconds)


def story_from_issue(content: bytes) -> Story:
    """Parse a Jira export issue (test-local stand-in for the real parser)."""
    issue = json.loads(content)
    fields = issue["fields"]
    parent = fields.get("parent")
    return Story(
        story_key=issue["key"],
        version=fields["updated"],
        summary=fields["summary"],
        description=fields.get("description", ""),
        acceptance_criteria=fields.get("acceptance_criteria", ""),
        links=tuple(
            StoryLink(link_type=link["type"], target_key=link["key"])
            for link in fields.get("issuelinks", [])
        ),
        parent_key=parent["key"] if parent else None,
        status=fields["status"]["name"],
    )


class FakeProcessor:
    """Records processed versions; fingerprints Jira stories like the real parser would."""

    def __init__(self) -> None:
        self.processed: list[ItemKey] = []
        self.crash_on: set[ItemKey] = set()

    def fingerprint(self, version: SourceItemVersion, content: bytes) -> str | None:
        """Story fingerprint for Jira items, ``None`` for everything else."""
        if version.source is not SourceKind.JIRA:
            return None
        return story_from_issue(content).fingerprint()

    def process(self, connection: Connection, version: SourceItemVersion, content: bytes) -> None:
        """Record the version, or crash on request."""
        if version.key in self.crash_on:
            raise ProcessorCrashError("Simulated stop")
        self.processed.append(version.key)

    def processed_ids(self, source: SourceKind) -> list[str]:
        """Item ids processed for one source, in order."""
        return [key.item_id for key in self.processed if key.source is source]


# Fixture readers -------------------------------------------------------------------------


def library_entries(root: Path) -> list[tuple[ChangedItem, FetchedItem]]:
    """Entries for the synthetic document library, with its metadata sidecars."""
    entries = []
    for meta_path in sorted((root / "library").glob("*.meta.json")):
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        body = meta_path.with_name(meta_path.name.replace(".meta.json", ".md")).read_bytes()
        attributes: dict[str, JsonValue] = {
            key: value for key, value in meta.items() if key not in {"item_id", "version"}
        }
        entries.append(
            entry(
                SourceKind.DOCUMENT_LIBRARY,
                meta["item_id"],
                meta["version"],
                content=body,
                title=meta["item_id"],
                attributes=attributes,
                modified_at=meta["modified_at"],
            )
        )
    return entries


def confluence_entries(root: Path) -> list[tuple[ChangedItem, FetchedItem]]:
    """Entries for the synthetic Confluence pages, one per page version."""
    entries = []
    for page_path in sorted((root / "confluence").glob("page-*.json")):
        page = json.loads(page_path.read_text(encoding="utf-8"))
        for version in page["versions"]:
            entries.append(
                entry(
                    SourceKind.CONFLUENCE,
                    page["id"],
                    str(version["number"]),
                    content=version["body"].encode(),
                    title=page["title"],
                    attributes={"labels": page["labels"], "state": version["state"]},
                    modified_at=version["modified"],
                )
            )
    return entries


def edition_entry(
    root: Path, label: str, *, merged: bool = True
) -> tuple[ChangedItem, FetchedItem]:
    """The entry for one edition of the synthetic regulatory repository."""
    folder = root / "regulatory_repo" / label
    meta = yaml.safe_load((folder / "edition.yaml").read_text(encoding="utf-8"))
    return entry(
        SourceKind.REGULATORY_REPO,
        "payments-rulebook",
        label,
        content=(folder / "payments-rulebook.md").read_bytes(),
        title="Payments Rulebook",
        attributes={"merged": merged, "effective_date": str(meta["effective_date"])},
    )


def jira_entries(root: Path, export: str) -> list[tuple[ChangedItem, FetchedItem]]:
    """Entries for every issue of one Jira export; version is the issue's update time."""
    data = json.loads((root / JIRA_FIXTURE / export).read_text(encoding="utf-8"))
    return [
        entry(
            SourceKind.JIRA,
            issue["key"],
            issue["fields"]["updated"],
            content=json.dumps(issue, sort_keys=True).encode(),
            title=issue["fields"]["summary"],
            modified_at=issue["fields"]["updated"],
        )
        for issue in data["issues"]
    ]


def governed_attributes(**overrides: str | None) -> dict[str, JsonValue]:
    """Attributes of a fully conforming, approved library document; override to break one."""
    attributes: dict[str, JsonValue] = {
        "approval_status": "approved",
        "document_type": "guide",
        "domain": "payments",
        "authority": "Example Scheme",
        "classification": "internal",
        "content_owner": "owner-role-payments",
    }
    attributes.update(overrides)
    return attributes


def keys_of(entries: Iterable[tuple[ChangedItem, FetchedItem]]) -> list[str]:
    """Item ids of entries, for assertions."""
    return [change.key.item_id for change, _ in entries]
