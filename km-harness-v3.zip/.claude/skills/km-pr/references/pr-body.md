# Pull request title and body: format

Read when pull request text is needed. The session drafts, then opens the pull request as a
draft (km-pr step 8, km-build 3b). Draft file: /home/user/km/work/builds/<task>-pr.md (title
on line 1, a blank line, then the body). ASCII only, lines of the body kept short. A section
not yet known says "pending"; never invent a result.

## Title

`[<EPIC-KEY>] [<TICKET-KEY>] Title`. Both keys come from the owner, the plan's Keys line or
kb/private/. If
either is unknown, push but do not open the pull request, and name the missing key; never
invent or copy a key from memory. The title is a plain
sentence-case phrase, no colon, no trailing period, under about 70 characters, no branch or
file names.

## Body, in this order

1. Ticket line: `Ticket: <TICKET-KEY>`. The key appears only here and in the title, never in
   code, comments, test names or commit text beyond what the owner asked for.
2. Optional callout first, only if the reviewer must know something before the diff: the
   branch depends on another open branch (name it, say which commits to skip), or main was
   merged in. Omit otherwise.
3. Problem. What a user or operator experiences today and why it hurts. One to three short
   paragraphs, product language, no module paths or class names.
4. Solution. What changes as behaviour. The last sentence says what stays unchanged.
5. How to verify. Numbered actions in the running product, each ending with what the
   reviewer should see. Include one negative case (missing, stale, malformed input, or a
   dependency down) with its expected result. Never imply a check that was not run.
6. Review focus. Two to four questions where judgment is needed ("Can this guard fire when
   the list is empty?"), not assertions.
7. Self-review. The checks actually run, in plain words with their real results, taken from
   work/builds/<task>.md and work/reviews/<task>.md: the full head sha they cover and the
   open-finding count (for example "Reviewed the final diff at <sha>: 2 blockers found,
   both fixed; 0 open"). No report path, no level numbers. If the review covers an older
   head than the branch head, write "stale" and say a re-run is needed. The report path
   goes to the owner in the reply, or under a "Not for the PR" line at the end of
   work/builds/<task>-pr.md, below the body, never in the body.
8. Checks. The state of the repository's automated checks for the exact head sha, or
   "pending" until they have reported. Name the head. "Passes locally" is not a check
   result; write only what a report or a command output showed.
9. `## Screenshots` last, only for a visible change (see screenshots.md).

Optional and rare: `## Not in this PR`, one line of why per item, only when "why not also
..." is predictable.

## Rules

- Draft by default. Ready for review is a separate go from the owner.
- One purpose per pull request; branch from the main line unless the code depends on another
  open branch. A mixed diff: say so and stop.
- No test counts, no "all green", no "verified" without a check report for that head.
- No attribution of any kind: no tool-credit line, no session link, no co-author line.
- Nothing local-only: no mention of the canon, kb, designs, work folder, skills, agents,
  plans or specs, and no text copied from them. Inline the reasoning instead.
- No credential, host name, address, staff id, email, customer or staff name. Roles only.
- No files table, no decisions list, no code excerpts, no diagrams, unless a mechanism
  changes (then one before and after pair).
- Refreshing a body later: start from the live body (`gh pr view <n> --json body`), because
  a replaced body loses images added in the browser. Edit with `gh pr edit <n> --body-file`.

## Skeleton

    [<EPIC-KEY>] [<TICKET-KEY>] Short sentence-case title

    Ticket: <TICKET-KEY>

    ## Problem
    ## Solution
    ## How to verify
    1. ... You should see ...
    2. Negative case: ... You should see ...
    ## Review focus
    - ...?
    ## Self-review
    - Checks run: ... Head: <40-char sha> Open: ...
    ## Checks
    - Head <short sha>: pending
