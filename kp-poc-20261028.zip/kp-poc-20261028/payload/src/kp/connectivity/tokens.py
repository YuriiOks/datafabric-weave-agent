"""Caller-identity tokens: acquire or reuse, refresh early, renew once after a refusal.

The gateway token lives about 30 minutes. A run may outlive it (exit criterion X-06), so the
renewal happens inside the call path: before a call when the token has used up
``TOKEN_REFRESH_FRACTION`` of its lifetime, and once more, forced, when the gateway answers 401.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Protocol

import httpx
from pydantic import SecretStr

from kp.clock import Clock
from kp.connectivity.errors import GatewayProtocolError
from kp.connectivity.http_status import BAD_REQUEST, FORBIDDEN, SERVER_ERROR
from kp.errors import SourceAuthRefusedError, SourceUnavailableError

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class AccessToken:
    """A bearer token with the facts needed to decide when to renew it.

    :ivar value: The secret token value; never logged.
    :ivar issued_at: When this process obtained it.
    :ivar lifetime_seconds: How long the issuer said it is valid.
    :ivar serial: Increases with every token a provider obtains; identifies a token.
    """

    value: SecretStr
    issued_at: datetime
    lifetime_seconds: float
    serial: int

    def is_due(self, now: datetime, fraction: float) -> bool:
        """Say whether ``fraction`` of the lifetime has been used up.

        :param now: The current time
        :param fraction: Share of the lifetime after which to renew, between 0 and 1
        :return: True when the token should be replaced before use
        """
        return (now - self.issued_at).total_seconds() >= self.lifetime_seconds * fraction


@dataclass(frozen=True, slots=True)
class TokenGrant:
    """A token handed to a caller, with whether getting it involved a renewal.

    :ivar token: The token to present.
    :ivar refreshed: True only when an existing token was replaced (early renewal or forced
        renewal). The very first sign-in of a provider is not a renewal.
    """

    token: AccessToken
    refreshed: bool


class TokenProvider(Protocol):
    """Source of the caller-identity token. Implementations must be thread-safe."""

    def acquire(self) -> TokenGrant:
        """Return a usable token, renewing first when it is due.

        :return: The token and whether this call replaced an existing one
        :raises kp.errors.SourceAuthRefusedError: If the issuer refuses the credentials
        :raises kp.errors.SourceUnavailableError: If the issuer cannot be reached
        """
        ...

    def force_refresh(self, rejected: AccessToken) -> TokenGrant:
        """Replace a token the gateway refused.

        If another caller already replaced ``rejected``, that newer token is returned and no
        second request is made to the issuer.

        :param rejected: The token that was refused
        :return: A token to retry with; ``refreshed`` is always true
        :raises kp.errors.SourceAuthRefusedError: If the issuer refuses the credentials
        :raises kp.errors.SourceUnavailableError: If the issuer cannot be reached
        """
        ...


class ClientCredentialsTokenProvider:
    """OAuth client-credentials grant against the configured token endpoint.

    :param http: The HTTP client used for the token endpoint
    :param token_url: The token endpoint
    :param client_id: The service identity
    :param client_secret: The service secret
    :param clock: Time source
    :param refresh_fraction: Share of the lifetime after which the token is renewed early
    """

    def __init__(
        self,
        *,
        http: httpx.Client,
        token_url: str,
        client_id: str,
        client_secret: SecretStr,
        clock: Clock,
        refresh_fraction: float,
    ) -> None:
        self._http = http
        self._token_url = token_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._clock = clock
        self._refresh_fraction = refresh_fraction
        self._lock = threading.Lock()
        self._token: AccessToken | None = None
        self._serial = 0

    def acquire(self) -> TokenGrant:
        """Return the current token, fetching or renewing it when needed.

        :return: The token and whether this call replaced an existing one; the first sign-in
            is not a renewal
        :raises kp.errors.SourceAuthRefusedError: If the issuer refuses the credentials
        :raises kp.errors.SourceUnavailableError: If the issuer cannot be reached
        """
        with self._lock:
            token = self._token
            if token is not None and not token.is_due(self._clock.now(), self._refresh_fraction):
                return TokenGrant(token, refreshed=False)
            return TokenGrant(self._fetch(), refreshed=token is not None)

    def force_refresh(self, rejected: AccessToken) -> TokenGrant:
        """Replace a refused token, unless someone else already did.

        :param rejected: The token the gateway refused
        :return: A token to retry with
        :raises kp.errors.SourceAuthRefusedError: If the issuer refuses the credentials
        :raises kp.errors.SourceUnavailableError: If the issuer cannot be reached
        """
        with self._lock:
            current = self._token
            if current is not None and current.serial != rejected.serial:
                return TokenGrant(current, refreshed=True)
            return TokenGrant(self._fetch(), refreshed=True)

    def _fetch(self) -> AccessToken:
        try:
            response = self._http.post(
                self._token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._client_id,
                    "client_secret": self._client_secret.get_secret_value(),
                },
            )
        except httpx.HTTPError as exc:
            raise SourceUnavailableError("Token endpoint could not be reached") from exc
        if BAD_REQUEST <= response.status_code <= FORBIDDEN:
            raise SourceAuthRefusedError("Token endpoint refused the client credentials")
        if response.status_code >= SERVER_ERROR:
            raise SourceUnavailableError("Token endpoint failed")
        token = self._parse(response)
        self._token = token
        logger.info(
            "Gateway token obtained",
            extra={"serial": token.serial, "lifetime_seconds": token.lifetime_seconds},
        )
        return token

    def _parse(self, response: httpx.Response) -> AccessToken:
        try:
            payload = response.json()
            value = payload["access_token"]
            lifetime = float(payload["expires_in"])
        except (ValueError, KeyError, TypeError) as exc:
            raise GatewayProtocolError("Token endpoint answered without a usable token") from exc
        if not isinstance(value, str) or not value or lifetime <= 0:
            raise GatewayProtocolError("Token endpoint answered without a usable token")
        self._serial += 1
        return AccessToken(
            value=SecretStr(value),
            issued_at=self._clock.now(),
            lifetime_seconds=lifetime,
            serial=self._serial,
        )


class FixedTokenProvider:
    """A provider that always hands out the same value; used to provoke a credential refusal.

    :param value: The token value to present
    :param clock: Time source
    """

    def __init__(self, value: SecretStr, clock: Clock) -> None:
        self._token = AccessToken(
            value=value, issued_at=clock.now(), lifetime_seconds=float("inf"), serial=1
        )

    def acquire(self) -> TokenGrant:
        """Return the fixed token.

        :return: The token, never marked as renewed
        """
        return TokenGrant(self._token, refreshed=False)

    def force_refresh(
        self,
        rejected: AccessToken,  # noqa: ARG002 - the protocol requires it; there is nothing to compare
    ) -> TokenGrant:
        """Return a fresh serial of the same value: there is nothing to renew.

        :param rejected: The token that was refused
        :return: The same value under a new serial
        """
        self._token = replace(self._token, serial=self._token.serial + 1)
        return TokenGrant(self._token, refreshed=True)
