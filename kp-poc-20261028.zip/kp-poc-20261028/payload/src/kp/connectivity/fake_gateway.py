"""In-process stand-in for the gateway, its token endpoint and the three tool servers.

Built on ``httpx.MockTransport`` so the real client code runs unchanged. It returns the
platform's shapes (JSON-RPC 2.0, ``tools/list`` and ``tools/call``, JSON or SSE framing) and
has switches for the situations the harness must survive: a token that stops working, a
permanent refusal, prose instead of objects, a rate limit, a missing entitlement.

The URLs are fixed fictional values; nothing is ever sent to a network.
"""

from __future__ import annotations

import json
import secrets
import threading
from collections.abc import Callable
from dataclasses import dataclass
from urllib.parse import parse_qs

import httpx
from pydantic import JsonValue

from kp.clock import Clock
from kp.connectivity.models import JsonObject
from kp.connectivity.stand_in_content import StandInData, build_stand_in_data

FAKE_BASE_URL = "http://gateway.stand-in"
FAKE_TOKEN_URL = "http://gateway.stand-in/oauth/token"  # noqa: S105 - a fictional address
FAKE_EXTRACTION_URL = "http://extraction.stand-in/extract"
FAKE_CLIENT_ID = "stand-in-client"
FAKE_CLIENT_SECRET = "stand-in-secret"  # noqa: S105 - accepted only by this fake
LOCAL_IDENTITY_HEADER = "x-caller-identity"
LOCAL_SOURCE_HEADER = "x-source-credential"
LOCAL_SOURCE_CREDENTIAL = "stand-in-source-credential"
DEFAULT_NAMESPACES = {"confluence": "confluence", "jira": "jira", "github": "github"}

_TOKEN_PATH = "/oauth/token"  # noqa: S105 - a URL path
_JSONRPC_INVALID_PARAMS = -32602
_JSONRPC_METHOD_NOT_FOUND = -32601


@dataclass(frozen=True)
class RecordedRequest:
    """One gateway request as the fake saw it."""

    namespace: str
    method: str
    tool: str | None
    arguments: JsonObject
    status: int


def _object(properties: list[str]) -> JsonObject:
    return {
        "type": "object",
        "properties": {name: {"type": "string"} for name in properties},
        "required": list(properties),
    }


_TOOLS: dict[str, dict[str, tuple[str, list[str]]]] = {
    "confluence": {
        "get_page": ("Read one page with its body.", ["page_id"]),
        "get_attachment": ("Read one attachment of a page.", ["page_id", "attachment_id"]),
    },
    "jira": {
        "get_issue": ("Read one issue with its fields.", ["issue_key"]),
        "get_attachment": ("Read one attachment of an issue.", ["issue_key", "attachment_id"]),
    },
    "github": {"get_file": ("Read one file at a ref.", ["repository", "path", "ref"])},
}


class FakeGateway:
    """The stand-in gateway.

    Switches are plain attributes or small methods; set them between calls.

    :param clock: The clock shared with the client, so token expiry is deterministic
    :param identity_header: Header the client sends the caller-identity token in
    :param source_header: Header the client sends the per-source credential in
    :param data: Content to serve; the nine default synthetic items when omitted
    :param token_lifetime_seconds: Lifetime of issued tokens
    :ivar sse: Answer in Server-Sent-Events framing instead of plain JSON.
    :ivar structured_content: Put the object in ``structuredContent`` as well as in the text.
    :ivar prose_namespaces: Namespaces whose ``tools/call`` answers return prose.
    :ivar forbidden_namespaces: Namespaces the caller is not entitled to (403).
    :ivar reject_all: Refuse every gateway request with 401, whatever the token.
    :ivar list_page_size: Paginate ``tools/list`` with this many tools per page.
    :ivar before_request: Called with the request count before each gateway request.
    :ivar requests: Every gateway request seen.
    :ivar token_requests: How many tokens have been issued.
    """

    def __init__(
        self,
        clock: Clock,
        *,
        identity_header: str = LOCAL_IDENTITY_HEADER,
        source_header: str = LOCAL_SOURCE_HEADER,
        data: StandInData | None = None,
        token_lifetime_seconds: float = 1800.0,
    ) -> None:
        self.data = data if data is not None else build_stand_in_data()
        self.sse = False
        self.structured_content = False
        self.prose_namespaces: set[str] = set()
        self.forbidden_namespaces: set[str] = set()
        self.reject_all = False
        self.list_page_size: int | None = None
        self.before_request: Callable[[int], None] | None = None
        self.requests: list[RecordedRequest] = []
        self.token_requests = 0
        self.token_lifetime_seconds = token_lifetime_seconds
        self._clock = clock
        self._identity_header = identity_header.lower()
        self._source_header = source_header.lower()
        self._lock = threading.Lock()
        self._tokens: dict[str, float] = {}
        self._rate_limited = 0
        self._retry_after = 1.0

    def transport(self) -> httpx.MockTransport:
        """Return the transport to build an ``httpx.Client`` on.

        :return: A transport that answers as the gateway and its token endpoint
        """
        return httpx.MockTransport(self._handle)

    def revoke_tokens(self) -> None:
        """Make every token issued so far invalid, as if the gateway had expired them."""
        with self._lock:
            self._tokens.clear()

    def rate_limit_next(self, count: int, retry_after: float = 1.0) -> None:
        """Answer the next ``count`` gateway requests with 429.

        :param count: How many requests to refuse
        :param retry_after: The wait, in seconds, the refusal asks for
        """
        self._rate_limited = count
        self._retry_after = retry_after

    def edit_page(self, page_id: str, body: str) -> None:
        """Change a page body and bump its version number.

        :param page_id: The page
        :param body: The new storage-format body
        """
        page = self.data.pages[page_id]
        version = page["version"]
        assert isinstance(version, dict)  # noqa: S101 - the stand-in builds this shape
        number = version["number"]
        assert isinstance(number, int)  # noqa: S101 - same stand-in shape
        version["number"] = number + 1
        page["body"] = {"storage": {"value": body}}

    def edit_issue(self, key: str, **fields: JsonValue) -> None:
        """Change fields of an issue.

        :param key: The issue key
        :param fields: Field names and new values
        """
        issue_fields = self.data.issues[key]["fields"]
        assert isinstance(issue_fields, dict)  # noqa: S101 - the stand-in builds this shape
        issue_fields.update(fields)

    def calls_for(self, namespace: str, tool: str) -> list[RecordedRequest]:
        """List the recorded ``tools/call`` requests for one tool.

        :param namespace: The route
        :param tool: The tool name
        :return: The matching requests
        """
        return [r for r in self.requests if r.namespace == namespace and r.tool == tool]

    # -- request handling ------------------------------------------------------------------

    def _handle(self, request: httpx.Request) -> httpx.Response:
        if request.url.path == _TOKEN_PATH:
            return self._issue_token(request)
        return self._gateway(request)

    def _issue_token(self, request: httpx.Request) -> httpx.Response:
        form = parse_qs(request.content.decode("utf-8"))
        ok = form.get("client_id") == [FAKE_CLIENT_ID] and form.get("client_secret") == [
            FAKE_CLIENT_SECRET
        ]
        if not ok:
            return httpx.Response(401, json={"error": "invalid_client"})
        with self._lock:
            self.token_requests += 1
            value = f"stand-in-token-{self.token_requests}-{secrets.token_hex(4)}"
            self._tokens[value] = self._clock.now().timestamp()
        return httpx.Response(
            200, json={"access_token": value, "expires_in": self.token_lifetime_seconds}
        )

    def _gateway(self, request: httpx.Request) -> httpx.Response:
        namespace = request.url.path.strip("/")
        body = json.loads(request.content)
        method = str(body.get("method"))
        params = body.get("params") if isinstance(body.get("params"), dict) else {}
        tool = params.get("name") if method == "tools/call" else None
        arguments = params.get("arguments", {}) if method == "tools/call" else {}
        status, response = self._decide(request, namespace, body, params)
        self.requests.append(
            RecordedRequest(
                namespace, method, tool if isinstance(tool, str) else None, arguments, status
            )
        )
        return response

    def _decide(
        self, request: httpx.Request, namespace: str, body: JsonObject, params: JsonObject
    ) -> tuple[int, httpx.Response]:
        if self.before_request is not None:
            self.before_request(len(self.requests) + 1)
        if self._rate_limited > 0:
            self._rate_limited -= 1
            return 429, httpx.Response(429, headers={"Retry-After": str(self._retry_after)})
        if self.reject_all or not self._token_is_valid(request):
            return 401, httpx.Response(401, json={"error": "invalid_token"})
        if namespace in self.forbidden_namespaces or not request.headers.get(self._source_header):
            return 403, httpx.Response(403, json={"error": "not entitled"})
        if namespace not in _TOOLS:
            return 404, httpx.Response(404, json={"error": "no such route"})
        message = self._dispatch(namespace, body, params)
        return 200, self._frame(message)

    def _token_is_valid(self, request: httpx.Request) -> bool:
        value = request.headers.get(self._identity_header, "").removeprefix("Bearer ")
        with self._lock:
            issued = self._tokens.get(value)
        return issued is not None and (
            self._clock.now().timestamp() - issued < self.token_lifetime_seconds
        )

    def _frame(self, message: JsonObject) -> httpx.Response:
        if not self.sse:
            return httpx.Response(200, json=message)
        notice = {"jsonrpc": "2.0", "method": "notifications/message", "params": {}}
        text = "".join(
            f"event: message\ndata: {json.dumps(event)}\n\n" for event in (notice, message)
        )
        return httpx.Response(200, headers={"Content-Type": "text/event-stream"}, content=text)

    def _dispatch(self, namespace: str, body: JsonObject, params: JsonObject) -> JsonObject:
        request_id = body.get("id")
        method = body.get("method")
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": request_id, "result": self._list(namespace, params)}
        if method == "tools/call":
            result = self._call(namespace, params)
            if result is None:
                return _rpc_error(request_id, _JSONRPC_INVALID_PARAMS, "invalid params")
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
        return _rpc_error(request_id, _JSONRPC_METHOD_NOT_FOUND, "method not found")

    def _list(self, namespace: str, params: JsonObject) -> JsonObject:
        tools: list[JsonValue] = [
            {"name": name, "description": description, "inputSchema": _object(required)}
            for name, (description, required) in _TOOLS[namespace].items()
        ]
        size = self.list_page_size
        if size is None:
            return {"tools": tools}
        cursor = params.get("cursor")
        start = int(cursor) if isinstance(cursor, str) else 0
        page = tools[start : start + size]
        result: JsonObject = {"tools": page}
        if start + size < len(tools):
            result["nextCursor"] = str(start + size)
        return result

    def _call(self, namespace: str, params: JsonObject) -> JsonObject | None:
        name = params.get("name")
        arguments = params.get("arguments")
        spec = _TOOLS[namespace].get(name) if isinstance(name, str) else None
        if spec is None or not isinstance(arguments, dict):
            return None
        if any(not isinstance(arguments.get(arg), str) for arg in spec[1]):
            return None
        found = self._lookup(namespace, str(name), arguments)
        if found is None:
            return {"isError": True, "content": [{"type": "text", "text": "not found"}]}
        if namespace in self.prose_namespaces:
            return {"content": [{"type": "text", "text": _prose(found)}]}
        result: JsonObject = {"content": [{"type": "text", "text": json.dumps(found)}]}
        if self.structured_content:
            result["structuredContent"] = found
        return result

    def _lookup(self, namespace: str, tool: str, arguments: JsonObject) -> JsonObject | None:
        data = self.data
        args = {key: str(value) for key, value in arguments.items()}
        if (namespace, tool) == ("confluence", "get_page"):
            return data.pages.get(args["page_id"])
        if (namespace, tool) == ("confluence", "get_attachment"):
            return data.page_attachments.get((args["page_id"], args["attachment_id"]))
        if (namespace, tool) == ("jira", "get_issue"):
            return data.issues.get(args["issue_key"])
        if (namespace, tool) == ("jira", "get_attachment"):
            return data.issue_attachments.get((args["issue_key"], args["attachment_id"]))
        return data.files.get((args["repository"], args["path"], args["ref"]))


def _prose(found: JsonObject) -> str:
    title = found.get("title") or found.get("path") or found.get("key") or "the item"
    return f"I found {title}. It is a short document about payment handling and it looks fine."


def _rpc_error(request_id: JsonValue, code: int, message: str) -> JsonObject:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}
