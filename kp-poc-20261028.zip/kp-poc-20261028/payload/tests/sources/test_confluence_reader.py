"""Confluence-like reader: US-01 (label, approved version only, draft never surfaces)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from kp.domain.enums import SourceKind
from kp.errors import SourceItemNotFoundError
from kp.sources import ConfluenceExportReader, MalformedSourceDataError
from kp.sources import attributes as attr
from kp.testing.dataset import SyntheticDataset

from .support import drain, ids, key, write_json

CONFLUENCE = SourceKind.CONFLUENCE


def _reader(data_root: Path, label: str = "approved") -> ConfluenceExportReader:
    return ConfluenceExportReader(data_root / "confluence", approved_label=label)


def test_us01_only_the_newest_published_version_of_a_page_is_listed(data_root: Path) -> None:
    items, _ = drain(_reader(data_root))

    assert ids(items) == {("page-1001", "1"), ("page-1002", "1"), ("page-1003", "2")}


def test_us01_a_newer_draft_never_surfaces_in_listing_or_fetch(
    data_root: Path, dataset: SyntheticDataset
) -> None:
    reader = _reader(data_root)
    page = dataset.truth.confluence.page_with_newer_draft
    export = json.loads((data_root / "confluence" / f"{page}.json").read_text(encoding="utf-8"))
    drafts = [v for v in export["versions"] if v["state"] == "draft"]

    assert drafts
    for draft in drafts:
        with pytest.raises(SourceItemNotFoundError):
            reader.fetch(key(CONFLUENCE, page, str(draft["number"])))
    items, _ = drain(reader)
    bodies = [reader.fetch(item.key).content.decode("utf-8") for item in items]
    assert all(draft["body"] not in bodies for draft in drafts)
    listed = {item.key.version for item in items if item.key.item_id == page}
    assert listed == {str(max(v["number"] for v in export["versions"] if v["state"] != "draft"))}


def test_us01_the_approved_version_body_is_returned_unaltered(data_root: Path) -> None:
    fetched = _reader(data_root).fetch(key(CONFLUENCE, "page-1003", "2"))

    assert fetched.content == b"# Reconciliation\n\nv2."
    assert fetched.metadata.title == "Reconciliation procedure"
    assert fetched.metadata.attributes[attr.PAGE_VERSION] == 2
    assert fetched.metadata.attributes[attr.WORKFLOW_STATE] == "published"


def test_us01_page_with_the_agreed_label_is_marked_as_having_it(data_root: Path) -> None:
    attributes = _reader(data_root).fetch(key(CONFLUENCE, "page-1001", "1")).metadata.attributes

    assert attributes[attr.HAS_REQUIRED_LABEL] is True
    assert attributes[attr.REQUIRED_LABEL] == "approved"
    assert attributes[attr.LABELS] == ["approved", "payments"]


def test_us01_page_without_the_label_is_listed_flagged_so_it_can_be_recorded_pending(
    data_root: Path, dataset: SyntheticDataset
) -> None:
    page = dataset.truth.confluence.unlabelled_page

    attributes = _reader(data_root).fetch(key(CONFLUENCE, page, "1")).metadata.attributes

    assert attributes[attr.HAS_REQUIRED_LABEL] is False
    assert attributes[attr.LABELS] == ["payments"]


def test_us01_the_agreed_label_is_a_setting(data_root: Path) -> None:
    reader = _reader(data_root, label="reviewed")

    items, _ = drain(reader)

    assert all(
        reader.fetch(item.key).metadata.attributes[attr.HAS_REQUIRED_LABEL] is False
        for item in items
    )


def test_us01_label_added_later_shows_the_page_as_changed(data_root: Path) -> None:
    reader = _reader(data_root)
    _, cursor = drain(reader)
    path = data_root / "confluence" / "page-1002.json"
    page = json.loads(path.read_text(encoding="utf-8"))
    page["labels"].append("approved")
    write_json(path, page)

    items, _ = drain(reader, cursor)

    assert ids(items) == {("page-1002", "1")}
    assert reader.fetch(items[0].key).metadata.attributes[attr.HAS_REQUIRED_LABEL] is True


def test_us01_draft_later_published_is_a_new_version_and_the_old_one_is_not_deleted(
    data_root: Path,
) -> None:
    reader = _reader(data_root)
    _, cursor = drain(reader)
    path = data_root / "confluence" / "page-1003.json"
    page = json.loads(path.read_text(encoding="utf-8"))
    page["versions"][2]["state"] = "published"
    write_json(path, page)

    items, _ = drain(reader, cursor)

    assert [(item.key.item_id, item.key.version, item.deleted) for item in items] == [
        ("page-1003", "3", False)
    ]


def test_us01_page_with_only_drafts_is_not_listed(data_root: Path) -> None:
    write_json(
        data_root / "confluence" / "page-2001.json",
        {
            "id": "page-2001",
            "title": "Only a draft",
            "labels": ["approved"],
            "versions": [
                {
                    "number": 1,
                    "state": "draft",
                    "modified": "2026-10-03T09:00:00+00:00",
                    "body": "secret draft",
                }
            ],
        },
    )

    items, _ = drain(_reader(data_root))

    assert "page-2001" not in {item.key.item_id for item in items}


def test_us04_removed_page_is_reported_deleted(data_root: Path) -> None:
    reader = _reader(data_root)
    _, cursor = drain(reader)

    (data_root / "confluence" / "page-1001.json").unlink()
    items, _ = drain(reader, cursor)

    assert [(item.key.item_id, item.deleted) for item in items] == [("page-1001", True)]


@pytest.mark.parametrize("label", ["Approved", "APPROVED"])
def test_us01_label_match_ignores_case_as_the_gate_does(data_root: Path, label: str) -> None:
    path = data_root / "confluence" / "page-1002.json"
    page = json.loads(path.read_text(encoding="utf-8"))
    page["labels"].append(label)
    write_json(path, page)

    attributes = _reader(data_root).fetch(key(CONFLUENCE, "page-1002", "1")).metadata.attributes

    assert attributes[attr.HAS_REQUIRED_LABEL] is True
    assert attributes[attr.LABELS] == sorted(["payments", label])


def test_us01_the_workflow_state_uses_the_key_the_gate_reads(data_root: Path) -> None:
    attributes = _reader(data_root).fetch(key(CONFLUENCE, "page-1001", "1")).metadata.attributes

    assert attr.WORKFLOW_STATE == "state"
    assert attributes["state"] == "published"


def test_us01_page_export_with_the_wrong_shape_raises_instead_of_hiding_the_page(
    data_root: Path,
) -> None:
    write_json(data_root / "confluence" / "page-9.json", {"id": "page-9", "versions": "none"})

    with pytest.raises(MalformedSourceDataError):
        drain(_reader(data_root))


def test_us01_page_export_that_is_not_json_raises(data_root: Path) -> None:
    (data_root / "confluence" / "page-9.json").write_text("{broken", encoding="utf-8")

    with pytest.raises(MalformedSourceDataError):
        drain(_reader(data_root))
