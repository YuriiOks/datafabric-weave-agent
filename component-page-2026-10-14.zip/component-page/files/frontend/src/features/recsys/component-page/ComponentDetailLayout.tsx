import type { CSSProperties } from 'react'
import { DetailHero } from './DetailHero'
import { DetailStatTiles } from './DetailStatTiles'
import { DetailsCard } from './DetailsCard'
import { EligibilityPanel } from './EligibilityPanel'
import { MarkdownViewer } from './MarkdownViewer'
import type { ComponentPageModel } from './model'
import { RelatedColumn } from './RelatedColumn'
import { SourceCard } from './SourceCard'
import { emptyBoxStyle, sectionCardStyle, sectionHeaderStyle, sectionLabelStyle } from './styles'
import { useWideLayout } from './useWideLayout'

type Props = {
  model: ComponentPageModel
  /** Where "Back" goes; defaults to the registry. */
  backTo?: string | undefined
  backLabel?: string | undefined
  /** Route of the Recommend page for a need like this one. */
  recommendTo?: string | undefined
  onRecommend?: (() => void) | undefined
}

/**
 * A registry component's own page. Wide screens get the hero, four summary tiles and two columns
 * (definition and details on the left; eligibility, source and related components on the right).
 * Phones get one column: the hero, eligibility with the action, the grouped details table, the
 * source, the definition and the related components.
 */
export function ComponentDetailLayout({
  model,
  backTo = '/registry',
  backLabel = 'Back to registry',
  recommendTo,
  onRecommend,
}: Props) {
  const wide = useWideLayout()
  const definition = <Definition model={model} idPrefix={wide ? 'md' : 'md-m'} />
  const eligibility = (
    <EligibilityPanel model={model} wide={wide} recommendTo={recommendTo} onRecommend={onRecommend} />
  )

  if (!wide) {
    return (
      <div style={{ ...columnStyle, gap: 'var(--space-4)' }} data-layout="narrow">
        <DetailHero model={model} wide={false} backTo={backTo} backLabel={backLabel} />
        {eligibility}
        <DetailsCard model={model} variant="grouped" />
        <SourceCard source={model.source} stacked />
        {definition}
        <RelatedColumn relations={model.relations} />
      </div>
    )
  }

  return (
    <div style={{ ...columnStyle, gap: 'var(--space-5)' }} data-layout="wide">
      <DetailHero model={model} wide backTo={backTo} backLabel={backLabel} />
      <DetailStatTiles model={model} />
      <div style={twoColumnStyle}>
        <div style={columnStyle}>
          {definition}
          <DetailsCard model={model} variant="details" />
        </div>
        <aside style={columnStyle} aria-label="Eligibility, source and related components">
          {eligibility}
          <SourceCard source={model.source} />
          <RelatedColumn relations={model.relations} />
        </aside>
      </div>
    </div>
  )
}

function Definition({ model, idPrefix }: { model: ComponentPageModel; idPrefix: string }) {
  if (model.definition) {
    return (
      <MarkdownViewer
        markdown={model.definition.markdown}
        path={model.definition.path ?? model.source.path}
        sourceUrl={model.source.url}
        idPrefix={idPrefix}
      />
    )
  }
  return (
    <section style={sectionCardStyle} aria-label="Definition">
      <div style={sectionHeaderStyle}>
        <h2 style={sectionLabelStyle}>Definition</h2>
      </div>
      <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        <div style={emptyBoxStyle}>Full definition not available yet.</div>
        {model.description && (
          <p style={{ margin: 0, fontSize: 'var(--text-sm)', lineHeight: 1.6, color: 'var(--color-text-primary)' }}>
            {model.description}
          </p>
        )}
      </div>
    </section>
  )
}

const columnStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-4)',
  minWidth: 0,
}

const twoColumnStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'minmax(0, 1fr) minmax(300px, 360px)',
  gap: 'var(--space-5)',
  alignItems: 'start',
}
