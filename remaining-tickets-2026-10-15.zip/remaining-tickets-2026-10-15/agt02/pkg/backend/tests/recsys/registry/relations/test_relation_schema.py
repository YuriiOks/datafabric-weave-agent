"""The relation DDL is additive, pinned to the contract and fully reversible.

Static checks only; the database round trip runs in
``tests/recsys/catalogue/test_schema.py``, which applies the reversal script before
re-creating the schema.
"""

from __future__ import annotations

import inspect
import unittest
from pathlib import Path

from app.recsys.contracts import LinkType, ResolutionOutcome
from app.recsys.db import schema
from app.recsys.db.relation_schema import (
    LINK_TYPE_VALUES,
    RELATION_ALTERS,
    RELATION_INDEXES,
    RELATION_SCHEMA,
    RELATION_TABLE_NAMES,
    RESOLUTION_OUTCOME_VALUES,
)

REVERSAL = Path(__file__).resolve().parents[5] / "docs" / "recsys" / "catalogue-reversal.sql"
ALL_DDL = (*RELATION_ALTERS, *RELATION_SCHEMA, *RELATION_INDEXES)


class RelationSchemaTests(unittest.TestCase):
    def test_the_spelled_out_values_match_the_enums(self):
        self.assertEqual(len(LINK_TYPE_VALUES), len(set(LINK_TYPE_VALUES)))
        self.assertEqual(set(LINK_TYPE_VALUES), {item.value for item in LinkType})
        self.assertEqual(
            len(RESOLUTION_OUTCOME_VALUES), len(set(RESOLUTION_OUTCOME_VALUES))
        )
        self.assertEqual(
            set(RESOLUTION_OUTCOME_VALUES), {item.value for item in ResolutionOutcome}
        )

    def test_every_value_is_spelled_out_in_each_check(self):
        table = RELATION_SCHEMA[0]
        ledger_outcome, ledger_link_type = RELATION_ALTERS[2], RELATION_ALTERS[4]
        for value in LINK_TYPE_VALUES:
            with self.subTest(value=value):
                self.assertIn(f"'{value}'", table)
                self.assertIn(f"'{value}'", ledger_link_type)
        for value in RESOLUTION_OUTCOME_VALUES:
            with self.subTest(value=value):
                self.assertIn(f"'{value}'", table)
                self.assertIn(f"'{value}'", ledger_outcome)

    def test_the_evidence_table_cascades_with_its_link(self):
        table = RELATION_SCHEMA[0]
        self.assertIn(
            "REFERENCES recsys_component_link (catalogue_version, src_id, dst_id, link_type)",
            table,
        )
        self.assertIn("ON DELETE CASCADE", table)
        for name in RELATION_TABLE_NAMES:
            with self.subTest(table=name):
                # The writer tests assert by prefix that nothing deletes link rows.
                self.assertFalse(name.startswith("recsys_component_link"))

    def test_every_change_is_additive(self):
        for statement in RELATION_ALTERS:
            with self.subTest(statement=statement):
                self.assertIn("ADD COLUMN IF NOT EXISTS", statement)
        for statement in ALL_DDL:
            with self.subTest(statement=statement):
                self.assertIn("IF NOT EXISTS", statement)
                self.assertNotIn("DROP", statement.upper())

    def test_ensure_schema_runs_the_relation_ddl(self):
        source = inspect.getsource(schema.ensure_schema)
        for name in ("RELATION_ALTERS", "RELATION_SCHEMA", "RELATION_INDEXES"):
            with self.subTest(name=name):
                self.assertIn(name, source)

    def test_the_reversal_removes_everything_added_here(self):
        sql = REVERSAL.read_text(encoding="utf-8")
        body = sql[sql.index("BEGIN;") : sql.index("COMMIT;")]
        for name in RELATION_TABLE_NAMES:
            with self.subTest(table=name):
                self.assertIn(f"DROP TABLE IF EXISTS {name};", body)
        for column in ("relation_key", "evidence_digest"):
            with self.subTest(column=column):
                self.assertIn(
                    f"ALTER TABLE recsys_component_link DROP COLUMN IF EXISTS {column};",
                    body,
                )
        self.assertNotIn("CASCADE", sql.upper())


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
