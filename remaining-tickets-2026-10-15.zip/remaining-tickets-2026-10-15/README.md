# Remaining tickets: five change packages, four pull requests

Each package has `apply.sh`, an apply script, the files under `pkg/` and a `PR-BODY.md`.
The apply scripts are harness files: never commit them, and never commit this README.

Every apply script checks the branch name, a clean worktree and every anchor or
prerequisite file before it writes anything. One problem writes nothing. The scripts never
stage, commit, push or run tests; CI runs the tests after the push.

## Order and branches

| # | Package | Ticket | Branch | Cut from | Pull request |
|---|---|---|---|---|---|
| 1 | `agt02` | DTAA-1486 | `feat/agt-02-relations` (exists) | `main` | A, base `main` |
| 2 | `fnd14` | DTAA-1487 | `feat/agt-02-relations`, after committing 1 | - | A |
| 3 | `fnd16` | DTAA-1495 | `feat/fnd-16-acceptance-matrix` | committed `feat/agt-02-relations` | B, base `feat/agt-02-relations` |
| 4 | `skl04` | DTAA-1489 | `feat/skl-04-casepack` | `main` | C, base `main` |
| 5 | `mcp04` | DTAA-1490 | `feat/mcp-04-cases` | committed `feat/skl-04-casepack` | D, base `feat/skl-04-casepack` |

Pull request A carries both relation and refresh work. The two packages touch different
files. Title: `DTAA-1486, DTAA-1487: Publish evidence-backed agent relations and integrate
the source set with refresh`. Body: `PR-BODY-agt02-fnd14.md`.

Two PRs instead of A: cut `feat/fnd-14-source-set` from `main` for package 2, cut
package 3 from it, and use each package's own `PR-BODY.md`. That keeps the schema change
and the runtime wiring separately reviewable and revertible.

`fnd16` refuses to apply unless the refresh integration files are committed, and `mcp04`
refuses unless the case-pack files are committed.

## Steps

```bash
sha256sum -c SHA256SUMS                      # inside the unzipped folder
bash agt02/apply.sh <agt-02 worktree>        # --check first, then the write
git -C <agt-02 worktree> status -s           # review the diff before staging
# commit 1, then on the same worktree:
bash fnd14/apply.sh <agt-02 worktree>
git -C <main checkout> worktree add -b feat/fnd-16-acceptance-matrix <path> feat/agt-02-relations
bash fnd16/apply.sh <path>
git -C <main checkout> worktree add -b feat/skl-04-casepack <path> origin/main
bash skl04/apply.sh <path>
# commit 4, then:
git -C <main checkout> worktree add -b feat/mcp-04-cases <path> feat/skl-04-casepack
bash mcp04/apply.sh <path>
```

PR titles: `DTAA-<n>: <title>`. A stacked PR whose base is a feature branch may not get
the main-branch CI lane. Retarget it to `main` once the parent merges.

## Testing map

| Package | CI tests | Check by hand once merged |
|---|---|---|
| `agt02` | `tests/recsys/registry/relations/` | Evidence command on the pre-production export: declared = accepted + unresolved per link type |
| `fnd14` | `tests/recsys/refresh/test_integration_*.py` | Startup refuses outside pre-production; with the flag off, startup is unchanged |
| `fnd16` | `tests/recsys/qualification/` | `render_matrix(ACCEPTANCE_MATRIX)`: 35 requirements, none passed |
| `skl04` | `tests/recsys/eval/test_casepack_*.py` | A denominator report never shows a failed case as valid empty |
| `mcp04` | `tests/recsys/eval/test_casepack_mcp.py`, `test_casepack_release.py` | Release evidence lists the open approvals as blockers |

## Known blockers (in the PR bodies)

- A real refresh cannot reach a validated candidate yet. The skills registration declares
  its ordering unknown, and both registrations claim skill content.
- Every case in the case packs is synthetic and unjudged.
- Publication reads are not mounted.
