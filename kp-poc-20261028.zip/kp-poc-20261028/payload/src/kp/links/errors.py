"""Errors raised by the link store and the queries on it."""

from __future__ import annotations

from kp.errors import KpError


class LinkError(KpError):
    """Base class of failures in the links package."""


class LinkModelViolationError(LinkError, ValueError):
    """A candidate link does not conform to the seven-relation model."""


class LinkNotFoundError(LinkError):
    """No link with the requested identity exists."""


class NoEditionInForceError(LinkError):
    """No rulebook edition was in force on the requested date.

    Rules are never read from another edition as a fallback; the caller reports this.
    """


class UnknownClauseError(LinkError):
    """A clause reference names no loaded clause and no link mentions it."""


class SimilarityPortError(LinkError):
    """The similarity port returned something the scorer cannot use."""


class UnknownEditionError(LinkError):
    """A rulebook edition was named that is not loaded."""
