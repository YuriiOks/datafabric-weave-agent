"""Ports: what the write side needs from the outside world, and the shape it serves.

Each port is a small ``typing.Protocol``. Real implementations live here when they only need
HTTP, git or the shared tables (publishers, Jira clients); capabilities owned by other lanes
(search, links, session ledger) are reached through these ports and wired by the integrator.

The three ``WriteTool*`` models mirror field for field the write port the agent-tool lane
defines (``describe`` / ``invoke``), so the integrator's adapter is a one-line conversion.
"""

from __future__ import annotations

from collections.abc import Sequence
from collections.abc import Set as AbstractSet
from datetime import date
from typing import Annotated, Protocol, runtime_checkable

from pydantic import Field, JsonValue

from kp.domain import DomainModel, Story, Template, ToolCallRecord
from kp.writeback.models import (
    JiraApplied,
    JiraStoryUpdate,
    MergeResult,
    PublishRequest,
    PublishResult,
)


class SpecPublisher(Protocol):
    """Commits a spec to a branch and opens (or finds) its pull request."""

    def publish(self, request: PublishRequest) -> PublishResult:
        """Publish the spec.

        Idempotent: the same branch always means the same pull request, and an identical
        re-publish adds no commit and no second pull request.

        :param request: A request whose repository, path and branch passed the write limits
        :return: The pull request and commit
        :raises kp.writeback.errors.PublishError: If the target could not be written
        :raises kp.errors.WriteNotPermittedError: If the request targets the publisher's
            base branch or a repository other than its own
        """
        ...


@runtime_checkable
class SpecMerger(Protocol):
    """Merges a spec's pull request into the base branch.

    In the real route a reviewer does this on the repository host; the stand-in publishers
    offer it so the local build can follow a spec all the way back in as knowledge.
    """

    def merge(self, branch: str) -> MergeResult:
        """Merge the pull request of a branch. Idempotent: a merged branch stays merged.

        :param branch: The branch the spec was published on
        :return: The merge, with its date
        :raises kp.writeback.errors.PublishError: If the branch has no open pull request
        """
        ...


class JiraUpdater(Protocol):
    """Moves a story to "Spec drafted" and sets the pull request link. Nothing else."""

    def apply(self, update: JiraStoryUpdate) -> JiraApplied:
        """Apply the update. Idempotent: an already-moved story is not moved again.

        :param update: The status and the single link field to set
        :return: What changed
        :raises kp.writeback.errors.JiraTransientError: If Jira is unreachable or failing
        :raises kp.writeback.errors.JiraUpdateError: If Jira refused the request
        """
        ...


class SessionRetrievals(Protocol):
    """The references an agent session has retrieved through the read tools."""

    def references(self, session_id: str, caller: str) -> AbstractSet[str]:
        """List what the session retrieved.

        A session belongs to the caller that opened it: another caller who names the same
        session is a different session and sees none of it.

        :param session_id: The agent session
        :param caller: The authenticated user the session belongs to
        :return: Canonical references (``<edition>:<number>`` or a requirement id)
        """
        ...


class AuditSink(Protocol):
    """Where tool call records go (same shape as the read lane's sink)."""

    def record(self, record: ToolCallRecord) -> None:
        """Persist one record.

        :param record: The call to record, refusals included
        """
        ...


class EvidenceItem(DomainModel):
    """A retrieved passage a draft may rely on.

    :ivar reference: Canonical clause reference or requirement id.
    :ivar proposed: True when the item reached the story through a guessed (proposed) link.
    """

    reference: str
    text: str
    proposed: bool = False


class Retrieval(DomainModel):
    """Everything retrieved for one story.

    :ivar notes: Problems found while retrieving (an edition not in force, a dangling link).
    """

    evidence: tuple[EvidenceItem, ...] = ()
    notes: tuple[str, ...] = ()


class Retriever(Protocol):
    """Finds the material a story's spec should rest on."""

    def retrieve(self, story: Story, *, as_at: date) -> Retrieval:
        """Retrieve rules and register rows for a story.

        :param story: The story to draft for
        :param as_at: The date the rules are read at
        :return: Evidence (every item counts as retrieved in the session) and notes
        """
        ...


class CoverageLookup(Protocol):
    """Tells which tests are linked to a rule."""

    def tests_for(self, reference: str) -> Sequence[str]:
        """List the tests reachable from a rule or register row.

        :param reference: Canonical clause reference or requirement id
        :return: Test keys; empty when the rule has no linked test
        """
        ...


class DraftRequest(DomainModel):
    """Input of a drafter: the story, the governed template and what was retrieved."""

    story: Story
    template: Template
    retrieval: Retrieval
    tests_by_reference: dict[str, tuple[str, ...]] = Field(default_factory=dict)


class DraftedSpec(DomainModel):
    """A drafted spec ready for ``publish_spec``."""

    template_id: str
    template_version: str
    markdown: str
    coverage: dict[str, JsonValue] = Field(default_factory=dict)
    open_items: tuple[str, ...] = ()


class Drafter(Protocol):
    """Drafts a spec from a template and retrieved material. A model can plug in here."""

    def draft(self, request: DraftRequest) -> DraftedSpec:
        """Draft the spec.

        :param request: Story, template, retrieved evidence and coverage
        :return: The spec markdown with its coverage and open items
        """
        ...


class WriteToolDescriptor(DomainModel):
    """Name, description and JSON input schema of one write tool."""

    name: str
    description: str
    input_schema: dict[str, JsonValue]


class WriteToolCall(DomainModel):
    """One write call as the transport hands it over. Identity comes from the transport."""

    tool: str
    arguments: dict[str, JsonValue]
    caller: str
    agent: str
    session_id: str
    domains: tuple[str, ...] = ()


class WriteToolResult(DomainModel):
    """What a write tool reports back.

    :ivar spec_id: The spec the call acted on, so the audit trail can be listed from it.
    """

    payload: dict[str, JsonValue]
    items_returned: Annotated[int, Field(ge=0)] = 0
    spec_id: str | None = None
