"""US-25: the sample items file: nine items, three per source, fixed in configuration."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import pytest
import yaml

from kp.connectivity import SampleItemsError, default_sample_items_path, load_sample_items
from kp.connectivity.models import SampleKind
from kp.domain import SourceKind


def _write(tmp_path: Path, items: list[dict[str, object]]) -> Path:
    path = tmp_path / "items.yaml"
    path.write_text(yaml.safe_dump({"items": items}), encoding="utf-8")
    return path


def _valid_items() -> list[dict[str, object]]:
    document = yaml.safe_load(default_sample_items_path().read_text(encoding="utf-8"))
    items: list[dict[str, object]] = document["items"]
    return items


def test_us25_shipped_sample_file_has_nine_items_three_per_source() -> None:
    samples = load_sample_items(default_sample_items_path())

    assert len(samples.items) == 9
    assert Counter(item.source for item in samples.items) == {
        SourceKind.CONFLUENCE: 3,
        SourceKind.JIRA: 3,
        SourceKind.GITHUB: 3,
    }
    kinds = {item.item_id: item.kind for item in samples.items}
    assert kinds["conf-pdf"] is SampleKind.ATTACHMENT
    assert kinds["jira-word"] is SampleKind.ATTACHMENT
    assert all(item.media_type for item in samples.items)
    assert {item.ref for item in samples.for_source(SourceKind.GITHUB)} == {
        "0123456789abcdef0123456789abcdef01234567"
    }


def test_us25_a_file_with_the_wrong_split_is_rejected(tmp_path: Path) -> None:
    items = [item for item in _valid_items() if item["item_id"] != "gh-excel"]

    with pytest.raises(SampleItemsError, match="3 items per source"):
        load_sample_items(_write(tmp_path, items))


def test_us25_duplicate_ids_are_rejected(tmp_path: Path) -> None:
    items = _valid_items()
    items[1]["item_id"] = items[0]["item_id"]

    with pytest.raises(SampleItemsError, match="unique"):
        load_sample_items(_write(tmp_path, items))


@pytest.mark.parametrize("bad_id", ["../x", "a/b", "", "-leading", "a b"])
def test_us25_item_ids_cannot_escape_the_storage_key(tmp_path: Path, bad_id: str) -> None:
    items = _valid_items()
    items[0]["item_id"] = bad_id

    with pytest.raises(SampleItemsError):
        load_sample_items(_write(tmp_path, items))


def test_us25_an_attachment_needs_its_parent(tmp_path: Path) -> None:
    items = _valid_items()
    for item in items:
        if item["item_id"] == "conf-pdf":
            del item["parent_native_id"]

    with pytest.raises(SampleItemsError, match="parent_native_id"):
        load_sample_items(_write(tmp_path, items))


def test_us25_a_file_must_be_pinned_to_a_commit(tmp_path: Path) -> None:
    items = _valid_items()
    for item in items:
        if item["item_id"] == "gh-word":
            del item["ref"]

    with pytest.raises(SampleItemsError, match="repository and ref"):
        load_sample_items(_write(tmp_path, items))


def test_us25_unreadable_or_malformed_files_are_typed_errors(tmp_path: Path) -> None:
    with pytest.raises(SampleItemsError, match="Cannot read"):
        load_sample_items(tmp_path / "missing.yaml")
    bad = tmp_path / "bad.yaml"
    bad.write_text("items: [", encoding="utf-8")
    with pytest.raises(SampleItemsError, match="Cannot read"):
        load_sample_items(bad)
    bad.write_text("- just\n- a list\n", encoding="utf-8")
    with pytest.raises(SampleItemsError, match="'items'"):
        load_sample_items(bad)
