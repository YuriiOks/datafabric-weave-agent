"""In-memory implementations of the tool ports, for tests and local demonstrations.

They follow the port contracts: domains are applied before ranking, hidden matches are
counted, and traversal never continues through an item the caller may not read.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date

from kp.domain import Edition, ItemRef, Link, LinkKind, Template, ToolCallRecord
from kp.errors import WriteNotPermittedError
from kp.tools.errors import LinkStoreUnavailableError
from kp.tools.ports import (
    SHOWN_LINK_STATES,
    CoverageSnapshot,
    LinkCounts,
    LinkedItem,
    LinkTraversal,
    RuleClause,
    SearchHit,
    SearchResponse,
    WriteToolCall,
    WriteToolDescriptor,
    WriteToolResult,
)


class InMemoryAudit:
    """An :class:`kp.tools.AuditSink` that keeps records in a list."""

    def __init__(self) -> None:
        self.records: list[ToolCallRecord] = []

    def record(self, record: ToolCallRecord) -> None:
        """Keep one record.

        :param record: The call to record
        """
        self.records.append(record)


@dataclass
class FakeSearch:
    """Keyword search over fixed hits: every query word must occur in the text.

    :ivar hits: All passages, best first.
    :ivar calls: The ``domains`` of each call, so tests can assert what was passed on.
    """

    hits: Sequence[SearchHit]
    calls: list[frozenset[str]] = field(default_factory=list)

    def search(
        self,
        query: str,
        *,
        domains: frozenset[str],
        as_at: date,  # noqa: ARG002 - the fake holds one fixed point in time
        limit: int,
    ) -> SearchResponse:
        """Return matching hits of the allowed domains and the count of the hidden ones.

        :param query: Keywords
        :param domains: Allowed domains
        :param as_at: Ignored
        :param limit: Maximum hits
        :return: The response
        """
        self.calls.append(domains)
        words = query.lower().split()
        matches = [hit for hit in self.hits if all(word in hit.text.lower() for word in words)]
        allowed = [hit for hit in matches if hit.domain in domains]
        return SearchResponse(hits=tuple(allowed[:limit]), filtered_out=len(matches) - len(allowed))


class FakeLinks:
    """A link store over a list of links, with an availability switch.

    :param links: The open links
    :param domains: Domain label per item key; items missing here are unlabelled
    """

    def __init__(self, links: Iterable[Link], domains: Mapping[str, str]) -> None:
        self._links = [link for link in links if link.is_open]
        self._domains = dict(domains)
        self.available = True

    def traverse(self, root: ItemRef, *, steps: int, domains: frozenset[str]) -> LinkTraversal:
        """Breadth-first walk in both directions; hidden items are counted, not expanded.

        :param root: The start item
        :param steps: Maximum distance
        :param domains: Allowed domains
        :return: The traversal
        :raises LinkStoreUnavailableError: If :attr:`available` is False
        """
        self._require_available()
        seen = {root}
        frontier = [root]
        items: list[LinkedItem] = []
        hidden = 0
        for distance in range(1, steps + 1):
            reached: list[ItemRef] = []
            for node in frontier:
                for link in self._links:
                    for other, outgoing in _ends(link, node):
                        if other in seen:
                            continue
                        seen.add(other)
                        if self._domains.get(other.key) not in domains:
                            hidden += 1
                            continue
                        reached.append(other)
                        items.append(_linked(link, other, node, outgoing, distance, self._domains))
            frontier = reached
        return LinkTraversal(
            root_domain=self._domains.get(root.key), items=tuple(items), filtered_out=hidden
        )

    def link_counts(
        self, items: Sequence[ItemRef], *, domains: frozenset[str]
    ) -> Mapping[ItemRef, LinkCounts]:
        """Count shown links (stated or proposed) to items visible in ``domains``.

        :param items: The items to count for
        :param domains: Allowed domains
        :return: Counts for items that have such links
        :raises LinkStoreUnavailableError: If :attr:`available` is False
        """
        self._require_available()
        counts: dict[ItemRef, LinkCounts] = {}
        for item in items:
            mine = [
                link
                for link in self._links
                if link.state in SHOWN_LINK_STATES
                for other, _ in _ends(link, item)
                if self._domains.get(other.key) in domains
            ]
            if mine:
                stated = sum(1 for link in mine if link.kind is LinkKind.STATED)
                counts[item] = LinkCounts(stated=stated, guessed=len(mine) - stated)
        return counts

    def _require_available(self) -> None:
        if not self.available:
            raise LinkStoreUnavailableError("The link store is down")


def _ends(link: Link, node: ItemRef) -> list[tuple[ItemRef, bool]]:
    ends: list[tuple[ItemRef, bool]] = []
    if link.source_ref == node:
        ends.append((link.target_ref, True))
    if link.target_ref == node:
        ends.append((link.source_ref, False))
    return ends


def _linked(
    link: Link,
    other: ItemRef,
    via: ItemRef,
    outgoing: bool,
    steps: int,
    domains: Mapping[str, str],
) -> LinkedItem:
    return LinkedItem(
        item=other,
        domain=domains.get(other.key),
        steps=steps,
        relation=link.relation,
        outgoing=outgoing,
        via=via,
        kind=link.kind,
        state=link.state,
        score=link.score,
        evidence=link.evidence,
    )


class FakeRules:
    """Editions and clauses held in memory.

    :param editions: All editions
    :param clauses: Clauses keyed by ``(edition label, number)``
    """

    def __init__(
        self, editions: Sequence[Edition], clauses: Mapping[tuple[str, str], RuleClause]
    ) -> None:
        self._editions = list(editions)
        self._clauses = dict(clauses)

    def editions(self) -> Sequence[Edition]:
        """List every edition.

        :return: The editions
        """
        return self._editions

    def clause(self, edition: str, number: str) -> RuleClause | None:
        """Fetch a clause.

        :param edition: Edition label
        :param number: Clause number
        :return: The clause, or ``None``
        """
        return self._clauses.get((edition, number))

    def edition_domain(self, edition: str) -> str | None:
        """Tell the domain of an edition: that of any of its clauses.

        :param edition: Edition label
        :return: The domain, or ``None`` when the edition has no clause held here
        """
        return next(
            (found.domain for (label, _), found in self._clauses.items() if label == edition), None
        )


class FakeTemplates:
    """Governed templates held in memory.

    :param templates: All governed templates
    """

    def __init__(self, templates: Iterable[Template]) -> None:
        self._templates = list(templates)

    def get(self, spec_type: str, version: str | None = None) -> Template | None:
        """Fetch a template; the highest version string wins when none is named.

        :param spec_type: Kind of spec
        :param version: A specific version, or ``None`` for the latest
        :return: The template, or ``None``
        """
        matching = [
            template
            for template in self._templates
            if template.spec_type == spec_type and version in (None, template.version)
        ]
        return max(matching, key=lambda template: template.version, default=None)


class FakeCoverage:
    """Coverage over a fixed snapshot, filtered by domain.

    :param snapshot: Everything, whatever the domain
    """

    def __init__(self, snapshot: CoverageSnapshot) -> None:
        self._snapshot = snapshot

    def snapshot(
        self,
        *,
        domains: frozenset[str],
        as_at: date,  # noqa: ARG002 - the fake holds one fixed point in time
    ) -> CoverageSnapshot:
        """Return the allowed part of the snapshot and the count of the hidden part.

        :param domains: Allowed domains
        :param as_at: Ignored
        :return: The filtered snapshot
        """
        rules = tuple(rule for rule in self._snapshot.rules if rule.domain in domains)
        gaps = tuple(gap for gap in self._snapshot.story_gaps if gap.domain in domains)
        hidden = len(self._snapshot.rules) - len(rules) + len(self._snapshot.story_gaps) - len(gaps)
        return CoverageSnapshot(rules=rules, story_gaps=gaps, filtered_out=hidden)


class FakeWritePort:
    """A write port with one ``publish_spec`` tool that only accepts one fixed target.

    :ivar calls: Every call received.
    """

    ALLOWED_PATH = "specs/"

    def __init__(self) -> None:
        self.calls: list[WriteToolCall] = []

    def describe(self) -> Sequence[WriteToolDescriptor]:
        """Describe the single tool.

        :return: One descriptor
        """
        return (
            WriteToolDescriptor(
                name="publish_spec",
                description="Publish a drafted spec as a pull request.",
                input_schema={
                    "type": "object",
                    "properties": {"spec_id": {"type": "string"}, "path": {"type": "string"}},
                    "required": ["spec_id", "path"],
                    "additionalProperties": False,
                },
            ),
        )

    def invoke(self, call: WriteToolCall) -> WriteToolResult:
        """Accept a path under the allowed prefix; refuse any other; reject malformed input.

        :param call: The call
        :return: The result
        :raises ValueError: If ``spec_id`` or ``path`` is missing
        :raises WriteNotPermittedError: If the path is outside the allowed prefix
        """
        self.calls.append(call)
        spec_id, path = call.arguments.get("spec_id"), call.arguments.get("path")
        if not isinstance(spec_id, str) or not isinstance(path, str):
            raise ValueError("spec_id and path are required strings")
        if not path.startswith(self.ALLOWED_PATH):
            raise WriteNotPermittedError("The path is outside the agreed spec location")
        return WriteToolResult(
            payload={"branch": f"spec/{spec_id}"}, items_returned=1, spec_id=spec_id
        )
