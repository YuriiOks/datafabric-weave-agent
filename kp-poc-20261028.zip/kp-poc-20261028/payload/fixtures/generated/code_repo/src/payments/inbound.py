"""Validation of inbound credit transfers (synthetic)."""

PERMITTED_CURRENCIES = {"EUR", "GBP"}
AMOUNT_LIMIT = 1_000_000


def validate_currency(currency: str) -> bool:
    """Return True when the currency is permitted. Implements 2026.1:4.2.1.

    Implements spec spec-pay-104.
    """
    return currency in PERMITTED_CURRENCIES


def validate_amount(amount: float) -> bool:
    """Return True when the amount is within the limit. Implements 2026.1:4.2.2."""
    return 0 < amount <= AMOUNT_LIMIT


def validate_creditor_account(account: str) -> bool:
    """Return True when the account looks valid. Implements 2026.1:4.2.3."""
    return 0 < len(account) <= 34
