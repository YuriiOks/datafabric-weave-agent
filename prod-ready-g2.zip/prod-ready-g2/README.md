# Change package, 23 Oct 2026 (G, second build)

This build replaces the 22 Oct G package, which refused correctly and wrote nothing. Its anchors come from `main` at 8852c0c26f1a. The card panel and the client test were checked against that commit by byte count and sha256. There is no base sha: the package checks its anchors against your checkout. If `main` moved under one of them, the script refuses and writes nothing. Send the refusal lines and the package is rebuilt.

None of the files in this folder are committed.

## Contents

| PR | Package | Branch | Cut from | PR base |
|---|---|---|---|---|
| G | `prod-ready` | `fix/no-sample-data-without-demo-mode` (exists, clean, from the 22 Oct attempt) | `origin/main` | `main` |

## Steps

```bash
sha256sum -c SHA256SUMS
python3 install.py --inspect
python3 install.py prod-ready <existing worktree> --check
python3 install.py prod-ready <existing worktree>
git -C <path> add -A && git -C <path> commit -m "Show sample components only in demo mode"
```

Every script checks the branch, a clean worktree and every anchor before it writes. A second run reports `ALREADY APPLIED`. Nothing is staged, committed, pushed or tested by the scripts.

## Expected result

5 edited files: `client.ts`, `client.test.ts`, `components/CatalogueSourceBar.tsx`, `components/SuggestedComponentsPanel.tsx`, `pages/ComponentDetailPage.tsx`.

2 new files: `components/CatalogueSourceBar.test.tsx`, `components/SuggestedComponentsPanel.unavailable.test.tsx`.

## Pull request

| PR | Title | Body |
|---|---|---|
| G | `Show sample components only in demo mode` | `bodies/no-sample-data.md` |

## Tests to expect in CI

| PR | Test files |
|---|---|
| G | frontend `client.test.ts` (edited: the old demo case now runs in demo mode only, and a new case covers demo mode off), `CatalogueSourceBar.test.tsx` and `SuggestedComponentsPanel.unavailable.test.tsx` (new). The existing recsys tests already mock the client with demo mode on and need no change. |
