"""``.env.example`` lists every ``KP_`` setting, holds placeholders only, and loads cleanly."""

from __future__ import annotations

import json
import re

import pytest
from package_world import PROJECT_ROOT
from pydantic import SecretStr

from kp.config import Settings, Thresholds, load_settings
from kp.errors import ConfigurationError
from kp.search.settings import SearchSettings
from kp.web.settings import WebSettings

ENV_EXAMPLE = PROJECT_ROOT / ".env.example"
_SETTING_LINE = re.compile(r"^(?:# )?(KP_[A-Z0-9_]+)=(.*)$")
_PLACEHOLDER = re.compile(r"<[^<>\s]+>")


def _listed() -> dict[str, str]:
    """Every setting line of the file, commented out or not, with its value unquoted."""
    found: dict[str, str] = {}
    for line in ENV_EXAMPLE.read_text(encoding="ascii").splitlines():
        match = _SETTING_LINE.match(line)
        if match:
            name, value = match.groups()
            assert name not in found, f"{name} is listed twice"
            found[name] = value.strip("'")
    return found


def _declared() -> dict[str, object]:
    """Every setting the program reads, with its default."""
    declared: dict[str, object] = {}
    for name, field in Settings.model_fields.items():
        if name != "thresholds":
            declared[f"KP_{name.upper()}"] = field.get_default()
    for name, field in Thresholds.model_fields.items():
        declared[f"KP_THRESHOLDS__{name.upper()}"] = field.get_default()
    for name, field in SearchSettings.model_fields.items():
        declared[f"KP_SEARCH_{name.upper()}"] = field.get_default(call_default_factory=True)
    for name, field in WebSettings.model_fields.items():
        declared[f"KP_WEB_{name.upper()}"] = field.get_default()
    return declared


def _is_placeholder(value: str) -> bool:
    without = _PLACEHOLDER.sub("", value)
    return bool(_PLACEHOLDER.search(value)) and not re.search(r"[A-Za-z0-9]", without)


def _matches_default(value: str, default: object) -> bool:
    if isinstance(default, SecretStr):
        return value == default.get_secret_value()
    if isinstance(default, bool):
        return value == str(default).lower()
    if isinstance(default, tuple):
        return bool(json.loads(value) == list(default))
    if isinstance(default, dict):
        names = {str(getattr(key, "value", key)): weight for key, weight in default.items()}
        return bool(json.loads(value) == names)
    return value == str(getattr(default, "value", default))


def test_every_setting_of_the_program_is_listed_and_nothing_else() -> None:
    assert set(_listed()) == set(_declared())


def test_every_value_is_a_placeholder_or_the_documented_default() -> None:
    declared = _declared()
    offenders = [
        name
        for name, value in _listed().items()
        if not _is_placeholder(value)
        and not (declared[name] is not None and _matches_default(value, declared[name]))
    ]

    assert offenders == []


def test_settings_without_a_default_are_always_placeholders() -> None:
    declared = _declared()
    listed = _listed()

    for name, default in declared.items():
        if default is None or default == ():
            assert _is_placeholder(listed[name]), name


def test_no_value_looks_like_a_real_address() -> None:
    for name, value in _listed().items():
        assert "http" not in value.lower(), name
        assert "@" not in value, name


def test_only_the_local_defaults_are_active_lines() -> None:
    active = {
        match.group(1)
        for line in ENV_EXAMPLE.read_text(encoding="ascii").splitlines()
        if (match := re.match(r"^(KP_[A-Z0-9_]+)=", line))
    }

    assert active == {"KP_MODE", "KP_LOG_LEVEL", "KP_DATABASE_URL", "KP_DATA_DIR"}


def _load_everything(monkeypatch: pytest.MonkeyPatch, *, mode: str) -> None:
    for name, value in _listed().items():
        monkeypatch.setenv(name, value)
    monkeypatch.setenv("KP_MODE", mode)


def test_the_file_with_every_line_switched_on_loads_in_local_mode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _load_everything(monkeypatch, mode="local")

    settings = load_settings()

    assert settings.mode.value == "local"
    assert settings.thresholds.structure_proceed == pytest.approx(0.85)
    assert SearchSettings().result_limit == 10


def test_real_mode_refuses_the_placeholders_and_names_what_is_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _load_everything(monkeypatch, mode="real")

    with pytest.raises(ConfigurationError) as caught:
        load_settings()

    message = str(caught.value)
    assert "KP_GATEWAY_BASE_URL" in message
    assert "KP_RAW_BUCKET" in message
    assert "KP_SPEC_REPO" in message
    assert "<" not in message
