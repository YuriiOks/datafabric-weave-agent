---
pack_id: "bpc-sep26-v1"
local_id: "CORE-04"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Publish isolated graph generations and enforce authorised bounded reads"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 10
scope: "foundation"
create_by_default: true
planned_start: "2026-09-14"
planned_due: "2026-09-15"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-03"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-04"
architecture_sections: ["publication","read-contract","security","operations"]
---

# Publish isolated graph generations and enforce authorised bounded reads

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-04** is not a Jira key.
- Estimate: **10 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-14 → 2026-09-15 (D4–D5)**.
- Recommendation extension: **2026-09-14 → 2026-09-15 (D4–D5)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Prevent readers from seeing partial graph writes, mixed catalogue versions or revoked relations during refresh and rollback.

## Scope and contract

One immutable candidate key per scope/build, one authoritative Postgres descriptor, current policy before every traversal and final serialization. Graph facts are source declarations only. Existing native Hub assets remain isolated.

## Implementation sequence

1. Adapt the verified PoC builder to candidate graph keys and explicit lifecycle records; record writer identity, lease/fence and stage evidence.
2. Require confirmed writer exit and readback/checksum before sealing. Permanently abandon a candidate on uncertain writer acknowledgement; a Postgres fence alone cannot atomically fence remote graph writes.
3. Activate a sealed candidate through descriptor compare-and-swap; define loser behavior for concurrent publishers.
4. Implement pinned bounded reads and cursor expiry with current per-hop/intermediate authorization, stable relation denies, output checks and explicit policy-changed/unavailable errors.
5. Implement guarded retained rollback and irreversible retirement with reader lifetime and cleanup safety; current revocations/deletions never rewind.

## Acceptance criteria

- [ ] No candidate/unsealed/mixed publication is reader-visible.
- [ ] Denied intermediate nodes and revoked relationships cannot influence traversal or output.
- [ ] Lost acknowledgements never lead to reuse or publication of an uncertain graph key.
- [ ] Rollback only targets an intact retained compatible version and preserves current policy.
- [ ] Budgets bound depth, result count, duration and cursor lifetime; no arbitrary client graph key or Cypher.

## Verification

- Fault-inject interrupted writes, expired leases, competing activation, policy changes, stale cursors and retirement races.
- Verify exact facts through the source oracle and exercise one-/two-hop reads plus a high-degree fixture.
- Run tests on the actual deployed FalkorDB behavior; mocks alone do not establish the cross-store lifecycle guarantee.

## Evidence to attach

- Fault/recovery traces, publication IDs/checksums, denied-path evidence, query/capacity observations and CI references.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Estimate assumes a reusable projection/read PoC. If isolation, writer termination or safe minimum queries cannot be proven on the current stack, block activation and replan; do not weaken the contract or introduce another database.

## Activation must not regress a source collection

Within authoritative activation/CAS validation, compare the candidate collection-version vector against the current active descriptor and reject any regression, including an older complete workbook arriving late. Preserve unchanged sources’ original revision/age; a fresh fetch timestamp cannot make old evidence current. Refuse ambiguous ordering. This check composes with expected-base, seal, compatibility and current authorization checks; it is not a best-effort preflight outside activation. The delayed-old-source acceptance case must prove retired facts are not resurrected.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `publication`, `read-contract`, `security`, `operations`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
