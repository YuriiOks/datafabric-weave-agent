# km-read legacy

Goal: record what the older knowledge project (LEGACY_ORG) solved, how, and what went wrong,
so S5 (extraction to graph), S6 (ingestion and storage layout) and S2 (risks) start from
evidence. The legacy code is a source of lessons. Record evidence for reuse and for no reuse.
Output: /home/user/km/kb/legacy/. The review PDF is a separate target (/km-read pdf).

## Inputs
- LEGACY_ORG login: names.md does not record it. Run `gh api user/orgs --jq '.[].login'`, take
  the one org that matches the LEGACY_ORG entry of names.md, write it to kb/log.d/RUN.txt as
  Unverified. No names.md, or zero or several matches: show the list, ask the owner for the
  login in one line, stop. gh refused or no answer: log, stop.
- Questions for S5 and S6: kb/seed/story-gaps.md and kb/seed/reference-patterns-1.md and -2.md.
- The gh command line, signed in. If gh is refused or asks for a login: log, stop.

## Steps
1. List the repositories: `gh repo list <org> --limit 100 --json name,primaryLanguage,diskUsage,
   pushedAt,isArchived,description`. No clone yet.
2. Write kb/legacy/repo-list.md (main session): one row per repository with number, name, size
   in KB, language, last push, archived or not, one-line purpose from the description (Observed).
   This is the only file that maps repository numbers to names.
3. Choose at most 6 by relevance and list each with its reason at the end of repo-list.md. A
   repository qualifies when it implements graph building, extraction against an ontology,
   vector indexing, ontology validation, fixed graph queries, hybrid search, re-authoring,
   quality reports, a review interface or a document-to-markdown pipeline. Empty, archived and
   configuration-only repositories are listed, not read.
4. For each chosen repository, one at a time:
   - clone: `gh repo clone <org>/<name> /home/user/km/work/legacy/<name> -- --depth 1`;
     no reader runs while a clone runs; never delete a clone;
   - one km-reader on the clone, output kb/legacy/repo-<n>.md (n = number in repo-list.md; the
     file says LEGACY_REPO_n, never the name). Budget: 30 files or 150 KB. No running, no
     installing, no containers. A quote is at most 3 lines.
   Headings: What it does; Data model (entities, node and edge types, path:line); Pipeline steps
   in order with the file for each; Source evidence (does an extracted item point back to a
   document span); Duplicates and cleaning (is an LLM the judge); Lessons for S5; Lessons for
   S6; Weak points seen; Reuse verdict (reuse, adapt or do not reuse, with one evidence line);
   What a reviewer flagged (write "not checked"; /km-read pdf fills it); Open questions.
5. Main session writes kb/legacy/lessons.md (at most 150 lines) from the repo files only: lists
   Lessons for S5, Lessons for S6, Risks for S2, Reuse summary (one line per repository). Each
   item names its repo file.
6. Resume: a repo whose repo-<n>.md exists is skipped, and so is its clone. A clone that exists
   without its file is read as is.

## Done when
- repo-list.md covers every repository the listing returned.
- Each chosen repository has its file with all headings filled or marked.
- lessons.md exists and each item cites a repo file.
- Run record and kb-lint.sh PASS as in the method; summary printed.

## Stop
- A clone fails twice for the same reason: log it, skip that repository, go on with the next.
- Over budget in a repository: Status partial and the rest listed in Open questions.
- At most 6 reader calls plus one repair.
