"""Errors of the write-back lane. Refusals subclass :class:`kp.errors.WriteNotPermittedError`.

They live in this package, as subclasses of the shared hierarchy in :mod:`kp.errors`, so the
lane adds nothing to the shared module.
"""

from __future__ import annotations

from kp.errors import KpError, WriteNotPermittedError


class WriteBackError(KpError):
    """Base class of write-back failures that are not refusals."""


class PublishError(WriteBackError):
    """The spec could not be committed or the pull request could not be created."""


class SpecNotFoundError(WriteBackError):
    """No published spec exists for the story, so there is nothing to link in Jira."""


class SpecNotDraftableError(WriteBackError):
    """The spec for this branch was already merged or closed, so it is not redrafted."""


class SpecNotDraftedError(WriteBackError):
    """The spec was already merged or closed, so the story is left as it is."""


class StoryNotFoundError(WriteBackError):
    """The story to draft a spec for is not in the store."""


class JiraUpdateError(WriteBackError):
    """Jira refused the update. Retrying the same request will not help."""


class JiraTransientError(JiraUpdateError):
    """Jira could not be reached or answered with a server-side failure. Safe to retry."""


class InvalidStoryKeyError(WriteNotPermittedError):
    """The story key is not a plain tracker key, so no target can be derived from it."""


class RepositoryNotPermittedError(WriteNotPermittedError):
    """The request named a repository other than the configured spec repository."""


class PathNotPermittedError(WriteNotPermittedError):
    """The request named a path other than the story's spec path under the configured prefix."""


class BranchNotPermittedError(WriteNotPermittedError):
    """The request named a branch other than the story's spec branch (never a protected one)."""


class JiraFieldNotPermittedError(WriteNotPermittedError):
    """The request named a Jira field or value outside the two agreed fields."""


class StoryDomainNotPermittedError(WriteNotPermittedError):
    """The story belongs to a domain the caller may not read, so the caller may not write for it."""
