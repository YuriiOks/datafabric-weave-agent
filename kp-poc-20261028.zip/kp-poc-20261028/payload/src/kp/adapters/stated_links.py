"""Seam: what stored items state about themselves becomes stated links.

The link loaders of :mod:`kp.links` work on domain values. This module reads those values from
the tables (stories, register rows, editions, the spec table) and hands the loaders' results to
:class:`~kp.links.service.LinkService`. Applying a set is idempotent, so a loader can run again
whenever something it depends on arrives (a register can be swept before the rulebook it cites).
"""

from __future__ import annotations

from collections.abc import Collection
from pathlib import Path

from sqlalchemy import Connection, select

from kp.clock import Clock
from kp.config import Thresholds
from kp.domain import Relation, Requirement, Story, StoryLink
from kp.links import (
    KeyIndex,
    LinkService,
    RepositoryScan,
    RepositoryScanner,
    SyncReport,
    register_link_set,
    story_link_set,
)
from kp.store import schema


class StatedLinkLoader:
    """Loads the stated links of stories, the register and a code repository.

    :param connection: A connection inside the caller's unit of work
    :param thresholds: Platform thresholds, passed on to the link service
    :param clock: Time source for link validity periods
    """

    def __init__(self, connection: Connection, *, thresholds: Thresholds, clock: Clock) -> None:
        self._connection = connection
        self._service = LinkService(connection, thresholds=thresholds, clock=clock)

    def sync_stories(self, story_keys: Collection[str]) -> SyncReport:
        """Load the issue links of the latest stored version of each named story.

        :param story_keys: Keys of the stories whose links to load
        :return: What the link service changed
        """
        latest = self._latest_stories()
        index = KeyIndex.build(
            requirements=self.requirements(),
            spec_keys=self._spec_keys(),
            story_keys=(story.story_key for story in latest),
        )
        stories = [story for story in latest if story.story_key in story_keys]
        return self._service.apply_stated(story_link_set(stories, index))

    def sync_register(self) -> SyncReport:
        """Load the rule references of every stored register row.

        Rows that cite a clause which is not loaded yet are counted as dangling; running this
        again after the rulebook arrives stores them.

        :return: What the link service changed
        """
        editions = set(self._connection.execute(select(schema.edition.c.label)).scalars())
        return self._service.apply_stated(register_link_set(self.requirements(), editions=editions))

    def sync_repository(self, root: Path) -> tuple[RepositoryScan, SyncReport]:
        """Load what the files of a code repository state: tests of code, fields of clauses and
        the specs the code implements.

        :param root: The checkout folder
        :return: The scan (with the clause citations it could not store) and the sync report
        """
        editions = set(self._connection.execute(select(schema.edition.c.label)).scalars())
        scan = RepositoryScanner(editions=editions, specs=self.known_specs()).scan(root)
        return scan, self._service.apply_stated(scan)

    def known_specs(self) -> set[str]:
        """List the specs the platform knows: those it drafted and those loaded back.

        :return: Spec identities
        """
        loaded = select(schema.link.c.target_key).where(
            schema.link.c.relation == Relation.SPECIFIED_BY.value,
            schema.link.c.valid_to.is_(None),
        )
        return set(self._spec_keys()) | set(self._connection.execute(loaded).scalars())

    def requirements(self) -> list[Requirement]:
        """Read every stored register row.

        :return: The requirements, ordered by id
        """
        rows = self._connection.execute(
            select(schema.requirement).order_by(schema.requirement.c.requirement_id)
        )
        return [Requirement.model_validate(row._mapping) for row in rows]

    def _latest_stories(self) -> list[Story]:
        """The newest stored version of every story."""
        newest: dict[str, Story] = {}
        for row in self._connection.execute(select(schema.story)):
            values = dict(row._mapping)
            values.pop("fingerprint", None)
            values["links"] = tuple(StoryLink.model_validate(link) for link in values["links"])
            story = Story.model_validate(values)
            held = newest.get(story.story_key)
            if held is None or story.version > held.version:
                newest[story.story_key] = story
        return [newest[key] for key in sorted(newest)]

    def _spec_keys(self) -> list[str]:
        return list(self._connection.execute(select(schema.spec.c.spec_id)).scalars())
