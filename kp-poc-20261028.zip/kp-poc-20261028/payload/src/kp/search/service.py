"""The search facade: filters, keyword and vector ranking, fusion, exact references, rules."""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date

from kp.clock import Clock
from kp.domain import ClauseRef, Passage, PassageType
from kp.search.embedding import (
    Embedder,
    HashingEmbedder,
    cosine_ranking,
    embed_pending,
    embed_texts,
)
from kp.search.errors import ClauseNotFoundError, NoEditionInForceError
from kp.search.fusion import reciprocal_rank_fusion
from kp.search.indexing import index_clauses, index_requirements, index_stories
from kp.search.keyword import Bm25Index
from kp.search.lookup import RuleLookup, question_references
from kp.search.models import RuleText, SearchHit, SearchResponse
from kp.search.settings import SearchSettings
from kp.search.store import PassageStore
from kp.search.tokens import analyze
from kp.store import Database

logger = logging.getLogger(__name__)

_EXACT_SCORE = 1.0  # above any fused score, which is at most 2 / (constant + 1)


@dataclass(frozen=True, slots=True)
class IndexReport:
    """How many passages a rebuild wrote.

    :ivar clauses: Clause passages written.
    :ivar stories: Story and acceptance-criteria passages written.
    :ivar requirements: Register-row passages written.
    :ivar embedded: Passages given a vector (0 when the vector side is off).
    """

    clauses: int
    stories: int
    requirements: int
    embedded: int


class SearchService:
    """Answers questions with exact clauses, and reads rules at a date.

    "No date" always means the clock's today, for search and for rule reads alike.

    :param database: The database holding passages, editions and clauses
    :param clock: Source of "today"
    :param settings: Search tunables; defaults come from ``KP_SEARCH_*`` variables
    :param embedder: The vector-side embedder; the hashing stand-in when the vector side is
        on and none is given
    """

    def __init__(
        self,
        database: Database,
        clock: Clock,
        settings: SearchSettings | None = None,
        embedder: Embedder | None = None,
    ) -> None:
        self._database = database
        self._clock = clock
        self._settings = settings or SearchSettings()
        self._embedder: Embedder | None = None
        if self._settings.vector_enabled:
            self._embedder = embedder or HashingEmbedder()

    @property
    def embedder(self) -> Embedder | None:
        """The embedder of the vector side; ``None`` when that side is off."""
        return self._embedder

    @property
    def embedding_batch_size(self) -> int:
        """The largest batch sent to the embedder."""
        return self._settings.embedding_batch_size

    def search(
        self,
        question: str,
        *,
        as_at: date | None = None,
        domains: Sequence[str] = (),
        limit: int | None = None,
    ) -> SearchResponse:
        """Answer a question from approved passages.

        Filters (approved and not withdrawn, domains, the version in force on the date) are
        applied before ranking. Ranking is BM25 over the remaining passages, fused with the
        vector ranking when that side is on, then weighted by source authority. A clause
        reference in the question (``clause 4.2.1``, ``2026.1:4.2.1``), or a question that is
        nothing but a reference (``4.2.1``), is looked up exactly and its hit comes first. A
        bare number is read in the edition in force on the date. A named edition is read even
        when it was not in force; the hit's ``state`` says so.

        :param question: Free text
        :param as_at: Read the rules as they were on this date; ``None`` means today
        :param domains: Only passages in these domains; empty means all
        :param limit: Maximum number of hits; the ``result_limit`` setting when ``None``
        :return: The ranked hits with the date and edition they were read at
        :raises ValueError: If ``limit`` is less than 1
        """
        if limit is not None and limit < 1:
            raise ValueError("limit must be at least 1")
        day = as_at or self._clock.today()
        size = self._settings.result_limit if limit is None else limit
        with self._database.transaction() as connection:
            store = PassageStore(connection)
            lookup = RuleLookup(connection, domains)
            candidates = store.candidates(
                as_at=day,
                domains=domains,
                with_embeddings=self._embedder is not None,
                editions=lookup.editions,
            )
            labels = {p.edition_label for p in candidates if p.edition_label}
            titles = store.clause_titles(labels)
            exact = self._exact_hits(lookup, question, day)
            ranked, vector_used = self._rank(question, candidates, titles)
            edition = lookup.edition_in_force(day)
        taken = {hit.reference for hit in exact}
        hits = [*exact, *(hit for hit in ranked if hit.reference not in taken)][:size]
        logger.info(
            "Search answered",
            extra={
                "as_at": day.isoformat(),
                "candidates": len(candidates),
                "hits": len(hits),
                "vector_used": vector_used,
            },
        )
        return SearchResponse(
            question=question,
            as_at=day,
            edition_in_force=edition.label if edition else None,
            vector_used=vector_used,
            hits=tuple(hits),
        )

    def lookup(
        self, reference: str, *, as_at: date | None = None, domains: Sequence[str] = ()
    ) -> RuleText:
        """Look up a clause by reference.

        :param reference: ``2026.1:4.2.1`` or ``2026.1 clause 4.2.1`` for a named edition;
            ``4.2.1`` or ``clause 4.2.1`` for whichever edition applied on ``as_at``
        :param as_at: The date to read at; ``None`` means today
        :param domains: Only read rules of documents in these domains; empty means all
        :return: The clause as written, with page and position
        :raises kp.errors.InvalidClauseRefError: If ``reference`` is not a reference
        :raises NoEditionInForceError: For a bare number when no edition applied then
        :raises ClauseNotFoundError: If the clause does not exist
        """
        day = as_at or self._clock.today()
        with self._database.transaction() as connection:
            return RuleLookup(connection, domains).resolve(reference, day)

    def rule_as_at(
        self, number: str, *, as_at: date | None = None, domains: Sequence[str] = ()
    ) -> RuleText:
        """Read a clause as it stood on a date.

        :param number: Clause number, e.g. ``4.2.1``
        :param as_at: The date to read at; ``None`` means today
        :param domains: Only read rules of documents in these domains; empty means all
        :return: The clause text of the edition then in force
        :raises NoEditionInForceError: If no edition applied on that date
        :raises ClauseNotFoundError: If that edition has no such clause
        """
        day = as_at or self._clock.today()
        with self._database.transaction() as connection:
            return RuleLookup(connection, domains).rule_as_at(number, day)

    def rebuild_index(self) -> IndexReport:
        """Rebuild passages from the stored clauses, stories and register rows.

        Embeds the new passages when the vector side is on.

        :return: Passages written per kind
        """
        with self._database.transaction() as connection:
            clauses = index_clauses(connection)
            stories = index_stories(connection)
            requirements = index_requirements(connection)
            embedded = (
                embed_pending(connection, self._embedder, self._settings.embedding_batch_size)
                if self._embedder is not None
                else 0
            )
        return IndexReport(clauses, stories, requirements, embedded)

    def embed_pending(self) -> int:
        """Embed passages that have no vector from the current model.

        :return: The number embedded; 0 when the vector side is off
        """
        if self._embedder is None:
            return 0
        with self._database.transaction() as connection:
            return embed_pending(connection, self._embedder, self._settings.embedding_batch_size)

    def _exact_hits(self, lookup: RuleLookup, question: str, day: date) -> list[SearchHit]:
        hits = []
        for edition, number in question_references(question):
            try:
                rule = (
                    lookup.rule_as_at(number, day)
                    if edition is None
                    else lookup.rule_in_edition(ClauseRef(edition, number), day)
                )
            except (ClauseNotFoundError, NoEditionInForceError):
                logger.info("Mentioned reference not found", extra={"as_at": day.isoformat()})
                continue
            hits.append(SearchHit.from_rule(rule, _EXACT_SCORE))
        return hits

    def _rank(
        self,
        question: str,
        candidates: Sequence[Passage],
        titles: dict[tuple[str, str], str],
    ) -> tuple[list[SearchHit], bool]:
        by_id = {p.passage_id: p for p in candidates}
        depth = self._settings.candidate_depth
        index = Bm25Index(
            [(p.passage_id, analyze(f"{_title(p, titles)} {p.text}")) for p in candidates]
        )
        keyword = index.search(analyze(question), depth)
        rankings = [[passage_id for passage_id, _ in keyword]]
        vector = self._vector_ranking(question, candidates)
        if vector:
            rankings.append([passage_id for passage_id, _ in vector])
        fused = reciprocal_rank_fusion(rankings, depth, self._settings.rrf_constant)
        weights = self._settings.authority_weights
        scored = sorted(
            (
                (score * weights.get(by_id[passage_id].source, 1.0), passage_id)
                for passage_id, score in fused.items()
            ),
            key=lambda item: (-item[0], item[1]),
        )
        keyword_rank = {passage_id: rank for rank, (passage_id, _) in enumerate(keyword, 1)}
        vector_rank = {passage_id: rank for rank, (passage_id, _) in enumerate(vector, 1)}
        hits = [
            SearchHit.from_passage(
                by_id[passage_id],
                title=_title(by_id[passage_id], titles),
                score=score,
                keyword_rank=keyword_rank.get(passage_id),
                vector_rank=vector_rank.get(passage_id),
            )
            for score, passage_id in scored
        ]
        return hits, bool(vector)

    def _vector_ranking(
        self, question: str, candidates: Sequence[Passage]
    ) -> list[tuple[str, float]]:
        if self._embedder is None:
            return []
        vectors = [
            (p.passage_id, p.embedding)
            for p in candidates
            if p.embedding is not None and p.model_version == self._embedder.model_version
        ]
        if not vectors:
            logger.info("No passage has a vector from the current model")
            return []
        query = embed_texts(self._embedder, [question], self._settings.embedding_batch_size)[0]
        return cosine_ranking(query, vectors, self._settings.candidate_depth)


def _title(passage: Passage, titles: dict[tuple[str, str], str]) -> str:
    if passage.passage_type is not PassageType.CLAUSE or passage.edition_label is None:
        return ""
    number = passage.parent_ref.removeprefix(f"{passage.edition_label}:")
    return titles.get((passage.edition_label, number), "")
