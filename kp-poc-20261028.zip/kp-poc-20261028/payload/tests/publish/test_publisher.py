"""Publication checks and the one-switch publication of a knowledge version (US-15)."""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from sqlalchemy import Connection, insert, select

from kp.clock import FixedClock
from kp.config import Thresholds
from kp.domain import (
    CheckSeverity,
    KnowledgeVersionState,
    LinkState,
    Relation,
    RunKind,
    RunOutcome,
)
from kp.errors import PublicationBlockedError
from kp.links import LinkService
from kp.publish import (
    AVERAGE_GUESSED_SCORE,
    CLAUSES_WITHOUT_FIELD_LINK,
    GUESSED_SHARE,
    HAS_ITEMS,
    ITEM_COUNT_CHANGE,
    ITEMS_HAVE_SOURCE,
    ITEMS_WITHOUT_LINKS,
    MODEL_CONFORMANCE,
    STORIES_WITHOUT_REQUIREMENT_OR_CLAUSE,
    CatalogItem,
    KnowledgePublisher,
    UnknownKnowledgeVersionError,
)
from kp.publish.versions import KnowledgeVersionStore
from kp.store.schema import knowledge_version
from kp.store.schema import link as link_table
from kp.store.schema import run as run_table
from links.builders import clause, code, guess_link, requirement, spec, state_link, story
from links.seed import insert_run
from publish.conftest import NOW, ListCatalog, catalog_item, filler


def _publisher(
    connection: Connection, clock: FixedClock, items: list[CatalogItem]
) -> KnowledgePublisher:
    return KnowledgePublisher(connection, clock=clock, catalog=ListCatalog(items))


def _check(result_checks: tuple[object, ...], name: str) -> object:
    return next(c for c in result_checks if getattr(c, "name", None) == name)


def test_us15_when_every_blocking_check_passes_the_version_is_published(
    connection: Connection, clock: FixedClock, tied_items: list[CatalogItem]
) -> None:
    publisher = _publisher(connection, clock, tied_items)

    result = publisher.publish()

    assert result.published
    assert result.version.state is KnowledgeVersionState.PUBLISHED
    assert result.version.published_at == NOW
    assert result.version.item_count == 3
    assert result.serving == result.version
    assert publisher.current() == result.version
    assert result.require_published() == result.version
    assert result.failed_checks == ()


def test_us15_the_first_publication_has_no_earlier_version_to_compare_with(
    connection: Connection, clock: FixedClock, tied_items: list[CatalogItem]
) -> None:
    result = _publisher(connection, clock, tied_items).publish()

    (change,) = (c for c in result.version.checks if c.name == ITEM_COUNT_CHANGE)
    assert change.passed
    assert change.detail == "No earlier version to compare with."


def test_us15_all_checks_run_and_the_clean_set_has_no_warning(
    connection: Connection, clock: FixedClock, tied_items: list[CatalogItem]
) -> None:
    result = _publisher(connection, clock, tied_items).publish()

    names = {c.name: c.severity for c in result.version.checks}
    assert names == {
        HAS_ITEMS: CheckSeverity.BLOCKING,
        MODEL_CONFORMANCE: CheckSeverity.BLOCKING,
        GUESSED_SHARE: CheckSeverity.BLOCKING,
        ITEM_COUNT_CHANGE: CheckSeverity.BLOCKING,
        ITEMS_HAVE_SOURCE: CheckSeverity.BLOCKING,
        ITEMS_WITHOUT_LINKS: CheckSeverity.WARNING,
        CLAUSES_WITHOUT_FIELD_LINK: CheckSeverity.WARNING,
        AVERAGE_GUESSED_SCORE: CheckSeverity.WARNING,
        STORIES_WITHOUT_REQUIREMENT_OR_CLAUSE: CheckSeverity.REPORT,
    }
    assert all(c.passed for c in result.version.checks)


def test_us15_an_empty_candidate_is_never_published(
    connection: Connection, clock: FixedClock
) -> None:
    publisher = _publisher(connection, clock, [])

    result = publisher.publish()

    assert not result.published
    assert [c.name for c in result.failed_checks] == [HAS_ITEMS]
    assert publisher.current() is None


def test_us15_publishing_expires_retired_versions_whose_retention_ran_out(
    connection: Connection, clock: FixedClock, tied_items: list[CatalogItem]
) -> None:
    publisher = _publisher(connection, clock, tied_items)
    first = publisher.publish().version
    clock.set(NOW + timedelta(days=1))
    second = publisher.publish().version
    clock.set(NOW + timedelta(days=40))

    third = publisher.publish().version

    assert {v.version_id for v in publisher.versions()} == {second.version_id, third.version_id}
    assert first.version_id not in {v.version_id for v in publisher.versions()}


def test_us15_publishing_again_retires_the_previous_version_for_thirty_days(
    connection: Connection, clock: FixedClock, tied_items: list[CatalogItem]
) -> None:
    publisher = _publisher(connection, clock, tied_items)
    first = publisher.publish().version
    clock.set(NOW + timedelta(days=1))

    second = publisher.publish().version

    stored = {v.version_id: v for v in publisher.versions()}
    published = [v for v in stored.values() if v.state is KnowledgeVersionState.PUBLISHED]
    assert published == [second]
    assert stored[first.version_id].state is KnowledgeVersionState.RETIRED
    assert stored[first.version_id].retained_until == date(2026, 11, 21) + timedelta(days=30)
    assert publisher.current() == second


def test_us15_a_blocking_failure_leaves_the_previous_version_serving_and_keeps_the_failed_run(
    connection: Connection, clock: FixedClock, links: LinkService, tied_items: list[CatalogItem]
) -> None:
    publisher = _publisher(connection, clock, tied_items)
    serving = publisher.publish().version
    clock.set(NOW + timedelta(days=1))
    for number in range(5):
        guess_link(links, spec("S1"), Relation.DERIVED_FROM, clause(f"4.3.{number}"))

    result = publisher.publish()

    assert not result.published
    assert result.version.state is KnowledgeVersionState.FAILED_KEPT
    assert result.serving == serving
    assert publisher.current() == serving
    assert [c.name for c in result.failed_checks] == [GUESSED_SHARE]
    assert result.failed_checks[0].value == pytest.approx(5 / 9)
    # The failed run is stored with its checks, so it can be inspected later.
    kept = KnowledgeVersionStore(connection).get(result.version.version_id)
    assert kept.state is KnowledgeVersionState.FAILED_KEPT
    assert kept.checks == result.version.checks
    with pytest.raises(PublicationBlockedError, match=GUESSED_SHARE):
        result.require_published()


def test_us15_guessed_share_above_half_blocks_but_exactly_half_passes(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    state_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    guess_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.2"))
    publisher = _publisher(connection, clock, filler(3))
    assert publisher.publish().published
    guess_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.3"))

    blocked = publisher.publish()

    assert not blocked.published
    assert blocked.failed_checks[0].value == pytest.approx(2 / 3)


def test_us15_a_stored_link_that_breaks_the_model_blocks_publication(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    state_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    connection.execute(
        insert(link_table).values(
            link_id="lnk-bad",
            source_item_type="story",
            source_key="PAY-1",
            relation="constrained_by",
            target_item_type="clause",
            target_key="2026.1:4.2.1",
            kind="stated",
            state="stated",
            score=None,
            evidence="",
            valid_from=NOW,
            valid_to=None,
        )
    )

    result = _publisher(connection, clock, filler(2)).publish()

    assert not result.published
    (failed,) = result.failed_checks
    assert failed.name == MODEL_CONFORMANCE
    assert failed.value == 0.5
    assert failed.threshold == 1.0


@pytest.mark.parametrize(
    ("first", "second", "published"),
    [(8, 10, True), (10, 12, True), (10, 13, False), (10, 7, False), (10, 8, True), (8, 4, False)],
)
def test_us15_item_count_may_change_by_at_most_a_quarter(
    connection: Connection, clock: FixedClock, first: int, second: int, published: bool
) -> None:
    catalog = ListCatalog(filler(first))
    publisher = KnowledgePublisher(connection, clock=clock, catalog=catalog)
    publisher.publish()
    catalog.listed = filler(second)

    result = publisher.publish()

    assert result.published is published
    (change,) = (c for c in result.version.checks if c.name == ITEM_COUNT_CHANGE)
    assert change.value == pytest.approx(abs(second - first) / first)
    assert change.threshold == Thresholds().item_count_change_max


def test_us15_an_item_without_its_source_blocks_publication(
    connection: Connection, clock: FixedClock
) -> None:
    items = [*filler(3), *filler(1, has_source=False)]

    result = _publisher(connection, clock, items).publish()

    assert not result.published
    (failed,) = result.failed_checks
    assert (failed.name, failed.value) == (ITEMS_HAVE_SOURCE, 0.75)
    assert "1 of 4 items have no source" in failed.detail


def test_us15_warnings_are_reported_and_do_not_block(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    guess_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"), score=0.6)
    guess_link(links, spec("S1"), Relation.IMPLEMENTED_BY, code("a.py::f"), score=0.7)
    state_link(links, spec("S1"), Relation.DERIVED_FROM, requirement("REQ-1"))
    state_link(links, spec("S1"), Relation.IMPLEMENTED_BY, code("b.py::g"))
    state_link(links, spec("S1"), Relation.DERIVED_FROM, requirement("REQ-9"))
    items = [
        catalog_item("clause", clause("4.2.1")),
        catalog_item("clause", clause("4.2.2")),
        catalog_item("requirement", requirement("REQ-1")),
        catalog_item("requirement", requirement("REQ-2")),
    ]

    result = _publisher(connection, clock, items).publish()

    by_name = {c.name: c for c in result.version.checks}
    assert result.published
    assert not by_name[ITEMS_WITHOUT_LINKS].passed
    assert by_name[ITEMS_WITHOUT_LINKS].value == pytest.approx(2 / 4)
    assert not by_name[CLAUSES_WITHOUT_FIELD_LINK].passed
    assert by_name[CLAUSES_WITHOUT_FIELD_LINK].value == 1.0
    assert not by_name[AVERAGE_GUESSED_SCORE].passed
    assert by_name[AVERAGE_GUESSED_SCORE].value == pytest.approx(0.65)
    assert all(c.severity is CheckSeverity.WARNING for c in by_name.values() if not c.passed)


def test_us15_items_with_no_links_may_be_five_percent_and_no_more(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    refs = [requirement(f"REQ-{number}") for number in range(20)]
    for ref in refs[:19]:
        state_link(links, ref, Relation.CONSTRAINED_BY, clause("4.2.1"))
    items = [catalog_item("requirement", ref) for ref in refs]

    one_in_twenty = _publisher(connection, clock, items).check()
    state_link(links, spec("S9"), Relation.DERIVED_FROM, clause("4.2.9"))
    items.append(catalog_item("requirement", requirement("REQ-X")))
    two_in_twentyone = _publisher(connection, clock, items).check()

    assert next(c for c in one_in_twenty if c.name == ITEMS_WITHOUT_LINKS).passed
    assert not next(c for c in two_in_twentyone if c.name == ITEMS_WITHOUT_LINKS).passed


def test_us15_stories_with_no_requirement_or_clause_are_reported_only(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    state_link(links, story("PAY-1"), Relation.SPECIFIED_BY, spec("S1"))
    state_link(links, spec("S1"), Relation.IMPLEMENTED_BY, code("a.py::f"))
    items = [catalog_item("story", story("PAY-1")), catalog_item("story", story("PAY-2"))]

    result = _publisher(connection, clock, items).publish()

    (report,) = (c for c in result.version.checks if c.severity is CheckSeverity.REPORT)
    assert result.published
    assert report.passed
    assert report.value == 2.0
    assert "PAY-1, PAY-2" in report.detail


def test_us15_review_links_are_not_counted_as_links_in_use(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    state_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    guess_link(
        links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.2"), score=0.6, state=LinkState.REVIEW
    )

    measured = _publisher(connection, clock, filler(1)).measure()

    assert (measured.links.in_use, measured.links.review, measured.links.guessed) == (1, 1, 0)


def test_us15_a_dry_run_checks_without_staging_or_publishing(
    connection: Connection, clock: FixedClock, tied_items: list[CatalogItem]
) -> None:
    publisher = _publisher(connection, clock, tied_items)

    checks = publisher.check()

    assert len(checks) == 9
    assert connection.execute(select(knowledge_version)).first() is None
    assert publisher.current() is None


def test_us15_retired_versions_expire_after_thirty_days_but_failed_runs_stay(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    catalog = ListCatalog(filler(10))
    publisher = KnowledgePublisher(connection, clock=clock, catalog=catalog)
    first = publisher.publish().version
    clock.set(NOW + timedelta(days=1))
    catalog.listed = filler(30)
    failed = publisher.publish().version  # grows by 200%: blocked and kept
    catalog.listed = filler(11)
    second = publisher.publish().version
    retired_until = date(2026, 11, 21) + timedelta(days=30)

    clock.set(NOW + timedelta(days=1) + timedelta(days=30))
    assert clock.today() == retired_until
    assert publisher.expire_retired() == 0
    clock.set(NOW + timedelta(days=1) + timedelta(days=31))
    assert publisher.expire_retired() == 1

    remaining = {v.version_id for v in publisher.versions()}
    assert remaining == {failed.version_id, second.version_id}
    assert first.version_id not in remaining
    with pytest.raises(UnknownKnowledgeVersionError):
        KnowledgeVersionStore(connection).get(first.version_id)


def test_us15_a_build_run_is_recorded_for_each_publication(
    connection: Connection, clock: FixedClock
) -> None:
    catalog = ListCatalog(filler(10))
    publisher = KnowledgePublisher(connection, clock=clock, catalog=catalog)
    ok = publisher.publish("build-1")
    catalog.listed = filler(40)
    blocked = publisher.publish("build-2")

    runs = {row.run_id: row for row in connection.execute(select(run_table)).all()}

    assert ok.version.run_id == "build-1"
    assert blocked.version.run_id == "build-2"
    assert runs["build-1"].kind == RunKind.BUILD.value
    assert runs["build-1"].outcome == RunOutcome.SUCCEEDED.value
    assert runs["build-1"].items_touched == 10
    assert runs["build-2"].outcome == RunOutcome.FAILED.value


def test_us15_a_run_the_caller_already_recorded_is_left_as_it_is(
    connection: Connection, clock: FixedClock
) -> None:
    insert_run(connection, "build-existing", "build")
    publisher = _publisher(connection, clock, filler(2))

    result = publisher.publish("build-existing")

    row = connection.execute(select(run_table).where(run_table.c.run_id == "build-existing")).one()
    assert result.version.run_id == "build-existing"
    assert row.outcome == RunOutcome.SUCCEEDED.value
    assert row.items_touched == 0


def test_us15_thresholds_come_from_settings(
    connection: Connection, clock: FixedClock, links: LinkService
) -> None:
    state_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    guess_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.2"))
    strict = Thresholds(guessed_share_max=0.4)

    result = KnowledgePublisher(
        connection, thresholds=strict, clock=clock, catalog=ListCatalog(filler(1))
    ).publish()

    assert not result.published
    assert result.failed_checks[0].threshold == 0.4
