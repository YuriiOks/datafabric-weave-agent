"""Fixtures of the sweep tests: a sweeper wired to fakes on in-memory SQLite."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta

import pytest
from sqlalchemy import select

from kp.clock import FixedClock
from kp.domain import (
    ChangeEvent,
    ChangeKind,
    ItemKey,
    ReviewItem,
    ReviewState,
    SourceItemVersion,
    SourceKind,
)
from kp.store import Database
from kp.store import schema as tables
from kp.sweep import (
    ApprovalGate,
    RateLimitPolicy,
    Sweeper,
    SweepStore,
    SweepSummary,
    SweepTarget,
)

from .support import FakeProcessor, MemoryRawStore, RecordingSleeper, ScriptedReader


@dataclass
class Harness:
    """A sweeper plus the fakes and queries a test needs."""

    database: Database
    clock: FixedClock
    processor: FakeProcessor = field(default_factory=FakeProcessor)
    raw_store: MemoryRawStore = field(default_factory=MemoryRawStore)
    sleeper: RecordingSleeper = field(default_factory=RecordingSleeper)
    page_size: int = 100
    rate_limit: RateLimitPolicy = field(default_factory=RateLimitPolicy)
    gate: ApprovalGate = field(default_factory=ApprovalGate)

    def sweeper(self) -> Sweeper:
        """Build a sweeper over the current fakes."""
        return Sweeper(
            self.database,
            clock=self.clock,
            processor=self.processor,
            raw_store=self.raw_store,
            sleeper=self.sleeper,
            gate=self.gate,
            rate_limit=self.rate_limit,
            page_size=self.page_size,
        )

    def sweep(self, *readers: ScriptedReader, scope: str = "") -> SweepSummary:
        """Run one sweep over the readers."""
        return self.sweeper().run([SweepTarget(reader, scope) for reader in readers])

    def advance(self, **delta: float) -> None:
        """Move the clock forward."""
        self.clock.set(self.clock.now() + timedelta(**delta))

    def version(self, source: SourceKind, item_id: str, version: str) -> SourceItemVersion:
        """Read one stored version; fails the test if absent."""
        with self.database.transaction() as connection:
            found = SweepStore(connection).get_version(
                ItemKey(source=source, item_id=item_id, version=version)
            )
        assert found is not None, f"{source}/{item_id}@{version} was not stored"
        return found

    def versions(self, source: SourceKind | None = None) -> list[SourceItemVersion]:
        """Read every stored version, optionally of one source."""
        with self.database.transaction() as connection:
            rows = connection.execute(
                select(
                    tables.source_item.c.source,
                    tables.source_item.c.item_id,
                    tables.source_item.c.version,
                )
            )
            keys = [
                ItemKey(source=SourceKind(r.source), item_id=r.item_id, version=r.version)
                for r in rows
            ]
            store = SweepStore(connection)
            found = [store.get_version(key) for key in keys]
        return [v for v in found if v is not None and (source is None or v.source is source)]

    def events(self, kind: ChangeKind | None = None) -> list[ChangeEvent]:
        """Read recorded change events."""
        with self.database.transaction() as connection:
            rows = connection.execute(select(tables.change_event)).mappings().all()
        events = [
            ChangeEvent(
                event_id=r["event_id"],
                source=SourceKind(r["source"]),
                item_id=r["item_id"],
                old_version=r["old_version"],
                new_version=r["new_version"],
                kind=ChangeKind(r["kind"]),
                detected_at=r["detected_at"],
                run_id=r["run_id"],
            )
            for r in rows
        ]
        return [e for e in events if kind is None or e.kind is kind]

    def reviews(self) -> list[ReviewItem]:
        """Read recorded review items."""
        with self.database.transaction() as connection:
            rows = connection.execute(select(tables.review_item)).mappings().all()
        return [
            ReviewItem(
                review_id=r["review_id"],
                kind=r["kind"],
                state=ReviewState(r["state"]),
                source=SourceKind(r["source"]),
                item_id=r["item_id"],
                version=r["version"],
                detail=r["detail"],
                missing_details=tuple(r["missing_details"]),
                content_owner=r["content_owner"],
                candidates=tuple(r["candidates"]),
                run_id=r["run_id"],
                created_at=r["created_at"],
                resolved_at=r["resolved_at"],
            )
            for r in rows
        ]


@pytest.fixture
def harness(database: Database, fixed_clock: FixedClock) -> Harness:
    """A harness over the in-memory database and the fixed clock."""
    return Harness(database=database, clock=fixed_clock)
