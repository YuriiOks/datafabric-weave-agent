---
name: km-pr
description: Checklist before any git push or pull request from a clone or a task work tree in /home/user/km. Use when the owner asks to push, to open or edit a pull request, or to hand over a branch. It prepares text and checks only. No hook enforces this here, so this checklist is the control.
argument-hint: <task id, work tree path or clone folder name>
---

# km-pr

This skill pushes and opens nothing: it checks and hands the owner the push command. $0 names where
the work is: a task id (work tree /home/user/km/work/wt/<task>), a work tree path, or a clone
folder name under /home/user/km. Call that folder <dir>, and the clone it belongs to <clone>
(`git rev-parse --git-common-dir` from a work tree). If $0 is missing, list the work trees
(`git -C <clone> worktree list`) and clones with commits ahead of upstream; one candidate: use
it; several: ask which. Run name: km-pr-<name>-<date>. Stop at the first failure, report it
in one line, and change nothing. All commands are read-only.

1. Branch. In a separate call, cd to <dir>; check with `pwd`. Run `git status -sb`. The tree
   is clean, the branch is not the default branch, and in a work tree the branch is the task's
   own `feat/...` branch. The base is origin/main for a work tree; for a clone, upstream, else
   the remote default branch. If unclear, ask the owner. Then `git fetch origin` (read-only)
   and `git log HEAD..origin/main --oneline`: if main has moved, the owner brings it in by
   merge commit before the push; report it as a stop.
2. Paths. `git diff --name-only <base>...HEAD`. No path under .claude or .github. No harness
   file: copies of AGENTS.md or CLAUDE.md, START.md, start.sh, anything from kb/, designs/ or
   work/, skills, agents, names or claims files.
3. Secrets. List files whose diff matches secret-shaped text, names only, never the match:
   `git diff --name-only -i -G'(password|secret|token|api[_-]?key|private key)' <base>...HEAD`
   and the same with an email pattern. Look at each file listed and decide. A credential,
   key, token, staff id or email address in the diff is a stop.
4. Commits. `git log --format='%h %s' <base>..HEAD`. Each commit is one logical step with a
   one-line message. History was not amended or rebased; the main line comes in by merge commit.
   No session link line and no attribution typed by hand. The attribution line the environment
   adds to commits is expected: leave it, do not add or strip it.
5. Guard. From inside <dir> (the hook lives in the clone and covers its work trees) run
   `/home/user/km/.claude/bin/pre-push-guard.sh --check` by its full path (if it is not
   executable, `bash` with the same path). Show its output to the owner. Anything other than
   a pass is a stop.
6. Pull request text, only when one is being opened or edited. Read
   ${CLAUDE_SKILL_DIR}/references/pr-text.md and check the draft against it. If the owner
   has no draft, write one to work/builds/<task>-pr.md from
   ${CLAUDE_SKILL_DIR}/references/pr-body.md (title, body order, Self-review and Checks from
   real results only). If the diff changes what people see on screen, also read
   ${CLAUDE_SKILL_DIR}/references/screenshots.md, list the views the owner should capture,
   and check the draft's `## Screenshots` section. Keys in the title come from the owner or
   kb/private/; unknown keys are a stop. The draft is a file; nothing is opened or edited.
7. Levels. For a work tree with a task id, read work/builds/<task>.md and
   work/reviews/<task>.md. List per level (1 builder checks, 2 tests, 3 and 4 review, 5 fix
   round, 6 advisor) the real result, and every finding still open. A failed check, an open
   blocker, or a missing level-6 answer for a change touching access control, migrations or
   data deletion is a stop. If work/reviews/grill-<task>.md exists, list its open Must fix
   count; an open must-fix item is a stop unless the owner accepts it in one line.
   No such files: say so; the owner decides whether to go on.
   The owner may also run `/km-review diff <clone>` or `/km-code-review <task>` first; read
   its table if he did.
8. Hand over. Print the summary below and the exact command for the owner to run, then stop:
   `cd <dir> && git push` (`cd <dir> && git push -u origin <branch>` if no upstream is set).
   The skill never pushes and never opens a pull request. The work tree stays; only the owner
   removes it.

Record the run in kb/log.d/<run>.txt: date, dir, branch, head id, result of each check, the
command handed over. No knowledge file is written, so there is no index.d entry.

If a command is denied or needs an approval you were not given, log it and stop.
End with a summary of at most 10 lines: one line per check as pass or stop, then the next action.
