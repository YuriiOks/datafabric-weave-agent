# Common shape of every story document

Read once per run, before the story's own reference. The story reference adds the skeleton
for the body. This file fixes the frame around it.

## Frame, in this order
1. Title line. Then: Date, Story, Status (draft for the owner), Confirming roles.
2. Summary: at most 6 lines. What the document delivers, the 3 decisions that matter most,
   the largest open question. Numbers, not adjectives ("9 of 14 components partial").
3. Facts: what exists today. One entry per fact: label, text, source (path:line, kb path or
   verdict id). Group by area. Nothing proposed in this section.
4. The body from the story reference (table, register, schema, matrix, workflow, design).
5. Decisions.
6. Gaps from the story text: one row per Left out item of the story in kb/seed/story-gaps.md
   and per "raise as uncovered scope" item: where this document covers it, or one line why
   it is out of scope and who takes it.
7. Acceptance criteria (Proposed).
8. Dependencies on other stories, and what other stories take from this one.
9. Open questions: at most 2 per role, each with what it blocks.
10. Review notes: filled in step 4 of the skill. Leave the heading with "none yet".

## Decisions
One entry per decision, numbered D1, D2, in this form (wrap at 100 characters):
- D1 Question in one sentence.
- Options: A, B, C with one line each on gain and cost.
- Recommended: one option, label Proposed. Reason: two lines at most, tied to a fact id.
- Confirmed by: a role, never a name. Effect if the owner picks another option: one line.
Make the decision. A decision that says "to be agreed" is a failure of the document.
Pick a default the team can start on, and say what would change the choice.

## Acceptance criteria
- 4 to 8 criteria, each marked Proposed. Each names an output and a check a reviewer answers
  with yes or no ("every role in the matrix has a row for every action: yes or no").
- At least one criterion on evidence (every Observed line has a source) and one on scope
  (every item in the Gaps table is covered or excluded with a reason).
- No criterion about code, tests or builds. These stories end in a document.

## Labels
- Observed: a kb line labelled Observed with a source, or a Confirmed or Narrowed verdict.
- Never present a proposal as existing. Never upgrade a label.

## Mistakes common to all six
- Describing the design in terms of one technology when two are still open. State the
  requirement, then the options.
- Copying a reference pattern as if it were a requirement. Say what fits and what is new.
- Listing risks that are not in the register, or ignoring register rows that touch the story.
- Using real names. Use the placeholders and roles unless the owner asks otherwise.
- Writing code or configuration for the application. A schema or table proposal is a design
  table (a DDL-style listing is fine), not a migration to run.
- Padding. If a section has nothing to say, one line says so.
