# Architecture

This is the contract document for the lanes that build on the foundation and for the integration that joins them. Requirements
live in `SPEC.md` (user stories US-01..US-26; supplied separately, not committed); this file says where code goes and what may
not change silently.

## Module map

| Path | Purpose | Owner |
|---|---|---|
| `src/kp/config.py` | `Settings` (env prefix `KP_`), `Mode`, `Thresholds`, `load_settings()` | foundation |
| `src/kp/errors.py` | Typed exception hierarchy rooted at `KpError` | foundation |
| `src/kp/clock.py` | `Clock` protocol, `SystemClock`, `FixedClock` | foundation |
| `src/kp/log.py` | JSON logging, redaction of secret-like and body-like keys | foundation |
| `src/kp/domain/` | Entities, enums, `ClauseRef`, `Relation`, as-at rule. No I/O | foundation |
| `src/kp/store/` | Core `MetaData` for all tables, engines, `Database` unit of work | foundation |
| `src/kp/sources/base.py` | `SourceReader` protocol and its value types | foundation |
| `src/kp/cli.py` | `kp` entry point; registers every lane command and the two application commands | integration |
| `src/kp/app.py` | Composition root: `build_application(settings)` and `Application` | integration |
| `src/kp/adapters/` | One small module per seam between lane ports (pipeline processor, stated and guessed links, tool ports, retrievals, publishers, the spec repository as a sweep target, the raw store and the gateway readers of the real route, the code checkout rebuilt from swept items) | integration |
| `src/kp/corrections/` | The corrections log and per-spec report of a product owner's reviews (US-24, build side) | integration |
| `src/kp/demo/` | `kp demo`: staging, build, the three "done when" checks, the connectivity table, HTML and JSON report | integration |
| `src/kp/testing/` | Synthetic data generator and its ground truth (needs `dev` extra) | foundation |
| `fixtures/generated/` | Committed output of the generator | foundation |
| `src/kp/sources/` (rest), `src/kp/sweep/` | Readers, approval gate, change tracking, cursors | L1 |
| `src/kp/ingest/` | Parsers: rulebook to clauses, register to requirements, stories to passages | L2 |
| `src/kp/connectivity/` | Gateway client, token handling, extraction client, exit-criteria report | L3 |
| `src/kp/search/` | Passages, keyword and (optional) vector search, exact-reference lookup | L4 |
| `src/kp/links/`, `src/kp/publish/` | Link store, guessed links, impact and coverage queries, publication checks | L5 |
| `src/kp/tools/`, `src/kp/mcp/` | Typed read tools, access control, audit, JSON-RPC servers (stdio, HTTP) | L6a |
| `src/kp/writeback/` | Spec pull requests, Jira status update, citation check, reference drafting client | L6b |

## Lanes and the commands they own

| Lane | Folders | Stories | CLI commands |
|---|---|---|---|
| L1a sources | `sources/` | US-01..05, 09 (reader side) | (used by `sweep`) |
| L1b sweep, approval, change tracking | `sweep/` | US-01..05, 08, 09, 23 (load-back) | `sweep` |
| L2 ingest parsers | `ingest/` | US-06, 07 | (library, used by `sweep`) |
| L3 connectivity harness | `connectivity/` | US-25, 26 | `connectivity` |
| L4 search | `search/` | US-10, 11 | `search` |
| L5 links, impact, coverage, publication | `links/`, `publish/` | US-12..15 | `impact`, `coverage`, `publish` |
| L6a agent tools and servers | `tools/`, `mcp/` | US-16..18, 22 | `serve-read`, `serve-write` |
| L6b write-back | `writeback/` | US-19..22 | `draft-spec` |
| Corrections | `corrections/` | US-24 (build side) | `corrections add`, `corrections report` |
| Integration | `app.py`, `adapters/`, `demo/`, `cli.py` | all (end to end) | `init-db`, `demo`, `merge-spec` |

A lane edits only its own folders and its own tests (`tests/<folder>/`). Lanes do not edit
`kp/cli.py`: each lane exposes `add_parser(subparsers)` and the integration wires it. Everything
else is a shared contract (below). Lanes never import each other; the seams between them are the
modules of `kp/adapters/`, and only `kp/app.py` puts them together.

## Shared contracts: do not change without noting it

Change one of these only with a note in this section (what, why, which lanes are affected) in
the same commit.

1. **Domain entities and enums** (`kp.domain`). Field names are the persistence contract:
   table columns equal field names (see `tests/test_schema.py`, which fails on drift). Add
   fields with defaults; do not rename or retype.
2. **Schema** (`kp.store.schema`). New tables and nullable columns are fine. Do not change
   keys, enum value sets, or column meanings. `source_item` content columns are immutable
   once written. Exceptions, each by one named writer: the sweep updates `approval_state`,
   `effective_date`, `superseded_at`, `withdrawn_at`, the five document detail columns and
   `machine_authored` (`SweepStore.save_approval`: a library sidecar corrected on the same
   version changes them); the load-back of a merged spec updates `state`, `merged_at`,
   `machine_authored` and `content_sha256` of the `spec` row of that spec (`SpecLoader`); the
   connectivity store updates `extraction_status`,
   `extraction_failure`, `markdown_location`, `manifest_location` and `extractor_version`, and
   only on a row still `pending` (`ConnectivityStore.complete_extraction`).
3. **`ClauseRef`**: canonical text `<edition>:<number>` (e.g. `2026.1:4.2.1`), spoken form
   `2026.1 clause 4.2.1`. This is the `parent_ref` of clause passages, the `key` of clause
   `ItemRef`s and the `reference` of citations.
4. **As-at rule** (`select_edition_as_at`): one semantic for everyone. An edition applies on
   D iff `effective_date <= D` and not `superseded_from <= D` and not `withdrawn_from <= D`.
   Load time is never used. No edition in force returns `None`; callers raise a typed error
   or report it, never fall back to another edition. "No date" means `clock.today()`.
5. **Story fingerprint** (`Story.fingerprint()`): excludes `status`. L1's "no rework" check
   and US-05 depend on it.
6. **`SourceReader` protocol** (`kp.sources.base`): `list_changed(cursor, limit=)` and
   `fetch(key)`. Cursors are opaque and persisted in `sweep_cursor` only after a page is
   processed. Source-specific approval signals travel in `ItemMetadata.attributes`.
7. **Relations** (`kp.domain.relations`): seven directed relations with their allowed
   `(from, to)` item-type pairs. `Link` validates against them. Traversal for impact may
   follow edges in either direction.
8. **Settings names** (`KP_*`) and the `Thresholds` defaults.
9. **Logging convention**: static message, variable data in `extra`; never log request
   bodies or secrets (the formatter redacts by key name, but do not rely on it).
10. **Errors**: raise subclasses of `KpError`. Errors every lane may need live in
    `kp/errors.py`; an error only one package raises lives in that package's `errors.py`
    (rooted at `KpError`), never as a bare `Exception`.

## Integration notes

Contract changes the lanes asked for, and what was decided. Applied changes are in the shared
files in the same commit as this section.

**Applied**

- Regulatory manifests fail closed: an edition is listed only if its `edition.yaml` says
  `merged: true`. The synthetic generator writes the flag (and `domain: payments`, the access
  domain of the document); the reader's `unflagged_is_merged` switch is gone. Lanes affected:
  `sources` (reader), `testing` (generator, fixtures regenerated, only the two manifests change).
- Export locations are settings: `KP_CONFLUENCE_EXPORT_PATH`, `KP_JIRA_EXPORT_PATH`,
  `KP_CODE_REPO_PATH` (fallback: folders under `KP_DATA_DIR`). `sources` factory reads them.
- Known document types are a setting, `KP_DOCUMENT_TYPES` (`Settings.document_types`); the
  sweep gate takes it. `ingest` no longer carries a second list (L2 deleted its copy).
- `KP_GIT_BINARY` is a setting (`Settings.git_binary`); `resolve_git_binary(preferred=...)`
  tries it first, then the environment variable, then `git`.
- Extraction service credential is its own pair of settings, `KP_EXTRACTION_AUTH_HEADER` and
  `KP_EXTRACTION_TOKEN`, set together or not at all. The gateway caller token is never sent to
  the extraction service.
- New table `session_retrieval` (session, reference, tool, time; append-only, no foreign key):
  what the read tools showed each agent session. The citation check on the write side reads it
  ("retrieved in the same session"); read and write servers can be separate processes.
- `ToolRegistry` takes an optional observer, told about every answered call after its audit
  record (used to fill `session_retrieval`). `build_read_registry`, `build_read_server` and
  `ServeWiring` pass it through. An observer failure is logged and never fails a call.
- `index_stories(connection, story_keys=None)` can index only the stories that changed.
- Shared contract 2 and 10 were amended above (named writers; lane error modules).
- Test layout: every test folder with a `conftest.py` is a package, so `mypy src tests` sees
  unique module names; shared helpers are imported as `<folder>.<module>`.
- `optional-dependencies.cloud = ["google-cloud-storage"]` for the bucket object store (imported
  lazily; the native client, credentials from the workload's service account, write-once through
  the generation precondition 0). `s3 = ["boto3"]` is the fallback for an S3-compatible store.

- Merged specs are knowledge (US-23), end to end. The spec repository is a second target of the
  code host's source, under its own cursor scope `specs`
  (`kp.adapters.spec_targets.SpecAwareTargets`, `kp.sources.spec_repo.SpecRepoReader`). It lists
  only files on the base branch. A spec file carries front matter `story`, `spec` (default
  `spec-<story key in lower case>`), `template` (`<id>@<version>`) and `machine_authored`; the
  reader turns it into the GitHub attributes the gate reads (`story_key`, `spec_id`,
  `merged_at`, `machine_authored`, `template`, `merged: true`). `render_spec_file` writes
  `spec` too. Lanes affected: `sources`, `sweep` (gate attribute `template`), `writeback`.
- The links of a spec open when it is merged, not when it is published. A drafted pull request
  is not knowledge, and the open `specified_by` link is what tells the write side that a story
  has a merged spec, so opening it at publication would stop the story from ever being redrafted.
- The load-back links more than before: story `specified_by` spec, spec `derived_from` the
  clauses and the register rows it cites (a row is found by its id or by its own id column), and
  spec `uses_template` the template it names. Their evidence starts with
  `kp.domain.MERGED_SPEC_EVIDENCE`; `LinkService.apply_stated` never closes such a link because
  another loader (the tracker's issue links, which own `specified_by` for their stories) did
  not list it. A newer merged version of the spec closes and opens them from its merge date.
- A spec is implemented by code when a function or class says so in its docstring or a comment:
  `Implements spec <spec id>`. The repository scan states `implemented_by` for a loaded spec,
  rejects an unknown one, and owns the relation for the files it read. With a test that calls the
  function, a rule reaches a test: clause, spec, code, test. The synthetic dataset carries one
  such chain (`spec_repo/` and the annotation in `code_repo/`); the demo merges it before the
  first sweep, exactly as a person's earlier merge.
- Publishers can merge. `SpecMerger.merge(branch)` and `merged_specs()` exist on the local git
  publisher (the file lands on the base branch, the record keeps the merge date) and on the
  dry-run publisher (the record keeps path, text and state). `kp merge-spec <story>` stands in
  for the reviewer in local mode. After a merge the story is not drafted again: `draft_spec`
  skips it with a reason and `SpecPublishingService.publish` refuses (`SpecNotDraftableError`),
  whether the spec was drafted here (its row is `merged`) or only a person wrote it (the open
  `specified_by` link). `LoadedSpec.triggers_draft` stays a report of the load, now consumed by
  these guards instead of nothing.
- New table `spec_correction` (spec, correction, reason, wrong-clause flag, time) and
  `kp.corrections` (US-24 build side): `kp corrections add|report`.
- Real mode is configuration. `build_application` builds the gateway-backed readers
  (`kp.adapters.real_route`), keeps raw copies in the raw bucket (`kp.adapters.raw_store`), reads
  the code links from the swept code items (`kp.adapters.code_checkout`) and refuses to guess a
  write route: `choose_writers` raises in real mode (the gateway's tool calls for writing are not
  proven yet). `KP_DATABASE_URL` is a secret, must be PostgreSQL in real mode, and only `kp
  init-db` creates tables there (`Database.ensure_schema`). `KP_SPEC_REPO` must be
  `<owner>/<repository>` and `KP_SPEC_PATH` a relative path without `..` or `.git`.
- The session behind a citation is the caller's own. `session_retrieval.session_id` holds
  `<caller>/<session label>` (`kp.adapters.retrievals.session_key`) and
  `SessionRetrievals.references` takes the caller, so a second user naming the same session
  label is credited with nothing. Over HTTP a request without `X-KP-Session` belongs to the stable
  session `http-<agent>` of its user instead of a fresh random one, and a read request may carry
  at most 64 KiB. The audit trail clips the arguments of a refused or anonymous call to 2 KiB
  (the digest still covers all of it).
- `RulePort.edition_domain` lets `rule_as_at` answer a clause that does not exist in an edition
  the caller may not read with the same refusal an existing clause gets.
- The vector side is wired: with `KP_SEARCH_VECTOR_ENABLED` the sweep embeds new passages; in
  real mode the flag is refused until a real embedding model exists.

**Rejected**

- New `Relation` values (story implements requirement, code implements clause): SPEC 5.2 fixes
  the model at seven relations and every link is validated against it. Code and tests that cite
  a clause are reported as citations (`RepositoryScan.citations`); a rule reaches a test only
  through a spec.
- An alert table or `ReviewKind` for stale and failing sources: alerts are derived from
  `sweep_cursor.consecutive_failures` and the freshness report; a second record would drift.
- A version column in the requirement key: register history is kept in `source_item`; the
  requirement table holds the current rows only.
- Folding `KP_SEARCH_*` into `Settings`: search tunables are a separate group with their own
  prefix and are read where search is built.
- Transport identity (`KP_CALLER`, `KP_AGENT`, `KP_SESSION_ID`, `KP_SPEC_ID`) as settings: it is
  per-connection identity, not configuration, and must not be shared by processes.
- A second REST base URL and Jira token settings for write-back: real-mode writes go through the
  same gateway (SPEC 4.2); the route is unknown until the first live discover. Until then a
  real-mode write is refused with a message (`choose_writers`). The REST publisher and Jira
  client stay in `kp.writeback` for the day the route is known; nothing selects them.
- `KP_TOKEN_LIFETIME_SECONDS`: the 30 minute reference is the design's figure for criterion
  X-06, not a tunable; the harness records the lifetime it actually sees.

**Policy decisions confirmed**

- An item with no domain label is visible to nobody (access control fails closed). Code, tests,
  schema fields and templates take the domain of the item they were reached from.
- Review-band guessed links (0.55 to below 0.75) are stored in state `review`, listed for a
  person, and never used by any query or count.
- Drafts, pending and non-conforming versions are stored (their raw bytes are needed to match a
  later approval); every consumer filters on `approval_state` (search does).
- Publication (US-15) is a gate and a marker: `knowledge_version.state` records which version
  passed the checks and when the previous one may go. Search, the read tools and the servers read
  the live tables, so a blocked run does not change what they answer; serving from a published
  snapshot is for the switch-over, when the shared database exists.
- Write access fails closed like read access: a story with no domain label is written for by
  nobody. The tool registry refuses a caller without a domain before the write tools are reached
  and the writing service refuses an unlabelled story on its own.

**Known limits**

- The load-back derives a spec's links to register rows when the spec is loaded. A spec swept
  before the register that it cites is linked to its story, clauses and template, but not to the
  rows until the spec changes. The sweep order of one run (library before code host) avoids it.
- `PipelineProcessor` has an `accept_review_band` switch for rulebooks held in the review band; no
  setting turns it on. A person releases such an edition through its review item.

## Repository convention

There is no shared ORM and no repository per aggregate in the foundation. Each lane writes
its own persistence in its own package, as functions or small classes that take a
`sqlalchemy.Connection` from `Database.transaction()`:

```python
with database.transaction() as connection:
    SweepStore(connection).save_cursor(cursor)
```

Rules: use the `kp.store.schema` tables (Core, no raw SQL strings with interpolated values);
convert rows to and from domain models inside the lane's repository module; keep one
transaction per unit of work; never reach into another lane's repository, depend on the
domain models and tables instead. Tests run on in-memory SQLite (`engine` fixture) and must
also be valid on PostgreSQL, so use only dialect-neutral SQL.

## Data conventions

- All datetimes are timezone-aware UTC (`AwareDatetime`, `UtcDateTime` column type). Dates
  that mean "from this day" (`effective_date`, `superseded_from`) are inclusive.
- Lists and mappings are JSON columns. The 768-value embedding is JSON for now; the vector
  side sits behind a search interface so a dedicated extension can replace it.
- Raw content is stored once per `(source, item_id, version)` and never overwritten.
- Digests (SHA-256, lowercase hex) are used wherever a request must be recorded without its
  body (`mcp_call.request_digest`).

## Open specification points resolved here

- `superseded` is an `ApprovalState` value plus a `superseded_at` date column; editions carry
  their own `superseded_from` / `withdrawn_from` dates, which drive the as-at rule.
- `Clause.parent_ref` is the enclosing clause (`4.2` for `4.2.1`). Split parts of a long
  clause are passages (`Passage.parent_ref`, `part_index`), not clauses.
- Edition labels are global keys: `edition.label` is the primary key, so a clause is
  identified by edition + number across the whole build.
- `Requirement.source` exists so register rows key to `source_item`.
- "No edition in force" returns `None` from `select_edition_as_at` rather than raising.
- `tool_call.request` stores the agent's arguments (the audited fact) plus a digest;
  `mcp_call` stores only a digest of the request.
- Thresholds marked provisional in the spec are `Settings.thresholds`, tunable per
  environment. Support enums (review kinds, spec states, run kinds, extraction status,
  check severity, edition state) were added where the spec left them implicit.
- `SPEC.md` is not committed (it names a person and internal documents); it is supplied
  alongside the repository.

## Hygiene rule (non-negotiable)

This code ships to a bank through a public channel. No bank names, hostnames, URLs, bucket
names, namespaces, directory-group names, staff IDs, people's names or secrets anywhere:
code, tests, fixtures, docs or comments. Everything environment-specific is a setting with a
`<placeholder>` example. Use generic names ("agent platform", "gateway", "document extraction
service", "document library", "regulatory repository"). Synthetic data must be obviously
synthetic ("Payments Rulebook" from "Example Scheme"). Before committing, search the tree
for company names, `http`, `@` and absolute paths.
