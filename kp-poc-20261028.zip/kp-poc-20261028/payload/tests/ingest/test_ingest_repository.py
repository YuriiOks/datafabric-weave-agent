"""Repositories: clauses, requirements, stories and review items persist idempotently."""

from __future__ import annotations

from datetime import date

import pytest
from sqlalchemy import Engine, func, select

from ingest.ingest_support import NOW, RUN_ID, XLSX, ItemFactory, seed_run, store_item
from kp.config import Thresholds
from kp.domain import ItemKey, ReviewItem, ReviewKind, SourceKind, Story, StoryLink
from kp.ingest import (
    ClauseStore,
    EditionConflictError,
    EditionStore,
    RequirementStore,
    ReviewStore,
    StoryChange,
    StoryStore,
    normalise_story,
    parse_register,
    parse_rulebook_markdown,
)
from kp.store import Database
from kp.store.schema import clause, edition
from kp.testing.dataset import SyntheticDataset

EFFECTIVE = date(2026, 11, 16)


def _story(key: str = "PAY-1", version: str = "1", **changes: object) -> Story:
    base = Story(
        story_key=key,
        version=version,
        summary="Check the account",
        description="Details.",
        acceptance_criteria="Given X, then Y.",
        links=(StoryLink(link_type="implements", target_key="REQ-1"),),
        parent_key="PAY-0",
        status="To Do",
        domain="payments",
    )
    return base.model_copy(update=changes)


def test_us07_clauses_round_trip_and_second_save_adds_nothing(
    engine: Engine, dataset: SyntheticDataset, thresholds: Thresholds, make_item: ItemFactory
) -> None:
    truth = dataset.truth.edition("2026.1")
    parsed = parse_rulebook_markdown(
        dataset.path(truth.markdown_path).read_text(encoding="utf-8"),
        default_edition=None,
        thresholds=thresholds,
    )
    item = make_item(version="2026.1", media_type="text/markdown")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        EditionStore(connection).ensure(parsed.edition, EFFECTIVE, item.key, item.title)
        store = ClauseStore(connection)
        assert store.save(parsed.clauses) == truth.toc_clause_count
        assert store.save(parsed.clauses) == 0
        assert store.list_for_edition("2026.1") == list(parsed.clauses)
        assert store.list_for_edition("2025.2") == []
        total = connection.execute(select(func.count()).select_from(clause)).scalar_one()
        assert total == truth.toc_clause_count


def test_us07_edition_row_is_created_once_and_left_alone_afterwards(
    engine: Engine, make_item: ItemFactory
) -> None:
    item = make_item(version="2026.1")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        store = EditionStore(connection)
        assert store.ensure("2026.1", EFFECTIVE, item.key, "Payments Rulebook")
        assert not store.ensure("2026.1", date(2030, 1, 1), item.key, "Other")
        found = store.get("2026.1")
        assert found is not None
        assert found.effective_date == EFFECTIVE
        assert found.title == "Payments Rulebook"
        assert (found.source, found.item_id, found.version) == (
            SourceKind.REGULATORY_REPO,
            "item-1",
            "2026.1",
        )
        assert store.get("1900.1") is None
        assert connection.execute(select(func.count()).select_from(edition)).scalar_one() == 1


def test_us07_edition_label_held_by_another_item_version_is_a_conflict(
    engine: Engine, make_item: ItemFactory
) -> None:
    first = make_item(item_id="item-1", version="2026.1")
    other_item = make_item(item_id="item-2", version="2026.1")
    other_version = make_item(item_id="item-1", version="2026.1-corrected")
    with Database(engine).transaction() as connection:
        for item in (first, other_item, other_version):
            store_item(connection, item)
        store = EditionStore(connection)
        assert store.ensure("2026.1", EFFECTIVE, first.key)
        for clash in (other_item, other_version):
            with pytest.raises(EditionConflictError):
                store.ensure("2026.1", EFFECTIVE, clash.key)


def test_us06_requirements_round_trip_and_second_save_adds_nothing(
    engine: Engine, dataset: SyntheticDataset, thresholds: Thresholds, make_item: ItemFactory
) -> None:
    item = make_item(
        item_id="register-1", source=SourceKind.DOCUMENT_LIBRARY, media_type=XLSX, version="1"
    )
    parsed = parse_register(
        dataset.path(dataset.truth.requirements_register.path).read_bytes(),
        key=item.key,
        thresholds=thresholds,
    )
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        store = RequirementStore(connection)
        assert store.replace_for_item(item.key, parsed.requirements) == len(parsed.requirements)
        assert store.replace_for_item(item.key, parsed.requirements) == 0
        assert store.list_for_item(item.key) == list(parsed.requirements)


def test_us06_newer_register_version_replaces_the_rows_of_the_older_one(
    engine: Engine, dataset: SyntheticDataset, thresholds: Thresholds, make_item: ItemFactory
) -> None:
    content = dataset.path(dataset.truth.requirements_register.path).read_bytes()
    old = make_item(item_id="register-1", source=SourceKind.DOCUMENT_LIBRARY, version="1")
    new = make_item(item_id="register-1", source=SourceKind.DOCUMENT_LIBRARY, version="2")
    first = parse_register(content, key=old.key, thresholds=thresholds).requirements
    second = parse_register(content, key=new.key, thresholds=thresholds).requirements[:5]
    with Database(engine).transaction() as connection:
        store_item(connection, old)
        store_item(connection, new)
        store = RequirementStore(connection)
        store.replace_for_item(old.key, first)
        assert store.replace_for_item(new.key, second) == 5
        stored = store.list_for_item(new.key)
        assert [row.version for row in stored] == ["2"] * 5


def test_us06_sheets_the_newer_version_could_not_read_keep_their_rows(
    engine: Engine, dataset: SyntheticDataset, thresholds: Thresholds, make_item: ItemFactory
) -> None:
    content = dataset.path(dataset.truth.requirements_register.path).read_bytes()
    old = make_item(item_id="register-1", source=SourceKind.DOCUMENT_LIBRARY, version="1")
    new = make_item(item_id="register-1", source=SourceKind.DOCUMENT_LIBRARY, version="2")
    first = parse_register(content, key=old.key, thresholds=thresholds).requirements
    with Database(engine).transaction() as connection:
        store_item(connection, old)
        store_item(connection, new)
        store = RequirementStore(connection)
        store.replace_for_item(old.key, first)
        assert store.replace_for_item(new.key, [], keep_sheets={first[0].sheet}) == 0
        assert store.list_for_item(new.key) == list(first)
        assert store.replace_for_item(new.key, []) == 0
        assert store.list_for_item(new.key) == []


def test_us05_story_verdicts_follow_the_fingerprint(engine: Engine) -> None:
    with Database(engine).transaction() as connection:
        store = StoryStore(connection)
        assert store.save(_story(version="2026-10-01")) == StoryChange.NEW
        assert store.save(_story(version="2026-10-02", status="In Progress")) == (
            StoryChange.UNCHANGED
        )
        assert store.save(_story(version="2026-10-03", acceptance_criteria="New.")) == (
            StoryChange.CHANGED
        )
        done = _story(version="2026-10-04", status="Done", acceptance_criteria="New.")
        assert store.save(done) == StoryChange.UNCHANGED
        # Going back to the earlier wording is a change again, not "already seen".
        assert store.save(_story(version="2026-10-05")) == StoryChange.CHANGED
        assert store.save(_story(key="PAY-2", version="2026-10-01")) == StoryChange.NEW


def test_us05_verdicts_compare_with_the_latest_moment_across_tracker_offsets(
    engine: Engine,
) -> None:
    def issue(updated: str, criteria: str, status: str = "To Do") -> Story:
        raw = {
            "key": "PAY-1",
            "fields": {
                "summary": "Check the account",
                "acceptance_criteria": criteria,
                "status": status,
                "updated": updated,
            },
        }
        return normalise_story(raw, default_version="unused")

    with Database(engine).transaction() as connection:
        store = StoryStore(connection)
        # 09:00Z, 09:30Z, 09:45Z: the text of the first one sorts last without normalising.
        assert store.save(issue("2026-10-01T10:00:00.000+0100", "Old.")) == StoryChange.NEW
        assert store.save(issue("2026-10-01T09:30:00.000+0000", "New.")) == StoryChange.CHANGED
        done = issue("2026-10-01T09:45:00.000+0000", "New.", status="Done")
        assert store.save(done) == StoryChange.UNCHANGED


def test_us05_storing_the_same_story_version_again_changes_nothing(engine: Engine) -> None:
    with Database(engine).transaction() as connection:
        store = StoryStore(connection)
        assert store.save(_story(version="v1")) == StoryChange.NEW
        assert store.save(_story(version="v1", summary="Edited")) == StoryChange.UNCHANGED
        stored = store.get("PAY-1", "v1")
        assert stored is not None
        assert stored.summary == "Check the account"


def test_us05_story_round_trips_with_links_and_separate_criteria(engine: Engine) -> None:
    story = _story(version="v1")
    with Database(engine).transaction() as connection:
        store = StoryStore(connection)
        store.save(story)
        assert store.get("PAY-1", "v1") == story
        assert store.get("PAY-1", "v2") is None


def test_us03_review_item_is_stored_once_and_listed_open(engine: Engine) -> None:
    item = ReviewItem(
        review_id="register_header:x",
        kind=ReviewKind.REGISTER_HEADER,
        source=SourceKind.GITHUB,
        item_id="register-1",
        version="1",
        detail="Sheet refused",
        candidates=("2", "5"),
        run_id=RUN_ID,
        created_at=NOW,
    )
    with Database(engine).transaction() as connection:
        seed_run(connection)
        store = ReviewStore(connection)
        assert store.add(item)
        assert not store.add(item)
        assert store.list_open() == [item]


def test_us03_key_of_an_item_formats_for_review_ids() -> None:
    key = ItemKey(source=SourceKind.GITHUB, item_id="register-1", version="3")
    assert str(key) == "github/register-1@3"
