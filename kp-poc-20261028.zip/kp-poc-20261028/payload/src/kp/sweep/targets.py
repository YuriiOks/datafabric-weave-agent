"""The target provider backed by the reader factory."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from kp.config import Settings
from kp.domain import SourceKind
from kp.sources.factory import RealReaderBuilder, StandInLocations, create_readers
from kp.sweep.models import SweepTarget


class FactoryTargetProvider:
    """Builds one sweep target per source with the readers ``kp.sources.factory`` creates.

    :param settings: The platform settings
    :param locations: Overrides for the stand-in export folders (local mode)
    :param real_builders: Builders for the real route, consulted in real mode
    """

    def __init__(
        self,
        settings: Settings,
        *,
        locations: StandInLocations | None = None,
        real_builders: Mapping[SourceKind, RealReaderBuilder] | None = None,
    ) -> None:
        self._settings = settings
        self._locations = locations
        self._real_builders = real_builders

    def targets(self, sources: Sequence[SourceKind]) -> Sequence[SweepTarget]:
        """Build the readers of the named sources, or of every source when none is named.

        :param sources: Sources to sweep; empty means all five
        :return: One target per source, in the order given (or enum order)
        :raises kp.errors.ConfigurationError: If a source cannot be read with these settings
        """
        readers = create_readers(
            self._settings,
            sources or tuple(SourceKind),
            locations=self._locations,
            real_builders=self._real_builders,
        )
        return [SweepTarget(reader) for reader in readers.values()]
