"""Synthetic content served by the fake gateway: nine items in the platform's tool shapes.

Everything is invented and deterministic, so two processes produce identical bytes and
therefore identical version tokens.
"""

from __future__ import annotations

import base64
import hashlib
import io
import zipfile
from dataclasses import dataclass, field
from datetime import UTC, datetime

from openpyxl import Workbook
from pydantic import JsonValue

from kp.connectivity.models import JsonObject

_FIXED_ZIP_TIME = (2026, 1, 1, 0, 0, 0)
_FIXED_DATETIME = datetime(2026, 1, 1, tzinfo=UTC)
_PAGE_TIME = "2026-10-01T09:00:00+00:00"
_COMMIT = "0123456789abcdef0123456789abcdef01234567"
_REPOSITORY = "example-org/example-repo"
_AUTHOR = "Synthetic Author"

# Namespace identifiers required by the Office Open XML file format; they are names, not addresses.
_OOXML = "http://schemas.openxmlformats.org"
_WORD_NS = f"{_OOXML}/wordprocessingml/2006/main"
_PACKAGE_NS = f"{_OOXML}/package/2006"
_OFFICE_NS = f"{_OOXML}/officeDocument/2006/relationships"


@dataclass
class StandInData:
    """The mutable content behind the fake gateway.

    Pages, issues and files are keyed by their native ids; attachments by parent and
    attachment id; files by repository, path and ref.
    """

    pages: dict[str, JsonObject] = field(default_factory=dict)
    page_attachments: dict[tuple[str, str], JsonObject] = field(default_factory=dict)
    issues: dict[str, JsonObject] = field(default_factory=dict)
    issue_attachments: dict[tuple[str, str], JsonObject] = field(default_factory=dict)
    files: dict[tuple[str, str, str], JsonObject] = field(default_factory=dict)


def encode(data: bytes) -> str:
    """Base64-encode bytes as text.

    :param data: The bytes
    :return: ASCII base64
    """
    return base64.b64encode(data).decode("ascii")


def git_blob_sha(data: bytes) -> str:
    """Compute the git blob sha of ``data``.

    :param data: File content
    :return: 40 hexadecimal characters
    """
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data, usedforsecurity=False).hexdigest()


def _zip(entries: dict[str, bytes]) -> bytes:
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, content in entries.items():
            info = zipfile.ZipInfo(name, date_time=_FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    return out.getvalue()


def make_docx(title: str, paragraphs: list[str]) -> bytes:
    """Build a minimal Word document: a heading and some paragraphs.

    :param title: The heading text
    :param paragraphs: Body paragraphs
    :return: The ``.docx`` bytes
    """
    heading = f'<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>{title}</w:t></w:r></w:p>'
    body = "".join(f"<w:p><w:r><w:t>{text}</w:t></w:r></w:p>" for text in paragraphs)
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<w:document xmlns:w="{_WORD_NS}"><w:body>{heading}{body}</w:body></w:document>'
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<Types xmlns="{_PACKAGE_NS}/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.'
        'relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-'
        'officedocument.wordprocessingml.document.main+xml"/>'
        "</Types>"
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<Relationships xmlns="{_PACKAGE_NS}/relationships">'
        f'<Relationship Id="rId1" Type="{_OFFICE_NS}/officeDocument" Target="word/document.xml"/>'
        "</Relationships>"
    )
    return _zip(
        {
            "[Content_Types].xml": content_types.encode("utf-8"),
            "_rels/.rels": rels.encode("utf-8"),
            "word/document.xml": document.encode("utf-8"),
        }
    )


def make_xlsx(sheet_title: str, rows: list[list[str | int]]) -> bytes:
    """Build a one-sheet workbook with reproducible bytes.

    :param sheet_title: The sheet name
    :param rows: Rows of cell values; the first is the header
    :return: The ``.xlsx`` bytes
    """
    workbook = Workbook()
    sheet = workbook.active
    assert sheet is not None  # noqa: S101 - a new workbook always has an active sheet
    sheet.title = sheet_title
    for row in rows:
        sheet.append(row)
    workbook.properties.created = _FIXED_DATETIME
    workbook.properties.modified = _FIXED_DATETIME
    raw = io.BytesIO()
    workbook.save(raw)
    with zipfile.ZipFile(raw) as source:
        entries = {info.filename: source.read(info.filename) for info in source.infolist()}
    core = entries["docProps/core.xml"].decode("utf-8")
    start = core.index("<dcterms:modified")
    end = core.index("</dcterms:modified>") + len("</dcterms:modified>")
    entries["docProps/core.xml"] = (
        core[:start]
        + '<dcterms:modified xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:modified>'
        + core[end:]
    ).encode("utf-8")
    return _zip(entries)


def make_pdf(lines: list[str]) -> bytes:
    """Build a one-page PDF whose text is ``lines``.

    :param lines: Lines of text, top to bottom
    :return: The PDF bytes
    """

    def escape(text: str) -> str:
        return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")

    shown = " T* ".join(f"({escape(line)}) Tj" for line in lines)
    stream = f"BT /F1 12 Tf 14 TL 72 720 Td {shown} ET".encode("latin-1")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
        b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offsets: list[int] = []
    for number, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % number + body + b"\nendobj\n"
    xref_at = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1)
    for offset in offsets:
        out += b"%010d 00000 n \n" % offset
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (
        len(objects) + 1,
        xref_at,
    )
    return bytes(out)


def _page(page_id: str, title: str, body: str) -> JsonObject:
    return {
        "id": page_id,
        "title": title,
        "version": {"number": 1, "when": _PAGE_TIME, "by": _AUTHOR},
        "body": {"storage": {"value": body}},
    }


def _attachment(attachment_id: str, name: str, media_type: str, data: bytes) -> JsonObject:
    return {
        "id": attachment_id,
        "title": name,
        "filename": name,
        "mediaType": media_type,
        "version": {"number": 1, "when": _PAGE_TIME, "by": _AUTHOR},
        "author": _AUTHOR,
        "created": _PAGE_TIME,
        "content_base64": encode(data),
    }


def _issue(key: str, summary: str, description: str, **extra: JsonValue) -> JsonObject:
    fields: JsonObject = {
        "summary": summary,
        "description": description,
        "status": {"name": "To Do"},
        "labels": ["synthetic"],
        "issuelinks": [],
        "reporter": {"displayName": _AUTHOR},
        "updated": _PAGE_TIME,
        "comment": {"comments": []},
    }
    fields.update(extra)
    return {"key": key, "fields": fields}


def _file(path: str, data: bytes) -> JsonObject:
    return {
        "path": path,
        "sha": git_blob_sha(data),
        "size": len(data),
        "encoding": "base64",
        "content": encode(data),
        "commit": _COMMIT,
    }


def build_stand_in_data() -> StandInData:
    """Build the nine synthetic items of the default sample file.

    :return: Fresh, mutable stand-in content
    """
    data = StandInData()
    data.pages["7001"] = _page(
        "7001",
        "Payment operations overview",
        "<h1>Operations overview</h1><p>How inbound transfers are handled.</p>"
        "<h2>Daily cycle</h2><p>Transfers are settled in the next cycle.</p>",
    )
    data.pages["7002"] = _page(
        "7002",
        "Transfer limits by channel",
        "<h1>Limits</h1><table><tr><th>Channel</th><th>Limit</th></tr>"
        "<tr><td>Online</td><td>10000</td></tr><tr><td>Branch</td><td>50000</td></tr></table>",
    )
    data.pages["7003"] = _page("7003", "Reference sheet", "<p>See the attached sheet.</p>")
    pdf = make_pdf(["Reference sheet", "Synthetic attachment for the connectivity proof."])
    data.page_attachments[("7003", "att-7003")] = _attachment(
        "att-7003", "reference-sheet.pdf", "application/pdf", pdf
    )

    data.issues["SYN-101"] = _issue(
        "SYN-101", "Acknowledge received transfers", "Send an acknowledgement for each transfer."
    )
    data.issues["SYN-102"] = _issue(
        "SYN-102",
        "Check the creditor account",
        "Confirm the creditor account exists before accepting funds.",
        issuelinks=[{"key": "SYN-101", "type": "relates to"}],
        comment={
            "comments": [
                {"id": "c1", "body": "Agreed with the business analyst.", "author": _AUTHOR},
                {"id": "c2", "body": "Needs a test for unknown accounts.", "author": _AUTHOR},
            ]
        },
    )
    data.issues["SYN-103"] = _issue(
        "SYN-103", "Update the procedure", "The attached procedure replaces the old one."
    )
    word = make_docx("Procedure", ["Step one: receive.", "Step two: acknowledge."])
    data.issue_attachments[("SYN-103", "att-5001")] = _attachment(
        "att-5001",
        "procedure.docx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        word,
    )

    files = {
        "docs/overview.md": (
            b"# Overview\n\nSynthetic repository notes.\n\n- first point\n- second point\n"
        ),
        "docs/procedure.docx": make_docx(
            "Repository procedure", ["Check the schema.", "Run the tests."]
        ),
        "data/limits.xlsx": make_xlsx(
            "Limits", [["Channel", "Limit"], ["Online", 10000], ["Branch", 50000]]
        ),
    }
    for path, content in files.items():
        data.files[(_REPOSITORY, path, _COMMIT)] = _file(path, content)
    return data
