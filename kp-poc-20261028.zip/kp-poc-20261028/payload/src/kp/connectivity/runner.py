"""The connectivity job: discover, fetch and store the nine items, extract, record.

For each sample item the flow is: fetch through the gateway (the version is derived from the
returned fields), skip when that exact version is already recorded, write the raw object once
under ``source/item/version``, ask the extraction service to convert it (sending a reference,
never bytes), then record the item version and, for every gateway call, a digest of the
request. A run that stops early still writes its evidence.

Item-level results (the tool lost fields, the item is missing, extraction failed for that
object) are recorded and the run goes on. Anything that says the route itself is unusable
(credential refused after one renewal, rate limit exhausted, gateway down, no entitlement, an
extraction answer without extractor version) stops the run with the typed error.

A failed extraction is recorded as a result and is not retried on the next run. An extraction
that never ran (``skip_extraction``, or no extractor) leaves the row ``pending``; the next run
that can extract completes that row from the stored raw object, without a new version.
"""

from __future__ import annotations

import itertools
import logging
import uuid
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from kp.clock import Clock
from kp.connectivity.digest import sha256_hex
from kp.connectivity.discovery import SignatureStore, discover_routes
from kp.connectivity.errors import (
    ConnectivityError,
    ExtractionError,
    FidelityError,
    GatewayProtocolError,
    ImmutableObjectError,
    MissingExtractorVersionError,
)
from kp.connectivity.extraction import ensure_extractor_version
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.ledger import write_run_result
from kp.connectivity.models import (
    HINT_MAX_CHARS,
    ExtractionRequest,
    ItemOutcome,
    ItemStatus,
    Route,
    RunActivity,
    RunResult,
    SampleItem,
    SampleSet,
    ToolResult,
)
from kp.connectivity.ports import ExtractionPort, ObjectStore, SampleFetcher
from kp.connectivity.records import ConnectivityStore, RunCallRecorder, new_run
from kp.connectivity.storage import object_key
from kp.domain import ExtractionStatus, RunOutcome, SourceItemVersion, SourceKind
from kp.errors import KpError, SourceItemNotFoundError
from kp.sources.base import FetchedItem
from kp.store import Database

logger = logging.getLogger(__name__)

# Keeps runs that start within one clock tick in order; the suffix keeps processes apart.
_RUN_SEQUENCE = itertools.count(1)

# Failures about one object: recorded, and the run continues with the next item.
_ITEM_LEVEL = (FidelityError, SourceItemNotFoundError, GatewayProtocolError, ImmutableObjectError)


class ConnectivityRunner:
    """The harness's implementation of :class:`~kp.connectivity.ports.ConnectivityJob`.

    :param database: Where run, item and call rows go
    :param recorder: The call sink the gateway client writes to; shared with the client
    :param client: The gateway client
    :param routes: The tool server of each source
    :param fetchers: How to fetch the current version of an item, by source
    :param samples: The nine sample items
    :param raw_store: Where raw objects are written
    :param extractor: The extraction service; ``None`` skips extraction entirely
    :param signatures: Where tool signatures are kept
    :param ledger_dir: Where run evidence files are kept
    :param clock: Time source
    :param probe_client: A client whose credential is deliberately wrong, for error probes
    """

    def __init__(
        self,
        *,
        database: Database,
        recorder: RunCallRecorder,
        client: GatewayClient,
        routes: Mapping[SourceKind, Route],
        fetchers: Mapping[SourceKind, SampleFetcher],
        samples: SampleSet,
        raw_store: ObjectStore,
        extractor: ExtractionPort | None,
        signatures: SignatureStore,
        ledger_dir: Path,
        clock: Clock,
        probe_client: GatewayClient | None = None,
    ) -> None:
        self._database = database
        self._recorder = recorder
        self._client = client
        self._routes = dict(routes)
        self._fetchers = dict(fetchers)
        self._samples = samples
        self._raw = raw_store
        self._extractor = extractor
        self._signatures = signatures
        self._ledger_dir = ledger_dir
        self._clock = clock
        self._probe_client = probe_client

    def discover(self) -> RunResult:
        """List and keep the tool signatures of all three servers.

        :return: The evidence of the discovery run
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after one renewal
        :raises kp.connectivity.errors.GatewayForbiddenError: If the group does not allow the call
        :raises kp.errors.SourceUnavailableError: If the gateway cannot be reached
        """
        active = self._begin(RunActivity.DISCOVER)
        with self._abort_on_error(active):
            counts = discover_routes(
                self._client,
                tuple(self._routes.values()),
                self._signatures,
                run_id=active.run_id,
                captured_at=active.started_at,
            )
        return self._end(active, RunOutcome.SUCCEEDED, tools=counts)

    def run(self, *, skip_extraction: bool = False) -> RunResult:
        """Fetch, store and extract the nine sample items.

        :param skip_extraction: Store raw objects only, to prove the route first
        :return: The evidence of the run
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after one renewal
        :raises kp.errors.SourceRateLimitedError: If the rate limit outlasts the retries
        :raises kp.errors.SourceUnavailableError: If the gateway cannot be reached
        :raises kp.connectivity.errors.MissingExtractorVersionError: If extraction answers
            without an extractor version
        """
        active = self._begin(RunActivity.FETCH)
        outcomes: list[ItemOutcome] = []
        with self._abort_on_error(active, outcomes):
            for item in self._samples.items:
                outcomes.append(self._process(active.run_id, item, skip_extraction))
        failed = any(outcome.status is ItemStatus.FAILED for outcome in outcomes)
        return self._end(
            active, RunOutcome.PARTIAL if failed else RunOutcome.SUCCEEDED, items=outcomes
        )

    def probe_errors(self) -> RunResult:
        """Provoke a bad credential and a bad parameter so the gateway errors are on record.

        :return: The evidence of the probe run
        :raises kp.connectivity.errors.ConnectivityError: If no probe client is configured or
            discovery has not been run
        """
        probe_client = self._probe_client
        if probe_client is None:
            raise ConnectivityError("No probe client is configured")
        route = next(iter(self._routes.values()))
        signatures = self._signatures.load_latest(route.namespace)
        if not signatures:
            raise ConnectivityError("Run discover before probing errors")
        tool = signatures[0].name

        def bad_credential() -> object:
            return probe_client.list_tools(route)

        def bad_parameter() -> object:
            return self._client.call_tool(route, tool, {})

        active = self._begin(RunActivity.PROBE)
        with self._abort_on_error(active):
            probes = {
                "bad_credential": _provoke(bad_credential),
                "bad_parameter": _provoke(bad_parameter),
            }
        unexpected = [name for name, error in probes.items() if error == "none"]
        outcome = RunOutcome.PARTIAL if unexpected else RunOutcome.SUCCEEDED
        return self._end(active, outcome, probes=probes)

    # -- one item ---------------------------------------------------------------------------

    def _process(self, run_id: str, item: SampleItem, skip_extraction: bool) -> ItemOutcome:
        try:
            fetched = self._fetchers[item.source].fetch_current(item)
            return self._store(run_id, item, fetched, skip_extraction)
        except _ITEM_LEVEL as exc:
            logger.warning(
                "Sample item could not be stored",
                extra={"item_id": item.item_id, "error_class": type(exc).__name__},
            )
            return ItemOutcome(
                item_id=item.item_id,
                source=item.source,
                media_type=item.media_type,
                status=ItemStatus.FAILED,
                error_class=type(exc).__name__,
                detail=str(exc),
            )

    def _store(
        self, run_id: str, item: SampleItem, fetched: FetchedItem, skip_extraction: bool
    ) -> ItemOutcome:
        key = fetched.key
        with self._database.transaction() as connection:
            recorded = ConnectivityStore(connection).extraction_status_of(
                key.source, key.item_id, key.version
            )
        raw_key = object_key(key.source.value, key.item_id, key.version)
        if recorded is None:
            return self._record_new(run_id, item, fetched, raw_key, skip_extraction)
        can_extract = not skip_extraction and self._extractor is not None
        if recorded is ExtractionStatus.PENDING and can_extract:
            return self._complete_pending(item, fetched, raw_key)
        return self._outcome(item, ItemStatus.UNCHANGED, key.version)

    def _record_new(
        self,
        run_id: str,
        item: SampleItem,
        fetched: FetchedItem,
        raw_key: str,
        skip_extraction: bool,
    ) -> ItemOutcome:
        key = fetched.key
        self._raw.put_if_absent(raw_key, fetched.content)
        sha = sha256_hex(fetched.content)
        extraction = self._extract(item, fetched, raw_key, skip_extraction)
        record = SourceItemVersion(
            source=key.source,
            item_id=key.item_id,
            version=key.version,
            native_id=fetched.metadata.native_id,
            content_sha256=sha,
            media_type=item.media_type,
            title=fetched.metadata.title,
            author=fetched.metadata.author,
            modified_at=fetched.metadata.modified_at,
            raw_location=self._raw.location(raw_key),
            markdown_location=extraction.markdown_location,
            fetched_at=self._clock.now(),
            run_id=run_id,
            attachment_parent=_attachment_parent(fetched),
            extraction_status=extraction.status,
            extraction_failure=extraction.failure,
            manifest_location=extraction.manifest_location,
            extractor_version=extraction.extractor_version,
        )
        with self._database.transaction() as connection:
            ConnectivityStore(connection).insert_item(record)
        return self._outcome(
            item, ItemStatus.STORED, key.version, extraction_status=extraction.status
        )

    def _complete_pending(
        self, item: SampleItem, fetched: FetchedItem, raw_key: str
    ) -> ItemOutcome:
        key = fetched.key
        # Same bytes under the same key is a no-op; different bytes would be an immutability error.
        self._raw.put_if_absent(raw_key, fetched.content)
        extraction = self._extract(item, fetched, raw_key, skip=False)
        with self._database.transaction() as connection:
            ConnectivityStore(connection).complete_extraction(
                key.source,
                key.item_id,
                key.version,
                status=extraction.status,
                failure=extraction.failure,
                markdown_location=extraction.markdown_location,
                manifest_location=extraction.manifest_location,
                extractor_version=extraction.extractor_version,
            )
        return self._outcome(
            item, ItemStatus.EXTRACTED, key.version, extraction_status=extraction.status
        )

    def _extract(
        self, item: SampleItem, fetched: FetchedItem, raw_key: str, skip: bool
    ) -> _Extraction:
        if skip or self._extractor is None:
            return _Extraction(ExtractionStatus.PENDING)
        metadata = fetched.metadata
        hints = {"native_id": metadata.native_id, "title": metadata.title}
        if metadata.author:
            hints["author"] = metadata.author
        if metadata.modified_at:
            hints["modified_at"] = metadata.modified_at.isoformat()
        request = ExtractionRequest(
            item_id=item.item_id,
            source_type=item.source,
            version=fetched.key.version,
            storage_reference=self._raw.location(raw_key),
            media_type=item.media_type,
            hints={name: value[:HINT_MAX_CHARS] for name, value in hints.items()},
        )
        try:
            response = ensure_extractor_version(self._extractor.extract(request))
        except MissingExtractorVersionError:
            raise
        except ExtractionError as exc:
            return _Extraction(ExtractionStatus.FAILED, failure=f"{type(exc).__name__}: {exc}")
        return _Extraction(
            ExtractionStatus.SUCCEEDED,
            markdown_location=response.markdown_location,
            manifest_location=response.manifest_location,
            extractor_version=response.extractor_version,
        )

    @staticmethod
    def _outcome(
        item: SampleItem,
        status: ItemStatus,
        version: str,
        *,
        extraction_status: ExtractionStatus | None = None,
    ) -> ItemOutcome:
        return ItemOutcome(
            item_id=item.item_id,
            source=item.source,
            media_type=item.media_type,
            status=status,
            version=version,
            extraction_status=extraction_status,
        )

    # -- run bookkeeping --------------------------------------------------------------------

    def _begin(self, activity: RunActivity) -> _ActiveRun:
        started = self._clock.now()
        sequence = next(_RUN_SEQUENCE)
        run_id = f"{activity.value}-{started:%Y%m%dT%H%M%S}-{sequence:06d}-{uuid.uuid4().hex[:8]}"
        with self._database.transaction() as connection:
            ConnectivityStore(connection).begin_run(new_run(run_id, started, tuple(self._routes)))
        self._recorder.start(run_id)
        return _ActiveRun(run_id, activity, started)

    @contextmanager
    def _abort_on_error(
        self, active: _ActiveRun, items: list[ItemOutcome] | None = None
    ) -> Iterator[None]:
        """Close the run as failed, with its evidence file, when the body raises anything."""
        try:
            yield
        except Exception as exc:
            self._end(active, RunOutcome.FAILED, items=items, abort=exc)
            raise

    def _end(
        self,
        active: _ActiveRun,
        outcome: RunOutcome,
        *,
        items: list[ItemOutcome] | None = None,
        tools: dict[str, int] | None = None,
        probes: dict[str, str] | None = None,
        abort: Exception | None = None,
    ) -> RunResult:
        self._recorder.stop()
        ended = self._clock.now()
        result = RunResult(
            run_id=active.run_id,
            activity=active.activity,
            started_at=active.started_at,
            ended_at=ended,
            outcome=outcome,
            items=tuple(items or ()),
            tools_by_namespace=tools or {},
            probes=probes or {},
            abort_reason=type(abort).__name__ if abort is not None else None,
        )
        with self._database.transaction() as connection:
            ConnectivityStore(connection).finish_run(
                active.run_id,
                ended_at=ended,
                outcome=outcome,
                items_touched=result.touched_count,
            )
        write_run_result(self._ledger_dir, result)
        logger.info(
            "Connectivity run finished",
            extra={
                "run_id": active.run_id,
                "activity": active.activity.value,
                "outcome": outcome.value,
                "stored": result.stored_count,
                "extracted": result.touched_count - result.stored_count,
            },
        )
        return result


@dataclass(frozen=True, slots=True)
class _ActiveRun:
    run_id: str
    activity: RunActivity
    started_at: datetime


@dataclass(frozen=True, slots=True)
class _Extraction:
    status: ExtractionStatus
    failure: str | None = None
    markdown_location: str | None = None
    manifest_location: str | None = None
    extractor_version: str | None = None


def _attachment_parent(fetched: FetchedItem) -> str | None:
    parent = fetched.metadata.attributes.get("attachment_parent")
    return parent if isinstance(parent, str) else None


def _provoke(action: Callable[[], object]) -> str:
    """Run an action that should fail; return the error class it produced, or ``none``."""
    try:
        outcome = action()
    except KpError as exc:
        return type(exc).__name__
    if isinstance(outcome, ToolResult) and outcome.is_error:
        return "ToolError"
    return "none"
