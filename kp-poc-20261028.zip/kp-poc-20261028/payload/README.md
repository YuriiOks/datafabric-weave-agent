# Knowledge platform

Governed sources in, clause-level references and search out, links and impact in between,
and read/write tools for agents on top. `ARCHITECTURE.md` has the module map, the shared
contracts and the integration decisions; `SPEC.md` (supplied separately) has the requirements.

## Try it

```bash
kp demo            # builds a database on the synthetic data and judges the three plan lines
```

`kp demo` runs the whole platform locally: sweep of the five sources, ingest, index, links
(stated and guessed), a published knowledge version, the connectivity job against stand-ins.
It prints the three "done when" lines as PASS or FAIL with evidence, writes `kp-demo/report.html`
(self-contained) and `kp-demo/summary.json`, and exits 0 only if all three pass. Options:
`--data DIR`, `--db PATH`, `--report PATH`, `--summary PATH`, `--workdir DIR`.

## Run the UI

A server-rendered web UI for search, rules, impact, coverage, specs, connectivity and the audit
trail. It needs the `web` extra and nothing else: no scripts, fonts or images are fetched, so it
works offline.

```bash
uv pip install --python .venv/bin/python -e '.[web]'
kp demo                                                   # once, to have a database to look at
kp web --db kp-demo/kp-demo.db --today 2026-11-20         # then open port 8090 on 127.0.0.1
```

`kp web [--host 127.0.0.1] [--port 8090] [--db PATH]` shows the database of `--db` (default
`KP_DATABASE_URL`). Beside a `kp demo` database it finds the identity mapping and the connectivity
run by itself; elsewhere pass `--identity-mapping PATH` (or `KP_IDENTITY_MAPPING_FILE`) and
`--connectivity-db PATH`. `--today` treats a date as today, because the demo's data lies after
the real date. A host other than loopback is refused unless `--trusted-proxy` says a proxy that
authenticates users sits in front, and `--trusted-proxy` is refused in local mode, where any
client could choose who it is: it needs `KP_MODE=real`.

| Page | What it answers |
|---|---|
| Overview | Which knowledge version serves, how fresh each source is, what the base holds, stated against guessed links |
| Search | A question (optionally as at a date) with clause, page, position, version and quoted text; the number hidden by access |
| Rule | A clause as at a date, with every edition and its effective dates |
| Impact | What a changed clause reaches within three steps, each marked stated or guessed |
| Coverage | Rules with no test and how many stories are tied to each |
| Specs | Draft the spec of a story, with citations, the citation rate against its target, flagged statements and the pull request record. Drafting writes nothing |
| Connectivity | The X-01..X-11 report of the last connectivity run, with its verdict |
| Audit | The recorded tool calls, refusals included, filtered by spec |

Who is signed in. In local mode a "Signed in as" selector lists the test users of the identity
mapping. In real mode (`KP_MODE=real`) the user comes only from one request header, named by
`KP_WEB_IDENTITY_HEADER` (default `X-KP-Caller`); a `user` value in a link or form is ignored.
The UI trusts that header, so run it behind something that authenticates people and sets it. The
allowed domains always come from the identity mapping. A user with no access gets the forbidden
state (status 403) on every page, never an empty list. Every question asked in the UI goes through
the same read tools an agent uses and is recorded in the audit trail.

## Commands

| Command | What it does |
|---|---|
| `kp init-db [--templates DIR]` | Create the tables; load governed templates |
| `kp sweep [--source S] [--freshness]` | Sweep sources (parse, index, link) or list stale ones |
| `kp search "<question>" [--as-at D]` | Passages and exact clauses with page and position |
| `kp impact <clause>` / `kp coverage` | What a changed rule affects; rules with no test |
| `kp publish [--dry-run]` | Run the publication checks; switch to a new knowledge version |
| `kp serve-read` / `kp serve-write` | MCP servers for agents (stdio, or `--http PORT`) |
| `kp draft-spec <story> [--publish]` | Reference client: draft a spec, optionally open the pull request; a story whose spec was already merged is skipped |
| `kp merge-spec <story>` | Local mode: merge the story's spec pull request (stands in for the reviewer); the next `kp sweep` loads the merged spec back as knowledge |
| `kp corrections add\|report` | Record what a product owner corrected in a drafted spec and why; report citation rate, wrong-clause count and correction count per spec |
| `kp connectivity discover\|run\|report` | The connectivity job and exit-criteria report |
| `kp demo` | The end-to-end demonstration above |
| `kp web [--db PATH]` | The web UI (see "Run the UI"); needs the `web` extra |

The application is assembled in one place, `kp.app.build_application(settings)`.

## Set up

Python 3.11 or newer. On a development machine with uv:

```bash
uv venv --python 3.11 .venv
uv pip install --python .venv/bin/python -e '.[dev]'
```

On the workstation use `python3 -m venv` and `pip` against the package mirror instead; the steps
are in `INSTALL-WORKSTATION.md`. The tool servers need no extra (they use the standard library
only). The `cloud` extra adds the Cloud Storage client for the real-route bucket store (the `s3`
extra is an alternative for an S3-compatible store) and the `postgres` extra adds the PostgreSQL
driver.

## Run the checks

```bash
scripts/check.sh      # ruff check, ruff format --check, mypy, pytest
```

The script uses `.venv` when present. Tests need no network, no bank access and no secrets.

## Configuration

Everything environment-specific is a `KP_`-prefixed environment variable (see
`src/kp/config.py`). Local mode (the default) needs none. Real mode needs every one of these
placeholders replaced by a real value, and a PostgreSQL database (SQLite is refused):

```bash
KP_MODE=real
KP_DATABASE_URL=<postgresql-address>            # a secret once it holds a password
KP_GATEWAY_BASE_URL=<gateway-base-url>
KP_GATEWAY_TOKEN_URL=<token-endpoint>
KP_GATEWAY_CLIENT_ID=<client-id>
KP_GATEWAY_CLIENT_SECRET=<from the secret store>
KP_GATEWAY_TOKEN_HEADER=<caller-identity-header-name>
KP_SOURCE_TOKEN_HEADER=<source-credential-header-name>
KP_USE_CASE_ID=<issued-identifier>
KP_EXTRACTION_BASE_URL=<extraction-endpoint>
KP_RAW_BUCKET=<bucket>
KP_MARKDOWN_BUCKET=<bucket>
KP_SPEC_REPO=<org>/<repository>
KP_SPEC_PATH=<directory-for-specs>
KP_JIRA_FIELDS_ALLOWED='["status", "<link-field>"]'
```

The connectivity job also needs the three tool namespaces and the three source tokens. See
`INSTALL-WORKSTATION.md` section 7 for the exact minimum of each step and where each value
comes from. In real mode only `kp init-db` creates tables.

Secrets are never logged and never committed.

## Synthetic data

`fixtures/generated/` holds a committed, obviously fictional dataset (a "Payments Rulebook"
from "Example Scheme" and its neighbours). Regenerate it with:

```bash
.venv/bin/python -m kp.testing.regenerate
```

The same seed gives byte-identical text files.
