"""Relation facts with stable keys, aggregated evidence, counts and a retirement diff.

A relation is one ``(source, link type, target)`` fact the deterministic catalogue
accepted. This package gives each relation a key that survives a rebuild. It gathers
every source declaration behind a relation into one evidence set with its own digest,
counts what the sources declared against what was published, and compares two builds,
so a relation leaves the graph only when a complete source says it should.

The package deliberately imports nothing at package level: :mod:`.keys` and
:mod:`.evidence` are imported by the link builder, while :mod:`.diff` is imported by
the transition gate, and neither side may pull the other in.
"""
