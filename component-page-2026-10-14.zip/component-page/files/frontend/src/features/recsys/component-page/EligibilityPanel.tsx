import type { CSSProperties } from 'react'
import { Link } from 'react-router-dom'
import { canRecommend, isProd } from './model'
import type { ComponentPageModel } from './model'
import { ProdPill } from './SourceCard'
import { mutedStyle, sectionCardStyle, sectionHeaderStyle, sectionLabelStyle } from './styles'

type Props = {
  model: ComponentPageModel
  wide: boolean
  /** Route of the Recommend page for a need like this one. */
  recommendTo?: string | undefined
  onRecommend?: (() => void) | undefined
}

/**
 * Eligibility, the Prod pill and the "Recommend" action. Only a component that `canRecommend`
 * accepts gets the action.
 */
export function EligibilityPanel({ model, wide, recommendTo, onRecommend }: Props) {
  const prod = isProd(model.source.environment)
  const notProd = model.source.environment !== null && !prod
  const action = canRecommend(model) ? <RecommendAction recommendTo={recommendTo} onRecommend={onRecommend} /> : null

  const status = (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', flexWrap: 'wrap' }}>
      <EligibleBadge eligible={model.eligible} />
      {prod && <ProdPill />}
    </div>
  )
  const note = notProd ? (
    <div role="note" style={warnStyle}>
      Taken from {model.source.environment}, not Prod. It is not recommended until it is tested in Prod.
    </div>
  ) : !model.eligible ? (
    <div style={{ ...mutedStyle, fontSize: '0.75rem' }}>Not eligible, so it is never recommended.</div>
  ) : prod ? (
    <div style={{ ...mutedStyle, fontSize: '0.75rem' }}>Tested in Prod. Only Prod is ingested.</div>
  ) : null

  if (!wide) {
    return (
      <section aria-label="Eligibility" style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
        {status}
        {note}
        {action}
      </section>
    )
  }

  return (
    <section style={sectionCardStyle} aria-label="Eligibility">
      <div style={sectionHeaderStyle}>
        <h2 style={sectionLabelStyle}>Eligibility</h2>
      </div>
      <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
        {status}
        {note}
        {action}
      </div>
    </section>
  )
}

function EligibleBadge({ eligible }: { eligible: boolean }) {
  return (
    <span
      style={{
        ...badgeStyle,
        color: eligible ? 'var(--color-success-text, #237804)' : 'var(--color-text-secondary)',
      }}
    >
      <span
        aria-hidden="true"
        style={{
          width: 8,
          height: 8,
          borderRadius: '50%',
          background: eligible ? 'var(--color-success, #52c41a)' : 'var(--color-border, #d9d9d9)',
        }}
      />
      {eligible ? 'Eligible' : 'Not eligible'}
    </span>
  )
}

function RecommendAction({ recommendTo, onRecommend }: { recommendTo?: string | undefined; onRecommend?: (() => void) | undefined }) {
  if (recommendTo) {
    return (
      <Link to={recommendTo} style={ctaStyle}>
        Recommend for a need like this
      </Link>
    )
  }
  if (onRecommend) {
    return (
      <button type="button" onClick={onRecommend} style={{ ...ctaStyle, border: 'none', cursor: 'pointer' }}>
        Recommend for a need like this
      </button>
    )
  }
  return null
}

const badgeStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 6,
  fontSize: 'var(--text-sm)',
  fontWeight: 600,
}

const warnStyle: CSSProperties = {
  fontSize: '0.75rem',
  lineHeight: 1.5,
  padding: 'var(--space-2) var(--space-3)',
  borderRadius: 'var(--radius-md)',
  background: 'rgba(250, 173, 20, 0.1)',
  border: '1px solid rgba(250, 173, 20, 0.45)',
  color: 'var(--color-text-primary)',
}

const ctaStyle: CSSProperties = {
  display: 'block',
  width: '100%',
  boxSizing: 'border-box',
  textAlign: 'center',
  padding: '10px 16px',
  borderRadius: 'var(--radius-md)',
  background: 'var(--color-primary)',
  color: '#ffffff',
  fontSize: 'var(--text-sm)',
  fontWeight: 600,
  fontFamily: 'inherit',
  textDecoration: 'none',
}
