"""What a changed rule affects: items up to three steps away, each marked stated or guessed."""

from __future__ import annotations

from collections import deque
from typing import Final

from kp.domain import ClauseRef, DomainModel, ItemRef, ItemType, LinkKind, Relation
from kp.links.graph import Edge, LinkGraph
from kp.links.refs import clause_item

IMPACT_MAX_STEPS: Final = 3

# Items a change can reach through. Other clauses and templates are never walked through:
# a template shared by many specs, or a sibling clause, would otherwise make unrelated
# work look affected.
_WALKED = frozenset(
    {ItemType.REQUIREMENT, ItemType.STORY, ItemType.SPEC, ItemType.CODE, ItemType.TEST}
)
# Reported, but a leaf: the field a clause resolves to is affected, not what else uses it.
_REPORTED = _WALKED | {ItemType.SCHEMA_FIELD}
_TYPE_ORDER = (
    ItemType.REQUIREMENT,
    ItemType.STORY,
    ItemType.SPEC,
    ItemType.CODE,
    ItemType.TEST,
    ItemType.SCHEMA_FIELD,
)


class ImpactStep(DomainModel):
    """One link crossed on the way to an item."""

    from_key: str
    relation: Relation
    to_key: str
    forward: bool
    kind: LinkKind
    score: float | None = None


class ImpactItem(DomainModel):
    """An item a rule change reaches.

    ``kind`` is ``stated`` when some path of at most the step limit uses only stated links
    (that path is shown), and ``guessed`` when every path uses at least one guessed link
    (the shortest is shown).
    """

    ref: ItemRef
    distance: int
    kind: LinkKind
    path: tuple[ImpactStep, ...]


class ImpactReport(DomainModel):
    """The answer to "this rule changed, what is affected".

    ``message`` is set when nothing is affected, and says why, so an empty list is never
    mistaken for "no impact".
    """

    clause: str
    max_steps: int
    items: tuple[ImpactItem, ...]
    message: str | None = None

    @property
    def stated_count(self) -> int:
        """Items reached through stated links only."""
        return sum(1 for item in self.items if item.kind is LinkKind.STATED)

    @property
    def guessed_count(self) -> int:
        """Items reached only through at least one guessed link."""
        return len(self.items) - self.stated_count

    def of_type(self, item_type: ItemType) -> tuple[ImpactItem, ...]:
        """Select the affected items of one type.

        :param item_type: The item type
        :return: Those items, nearest first
        """
        return tuple(item for item in self.items if item.ref.item_type is item_type)


def _step(edge: Edge, origin: ItemRef) -> ImpactStep:
    return ImpactStep(
        from_key=origin.key,
        relation=edge.link.relation,
        to_key=edge.other.key,
        forward=edge.forward,
        kind=edge.link.kind,
        score=edge.link.score,
    )


def _shortest_paths(
    graph: LinkGraph, start: ItemRef, max_steps: int
) -> dict[ItemRef, tuple[ImpactStep, ...]]:
    """Breadth-first search over links in either direction; the first path found is shortest."""
    paths: dict[ItemRef, tuple[ImpactStep, ...]] = {}
    queue: deque[tuple[ItemRef, tuple[ImpactStep, ...]]] = deque([(start, ())])
    seen = {start}
    while queue:
        node, path = queue.popleft()
        if len(path) == max_steps:
            continue
        for edge in sorted(graph.edges(node), key=lambda e: (e.other.item_type, e.other.key)):
            if edge.other in seen or edge.other.item_type not in _REPORTED:
                continue
            seen.add(edge.other)
            reached = (*path, _step(edge, node))
            paths[edge.other] = reached
            if edge.other.item_type in _WALKED:
                queue.append((edge.other, reached))
    return paths


def impact_of_clause(
    graph: LinkGraph, clause: ClauseRef, max_steps: int = IMPACT_MAX_STEPS
) -> ImpactReport:
    """Find what a change to a clause affects.

    Links are followed in either direction up to ``max_steps`` away. Each item carries the
    path to it and is marked ``stated`` when a stated-only path exists within the limit.

    :param graph: The links in use
    :param clause: The changed clause
    :param max_steps: How many links away to look; three by default
    :return: The affected items, nearest first, or an explicit message when the clause has
        no links
    :raises ValueError: If ``max_steps`` is less than one
    """
    if max_steps < 1:
        raise ValueError("max_steps must be at least 1")
    start = clause_item(clause)
    reference = clause.format()
    if not graph.edges(start):
        return ImpactReport(
            clause=reference,
            max_steps=max_steps,
            items=(),
            message=(
                f"No links are recorded for clause {reference}, so nothing is known to be "
                "affected. This is a gap in the links, not proof of no impact."
            ),
        )
    any_path = _shortest_paths(graph, start, max_steps)
    stated_path = _shortest_paths(graph.stated_only(), start, max_steps)
    items = [
        ImpactItem(
            ref=ref,
            distance=len(stated_path.get(ref, path)),
            kind=LinkKind.STATED if ref in stated_path else LinkKind.GUESSED,
            path=stated_path.get(ref, path),
        )
        for ref, path in any_path.items()
    ]
    items.sort(
        key=lambda item: (item.distance, _TYPE_ORDER.index(item.ref.item_type), item.ref.key)
    )
    return ImpactReport(clause=reference, max_steps=max_steps, items=tuple(items))
