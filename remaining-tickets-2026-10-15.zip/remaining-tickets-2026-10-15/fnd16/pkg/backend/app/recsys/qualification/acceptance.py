"""The committed acceptance matrix for the graph and controlled-refresh delivery.

Rows follow the architecture's nineteen acceptance scenarios, the seven controlled-refresh
cases, the delayed-source regression extensions and the release gates. A row that needs a
validated candidate is blocked by the two source registrations and the deployed image's
missing workbook reader, because no real refresh reaches validation until they change. A
test reference names where evidence exists, never that it passed.
"""

from __future__ import annotations

from app.recsys.qualification.matrix import (
    AcceptanceMatrix,
    AcceptanceMode,
    AcceptanceRow,
    Blocker,
    EvidenceKind,
    OwnerRole,
    RequirementSource,
    RowStatus,
)

#: A validated candidate is needed: the two registrations stop every refresh short of one,
#: and the deployed image cannot read the acquired workbook.
CANDIDATE = ("B1", "B2", "B4")

#: A second publication from a changed export is needed as well.
CHANGED_EXPORT = (*CANDIDATE, "B3")

_ARCH = RequirementSource.architecture_scenario
_REFRESH = RequirementSource.refresh_case
_GATE = RequirementSource.release_gate
_CONTRACTS = OwnerRole.contracts_owner
_ADAPTERS = OwnerRole.adapters_owner
_PLANNED = RowStatus.planned
_NOT_RUN = RowStatus.not_run
_BLOCKED = RowStatus.blocked

_FIXTURE_GAP = (
    "Stale-fence and lost-acknowledgement fixtures exist for the refresh protocol; "
    "the integrated fault run needs a validated candidate."
)
_UNMAPPED_GAP = "The covering test on the current checkout is not yet mapped."

BLOCKERS: tuple[Blocker, ...] = (
    Blocker(
        blocker_id="B1",
        summary=(
            "The skills registration declares its ordering unknown at revision 0, so a "
            "catalogue built from it is never validated."
        ),
        decision="The source owner chooses a monotonic revision for the skills repository.",
        owner_role=OwnerRole.source_owner,
    ),
    Blocker(
        blocker_id="B2",
        summary=(
            "Both registrations claim the skill-content collection, so the publisher "
            "refuses the capture as a disagreement."
        ),
        decision="Decide which of the two sources owns skill content.",
        owner_role=OwnerRole.source_owner,
    ),
    Blocker(
        blocker_id="B3",
        summary=(
            "The workbook registration pins one revision for every export, so a changed "
            "export is refused as a reused revision."
        ),
        decision="Derive the workbook revision from each export, or register each export.",
        owner_role=OwnerRole.source_owner,
    ),
    Blocker(
        blocker_id="B4",
        summary="The deployed image has no workbook reader, so an acquired export is refused.",
        decision="Ship the optional workbook reader in the deployed image.",
        owner_role=OwnerRole.platform_owner,
    ),
    Blocker(
        blocker_id="B5",
        summary=(
            "No loader returns the previous validated candidate, so builds run without "
            "reuse, carried sources or retirement proposals."
        ),
        decision="Add the previous-candidate loader to the catalogue port.",
        owner_role=_CONTRACTS,
    ),
    Blocker(
        blocker_id="B6",
        summary=(
            "Publication reads and the read policy are not mounted; registry reads stay "
            "refused."
        ),
        decision="Mount the publication reads behind an implemented read policy.",
        owner_role=_CONTRACTS,
    ),
    Blocker(
        blocker_id="B7",
        summary="The owner reference rules are not part of the refresh configuration.",
        decision="Add the owner rules file to the registered configuration.",
        owner_role=_CONTRACTS,
    ),
    Blocker(
        blocker_id="B8",
        summary="Production has no operator authority service, so production refresh is refused.",
        decision="Deliver the operator authority service.",
        owner_role=OwnerRole.platform_owner,
    ),
    Blocker(
        blocker_id="Q1",
        summary="Latency, freshness, resource and capacity limits have no named owner.",
        decision="Name the domain and platform owners and fix the limits before the run.",
        owner_role=OwnerRole.platform_owner,
    ),
    Blocker(
        blocker_id="Q2",
        summary="The per-type case packs carry no adjudicated labels.",
        decision="Domain reviewers judge the cases and freeze the final test.",
        owner_role=OwnerRole.domain_reviewers,
    ),
)

ARCHITECTURE_ROWS: tuple[AcceptanceRow, ...] = (
    AcceptanceRow(
        requirement_id="A01",
        source=_ARCH,
        title="Reordered export rows and a renamed mapped folder",
        observable_result=(
            "Stable ids and an unchanged semantic edge set on reorder; a reviewed rename "
            "keeps identity while affected aliases and display properties change explicitly."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        gap=_UNMAPPED_GAP,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="A02",
        source=_ARCH,
        title="Duplicate MCP id and an ambiguous tool prefix",
        observable_result=(
            "No guessed edge and no order-dependent suffix; evidence and affected-reference "
            "counts stay visible to operators."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        gap=_UNMAPPED_GAP,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="A03",
        source=_ARCH,
        title="The same external id in two tenants and in two environments",
        observable_result="No cross-scope identity, traversal, cache or aggregate leakage.",
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.ci_job,
        status=_BLOCKED,
        blocked_by=("B6",),
    ),
    AcceptanceRow(
        requirement_id="A04",
        source=_ARCH,
        title="An empty description on an otherwise valid Agent",
        observable_result=(
            "The node and its valid declared edges stay visible with a quality reason; no "
            "readiness or approval claim."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        gap=_UNMAPPED_GAP,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="A05",
        source=_ARCH,
        title="A missing sheet or header, a partial export, a valid row turning invalid",
        observable_result=(
            "No inferred removal or silent promotion; the active publication stays unchanged "
            "until policy permits a reviewed result."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=CANDIDATE,
    ),
    AcceptanceRow(
        requirement_id="A06",
        source=_ARCH,
        title="A valid full snapshot removes an edge; an input claims delta mode",
        observable_result=(
            "The edge leaves only in the next active publication; the importer rejects delta "
            "mode and infers no deletion."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=(*CHANGED_EXPORT, "B5"),
    ),
    AcceptanceRow(
        requirement_id="A07",
        source=_ARCH,
        title="A crash after a graph batch, seal or activation; a lost acknowledgement",
        observable_result=(
            "Readers see a complete old or new publication; uncertain builders are abandoned "
            "and rebuilt; a sealed activation retries idempotently from its recorded outcome."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        gap=_FIXTURE_GAP,
        status=_BLOCKED,
        blocked_by=CANDIDATE,
    ),
    AcceptanceRow(
        requirement_id="A08",
        source=_ARCH,
        title="Two imports race; a former worker resumes late",
        observable_result=(
            "Losing ownership abandons the key for good; a delayed stale write cannot touch "
            "active data or overwrite a newer publication."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        gap=_FIXTURE_GAP,
        status=_BLOCKED,
        blocked_by=CANDIDATE,
    ),
    AcceptanceRow(
        requirement_id="A09",
        source=_ARCH,
        title="Graph down, a query timeout, an authoritative zero-relationship answer",
        observable_result=(
            "Unavailable, timeout and successful empty stay distinct; no disk fallback poses "
            "as a graph result."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.ci_job,
        status=_BLOCKED,
        blocked_by=("B6",),
    ),
    AcceptanceRow(
        requirement_id="A10",
        source=_ARCH,
        title="A permission revoked after a cursor, cache or rollback target exists",
        observable_result=(
            "Current policy denies the object and its connecting paths; nothing resurfaces "
            "through historical state."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.ci_job,
        status=_BLOCKED,
        blocked_by=("B6",),
    ),
    AcceptanceRow(
        requirement_id="A11",
        source=_ARCH,
        title="A dependency cycle, a high-degree Agent, an oversized request",
        observable_result=(
            "Bounded expansion, typed validation and visible truncation; no unbounded "
            "traversal."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.ci_job,
        status=_BLOCKED,
        blocked_by=("B6",),
    ),
    AcceptanceRow(
        requirement_id="A12",
        source=_ARCH,
        title="An Agent without a native Hub binding",
        observable_result=(
            "The graph stays valid and explicitly unbound; no native relationship or "
            "name-based attachment is implied."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        gap=_UNMAPPED_GAP,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="A13",
        source=_ARCH,
        title="Prompt-like source text, unsafe HTML and path traversal",
        observable_result=(
            "Text stays data, HTML is safe and paths are rejected; no tool execution or "
            "remote fetch."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        gap=_UNMAPPED_GAP,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="A14",
        source=_ARCH,
        title="Roll back, then reclaim expired generations",
        observable_result=(
            "The retained target is validated; active and in-flight data survive; expired "
            "cursors restart; only owned inactive keys are removed."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=(*CANDIDATE, "B6"),
    ),
    AcceptanceRow(
        requirement_id="A15",
        source=_ARCH,
        title="The evidence surface with a keyboard and unavailable or stale data",
        observable_result="Accessible list or query evidence with clear status and provenance.",
        owner_role=_ADAPTERS,
        evidence_kind=EvidenceKind.manual_rehearsal,
        status=_BLOCKED,
        blocked_by=("B6",),
    ),
    AcceptanceRow(
        requirement_id="A16",
        source=_ARCH,
        title="Enabling the graph feature on the existing branch",
        observable_result=(
            "No model calls, recommendation runs, native graph or index changes, and no "
            "regression in current Hub workflows."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        evidence_reference="tests/recsys/refresh/test_runtime.py",
        gap="Covers the disabled runtime and the guarded router mount, not an enabled run.",
        status=_NOT_RUN,
    ),
    AcceptanceRow(
        requirement_id="A17",
        source=_ARCH,
        title="Cleanup selects a rollback target while an old cursor is valid",
        observable_result=(
            "The shared reservation keeps the rollback target; a fixed cursor lifetime plus "
            "read grace protects valid reads."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=(*CANDIDATE, "B6"),
    ),
    AcceptanceRow(
        requirement_id="A18",
        source=_ARCH,
        title="A newer source removes an edge; a delayed older source tries activation",
        observable_result=(
            "The collection-version regression is rejected and the retired fact stays "
            "absent; new evidence or a new publication cannot bring back a denied relation."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=CHANGED_EXPORT,
    ),
    AcceptanceRow(
        requirement_id="A18-age",
        source=_ARCH,
        title="A source carried into a newer publication",
        observable_result=(
            "A carried source keeps its original capture age; carrying never refreshes its "
            "freshness."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=(*CANDIDATE, "B5"),
    ),
    AcceptanceRow(
        requirement_id="A18-order",
        source=_ARCH,
        title="A source whose revisions cannot be ordered",
        observable_result="Activation refuses the ambiguous ordering instead of guessing it.",
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        gap=(
            "The catalogue build already refuses unknown ordering; in an integrated run the "
            "skill-content disagreement is refused first and hides it."
        ),
        status=_BLOCKED,
        blocked_by=("B2",),
    ),
    AcceptanceRow(
        requirement_id="A19",
        source=_ARCH,
        title="An alias moves from one component to another; one identity splits",
        observable_result=(
            "Old publications keep their mapping and endpoints; new ambiguous references stay "
            "unresolved; redirects are separate and derived caches invalidate."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=CHANGED_EXPORT,
    ),
)

REFRESH_ROWS: tuple[AcceptanceRow, ...] = (
    AcceptanceRow(
        requirement_id="R01",
        source=_REFRESH,
        title="Unauthorised or unconfigured request",
        observable_result=(
            "No job and no source access; the status reports unsupported or unavailable; "
            "there is no unauthenticated refresh endpoint."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        evidence_reference="tests/recsys/refresh/test_integration_authority.py",
        gap="Covers the pre-production allow-list; production stays refused (B8).",
        status=_NOT_RUN,
    ),
    AcceptanceRow(
        requirement_id="R02",
        source=_REFRESH,
        title="Duplicate request",
        observable_result=(
            "The same scoped key and payload return the same job even after completion; key "
            "reuse with another payload is rejected; overlapping scopes never share a writer."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        gap=_UNMAPPED_GAP,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="R03",
        source=_REFRESH,
        title="Skill or workbook capture",
        observable_result=(
            "The job records the pinned commit or atomic workbook copy, its checksum, scope "
            "and time; no arbitrary URL or ref and no skill-content execution."
        ),
        owner_role=_ADAPTERS,
        evidence_kind=EvidenceKind.existing_test,
        evidence_reference="tests/recsys/refresh/test_integration_acquisition_source.py",
        gap="Unit level against fakes; the integrated capture has not run.",
        status=_NOT_RUN,
    ),
    AcceptanceRow(
        requirement_id="R04",
        source=_REFRESH,
        title="Failed, stale or incomplete source",
        observable_result=(
            "The source status is explicit, no removal is inferred and the active publication "
            "stays readable under its freshness policy."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.existing_test,
        evidence_reference="tests/recsys/refresh/test_integration_acquisition_source.py",
        gap="Refusals and their safe reasons are unit-tested; readability needs mounted reads.",
        status=_BLOCKED,
        blocked_by=("B6",),
    ),
    AcceptanceRow(
        requirement_id="R05",
        source=_REFRESH,
        title="Worker crash, lease loss or uncertain write",
        observable_result=(
            "The candidate key is abandoned and a replacement uses a new key; nothing becomes "
            "reader-visible before writer exit and readback sealing; only the current control "
            "owner activates."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        gap=_FIXTURE_GAP,
        status=_BLOCKED,
        blocked_by=CANDIDATE,
    ),
    AcceptanceRow(
        requirement_id="R06",
        source=_REFRESH,
        title="Activation, cancel and recovery",
        observable_result=(
            "Only a sealed candidate changes the descriptor; a pre-activation cancel keeps the "
            "current version; an in-flight activation is resolved before the job ends."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.fault_run,
        status=_BLOCKED,
        blocked_by=CANDIDATE,
    ),
    AcceptanceRow(
        requirement_id="R07",
        source=_REFRESH,
        title="Status truthfulness",
        observable_result=(
            "Progress reflects completed, permitted work with separate fetched, validated and "
            "activated outcomes, current version, last successful fetch, freshness and retry."
        ),
        owner_role=_ADAPTERS,
        evidence_kind=EvidenceKind.existing_test,
        evidence_reference="tests/recsys/refresh/test_integration_status.py",
        gap="Reports the active publication; the integrated job outcomes have not run.",
        status=_NOT_RUN,
    ),
)

GATE_ROWS: tuple[AcceptanceRow, ...] = (
    AcceptanceRow(
        requirement_id="G01",
        source=_GATE,
        title="No access, fabricated-id or mixed-publication regression",
        observable_result=(
            "Zero observed regressions across the access, identity and publication cases."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.ci_job,
        status=_BLOCKED,
        blocked_by=(*CANDIDATE, "B6"),
    ),
    AcceptanceRow(
        requirement_id="G02",
        source=_GATE,
        title="Latency, freshness and resource budgets",
        observable_result="Every approved budget is met in the recorded run.",
        owner_role=OwnerRole.platform_owner,
        evidence_kind=EvidenceKind.load_run,
        status=_BLOCKED,
        blocked_by=("Q1",),
    ),
    AcceptanceRow(
        requirement_id="G03",
        source=_GATE,
        title="Workload and stress",
        observable_result=(
            "The deployed minimum workload plus approved growth, high-degree and selectivity "
            "stress, with reads during refresh across active, candidate and retained data."
        ),
        owner_role=OwnerRole.platform_owner,
        evidence_kind=EvidenceKind.load_run,
        status=_BLOCKED,
        blocked_by=("B6", "Q1"),
    ),
    AcceptanceRow(
        requirement_id="G04",
        source=_GATE,
        title="Rollout and rollback configuration",
        observable_result=(
            "Rollout and rollback settings stay compatible, and source, model and policy "
            "versions are recorded with each run."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.manual_rehearsal,
        status=_PLANNED,
    ),
    AcceptanceRow(
        requirement_id="G05",
        source=_GATE,
        title="Controlled enablement rehearsal",
        observable_result=(
            "Shadow or controlled-cohort enablement under shared budgets, with rollback and "
            "current-policy preservation."
        ),
        owner_role=_CONTRACTS,
        evidence_kind=EvidenceKind.manual_rehearsal,
        status=_BLOCKED,
        blocked_by=(*CANDIDATE, "Q1"),
    ),
    AcceptanceRow(
        requirement_id="G06",
        source=_GATE,
        mode=AcceptanceMode.recommendation,
        title="Quality per task and type",
        observable_result=(
            "Quality is reported per task and type with coverage, latency and cost; a small "
            "aggregate cannot hide a weak type."
        ),
        owner_role=OwnerRole.domain_reviewers,
        evidence_kind=EvidenceKind.evaluation_report,
        status=_BLOCKED,
        blocked_by=("Q2",),
    ),
    AcceptanceRow(
        requirement_id="G07",
        source=_GATE,
        mode=AcceptanceMode.recommendation,
        title="Held-out release claim",
        observable_result=(
            "Release claims use a separate frozen held-out split; a tuning change needs a new "
            "held-out set."
        ),
        owner_role=OwnerRole.domain_reviewers,
        evidence_kind=EvidenceKind.evaluation_report,
        status=_BLOCKED,
        blocked_by=("Q2",),
    ),
)

ACCEPTANCE_MATRIX = AcceptanceMatrix(
    rows=ARCHITECTURE_ROWS + REFRESH_ROWS + GATE_ROWS,
    blockers=BLOCKERS,
)
