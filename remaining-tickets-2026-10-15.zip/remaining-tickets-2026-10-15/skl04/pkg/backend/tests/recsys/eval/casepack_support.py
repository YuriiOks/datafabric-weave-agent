"""Synthetic builders for the case-pack tests. Every name, need and revision is made up."""

from __future__ import annotations

import hashlib
from collections.abc import Iterable, Sequence
from types import SimpleNamespace
from typing import Any
from uuid import UUID

from app.recsys.contract_fixtures import PPD_SCOPE
from app.recsys.contracts import ComponentType
from app.recsys.contracts.catalogue import QualityFlag
from app.recsys.contracts.sources import SourceAuthority, SourceCollection
from app.recsys.contracts.states import (
    ExecutionPermission,
    GraphStatus,
    RecommendationEligibility,
)
from app.recsys.eval.casepack.cases import (
    Adjudication,
    AdjudicationState,
    EvaluationCase,
    EvidenceRequirement,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.casepack.corpus import CorpusManifest, build_corpus_manifest
from app.recsys.eval.casepack.lineage import CasePackLineage, lineage_for
from app.recsys.eval.casepack.pack import CasePack
from app.recsys.eval.schema import GoldenInput

CATALOGUE_ID = "cat-" + "1" * 32
SKILLS_REVISION = "commit-feedc0de"
SKILLS_CONFIGURATION = "registered-skills-1"


def component_id(number: int) -> str:
    """:return: The canonical component id of synthetic component ``number``."""
    return str(UUID(int=number))


def occurrence(number: int) -> str:
    """:return: A synthetic record occurrence id."""
    return hashlib.sha256(f"occurrence-{number}".encode()).hexdigest()


def evidence(
    number: int,
    *,
    authority: SourceAuthority = SourceAuthority.skills_repo,
    revision: str = SKILLS_REVISION,
    configuration: str = SKILLS_CONFIGURATION,
    collection: SourceCollection = SourceCollection.skill_content,
) -> SimpleNamespace:
    """:return: Source evidence shaped like ``SourceEvidence``."""
    return SimpleNamespace(
        authority=authority,
        source_key=None,
        locator=SimpleNamespace(
            capture_digest="a" * 64,
            collection=collection,
            structural_locator=f"synthetic/{number}",
        ),
        source_configuration_version=configuration,
        resolved_revision=revision,
        record_occurrence_id=occurrence(number),
    )


def record(
    number: int,
    *,
    name: str = "Synthetic helper",
    description: str = "Drafts a synthetic summary for a made-up request.",
    flags: Iterable[QualityFlag] = (),
    component_type: ComponentType = ComponentType.skill,
    eligibility: RecommendationEligibility = RecommendationEligibility.recommendation_eligible,
    graph: GraphStatus = GraphStatus.graph_valid,
    catalogue_id: str = CATALOGUE_ID,
    evidence_items: Sequence[Any] | None = None,
) -> SimpleNamespace:
    """:return: A record shaped like ``CanonicalRecord``."""
    return SimpleNamespace(
        catalogue_id=catalogue_id,
        identity=SimpleNamespace(component_uuid=UUID(int=number), component_type=component_type),
        name=name,
        description=description,
        component_version=None,
        states=SimpleNamespace(
            graph_status=graph,
            recommendation_eligibility=eligibility,
            execution_permission=ExecutionPermission.execution_denied,
            reasons=[],
        ),
        quality_flags=list(flags),
        source_evidence=list(evidence_items) if evidence_items is not None else [evidence(number)],
    )


def snapshot(state: str = "validated", catalogue_id: str = CATALOGUE_ID) -> SimpleNamespace:
    """:return: A snapshot shaped like ``CatalogueSnapshot``."""
    return SimpleNamespace(
        catalogue_id=catalogue_id,
        state=state,
        manifest_digest="b" * 64,
        policy_version="policy-1",
        code_version="6",
        scope=PPD_SCOPE,
    )


def default_records() -> list[SimpleNamespace]:
    """:return: Five published Skills; number 3 has an empty description."""
    return [
        record(1),
        record(2),
        record(3, description="", flags=(QualityFlag.empty_description,)),
        record(4),
        record(5),
    ]


def corpus(
    records: Sequence[Any] | None = None,
    *,
    component_type: ComponentType = ComponentType.skill,
    access_policy_revision: str | None = "read-policy-1",
) -> CorpusManifest:
    """:return: A corpus manifest pinned to the synthetic snapshot."""
    items = list(records) if records is not None else default_records()
    lineage = lineage_for(snapshot(), items, access_policy_revision=access_policy_revision)
    return build_corpus_manifest(items, component_type=component_type, lineage=lineage)


def judged(
    labels: dict[str, RelevanceLabel],
    *,
    reviewer: str = "reviewer-a",
    reference: str = "review-log-1",
) -> Adjudication:
    """:return: A judged adjudication by a named reviewer."""
    return Adjudication(
        state=AdjudicationState.judged,
        reviewer=reviewer,
        decision_reference=reference,
        labels=labels,
    )


def case(
    number: int,
    *,
    lineage: CasePackLineage,
    scenario: Scenario = Scenario.positive,
    expected: ExpectedOutcome = ExpectedOutcome.ranked,
    group: str | None = None,
    adjudication: Adjudication | None = None,
    forbidden: Iterable[str] = (),
    required_evidence: Iterable[EvidenceRequirement] = (),
    prefix: str = "skl",
    component_type: ComponentType = ComponentType.skill,
    need: str | None = None,
    notes: str = "synthetic: made-up need",
) -> EvaluationCase:
    """:return: An evaluation case with a synthetic free-text need."""
    return EvaluationCase(
        case_id=f"{prefix}-{number:04d}",
        component_type=component_type,
        group_id=group or f"need-{number}",
        scenario=scenario,
        input=GoldenInput(
            card_id=None, text=need or f"Synthetic need number {number}", pair_card_id=None
        ),
        expected_outcome=expected,
        forbidden=tuple(forbidden),
        required_evidence=tuple(required_evidence),
        adjudication=adjudication or Adjudication(),
        lineage_digest=lineage.digest(),
        notes=notes,
    )


def pack(cases: Iterable[EvaluationCase], manifest: CorpusManifest) -> CasePack:
    """:return: A case pack pinned to ``manifest``."""
    return CasePack(
        pack_id="synthetic-pack",
        component_type=manifest.component_type,
        lineage=manifest.lineage,
        corpus_digest=manifest.digest(),
        cases=tuple(sorted(cases, key=lambda item: item.case_id)),
    )
