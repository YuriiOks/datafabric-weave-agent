"""The rules that coverage is measured against: the clauses of the edition in force."""

from __future__ import annotations

from datetime import date

from pydantic import BaseModel, ConfigDict
from sqlalchemy import Connection, select

from kp.domain import ClauseRef, Edition, SourceKind, select_edition_as_at
from kp.links.errors import NoEditionInForceError, UnknownEditionError
from kp.store.schema import clause as clause_table
from kp.store.schema import edition as edition_table
from kp.store.schema import story as story_table


class Rule(BaseModel):
    """One rule: a clause that no other clause nests under."""

    model_config = ConfigDict(frozen=True)

    reference: str
    title: str


class RuleCatalog:
    """Reads the rules from the ``clause`` and ``edition`` tables.

    A rule is a *leaf* clause: ``4.2`` only introduces ``4.2.1`` to ``4.2.4``, so the four
    are the rules. Pass ``leaf_only=False`` to treat every numbered clause as a rule.

    :param connection: A connection inside the caller's unit of work
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def edition_as_at(self, as_at: date) -> str:
        """Return the label of the edition in force on a date.

        :param as_at: The date; the single "as at" rule applies
        :return: The edition label
        :raises NoEditionInForceError: If no edition was in force on that date
        """
        rows = self._connection.execute(select(edition_table)).mappings()
        editions = [
            Edition(
                label=row["label"],
                effective_date=row["effective_date"],
                superseded_from=row["superseded_from"],
                withdrawn_from=row["withdrawn_from"],
                title=row["title"],
                source=SourceKind(row["source"]),
                item_id=row["item_id"],
                version=row["version"],
            )
            for row in rows
        ]
        selected = select_edition_as_at(editions, as_at)
        if selected is None:
            raise NoEditionInForceError(f"No edition was in force on {as_at.isoformat()}")
        return selected.label

    def rules(self, edition: str, *, leaf_only: bool = True) -> list[Rule]:
        """List the rules of one edition in clause-number order.

        :param edition: The edition label
        :param leaf_only: When True, clauses that contain sub-clauses are not rules
        :return: The rules, ordered by clause number
        :raises UnknownEditionError: If the edition is not loaded
        """
        known = self._connection.execute(
            select(edition_table.c.label).where(edition_table.c.label == edition)
        ).first()
        if known is None:
            raise UnknownEditionError(f"Edition {edition} is not loaded")
        rows = list(
            self._connection.execute(
                select(
                    clause_table.c.number, clause_table.c.title, clause_table.c.parent_number
                ).where(clause_table.c.edition == edition)
            ).mappings()
        )
        parents = {row["parent_number"] for row in rows if row["parent_number"] is not None}
        rules = [
            Rule(reference=ClauseRef(edition, row["number"]).format(), title=row["title"])
            for row in rows
            if not (leaf_only and row["number"] in parents)
        ]
        return sorted(rules, key=lambda rule: ClauseRef.parse(rule.reference))

    def exists(self, ref: ClauseRef) -> bool:
        """Tell whether a clause is loaded.

        :param ref: The clause reference
        :return: True when the clause table holds it
        """
        statement = select(clause_table.c.number).where(
            clause_table.c.edition == ref.edition, clause_table.c.number == ref.number
        )
        return self._connection.execute(statement).first() is not None


def loaded_story_keys(connection: Connection) -> list[str]:
    """List the keys of the loaded stories.

    :param connection: A connection inside the caller's unit of work
    :return: Distinct story keys in order
    """
    statement = select(story_table.c.story_key).distinct().order_by(story_table.c.story_key)
    return list(connection.execute(statement).scalars())
