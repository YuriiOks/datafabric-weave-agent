"""Pre-production refresh authority over an explicit operator allow-list.

This stands in for the operator authority service until that service exists. It is
refused outside pre-production when constructed, admits only the listed principals,
and re-checks the initiating principal, the configuration digest and the fence before
every activation, so removing an operator stops activations of jobs they started.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from datetime import UTC, datetime, timedelta

from app.recsys.contracts import Principal, PublicationScope, SourceEnvironment
from app.recsys.refresh.models import (
    ActivationAuthorization,
    CandidateHandle,
    CommandIdentity,
    LeaseToken,
    SourceConfigurationSnapshot,
)
from app.recsys.refresh.ports import AuthorizationRevoked, ConfigurationPort, StaleFence

POLICY_REVISION = "preproduction-allow-list-1"
ACTIVATION_AUTHORIZATION_TTL = timedelta(minutes=5)
COMMAND_ACTIONS = frozenset({"submit", "status", "cancel", "retry"})


def parse_operators(raw: str) -> frozenset[str]:
    """Split a comma-separated operator list, ignoring blanks.

    :param raw: The configured list.
    :return: The principal ids.
    """
    return frozenset(part.strip() for part in raw.split(",") if part.strip())


class PreproductionAuthorityPort:
    """``AuthorityPort`` for one pre-production scope."""

    def __init__(
        self,
        *,
        scope: PublicationScope,
        operators: Iterable[str],
        configurations: ConfigurationPort,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        """Create the port.

        :param scope: The only scope it authorizes; must be pre-production.
        :param operators: Principal ids allowed to run refresh commands.
        :param configurations: Used to re-check the configuration at activation.
        :param clock: Returns the current UTC time; injectable for tests.
        :raises ValueError: Outside pre-production or with no operators.
        """
        if scope.environment is not SourceEnvironment.ppd:
            raise ValueError("pre-production refresh authority is refused outside ppd")
        allowed = frozenset(operator.strip() for operator in operators if operator.strip())
        if not allowed:
            raise ValueError("pre-production refresh authority requires at least one operator")
        self._scope = scope
        self._operators = allowed
        self._configurations = configurations
        self._clock = clock or (lambda: datetime.now(UTC))

    async def authorize(
        self,
        identity: CommandIdentity,
        action: str,
        scope: PublicationScope,
    ) -> Principal:
        """Admit a listed operator to one refresh command in this scope.

        :param identity: The authenticated caller.
        :param action: One of submit, status, cancel or retry.
        :param scope: The scope the command targets.
        :return: The caller's principal.
        :raises AuthorizationRevoked: For any other action, scope or principal.
        """
        if action not in COMMAND_ACTIONS:
            raise AuthorizationRevoked("action")
        if scope != self._scope or identity.principal.policy_scope != self._scope:
            raise AuthorizationRevoked("scope")
        if identity.principal.principal_id not in self._operators:
            raise AuthorizationRevoked("principal_id")
        return identity.principal

    async def reauthorize_activation(
        self,
        initiating_principal_id: str,
        snapshot: SourceConfigurationSnapshot,
        lease: LeaseToken,
        candidate: CandidateHandle,
    ) -> ActivationAuthorization:
        """Re-check the job's operator, configuration and fence just before activation.

        :param initiating_principal_id: The principal that submitted the job.
        :param snapshot: The configuration snapshot after re-verification.
        :param lease: The attempt's lease.
        :param candidate: The sealed candidate.
        :return: A short-lived authorization bound to this fence and configuration.
        :raises AuthorizationRevoked: If the operator is no longer listed.
        :raises StaleFence: If the candidate belongs to another fence.
        :raises ConfigurationChanged: If the registrations changed since admission.
        """
        if initiating_principal_id not in self._operators:
            raise AuthorizationRevoked("principal_id")
        if any(scope != self._scope for scope in (snapshot.scope, lease.scope, candidate.scope)):
            raise AuthorizationRevoked("scope")
        if candidate.fence != lease.fence:
            raise StaleFence("fence")
        current = await self._configurations.verify_revision(snapshot)
        return ActivationAuthorization(
            initiating_principal_id=initiating_principal_id,
            job_id=lease.job_id,
            candidate_id=candidate.candidate_id,
            scope=self._scope,
            fence=lease.fence,
            config_digest=current.source_configuration_digest,
            policy_revision=POLICY_REVISION,
            expires_at=self._clock() + ACTIVATION_AUTHORIZATION_TTL,
            authorization_reference=f"preproduction-authority:{lease.job_id}:{lease.fence}",
        )
