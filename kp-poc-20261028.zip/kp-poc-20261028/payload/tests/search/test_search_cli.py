"""The ``kp search`` command and the page index fallback."""

from __future__ import annotations

import argparse
import io
from pathlib import Path
from typing import NoReturn

import pytest
from sqlalchemy import Engine

from kp.clock import SystemClock
from kp.domain import ApprovalState, SourceKind
from kp.errors import InvalidClauseRefError
from kp.search import (
    DocumentText,
    PageIndex,
    SearchService,
    fill_missing_pages,
    page_passages,
)
from kp.search.cli import add_parser, handle
from kp.store import Database, create_all, create_engine_for_url
from kp.testing.dataset import SyntheticDataset
from search.search_support import add_edition, add_run


def _parse(*argv: str) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))
    return parser.parse_args(["search", *argv])


@pytest.fixture
def database_url(
    tmp_path: Path, committed_dataset: SyntheticDataset, monkeypatch: pytest.MonkeyPatch
) -> str:
    """A file database seeded with the rulebook, selected through ``KP_DATABASE_URL``."""
    url = f"sqlite+pysqlite:///{tmp_path / 'kp.db'}"
    engine: Engine = create_engine_for_url(url)
    create_all(engine)
    database = Database(engine)
    with database.transaction() as connection:
        add_run(connection)
        add_edition(connection, committed_dataset, "2025.2", state=ApprovalState.SUPERSEDED)
        add_edition(connection, committed_dataset, "2026.1")
    SearchService(database, SystemClock()).rebuild_index()
    database.dispose()
    monkeypatch.setenv("KP_DATABASE_URL", url)
    return url


def test_us10_cli_arguments_are_question_as_at_and_domain() -> None:
    args = _parse(
        "which currency?", "--as-at", "2026-11-16", "--domain", "payments", "--limit", "3"
    )

    assert args.question == "which currency?"
    assert str(args.as_at) == "2026-11-16"
    assert args.domains == ["payments"]
    assert args.limit == 3
    assert args.handler is handle


def test_us10_cli_rejects_a_malformed_date() -> None:
    with pytest.raises(SystemExit):
        _parse("q", "--as-at", "16 Nov")


def test_us10_cli_prints_the_clause_with_page_and_position(
    database_url: str, committed_dataset: SyntheticDataset
) -> None:
    out = io.StringIO()

    status = handle(
        _parse("which currency may an inbound credit transfer use?", "--as-at", "2026-11-16"),
        out=out,
    )

    lines = out.getvalue().splitlines()
    assert status == 0
    assert lines[0] == "As at 2026-11-16 (edition in force: 2026.1)"
    assert lines[1].startswith("1. 2026.1 clause 4.2.1 Currency of inbound credit transfers")
    truth = next(
        c for c in committed_dataset.truth.edition("2026.1").clauses if c.number == "4.2.1"
    )
    assert f"page {truth.page}" in lines[1]
    assert f"characters {truth.md_char_start}-{truth.md_char_end}" in lines[1]
    assert "euro or in pounds sterling" in lines[2]


def test_us10_cli_accepts_a_bare_clause_number_as_the_question(database_url: str) -> None:
    out = io.StringIO()

    status = handle(_parse("4.2.1", "--as-at", "2026-11-16"), out=out)

    assert status == 0
    assert out.getvalue().splitlines()[1].startswith("1. 2026.1 clause 4.2.1 Currency of")


def test_us10_cli_limit_caps_the_number_of_hits(database_url: str) -> None:
    out = io.StringIO()

    handle(_parse("credit transfer", "--as-at", "2026-11-16", "--limit", "2"), out=out)

    numbered = [line for line in out.getvalue().splitlines() if line[:1].isdigit()]
    assert len(numbered) == 2


@pytest.mark.parametrize("limit", ["0", "-3", "many"])
def test_us10_cli_rejects_a_limit_below_one(limit: str) -> None:
    with pytest.raises(SystemExit):
        _parse("q", "--limit", limit)


def test_us10_cli_domain_with_matches_filters_to_it(database_url: str) -> None:
    out = io.StringIO()

    status = handle(_parse("currency", "--as-at", "2026-11-16", "--domain", "payments"), out=out)

    assert status == 0
    assert "No matching passages." not in out.getvalue()


def test_us11_cli_as_at_changes_the_edition_answered(database_url: str) -> None:
    out = io.StringIO()

    handle(_parse("clause 4.2.1", "--as-at", "2026-11-15"), out=out)

    assert "2025.2 clause 4.2.1" in out.getvalue()


def test_us10_cli_domain_without_matches_says_so(database_url: str) -> None:
    out = io.StringIO()

    status = handle(_parse("currency", "--as-at", "2026-11-16", "--domain", "cards"), out=out)

    assert status == 0
    assert "No matching passages." in out.getvalue()


def test_us10_cli_reports_an_uninitialised_database_without_a_traceback(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("KP_DATABASE_URL", f"sqlite+pysqlite:///{tmp_path / 'empty.db'}")

    status = handle(_parse("currency"), out=io.StringIO())

    assert status == 1
    assert "not initialised" in capsys.readouterr().err


def test_us10_cli_reports_a_domain_error_with_status_1(
    database_url: str, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    def refuse(self: SearchService, question: str, **_: object) -> NoReturn:
        raise InvalidClauseRefError("bad reference")

    monkeypatch.setattr(SearchService, "search", refuse)

    status = handle(_parse("q"), out=io.StringIO())

    assert status == 1
    assert "kp search: bad reference" in capsys.readouterr().err


def test_us10_cli_reports_an_invalid_setting_without_a_traceback(
    database_url: str, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("KP_SEARCH_RESULT_LIMIT", "0")

    status = handle(_parse("currency"), out=io.StringIO())

    assert status == 1
    assert "invalid value" in capsys.readouterr().err


def test_us10_page_index_from_the_pdf_finds_every_clause_page(
    committed_dataset: SyntheticDataset,
) -> None:
    truth = committed_dataset.truth.edition("2026.1")
    index = PageIndex.from_pdf(committed_dataset.path(truth.pdf_path))
    current = 3  # the table of contents ends before the first clause page

    for clause in truth.clauses:
        page = index.page_of(clause.text, from_page=current)
        assert page == clause.page
        current = page

    assert len(index) == 9


def test_us10_page_index_returns_none_for_text_it_does_not_hold() -> None:
    index = PageIndex(["first   page\ntext", "second page"])

    assert index.page_of("first page text") == 1
    assert index.page_of("second page") == 2
    assert index.page_of("second page", from_page=3) is None
    assert index.page_of("missing words") is None
    assert index.page_of("   ") is None


def test_us10_page_index_numbers_passages_when_the_markdown_has_no_page_markers() -> None:
    first = "Alpha bravo charlie delta echo foxtrot golf hotel india juliet kilo lima"
    second = "Mike november oscar papa quebec romeo sierra tango uniform victor whiskey xray"
    index = PageIndex([f"Heading\n{first}", f"{second} yankee zulu"])
    document = DocumentText(SourceKind.DOCUMENT_LIBRARY, "guide", "1", f"{first}\n\n{second}")

    unnumbered = page_passages(document)
    numbered = page_passages(document, index)

    assert [p.page for p in unnumbered] == [None]
    assert [p.page for p in numbered] == [1]
    assert numbered[0].text == unnumbered[0].text


def test_us10_fill_missing_pages_keeps_known_pages_and_skips_unfindable_text() -> None:
    index = PageIndex(["one two three four five", "six seven eight nine ten"])
    document = DocumentText(SourceKind.DOCUMENT_LIBRARY, "guide", "1", "six seven eight nine ten")
    [passage] = page_passages(document)
    known = passage.model_copy(update={"page": 2})
    lost = passage.model_copy(update={"text": "words nowhere in the file"})

    filled = fill_missing_pages([passage, known, lost], index)

    assert [p.page for p in filled] == [2, 2, None]
    assert filled[1] is known
