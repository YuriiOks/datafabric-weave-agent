"""Fixtures of the connectivity tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from connectivity.support import Stack, build_stack
from kp.clock import FixedClock
from kp.store import Database


@pytest.fixture
def stack(database: Database, fixed_clock: FixedClock, tmp_path: Path) -> Stack:
    """A wired local stack: fake gateway, stub extractor, local stores, in-memory database."""
    return build_stack(database, fixed_clock, tmp_path)
