---
pack_id: "bpc-sep26-v1"
local_id: "CORE-14"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Prepare operator runbook and demonstration evidence before qualification"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 2
scope: "foundation"
create_by_default: true
planned_start: "2026-09-25"
planned_due: "2026-09-25"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-05","CORE-06","CORE-13","SKL-04","MCP-04","AGT-04","CORE-15"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-14"
architecture_sections: ["operations","delivery","evidence"]
---

# Prepare operator runbook and demonstration evidence before qualification

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-14** is not a Jira key.
- Estimate: **2 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-25 → 2026-09-25 (D13–D13)**.
- Recommendation extension: **2026-09-28 → 2026-09-29 (D14–D15)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Prepare the operator and demonstration materials while qualification work runs, so the final release gate is not followed by unplanned documentation work.

## Scope and steps

1. Write the draft approved-source refresh procedure, credential owner/contact, job states, failure/retry behavior, freshness handling, source correction/quarantine and retained-version recovery using the implemented interfaces.
2. Create a demonstration script for the approved Skills/MCP/Agent scope with explicit denied, missing-input, unavailable and failed-refresh examples.
3. Assemble evidence links and placeholders labelled pending for runs not yet completed. Never pre-fill passed states or invent CI IDs.
4. Review the draft with Yurii and record the nominated operator; CORE-10 performs the final qualified walkthrough after CORE-09.

## Acceptance criteria

- [ ] The runbook refers to observed routes/commands and approved identities, with no embedded secrets.
- [ ] Every operational failure has a recovery action and accountable owner or an explicit blocker.
- [ ] Demo steps distinguish delivered graph/Hub capabilities from conditional component recommendations and future LLM work.
- [ ] Pending evidence remains pending until CORE-09 provides actual run references.

## Verification and evidence

Check every source/route/command against the current implementation and perform a preparation walkthrough. Attach the draft runbook, demo script and evidence index. Final release acceptance is outside this preparation ticket and cannot be inferred from its completion.

## Estimate and integration seam

Two engineering hours covers preparation against already implemented boundaries and peer correction; final walkthrough is the separate one-hour CORE-10 task. Exact bank paths and approved commands come from CORE-01. No backend code or new operational platform is created here.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-05](CORE-05.md) must finish its stated contract boundary before this task starts.
- [CORE-06](CORE-06.md) must finish its stated contract boundary before this task starts.
- [CORE-13](CORE-13.md) must finish its stated contract boundary before this task starts.
- [SKL-04](SKL-04.md) must finish its stated contract boundary before this task starts.
- [MCP-04](MCP-04.md) must finish its stated contract boundary before this task starts.
- [AGT-04](AGT-04.md) must finish its stated contract boundary before this task starts.
- [CORE-15](CORE-15.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `operations`, `delivery`, `evidence`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
