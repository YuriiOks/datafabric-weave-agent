"""Assembling the harness from settings.

Local mode wires the in-process fake gateway and the stub extractor behind the same client
classes the real route uses, so switching to the real route is configuration, not code.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import httpx
from pydantic import SecretStr

from kp.clock import Clock, SystemClock
from kp.config import Mode, Settings
from kp.connectivity.adapters import (
    ConfluenceAdapter,
    GatewayToolAdapter,
    GitHubAdapter,
    JiraAdapter,
)
from kp.connectivity.discovery import SignatureStore
from kp.connectivity.evidence import Evidence, collect_evidence
from kp.connectivity.extraction import ExtractionClient
from kp.connectivity.fake_gateway import (
    DEFAULT_NAMESPACES,
    FAKE_BASE_URL,
    FAKE_CLIENT_ID,
    FAKE_CLIENT_SECRET,
    FAKE_EXTRACTION_URL,
    FAKE_TOKEN_URL,
    LOCAL_IDENTITY_HEADER,
    LOCAL_SOURCE_CREDENTIAL,
    LOCAL_SOURCE_HEADER,
    FakeGateway,
)
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.models import Route, SampleSet
from kp.connectivity.ports import ObjectStore
from kp.connectivity.records import RunCallRecorder
from kp.connectivity.runner import ConnectivityRunner
from kp.connectivity.samples import default_sample_items_path, load_sample_items
from kp.connectivity.storage import BucketObjectStore, LocalObjectStore
from kp.connectivity.stub_extractor import StubExtractionService
from kp.connectivity.tokens import ClientCredentialsTokenProvider, FixedTokenProvider
from kp.domain import SourceKind
from kp.errors import ConfigurationError
from kp.store import Database

_HTTP_TIMEOUT_SECONDS = 60.0
_PROBE_CREDENTIAL = "invalid-credential-for-error-probe"


@dataclass
class Harness:
    """The assembled connectivity harness.

    :ivar job: The job the CLI drives.
    :ivar fake: The fake gateway when running locally, so callers can flip its switches.
    :ivar stub: The stub extraction service when running locally.
    """

    settings: Settings
    database: Database
    job: ConnectivityRunner
    samples: SampleSet
    namespaces: dict[SourceKind, str]
    ledger_dir: Path
    signatures: SignatureStore
    raw_store: ObjectStore
    markdown_store: ObjectStore
    fake: FakeGateway | None
    stub: StubExtractionService | None
    _clients: tuple[httpx.Client, ...]

    def evidence(self) -> Evidence:
        """Gather the evidence of every run so far.

        :return: The evidence for scoring
        """
        return collect_evidence(
            database=self.database,
            mode=self.settings.mode,
            namespaces=self.namespaces,
            sample_total=len(self.samples.items),
            ledger_dir=self.ledger_dir,
            signatures=self.signatures,
            raw_store=self.raw_store,
            markdown_store=self.markdown_store,
        )

    def close(self) -> None:
        """Release HTTP clients and database connections."""
        for client in self._clients:
            client.close()
        self.database.dispose()


def build_harness(
    settings: Settings,
    *,
    clock: Clock | None = None,
    sleep: Callable[[float], None] = time.sleep,
) -> Harness:
    """Assemble the harness for the mode in ``settings``.

    :param settings: Platform settings
    :param clock: Time source; the system clock when omitted
    :param sleep: Used to wait out rate limits
    :return: The harness; the caller closes it
    :raises kp.errors.ConfigurationError: If real mode lacks a value the route needs
    :raises kp.connectivity.errors.SampleItemsError: If the sample items file is not valid
    """
    now = clock if clock is not None else SystemClock()
    root = settings.data_dir / "connectivity"
    samples = load_sample_items(settings.sample_items_file or default_sample_items_path())
    database = Database.from_settings(settings)
    database.ensure_schema(settings)
    namespaces = namespaces_for(settings)
    routes = {kind: Route(namespace=name, source=kind) for kind, name in namespaces.items()}
    raw_store, markdown_store = object_stores(settings, root)

    fake: FakeGateway | None = None
    stub: StubExtractionService | None = None
    if settings.mode is Mode.LOCAL:
        identity_header = settings.gateway_token_header or LOCAL_IDENTITY_HEADER
        source_header = settings.source_token_header or LOCAL_SOURCE_HEADER
        fake = FakeGateway(now, identity_header=identity_header, source_header=source_header)
        stub = StubExtractionService(raw_store, markdown_store, now)
        http = httpx.Client(transport=fake.transport())
        extraction_http = httpx.Client(transport=stub.transport())
        base_url, token_url = FAKE_BASE_URL, FAKE_TOKEN_URL
        client_id, client_secret = FAKE_CLIENT_ID, SecretStr(FAKE_CLIENT_SECRET)
        credentials = dict.fromkeys(routes, SecretStr(LOCAL_SOURCE_CREDENTIAL))
        extraction_endpoint = FAKE_EXTRACTION_URL
    else:
        identity_header = required_setting("KP_GATEWAY_TOKEN_HEADER", settings.gateway_token_header)
        source_header = required_setting("KP_SOURCE_TOKEN_HEADER", settings.source_token_header)
        http = httpx.Client(timeout=_HTTP_TIMEOUT_SECONDS)
        extraction_http = http
        base_url = required_setting("KP_GATEWAY_BASE_URL", settings.gateway_base_url)
        token_url = required_setting("KP_GATEWAY_TOKEN_URL", settings.gateway_token_url)
        client_id = required_setting("KP_GATEWAY_CLIENT_ID", settings.gateway_client_id)
        client_secret = required_secret("KP_GATEWAY_CLIENT_SECRET", settings.gateway_client_secret)
        credentials = {
            SourceKind.CONFLUENCE: required_secret(
                "KP_SOURCE_TOKEN_CONFLUENCE", settings.source_token_confluence
            ),
            SourceKind.JIRA: required_secret("KP_SOURCE_TOKEN_JIRA", settings.source_token_jira),
            SourceKind.GITHUB: required_secret(
                "KP_SOURCE_TOKEN_GITHUB", settings.source_token_github
            ),
        }
        extraction_endpoint = required_setting(
            "KP_EXTRACTION_BASE_URL", settings.extraction_base_url
        )

    tokens = ClientCredentialsTokenProvider(
        http=http,
        token_url=token_url,
        client_id=client_id,
        client_secret=client_secret,
        clock=now,
        refresh_fraction=settings.token_refresh_fraction,
    )
    recorder = RunCallRecorder(database)

    def gateway(provider: ClientCredentialsTokenProvider | FixedTokenProvider) -> GatewayClient:
        return GatewayClient(
            http=http,
            base_url=base_url,
            tokens=provider,
            identity_header=identity_header,
            source_header=source_header,
            source_credentials=credentials,
            clock=now,
            sink=recorder,
            use_case_id=settings.use_case_id,
            sleep=sleep,
        )

    client = gateway(tokens)
    adapters: dict[SourceKind, GatewayToolAdapter] = {
        SourceKind.CONFLUENCE: ConfluenceAdapter(
            client, routes[SourceKind.CONFLUENCE], samples.for_source(SourceKind.CONFLUENCE)
        ),
        SourceKind.JIRA: JiraAdapter(
            client, routes[SourceKind.JIRA], samples.for_source(SourceKind.JIRA)
        ),
        SourceKind.GITHUB: GitHubAdapter(
            client, routes[SourceKind.GITHUB], samples.for_source(SourceKind.GITHUB)
        ),
    }
    extraction_tokens, extraction_header = extraction_auth(settings, now)
    extractor = ExtractionClient(
        http=extraction_http,
        endpoint=extraction_endpoint,
        tokens=extraction_tokens,
        identity_header=extraction_header,
    )
    signatures = SignatureStore(root / "signatures")
    ledger_dir = root / "runs"
    job = ConnectivityRunner(
        database=database,
        recorder=recorder,
        client=client,
        routes=routes,
        fetchers=adapters,
        samples=samples,
        raw_store=raw_store,
        extractor=extractor,
        signatures=signatures,
        ledger_dir=ledger_dir,
        clock=now,
        probe_client=gateway(FixedTokenProvider(SecretStr(_PROBE_CREDENTIAL), now)),
    )
    clients = (http,) if extraction_http is http else (http, extraction_http)
    return Harness(
        settings=settings,
        database=database,
        job=job,
        samples=samples,
        namespaces=namespaces,
        ledger_dir=ledger_dir,
        signatures=signatures,
        raw_store=raw_store,
        markdown_store=markdown_store,
        fake=fake,
        stub=stub,
        _clients=clients,
    )


def object_stores(settings: Settings, root: Path) -> tuple[ObjectStore, ObjectStore]:
    """The raw and Markdown stores of the connectivity job: buckets in real mode, folders otherwise.

    :param settings: Platform settings
    :param root: The job's folder below the data directory (used in local mode)
    :return: The raw store and the Markdown store
    :raises kp.errors.ConfigurationError: If real mode lacks a bucket name
    """
    if settings.mode is Mode.REAL:
        return (
            BucketObjectStore(required_setting("KP_RAW_BUCKET", settings.raw_bucket)),
            BucketObjectStore(required_setting("KP_MARKDOWN_BUCKET", settings.markdown_bucket)),
        )
    return LocalObjectStore(root / "raw"), LocalObjectStore(root / "markdown")


def load_evidence(settings: Settings) -> Evidence:
    """Gather the evidence the connectivity runs left, without being able to run anything.

    Only reads: the database, the run files, the kept signatures and the stored objects. It needs
    no gateway address, no credential and no source token, and it creates no table, so a page
    that shows the report cannot be used to reach the gateway or to change the database.

    :param settings: Platform settings
    :return: The evidence for scoring
    :raises kp.errors.ConfigurationError: If real mode lacks a namespace or a bucket name
    """
    root = settings.data_dir / "connectivity"
    samples = load_sample_items(settings.sample_items_file or default_sample_items_path())
    raw_store, markdown_store = object_stores(settings, root)
    database = Database.from_settings(settings)
    try:
        return collect_evidence(
            database=database,
            mode=settings.mode,
            namespaces=namespaces_for(settings),
            sample_total=len(samples.items),
            ledger_dir=root / "runs",
            signatures=SignatureStore(root / "signatures"),
            raw_store=raw_store,
            markdown_store=markdown_store,
        )
    finally:
        database.dispose()


def extraction_auth(
    settings: Settings, clock: Clock
) -> tuple[FixedTokenProvider | None, str | None]:
    """The extraction service's own credential; the gateway token is never sent to it."""
    if settings.extraction_token is None or settings.extraction_auth_header is None:
        return None, None
    return FixedTokenProvider(settings.extraction_token, clock), settings.extraction_auth_header


def namespaces_for(settings: Settings) -> dict[SourceKind, str]:
    """Resolve the tool namespace of each source server.

    :param settings: Platform settings
    :return: One namespace per source; the stand-in names in local mode
    :raises kp.errors.ConfigurationError: If real mode lacks a namespace
    """
    configured = {
        SourceKind.CONFLUENCE: settings.tool_namespace_confluence,
        SourceKind.JIRA: settings.tool_namespace_jira,
        SourceKind.GITHUB: settings.tool_namespace_github,
    }
    names: dict[SourceKind, str] = {}
    for kind, value in configured.items():
        usable = value is not None and value.strip() and not value.strip().startswith("<")
        if usable and value is not None:
            names[kind] = value.strip()
        elif settings.mode is Mode.REAL:
            raise ConfigurationError(f"KP_TOOL_NAMESPACE_{kind.name} is required in real mode")
        else:
            names[kind] = DEFAULT_NAMESPACES[kind.value]
    return names


def required_setting(name: str, value: str | None) -> str:
    """Return a setting that the route cannot do without.

    :param name: The setting's environment variable, for the message
    :param value: Its value
    :return: The value
    :raises kp.errors.ConfigurationError: If it is absent or blank
    """
    if value is None or not value.strip():
        raise ConfigurationError(f"{name} is required for the connectivity job")
    return value


def required_secret(name: str, value: SecretStr | None) -> SecretStr:
    """Return a secret that the route cannot do without.

    :param name: The setting's environment variable, for the message
    :param value: Its value
    :return: The value
    :raises kp.errors.ConfigurationError: If it is absent or blank
    """
    if value is None or not value.get_secret_value().strip():
        raise ConfigurationError(f"{name} is required for the connectivity job")
    return value
