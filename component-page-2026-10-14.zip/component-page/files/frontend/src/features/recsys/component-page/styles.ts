import type { CSSProperties } from 'react'

/** Shared inline styles of the component page, in the Playbook Library's tokens. */

export const STATE_COLOUR = {
  none: 'var(--color-border, #d9d9d9)',
  look: 'var(--color-warning, #faad14)',
  clear: 'var(--color-success, #52c41a)',
} as const

export type TileState = keyof typeof STATE_COLOUR

export const sectionCardStyle: CSSProperties = {
  background: 'var(--color-surface)',
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-lg)',
  overflow: 'hidden',
  minWidth: 0,
}

export const sectionHeaderStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 'var(--space-3)',
  padding: 'var(--space-3) var(--space-4)',
  borderBottom: '1px solid var(--color-border-light)',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.015))',
}

export const sectionLabelStyle: CSSProperties = {
  margin: 0,
  fontSize: '0.6875rem',
  fontWeight: 600,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--color-text-secondary)',
}

export const rowStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'minmax(96px, 30%) minmax(0, 1fr)',
  gap: 'var(--space-3)',
  padding: 'var(--space-3) var(--space-4)',
  borderBottom: '1px solid var(--color-border-light)',
  fontSize: 'var(--text-sm)',
  lineHeight: 1.5,
}

export const stackedRowStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-1)',
  padding: 'var(--space-3) var(--space-4)',
  borderBottom: '1px solid var(--color-border-light)',
  fontSize: 'var(--text-sm)',
  lineHeight: 1.5,
}

export const rowLabelStyle: CSSProperties = {
  color: 'var(--color-text-secondary)',
}

export const rowValueStyle: CSSProperties = {
  color: 'var(--color-text-primary)',
  minWidth: 0,
  overflowWrap: 'anywhere',
}

export const monoStyle: CSSProperties = {
  fontFamily: 'var(--font-mono)',
  fontSize: '0.8125rem',
}

export const mutedStyle: CSSProperties = {
  color: 'var(--color-text-tertiary)',
}

export const chipStyle: CSSProperties = {
  display: 'inline-block',
  fontFamily: 'var(--font-mono)',
  fontSize: '0.75rem',
  padding: '2px 10px',
  borderRadius: 'var(--radius-full)',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.04))',
  border: '1px solid var(--color-border-light)',
  color: 'var(--color-text-primary)',
  marginRight: 'var(--space-2)',
  marginBottom: 'var(--space-1)',
}

export const flagChipStyle: CSSProperties = {
  ...chipStyle,
  fontFamily: 'inherit',
  background: 'rgba(250, 173, 20, 0.12)',
  border: '1px solid rgba(250, 173, 20, 0.45)',
}

export const prodPillStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 4,
  fontSize: '0.6875rem',
  fontWeight: 600,
  padding: '1px 8px',
  borderRadius: 'var(--radius-full)',
  color: 'var(--color-success-text, #237804)',
  background: 'rgba(82, 196, 26, 0.12)',
  border: '1px solid rgba(82, 196, 26, 0.45)',
  whiteSpace: 'nowrap',
}

export const linkStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 4,
  fontSize: 'var(--text-sm)',
  color: 'var(--color-link, #1677ff)',
  textDecoration: 'none',
}

export const emptyBoxStyle: CSSProperties = {
  border: '1px dashed var(--color-border)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-4)',
  textAlign: 'center',
  fontSize: 'var(--text-sm)',
  color: 'var(--color-text-tertiary)',
}
