import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render, screen, within } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { ComponentDetailLayout } from './ComponentDetailLayout'
import { EMPTY_GROUP, EMPTY_SOURCE } from './model'
import type { ComponentPageModel } from './model'
import { sampleFor, withDemoSample } from './sampleDefinitions'

const originalMatchMedia = window.matchMedia

/** Pins the layout breakpoint, whatever the test setup polyfills for matchMedia. */
function setWide(wide: boolean) {
  Object.defineProperty(window, 'matchMedia', {
    configurable: true,
    writable: true,
    value: vi.fn((query: string) => ({
      matches: wide,
      media: query,
      onchange: null,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })),
  })
}

afterEach(() => {
  cleanup()
  Object.defineProperty(window, 'matchMedia', { configurable: true, writable: true, value: originalMatchMedia })
})

function makeModel(overrides: Partial<ComponentPageModel> = {}): ComponentPageModel {
  return {
    id: 'skill:alpha-ticket-helper',
    type: 'skill',
    name: 'Alpha Ticket Helper',
    description: 'Classifies a ticket into a queue and drafts a first reply.',
    version: '1.2.0',
    nativeBinding: null,
    tenants: ['tenant-atlas'],
    eligible: true,
    qualityFlags: [],
    triggers: ['Use when a team needs to triage inbound support tickets'],
    tools: ['Read', 'Write'],
    tags: ['ticket_automation'],
    definition: null,
    source: EMPTY_SOURCE,
    relations: {
      usedBy: { items: [{ id: 'agent:epsilon-triage-agent', name: 'Epsilon Triage Agent', type: 'agent', summary: null }], withheld: 0 },
      uses: EMPTY_GROUP,
      dependsOn: { items: [], withheld: 1 },
    },
    ...overrides,
  }
}

function renderPage(model: ComponentPageModel, props: { recommendTo?: string } = {}) {
  return render(
    <MemoryRouter>
      <ComponentDetailLayout model={model} recommendTo={props.recommendTo} />
    </MemoryRouter>,
  )
}

describe('ComponentDetailLayout on a wide screen', () => {
  it('shows the hero, the summary tiles and both columns', () => {
    setWide(true)
    const { container } = renderPage(makeModel(), { recommendTo: '/recommend' })
    expect(container.querySelector('[data-layout="wide"]')).not.toBeNull()
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent('Alpha Ticket Helper')
    expect(screen.getByRole('link', { name: /Back to registry/ })).toHaveAttribute('href', '/registry')
    const summary = screen.getByRole('region', { name: 'Summary' })
    expect(within(summary).getByText('Quality flags')).toBeInTheDocument()
    expect(within(summary).getByText('No flags raised')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Recommend for a need like this' })).toHaveAttribute('href', '/recommend')
  })

  it('falls back to the description when the full definition is not available', () => {
    setWide(true)
    renderPage(makeModel())
    expect(screen.getByText('Full definition not available yet.')).toBeInTheDocument()
    expect(screen.getAllByText('Classifies a ticket into a queue and drafts a first reply.').length).toBeGreaterThan(0)
  })

  it('renders the full definition when the model carries one', () => {
    setWide(true)
    renderPage(withDemoSample(makeModel()))
    expect(screen.getByRole('heading', { name: 'When to use' })).toBeInTheDocument()
    const definition = screen.getByRole('region', { name: 'Definition' })
    expect(within(definition).getByText('skills/alpha-ticket-helper/SKILL.md')).toBeInTheDocument()
  })

  it('lists related components, says when a group is empty and warns about withheld declarations', () => {
    setWide(true)
    renderPage(makeModel())
    const related = screen.getByRole('region', { name: 'Related components' })
    expect(within(related).getByRole('link', { name: /Epsilon Triage Agent/ })).toHaveAttribute(
      'href',
      '/registry/' + encodeURIComponent('agent:epsilon-triage-agent'),
    )
    expect(within(related).getAllByText('None recorded')).toHaveLength(2)
    expect(within(related).getByText('1 unresolved declaration withheld')).toBeInTheDocument()
  })

  it('never offers to recommend a component that is not from Prod or not eligible', () => {
    setWide(true)
    const { unmount } = renderPage(makeModel({ source: { ...EMPTY_SOURCE, environment: 'UAT' } }), {
      recommendTo: '/recommend',
    })
    expect(screen.queryByText('Recommend for a need like this')).toBeNull()
    expect(screen.getByText(/not Prod\. It is not recommended/)).toBeInTheDocument()
    unmount()
    renderPage(makeModel({ eligible: false }), { recommendTo: '/recommend' })
    expect(screen.queryByText('Recommend for a need like this')).toBeNull()
    expect(screen.getByText('Not eligible')).toBeInTheDocument()
  })
})

describe('ComponentDetailLayout on a phone', () => {
  it('uses one column with the grouped details and no summary tiles', () => {
    setWide(false)
    const { container } = renderPage(makeModel(), { recommendTo: '/recommend' })
    expect(container.querySelector('[data-layout="narrow"]')).not.toBeNull()
    expect(screen.queryByRole('region', { name: 'Summary' })).toBeNull()
    expect(screen.getByRole('heading', { name: 'What it does' })).toBeInTheDocument()
    expect(screen.getByRole('heading', { name: 'How it runs' })).toBeInTheDocument()
    expect(screen.getByText('skill:alpha-ticket-helper', { selector: 'dd span' })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Recommend for a need like this' })).toBeInTheDocument()
  })
})

describe('sampleFor', () => {
  it('matches demo fixtures on the last segment of their id', () => {
    expect(sampleFor('agent:tenant-atlas/epsilon-triage-agent')?.source.environment).toBe('Prod')
    expect(sampleFor('mcp:delta-wiki')?.definition.path).toBe('mcp/delta-wiki/MCP.md')
    expect(sampleFor('skill:unknown')).toBeNull()
  })
})
