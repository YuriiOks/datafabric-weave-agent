# Routing and dispatch (shared by /km-code-review and /km-review-pr)

## Which layer does a changed path belong to
- Conventions folder, by clone: kb/conventions/ for BASE_REPO, kb/conventions/capture/ for
  CAPTURE_REPO (km-code-review: from the plan's Conventions line). Below, kb/conventions/
  means that folder. Say in the report which map was used.
- Read kb/conventions/layers.md. It maps path prefixes to the layers backend, frontend, data,
  infra, ai. Match each changed path to the longest prefix. A path can match none.
- layers.md missing or unreadable: do not guess a map. Treat every path as unmapped, route
  by the content rules below only, and say in the report that the layer map was missing and
  /km-conventions should run.
- Unmapped paths (docs, lock files, generated files): list them in the report. They go to
  the reviewers only when the content rules pick them.
- Convention file of a layer: kb/conventions/<layer>.md. Pass the ones for the touched
  layers. A touched layer whose file is missing: note it, do not stop; the reviewers say what
  that leaves unchecked.

## Which reviewers run (2 to 4)
Read the diff once, with grep, to decide. Use the layers of the changed paths and the diff
text; never the author's description alone.

- km-rev-correctness: always.
- km-rev-quality: always.
- km-rev-security: a path is in backend, ai or infra; or the diff touches one of routes,
  handlers, tools, queries, auth, sessions, permissions, secrets, configuration, containers,
  pipelines, prompts, model calls.
- km-rev-contracts: two or more layers are touched; or a path is in data; or the diff changes
  one of an API path, a response shape, a schema, a migration, a shared type, a message
  format, an API client.

A diff of docs or tests only: correctness and quality still run, with the same task text.
Write the chosen reviewers and the reason for each skipped one into the report.

## Dispatch
- At most 3 subagents at once, in any mix of reviewers and skeptics. Four reviewers: run
  three, then the fourth when one returns.
- A subagent sees none of this conversation. The task text carries: goal in one sentence;
  inputs as exact paths (diff file, work tree, convention files of the touched layers, plan
  file if there is one, layers.md); the list of changed paths; output, the agent's own reply
  format; skip, editing anything and running anything; limit, as the agent file says. Do
  not point a subagent at a file of instructions.
- Reviewers cannot write. Save each reply at once to work/reviews/<name>-<tag>-<agent>.txt
  (tag r1, r2, or p1, p2 for a pull request round). On a restart skip a reviewer whose file
  exists.
- A diff longer than 2500 lines: give each reviewer only the changed paths of the layers it
  cares about, as a list of files with their hunks (the diff file stays whole; say which
  files to read), and state in the report that the split was made.

## Merge, then refute
1. Merge the findings of all reviewers into one numbered list F1, F2. Findings on the same
   place and problem become one, keeping the highest severity and naming both dimensions.
   Drop any finding that is a linter's job.
2. Send the list to km-skeptic: batches of at most 12, one batch per call, the work tree, the
   diff path and the numbered findings pasted in the task. Up to 3 calls at once. Save
   each table to work/reviews/<name>-<tag>-skeptic-<N>.txt.
3. Keep proven. Keep unclear in a separate list headed "Open questions", with what is
   missing. An unclear finding keeps its original severity; if any blocker is unclear, the
   verdict reads "owner decides: unresolved blocker" and the finding also sits in the table
   with Skeptic = unclear and the one check that would settle it. Drop refuted from the
   report body but count them and list their numbers.
4. Spot-check before keeping anything: read 10 lines around the cited place of every proven
   finding that is a blocker. If the lines do not show it, move the finding to unclear.

## Severity words (the same everywhere)
blocker: wrong or unsafe on a normal path, or breaks a consumer or data. should-fix: real
problem on a less common path or a real maintenance cost. question: cannot be decided without
the author. nit: small, worth a word, never a linter's job.
