"""Connectivity: the exit-criteria report of the last connectivity run, with its verdict."""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.exc import SQLAlchemyError

from kp.config import Mode, Settings
from kp.connectivity import ExitReport, RunResult, build_report, load_evidence
from kp.domain import ExitResult
from kp.errors import KpError
from kp.web.errors import Problem, ProblemKind, problem_from
from kp.web.identity import Viewer
from kp.web.state import WebState

# Where the job keeps its run files, below the data folder (see kp.connectivity.wiring).
_JOB_FOLDER = "connectivity"
_RUNS_FOLDER = "runs"


@dataclass(frozen=True, slots=True)
class ConnectivityView:
    """The connectivity page.

    :ivar report: The scored report; ``None`` when no run has left evidence yet.
    :ivar last_run: The newest run recorded.
    """

    report: ExitReport | None = None
    last_run: RunResult | None = None
    problem: Problem | None = None

    def _count(self, result: ExitResult) -> int:
        return 0 if self.report is None else self.report.count(result)

    @property
    def passed(self) -> int:
        """How many criteria passed."""
        return self._count(ExitResult.PASS)

    @property
    def failed(self) -> int:
        """How many criteria failed."""
        return self._count(ExitResult.FAIL)

    @property
    def inconclusive(self) -> int:
        """How many criteria have no evidence yet."""
        return self._count(ExitResult.INCONCLUSIVE)


def read_connectivity(state: WebState, viewer: Viewer) -> ConnectivityView:
    """Score the evidence the last connectivity run left.

    The report is built from what the run left behind (rows, stored objects, kept signatures),
    exactly as ``kp connectivity report`` does. A hop without evidence reads "no evidence", never
    "passed".

    :param state: The shared state
    :param viewer: Who is asking; a viewer with no access is refused
    :return: The view
    """
    try:
        state.require_access(viewer)
        settings = state.connectivity or state.application.settings
        if not _has_evidence(settings):
            return ConnectivityView()
        return _score(settings)
    except KpError as exc:
        return ConnectivityView(problem=problem_from(exc))
    except SQLAlchemyError:
        return ConnectivityView(
            problem=Problem(ProblemKind.UNAVAILABLE, "The connectivity evidence cannot be read.")
        )


def _has_evidence(settings: Settings) -> bool:
    """True when a run can have left evidence, so viewing the page never creates any.

    The real route keeps its objects in buckets, so there is always something to read; the local
    one keeps run files in a folder that exists only once the job has run.
    """
    if settings.mode is Mode.REAL:
        return True
    return (settings.data_dir / _JOB_FOLDER / _RUNS_FOLDER).is_dir()


def _score(settings: Settings) -> ConnectivityView:
    # Read-only: the page never builds the harness, so it holds no gateway credential and cannot
    # create tables or call the gateway.
    evidence = load_evidence(settings)
    # The runs come oldest first, so the last one is the newest.
    last = evidence.runs[-1] if evidence.runs else None
    return ConnectivityView(report=build_report(evidence), last_run=last)
