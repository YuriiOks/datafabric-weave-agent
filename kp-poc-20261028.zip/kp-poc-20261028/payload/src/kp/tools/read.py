"""Assembly of the read tool set."""

from __future__ import annotations

from kp.clock import Clock
from kp.tools.access import DomainDirectory
from kp.tools.audit import AuditSink
from kp.tools.coverage import coverage_tool
from kp.tools.links import links_tool
from kp.tools.ports import ReadPorts
from kp.tools.registry import ToolObserver, ToolRegistry
from kp.tools.rules import rule_as_at_tool
from kp.tools.search import search_tool
from kp.tools.templates import template_tool


def build_read_registry(
    ports: ReadPorts,
    directory: DomainDirectory,
    audit: AuditSink,
    *,
    clock: Clock | None = None,
    observer: ToolObserver | None = None,
) -> ToolRegistry:
    """Build a registry holding the five read tools.

    :param ports: Search, links, rules, templates and coverage
    :param directory: Identity to allowed domains
    :param audit: Where call records go
    :param clock: Time source; defaults to the system clock
    :param observer: Told about every successful call, e.g. to remember what a session saw
    :return: The registry; it contains read tools only
    """
    registry = ToolRegistry(directory, audit, clock=clock, observer=observer)
    registry.register(search_tool(ports.search, ports.links))
    registry.register(links_tool(ports.links))
    registry.register(template_tool(ports.templates))
    registry.register(rule_as_at_tool(ports.rules))
    registry.register(coverage_tool(ports.coverage))
    return registry
