"""Environment-driven settings.

Every environment-specific value is a setting read from a ``KP_``-prefixed environment
variable. Examples in docs use ``<placeholder>`` values only. Secrets are ``SecretStr`` and are
never logged. Write targets (spec repository, spec path, allowed Jira fields) are server-side
settings: an agent request can never change them.

Switching from stand-in data to real data is a configuration change (``KP_MODE=real`` plus the
gateway and storage settings), not a code change.
"""

from __future__ import annotations

import re
from enum import StrEnum
from pathlib import Path, PurePosixPath
from typing import Annotated, Self

from pydantic import BaseModel, ConfigDict, Field, SecretStr, ValidationError, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from kp.errors import ConfigurationError


class Mode(StrEnum):
    """Which route the process talks to."""

    LOCAL = "local"
    REAL = "real"


class Thresholds(BaseModel):
    """Provisional quality thresholds. Tuned against reviewed results, so they are settings.

    Override one with e.g. ``KP_THRESHOLDS__GUESSED_SHARE_MAX=0.4``.
    """

    model_config = ConfigDict(frozen=True)

    structure_proceed: Annotated[float, Field(ge=0, le=1)] = 0.85
    structure_review: Annotated[float, Field(ge=0, le=1)] = 0.60
    register_header_min_confidence: Annotated[float, Field(ge=0, le=1)] = 0.70
    link_proposed_min: Annotated[float, Field(ge=0, le=1)] = 0.75
    link_review_min: Annotated[float, Field(ge=0, le=1)] = 0.55
    guessed_share_max: Annotated[float, Field(ge=0, le=1)] = 0.50
    item_count_change_max: Annotated[float, Field(ge=0)] = 0.25
    items_without_links_max: Annotated[float, Field(ge=0, le=1)] = 0.05
    clauses_without_field_link_max: Annotated[float, Field(ge=0, le=1)] = 0.30
    average_guessed_score_min: Annotated[float, Field(ge=0, le=1)] = 0.80
    citation_rate_target: Annotated[float, Field(ge=0, le=1)] = 0.95
    stale_after_hours: Annotated[float, Field(gt=0)] = 6.0
    fetch_failures_before_alert: Annotated[int, Field(ge=1)] = 3
    previous_version_retention_days: Annotated[int, Field(ge=0)] = 30

    @model_validator(mode="after")
    def _ordered(self) -> Self:
        if not self.structure_review <= self.structure_proceed:
            raise ValueError("structure_review must not exceed structure_proceed")
        if not self.link_review_min <= self.link_proposed_min:
            raise ValueError("link_review_min must not exceed link_proposed_min")
        return self


_REPOSITORY_NAME = re.compile(r"[\w.-]+/[\w.-]+")

# Settings that must be present (and not a "<placeholder>") when KP_MODE=real.
_REAL_MODE_REQUIRED: tuple[str, ...] = (
    "gateway_base_url",
    "gateway_token_url",
    "gateway_client_id",
    "gateway_client_secret",
    "gateway_token_header",
    "source_token_header",
    "use_case_id",
    "extraction_base_url",
    "raw_bucket",
    "markdown_bucket",
    "spec_repo",
    "spec_path",
)


class Settings(BaseSettings):
    """All settings of the platform. See ``.env.example`` style placeholders in the README."""

    model_config = SettingsConfigDict(
        env_prefix="KP_",
        env_nested_delimiter="__",
        extra="ignore",
        frozen=True,
    )

    mode: Mode = Mode.LOCAL
    log_level: str = "INFO"
    database_url: SecretStr = SecretStr("sqlite+pysqlite:///kp-local.db")  # may carry a password
    data_dir: Path = Path("var")

    # Gateway and credentials (real route).
    gateway_base_url: str | None = None  # e.g. <gateway-base-url>
    gateway_token_url: str | None = None  # e.g. <token-endpoint>
    gateway_client_id: str | None = None  # e.g. <client-id>
    gateway_client_secret: SecretStr | None = None
    gateway_token_header: str | None = None  # caller-identity header name
    source_token_header: str | None = None  # per-tool source credential header name
    source_token_confluence: SecretStr | None = None
    source_token_jira: SecretStr | None = None
    source_token_github: SecretStr | None = None
    use_case_id: str | None = None  # e.g. <issued-identifier>
    tool_namespace_confluence: str | None = None  # e.g. <namespace>
    tool_namespace_jira: str | None = None
    tool_namespace_github: str | None = None
    token_refresh_fraction: Annotated[float, Field(gt=0, lt=1)] = 0.8

    # Storage and extraction (real route).
    extraction_base_url: str | None = None  # e.g. <extraction-endpoint>
    raw_bucket: str | None = None  # e.g. <bucket>
    markdown_bucket: str | None = None  # e.g. <bucket>
    sample_items_file: Path | None = None  # the nine connectivity items
    extraction_auth_header: str | None = None  # header name for the extraction service
    extraction_token: SecretStr | None = None  # its own credential, never the gateway token

    # Source scope.
    document_library_root: Path | None = None
    regulatory_repo_path: Path | None = None
    confluence_export_path: Path | None = None  # stand-in export; default <data_dir>/confluence
    jira_export_path: Path | None = None  # stand-in export; default <data_dir>/jira
    code_repo_path: Path | None = None  # stand-in checkout; default <data_dir>/code_repo
    confluence_approved_label: str = "approved"
    document_types: tuple[str, ...] = (
        "guide",
        "procedure",
        "policy",
        "standard",
        "specification",
        "register",
        "rulebook",
    )  # document types the processors know; any other is held for review
    jira_project_key: str | None = None  # e.g. <project-key>
    jira_overlap_seconds: Annotated[int, Field(ge=0)] = 60
    jira_page_size: Annotated[int, Field(ge=1)] = 100

    # Access control.
    identity_mapping_file: Path | None = None

    # Write targets: server-side constants, never taken from an agent request.
    spec_repo: str | None = None  # e.g. <org>/<repository>
    spec_path: str | None = None  # e.g. <directory-for-specs>
    jira_fields_allowed: tuple[str, ...] = ()  # e.g. ["status", "<link-field>"]
    git_binary: str | None = None  # git executable for the local spec repository

    thresholds: Thresholds = Thresholds()

    @model_validator(mode="after")
    def _extraction_auth_is_paired(self) -> Self:
        if (self.extraction_auth_header is None) != (self.extraction_token is None):
            raise ValueError(
                "KP_EXTRACTION_AUTH_HEADER and KP_EXTRACTION_TOKEN must be set together"
            )
        return self

    @model_validator(mode="after")
    def _write_targets_are_confined(self) -> Self:
        """Reject a spec repository or path that could point outside the agreed location."""
        if (
            self.spec_repo is not None
            and not _is_unset(self.spec_repo)
            and not _REPOSITORY_NAME.fullmatch(self.spec_repo.strip())
        ):
            raise ValueError("KP_SPEC_REPO must look like <owner>/<repository>")
        if self.spec_path is not None and not _is_unset(self.spec_path):
            path = PurePosixPath(self.spec_path.strip())
            if path.is_absolute() or "\\" in self.spec_path or {"..", ".git"} & set(path.parts):
                raise ValueError("KP_SPEC_PATH must be a relative path without '..' or '.git'")
        return self

    @model_validator(mode="after")
    def _real_mode_is_complete(self) -> Self:
        if self.mode is not Mode.REAL:
            return self
        missing = [name for name in _REAL_MODE_REQUIRED if _is_unset(getattr(self, name))]
        if not self.jira_fields_allowed:
            missing.append("jira_fields_allowed")
        if _is_unset(self.database_url) or _is_sqlite(self.database_url):
            missing.append("database_url")
        if missing:
            joined = ", ".join(f"KP_{name.upper()}" for name in missing)
            hint = (
                " (the database must be PostgreSQL, not a SQLite file)"
                if ("database_url" in missing)
                else ""
            )
            raise ValueError(f"KP_MODE=real requires real values for: {joined}{hint}")
        return self


def _is_sqlite(url: SecretStr) -> bool:
    """Return True when a database URL names the SQLite backend."""
    return url.get_secret_value().strip().lower().startswith("sqlite")


def _is_unset(value: object) -> bool:
    """Return True when a setting is absent or still a ``<placeholder>``."""
    if value is None:
        return True
    text = value.get_secret_value() if isinstance(value, SecretStr) else str(value)
    stripped = text.strip()
    return not stripped or (stripped.startswith("<") and stripped.endswith(">"))


def load_settings() -> Settings:
    """Load settings from the process environment.

    :return: The validated, immutable settings
    :raises kp.errors.ConfigurationError: If a value is invalid or real mode is incomplete
    """
    try:
        return Settings()
    except ValidationError as exc:
        # Report field names and reasons only; input values may be secrets.
        problems = "; ".join(
            f"{'.'.join(str(part) for part in err['loc']) or 'settings'}: {err['msg']}"
            for err in exc.errors(include_input=False, include_url=False)
        )
        raise ConfigurationError(f"Invalid settings: {problems}") from exc
