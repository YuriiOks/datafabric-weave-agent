"""Jira updaters: a REST client and a dry-run stand-in.

The only change either makes is the one in :class:`~kp.writeback.models.JiraStoryUpdate`: set
the link field, then move the story to the target status through a workflow transition. No
other field is read for writing or written. Both are idempotent, so a retry after a partial
failure converges.
"""

from __future__ import annotations

import logging
from typing import cast
from urllib.parse import quote

import httpx
from pydantic import JsonValue

from kp.config import Settings
from kp.writeback.errors import JiraTransientError, JiraUpdateError
from kp.writeback.http import (
    HTTP_NO_CONTENT,
    HTTP_OK,
    build_client,
    is_transient_status,
    source_token_header,
)
from kp.writeback.models import JiraApplied, JiraStoryUpdate

logger = logging.getLogger(__name__)

_Json = dict[str, JsonValue]


class JiraRestClient:
    """Updates a story through the Jira REST API.

    :param client: An HTTP client whose base URL is the Jira root
    """

    def __init__(self, client: httpx.Client) -> None:
        self._client = client

    @classmethod
    def from_settings(
        cls, settings: Settings, *, base_url: str, transport: httpx.BaseTransport | None = None
    ) -> JiraRestClient:
        """Build a client with the Jira source credential from settings.

        :param settings: Platform settings (the Jira source token and its header name)
        :param base_url: Root URL of the Jira API
        :param transport: A transport to use instead of the network (tests)
        :return: The client; it owns its HTTP client
        """
        return cls(
            build_client(
                base_url,
                token=settings.source_token_jira,
                token_header=source_token_header(settings),
                transport=transport,
            )
        )

    def apply(self, update: JiraStoryUpdate) -> JiraApplied:
        """Set the link field, then move the story to the target status if it is not there.

        :param update: The status and link field to set
        :return: What changed
        :raises kp.writeback.errors.JiraTransientError: If Jira is unreachable or failing
        :raises kp.writeback.errors.JiraUpdateError: If Jira refuses, or offers no transition
            to the target status
        """
        issue = f"/rest/api/2/issue/{quote(update.story_key, safe='')}"
        self._send(
            "PUT",
            issue,
            {HTTP_NO_CONTENT, HTTP_OK},
            {"fields": {update.link_field: update.link_value}},
        )
        current = self._send("GET", issue, {HTTP_OK}, params={"fields": "status"})
        if self._current_status(current) == update.status:
            logger.info(
                "Jira story already in target status", extra={"story_key": update.story_key}
            )
            return JiraApplied(status_changed=False, link_set=True)
        transitions = self._send("GET", f"{issue}/transitions", {HTTP_OK})
        transition_id = self._transition_to(transitions, update.status)
        self._send(
            "POST",
            f"{issue}/transitions",
            {HTTP_NO_CONTENT, HTTP_OK},
            {"transition": {"id": transition_id}},
        )
        logger.info("Jira story updated", extra={"story_key": update.story_key})
        return JiraApplied(status_changed=True, link_set=True)

    def _send(
        self,
        method: str,
        path: str,
        expected: set[int],
        body: _Json | None = None,
        *,
        params: dict[str, str] | None = None,
    ) -> httpx.Response:
        try:
            response = self._client.request(method, path, json=body, params=params)
        except httpx.HTTPError as exc:
            raise JiraTransientError("Jira could not be reached") from exc
        if response.status_code in expected:
            return response
        logger.warning(
            "Jira refused a request", extra={"method": method, "status": response.status_code}
        )
        message = f"Jira answered {response.status_code} to {method}"
        if is_transient_status(response.status_code):
            raise JiraTransientError(message)
        raise JiraUpdateError(message)

    @staticmethod
    def _body(response: httpx.Response) -> _Json:
        try:
            body = response.json()
        except ValueError as exc:
            raise JiraUpdateError("Jira answered with invalid JSON") from exc
        if not isinstance(body, dict):
            raise JiraUpdateError("Jira answered with an unexpected shape")
        return cast(_Json, body)

    def _current_status(self, response: httpx.Response) -> str | None:
        fields = self._body(response).get("fields")
        status = fields.get("status") if isinstance(fields, dict) else None
        name = status.get("name") if isinstance(status, dict) else None
        return name if isinstance(name, str) else None

    def _transition_to(self, response: httpx.Response, status: str) -> str:
        offered = self._body(response).get("transitions")
        for item in offered if isinstance(offered, list) else []:
            if not isinstance(item, dict):
                continue
            target = item.get("to")
            name = target.get("name") if isinstance(target, dict) else None
            identifier = item.get("id")
            if (
                isinstance(name, str)
                and name.casefold() == status.casefold()
                and isinstance(identifier, str)
            ):
                return identifier
        raise JiraUpdateError("Jira offers no transition to the target status")


class DryRunJiraUpdater:
    """Records the update it would make and changes nothing."""

    def __init__(self) -> None:
        self.updates: list[JiraStoryUpdate] = []

    def apply(self, update: JiraStoryUpdate) -> JiraApplied:
        """Record the update.

        :param update: The status and link field that would be set
        :return: A result marked as a dry run
        """
        self.updates.append(update)
        logger.info("Jira update skipped (dry run)", extra={"story_key": update.story_key})
        return JiraApplied(status_changed=True, link_set=True, dry_run=True)
