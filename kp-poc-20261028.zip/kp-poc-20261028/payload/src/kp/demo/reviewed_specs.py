"""The part of the demo that plays the people: they merge specs and edit them.

On the real route a reviewer merges the pull request on the repository host and may edit the
file first. Here the same two things happen on the local spec repository, through the
publishers' own operations, so everything after them (the sweep, the load-back, the links) is
the platform's real code path.
"""

from __future__ import annotations

from pathlib import Path

from kp.app import Application
from kp.demo.staging import StagedData
from kp.domain import ClauseRef
from kp.errors import ConfigurationError
from kp.writeback import MergeResult, PublishRequest, SpecMerger

_PERSON_BRANCH = "people"
_MACHINE_MARK = "machine_authored: true\n"


def _request(application: Application, branch: str, path: str, content: str) -> PublishRequest:
    title = f"Spec change {Path(path).stem}"
    return PublishRequest(
        repository=application.settings.spec_repo or "",
        branch=branch,
        path=path,
        content=content,
        commit_message=f"{title}\n",
        pr_title=title,
        pr_body=f"{title}, written by a person.\n",
    )


def _merger(application: Application) -> SpecMerger:
    publisher = application.writers().publisher
    if not isinstance(publisher, SpecMerger):
        raise ConfigurationError("The spec publisher of this mode cannot merge a pull request")
    return publisher


def seed_merged_specs(application: Application, staged: StagedData) -> int:
    """Put the specs a person already merged into the spec repository.

    :param application: The application
    :param staged: The staged dataset, whose spec repository folder holds the files
    :return: How many specs were merged
    """
    folder = staged.spec_repo
    files = sorted(folder.rglob("*.md")) if folder.is_dir() else []
    publisher = _merger(application)
    for path in files:
        relative = path.relative_to(folder).as_posix()
        branch = f"{_PERSON_BRANCH}/{Path(relative).stem}"
        request = _request(application, branch, relative, path.read_text(encoding="utf-8"))
        application.writers().publisher.publish(request)
        publisher.merge(branch)
    return len(files)


def person_edits_and_merges(
    application: Application, merged: MergeResult, *, replace: tuple[str, str]
) -> MergeResult:
    """A person edits a merged machine spec: takes the machine mark off and cites another rule.

    :param application: The application
    :param merged: The merge of the machine-authored spec
    :param replace: The clause reference the person stops citing, and the one cited instead
    :return: The merge of the edit
    :raises kp.errors.ConfigurationError: If the file is not among the merged specs
    """
    source = application.spec_source()
    current = next(
        (item for item in (source.merged_specs() if source else []) if item.path == merged.path),
        None,
    )
    if current is None:
        raise ConfigurationError("The merged spec is not in the spec repository")
    text = current.content.decode("utf-8").replace(_MACHINE_MARK, "", 1)
    old, new = (ClauseRef.parse(item) for item in replace)
    # Both ways a spec cites a clause: the canonical form and the spoken one.
    edited = text.replace(old.format(), new.format()).replace(old.human(), new.human())
    branch = f"{_PERSON_BRANCH}/edit-{Path(merged.path).stem}"
    publisher = application.writers().publisher
    publisher.publish(_request(application, branch, merged.path, edited))
    return _merger(application).merge(branch)
