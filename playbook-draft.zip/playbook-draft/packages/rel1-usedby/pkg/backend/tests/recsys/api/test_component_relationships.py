"""Detail-page relationships: who uses a component, and what stays withheld."""

from __future__ import annotations

import unittest
from collections.abc import Callable
from contextlib import asynccontextmanager
from typing import Any

from app.recsys.contracts import RelationshipDisclosureState
from app.recsys.db import repository as repo
from app.recsys.db.repository import (
    DEPENDS_LINK_TYPES,
    USES_LINK_TYPES,
    RecsysRepository,
    RegistryReadScope,
)

VERSION = "catalogue-fixture"
TENANT = "tenant-one"
SCOPE = RegistryReadScope(
    principal_id="reader-fixture", catalogue_version=VERSION, allowed_tenants=(TENANT,)
)
SKILL = "skill:search-helper"
DEPENDENT_SKILL = "skill:report-writer"
AGENT = "agent:tenant-one/triage-helper"


def _row(component_id: str) -> dict[str, Any]:
    component_type = component_id.split(":", 1)[0]
    return {
        "component_id": component_id,
        "catalogue_version": VERSION,
        "component_type": component_type,
        "name": component_id.split(":", 1)[1],
        "description": "Fixture component.",
        "source": "fixture",
        "source_ref": "fixture:1",
        "external_ids": {},
        "tenants": [TENANT],
        "version": None,
        "triggers": [],
        "tools": [],
        "tags": [],
        "quality_flags": [],
        "eligible": True,
        "retrieval_text": "",
        "definition": "",
    }


class _Connection:
    """Answers each repository query by its constant, recording the arguments."""

    def __init__(self, handlers: dict[str, Callable[..., Any]]) -> None:
        self.handlers = handlers
        self.calls: list[tuple[str, tuple[Any, ...]]] = []

    def _answer(self, query: str, args: tuple[Any, ...]) -> Any:
        self.calls.append((query, args))
        if query not in self.handlers:
            raise AssertionError("unexpected query")
        return self.handlers[query](*args)

    async def fetch(self, query: str, *args: Any) -> list[Any]:
        return self._answer(query, args)

    async def fetchrow(self, query: str, *args: Any) -> Any:
        return self._answer(query, args)


class _Pool:
    def __init__(self, connection: _Connection) -> None:
        self.connection = connection

    @asynccontextmanager
    async def acquire(self):
        yield self.connection


#: Resolved links in the fixture catalogue: (src, dst, link type).
LINKS = [
    (AGENT, SKILL, "USES_SKILL"),
    (DEPENDENT_SKILL, SKILL, "DEPENDS_ON_SKILL"),
]
#: Unresolved link rows: (outgoing, link type, count) as the disclosure query groups them.
UNRESOLVED_LINKS: list[tuple[bool, str, int]] = []


def _handlers() -> dict[str, Callable[..., Any]]:
    def links_to(version, dst, link_types, tenants):
        return [
            {"src_id": src}
            for src, target, link_type in LINKS
            if target == dst and link_type in link_types
        ]

    def links_from(version, src, link_types, tenants):
        return [
            {"dst_id": dst, "link_type": link_type}
            for source, dst, link_type in LINKS
            if source == src and link_type in link_types
        ]

    def unresolved(version, component_id):
        return [
            {"outgoing": outgoing, "link_type": link_type, "resolved": False, "total": total}
            for outgoing, link_type, total in UNRESOLVED_LINKS
        ]

    def summaries(version, ids, tenants):
        return [_row(component_id) for component_id in ids]

    return {
        repo._COMPONENT_BY_ID: lambda version, component_id, tenants: _row(component_id),
        repo._LINKS_FROM: links_from,
        repo._LINKS_TO: links_to,
        repo._UNRESOLVED_LINK_DISCLOSURE_COUNTS: unresolved,
        repo._AUTHORIZED_COMPONENTS_BY_IDS: summaries,
    }


class UsedByTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.connection = _Connection(_handlers())
        self.repository = RecsysRepository(_Pool(self.connection))

    def tearDown(self) -> None:
        UNRESOLVED_LINKS.clear()

    async def test_used_by_lists_only_components_that_use_this_one(self) -> None:
        detail = await self.repository.get_component(VERSION, SKILL, SCOPE)

        self.assertEqual([item.component_id for item in detail.used_by], [AGENT])
        self.assertEqual(detail.used_by_disclosure.resolved_count, 1)
        self.assertEqual(
            detail.used_by_disclosure.state, RelationshipDisclosureState.complete
        )

    async def test_the_incoming_query_is_limited_to_usage_links(self) -> None:
        await self.repository.get_component(VERSION, SKILL, SCOPE)

        (args,) = [args for query, args in self.connection.calls if query == repo._LINKS_TO]
        self.assertEqual(args, (VERSION, SKILL, list(USES_LINK_TYPES), [TENANT]))

    async def test_a_dependent_skill_still_shows_what_it_depends_on(self) -> None:
        detail = await self.repository.get_component(VERSION, DEPENDENT_SKILL, SCOPE)

        self.assertEqual([item.component_id for item in detail.depends_on], [SKILL])
        self.assertEqual(detail.used_by, [])

    async def test_withheld_incoming_dependencies_do_not_count_as_used_by(self) -> None:
        UNRESOLVED_LINKS.extend(
            [(False, link_type, 2) for link_type in DEPENDS_LINK_TYPES]
            + [(False, "USES_MCP", 3)]
        )

        detail = await self.repository.get_component(VERSION, SKILL, SCOPE)

        self.assertEqual(detail.used_by_disclosure.withheld_unresolved_count, 3)
        self.assertEqual(
            detail.used_by_disclosure.state, RelationshipDisclosureState.unresolved_withheld
        )


if __name__ == "__main__":
    unittest.main()
