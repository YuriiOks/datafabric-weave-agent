"""Jira adapter. The version token is a SHA-256 of the issue's semantic fields.

Jira has no per-issue version number, and ``updated`` moves for reasons that change nothing a
reader cares about. The token therefore hashes only the fields that carry meaning: summary,
description, status, labels, links, parent and the comment texts. The stored raw object is
that same projection, so equal tokens mean equal bytes.
"""

from __future__ import annotations

from collections.abc import Sequence

from pydantic import JsonValue

from kp.connectivity.adapters.base import (
    GatewayToolAdapter,
    decode_base64,
    dig_object,
    dig_text,
    fetched_item,
    optional_text,
    optional_time,
)
from kp.connectivity.digest import canonical_json, sha256_hex
from kp.connectivity.errors import FidelityError
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.models import JsonObject, Route, SampleItem
from kp.sources.base import FetchedItem, ItemMetadata

ISSUE_TOOL = "get_issue"
ATTACHMENT_TOOL = "get_attachment"

# Fields copied from ``fields`` into the semantic projection, besides summary and status.
_OPTIONAL_SEMANTIC = ("description", "labels", "issuelinks", "parent", "acceptance_criteria")


class JiraAdapter(GatewayToolAdapter):
    """Reads issues and attachments through the Jira tool server.

    :param client: The gateway client
    :param route: The Jira route
    :param items: The Jira sample items
    :param issue_tool: Name of the issue tool
    :param attachment_tool: Name of the attachment tool
    """

    def __init__(
        self,
        client: GatewayClient,
        route: Route,
        items: Sequence[SampleItem],
        *,
        issue_tool: str = ISSUE_TOOL,
        attachment_tool: str = ATTACHMENT_TOOL,
    ) -> None:
        super().__init__(client, route, items)
        self._issue_tool = issue_tool
        self._attachment_tool = attachment_tool

    def _fetch_primary(self, item: SampleItem) -> FetchedItem:
        payload = self._call(item, self._issue_tool, {"issue_key": item.native_id})
        key = dig_text(item, payload, "key")
        projection = semantic_projection(item, payload)
        content = canonical_json(projection)
        return fetched_item(
            item,
            sha256_hex(content),
            content,
            ItemMetadata(
                native_id=key,
                media_type=item.media_type,
                title=dig_text(item, payload, "fields.summary"),
                author=optional_text(payload, "fields.reporter"),
                modified_at=optional_time(payload, "fields.updated"),
            ),
        )

    def _fetch_attachment(self, item: SampleItem) -> FetchedItem:
        payload = self._call(
            item,
            self._attachment_tool,
            {"issue_key": item.parent_native_id or "", "attachment_id": item.native_id},
        )
        content = decode_base64(item, payload, "content_base64")
        return fetched_item(
            item,
            sha256_hex(content),
            content,
            ItemMetadata(
                native_id=dig_text(item, payload, "id"),
                media_type=item.media_type,
                title=dig_text(item, payload, "filename"),
                author=optional_text(payload, "author"),
                modified_at=optional_time(payload, "created"),
                attributes={"attachment_parent": item.parent_native_id},
            ),
        )


def semantic_projection(item: SampleItem, payload: JsonObject) -> JsonObject:
    """Select the fields of an issue that make up its meaning.

    :param item: The item being read, for errors
    :param payload: The tool's issue object
    :return: The projection that is hashed and stored
    :raises kp.connectivity.errors.FidelityError: If summary, status or the key are missing
    """
    fields = dig_object(item, payload, "fields")
    projection: JsonObject = {
        "key": dig_text(item, payload, "key"),
        "summary": dig_text(item, payload, "fields.summary"),
        "status": dig_text(item, payload, "fields.status.name"),
    }
    for name in _OPTIONAL_SEMANTIC:
        if name in fields:
            projection[name] = fields[name]
    projection["comments"] = _comment_texts(item, payload)
    return projection


def _comment_texts(item: SampleItem, payload: JsonObject) -> list[JsonValue]:
    comment = dig_object(item, payload, "fields").get("comment")
    if comment is None:
        return []
    comments = comment.get("comments") if isinstance(comment, dict) else None
    if not isinstance(comments, list):
        raise FidelityError(item.source.value, item.item_id, "comment field has an unknown shape")
    return [entry["body"] for entry in comments if isinstance(entry, dict) and "body" in entry]
