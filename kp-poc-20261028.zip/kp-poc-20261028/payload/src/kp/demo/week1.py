"""Week 1, "sources in": the rulebook, the register and the stories are loaded, every clause
can be referenced on its own, and drafts are excluded."""

from __future__ import annotations

from collections import defaultdict

from sqlalchemy import Connection, func, select

from kp.app import Application
from kp.demo.build import BuildRun
from kp.demo.model import Check, LineResult
from kp.demo.staging import StagedData
from kp.domain import ApprovalState, ReviewKind, SourceKind
from kp.errors import KpError
from kp.search import quote_matches
from kp.store import schema

_SEARCHABLE = {ApprovalState.ADMITTED.value, ApprovalState.SUPERSEDED.value}


def evaluate_week1(application: Application, staged: StagedData, build: BuildRun) -> LineResult:
    """Judge the week 1 line.

    :param application: The application the build ran on
    :param staged: The staged dataset (for the ground truth)
    :param build: What the build phases returned
    :return: The line with its checks
    """
    with application.database.transaction() as connection:
        checks = (
            _rulebook_loaded(connection, staged),
            _register_loaded(connection, staged),
            _stories_loaded(connection, staged),
            _every_clause_referenced(application, staged),
            _drafts_excluded(connection, staged),
            _board_move_causes_no_rework(build, staged),
        )
    return LineResult("W1", checks)


def _rulebook_loaded(connection: Connection, staged: StagedData) -> Check:
    stored: dict[str, int] = {
        edition: count
        for edition, count in connection.execute(
            select(schema.clause.c.edition, func.count()).group_by(schema.clause.c.edition)
        )
    }
    expected = {e.label: len(e.clauses) for e in staged.dataset.truth.editions}
    detail = ", ".join(f"{label}: {stored.get(label, 0)} of {n}" for label, n in expected.items())
    return Check("Payment rulebook loaded (clauses per edition)", stored == expected, detail)


def _register_loaded(connection: Connection, staged: StagedData) -> Check:
    truth = staged.dataset.truth.requirements_register
    sheets: dict[str, int] = {
        sheet: count
        for sheet, count in connection.execute(
            select(schema.requirement.c.sheet, func.count()).group_by(schema.requirement.c.sheet)
        )
    }
    refused = connection.execute(
        select(func.count()).where(schema.review_item.c.kind == ReviewKind.REGISTER_HEADER.value)
    ).scalar_one()
    ok = sheets == {truth.main_sheet: truth.data_row_count} and refused >= 1
    detail = (
        f"{sheets.get(truth.main_sheet, 0)} requirements from sheet '{truth.main_sheet}' "
        f"(register has {truth.data_row_count} data rows); sheet '{truth.headerless_sheet}' has "
        f"no readable header and was refused with {refused} review item(s)"
    )
    return Check("Requirements register loaded, one requirement per row", ok, detail)


def _stories_loaded(connection: Connection, staged: StagedData) -> Check:
    truth = staged.dataset.truth.stories
    keys = set(connection.execute(select(schema.story.c.story_key)).scalars())
    status_only = truth.status_only_key in keys
    detail = f"{len(keys)} of {truth.story_count} stories of the project: " + ", ".join(
        sorted(keys)
    )
    return Check(
        "One project's stories loaded", len(keys) == truth.story_count and status_only, detail
    )


def _every_clause_referenced(application: Application, staged: StagedData) -> Check:
    failures: list[str] = []
    total = 0
    for edition in staged.dataset.truth.editions:
        markdown = staged.dataset.path(edition.markdown_path).read_text(encoding="utf-8")
        for clause in edition.clauses:
            total += 1
            reference = f"{edition.label}:{clause.number}"
            try:
                found = application.search.lookup(reference)
            except KpError:
                failures.append(reference)
                continue
            positioned = found.page == clause.page and found.char_start is not None
            if not (positioned and quote_matches(found, markdown)):
                failures.append(reference)
    detail = (
        f"{total - len(failures)} of {total} clauses opened on their own by reference, with "
        "page and position, and the text equals the source at that position"
    )
    if failures:
        detail += "; failed: " + ", ".join(failures[:5])
    return Check("Every rule clause can be referenced on its own", not failures, detail)


def _drafts_excluded(connection: Connection, staged: StagedData) -> Check:
    versions: dict[str, set[str]] = defaultdict(set)
    for item_id, version in connection.execute(
        select(schema.source_item.c.item_id, schema.source_item.c.version).where(
            schema.source_item.c.source.in_(
                [SourceKind.DOCUMENT_LIBRARY.value, SourceKind.CONFLUENCE.value]
            )
        )
    ):
        versions[item_id].add(version)
    guide_ok = versions["operating-guide"] == {"2"}
    page = staged.dataset.truth.confluence
    page_ok = "3" not in versions[page.page_with_newer_draft]
    unlabelled_state = connection.execute(
        select(schema.source_item.c.approval_state).where(
            schema.source_item.c.item_id == page.unlabelled_page
        )
    ).scalar_one()
    leaked = connection.execute(
        select(func.count())
        .select_from(schema.passage)
        .join(
            schema.source_item,
            (schema.source_item.c.source == schema.passage.c.source)
            & (schema.source_item.c.item_id == schema.passage.c.item_id)
            & (schema.source_item.c.version == schema.passage.c.version),
        )
        .where(schema.source_item.c.approval_state.not_in(_SEARCHABLE))
    ).scalar_one()
    ok = guide_ok and page_ok and unlabelled_state != ApprovalState.ADMITTED.value and leaked == 0
    detail = (
        f"library guide stores only version(s) {sorted(versions['operating-guide'])} "
        "(its newer draft was never listed or stored); "
        "Confluence page with a newer draft stores "
        f"{sorted(versions[page.page_with_newer_draft])}; "
        f"the page without the approved label is '{unlabelled_state}'; "
        f"{leaked} passages belong to a version that is not approved"
    )
    return Check("Drafts and unapproved versions excluded", ok, detail)


def _board_move_causes_no_rework(build: BuildRun, staged: StagedData) -> Check:
    truth = staged.dataset.truth.stories
    reworked = {item.key.item_id for item in build.second_sweep.work_items}
    ok = (
        truth.status_only_key not in reworked
        and truth.criteria_changed_key in reworked
        and build.second_sweep.versions_recorded
        >= len({truth.status_only_key, truth.criteria_changed_key})
    )
    detail = (
        f"second export recorded {build.second_sweep.versions_recorded} new versions; reprocessed: "
        f"{sorted(reworked) or 'none'} (board move {truth.status_only_key} left alone, "
        f"criteria change {truth.criteria_changed_key} reprocessed)"
    )
    return Check("A status-only board move causes no rework", ok, detail)
