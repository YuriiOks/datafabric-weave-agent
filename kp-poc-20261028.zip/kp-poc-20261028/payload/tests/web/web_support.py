"""Reading rendered pages in tests: plain text and the structure that accessibility depends on."""

from __future__ import annotations

from dataclasses import dataclass, field
from html.parser import HTMLParser

BARE_PAGES = ("/", "/search", "/rule", "/impact", "/coverage", "/specs", "/connectivity", "/audit")
PAGES = (
    "/",
    "/search?q=currency",
    "/rule?number=4.2.1",
    "/impact?clause=4.2.1",
    "/coverage",
    "/specs?story=PAY-101",
    "/connectivity",
    "/audit",
)


@dataclass
class Structure:
    """What a page says about itself."""

    language: str | None = None
    headings: list[tuple[str, str]] = field(default_factory=list)
    landmarks: set[str] = field(default_factory=set)
    labels_for: set[str] = field(default_factory=set)
    controls: list[str] = field(default_factory=list)
    scripts: int = 0
    images: int = 0
    external: list[str] = field(default_factory=list)
    skip_link: bool = False
    table_headers_without_scope: int = 0


class _Reader(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.structure = Structure()
        self._current: str | None = None
        self._text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {name: value or "" for name, value in attrs}
        found = self.structure
        if tag == "html":
            found.language = values.get("lang")
        elif tag in {"h1", "h2", "h3"}:
            self._current = tag
            self._text = []
        elif tag in {"main", "nav", "header", "footer"}:
            found.landmarks.add(tag)
        elif tag == "label":
            found.labels_for.add(values.get("for", ""))
        elif tag in {"input", "select"} and values.get("type") != "hidden":
            found.controls.append(values.get("id", ""))
        elif tag == "script":
            found.scripts += 1
        elif tag == "img":
            found.images += 1
        elif tag == "th" and "scope" not in values:
            found.table_headers_without_scope += 1
        elif tag == "a" and values.get("href") == "#main":
            found.skip_link = True
        for name in ("href", "src", "action"):
            value = values.get(name, "")
            if value.startswith(("http:", "https:", "//")):
                found.external.append(value)

    def handle_data(self, data: str) -> None:
        if self._current is not None:
            self._text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == self._current:
            self.structure.headings.append((tag, "".join(self._text).strip()))
            self._current = None


def structure_of(page: str) -> Structure:
    """Read the structure of a rendered page.

    :param page: The page's HTML
    :return: Its language, headings, landmarks, labelled controls and external references
    """
    reader = _Reader()
    reader.feed(page)
    return reader.structure
