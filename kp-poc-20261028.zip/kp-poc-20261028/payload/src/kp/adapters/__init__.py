"""Adapters between the ports of the lane packages.

Each module here joins two ports that were built apart: it implements one lane's protocol on
top of another lane's implementation. The composition root (:mod:`kp.app`) is the only place
that puts them together. One module per seam; none of them holds business rules of its own.
"""
