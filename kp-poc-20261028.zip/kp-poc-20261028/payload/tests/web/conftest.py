"""A built platform with one published spec and one connectivity run, served by the web UI."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from pydantic import SecretStr

from kp.config import Settings
from kp.demo.connectivity import DATABASE_FILE, run_connectivity
from kp.web.app import create_app
from kp.web.settings import WebSettings
from kp.writeback import draft_spec
from world_support import World, build_world

PUBLISHED_STORY = "PAY-101"
SPEC_TYPE = "functional"
LOCAL_USERS = (
    "user-full-access",
    "user-no-access",
    "user-no-payments-access",
    "user-one-domain",
)
CURRENCY_QUESTION = "which currency may an inbound credit transfer use?"


@dataclass(frozen=True)
class WebWorld:
    """The platform the pages are tested on.

    :ivar connectivity: Settings of the database the connectivity run used.
    """

    world: World
    connectivity: Settings


@pytest.fixture(scope="session")
def web_world(
    committed_fixtures_dir: Path, tmp_path_factory: pytest.TempPathFactory
) -> Iterator[WebWorld]:
    """The demo's platform, with a spec published for one story and a connectivity run."""
    world = build_world(committed_fixtures_dir, tmp_path_factory.mktemp("web-world"))
    application = world.application
    draft_spec(
        PUBLISHED_STORY,
        runtime=application.draft_runtime(),
        publish=True,
        spec_type=SPEC_TYPE,
        as_at=application.clock.today(),
    )
    run_connectivity(world.settings, application.clock, world.workdir)
    connectivity = world.settings.model_copy(
        update={
            "database_url": SecretStr(f"sqlite+pysqlite:///{world.workdir / DATABASE_FILE}"),
            "data_dir": world.workdir / "connectivity",
        }
    )
    yield WebWorld(world, connectivity)
    application.close()


@pytest.fixture
def client(web_world: WebWorld) -> TestClient:
    """A browser stand-in for the local-mode UI."""
    app = create_app(
        web_world.world.application,
        settings=WebSettings(),
        connectivity=web_world.connectivity,
    )
    return TestClient(app)
