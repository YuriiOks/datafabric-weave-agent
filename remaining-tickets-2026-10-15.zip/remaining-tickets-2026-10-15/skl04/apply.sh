#!/usr/bin/env bash
# Apply the Skill case-pack package to a clean worktree, uncommitted and unstaged.
# Usage: bash apply.sh <worktree-root>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:?worktree root}"
python3 "$HERE/apply_skl04.py" "$ROOT" --check
python3 "$HERE/apply_skl04.py" "$ROOT"
git -C "$ROOT" status -s --untracked-files=all
