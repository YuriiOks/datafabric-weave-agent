"""Tests for inbound validation (synthetic)."""

from payments.inbound import validate_amount, validate_currency


def test_unlisted_currency_is_rejected() -> None:
    """Verifies 2026.1:4.2.1."""
    assert not validate_currency("USD")


def test_amount_above_limit_is_rejected() -> None:
    """Verifies 2026.1:4.2.2."""
    assert not validate_amount(2_000_000)
