---
name: km-pr
description: Checklist before any git push or pull request from a clone in /home/user/km. Use when the owner asks to push, to open or edit a pull request, or to hand over a branch. No hook enforces this here, so this checklist is the control.
argument-hint: <clone folder name>
---

# km-pr

Nothing is pushed or opened until every check passes and the owner has said go. $0 is the clone
folder name under /home/user/km. If it is missing, use the clone with commits ahead of its
upstream; if two qualify, ask which. Run name: km-pr-<clone>-<date>. Stop at the first failure,
report it in one line, and change nothing. Commands are read-only until step 8.

1. Branch. In a separate call, cd to /home/user/km/<clone>; check with `pwd`. Run
   `git status -sb`. The tree is clean, the branch is not the default branch, and the base is
   known (upstream, else the remote default branch). If the base is unclear, ask the owner.
2. Paths. `git diff --name-only <base>...HEAD`. No path under .claude or .github. No harness
   file: copies of AGENTS.md or CLAUDE.md, START.md, start.sh, anything from kb/, designs/ or
   work/, skills, agents, names or claims files.
3. Secrets. List files whose diff matches secret-shaped text, names only, never the match:
   `git diff --name-only -i -G'(password|secret|token|api[_-]?key|private key)' <base>...HEAD`
   and the same with an email pattern. Look at each file listed and decide. A credential,
   key, token, staff id or email address in the diff is a stop.
4. Commits. `git log --format='%h %s' <base>..HEAD`. Each commit is one logical step with a
   one-line message. History was not amended or rebased; the main line comes in by merge commit.
   No session link line and no attribution typed by hand. The attribution line the environment
   adds to commits is expected: leave it, do not add or strip it.
5. Guard. From inside the clone run `/home/user/km/.claude/bin/pre-push-guard.sh --check` by its
   full path (if it is not executable, `bash` with the same path). Show its output to the owner.
   Anything other than a pass is a stop.
6. Pull request text, only when one is being opened or edited. Read
   ${CLAUDE_SKILL_DIR}/references/pr-text.md and check the draft against it.
7. Review, optional. The owner may run `/km-review diff <clone>` first. If he did, read its
   table before asking for the go.
8. Go. Print the summary below and ask: "go for push of <branch> in <clone>?" A go covers that
   one push only. Push from inside the clone with plain `git push` (add `-u origin <branch>`
   only if no upstream is set). Never `git -C <dir> push`: the approval rule matches the plain
   form only. Opening a pull request needs its own go. After the push run
   `git log -1 --format='%h %cI'` and return with `cd /home/user/km`.

Record the run in kb/log.d/<run>.txt: date, clone, branch, head id, result of each check, the
go (time), the pushed head id. No knowledge file is written, so there is no index.d entry.

If a command is denied or needs an approval you were not given, log it and stop.
End with a summary of at most 10 lines: one line per check as pass or stop, then the next action.
