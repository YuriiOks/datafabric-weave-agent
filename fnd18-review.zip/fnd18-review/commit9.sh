cd /home/user/bp-card-matured || exit 1
clear
[ "$(git branch --show-current)" = "feat/fnd-18" ] || { echo NOT ON BRANCH; exit 1; }
D=/home/user/bpc-port/fnd18-review
B=backend/app/recsys
git add $B/registry/agent_hub_api.py $B/config.py backend/tests/recsys/registry/test_agent_hub_api.py
git commit -q -F $D/commit9-msg.txt || exit 1
T=frontend/src/features/recsys
git add $T/components/RecommendationCard.tsx $T/components/RecommendationCard.test.tsx $T/component-page/fromRegistry.ts $T/component-page/fromRegistry.test.ts
git commit -q -F $D/commit10-msg.txt || exit 1
git log --format='%h %s' -2 | cut -c1-90
git diff --stat HEAD~2 | tail -1
echo "TRACKED CHANGES $(git status --short | grep -cv '^??')"
GIT_TERMINAL_PROMPT=0 git push origin feat/fnd-18 2>&1 | tail -1; echo PUSH RC ${PIPESTATUS[0]}
[ "$(git rev-parse origin/feat/fnd-18)" = "$(git rev-parse HEAD)" ] && echo PUSHED $(git rev-parse --short HEAD)
