"""Synthetic registrations for the refresh integration tests (no real sources)."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from app.recsys.acquisition.models import (
    RegisteredGitSource,
    RegisteredWorkbookSource,
    ResourceLimits,
    WorkbookConsistency,
)
from app.recsys.contract_fixtures import digest
from app.recsys.contracts.sources import (
    CollectionRevision,
    CompletenessState,
    OrderingBasis,
    SourceAuthority,
    SourceCollection,
)

from . import protocol_fixtures as fixtures

WORKBOOK_ID = "workbook-fixture"
SKILLS_ID = "skills-fixture"
WORKBOOK_PATH = Path("/srv/recsys-fixture/workspace/export.xlsx")
SKILLS_HOST = "git.fixture.invalid"

LIMITS = ResourceLimits(
    max_objects=1000,
    max_file_bytes=1_000_000,
    max_total_bytes=10_000_000,
    max_output_bytes=1_000_000,
    timeout_seconds=30.0,
)


def revision(collection: SourceCollection, number: int) -> CollectionRevision:
    """Return an authoritative, complete revision of one collection."""
    return CollectionRevision(
        collection=collection,
        revision=number,
        ordering_basis=OrderingBasis.authoritative_sequence,
        content_hash=digest(f"{collection.value}:{number}"),
        completeness=CompletenessState.complete_snapshot,
    )


def workbook_source(number: int = 7) -> RegisteredWorkbookSource:
    """Return a workbook registration for the fixture scope."""
    return RegisteredWorkbookSource(
        source_id=WORKBOOK_ID,
        authority=SourceAuthority.agent_hub_export,
        scope=fixtures.SCOPE,
        source_configuration_version="workbook-fixture-1",
        limits=LIMITS,
        path=WORKBOOK_PATH,
        consistency=WorkbookConsistency.stable_file_identity,
        resolved_revision=f"workbook-{number}",
        revision_captured_at=datetime(2026, 9, 15, tzinfo=UTC),
        max_age_seconds=86_400,
        collection_revisions=[
            revision(SourceCollection.agent_records, number),
            revision(SourceCollection.mcp_records, number),
        ],
    )


def skills_source() -> RegisteredGitSource:
    """Return a skills repository registration for the fixture scope."""
    return RegisteredGitSource(
        source_id=SKILLS_ID,
        authority=SourceAuthority.skills_repo,
        scope=fixtures.SCOPE,
        source_configuration_version="skills-fixture-1",
        limits=LIMITS,
        remote_url=f"https://{SKILLS_HOST}/skills/catalogue.git",
        ref="refs/heads/main",
        allowed_hosts=frozenset({SKILLS_HOST, "mirror.fixture.invalid"}),
        collection_revision=revision(SourceCollection.skill_content, 3),
        max_age_seconds=86_400,
    )
