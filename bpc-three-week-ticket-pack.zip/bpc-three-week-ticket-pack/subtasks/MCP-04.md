---
pack_id: "bpc-sep26-v1"
local_id: "MCP-04"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1347"
summary: "Expose MCP facts and incoming declaration evidence through the shared read contract"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 5
scope: "foundation"
create_by_default: true
planned_start: "2026-09-21"
planned_due: "2026-09-21"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["MCP-02","MCP-03","CORE-03","CORE-04","SKL-04","AGT-03"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-mcp-04"
architecture_sections: ["model","identity","ingestion","publication","read-contract"]
---

# Expose MCP facts and incoming declaration evidence through the shared read contract

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1347**. Local reference **MCP-04** is not a Jira key.
- Estimate: **5 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-21 → 2026-09-21 (D9–D9)**.
- Recommendation extension: **2026-09-22 → 2026-09-22 (D10–D10)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

The component graph may represent only relationships declared by approved sources. Produce MCP relationship facts that retain evidence, reject unresolved endpoints, and never imply suitability.

## Scope and contract

Input is a validated complete occurrence set and resolved endpoint references. Each fact records source authority/version/field locator, declared relation, endpoint identity/scope, resolver versions, and publication candidate. Both endpoints must be eligible for the same publication/scope. Normalise read-shape duplicates only by resolved endpoint/relation/publication tuple while preserving all source occurrences. Ambiguous, missing, cross-scope, and unsupported links remain in the review ledger.

## Steps

1. Map only MCP-01-approved and MCP-02-validated relation fields.
2. Resolve every endpoint through MCP-03/CORE-03.
3. Preserve relation provenance while generating CORE-04 projection input.
4. Emit unresolved/rejected references with locators; never fall back to name matching or graph inference.

## Acceptance and verification

- Exact in-scope declarations project with source/field evidence available on read.
- Repeated declarations do not duplicate the read relation but retain every origin.
- Ambiguous, missing, cross-scope, or display-name-only endpoints project no relation and remain visible.
- Partial/failed source input cannot activate a publication.
- No projected relation is labelled as compatibility, permission, quality, or recommendation evidence.

## Evidence, blockers and exclusions

Attach candidate relation/provenance report, duplicate and unresolved results, and publication-gate evidence. Block on unsupported relation fields, incomplete sources, or unresolved IDs. New storage, unbounded traversal, scoring, and external MCP execution are excluded.

## Relation ownership

This ticket owns the MCP-node facts and evidence aggregation/read adapter. Agent USES_MCP emission is owned by AGT-03 and Skill ALLOWS_MCP emission by SKL-04. Reuse those source-declaration facts; do not reparse their declarations or emit a second relationship implementation. If the approved MCP source contains no independently declared outbound relation, do not invent one to fill this ticket; demonstrate MCP facts, inbound evidence and unresolved references through the common read contract.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [MCP-02](MCP-02.md) must finish its stated contract boundary before this task starts.
- [MCP-03](MCP-03.md) must finish its stated contract boundary before this task starts.
- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.
- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [SKL-04](SKL-04.md) must finish its stated contract boundary before this task starts.
- [AGT-03](AGT-03.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `model`, `identity`, `ingestion`, `publication`, `read-contract`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
