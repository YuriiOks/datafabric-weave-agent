"""Value types the sweep returns and consumes.

The report types are immutable; the sweep targets and policies are frozen dataclasses.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import StrEnum
from typing import Annotated

from pydantic import AwareDatetime, Field

from kp.domain import ApprovalState, ItemKey, RunOutcome, SourceKind
from kp.domain.base import DomainModel
from kp.sources.base import SourceReader


@dataclass(frozen=True)
class SweepTarget:
    """One reader to sweep and the scope its cursor is saved under.

    :ivar reader: The source reader (a fake in tests)
    :ivar scope: Narrows the source (a project, a repository); ``""`` for none
    """

    reader: SourceReader
    scope: str = ""


@dataclass(frozen=True)
class RateLimitPolicy:
    """How long the sweep is willing to wait when a source asks it to slow down.

    :ivar max_waits: How many consecutive waits one call may take before the sweep defers
    :ivar max_wait_seconds: A single requested wait longer than this defers at once
    """

    max_waits: int = 3
    max_wait_seconds: float = 300.0


class WorkReason(StrEnum):
    """Why an item version was handed to the content processor."""

    NEW = "new"
    CHANGED = "changed"


class WorkItem(DomainModel):
    """One admitted item version handed to the content processor."""

    key: ItemKey
    reason: WorkReason


class LoadedSpec(DomainModel):
    """A merged spec loaded back as knowledge.

    :ivar spec_key: The spec's natural key in the link store
    :ivar clause_refs: Canonical clause references the spec cites, in sorted order
    :ivar requirement_ids: Register rows the spec cites, by row id
    :ivar machine_authored: True when the merge carried the machine-authored mark
    :ivar triggers_draft: True only for a person's own first spec; machine-authored specs
        and later versions of a spec already loaded never ask for a new draft
    """

    key: ItemKey
    story_key: str
    spec_key: str
    clause_refs: tuple[str, ...]
    requirement_ids: tuple[str, ...] = ()
    machine_authored: bool
    triggers_draft: bool


class TargetStatus(StrEnum):
    """How sweeping one target ended."""

    COMPLETED = "completed"
    DEFERRED = "deferred"
    FAILED = "failed"


class AlertKind(StrEnum):
    """What an alert is about."""

    REPEATED_FETCH_FAILURES = "repeated_fetch_failures"


class Alert(DomainModel):
    """A source whose sweeps keep failing.

    :ivar kind: What the alert is about
    :ivar consecutive_failures: Failed sweeps in a row, as saved with the cursor
    """

    source: SourceKind
    scope: str = ""
    kind: AlertKind = AlertKind.REPEATED_FETCH_FAILURES
    consecutive_failures: Annotated[int, Field(ge=1)]
    last_attempt_at: AwareDatetime | None = None
    raised_at: AwareDatetime


class TargetSummary(DomainModel):
    """Outcome of sweeping one target in a run."""

    source: SourceKind
    scope: str = ""
    status: TargetStatus
    pages: int = 0
    error: str | None = None


class SweepSummary(DomainModel):
    """Everything one sweep run did.

    :ivar versions_recorded: New immutable item versions written
    :ivar state_changes: Approval changes to versions that already existed
    :ivar conflicts: Versions refused because the source offered different bytes for a key
    :ivar work_items: Versions handed to the content processor; empty when nothing changed
    """

    run_id: str
    outcome: RunOutcome
    targets: tuple[TargetSummary, ...] = ()
    versions_recorded: int = 0
    state_changes: int = 0
    conflicts: int = 0
    work_items: tuple[WorkItem, ...] = ()
    loaded_specs: tuple[LoadedSpec, ...] = ()
    alerts: tuple[Alert, ...] = ()


class SourceFreshness(DomainModel):
    """A source that has not been swept successfully recently enough."""

    source: SourceKind
    scope: str = ""
    last_success_at: AwareDatetime | None = None
    age_hours: float | None = None
    consecutive_failures: int = 0


class FreshnessReport(DomainModel):
    """Result of the freshness check: stale sources and raised alerts."""

    checked_at: AwareDatetime
    stale: tuple[SourceFreshness, ...] = ()
    alerts: tuple[Alert, ...] = ()

    @property
    def is_healthy(self) -> bool:
        """True when no source is stale and no alert is raised."""
        return not self.stale and not self.alerts


class CitationStatus(DomainModel):
    """What a citation of an item version resolves to.

    A withdrawn or superseded version still resolves: content is kept for history and the
    dates say since when it is no longer in use.
    """

    key: ItemKey
    approval_state: ApprovalState
    superseded_at: date | None = None
    withdrawn_at: date | None = None
