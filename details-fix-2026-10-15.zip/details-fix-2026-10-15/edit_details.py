"""Component page details: triggers as a Markdown list without markers or rules, a description
that the prompt opens with left to the definition, multi-line descriptions rendered, and no
second copy of the description under a missing definition.

Validates every anchor first and writes nothing unless all of them hold.
Run from the worktree root.
"""

import pathlib
import sys

ROOT = pathlib.Path.cwd()
BT = chr(96)
CP = "frontend/src/features/recsys/component-page/"

texts, created, errors, done = {}, {}, [], []


def get(path):
    if path not in texts:
        texts[path] = (ROOT / path).read_text(encoding="utf-8")
    return texts[path]


def bounds(text, start, end, label):
    if start is None:
        return 0, len(text)
    n = text.count(start)
    if n != 1:
        errors.append(f"{label}: scope start x{n}")
        return None, None
    lo = text.index(start)
    hi = text.find(end, lo + len(start)) if end else -1
    return lo, (len(text) if hi < 0 else hi)


def edit(path, old, new, label, start=None, end=None):
    text = get(path)
    lo, hi = bounds(text, start, end, label)
    if lo is None:
        return
    seg = text[lo:hi]
    n = seg.count(old)
    if n != 1:
        errors.append(f"{label}: x{n}")
        return
    texts[path] = text[:lo] + seg.replace(old, new.replace("@b@", BT)) + text[hi:]
    done.append(label)


def append(path, block, label):
    texts[path] = get(path).rstrip("\n") + "\n" + block.replace("@b@", BT).rstrip("\n") + "\n"
    done.append(label)


def create(path, content, label):
    if (ROOT / path).exists():
        errors.append(f"{label}: already exists")
        return
    created[path] = content.replace("@b@", BT).lstrip("\n")
    done.append(label)


L = CP + "ComponentDetailLayout.tsx"
V = CP + "MarkdownViewer.tsx"
M = CP + "markdown.ts"

CARET = chr(94)


def c(text):
    return text.replace("@c@", CARET).replace("@b@", BT)


MV = CP + "MarkdownViewer.tsx"
DC = CP + "DetailsCard.tsx"
LAY = CP + "ComponentDetailLayout.tsx"
TEST = CP + "ComponentDetailLayout.test.tsx"

# --- viewer: inline and short Markdown for the details ------------------------
edit(
    MV,
    "import { parseMarkdown, safeHref } from './markdown'\n",
    "import { parseInline, parseMarkdown, safeHref } from './markdown'\n",
    "viewer import",
)
append(
    MV,
    r"""
type SnippetProps = { markdown: string; idPrefix?: string | undefined }

/** One line of inline Markdown outside the definition, such as a trigger. */
export function InlineMarkdown({ source }: { source: string }) {
  return <>{renderInline(parseInline(source), 'inline')}</>
}

/**
 * A short Markdown text inside the details, such as a description: one paragraph reads as inline
 * text; anything longer keeps its lists and line breaks, with no title or contents list.
 */
export function MarkdownSnippet({ markdown, idPrefix = 'snippet' }: SnippetProps) {
  const blocks = useMemo(() => parseMarkdown(markdown, { lineBreaks: true }).blocks, [markdown])
  const only = blocks.length === 1 ? blocks[0] : undefined
  if (only?.kind === 'paragraph') return <>{renderInline(only.inline, idPrefix)}</>
  return <div style={snippetStyle}>{renderBlocks(blocks, idPrefix, 's')}</div>
}

// The last block's bottom margin would add a gap inside the row.
const snippetStyle: CSSProperties = { display: 'flow-root', marginBottom: 'calc(-1 * var(--space-3))' }
""",
    "viewer snippet",
)

# --- details card ------------------------------------------------------------
edit(
    DC,
    "import { hasFrontmatter } from './markdown'\n",
    "import { hasFrontmatter } from './markdown'\nimport { InlineMarkdown, MarkdownSnippet } from './MarkdownViewer'\n",
    "details import",
)
edit(
    DC,
    r"""  const triggers: ReactNode = model.triggers.length === 0 ? dash : model.triggers.join(' \u00b7 ')
""",
    r"""  const triggerLines = Array.from(new Set(model.triggers.map(cleanTrigger).filter((line) => line !== '')))
  const triggers: ReactNode =
    triggerLines.length === 0 ? (
      dash
    ) : (
      <ul style={triggerListStyle}>
        {triggerLines.map((line) => (
          <li key={line}>
            <InlineMarkdown source={line} />
          </li>
        ))}
      </ul>
    )
""",
    "details triggers",
)
edit(
    DC,
    "  const description: Row = ['Description', model.description ?? dash, !model.description]\n",
    """  const description: Row = [
    'Description',
    model.description ? <MarkdownSnippet markdown={model.description} idPrefix="description" /> : dash,
    !model.description,
  ]
""",
    "details description",
)
edit(
    DC,
    "  const triggersRow: Row = ['Triggers', triggers, model.triggers.length === 0]\n",
    "  const triggersRow: Row = ['Triggers', triggers, triggerLines.length === 0]\n",
    "details triggers row",
)
edit(
    DC,
    """  const detailsRows: Row[] = showsSummary
    ? [triggersRow, ...howItRuns]
    : [description, triggersRow, tools, tags, ...howItRuns]
""",
    """  // An agent whose description is its whole prompt would show the same text twice.
  const repeatsDefinition =
    !!model.definition && !!model.description && opensWith(model.definition.markdown, model.description)
  const detailsRows: Row[] = showsSummary
    ? [triggersRow, ...howItRuns]
    : [...(repeatsDefinition ? [] : [description]), triggersRow, tools, tags, ...howItRuns]
""",
    "details dedupe",
)
append(
    DC,
    c(
        r"""
const triggerListStyle: CSSProperties = {
  margin: 0,
  paddingLeft: 'var(--space-4)',
  listStyleType: 'disc',
  lineHeight: 1.5,
}

/** A line from a "When to use" section without its list marker; a horizontal rule is no trigger. */
function cleanTrigger(raw: string): string {
  const line = raw.trim()
  if (/@c@([-*_])(?:\s*\1){2,}$/.test(line)) return ''
  return line.replace(/@c@(?:[-*+]|\d+[.)])\s+/, '')
}

/** Whether a definition starts with the given text, ignoring spacing. */
function opensWith(definition: string, text: string): boolean {
  const flat = (value: string) => value.replace(/\s+/g, ' ').trim()
  const head = flat(text)
  return head.length > 0 && flat(definition).startsWith(head)
}
"""
    ),
    "details helpers",
)

# --- layout: the fallback no longer repeats the description -----------------
edit(
    LAY,
    """        <div style={emptyBoxStyle}>Full definition not available yet.</div>
        {model.description && (
          <p style={{ margin: 0, fontSize: 'var(--text-sm)', lineHeight: 1.6, color: 'var(--color-text-primary)' }}>
            {model.description}
          </p>
        )}
""",
    """        <div style={emptyBoxStyle}>Full definition not available yet.</div>
""",
    "layout fallback",
)

# --- tests ---------------------------------------------------------------------
edit(
    TEST,
    """  it('falls back to the description when the full definition is not available', () => {
    setWide(true)
    renderPage(makeModel())
    expect(screen.getByText('Full definition not available yet.')).toBeInTheDocument()
    expect(screen.getAllByText('Classifies a ticket into a queue and drafts a first reply.').length).toBeGreaterThan(0)
  })
""",
    """  it('says the full definition is not available and shows the description once, in the details', () => {
    setWide(true)
    renderPage(makeModel())
    expect(screen.getByText('Full definition not available yet.')).toBeInTheDocument()
    const details = screen.getByRole('region', { name: 'Details' })
    expect(within(details).getByText('Classifies a ticket into a queue and drafts a first reply.')).toBeInTheDocument()
    expect(screen.getAllByText('Classifies a ticket into a queue and drafts a first reply.')).toHaveLength(1)
  })
""",
    "test fallback",
)
edit(
    TEST,
    "  it('keeps the line breaks of an agent prompt', () => {\n",
    c(
        """  it('drops a description that the prompt opens with', () => {
    setWide(true)
    renderPage(
      makeModel({
        type: 'agent',
        description: 'You triage inbound tickets.',
        definition: { markdown: 'You triage   inbound tickets.\\nAlways answer in plain words.', path: null },
      }),
    )
    const details = screen.getByRole('region', { name: 'Details' })
    expect(within(details).queryByText('Description')).toBeNull()
    expect(within(details).getByText('Tools')).toBeInTheDocument()
  })

  it('lists the triggers as Markdown without list markers or rules', () => {
    setWide(true)
    renderPage(makeModel({ triggers: ['- Use **when** a ticket arrives', '---', '@b@triage@b@ requests', '* * *'] }))
    const details = screen.getByRole('region', { name: 'Details' })
    expect(within(details).getByText('when').tagName).toBe('STRONG')
    expect(within(details).getByText('triage').tagName).toBe('CODE')
    expect(within(details).queryByText('---')).toBeNull()
    expect(within(details).queryByText('* * *')).toBeNull()
    const items = within(details).getAllByRole('listitem')
    expect(items).toHaveLength(2)
    expect(items[0]?.textContent).toBe('Use when a ticket arrives')
  })

  it('renders a description that is a list', () => {
    setWide(true)
    renderPage(makeModel({ description: 'Helps with:\\n- triage\\n- replies' }))
    const details = screen.getByRole('region', { name: 'Details' })
    expect(within(details).getByText('replies').tagName).toBe('LI')
    expect(within(details).queryByText(/- replies/)).toBeNull()
  })

  it('keeps the line breaks of an agent prompt', () => {
"""
    ),
    "test details",
)

if errors:
    print("NOTHING WRITTEN")
    for line in errors:
        print("FAIL", line)
    sys.exit(1)
for path, text in texts.items():
    (ROOT / path).write_text(text, encoding="utf-8")
for path, text in created.items():
    (ROOT / path).write_text(text, encoding="utf-8")
print(f"OK {len(done)} edits, {len(texts)} files changed, {len(created)} created")
