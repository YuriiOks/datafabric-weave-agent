"""The coverage port: coverage of the rules in force, filtered by domain."""

from __future__ import annotations

from datetime import date

import pytest

from kp.adapters.coverage_port import LinkServiceCoveragePort
from kp.tools import NoEditionInForceError
from world_support import World


def _port(world: World) -> LinkServiceCoveragePort:
    return LinkServiceCoveragePort(
        world.application.database, world.application.clock, world.settings.thresholds
    )


def test_every_rule_in_force_is_listed_for_a_caller_with_the_domain(built_world: World) -> None:
    snapshot = _port(built_world).snapshot(
        domains=frozenset({"payments"}), as_at=date(2026, 11, 20)
    )

    assert len(snapshot.rules) == 27
    # Only 4.2.1 reaches a test: clause, the spec a person merged, its code and the code's test.
    assert [rule.reference for rule in snapshot.rules if rule.has_test] == ["2026.1:4.2.1"]
    assert snapshot.filtered_out >= 0
    assert {rule.domain for rule in snapshot.rules} == {"payments"}


def test_a_caller_with_another_domain_gets_no_rules_and_a_count_of_what_was_hidden(
    built_world: World,
) -> None:
    snapshot = _port(built_world).snapshot(domains=frozenset({"cards"}), as_at=date(2026, 11, 20))

    assert snapshot.rules == ()
    assert snapshot.filtered_out >= 27


def test_the_rules_are_those_of_the_edition_in_force_on_the_date(built_world: World) -> None:
    snapshot = _port(built_world).snapshot(
        domains=frozenset({"payments"}), as_at=date(2026, 11, 15)
    )

    assert snapshot.rules
    assert all(rule.reference.startswith("2025.2:") for rule in snapshot.rules)


def test_a_date_before_any_edition_is_a_typed_error(built_world: World) -> None:
    with pytest.raises(NoEditionInForceError):
        _port(built_world).snapshot(domains=frozenset({"payments"}), as_at=date(2020, 1, 1))
