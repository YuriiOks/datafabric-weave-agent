"""The write port: write-back tools served through the agent tools' types."""

from __future__ import annotations

import pytest
from pydantic import JsonValue

from kp.errors import WriteNotPermittedError
from kp.tools import WriteToolCall
from world_support import World

CALLER = {"caller": "user-full-access", "agent": "test-agent", "session_id": "sess-1"}


def test_the_two_write_tools_are_described_with_their_schemas(built_world: World) -> None:
    descriptors = built_world.application.write_port().describe()

    assert [item.name for item in descriptors] == ["publish_spec", "update_jira"]
    assert all(item.input_schema for item in descriptors)


def test_an_unknown_tool_is_a_value_error(built_world: World) -> None:
    port = built_world.application.write_port()

    with pytest.raises(ValueError, match="Unknown write tool"):
        port.invoke(WriteToolCall(tool="drop_table", arguments={}, domains=("payments",), **CALLER))


def test_a_write_for_another_repository_is_refused(built_world: World) -> None:
    port = built_world.application.write_port()
    arguments: dict[str, JsonValue] = {
        "story_key": "PAY-101",
        "spec_markdown": "# x",
        "template_id": "functional-spec",
        "template_version": "1.0.0",
        "repository": "other-owner/other-repository",
    }

    with pytest.raises(WriteNotPermittedError):
        port.invoke(
            WriteToolCall(tool="publish_spec", arguments=arguments, domains=("payments",), **CALLER)
        )
