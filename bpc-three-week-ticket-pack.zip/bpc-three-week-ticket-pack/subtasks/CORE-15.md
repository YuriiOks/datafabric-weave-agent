---
pack_id: "bpc-sep26-v1"
local_id: "CORE-15"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Integrate the complete source set with refresh publication and status"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 3
scope: "foundation"
create_by_default: true
planned_start: "2026-09-24"
planned_due: "2026-09-24"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-04","CORE-05","CORE-13","SKL-04","MCP-04","AGT-03","CORE-06"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-15"
architecture_sections: ["source-refresh","ingestion","publication","read-contract"]
---

# Integrate the complete source set with refresh publication and status

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-15** is not a Jira key.
- Estimate: **3 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-24 → 2026-09-24 (D12–D12)**.
- Recommendation extension: **2026-09-28 → 2026-09-28 (D14–D14)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Connect the job framework to real acquisition, type adapters, complete catalogue assembly, projection and status. The release test ticket must receive an integrated implementation, not be expected to build missing orchestration.

## Scope and implementation steps

1. Register CORE-13 acquisition and all SKL/MCP/AGT adapters against the immutable complete-source-set manifest and version vector.
2. Assemble one canonical identity catalogue before resolving cross-type references. MCP identity results feed Skill allowances; Skill/MCP identities feed Agent declarations. Unresolved references remain diagnostics, never guessed joins.
3. Reconcile all required row/reference outcomes, source completeness/freshness and monotonic collection ordering. No missing required source can silently reuse a stale source under a new capture timestamp.
4. Pass the complete candidate to CORE-04 sealing/activation only after current operator/source policy and expected-base/vector checks. Preserve the uncertain-writer abandonment contract.
5. Connect CORE-06 to the real durable status/refresh operation. Fetched, validated, sealed and activated outcomes stay separate. Enable only in an approved scope after qualification; unsupported dependencies keep the control disabled.

## Acceptance criteria

- [ ] One real authorised job uses the registered sources and all three type adapters to assemble one internally consistent candidate.
- [ ] Cross-type edges resolve only through the canonical target identity set and retain source evidence.
- [ ] A missing, failed, incomplete or too-old required source prevents activation and cannot imply deletion by absence.
- [ ] Older/ambiguous collection versions cannot restore retired facts or overwrite a newer active source vector.
- [ ] The live UI/status/reader returns the actually active publication and truthful stage outcomes; job-framework mocks cannot satisfy acceptance.

## Verification and evidence

Run the approved thin real source-to-publication-to-read integration, including missing target, older collection, failed source, revoked initiating operator and job retry. Attach manifest/vector, graph/read reconciliation, real status trace and CI/run reference. Full fault/load/quality coverage follows in CORE-09.

## Estimate and integration map

Three hours is the remaining integration portion of the original eight-hour refresh adaptation allowance; CORE-05 owns five framework hours. This estimate requires reusable source/graph/job interfaces proven in G0. Record exact mapped files from CORE-01. Missing platform capability blocks this task and forces replan, not implementation inside the release-check ticket.

## Exclusions

New auth or worker platform, source parsers duplicated here, a replacement database, unapproved scheduling and a recommendation engine.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [CORE-05](CORE-05.md) must finish its stated contract boundary before this task starts.
- [CORE-13](CORE-13.md) must finish its stated contract boundary before this task starts.
- [SKL-04](SKL-04.md) must finish its stated contract boundary before this task starts.
- [MCP-04](MCP-04.md) must finish its stated contract boundary before this task starts.
- [AGT-03](AGT-03.md) must finish its stated contract boundary before this task starts.
- [CORE-06](CORE-06.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `source-refresh`, `ingestion`, `publication`, `read-contract`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
