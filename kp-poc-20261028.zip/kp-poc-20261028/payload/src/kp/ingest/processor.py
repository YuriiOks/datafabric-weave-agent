"""The content-processing entry point for every admitted item version.

:class:`ContentProcessor` is this package's own port. The sweep has a different one
(``fingerprint`` and ``process(connection, version, content)``); the adapter in
:mod:`kp.ingest.sweep_adapter` implements it on top of :class:`IngestProcessor`, which turns
the version into clauses, requirements or stories and stores them:

========================================  =========================================
item                                      becomes
========================================  =========================================
regulatory repository PDF or Markdown     clauses (and the edition row if absent)
spreadsheet                               one requirement per register data row
tracker JSON (export or single issue)     stories, with a change verdict for each
anything else                             nothing (``NOT_APPLICABLE``); there is no
                                          general-purpose fallback
========================================  =========================================

The edition a rulebook is stored under is the one its reviewed source item carries; a
document that states another edition is held for review, never stored under either label.

Only the ``PROCEED`` structure decision stores clauses. ``REVIEW`` and ``BLOCK`` store
nothing and raise a review item. The review band is stored once that item is resolved by a
person (the next call for the same version then loads it); ``BLOCK`` never loads. Every call
is idempotent for an item version. The approval gate (``kp.sweep``) decides which versions
are admitted and raises the missing-detail and unknown-type questions; this package only
processes admitted versions.
"""

from __future__ import annotations

import logging
from enum import StrEnum
from typing import Protocol, runtime_checkable

from sqlalchemy import Connection

from kp.clock import Clock
from kp.config import Thresholds
from kp.domain import (
    ApprovalState,
    ItemKey,
    ReviewItem,
    ReviewState,
    SourceItemVersion,
    SourceKind,
)
from kp.domain.base import DomainModel
from kp.ingest.errors import MissingEffectiveDateError
from kp.ingest.models import ParsedRegister, ParsedRulebook, StructureDecision
from kp.ingest.register import parse_register
from kp.ingest.repository import (
    ClauseStore,
    EditionStore,
    RequirementStore,
    ReviewStore,
    StoryChange,
    StoryStore,
)
from kp.ingest.reviews import (
    ReviewContext,
    register_header_review,
    structure_review,
    structure_review_id,
)
from kp.ingest.rulebook import parse_rulebook_markdown, parse_rulebook_pdf
from kp.ingest.stories import parse_story_export
from kp.sources.base import FetchedItem

logger = logging.getLogger(__name__)

_PDF = "application/pdf"
_MARKDOWN = "text/markdown"
_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
_JSON = "application/json"


class ProcessingOutcome(StrEnum):
    """What happened to an item version."""

    PROCESSED = "processed"
    HELD_FOR_REVIEW = "held_for_review"
    BLOCKED = "blocked"
    NOT_APPLICABLE = "not_applicable"
    NOT_ADMITTED = "not_admitted"


class ProcessingResult(DomainModel):
    """Counts and verdicts for one processed item version.

    :ivar clauses_stored: Clauses inserted by this call (0 on a re-run).
    :ivar requirements_stored: Requirements inserted by this call.
    :ivar stories_new: Keys of stories seen for the first time.
    :ivar stories_changed: Keys whose fingerprint changed; these need reprocessing.
    :ivar stories_unchanged: Keys with an unchanged fingerprint (status moves, re-exports).
    :ivar review_ids: Ids of review items created by this call.
    :ivar detail: A short statement of why nothing was stored, when nothing was.
    """

    key: ItemKey
    outcome: ProcessingOutcome
    clauses_stored: int = 0
    requirements_stored: int = 0
    stories_new: tuple[str, ...] = ()
    stories_changed: tuple[str, ...] = ()
    stories_unchanged: tuple[str, ...] = ()
    review_ids: tuple[str, ...] = ()
    detail: str = ""

    @property
    def stories_to_reprocess(self) -> tuple[str, ...]:
        """Keys of stories whose downstream work must be redone."""
        return (*self.stories_new, *self.stories_changed)


@runtime_checkable
class ContentProcessor(Protocol):
    """Turns one admitted item version into stored content."""

    def process(
        self, item: SourceItemVersion, fetched: FetchedItem, connection: Connection
    ) -> ProcessingResult:
        """Process one item version.

        :param item: The stored version, with its approval state and dates
        :param fetched: The version's raw content
        :param connection: Open connection inside the caller's transaction
        :return: What was stored and what needs a person
        :raises kp.ingest.errors.IngestError: If the content is unreadable
        """
        ...


class IngestProcessor:
    """The ingest implementation of :class:`ContentProcessor`.

    :param thresholds: Structure and header-confidence thresholds from settings
    :param clock: Time source for review items
    :param accept_review_band: Store every rulebook whose structure score is in the review
        band without waiting for a person. A local-mode override; by default only a review
        item resolved by a person releases an edition held in that band.
    """

    def __init__(
        self, thresholds: Thresholds, clock: Clock, *, accept_review_band: bool = False
    ) -> None:
        self._thresholds = thresholds
        self._clock = clock
        self._accept_review_band = accept_review_band

    def process(
        self, item: SourceItemVersion, fetched: FetchedItem, connection: Connection
    ) -> ProcessingResult:
        """Process one item version (see the module description).

        :param item: The stored version; only ``ADMITTED`` versions are processed
        :param fetched: The version's raw content
        :param connection: Open connection inside the caller's transaction
        :return: What was stored and what needs a person
        :raises kp.ingest.errors.IngestError: If the content is unreadable
        :raises kp.ingest.errors.MissingEffectiveDateError: If an edition row must be created
            and neither the item nor the document gives an effective date
        """
        if item.approval_state is not ApprovalState.ADMITTED:
            return ProcessingResult(
                key=item.key, outcome=ProcessingOutcome.NOT_ADMITTED, detail="not admitted"
            )
        media_type = item.media_type.split(";")[0].strip().casefold()
        context = ReviewContext(item.key, item.run_id, self._clock.now())
        if item.source is SourceKind.REGULATORY_REPO and media_type in (_PDF, _MARKDOWN):
            result = self._rulebook(item, fetched.content, media_type, context, connection)
        elif media_type == _XLSX:
            result = self._register(item, fetched.content, context, connection)
        elif item.source is SourceKind.JIRA and media_type == _JSON:
            result = self._stories(item, fetched.content, connection)
        else:
            result = ProcessingResult(
                key=item.key,
                outcome=ProcessingOutcome.NOT_APPLICABLE,
                detail="no parser for this source and media type",
            )
        logger.info(
            "Item processed",
            extra={
                "source": item.source.value,
                "item_id": item.item_id,
                "version": item.version,
                "outcome": result.outcome.value,
            },
        )
        return result

    def _rulebook(
        self,
        item: SourceItemVersion,
        content: bytes,
        media_type: str,
        context: ReviewContext,
        connection: Connection,
    ) -> ProcessingResult:
        parse = parse_rulebook_pdf if media_type == _PDF else parse_rulebook_markdown
        parsed = parse(content, default_edition=item.version, thresholds=self._thresholds)
        if not self._may_store(item.key, parsed, connection):
            created = _add_reviews(connection, [structure_review(parsed, context)])
            outcome = (
                ProcessingOutcome.BLOCKED
                if parsed.decision is StructureDecision.BLOCK
                else ProcessingOutcome.HELD_FOR_REVIEW
            )
            return ProcessingResult(
                key=item.key,
                outcome=outcome,
                review_ids=created,
                detail=f"structure score {parsed.structure_score:.2f}",
            )
        self._ensure_edition(item, parsed, connection)
        stored = ClauseStore(connection).save(parsed.clauses)
        return ProcessingResult(
            key=item.key, outcome=ProcessingOutcome.PROCESSED, clauses_stored=stored
        )

    def _may_store(self, key: ItemKey, parsed: ParsedRulebook, connection: Connection) -> bool:
        if parsed.decision is StructureDecision.PROCEED:
            return True
        if parsed.decision is not StructureDecision.REVIEW:
            return False
        if self._accept_review_band:
            return True
        review = ReviewStore(connection).get(structure_review_id(key))
        return review is not None and review.state is ReviewState.RESOLVED

    @staticmethod
    def _ensure_edition(
        item: SourceItemVersion, parsed: ParsedRulebook, connection: Connection
    ) -> None:
        effective = item.effective_date or parsed.declared_effective_date
        if effective is None:
            raise MissingEffectiveDateError("Neither the item nor the rulebook gives a date")
        EditionStore(connection).ensure(parsed.edition, effective, item.key, item.title)

    def _register(
        self,
        item: SourceItemVersion,
        content: bytes,
        context: ReviewContext,
        connection: Connection,
    ) -> ProcessingResult:
        parsed: ParsedRegister = parse_register(
            content,
            key=item.key,
            thresholds=self._thresholds,
            default_domain=item.details.domain,
        )
        unreadable = tuple(sheet.sheet for sheet in parsed.sheets if sheet.header_row is None)
        stored = RequirementStore(connection).replace_for_item(
            item.key, parsed.requirements, keep_sheets=unreadable
        )
        created = _add_reviews(
            connection,
            [
                register_header_review(sheet, self._thresholds, context)
                for sheet in parsed.refused_sheets
            ],
        )
        held = bool(parsed.refused_sheets) and not parsed.requirements
        return ProcessingResult(
            key=item.key,
            outcome=ProcessingOutcome.HELD_FOR_REVIEW if held else ProcessingOutcome.PROCESSED,
            requirements_stored=stored,
            review_ids=created,
        )

    @staticmethod
    def _stories(
        item: SourceItemVersion, content: bytes, connection: Connection
    ) -> ProcessingResult:
        store = StoryStore(connection)
        verdicts: dict[StoryChange, list[str]] = {change: [] for change in StoryChange}
        for parsed in parse_story_export(content, default_version=item.version):
            story = (
                parsed
                if parsed.domain
                else parsed.model_copy(update={"domain": item.details.domain})
            )
            verdicts[store.save(story)].append(story.story_key)
        return ProcessingResult(
            key=item.key,
            outcome=ProcessingOutcome.PROCESSED,
            stories_new=tuple(verdicts[StoryChange.NEW]),
            stories_changed=tuple(verdicts[StoryChange.CHANGED]),
            stories_unchanged=tuple(verdicts[StoryChange.UNCHANGED]),
        )


def _add_reviews(connection: Connection, items: list[ReviewItem]) -> tuple[str, ...]:
    store = ReviewStore(connection)
    return tuple(item.review_id for item in items if store.add(item))
