"""US-19 / US-20 / US-21 / US-22 through the publishing and Jira services."""

from __future__ import annotations

from datetime import date

import pytest
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from kp.domain import SpecState, Story
from kp.errors import TemplateNotFoundError, WriteNotPermittedError
from kp.store import Database
from kp.store.schema import citation, edition, spec
from kp.writeback import (
    DraftRequest,
    EvidenceItem,
    JiraTransientError,
    JiraUpdateError,
    PublishSpecArguments,
    Retrieval,
    SpecNotDraftableError,
    SpecNotDraftedError,
    SpecNotFoundError,
    SpecRepository,
    StoryDomainNotPermittedError,
    StoryNotFoundError,
    TemplateDrafter,
    UpdateJiraArguments,
)
from writeback.writeback_support import (
    DOMAINS,
    GOOD_SPEC,
    NOW,
    RETRIEVED,
    Seeded,
    Writers,
    add_story,
)


def arguments(**overrides: object) -> PublishSpecArguments:
    values: dict[str, object] = {
        "story_key": "PAY-101",
        "spec_markdown": GOOD_SPEC,
        "template_id": "functional-spec",
        "template_version": "1.0.0",
        "coverage": {"rules_without_test": ["2026.1:4.2.3"]},
        "open_items": ("Confirm the timeout.",),
    }
    values.update(overrides)
    return PublishSpecArguments.model_validate(values)


def test_us19_publish_stores_the_spec_with_template_version_coverage_and_open_items(
    writers: Writers, database: Database
) -> None:
    outcome = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    with database.transaction() as connection:
        stored = SpecRepository(connection).get_by_story("PAY-101")
        stored_citations = SpecRepository(connection).citations("spec-pay-101")
    assert stored == outcome.spec
    assert stored is not None
    assert (stored.template_id, stored.template_version) == ("functional-spec", "1.0.0")
    assert (stored.branch, stored.path) == ("spec/pay-101", "specs/PAY-101.md")
    assert (stored.state, stored.machine_authored, stored.created_at) == (
        SpecState.DRAFTED,
        True,
        NOW,
    )
    assert stored.pr_identity == "local-pr:1"
    assert stored.open_items == ("Confirm the timeout.",)
    assert stored.coverage["rules_without_test"] == ["2026.1:4.2.3"]
    assert stored.coverage["citations"] == {
        "rule_statements": 2,
        "valid": 2,
        "flagged": 0,
        "rate": 1.0,
        "target": 0.95,
    }
    assert [c.is_valid for c in stored_citations] == [True, True]


def test_us19_the_pull_request_carries_spec_template_version_citations_coverage_open_items(
    writers: Writers,
) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    (request,) = writers.publisher.requests
    assert request.content.startswith("---\nstory: PAY-101\nspec: spec-pay-101\n")
    assert "template: functional-spec@1.0.0" in request.content
    assert "machine_authored: true" in request.content
    assert "## Rules" in request.content
    assert "Machine-Authored: true" in request.commit_message
    assert "`functional-spec` version `1.0.0`" in request.pr_body
    assert "Citation rate: 100% (meets the 95% target)" in request.pr_body
    assert "rules_without_test" in request.pr_body
    assert "- Confirm the timeout." in request.pr_body
    assert request.pr_title == "[PAY-101] Acknowledge received credit transfers"


def test_us19_same_draft_published_twice_yields_no_second_pull_request(
    writers: Writers, database: Database
) -> None:
    first = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    second = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    assert first.result.created
    assert not second.result.created
    assert second.result.pr_url == first.result.pr_url
    assert writers.publisher.pull_requests == {"spec/pay-101": 1}
    with database.transaction() as connection:
        assert connection.execute(select(func.count()).select_from(spec)).scalar() == 1
        assert connection.execute(select(func.count()).select_from(citation)).scalar() == 2
    assert second.spec.created_at == first.spec.created_at


def test_us19_a_revised_draft_goes_to_the_same_branch_and_pull_request(writers: Writers) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    revised = GOOD_SPEC.replace("within five seconds", "promptly")

    second = writers.publishing.publish(
        arguments(spec_markdown=revised), retrieved=RETRIEVED, domains=DOMAINS
    )

    assert (second.result.created, second.result.committed) == (False, True)
    assert writers.publisher.pull_requests == {"spec/pay-101": 1}


def test_us22_the_spec_is_never_committed_to_the_main_branch(writers: Writers) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    writers.publishing.publish(arguments(story_key="PAY-102"), retrieved=RETRIEVED, domains=DOMAINS)

    assert {request.branch for request in writers.publisher.requests} == {
        "spec/pay-101",
        "spec/pay-102",
    }
    assert all(request.branch != "main" for request in writers.publisher.requests)


def test_us19_a_template_version_that_is_not_governed_is_an_error_not_a_fallback(
    writers: Writers,
) -> None:
    with pytest.raises(TemplateNotFoundError):
        writers.publishing.publish(
            arguments(template_version="9.9.9"), retrieved=RETRIEVED, domains=DOMAINS
        )

    assert writers.publisher.requests == []


def test_us19_a_merged_spec_is_not_redrafted(writers: Writers, database: Database) -> None:
    first = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    with database.transaction() as connection:
        SpecRepository(connection).save(
            first.spec.model_copy(update={"state": SpecState.MERGED, "merged_at": NOW}), ()
        )

    with pytest.raises(SpecNotDraftableError):
        writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    assert len(writers.publisher.requests) == 1


def test_us21_uncited_and_broken_statements_are_flagged_in_the_pull_request(
    writers: Writers,
) -> None:
    markdown = (
        "# Title\n\n## Rules\n\n"
        "- A cited rule [ref: 2026.1:4.1.2].\n"
        "- An uncited rule.\n"
        "- A broken rule [ref: 2026.1:9.9.9].\n"
        "- An unretrieved rule [ref: 2026.1:4.2.1].\n"
    )

    outcome = writers.publishing.publish(
        arguments(spec_markdown=markdown), retrieved=RETRIEVED | {"2026.1:9.9.9"}, domains=DOMAINS
    )

    body = writers.publisher.requests[0].pr_body
    assert (outcome.report.rule_statements, outcome.report.valid_statements) == (4, 1)
    assert "Citation rate: 25% (is below the 95% target)" in body
    assert "| 1 | An uncited rule. | no citation |" in body
    assert "does not resolve: 2026.1:9.9.9" in body
    assert "not retrieved in this session: 2026.1:4.2.1" in body
    assert "A cited rule" not in body.split("### Flagged statements")[1]


def test_us21_a_proposed_item_is_marked_in_the_committed_text_and_listed_as_open(
    writers: Writers, seeded: Seeded
) -> None:
    story = Story(story_key="PAY-101", version="v1", summary="Acknowledge transfers")
    proposed = EvidenceItem(
        reference="2026.1:4.1.2",
        text="A participant shall acknowledge every received credit transfer.",
        proposed=True,
    )
    drafted = TemplateDrafter().draft(
        DraftRequest(
            story=story, template=seeded.template, retrieval=Retrieval(evidence=(proposed,))
        )
    )

    outcome = writers.publishing.publish(
        arguments(
            spec_markdown=drafted.markdown,
            coverage=drafted.coverage,
            open_items=drafted.open_items,
        ),
        retrieved=RETRIEVED,
        domains=DOMAINS,
    )

    (request,) = writers.publisher.requests
    assert "[ref: 2026.1:4.1.2] (proposed link)." in request.content
    assert "Confirm the proposed link to 2026.1:4.1.2." in request.pr_body
    assert outcome.report.flagged == ()


@pytest.mark.parametrize(
    "override",
    [
        {"repository": "other-org/other-repo"},
        {"path": "elsewhere/PAY-101.md"},
        {"branch": "main"},
    ],
)
def test_us22_another_repository_path_or_branch_is_refused_and_nothing_is_written(
    writers: Writers, database: Database, override: dict[str, str]
) -> None:
    with pytest.raises(WriteNotPermittedError):
        writers.publishing.publish(arguments(**override), retrieved=RETRIEVED, domains=DOMAINS)

    assert writers.publisher.requests == []
    with database.transaction() as connection:
        assert connection.execute(select(func.count()).select_from(spec)).scalar() == 0


def test_us20_pr_created_story_moves_to_spec_drafted_and_links_the_pr(writers: Writers) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    outcome = writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)

    (update,) = writers.jira.updates
    assert update == outcome.update
    assert (update.status, update.link_field, update.link_value) == (
        "Spec drafted",
        "spec_link",
        "local-pr:1",
    )
    assert outcome.attempts == 1


def test_us20_jira_failure_is_retried_on_its_own_and_the_pr_is_not_created_again(
    writers: Writers,
) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    writers.jira.failures = [JiraTransientError("down"), JiraTransientError("down")]

    outcome = writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)

    assert outcome.attempts == 3
    assert len(writers.jira.updates) == 3
    assert writers.sleeps == [1.0, 2.0]
    assert len(writers.publisher.requests) == 1
    assert writers.publisher.pull_requests == {"spec/pay-101": 1}


def test_us20_after_retries_are_exhausted_a_later_call_retries_without_a_new_pr(
    writers: Writers,
) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    writers.jira.failures = [JiraTransientError("down")] * 3

    with pytest.raises(JiraTransientError):
        writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)
    outcome = writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)

    assert (len(writers.jira.updates), outcome.attempts) == (4, 1)
    assert len(writers.publisher.requests) == 1


def test_us20_a_refusal_by_jira_is_not_retried(writers: Writers) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    writers.jira.failures = [JiraUpdateError("no")]

    with pytest.raises(JiraUpdateError):
        writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)

    assert len(writers.jira.updates) == 1
    assert writers.sleeps == []


def test_us20_a_story_without_a_published_spec_has_nothing_to_link(writers: Writers) -> None:
    with pytest.raises(SpecNotFoundError):
        writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)

    assert writers.jira.updates == []


@pytest.mark.parametrize(
    "fields",
    [{"priority": "High"}, {"status": "Done"}, {"spec_link": "somewhere-else"}],
)
def test_us22_another_jira_field_or_value_is_refused_and_nothing_is_written(
    writers: Writers, fields: dict[str, str]
) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    with pytest.raises(WriteNotPermittedError):
        writers.sync.update(
            UpdateJiraArguments(story_key="PAY-101", fields=fields), domains=DOMAINS
        )

    assert writers.jira.updates == []


def test_us22_the_agreed_fields_with_the_agreed_values_are_accepted(writers: Writers) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    writers.sync.update(
        UpdateJiraArguments(
            story_key="PAY-101", fields={"status": "Spec drafted", "spec_link": "local-pr:1"}
        ),
        domains=DOMAINS,
    )

    assert len(writers.jira.updates) == 1


def test_us22_a_field_request_is_refused_even_when_the_story_has_no_spec(
    writers: Writers, seeded: Seeded
) -> None:
    with pytest.raises(WriteNotPermittedError):
        writers.sync.update(
            UpdateJiraArguments(story_key="PAY-101", fields={"priority": "High"}), domains=DOMAINS
        )


def test_us22_publishing_for_an_unknown_story_is_refused_before_the_publisher_is_called(
    writers: Writers, database: Database
) -> None:
    with pytest.raises(StoryNotFoundError):
        writers.publishing.publish(
            arguments(story_key="PAY-404"), retrieved=RETRIEVED, domains=DOMAINS
        )

    assert writers.publisher.requests == []
    with database.transaction() as connection:
        assert connection.execute(select(func.count()).select_from(spec)).scalar() == 0


def test_us22_publishing_for_another_domain_is_refused_before_the_publisher_is_called(
    writers: Writers, database: Database
) -> None:
    add_story(database, "TRD-201", domain="trading")

    with pytest.raises(StoryDomainNotPermittedError):
        writers.publishing.publish(
            arguments(story_key="TRD-201"), retrieved=RETRIEVED, domains=DOMAINS
        )

    assert writers.publisher.requests == []


def test_us22_the_jira_update_checks_the_story_and_its_domain_before_anything_else(
    writers: Writers, database: Database
) -> None:
    add_story(database, "TRD-201", domain="trading")

    with pytest.raises(StoryNotFoundError):
        writers.sync.update(UpdateJiraArguments(story_key="PAY-404"), domains=DOMAINS)
    with pytest.raises(StoryDomainNotPermittedError):
        writers.sync.update(UpdateJiraArguments(story_key="TRD-201"), domains=DOMAINS)

    assert writers.jira.updates == []


@pytest.mark.parametrize("state", [SpecState.MERGED, SpecState.CLOSED])
def test_us20_a_merged_or_closed_spec_does_not_move_the_story_again(
    writers: Writers, database: Database, state: SpecState
) -> None:
    published = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)
    with database.transaction() as connection:
        SpecRepository(connection).save(
            published.spec.model_copy(update={"state": state, "merged_at": NOW}), ()
        )

    with pytest.raises(SpecNotDraftedError):
        writers.sync.update(UpdateJiraArguments(story_key="PAY-101"), domains=DOMAINS)

    assert writers.jira.updates == []


def test_us19_a_concurrent_first_publish_that_loses_the_insert_race_updates_the_row(
    writers: Writers, database: Database, monkeypatch: pytest.MonkeyPatch
) -> None:
    real_save = SpecRepository.save
    attempts: list[int] = []

    def losing_first_save(self: SpecRepository, saved: object, citations: object) -> None:
        attempts.append(1)
        if len(attempts) == 1:
            raise IntegrityError("insert into spec", {}, Exception("duplicate key"))
        real_save(self, saved, citations)  # type: ignore[arg-type]  # forwarded as received

    monkeypatch.setattr(SpecRepository, "save", losing_first_save)

    outcome = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    assert len(attempts) == 2
    with database.transaction() as connection:
        assert SpecRepository(connection).get_by_story("PAY-101") == outcome.spec
        assert connection.execute(select(func.count()).select_from(citation)).scalar() == 2


def test_us19_saving_a_spec_twice_updates_in_place_without_a_second_row(
    writers: Writers, database: Database
) -> None:
    first = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    with database.transaction() as connection:
        SpecRepository(connection).save(first.spec, ())
        SpecRepository(connection).save(first.spec, ())
        assert connection.execute(select(func.count()).select_from(spec)).scalar() == 1


def test_us04_the_pull_request_says_since_when_a_cited_clause_is_withdrawn(
    writers: Writers, database: Database
) -> None:
    with database.transaction() as connection:
        connection.execute(
            edition.update()
            .where(edition.c.label == "2026.1")
            .values(withdrawn_from=date(2027, 1, 1))
        )

    outcome = writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    (request,) = writers.publisher.requests
    assert outcome.report.flagged == ()  # a withdrawn clause still resolves
    assert "### Withdrawn material" in request.pr_body
    assert "2026.1:4.1.2 is in an edition withdrawn on 2027-01-01" in request.pr_body


def test_us04_a_spec_citing_only_clauses_in_use_has_no_withdrawn_section(
    writers: Writers,
) -> None:
    writers.publishing.publish(arguments(), retrieved=RETRIEVED, domains=DOMAINS)

    (request,) = writers.publisher.requests
    assert "Withdrawn material" not in request.pr_body
