"""MCP over standard input and output: one JSON-RPC message per line.

Standard output carries protocol messages only; logging goes to standard error.
"""

from __future__ import annotations

from typing import TextIO

from kp.mcp.jsonrpc import encode
from kp.mcp.server import McpServer
from kp.tools import Caller


def serve_stdio(server: McpServer, caller: Caller, stdin: TextIO, stdout: TextIO) -> None:
    """Serve messages until the input ends.

    The caller is fixed for the life of the process: it comes from the environment, never from
    a message.

    :param server: The MCP server
    :param caller: The caller asserted for this process
    :param stdin: Where messages are read from, one per line
    :param stdout: Where responses are written, one per line
    """
    for line in stdin:
        text = line.strip()
        if not text:
            continue
        response = server.handle_text(text, caller)
        if response is not None:
            stdout.write(encode(response) + "\n")
            stdout.flush()
