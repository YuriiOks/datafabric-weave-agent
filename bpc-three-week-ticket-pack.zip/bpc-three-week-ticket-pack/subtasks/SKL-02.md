---
pack_id: "bpc-sep26-v1"
local_id: "SKL-02"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1169"
summary: "Parse Skill definitions into lossless source occurrences and quality diagnostics"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-14"
planned_due: "2026-09-14"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["SKL-01","CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-skl-02"
architecture_sections: ["model","ingestion","source-refresh","validation-gates"]
---

# Parse Skill definitions into lossless source occurrences and quality diagnostics

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1169**. Local reference **SKL-02** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-14 → 2026-09-14 (D4–D4)**.
- Recommendation extension: **2026-09-14 → 2026-09-14 (D4–D4)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

Skill definitions have flexible YAML front matter, optional metadata in more than one location and known malformed examples. Parse them into the shared source-occurrence and field-claim contracts without discarding evidence or inventing a preferred value.

## Scope

Implement the Skills-source adapter against the logical interfaces approved in CORE-02 and map actual files only after SKL-01 identifies the checkout. Discover Skill documents recursively under the approved root, preserve source path and content hash, read front matter and body separately, and emit typed diagnostic records alongside parseable occurrences.

## Boundaries, inputs and outputs

Input is the verified Git snapshot and the shared source-contract DTOs. Outputs are lossless Skill source occurrences, field claims with source anchors, parse diagnostics, a source-quality summary and fixtures or examples for the shared ingestion validation. This task does not decide canonical IDs, repair malformed files, change marketplace content, resolve MCP names or attach suitability meaning to text.

## Technical steps

1. Implement the approved recursive discovery rule, excluding only directories proven non-Skill by SKL-01 evidence.
2. Parse YAML front matter when it is syntactically present; retain body text and raw front-matter evidence for every discovered document.
3. Map both top-level and nested metadata fields as independent claims, including name, description, version, ownership, category, visibility, dependencies, allowed MCP and tool declarations where present.
4. Classify diagnostics for absent or unclosed front matter, malformed YAML, absent required name or description, folder-name versus declared-name disagreement, duplicate declared names, mixed value shapes and conflicting duplicate claims.
5. Produce reviewable normalisation proposals for value-shape differences, but defer all precedence and canonicalisation decisions to CORE-02 and CORE-03.

## Acceptance criteria

- [ ] Every discovered Skill document has one source occurrence with snapshot identifier, source path, content hash and parse status.
- [ ] Parseable fields are represented as individually anchored source claims, preserving top-level versus nested provenance.
- [ ] Malformed or incomplete documents produce typed diagnostics and remain counted in source completeness; they are never silently skipped or repaired.
- [ ] The adapter records allowed-tools or tools as tool declarations and does not convert them into MCP-server relationships.
- [ ] The quality summary reconciles discovered documents, parse successes and every diagnostic class to the SKL-01 manifest denominator.

## Meaningful verification cases

- A valid definition with only name and description is admitted as a minimal occurrence.
- An unclosed front-matter delimiter and malformed YAML each produce distinct diagnostics with retained source anchors.
- A definition with metadata at both top level and nested metadata preserves both claims rather than choosing one.
- Space-delimited and list-shaped tool declarations are normalised only into a documented source representation.
- A directory/name mismatch and duplicate declared name are surfaced for identity review.

## Evidence to attach

Attach the source-occurrence count report, diagnostic report, field-presence and value-shape matrix, fixture manifest and examples with content redacted where necessary.

## Blockers

The current marketplace checkout, approved parsing contract from CORE-02 and handling approval for sensitive source content are required. Unresolved field precedence does not block lossless extraction, but blocks canonical projection.

## Out of scope

Marketplace file remediation, central registry creation, portal synchronisation, dependency endpoint resolution, graph writes and relevance scoring.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [SKL-01](SKL-01.md) must finish its stated contract boundary before this task starts.
- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `model`, `ingestion`, `source-refresh`, `validation-gates`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
