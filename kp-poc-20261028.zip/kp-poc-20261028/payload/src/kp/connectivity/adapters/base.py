"""Shared mechanics of the three gateway source adapters.

An adapter turns one sample item into a :class:`~kp.sources.base.FetchedItem` by calling the
source's tool through the gateway and reading the source's own fields from the answer. When
the tool answers with prose, or with an object that lacks the fields the version token needs,
the adapter raises :class:`~kp.connectivity.errors.FidelityError` (risk R-02).

The adapters also satisfy :class:`~kp.sources.base.SourceReader`, so the sweep can sit above
them. ``list_changed`` has no change tracking at this proof level: it reports the current
version of every configured item of the source.
"""

from __future__ import annotations

import base64
import binascii
from abc import ABC, abstractmethod
from collections.abc import Sequence
from datetime import datetime

from pydantic import AwareDatetime, JsonValue, TypeAdapter, ValidationError

from kp.connectivity.errors import FidelityError
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.models import JsonObject, Route, SampleItem, SampleKind, ToolResult
from kp.domain import ItemKey, SourceKind
from kp.errors import SourceItemNotFoundError
from kp.sources.base import ChangeBatch, ChangedItem, FetchedItem, ItemMetadata

_DATETIME = TypeAdapter(AwareDatetime)


class GatewayToolAdapter(ABC):
    """Base class of the Confluence, Jira and GitHub adapters.

    :param client: The gateway client
    :param route: Where the source's tool server sits
    :param items: The sample items of this source
    """

    def __init__(self, client: GatewayClient, route: Route, items: Sequence[SampleItem]) -> None:
        self._client = client
        self._route = route
        self._items = tuple(items)

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this adapter serves."""
        return self._route.source

    @abstractmethod
    def _fetch_primary(self, item: SampleItem) -> FetchedItem:
        """Fetch a page, issue or file."""

    @abstractmethod
    def _fetch_attachment(self, item: SampleItem) -> FetchedItem:
        """Fetch an attachment."""

    def fetch_current(self, item: SampleItem) -> FetchedItem:
        """Fetch the item as it is now and derive its version from the returned fields.

        :param item: The sample item
        :return: Its bytes and metadata
        :raises kp.connectivity.errors.FidelityError: If the tool lost the source's fields
        :raises kp.errors.SourceItemNotFoundError: If the source has no such item
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after renewal
        :raises kp.errors.SourceUnavailableError: If the gateway cannot be reached
        """
        if item.source is not self.kind:
            raise ValueError(
                f"{item.item_id} belongs to {item.source.value}, not {self.kind.value}"
            )
        if item.kind is SampleKind.ATTACHMENT:
            return self._fetch_attachment(item)
        return self._fetch_primary(item)

    def list_changed(
        self,
        cursor: str | None,  # noqa: ARG002 - the SourceReader protocol requires it
        *,
        limit: int = 100,
    ) -> ChangeBatch:
        """Report the current version of each configured item of this source.

        There is no change tracking here, so the cursor is ignored and nothing is paged.

        :param cursor: Ignored
        :param limit: Maximum number of items to report
        :return: One exhausted page
        """
        changed = []
        for item in self._items[:limit]:
            fetched = self.fetch_current(item)
            changed.append(
                ChangedItem(
                    key=fetched.key,
                    title=fetched.metadata.title,
                    modified_at=fetched.metadata.modified_at,
                )
            )
        return ChangeBatch(items=tuple(changed), next_cursor=None, exhausted=True)

    def fetch(self, key: ItemKey) -> FetchedItem:
        """Fetch a version the sweep already knows.

        The gateway tools address the current object, so this succeeds only while the source
        still has that version.

        :param key: The version to fetch
        :return: Its content and metadata
        :raises kp.errors.SourceItemNotFoundError: If the item is not configured or has moved on
        """
        for item in self._items:
            if item.item_id == key.item_id:
                fetched = self.fetch_current(item)
                if fetched.key.version != key.version:
                    raise SourceItemNotFoundError(f"{key} is no longer the current version")
                return fetched
        raise SourceItemNotFoundError(f"{key} is not a configured sample item")

    def _call(self, item: SampleItem, tool: str, arguments: JsonObject) -> JsonObject:
        """Call a tool and return its result as an object, or explain why it is not one."""
        result: ToolResult = self._client.call_tool(self._route, tool, arguments)
        if result.is_error:
            raise SourceItemNotFoundError(f"The {tool} tool reported an error for {item.item_id}")
        if result.structured is None:
            raise FidelityError(
                item.source.value, item.item_id, "the tool returned prose, not an object"
            )
        return result.structured


def fetched_item(
    item: SampleItem, version: str, content: bytes, metadata: ItemMetadata
) -> FetchedItem:
    """Assemble a fetched item whose key is the sample item's own id and the derived version.

    :param item: The sample item that was read
    :param version: The version token derived from the returned fields
    :param content: The exact bytes to store
    :param metadata: Descriptive facts about the item
    :return: The fetched item
    """
    return FetchedItem(
        key=ItemKey(source=item.source, item_id=item.item_id, version=version),
        content=content,
        metadata=metadata,
    )


def dig(item: SampleItem, payload: JsonObject, path: str) -> JsonValue:
    """Read a required field by dotted path.

    :param item: The item being read, for the error
    :param payload: The tool's object
    :param path: Dotted path such as ``version.number``
    :return: The value found
    :raises kp.connectivity.errors.FidelityError: If any step of the path is missing
    """
    node: JsonValue = payload
    for step in path.split("."):
        if not isinstance(node, dict) or step not in node:
            raise FidelityError(item.source.value, item.item_id, f"missing field {path}")
        node = node[step]
    return node


def dig_text(item: SampleItem, payload: JsonObject, path: str) -> str:
    """Read a required string field.

    :param item: The item being read, for the error
    :param payload: The tool's object
    :param path: Dotted path
    :return: The string
    :raises kp.connectivity.errors.FidelityError: If the field is missing or not a string
    """
    value = dig(item, payload, path)
    if not isinstance(value, str):
        raise FidelityError(item.source.value, item.item_id, f"field {path} is not text")
    return value


def dig_object(item: SampleItem, payload: JsonObject, path: str) -> JsonObject:
    """Read a required object field.

    :param item: The item being read, for the error
    :param payload: The tool's object
    :param path: Dotted path
    :return: The object
    :raises kp.connectivity.errors.FidelityError: If the field is missing or not an object
    """
    value = dig(item, payload, path)
    if not isinstance(value, dict):
        raise FidelityError(item.source.value, item.item_id, f"field {path} is not an object")
    return value


def decode_base64(item: SampleItem, payload: JsonObject, path: str) -> bytes:
    """Read a required base64 field and decode it.

    :param item: The item being read, for the error
    :param payload: The tool's object
    :param path: Dotted path of the encoded content
    :return: The decoded bytes
    :raises kp.connectivity.errors.FidelityError: If the field is missing, empty or not valid
        base64. Characters outside the alphabet are an error, never skipped, because skipping
        them would turn prose into plausible-looking bytes. Line breaks and spaces, which
        sources use to wrap long values, are removed first.
    """
    encoded = "".join(dig_text(item, payload, path).split())
    if not encoded:
        raise FidelityError(item.source.value, item.item_id, f"field {path} is empty")
    try:
        return base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise FidelityError(item.source.value, item.item_id, f"field {path} is not base64") from exc


def optional_text(payload: JsonObject, path: str) -> str | None:
    """Read an optional person or text field.

    A string is returned as is; an object is read through its ``displayName`` or ``name``.

    :param payload: The tool's object
    :param path: Dotted path
    :return: The text, or ``None`` when absent
    """
    node: JsonValue = payload
    for step in path.split("."):
        if not isinstance(node, dict) or step not in node:
            return None
        node = node[step]
    if isinstance(node, dict):
        for key in ("displayName", "name"):
            named = node.get(key)
            if isinstance(named, str):
                return named
        return None
    return node if isinstance(node, str) else None


def optional_time(payload: JsonObject, path: str) -> datetime | None:
    """Read an optional timestamp; values that are not aware ISO timestamps count as absent.

    :param payload: The tool's object
    :param path: Dotted path
    :return: The timestamp, or ``None``
    """
    text = optional_text(payload, path)
    if text is None:
        return None
    try:
        return _DATETIME.validate_python(text)
    except ValidationError:
        return None
