"""Publisher that writes to a local git repository and keeps the pull request as a JSON record.

Merging (:meth:`LocalGitPublisher.merge`) stands in for a reviewer pressing the merge button: the
branch's file is committed onto the base branch and the record says when. The publisher then
lists the files of the base branch (:meth:`LocalGitPublisher.merged_specs`), which is what the
spec repository reader sweeps.

The branch is built with git plumbing (blob, temporary index, tree, commit, ref) so the
caller's working tree, index and checked-out branch are never touched, and the base branch is
never moved. The "pull request" is a small JSON file inside the repository's git directory,
found by branch name: the same branch is always the same pull request. It behaves like the
REST publisher: a record that is no longer open is never committed to, and a request naming
another repository than the configured one is refused. Pull request numbers are allocated
without a lock, so the stand-in is for a single process; the REST publisher is the real one.
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import tempfile
from collections.abc import Mapping
from datetime import datetime
from pathlib import Path
from typing import Any

from kp.clock import Clock, SystemClock
from kp.sources.spec_repo import MergedSpecFile
from kp.writeback.errors import BranchNotPermittedError, PublishError, RepositoryNotPermittedError
from kp.writeback.models import MergeResult, PublishRequest, PublishResult
from kp.writeback.rendering import MACHINE_AUTHOR_EMAIL, MACHINE_AUTHOR_NAME

logger = logging.getLogger(__name__)

GIT_BINARY_VARIABLE = "KP_GIT_BINARY"
RECORD_DIRECTORY = "kp-pull-requests"
_PROBE_TIMEOUT_SECONDS = 10
_FILE_MODE = "100644"


def resolve_git_binary(
    environ: Mapping[str, str] | None = None, *, preferred: str | None = None
) -> str | None:
    """Find a working git binary: the setting, ``KP_GIT_BINARY``, else ``git`` on the path.

    :param environ: The environment to read; defaults to the process environment
    :param preferred: The ``git_binary`` setting, tried first when given
    :return: A path or command that answers ``--version``, or ``None``
    """
    env = os.environ if environ is None else environ
    for candidate in (preferred, env.get(GIT_BINARY_VARIABLE), "git"):
        if not candidate:
            continue
        try:
            probe = subprocess.run(  # noqa: S603 - fixed argument vector, no shell
                [candidate, "--version"],
                capture_output=True,
                check=False,
                timeout=_PROBE_TIMEOUT_SECONDS,
            )
        except (OSError, subprocess.SubprocessError):
            continue
        if probe.returncode == 0:
            return candidate
    return None


class LocalGitPublisher:
    """Publishes specs to a local repository.

    :param repository_path: A git repository that already has the base branch
    :param git_binary: The git executable (see :func:`resolve_git_binary`)
    :param base_branch: The branch pull requests target; it is never committed to
    :param clock: Time source for commit dates and records
    :param repository: ``<owner>/<repository>`` the stand-in represents; when given, a request
        naming another repository is refused
    """

    def __init__(
        self,
        repository_path: Path,
        git_binary: str,
        *,
        base_branch: str = "main",
        clock: Clock | None = None,
        repository: str | None = None,
    ) -> None:
        self._path = repository_path
        self._git = git_binary
        self._base = base_branch
        self._clock = clock or SystemClock()
        self._repository = repository

    @classmethod
    def initialise(
        cls,
        repository_path: Path,
        git_binary: str,
        *,
        base_branch: str = "main",
        clock: Clock | None = None,
        repository: str | None = None,
    ) -> LocalGitPublisher:
        """Open the repository, creating it with an empty first commit when it is missing.

        :param repository_path: Where the repository lives
        :param git_binary: The git executable
        :param base_branch: The base branch to create when the repository is new
        :param clock: Time source
        :param repository: The repository name requests must carry, if any
        :return: A publisher for the repository
        """
        publisher = cls(
            repository_path, git_binary, base_branch=base_branch, clock=clock, repository=repository
        )
        if not (repository_path / ".git").exists():
            repository_path.mkdir(parents=True, exist_ok=True)
            publisher._run("init", "--quiet")
            publisher._run("symbolic-ref", "HEAD", f"refs/heads/{base_branch}")
            tree = publisher._run("mktree", stdin=b"")
            commit = publisher._commit(tree, None, "Initial commit\n")
            publisher._run("update-ref", f"refs/heads/{base_branch}", commit)
        return publisher

    def publish(self, request: PublishRequest) -> PublishResult:
        """Commit the spec to its branch and create or update the pull request record.

        :param request: A request that passed the write limits
        :return: The pull request record and the commit
        :raises kp.writeback.errors.RepositoryNotPermittedError: If the request names another
            repository than the configured one
        :raises kp.writeback.errors.BranchNotPermittedError: If the branch is the base branch
        :raises kp.writeback.errors.PublishError: If git fails, or the pull request record for
            the branch is no longer open (nothing is committed then)
        """
        if (
            self._repository is not None
            and request.repository.casefold() != self._repository.casefold()
        ):
            raise RepositoryNotPermittedError("Repository is not the configured spec repository")
        if request.branch == self._base:
            raise BranchNotPermittedError(
                "Branch is the base branch; specs go through a pull request"
            )
        record = self._read_record(request.branch)
        if record is not None and record["state"] != "open":
            raise PublishError("The pull request for this branch is no longer open")
        ref = f"refs/heads/{request.branch}"
        head = self._rev_parse(f"{ref}^{{commit}}")
        parent = head or self._rev_parse(f"refs/heads/{self._base}^{{commit}}")
        if parent is None:
            raise PublishError("The base branch does not exist in the repository")
        tree = self._tree_with(parent, request.path, request.content)
        committed = head is None or tree != self._run("rev-parse", f"{head}^{{tree}}")
        commit = self._commit(tree, parent, request.commit_message) if committed else parent
        if committed:
            self._run("update-ref", ref, commit)
        number, created = self._write_record(request, commit, record)
        logger.info(
            "Spec published to local repository",
            extra={"branch": request.branch, "pr_number": number, "committed": committed},
        )
        return PublishResult(
            branch=request.branch,
            pr_url=f"local-pr:{number}",
            pr_number=number,
            commit_sha=commit,
            created=created,
            committed=committed,
        )

    def merge(self, branch: str) -> MergeResult:
        """Merge the pull request of a branch into the base branch.

        The branch's copy of the spec file is committed onto the base branch (a squash: the
        base gets one commit whatever the branch holds) and the record is marked merged with
        the clock's time. Merging a merged branch changes nothing.

        :param branch: The branch the spec was published on
        :return: The merge
        :raises kp.writeback.errors.PublishError: If the branch has no pull request record or
            its record is closed, or git fails
        """
        record = self._read_record(branch)
        if record is None or record["state"] not in {"open", "merged"}:
            raise PublishError("There is no open pull request for this branch")
        path = str(record["path"])
        if record["state"] == "merged":
            return self._merge_result(branch, record, merged=False)
        base = self._rev_parse(f"refs/heads/{self._base}^{{commit}}")
        content = self._rev_parse(f"refs/heads/{branch}:{path}")
        if base is None or content is None:
            raise PublishError("The branch or its spec file does not exist in the repository")
        tree = self._tree_with_blob(base, path, content)
        commit = self._commit(tree, base, f"Merge {branch}\n")
        self._run("update-ref", f"refs/heads/{self._base}", commit)
        record.update(state="merged", merged_at=self._clock.now().isoformat(), merge_commit=commit)
        self._save_record(branch, record)
        logger.info("Spec pull request merged", extra={"branch": branch})
        return self._merge_result(branch, record, merged=True)

    def merged_specs(self) -> list[MergedSpecFile]:
        """List the spec files on the base branch, each with the date of its newest merge.

        :return: One entry per file path that a merged pull request wrote; empty when none was
            merged
        :raises kp.writeback.errors.PublishError: If git fails
        """
        newest: dict[str, dict[str, Any]] = {}
        for record_path in sorted(self._record_directory().glob("*.json")):
            record: dict[str, Any] = json.loads(record_path.read_text(encoding="utf-8"))
            held = newest.get(str(record["path"]))
            if record["state"] == "merged" and (
                held is None or record["merged_at"] >= held["merged_at"]
            ):
                newest[str(record["path"])] = record
        base = f"refs/heads/{self._base}"
        return [
            MergedSpecFile(
                path=path,
                content=self._run_bytes("cat-file", "blob", f"{base}:{path}"),
                merged_at=datetime.fromisoformat(record["merged_at"]),
            )
            for path, record in sorted(newest.items())
        ]

    @staticmethod
    def _merge_result(branch: str, record: dict[str, Any], *, merged: bool) -> MergeResult:
        return MergeResult(
            branch=branch,
            path=str(record["path"]),
            merged_at=datetime.fromisoformat(record["merged_at"]),
            commit_sha=str(record["merge_commit"]),
            merged=merged,
        )

    def _env(self, extra: Mapping[str, str] | None = None) -> dict[str, str]:
        env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
        env["GIT_TERMINAL_PROMPT"] = "0"
        env.update(extra or {})
        return env

    def _run(
        self,
        *args: str,
        stdin: bytes | None = None,
        env: Mapping[str, str] | None = None,
        allow_failure: bool = False,
    ) -> str:
        done = self._run_bytes(*args, stdin=stdin, env=env, allow_failure=allow_failure)
        return done.decode("utf-8").strip()

    def _run_bytes(
        self,
        *args: str,
        stdin: bytes | None = None,
        env: Mapping[str, str] | None = None,
        allow_failure: bool = False,
    ) -> bytes:
        try:
            done = subprocess.run(  # noqa: S603 - fixed argument vector, no shell
                [self._git, "-C", str(self._path), "-c", "commit.gpgsign=false", *args],
                input=stdin,
                capture_output=True,
                check=False,
                env=self._env(env),
                timeout=_PROBE_TIMEOUT_SECONDS * 6,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise PublishError("The git binary could not be run") from exc
        if done.returncode != 0:
            if allow_failure:
                return b""
            logger.error(
                "git command failed", extra={"git_command": args[0], "exit_code": done.returncode}
            )
            raise PublishError(f"git {args[0]} failed")
        return done.stdout

    def _rev_parse(self, expression: str) -> str | None:
        found = self._run("rev-parse", "--verify", "--quiet", expression, allow_failure=True)
        return found or None

    def _tree_with(self, parent: str, path: str, content: str) -> str:
        blob = self._run("hash-object", "-w", "--stdin", stdin=content.encode("utf-8"))
        return self._tree_with_blob(parent, path, blob)

    def _tree_with_blob(self, parent: str, path: str, blob: str) -> str:
        with tempfile.TemporaryDirectory() as scratch:
            index = {"GIT_INDEX_FILE": str(Path(scratch) / "index")}
            self._run("read-tree", parent, env=index)
            self._run(
                "update-index", "--add", "--cacheinfo", f"{_FILE_MODE},{blob},{path}", env=index
            )
            return self._run("write-tree", env=index)

    def _commit(self, tree: str, parent: str | None, message: str) -> str:
        stamp = self._clock.now().isoformat()
        identity = {
            "GIT_AUTHOR_NAME": MACHINE_AUTHOR_NAME,
            "GIT_AUTHOR_EMAIL": MACHINE_AUTHOR_EMAIL,
            "GIT_COMMITTER_NAME": MACHINE_AUTHOR_NAME,
            "GIT_COMMITTER_EMAIL": MACHINE_AUTHOR_EMAIL,
            "GIT_AUTHOR_DATE": stamp,
            "GIT_COMMITTER_DATE": stamp,
        }
        parents = ["-p", parent] if parent else []
        return self._run("commit-tree", tree, *parents, stdin=message.encode("utf-8"), env=identity)

    def _record_directory(self) -> Path:
        directory = Path(self._run("rev-parse", "--absolute-git-dir")) / RECORD_DIRECTORY
        directory.mkdir(exist_ok=True)
        return directory

    def _record_path(self, branch: str) -> Path:
        return self._record_directory() / f"{branch.replace('/', '__')}.json"

    def _read_record(self, branch: str) -> dict[str, Any] | None:
        record_path = self._record_path(branch)
        if not record_path.exists():
            return None
        record: dict[str, Any] = json.loads(record_path.read_text(encoding="utf-8"))
        return record

    def _write_record(
        self, request: PublishRequest, commit: str, existing: dict[str, Any] | None
    ) -> tuple[int, bool]:
        directory = self._record_directory()
        now: datetime = self._clock.now()
        if existing is not None:
            record = existing
            created = False
        else:
            taken = [
                int(json.loads(item.read_text(encoding="utf-8"))["number"])
                for item in directory.glob("*.json")
            ]
            record = {"number": max(taken, default=0) + 1, "created_at": now.isoformat()}
            created = True
        record.update(
            head=request.branch,
            base=self._base,
            title=request.pr_title,
            body=request.pr_body,
            state="open",
            commit=commit,
            path=request.path,
            updated_at=now.isoformat(),
        )
        self._save_record(request.branch, record)
        return int(record["number"]), created

    def _save_record(self, branch: str, record: dict[str, Any]) -> None:
        record_path = self._record_path(branch)
        scratch = record_path.with_suffix(".tmp")
        scratch.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
        scratch.replace(record_path)
