"""PR 82 review fixes: gateway-only token, MCP answer parsing and pages, stale export keys,
tool chips once each, no list position for hub servers. Usage: apply_t.py ROOT [--check]"""
import ast
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
CHECK = "--check" in sys.argv
B = ROOT / "backend"
F = ROOT / "frontend/src/features/recsys"
MOD = B / "app/recsys/registry/agent_hub_api.py"
CFG = B / "app/recsys/config.py"
TST = B / "tests/recsys/registry/test_agent_hub_api.py"
CARD = F / "components/RecommendationCard.tsx"
CARDT = F / "components/RecommendationCard.test.tsx"
REG = F / "component-page/fromRegistry.ts"
REGT = F / "component-page/fromRegistry.test.ts"
edits = {}


def fail(msg):
    sys.exit("FAIL " + msg)


def swap(text, old, new, what):
    if text.count(old) != 1:
        fail(f"{what}: anchor found {text.count(old)} times")
    return text.replace(old, new)


def top(tree, name):
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    fail("no function " + name)


def splice(text, spans):
    """Replace 1-based inclusive line spans with new text, bottom-up."""
    lines = text.splitlines(keepends=True)
    for start, end, new in sorted(spans, key=lambda s: -s[0]):
        lines[start - 1 : end] = [new.strip("\n") + "\n"]
    return "".join(lines)


def block(src, indent=""):
    return "\n".join(indent + line if line else "" for line in src.strip("\n").splitlines())


# --- agent_hub_api.py ---------------------------------------------------------------
t = MOD.read_text()
if "def under_gateway" in t:
    fail("module already patched")
tree = ast.parse(t)
spans = []

rpc = top(tree, "_rpc_result")
spans.append((rpc.lineno, rpc.end_lineno, '''
def under_gateway(server_url: str, gateway_url: str) -> bool:
    """Tell whether a server address sits under the MCP gateway, so it may get the token.

    :param server_url: The server's ``serverUrl`` from the hub list.
    :param gateway_url: The gateway's base address from the settings.
    :return: ``True`` only for an https address on the gateway's host and port whose path
        is the gateway's path or below it.
    """
    try:
        server, gateway = urlsplit(server_url), urlsplit(gateway_url)
        same_host = (server.hostname, server.port) == (gateway.hostname, gateway.port)
    except ValueError:
        return False
    if server.scheme != "https" or gateway.scheme != "https" or not gateway.hostname:
        return False
    base = gateway.path.rstrip("/")
    return same_host and (server.path == base or server.path.startswith(base + "/"))


def _rpc_result(response: httpx.Response, request_id: int) -> JsonObject:
    """Read the result for one request from a plain JSON or a server-sent-events response.

    A stream can carry notifications next to the answer and can split one message over
    several ``data:`` lines, so the answer is the message whose id matches.

    :param response: The response to an MCP request.
    :param request_id: The id the request was sent with.
    :return: The ``result`` object, or an empty dict when there is none.
    :raises AgentHubApiError: If the server answered with a JSON-RPC error.
    """
    texts = [response.text]
    if "event-stream" in response.headers.get("Content-Type", ""):
        events = response.text.replace("\\r\\n", "\\n").split("\\n\\n")
        texts = [
            "\\n".join(
                line[5:].removeprefix(" ") for line in event.splitlines() if line.startswith("data:")
            )
            for event in events
        ]
    for text in texts:
        try:
            message = json.loads(text) if text else None
        except ValueError:
            continue
        if not isinstance(message, dict) or message.get("id") != request_id:
            continue
        error = message.get("error")
        if error is not None:
            code = error.get("code") if isinstance(error, dict) else None
            raise AgentHubApiError(f"MCP request {request_id} returned error {code}")
        result = message.get("result")
        return result if isinstance(result, dict) else {}
    return {}
'''))

fmt = top(tree, "fetch_mcp_tools")
body = fmt.body
# keep everything up to the `try:` (docstring rewritten, headers and initialize kept)
tri = next(node for node in body if isinstance(node, ast.Try))
lines = t.splitlines()
kept = "\n".join(lines[body[1].lineno - 1 : tri.lineno - 1])
spans.append((fmt.lineno, fmt.end_lineno, '''
def fetch_mcp_tools(server_url: str, id_token: str, client: httpx.Client) -> list[JsonObject]:
    """List one server's tools over MCP through the gateway.

    Only the gateway header is sent; the server's own ``requiredHeaders`` are tool
    credentials and stay out of this. No tool is ever called. ``tools/list`` is read page
    by page while the server returns a ``nextCursor``, up to ``MAX_TOOL_PAGES`` pages.

    :param server_url: The server's ``serverUrl``; enrich_with_tools sends only
        addresses under the gateway.
    :param id_token: The Entra ID token the gateway accepts. Never logged.
    :param client: The client to send the requests with.
    :return: ``{name, description}`` per tool, in server order.
    :raises AgentHubApiError: If a request fails or the server refuses it.
    """
''' + kept + '''
    tools: list[Any] = []  # Any: raw JSON entries, checked below
    try:
        opened = client.post(server_url, headers=headers, json=initialize)
        if opened.status_code != 200:
            raise AgentHubApiError(f"initialize returned HTTP {opened.status_code}")
        session = opened.headers.get("Mcp-Session-Id")
        if session:
            headers["Mcp-Session-Id"] = session
        initialized = {"jsonrpc": "2.0", "method": "notifications/initialized"}
        acknowledged = client.post(server_url, headers=headers, json=initialized)
        if acknowledged.status_code not in NOTIFICATION_OK:
            status = acknowledged.status_code
            raise AgentHubApiError(f"notifications/initialized returned HTTP {status}")
        cursor = ""
        for request_id in range(2, MAX_TOOL_PAGES + 2):
            request: JsonObject = {"jsonrpc": "2.0", "id": request_id, "method": "tools/list"}
            if cursor:
                request["params"] = {"cursor": cursor}
            listed = client.post(server_url, headers=headers, json=request)
            if listed.status_code != 200:
                raise AgentHubApiError(f"tools/list returned HTTP {listed.status_code}")
            result = _rpc_result(listed, request_id)
            tools.extend(result.get("tools") or [])
            cursor = _text(result.get("nextCursor"))
            if not cursor:
                break
        else:
            logger.warning("MCP tools/list stopped at the page limit", extra={"pages": MAX_TOOL_PAGES})
    except httpx.HTTPError as exc:
        raise AgentHubApiError(f"MCP handshake failed: {type(exc).__name__}") from exc
    return [
        {
            "name": _text(tool.get("name")).strip(),
            "description": _text(tool.get("description")).strip(),
        }
        for tool in tools
        if isinstance(tool, dict) and _text(tool.get("name")).strip()
    ]
'''))

enr = top(tree, "enrich_with_tools")
one = next(node for node in enr.body if isinstance(node, ast.FunctionDef) and node.name == "one")
early = next(node for node in one.body if isinstance(node, ast.If))  # the empty-address early return
spans.append((early.end_lineno + 1, early.end_lineno, block('''
if not under_gateway(url, gateway_url):
    logger.warning("MCP server is not under the gateway", extra={"server": item.get("serverId")})
    return item
''', "        ")))
owned = next(node for node in enr.body if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") == "owned")
spans.append((owned.lineno, owned.lineno - 1, block('''
if not under_gateway(gateway_url, gateway_url):
    raise AgentHubApiError("RECSYS_AGENT_HUB_MCP_GATEWAY_URL must be an https address")
''', "    ")))
doc_e = enr.body[0]
spans.append((doc_e.lineno, doc_e.end_lineno, block('''
"""Attach each server's tools, listed live; a server that fails gets none.

The ID token goes only to servers under the gateway; any other ``serverUrl`` is skipped
without a request.

:param items: Server objects from the hub list.
:param id_token: The Entra ID token the gateway accepts. Never logged.
:param gateway_url: The MCP gateway's https base address.
:param client: An optional client (tests pass one with a mock transport).
:param timeout: Per-request timeout in seconds.
:return: Copies of the items, with a ``tools`` list on every server that answered.
:raises AgentHubApiError: If the gateway address is missing or not https.
"""
''', "    ")))
sig_end = enr.body[0].lineno - 1  # the `) -> list[JsonObject]:` line
sig = "\n".join(lines[enr.lineno - 1 : sig_end])
if sig.count("id_token: str,") != 1:
    fail("enrich signature")
spans.append((enr.lineno, sig_end, sig.replace("id_token: str,\n    *,", "id_token: str,\n    *,\n    gateway_url: str,")))
if "gateway_url: str" not in spans[-1][2]:
    fail("enrich keyword-only marker")

wam = top(tree, "with_agent_hub_mcps")
ret = wam.body[-1]
if not isinstance(ret, ast.Return):
    fail("with_agent_hub_mcps return")
spans.append((ret.lineno, ret.end_lineno, block('''
# The export's MCP List no longer feeds the catalogue, so its column counts go too.
stale = f"export:{MCP_SHEET}:"
unconsumed = {key: n for key, n in tables.unconsumed_keys.items() if not key.startswith(stale)}
return dataclasses.replace(
    tables, mcps=rows, inputs=[*tables.inputs, descriptor], unconsumed_keys=unconsumed
)
''', "    ")))

mn = top(tree, "main")
wt = next(node for node in mn.body if isinstance(node, ast.If) and "with_tools" in ast.unparse(node.test))
spans.append((wt.lineno, wt.end_lineno, block('''
if args.with_tools:
    gateway = recsys_settings.recsys_agent_hub_mcp_gateway_url
    try:
        items = enrich_with_tools(items, token, gateway_url=gateway)
    except AgentHubApiError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(f"tools listed for {sum(1 for item in items if item.get('tools'))} servers")
''', "    ")))

t = splice(t, spans)
t = swap(t, "bank's MCP gateway, using the same gateway header the hub SDK sends; the tool names fill\n",
         "bank's MCP gateway, using the same gateway header the hub SDK sends. The ID token is sent\n"
         "only to servers under the gateway's base address, `RECSYS_AGENT_HUB_MCP_GATEWAY_URL`, and\n"
         "`tools/list` is read page by page. The tool names fill\n", "module docstring")
t = swap(t, "from typing import Any\n", "from typing import Any\nfrom urllib.parse import urlsplit\n", "urlsplit import")
t = swap(t, "TOOL_WORKERS = 8\n", "TOOL_WORKERS = 8\n"
         "#: Most `tools/list` pages read from one server.\n"
         "MAX_TOOL_PAGES = 20\n"
         "#: Statuses a server may answer `notifications/initialized` with.\n"
         "NOTIFICATION_OK = frozenset({200, 202, 204})\n", "constants")
ast.parse(t)
edits[MOD] = t

# --- config.py ----------------------------------------------------------------------
c = CFG.read_text()
if "RECSYS_AGENT_HUB_MCP_GATEWAY_URL" in c:
    fail("config already patched")
cl = c.splitlines(keepends=True)
at = [i for i, line in enumerate(cl) if 'alias="RECSYS_AGENT_HUB_ID_TOKEN"' in line]
if len(at) != 1:
    fail("config token anchor")
if "Field(" in cl[at[0]]:
    end = at[0]
else:
    end = next(i for i in range(at[0], at[0] + 3) if cl[i].strip() == ")")
pad = cl[at[0]][: len(cl[at[0]]) - len(cl[at[0]].lstrip())]
pad = pad[:-4] if cl[at[0]].strip().startswith("default=") else pad
cl[end + 1 : end + 1] = [
    pad + "#: MCP gateway base address (https). With `--with-tools` the ID token is sent only\n",
    pad + "#: to servers whose `serverUrl` sits under it.\n",
    pad + "recsys_agent_hub_mcp_gateway_url: str = Field(\n",
    pad + '    default="", alias="RECSYS_AGENT_HUB_MCP_GATEWAY_URL"\n',
    pad + ")\n",
]
edits[CFG] = "".join(cl)

# --- backend tests ------------------------------------------------------------------
s = TST.read_text()
s = swap(s, "    main,\n    with_agent_hub_mcps,\n)", "    main,\n    under_gateway,\n    with_agent_hub_mcps,\n)", "test import")
s = swap(s, 'enrich_with_tools(items, "id-token-value", client=client)',
         'enrich_with_tools(\n            items, "id-token-value", gateway_url="https://gateway.example.test/", client=client\n        )',
         "existing enrich call")
s = swap(s, '\n\nif __name__ == "__main__":', '''

GATEWAY = "https://gateway.example.test/"


class GatewayTests(unittest.TestCase):
    def test_only_https_addresses_under_the_gateway_qualify(self) -> None:
        self.assertTrue(under_gateway("https://gateway.example.test/alpha/mcp", GATEWAY))
        self.assertTrue(under_gateway("https://GATEWAY.example.test/beta", GATEWAY))
        for url in (
            "http://gateway.example.test/alpha/mcp",
            "https://gateway.example.test.other.test/alpha/mcp",
            "https://other.example.test/alpha/mcp",
            "https://gateway.example.test:8443/alpha/mcp",
            "not a url",
        ):
            self.assertFalse(under_gateway(url, GATEWAY), url)

    def test_a_gateway_path_matches_whole_segments(self) -> None:
        base = "https://gateway.example.test/mcp"
        self.assertTrue(under_gateway("https://gateway.example.test/mcp/alpha", base))
        self.assertFalse(under_gateway("https://gateway.example.test/mcp-other/alpha", base))

    def test_enrich_sends_nothing_to_servers_off_the_gateway(self) -> None:
        seen: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            seen.append(str(request.url))
            if json.loads(request.content)["method"] == "tools/list":
                listed = {"jsonrpc": "2.0", "id": 2, "result": {"tools": TOOLS}}
                return httpx.Response(200, json=listed)
            return httpx.Response(200, json={"jsonrpc": "2.0", "id": 1, "result": {}})

        client = httpx.Client(transport=httpx.MockTransport(handler))
        self.addCleanup(client.close)
        items = [
            _server(serverUrl="https://gateway.example.test/alpha/mcp"),
            _server("mcp-beta", serverUrl="https://other.example.test/beta/mcp"),
            _server("mcp-gamma", serverUrl="http://gateway.example.test/gamma/mcp"),
        ]
        alpha, beta, gamma = enrich_with_tools(
            items, "id-token-value", gateway_url=GATEWAY, client=client
        )
        self.assertEqual(len(alpha["tools"]), 2)
        self.assertNotIn("tools", beta)
        self.assertNotIn("tools", gamma)
        self.assertEqual(set(seen), {"https://gateway.example.test/alpha/mcp"})

    def test_enrich_refuses_a_missing_gateway(self) -> None:
        with self.assertRaises(AgentHubApiError):
            enrich_with_tools([_server()], "id-token-value", gateway_url="")

    def test_main_with_tools_needs_the_gateway(self) -> None:
        from app.recsys.config import recsys_settings

        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        out = Path(directory.name) / "mcps.json"
        target = "app.recsys.registry.agent_hub_api.fetch_agent_hub_mcps"
        with (
            mock.patch(target, return_value=[_server()]),
            mock.patch.object(recsys_settings, "recsys_agent_hub_mcp_gateway_url", ""),
        ):
            self.assertEqual(main(["--out", str(out), "--with-tools"]), 1)
        self.assertFalse(out.exists())


class McpAnswerTests(unittest.TestCase):
    URL = "https://gateway.example.test/alpha/mcp"

    def _tools(
        self, pages: list[httpx.Response], initialized: int = 202
    ) -> tuple[list[dict[str, str]], list[dict[str, object]]]:
        """List tools from a server that answers each ``tools/list`` with the next page."""
        sent: list[dict[str, object]] = []

        def handler(request: httpx.Request) -> httpx.Response:
            message = json.loads(request.content)
            sent.append(message)
            if message["method"] == "initialize":
                return httpx.Response(200, json={"jsonrpc": "2.0", "id": 1, "result": {}})
            if message["method"] == "notifications/initialized":
                return httpx.Response(initialized)
            return pages.pop(0)

        client = httpx.Client(transport=httpx.MockTransport(handler))
        self.addCleanup(client.close)
        return fetch_mcp_tools(self.URL, "id-token-value", client), sent

    def test_the_answer_is_found_among_notifications_and_split_data_lines(self) -> None:
        answer = json.dumps({"jsonrpc": "2.0", "id": 2, "result": {"tools": TOOLS}}, indent=1)
        body = (
            _sse({"jsonrpc": "2.0", "method": "notifications/message", "params": {}})
            + "event: message\\n"
            + "".join(f"data: {line}\\n" for line in answer.splitlines())
            + "\\n"
            + _sse({"jsonrpc": "2.0", "method": "notifications/progress", "params": {}})
        )
        stream = httpx.Response(200, text=body, headers={"Content-Type": "text/event-stream"})
        tools, _ = self._tools([stream])
        self.assertEqual([tool["name"] for tool in tools], ["find_symbol", "index_status"])

    def test_every_tools_page_is_read(self) -> None:
        first = {"jsonrpc": "2.0", "id": 2, "result": {"tools": TOOLS[:1], "nextCursor": "p2"}}
        second = {"jsonrpc": "2.0", "id": 3, "result": {"tools": TOOLS[1:]}}
        pages = [httpx.Response(200, json=first), httpx.Response(200, json=second)]
        tools, sent = self._tools(pages)
        self.assertEqual([tool["name"] for tool in tools], ["find_symbol", "index_status"])
        self.assertEqual(sent[-1]["params"], {"cursor": "p2"})

    def test_a_refused_initialized_notification_is_an_error(self) -> None:
        with self.assertRaises(AgentHubApiError) as caught:
            self._tools([], initialized=500)
        self.assertIn("500", str(caught.exception))

    def test_a_json_rpc_error_is_an_error(self) -> None:
        failed = {"jsonrpc": "2.0", "id": 2, "error": {"code": -32601, "message": "unknown"}}
        with self.assertRaises(AgentHubApiError):
            self._tools([httpx.Response(200, json=failed)])


class StaleExportKeysTests(unittest.TestCase):
    def test_the_export_mcp_list_counts_go_and_the_others_stay(self) -> None:
        keys = {f"export:{MCP_SHEET}:Extra": 1, "export:Agent List:Extra": 2}
        result = with_agent_hub_mcps(ExportTables(unconsumed_keys=keys), [_server()])
        self.assertEqual(result.unconsumed_keys, {"export:Agent List:Extra": 2})


if __name__ == "__main__":''', "test tail")
edits[TST] = s

# --- frontend -----------------------------------------------------------------------
k = CARD.read_text()
k = swap(k, "const MAX_TOOL_CHIPS = 6\n", """const MAX_TOOL_CHIPS = 6

/** A card's tool chips: each tool once, the first few shown and the rest counted. */
function ToolChips({ tools = [] }: { tools?: string[] }) {
  const unique = Array.from(new Set(tools))
  if (unique.length === 0) return null
  return (
    <div className="mt-2 flex flex-wrap items-center gap-1">
      <span className="text-xs text-gray-500">Tools:</span>
      {unique.slice(0, MAX_TOOL_CHIPS).map((tool) => (
        <Tag key={tool} className="m-0 font-mono text-xs">
          {tool}
        </Tag>
      ))}
      {unique.length > MAX_TOOL_CHIPS && (
        <span className="text-xs text-gray-500">+{unique.length - MAX_TOOL_CHIPS} more</span>
      )}
    </div>
  )
}
""", "card chips const")
old_chips = ("        {component.tools && component.tools.length > 0 && (\n"
             '          <div className="mt-2 flex flex-wrap items-center gap-1">\n'
             '            <span className="text-xs text-gray-500">Tools:</span>\n'
             "            {component.tools.slice(0, MAX_TOOL_CHIPS).map((tool) => (\n"
             '              <Tag key={tool} className="m-0 font-mono text-xs">\n'
             "                {tool}\n"
             "              </Tag>\n"
             "            ))}\n"
             "            {component.tools.length > MAX_TOOL_CHIPS && (\n"
             '              <span className="text-xs text-gray-500">\n'
             "                +{component.tools.length - MAX_TOOL_CHIPS} more\n"
             "              </span>\n"
             "            )}\n"
             "          </div>\n"
             "        )}\n")
k = swap(k, old_chips, "        <ToolChips tools={component.tools} />\n", "card chips block")
edits[CARD] = k

kt = CARDT.read_text()
kt = swap(kt, "    expect(screen.queryByText('Tools:')).toBeNull()\n  })\n})\n", """    expect(screen.queryByText('Tools:')).toBeNull()
  })

  it('shows a repeated tool once', () => {
    render(
      <MemoryRouter>
        <RecommendationCard recommendation={recommendation(['t1', 't1', 't2'])} />
      </MemoryRouter>,
    )
    expect(screen.getAllByText('t1')).toHaveLength(1)
    expect(screen.queryByText(/more$/)).toBeNull()
  })
})
""", "card test tail")
edits[CARDT] = kt

r = REG.read_text()
r = swap(r, "      sourceReference: formatSourceRef(detail.source_ref) || null,\n",
         "      // A hub server's row number is only its place in the API list, so it is left out.\n"
         "      sourceReference: detail.source === 'agent_hub_api' ? null : formatSourceRef(detail.source_ref) || null,\n",
         "registry source reference")
edits[REG] = r

rt = REGT.read_text()
if not rt.endswith("})\n"):
    fail("registry test tail")
edits[REGT] = rt + """
describe('toPageModel source reference', () => {
  it('leaves out the list position of a server read from the Agent Hub', () => {
    const hub = detail({ component_type: 'mcp', source: 'agent_hub_api', source_ref: 'sheet=MCP List;row=12' })
    expect(toPageModel(hub, { demo: false }).source.sourceReference).toBeNull()
  })

  it('keeps the sheet and row of an exported component', () => {
    const exported = detail({ source: 'agenthub_export', source_ref: 'sheet=Agents;row=4' })
    expect(toPageModel(exported, { demo: false }).source.sourceReference).toBe('Agents sheet, row 4')
  })
})
"""

for path, text in edits.items():
    if not text.isascii():
        fail("non-ascii in " + path.name)
    if not CHECK:
        path.write_text(text)
print(("CHECK OK " if CHECK else "APPLIED ") + str(len(edits)) + " files")
