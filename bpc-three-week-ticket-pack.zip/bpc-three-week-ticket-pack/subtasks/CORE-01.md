---
pack_id: "bpc-sep26-v1"
local_id: "CORE-01"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Reconcile the working PoC, source access and delivery prerequisites"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 4
scope: "foundation"
create_by_default: true
planned_start: "2026-09-09"
planned_due: "2026-09-09"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: []
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-01"
architecture_sections: ["mandate","validation-gates","evidence"]
---

# Reconcile the working PoC, source access and delivery prerequisites

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-01** is not a Jira key.
- Estimate: **4 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-09 → 2026-09-09 (D1–D1)**.
- Recommendation extension: **2026-09-09 → 2026-09-09 (D1–D1)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Turn dated reports into a current implementation map before promising a three-week delivery. Preserve working PoC code and expose unknown prerequisites.

## Scope and contract

Record current commit/branch, cleaned architecture, public routes, import CLI, source adapters, identity/resolver, graph publication, model gateway, frontend hooks, auth, worker persistence and CI. Separate observed / reported / missing / proposed. The non-ticket import preflight resolves Jira identities/schema before this ticket exists; this task consumes its readback record and does not block its own creation.

## Implementation sequence

1. Inspect the actual HSBC checkout and map logical responsibilities to exact files and symbols, including startup DDL and asyncpg usage if still present.
2. Run the approved narrow baseline smoke/CI workflow and capture the invocation and actual result; unavailable dependencies remain explicit.
3. Verify the approved workbook location, Skills repository/ref, source scope and read credentials; inspect source hashes without copying secrets into tickets.
4. Confirm graph namespace/privileges, current service identity and refresh write policy with the responsible owner. Verify the worker/outbox/recovery mechanism rather than assuming Redis implies durable jobs.
5. Record current UI/CLI capabilities, evaluation reports, feature defaults and what can be reused. Resolve acceptance scope with Joseph and record a change budget before downstream work starts.

## Acceptance criteria

- [ ] A versioned code/source/runtime map contains exact observed paths and current commit.
- [ ] Every G0 dependency has an owner and verified status; missing auth, graph isolation or acquisition credentials explicitly blocks dependent work.
- [ ] Existing parent issue identities, statuses and due dates are checked without silently overwriting them.
- [ ] The three-week estimate is retained only if core PoC reuse and approved access are demonstrated.

## Verification

- Inspect at least one end-to-end source-to-publication/read path and one existing Hub request/result path.
- Record failed or unavailable checks with their reason; a zero-exit CLI is not a quality measurement.

## Evidence to attach

- Current-state manifest, exact integration map, baseline invocation/output reference, capability-gap register and scope decision.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

No new SSO, queue product, database replacement or claim that the old completeness defect is already fixed. An external dependency is not solved by writing a mock and marking this gate passed.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- No technical predecessor; this task establishes the delivery baseline.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `mandate`, `validation-gates`, `evidence`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
