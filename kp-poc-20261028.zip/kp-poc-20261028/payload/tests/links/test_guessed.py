"""Guessed links: the score formula, the three bands and the guessed share."""

from __future__ import annotations

from collections.abc import Sequence

import pytest
from sqlalchemy import Connection, select

from kp.clock import FixedClock
from kp.config import Thresholds
from kp.domain import ItemType, LinkKind, LinkState, Relation
from kp.links import (
    GuessItem,
    LinkScorer,
    LinkService,
    SimilarityPortError,
    TermOverlapSimilarity,
)
from kp.links.guessed import (
    WEIGHT_SEARCH_AGREEMENT,
    WEIGHT_SHARED_SCHEMA_FIELDS,
    WEIGHT_SHARED_TERMS,
)
from kp.store.schema import clause as clause_table
from kp.testing.dataset import SyntheticDataset
from links.builders import clause, requirement, spec, state_link, story
from links.seed import register_requirements

SHARED_TEXT = "inbound credit transfer currency"


class FixedSimilarity:
    """A similarity port that returns the same raw score for every candidate."""

    def __init__(self, raw: float, max_score: float = 1.0) -> None:
        self._raw = raw
        self._max = max_score

    @property
    def max_score(self) -> float:
        return self._max

    def agreement(self, query: str, candidates: Sequence[str]) -> list[float]:
        return [self._raw] * len(candidates)


class WrongCountSimilarity(FixedSimilarity):
    def agreement(self, query: str, candidates: Sequence[str]) -> list[float]:
        return [self._raw]


def _requirement_item(
    key: str = "REQ-1", fields: frozenset[str] = frozenset({"currency"})
) -> GuessItem:
    return GuessItem(ref=requirement(key), text=SHARED_TEXT, schema_fields=fields)


def _clause_item(
    number: str = "4.2.1", fields: frozenset[str] = frozenset({"currency"})
) -> GuessItem:
    return GuessItem(ref=clause(number), text=SHARED_TEXT, schema_fields=fields)


def test_us14_the_score_weights_are_half_a_third_and_a_fifth() -> None:
    assert (WEIGHT_SEARCH_AGREEMENT, WEIGHT_SHARED_SCHEMA_FIELDS, WEIGHT_SHARED_TERMS) == (
        0.50,
        0.30,
        0.20,
    )
    assert WEIGHT_SEARCH_AGREEMENT + WEIGHT_SHARED_SCHEMA_FIELDS + WEIGHT_SHARED_TERMS == 1.0


def test_us14_score_adds_the_three_weighted_parts() -> None:
    scorer = LinkScorer(FixedSimilarity(0.4))
    # Texts share all terms (1.0); the requirement names one field the clause also names (1.0).
    full = scorer.score(_requirement_item(), _clause_item())
    no_fields = scorer.score(_requirement_item(fields=frozenset()), _clause_item())
    half_terms = scorer.score(
        _requirement_item(),
        GuessItem(
            ref=clause("4.2.1"),
            text="inbound credit transfer",
            schema_fields=frozenset({"currency"}),
        ),
    )

    assert full.score == pytest.approx(0.5 * 0.4 + 0.3 * 1.0 + 0.2 * 1.0)
    assert no_fields.score == pytest.approx(0.5 * 0.4 + 0.2 * 1.0)
    assert half_terms.shared_terms == pytest.approx(0.75)
    assert half_terms.score == pytest.approx(0.5 * 0.4 + 0.3 * 1.0 + 0.2 * 0.75)
    assert "shared schema fields currency" in full.evidence
    assert "shared terms" in full.evidence


def test_us14_search_agreement_is_rescaled_to_zero_one_before_weighting() -> None:
    scaled = LinkScorer(FixedSimilarity(5.0, max_score=10.0)).score(
        _requirement_item(fields=frozenset()),
        GuessItem(ref=clause("4.2.1"), text="unrelated words"),
    )
    capped = LinkScorer(FixedSimilarity(25.0, max_score=10.0)).score(
        _requirement_item(fields=frozenset()),
        GuessItem(ref=clause("4.2.1"), text="unrelated words"),
    )

    assert scaled.search_agreement == pytest.approx(0.5)
    assert capped.search_agreement == 1.0


def test_us14_a_misbehaving_similarity_port_is_a_typed_error() -> None:
    with pytest.raises(SimilarityPortError, match="wrong number"):
        LinkScorer(WrongCountSimilarity(0.5)).score_all(
            _requirement_item(), [_clause_item("4.2.1"), _clause_item("4.2.2")]
        )
    with pytest.raises(SimilarityPortError, match="positive max_score"):
        LinkScorer(FixedSimilarity(0.5, max_score=0.0)).score(_requirement_item(), _clause_item())


def test_us14_local_term_overlap_scores_identical_texts_one_and_disjoint_texts_zero() -> None:
    similarity = TermOverlapSimilarity()

    scores = similarity.agreement(
        "Inbound credit transfers currencies",
        ["inbound credit transfer currency", "stone wall"],
    )

    assert similarity.max_score == 1.0
    assert scores[0] == pytest.approx(1.0)
    assert scores[1] == 0.0


@pytest.mark.parametrize(
    ("raw", "state"),
    [
        (1.0, LinkState.PROPOSED),
        (0.5, LinkState.PROPOSED),  # 0.75 exactly: proposed
        (0.4, LinkState.REVIEW),  # 0.70
        (0.1, LinkState.REVIEW),  # 0.55 exactly: review
        (0.0, None),  # 0.50: not kept
    ],
)
def test_us14_scores_fall_into_proposed_review_or_not_kept(
    loaded: Connection, clock: FixedClock, raw: float, state: LinkState | None
) -> None:
    # Full field and term overlap gives 0.30 + 0.20; agreement supplies the rest.
    service = LinkService(loaded, clock=clock, similarity=FixedSimilarity(raw))
    report = service.guess(Relation.CONSTRAINED_BY, [_requirement_item()], [_clause_item()])

    stored = service.store.open_links()
    if state is None:
        assert (stored, report.dropped) == ([], 1)
    else:
        (link,) = stored
        assert link.state is state
        assert link.kind is LinkKind.GUESSED
        assert link.score == pytest.approx(0.5 + 0.5 * raw)
        assert "search agreement" in link.evidence


def test_us14_proposed_links_carry_score_and_evidence_and_review_links_are_not_used(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock)
    report = service.guess(
        Relation.CONSTRAINED_BY,
        [_requirement_item("REQ-1")],
        [_clause_item("4.2.1"), _clause_item("4.2.2", fields=frozenset())],
    )

    (proposed,) = report.proposed
    assert proposed.state is LinkState.PROPOSED
    assert proposed.score is not None
    assert proposed.score >= 0.75
    assert "shared schema fields currency" in proposed.evidence
    assert [link.target_ref.key for link in service.store.in_use_links()] == ["2026.1:4.2.1"]
    # The second clause shares the terms but no field: score 0.5 + 0.2 = 0.70 -> review only.
    (waiting,) = service.review_list()
    assert waiting.target_ref.key == "2026.1:4.2.2"
    assert 0.55 <= (waiting.score or 0) < 0.75
    assert report.review == (waiting,)


def test_us14_the_register_requirements_find_their_clauses_by_text(
    loaded: Connection, clock: FixedClock, dataset: SyntheticDataset
) -> None:
    fields = ["currency", "amount", "creditor_account", "debtor_account", "reference"]
    rows = loaded.execute(
        select(clause_table.c.number, clause_table.c.title, clause_table.c.text).where(
            clause_table.c.edition == "2026.1"
        )
    ).all()
    clauses = [
        GuessItem.from_text(clause(row.number), f"{row.title}. {row.text}", fields) for row in rows
    ]
    requirements = [
        GuessItem.from_text(
            requirement(item.fields["Req ID"]),
            f"{item.fields['Title']}. {item.fields['Description']}",
            fields,
        )
        for item in register_requirements(dataset)[:4]
    ]
    service = LinkService(loaded, clock=clock)

    report = service.guess(Relation.CONSTRAINED_BY, requirements, clauses)

    proposed = {(link.source_ref.key, link.target_ref.key) for link in report.proposed}
    review = {(link.source_ref.key, link.target_ref.key) for link in report.review}
    assert ("REQ-002", "2026.1:4.2.2") in proposed
    assert ("REQ-003", "2026.1:4.2.3") in proposed
    assert ("REQ-001", "2026.1:4.2.1") in proposed | review
    assert not any(
        link.target_ref.key == "2026.1:4.2.4"
        for link in report.proposed
        if link.source_ref.key == "REQ-002"
    )
    assert report.dropped > 0


def test_us14_guessed_share_of_all_links_is_reported_against_the_limit(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock, similarity=FixedSimilarity(1.0))
    state_link(service, requirement("REQ-1"), Relation.CONSTRAINED_BY, clause("4.2.9"))

    one_guess = service.guess(
        Relation.CONSTRAINED_BY, [_requirement_item("REQ-2")], [_clause_item()]
    )
    two_guesses = service.guess(
        Relation.CONSTRAINED_BY, [_requirement_item("REQ-3")], [_clause_item("4.2.2")]
    )

    assert one_guess.guessed_share == pytest.approx(0.5)
    assert one_guess.share_within_limit
    assert two_guesses.guessed_share == pytest.approx(2 / 3)
    assert not two_guesses.share_within_limit
    assert two_guesses.guessed_share_limit == Thresholds().guessed_share_max


def test_us14_a_pair_that_is_already_stated_is_never_overwritten_by_a_guess(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock, similarity=FixedSimilarity(1.0))
    state_link(service, requirement("REQ-1"), Relation.CONSTRAINED_BY, clause("4.2.1"))

    report = service.guess(Relation.CONSTRAINED_BY, [_requirement_item()], [_clause_item()])

    assert report.already_stated == 1
    assert report.proposed == ()
    (link,) = service.store.in_use_links()
    assert link.kind is LinkKind.STATED


def test_us14_a_guess_that_later_scores_below_the_band_is_closed(
    loaded: Connection, clock: FixedClock
) -> None:
    pair = ([_requirement_item()], [_clause_item()])
    LinkService(loaded, clock=clock, similarity=FixedSimilarity(1.0)).guess(
        Relation.CONSTRAINED_BY, *pair
    )
    clock.set(clock.now().replace(hour=10))
    service = LinkService(loaded, clock=clock, similarity=FixedSimilarity(0.0))

    report = service.guess(Relation.CONSTRAINED_BY, *pair)

    assert report.dropped == 1
    assert service.store.in_use_links() == []
    assert (
        len(service.store.history(requirement("REQ-1"), Relation.CONSTRAINED_BY, clause("4.2.1")))
        == 1
    )


def test_us13_candidates_outside_the_model_are_rejected_not_scored(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock, similarity=FixedSimilarity(1.0))
    wrong_source = GuessItem(ref=story("PAY-1"), text=SHARED_TEXT)

    report = service.guess(Relation.CONSTRAINED_BY, [wrong_source], [_clause_item()])

    assert report.proposed == ()
    assert report.review == ()
    assert [r.origin for r in report.rejected] == ["PAY-1 constrained_by 2026.1:4.2.1"]
    assert service.store.open_links() == []


def test_us14_a_spec_can_be_guessed_to_derive_from_a_clause(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock, similarity=FixedSimilarity(1.0))
    drafted = GuessItem(ref=spec("S1"), text=SHARED_TEXT, schema_fields=frozenset({"currency"}))

    report = service.guess(Relation.DERIVED_FROM, [drafted], [_clause_item()])

    (link,) = report.proposed
    assert (link.source_ref.item_type, link.target_ref.item_type) == (
        ItemType.SPEC,
        ItemType.CLAUSE,
    )


def test_us14_schema_fields_are_found_in_prose_and_identifiers() -> None:
    item = GuessItem.from_text(
        clause("4.2.3"),
        "The Creditor-Account element and the currency_code must exist.",
        ["creditor_account", "currency", "amount"],
    )

    assert item.schema_fields == frozenset({"creditor_account"})
