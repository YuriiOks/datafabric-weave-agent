"""Cursor, paging and restart behaviour common to the snapshot-based readers (US-09 reader side)."""

from __future__ import annotations

import base64
import zlib
from pathlib import Path

import pytest

from kp.domain.enums import SourceKind
from kp.errors import SourceItemNotFoundError, SourceUnavailableError
from kp.sources import (
    CodeRepoReader,
    ConfluenceExportReader,
    DocumentLibraryReader,
    InvalidCursorError,
    InvalidReadRequestError,
    JiraExportReader,
    MalformedSourceDataError,
    RegulatoryRepoReader,
    SourceReader,
)
from kp.sources.snapshot import ScannedItem

from .support import drain, ids, key


def _snapshot_readers(data_root: Path) -> list[SourceReader]:
    return [
        DocumentLibraryReader(data_root / "library"),
        ConfluenceExportReader(data_root / "confluence", approved_label="approved"),
        RegulatoryRepoReader(data_root / "regulatory_repo"),
        CodeRepoReader(data_root / "code_repo"),
    ]


def test_every_reader_satisfies_the_source_reader_protocol(data_root: Path) -> None:
    readers = [*_snapshot_readers(data_root), JiraExportReader(data_root / "jira")]

    assert all(isinstance(reader, SourceReader) for reader in readers)
    assert [reader.kind for reader in readers] == [
        SourceKind.DOCUMENT_LIBRARY,
        SourceKind.CONFLUENCE,
        SourceKind.REGULATORY_REPO,
        SourceKind.GITHUB,
        SourceKind.JIRA,
    ]


def test_us09_second_sweep_with_nothing_changed_creates_no_work(data_root: Path) -> None:
    for reader in _snapshot_readers(data_root):
        _, cursor = drain(reader)

        items, again = drain(reader, cursor)

        assert items == []
        assert again == cursor


def test_us09_paging_one_item_at_a_time_reports_each_item_once(data_root: Path) -> None:
    for reader in _snapshot_readers(data_root):
        everything, _ = drain(reader)

        paged: list[tuple[str, str]] = []
        cursor: str | None = None
        while True:
            batch = reader.list_changed(cursor, limit=1)
            assert len(batch.items) <= 1
            paged.extend((i.key.item_id, i.key.version) for i in batch.items)
            cursor = batch.next_cursor
            if batch.exhausted:
                break

        assert sorted(paged) == sorted(ids(everything))
        assert len(paged) == len(set(paged))


def test_us09_stopped_run_continues_from_the_last_saved_page(data_root: Path) -> None:
    library = data_root / "library"
    first_page = DocumentLibraryReader(library).list_changed(None, limit=1)

    # A new process picks up the persisted cursor of the first page only.
    rest, _ = drain(DocumentLibraryReader(library), first_page.next_cursor, limit=1)

    everything, _ = drain(DocumentLibraryReader(library))
    assert first_page.exhausted is False
    assert ids(list(first_page.items)) | ids(rest) == ids(everything)
    assert ids(list(first_page.items)) & ids(rest) == set()


def test_us09_cursor_of_an_unprocessed_page_does_not_skip_its_items(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")
    first = reader.list_changed(None, limit=1)

    # The run died before saving the first page's cursor: the sweep starts over.
    again = reader.list_changed(None, limit=1)

    assert first.items == again.items


def test_a_cursor_reflects_only_the_pages_applied_so_far(data_root: Path) -> None:
    reader = CodeRepoReader(data_root / "code_repo")
    first = reader.list_changed(None, limit=2)

    rest = reader.list_changed(first.next_cursor, limit=100)

    assert {i.key.item_id for i in first.items}.isdisjoint({i.key.item_id for i in rest.items})
    assert rest.exhausted is True
    assert len(first.items) + len(rest.items) == 4


def test_empty_source_returns_an_empty_exhausted_batch(tmp_path: Path) -> None:
    batch = DocumentLibraryReader(tmp_path).list_changed(None)

    assert batch.items == ()
    assert batch.exhausted is True
    assert batch.next_cursor is not None


def test_missing_source_directory_raises_a_source_error(tmp_path: Path) -> None:
    with pytest.raises(SourceUnavailableError):
        DocumentLibraryReader(tmp_path / "gone").list_changed(None)


@pytest.mark.parametrize(
    "cursor",
    [
        "",
        "not-a-cursor",
        "snap1:***",
        "snap1:" + base64.urlsafe_b64encode(b"not zlib").decode("ascii"),
        "snap1:" + base64.urlsafe_b64encode(zlib.compress(b"[1, 2]")).decode("ascii"),
        "snap1:" + base64.urlsafe_b64encode(zlib.compress(b'{"a": "b"}')).decode("ascii"),
        "jira1:c|2026-10-01T09:00:00+00:00|",
    ],
)
def test_foreign_or_corrupt_cursor_is_refused(data_root: Path, cursor: str) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    with pytest.raises(InvalidCursorError):
        reader.list_changed(cursor)


def test_limit_below_one_is_refused(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    with pytest.raises(InvalidReadRequestError):
        reader.list_changed(None, limit=0)


def test_us09_cursor_larger_than_the_bound_is_refused_as_too_large_not_corrupt(
    data_root: Path,
) -> None:
    # Spaces compress to almost nothing but inflate past the 64 MB bound.
    payload = zlib.compress(b" " * (65 * 1024 * 1024))
    cursor = "snap1:" + base64.urlsafe_b64encode(payload).decode("ascii")

    with pytest.raises(InvalidCursorError, match="too large"):
        DocumentLibraryReader(data_root / "library").list_changed(cursor)


def test_us09_cursor_stays_small_enough_to_persist_after_every_page(tmp_path: Path) -> None:
    for number in range(300):
        folder = tmp_path / "src" / f"package_{number % 10}"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / f"module_{number}.py").write_text(f"value = {number}\n", encoding="utf-8")

    batch = CodeRepoReader(tmp_path).list_changed(None, limit=1000)

    assert batch.next_cursor is not None
    assert len(batch.next_cursor) < 300 * 100


class _CountingLibrary(DocumentLibraryReader):
    """A library reader that counts how often the whole source is scanned."""

    scans = 0

    def _scan(self) -> list[ScannedItem]:
        self.scans += 1
        return super()._scan()


def test_us09_listing_and_fetching_a_whole_sweep_scans_the_source_once(data_root: Path) -> None:
    reader = _CountingLibrary(data_root / "library")

    items, _ = drain(reader)
    fetched = [reader.fetch(item.key) for item in items]

    assert len(fetched) == len(items) > 1
    assert reader.scans == 1


def test_us09_a_key_missing_from_the_last_scan_triggers_one_new_scan(data_root: Path) -> None:
    library = data_root / "library"
    reader = _CountingLibrary(library)
    drain(reader)
    (library / "added.md").write_text("# Added\n", encoding="utf-8")

    fetched = reader.fetch(
        next(i.key for i in drain(_CountingLibrary(library))[0] if i.key.item_id == "added.md")
    )

    assert fetched.content == b"# Added\n"
    assert reader.scans == 2


def test_us09_bytes_changed_between_listing_and_fetch_are_not_returned(data_root: Path) -> None:
    repo = data_root / "code_repo"
    reader = CodeRepoReader(repo)
    items, _ = drain(reader)
    target = next(i.key for i in items if i.key.item_id == "src/payments/inbound.py")

    (repo / "src" / "payments" / "inbound.py").write_text("changed = True\n", encoding="utf-8")

    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(target)


def test_us09_a_duplicate_only_blocks_the_key_it_affects_when_fetching(
    data_root: Path,
) -> None:
    library = data_root / "library"
    (library / "copy.md").write_text("# Copy\n", encoding="utf-8")
    (library / "copy.meta.json").write_text(
        (library / "operating-guide.v2.meta.json").read_text(encoding="utf-8"), encoding="utf-8"
    )
    reader = DocumentLibraryReader(library)

    assert reader.fetch(key(SourceKind.DOCUMENT_LIBRARY, "escalation-note", "1")).content
    with pytest.raises(MalformedSourceDataError):
        reader.fetch(key(SourceKind.DOCUMENT_LIBRARY, "operating-guide", "2"))
    with pytest.raises(MalformedSourceDataError):
        reader.list_changed(None)
