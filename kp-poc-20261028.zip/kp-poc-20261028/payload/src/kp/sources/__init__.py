"""Content sources. The contract lives in :mod:`kp.sources.base`.

Five readers implement :class:`SourceReader` over local stand-in data, one per route:

* :class:`DocumentLibraryReader` - documents with approval metadata sidecars
* :class:`ConfluenceExportReader` - page exports; label and published version only
* :class:`JiraExportReader` - story exports; updated-time cursor with overlap
* :class:`RegulatoryRepoReader` - editions with manifests; unmerged editions never listed
* :class:`CodeRepoReader` - file tree with a content hash per file

The spec repository, where the platform's own spec pull requests land, is read by
:class:`kp.sources.spec_repo.SpecRepoReader` once a person has merged one (US-23).

:func:`create_reader` builds them from the settings. The attribute names each route reports are
in :mod:`kp.sources.attributes`.
"""

from kp.sources.base import ChangeBatch, ChangedItem, FetchedItem, ItemMetadata, SourceReader
from kp.sources.code_repo import CodeRepoReader
from kp.sources.confluence import ConfluenceExportReader
from kp.sources.document_library import DocumentLibraryReader
from kp.sources.errors import (
    InvalidCursorError,
    InvalidReadRequestError,
    MalformedSourceDataError,
)
from kp.sources.factory import RealReaderBuilder, StandInLocations, create_reader, create_readers
from kp.sources.jira import JiraExportReader
from kp.sources.regulatory import RegulatoryRepoReader

__all__ = [
    "ChangeBatch",
    "ChangedItem",
    "CodeRepoReader",
    "ConfluenceExportReader",
    "DocumentLibraryReader",
    "FetchedItem",
    "InvalidCursorError",
    "InvalidReadRequestError",
    "ItemMetadata",
    "JiraExportReader",
    "MalformedSourceDataError",
    "RealReaderBuilder",
    "RegulatoryRepoReader",
    "SourceReader",
    "StandInLocations",
    "create_reader",
    "create_readers",
]
