"""Catalogue version port that builds the canonical catalogue from a refresh's captures.

The publisher asks this port for the catalogue a candidate projects. The answer is
built here from exactly the artifacts the attempt captured: the acquired workbook
through the export reader, the acquired skills tree through the skill parser, then the
registry adapters, one identity catalogue and its persisted snapshot. Only a
``validated`` snapshot is returned; anything else refuses the candidate with the
build's own diagnostic reason, so a missing, failed, incomplete or too-old source can
never reach activation.

Every refusal is ``CatalogueSnapshotRefused``: the refresh worker maps only refresh
port errors, and the same captures would be refused again, so none of them is retried.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Mapping
from typing import Any, NoReturn

from pydantic import ValidationError

from app.recsys.acquisition.models import AcquiredGitSource, AcquiredWorkbook
from app.recsys.catalogue.builder import build_catalogue
from app.recsys.contracts.resolution import (
    CatalogueBuildResult,
    SnapshotState,
    SourceBatch,
)
from app.recsys.contracts.scope import PublicationScope
from app.recsys.contracts.sources import SourceAuthority, SourceManifest
from app.recsys.db.catalogue import CataloguePersistenceError, CatalogueRepository
from app.recsys.ingest import read_skills_repo
from app.recsys.publication.errors import CatalogueSnapshotRefused
from app.recsys.refresh.models import CapturedSource, SourceConfigurationSnapshot
from app.recsys.registry import INGEST_CODE_VERSION
from app.recsys.registry.catalogue_build import build_policy
from app.recsys.registry.excel_reader import (
    ExportError,
    ExportFormatUnavailable,
    ExportTables,
    read_export,
)
from app.recsys.registry.owner_rules import materialise_rules, server_tool_cells
from app.recsys.registry.source_records import build_source_batches

from .staging import ArtifactStaging, StagedArtifactMismatch, StagedArtifactMissing

logger = logging.getLogger(__name__)


def _refuse(reason: str) -> NoReturn:
    raise CatalogueSnapshotRefused(reason)


def attest_batch(
    batch: SourceBatch,
    captured: Mapping[SourceAuthority, SourceManifest],
) -> SourceBatch:
    """Re-issue one build batch under the manifest its source was captured with.

    The registry adapters stamp each batch with a diagnostic manifest that declares
    completeness, freshness and ordering unknown, which is what keeps a dry-run
    candidate ``captured``. In a refresh the source was acquired under a registration
    that establishes those properties, so the batch takes them from the capture:
    completeness, freshness, deletion semantics, capture time, resolved revision and
    the revision of every collection the batch carries. The content hash stays the
    build's own digest, because every record's locator is bound to it.

    :param batch: A batch produced by the registry adapters.
    :param captured: The capture manifest of each authority in this attempt.
    :return: The same records under the captured manifest.
    :raises CatalogueSnapshotRefused: If the capture cannot vouch for the batch.
    """
    if batch.manifest is None:
        _refuse("source_failed")
    capture = captured.get(batch.authority)
    if capture is None:
        _refuse("required_source_missing")
    if capture.scope != batch.scope:
        _refuse("scope_invariant")
    revisions = []
    for revision in batch.manifest.collection_revisions:
        captured_revision = capture.revision_for(revision.collection)
        if captured_revision is None:
            _refuse("collection_not_captured")
        revisions.append(captured_revision)
    try:
        manifest = SourceManifest(
            authority=batch.authority,
            scope=batch.scope,
            source_configuration_version=capture.source_configuration_version,
            resolved_revision=capture.resolved_revision,
            content_hash=batch.manifest.content_hash,
            captured_at=capture.captured_at,
            completeness=capture.completeness,
            freshness=capture.freshness,
            deletion_semantics=capture.deletion_semantics,
            collection_revisions=revisions,
            row_counts=dict(batch.manifest.row_counts),
            quarantine_reasons=list(batch.manifest.quarantine_reasons),
        )
        return SourceBatch(
            scope=batch.scope,
            authority=batch.authority,
            manifest=manifest,
            failure=None,
            expected_record_occurrence_ids=batch.expected_record_occurrence_ids,
            expected_reference_occurrence_ids=batch.expected_reference_occurrence_ids,
            records=list(batch.records),
        )
    except ValidationError as error:
        logger.error(
            "Captured manifest cannot attest a catalogue batch",
            extra={"authority": batch.authority.value, "error_count": error.error_count()},
        )
        raise CatalogueSnapshotRefused("capture_manifest_invalid") from error


def verify_revision_vector(
    result: CatalogueBuildResult,
    captured: Mapping[SourceAuthority, SourceManifest],
) -> None:
    """Refuse a candidate whose stored source manifests disagree with the captures.

    The publisher derives the descriptor's revision vector from the captures but does
    not compare it with the manifests the catalogue snapshot stores; that comparison
    belongs where the real source set is wired. A candidate that reuses a source from
    an earlier build is refused too: every source it carries must have been captured
    by this attempt.

    :param result: The validated build.
    :param captured: The capture manifest of each authority in this attempt.
    :raises CatalogueSnapshotRefused: On any disagreement.
    """
    if result.reused_sources:
        _refuse("source_reuse_not_captured")
    for batch in result.source_batches:
        if batch.manifest is None:
            _refuse("source_failed")
        capture = captured.get(batch.authority)
        if capture is None:
            _refuse("required_source_missing")
        for revision in batch.manifest.collection_revisions:
            if capture.revision_for(revision.collection) != revision:
                _refuse("capture_revision_mismatch")


def _manifests_by_authority(
    captures: tuple[CapturedSource, ...],
) -> dict[SourceAuthority, SourceManifest]:
    manifests: dict[SourceAuthority, SourceManifest] = {}
    for capture in captures:
        authority = capture.manifest.authority
        if authority in manifests:
            _refuse("authority_claimed_twice")
        manifests[authority] = capture.manifest
    return manifests


class CapturedCatalogueVersion:
    """``CatalogueVersionPort`` over the registered workbook and skills sources."""

    def __init__(
        self,
        pool: Any,
        staging: ArtifactStaging,
        *,
        repository: CatalogueRepository | None = None,
        code_version: str = INGEST_CODE_VERSION,
    ) -> None:
        """Create the port.

        :param pool: The PostgreSQL pool the catalogue snapshot is written to.
        :param staging: Where the source adapters left this attempt's artifacts.
        :param repository: Catalogue writer; defaults to one over ``pool``.
        :param code_version: Version of the deterministic build rules.
        """
        self._staging = staging
        self._repository = repository if repository is not None else CatalogueRepository(pool)
        self._code_version = code_version

    async def resolve(
        self,
        captures: tuple[CapturedSource, ...],
        snapshot: SourceConfigurationSnapshot,
    ) -> str:
        """Build, persist and return the validated catalogue for these captures.

        :param captures: The attempt's captures, one per configured adapter.
        :param snapshot: The configuration snapshot the job was admitted with.
        :return: The catalogue id of a validated snapshot in the snapshot's scope.
        :raises CatalogueSnapshotRefused: If no validated catalogue can be built.
        """
        references = [capture.artifact_reference for capture in captures]
        try:
            workbook, skills_tree = self._staged_sources(captures, snapshot)
            result = await asyncio.to_thread(
                self._build, workbook, skills_tree, captures, snapshot.scope
            )
        finally:
            self._staging.discard(references)
        try:
            written = await self._repository.write_candidate(result)
        except CataloguePersistenceError as error:
            logger.error(
                "Refresh catalogue candidate could not be persisted",
                extra={"catalogue_id": result.snapshot.catalogue_id},
            )
            raise CatalogueSnapshotRefused("catalogue_persistence_refused") from error
        logger.info(
            "Refresh catalogue candidate persisted",
            extra={"catalogue_id": written.catalogue_id, "status": written.status},
        )
        return written.catalogue_id

    def _staged_sources(
        self,
        captures: tuple[CapturedSource, ...],
        snapshot: SourceConfigurationSnapshot,
    ) -> tuple[AcquiredWorkbook, AcquiredGitSource]:
        adapter_ids = [capture.adapter_id for capture in captures]
        if len(set(adapter_ids)) != len(adapter_ids) or set(adapter_ids) != set(
            snapshot.adapter_ids
        ):
            _refuse("source_set_mismatch")
        workbooks: list[AcquiredWorkbook] = []
        trees: list[AcquiredGitSource] = []
        for capture in captures:
            try:
                entry = self._staging.get(capture.artifact_reference, capture.artifact_digest)
            except StagedArtifactMissing:
                _refuse("artifact_unavailable")
            except StagedArtifactMismatch:
                _refuse("artifact_digest_mismatch")
            acquired = entry.acquired
            if (
                entry.source_id != capture.adapter_id
                or getattr(acquired, "manifest", None) != capture.manifest
            ):
                _refuse("capture_manifest_mismatch")
            if isinstance(acquired, AcquiredWorkbook):
                workbooks.append(acquired)
            elif isinstance(acquired, AcquiredGitSource):
                trees.append(acquired)
            else:
                _refuse("artifact_unavailable")
        if len(workbooks) != 1 or len(trees) != 1:
            _refuse("source_set_incomplete")
        return workbooks[0], trees[0]

    def _build(
        self,
        workbook: AcquiredWorkbook,
        skills_tree: AcquiredGitSource,
        captures: tuple[CapturedSource, ...],
        scope: PublicationScope,
    ) -> CatalogueBuildResult:
        try:
            return self._build_checked(workbook, skills_tree, captures, scope)
        except CatalogueSnapshotRefused:
            raise
        except Exception as error:
            # Build rules raise typed errors for contradictory inputs; the type is
            # logged, the message is not (it can quote source rows).
            logger.error(
                "Refresh catalogue build failed",
                extra={"error_type": type(error).__name__},
            )
            raise CatalogueSnapshotRefused("catalogue_build_failed") from error

    def _build_checked(
        self,
        workbook: AcquiredWorkbook,
        skills_tree: AcquiredGitSource,
        captures: tuple[CapturedSource, ...],
        scope: PublicationScope,
    ) -> CatalogueBuildResult:
        captured = _manifests_by_authority(captures)
        tables = _read_workbook(workbook)
        try:
            skills, _ = read_skills_repo(skills_tree.snapshot_path)
        except (OSError, ValueError) as error:
            raise CatalogueSnapshotRefused("skills_repo_unreadable") from error
        adapter = build_source_batches(tables, skills, scope)
        adapter.batches = [attest_batch(batch, captured) for batch in adapter.batches]
        rules = materialise_rules([], server_tool_cells(tables.mcps))
        policy = build_policy(scope, adapter, rules)
        result = build_catalogue(adapter.batches, policy, [], code_version=self._code_version)
        if result.snapshot.state is not SnapshotState.validated:
            reason = result.snapshot.diagnostic_reason or "snapshot_not_validated"
            logger.warning(
                "Refresh catalogue candidate is not validated",
                extra={"catalogue_id": result.snapshot.catalogue_id, "reason": reason},
            )
            _refuse(reason)
        verify_revision_vector(result, captured)
        return result


def _read_workbook(workbook: AcquiredWorkbook) -> ExportTables:
    try:
        return read_export(workbook.snapshot_path)
    except ExportFormatUnavailable as error:
        # The deployed image ships the dependency-free CSV reader only.
        raise CatalogueSnapshotRefused("export_reader_unavailable") from error
    except (ExportError, OSError) as error:
        raise CatalogueSnapshotRefused("export_unreadable") from error
