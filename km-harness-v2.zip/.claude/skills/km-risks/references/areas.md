# Risk areas and rating scale

Every area below gets at least one register row. If the source run for an area is missing,
write a row "area not yet checked: <missing run>", label Unverified, and add a question.
An area with no finding after a real check gets one row stating what was searched and that
nothing was found, so a reader can tell "checked" from "not looked at".

## security
- How callers are identified on each route and how identity reaches the data layer.
- How administrator rights are granted today, and whether directory groups could replace it.
- Credentials in code, configuration, images and scripts (record the path only).
- Access control on every route and every list query, and on publication to consumers.
- Privacy and restricted-data checks before any document is processed.
- Audit of access and change: what is recorded, who can alter it.
- Upload handling: type checks, size limits, server-chosen names.
- Services and ports reachable without sign-in.
- Sign-in abuse: lockout of other accounts, rate limits behind a proxy, forged-request
  protection actually checked.
- Model calls: unauthenticated routes that spend model budget, untrusted text sent to a model,
  generated queries and how they are kept read-only.

## isolation
- Separation between domains, sub-domains and namespaces in storage paths, tables, graphs
  and search indexes.
- Tables or graphs created at run time: who names them and what scope they carry.
- Fit with a multi-tenant, multi-region target with one control plane.
- Shared credentials or shared services that cross a scope boundary.
- What happens on delete: orphans, cascades, leftovers in other stores.

## scalability
- Heavy steps (parse, chunk, embed, graph load): synchronous or queued, size limits, timeouts.
- Single-process or single-instance parts; work done on the request path.
- Full scans, unbounded lists, missing paging.
- Silent caps or truncation that make partial data look complete.
- Storage growth, retries, back-pressure, schedules.

## versioning
- Versions of documents, ontologies and published products: kept, immutable, restorable.
- What an edit after publication does.
- Schema changes: migrations, compatibility, API versions.
- Concurrent edits to the same record.

## maintainability
- Tests: what exists, what the main flows lack. Health checks and monitoring.
- API description and hand-made configuration.
- Status words in documents versus behaviour in code (mock-up, live, planned).
- Open technology choices, such as two candidate stores for the same job.
- Health of derived data: index refresh, ontology status, import resolution, inference runs.
- Work that depends on one person, or on a story owned by someone else.

## Scale
- Impact high: leak of data or a credential, access across a domain boundary, or a block for
  PILOT_USE_CASE. Medium: wrong or lost data that can be recovered, or a delay to one story.
  Low: extra cost or effort only.
- Likelihood high: Observed in code today or already happening. Medium: reachable with the
  planned use. Low: needs unusual conditions or a second failure.
- Owner roles: platform owner, security reviewer, domain architect, delivery lead, data owner,
  ontologist, steward. Never a person name.
- Treatment is one proposed step, not a design. The design belongs to the story document.
