## What changed

- A component's "Used by" list shows only the components that use it. A skill that another skill depends on no longer appears there; it stays visible on the dependent skill's own page under "Depends on".
- Detail pages count the declarations a component made that matched no catalogue component. An agent whose declared skills or MCP tools did not match now reports them as withheld (state `unresolved_withheld` with a count) instead of looking as if it declared nothing. Only counts leave the server; the raw names stay in the review ledger.

## Why

- The "Used by" query read every incoming link, dependency links included, while the contract describes it as the list of users.
- Unmatched declarations are kept in the review ledger and never become link rows, but the detail page counted only unmatched link rows, so its withheld count was always 0. On the current pre-production export about 21,600 declarations are affected, nearly all of them MCP tools.

## How to verify

1. Ingest an export where skill A depends on skill B and agent X uses skill B. B's page lists X under "Used by" and nothing else; A's page lists B under "Depends on".
2. An agent with 3 MCP tool declarations that match no MCP server: its uses disclosure is `unresolved_withheld` with a withheld count of 3. If one more of its declarations does match, the resolved count is 1 and the withheld count stays 3.
3. Negative case: a component with no declarations still reads `no_declarations` with both counts at 0.
4. The detail response carries no raw declaration text for the withheld ones.

## Review focus

- Ledger entries are counted by owner component id and `kind = 'reference'`. An entry whose declaring record has no accepted identity has no owner and is counted nowhere, as before.
- An unmatched declaration has no target, so the "Used by" withheld count can only come from link rows; only usage link types count there now.
