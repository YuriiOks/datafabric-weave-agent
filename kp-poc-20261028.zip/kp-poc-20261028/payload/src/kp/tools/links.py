"""The ``links`` tool: items up to three steps away, each marked stated or guessed."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from kp.domain import DomainModel, ItemRef, ItemType, LinkKind, LinkState, Relation
from kp.tools.access import ToolContext
from kp.tools.ports import SHOWN_LINK_STATES, LinkedItem, LinkPort
from kp.tools.registry import RegisteredTool, ToolArguments, ToolOutcome, define_tool

NAME = "links"
MAX_STEPS = 3


class LinksArguments(ToolArguments):
    """Arguments of ``links``. There is deliberately no domain argument."""

    item_type: Annotated[ItemType, Field(description="Kind of the start item")]
    key: Annotated[
        str,
        Field(min_length=1, max_length=255, description="Natural key, e.g. 2026.1:4.2.1"),
    ]
    steps: Annotated[int, Field(ge=1, le=MAX_STEPS, description="How far to follow links")] = (
        MAX_STEPS
    )


class LinkedItemView(DomainModel):
    """One linked item as shown to the agent."""

    item_type: ItemType
    key: str
    steps: int
    relation: Relation
    direction: Literal["outgoing", "incoming"]
    via_type: ItemType
    via_key: str
    kind: LinkKind
    state: LinkState
    score: float | None
    evidence: str


class LinksOutput(DomainModel):
    """The ``links`` result. ``message`` explains an empty list."""

    root_type: ItemType
    root_key: str
    steps: int
    items: tuple[LinkedItemView, ...]
    stated: int
    guessed: int
    filtered_out: int
    message: str | None


def links_tool(links: LinkPort) -> RegisteredTool:
    """Build the ``links`` tool.

    :param links: Link store
    :return: The registrable tool
    """

    def handle(context: ToolContext, arguments: LinksArguments) -> ToolOutcome:
        root = ItemRef(item_type=arguments.item_type, key=arguments.key)
        traversal = links.traverse(root, steps=arguments.steps, domains=context.domains)
        context.require_visible(traversal.root_domain)
        usable = [
            item
            for item in traversal.items
            if item.state in SHOWN_LINK_STATES and item.steps <= arguments.steps
        ]
        visible, hidden = context.split_visible(usable, lambda item: item.domain)
        shown = tuple(_view(item) for item in sorted(visible, key=_order))
        filtered_out = traversal.filtered_out + hidden
        output = LinksOutput(
            root_type=root.item_type,
            root_key=root.key,
            steps=arguments.steps,
            items=shown,
            stated=sum(1 for item in shown if item.kind is LinkKind.STATED),
            guessed=sum(1 for item in shown if item.kind is LinkKind.GUESSED),
            filtered_out=filtered_out,
            message=_message(arguments.steps, shown_count=len(shown), filtered_out=filtered_out),
        )
        return ToolOutcome(
            payload=output.model_dump(mode="json"),
            items_returned=len(shown),
            filtered_count=filtered_out,
        )

    return define_tool(
        NAME,
        "Follow links from an item (a clause, requirement, story, spec, code or test) up to "
        "three steps in either direction. Each item shows whether its link was stated by a "
        "source or guessed (proposed, with score and evidence).",
        LinksArguments,
        handle,
    )


def _order(item: LinkedItem) -> tuple[int, str, str]:
    return (item.steps, item.item.item_type.value, item.item.key)


def _view(item: LinkedItem) -> LinkedItemView:
    return LinkedItemView(
        item_type=item.item.item_type,
        key=item.item.key,
        steps=item.steps,
        relation=item.relation,
        direction="outgoing" if item.outgoing else "incoming",
        via_type=item.via.item_type,
        via_key=item.via.key,
        kind=item.kind,
        state=item.state,
        score=item.score,
        evidence=item.evidence,
    )


def _message(steps: int, *, shown_count: int, filtered_out: int) -> str | None:
    if shown_count:
        return None
    if filtered_out:
        return "Every linked item lies in a domain the caller may not read."
    return f"No links are recorded for this item within {steps} steps."
