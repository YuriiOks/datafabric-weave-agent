---
pack_id: "bpc-sep26-v1"
local_id: "MCP-02"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1347"
summary: "Admit versioned MCP Excel occurrences under an explicit source contract"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-10"
planned_due: "2026-09-11"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["MCP-01","CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-mcp-02"
architecture_sections: ["ingestion","source-refresh","publication"]
---

# Admit versioned MCP Excel occurrences under an explicit source contract

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1347**. Local reference **MCP-02** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-10 → 2026-09-11 (D2–D3)**.
- Recommendation extension: **2026-09-10 → 2026-09-11 (D2–D3)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Workbook rows cannot become catalogue facts until their source contract, scope, and field provenance are explicit. Produce validated, versioned MCP source occurrences for the CORE-02 DTO and source-manifest contracts.

## Scope and contract

Input is an immutable approved workbook and MCP-01 mapping. Validate only approved sheets/header aliases; emit accepted or quarantined occurrences with source descriptor, stable row/field locator, supplied MCP ID, scope/partition, field provenance, and outcome. Preserve duplicate IDs as separate occurrences for MCP-03. Invalid/incomplete input is never a deletion instruction; source content is parsed as data without URL fetch, connection, or execution.

## Steps

1. Implement the approved MCP field mapping and explicit unknown-field handling.
2. Validate completeness, row shape, required identity fields, scope, and supported types.
3. Emit CORE-02 manifest metadata and validation/quarantine outcomes.
4. Preserve original field locations for MCP-03 and MCP-04.

## Acceptance and verification

- Valid rows are traceable to immutable input and field locators.
- Missing required sheet/header, unknown mandatory relationship field, invalid scope, or incomplete source blocks the affected source contract.
- Duplicate MCP IDs remain separate occurrences with no row-order canonicalisation.
- Missing description is visible quality/evidence state, not deletion.
- Parser paths perform no execution or network fetch.

## Evidence, blockers and exclusions

Attach mapping, manifest, validation/quarantine report, and examples for valid, missing-header, duplicate-ID, and incomplete-source cases. Block on unresolved MCP-01 authority/header decisions. Identity, projection activation, and ranking remain out of scope.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [MCP-01](MCP-01.md) must finish its stated contract boundary before this task starts.
- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `ingestion`, `source-refresh`, `publication`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
