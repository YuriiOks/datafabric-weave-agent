"""Write-back: spec pull requests, the Jira status update and the citation check.

``WriteTools`` is the write surface for the write MCP server. Publishers (local git, REST),
the Jira clients (REST, dry run), the citation check and the reference drafter sit behind
small ports so the integrator can swap any of them.

Wiring left to the integrator: register ``kp draft-spec`` with
``kp.writeback.cli.add_parser(subparsers)``, and pass the caller's readable domains to every
write call (``WriteToolCall.domains`` / ``CallContext.domains``). The real-repository tests
need a working git; point ``KP_GIT_BINARY`` at one (they fail instead of skipping when the
``CI`` variable is set).
"""

from kp.writeback.citations import (
    CitationReport,
    Problem,
    StatementCheck,
    canonical_reference,
    check_citations,
    extract_references,
    extract_rule_statements,
)
from kp.writeback.cli import DraftSpecReport, DraftSpecRuntime, add_parser, draft_spec, run
from kp.writeback.drafter import TemplateDrafter
from kp.writeback.errors import (
    BranchNotPermittedError,
    InvalidStoryKeyError,
    JiraFieldNotPermittedError,
    JiraTransientError,
    JiraUpdateError,
    PathNotPermittedError,
    PublishError,
    RepositoryNotPermittedError,
    SpecNotDraftableError,
    SpecNotDraftedError,
    SpecNotFoundError,
    StoryDomainNotPermittedError,
    StoryNotFoundError,
    WriteBackError,
)
from kp.writeback.github import GitHubRestPublisher
from kp.writeback.jira import DryRunJiraUpdater, JiraRestClient
from kp.writeback.limits import WriteGuard, branch_for_story, spec_id_for_story
from kp.writeback.local_git import LocalGitPublisher, resolve_git_binary
from kp.writeback.models import (
    SPEC_DRAFTED_STATUS,
    CallContext,
    JiraApplied,
    JiraStoryUpdate,
    MergeResult,
    PublishRequest,
    PublishResult,
    PublishSpecArguments,
    PublishSpecResult,
    UpdateJiraArguments,
    UpdateJiraResult,
)
from kp.writeback.ports import (
    AuditSink,
    CoverageLookup,
    DraftedSpec,
    Drafter,
    DraftRequest,
    EvidenceItem,
    JiraUpdater,
    Retrieval,
    Retriever,
    SessionRetrievals,
    SpecMerger,
    SpecPublisher,
    WriteToolCall,
    WriteToolDescriptor,
    WriteToolResult,
)
from kp.writeback.retrieval import (
    DatabaseRetriever,
    InMemorySessionRetrievals,
    LinkGraphCoverage,
    load_story,
)
from kp.writeback.service import (
    JiraOutcome,
    JiraSyncService,
    PublishOutcome,
    RetryPolicy,
    SpecPublishingService,
)
from kp.writeback.store import (
    DatabaseAuditSink,
    DatabaseReferenceResolver,
    SpecRepository,
    TemplateRepository,
)
from kp.writeback.template import parse_template
from kp.writeback.tools import PUBLISH_SPEC, UPDATE_JIRA, WriteTools

__all__ = [
    "PUBLISH_SPEC",
    "SPEC_DRAFTED_STATUS",
    "UPDATE_JIRA",
    "AuditSink",
    "BranchNotPermittedError",
    "CallContext",
    "CitationReport",
    "CoverageLookup",
    "DatabaseAuditSink",
    "DatabaseReferenceResolver",
    "DatabaseRetriever",
    "DraftRequest",
    "DraftSpecReport",
    "DraftSpecRuntime",
    "DraftedSpec",
    "Drafter",
    "DryRunJiraUpdater",
    "EvidenceItem",
    "GitHubRestPublisher",
    "InMemorySessionRetrievals",
    "InvalidStoryKeyError",
    "JiraApplied",
    "JiraFieldNotPermittedError",
    "JiraOutcome",
    "JiraRestClient",
    "JiraStoryUpdate",
    "JiraSyncService",
    "JiraTransientError",
    "JiraUpdateError",
    "JiraUpdater",
    "LinkGraphCoverage",
    "LocalGitPublisher",
    "MergeResult",
    "PathNotPermittedError",
    "Problem",
    "PublishError",
    "PublishOutcome",
    "PublishRequest",
    "PublishResult",
    "PublishSpecArguments",
    "PublishSpecResult",
    "RepositoryNotPermittedError",
    "Retrieval",
    "Retriever",
    "RetryPolicy",
    "SessionRetrievals",
    "SpecMerger",
    "SpecNotDraftableError",
    "SpecNotDraftedError",
    "SpecNotFoundError",
    "SpecPublisher",
    "SpecPublishingService",
    "SpecRepository",
    "StatementCheck",
    "StoryDomainNotPermittedError",
    "StoryNotFoundError",
    "TemplateDrafter",
    "TemplateRepository",
    "UpdateJiraArguments",
    "UpdateJiraResult",
    "WriteBackError",
    "WriteGuard",
    "WriteToolCall",
    "WriteToolDescriptor",
    "WriteToolResult",
    "WriteTools",
    "add_parser",
    "branch_for_story",
    "canonical_reference",
    "check_citations",
    "draft_spec",
    "extract_references",
    "extract_rule_statements",
    "load_story",
    "parse_template",
    "resolve_git_binary",
    "run",
    "spec_id_for_story",
]
