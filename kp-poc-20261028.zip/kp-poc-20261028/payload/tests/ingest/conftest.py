"""Fixtures of the ingest tests: thresholds, item versions and fetched items."""

from __future__ import annotations

from datetime import date

import pytest

from ingest.ingest_support import NOW, RUN_ID, FetchFactory, ItemFactory
from kp.config import Thresholds
from kp.domain import ApprovalState, DocumentDetails, SourceItemVersion, SourceKind
from kp.sources.base import FetchedItem, ItemMetadata


@pytest.fixture
def thresholds() -> Thresholds:
    """The default provisional thresholds."""
    return Thresholds()


@pytest.fixture
def make_item() -> ItemFactory:
    """Build an admitted item version (not yet stored)."""

    def build(
        *,
        item_id: str = "item-1",
        version: str = "1",
        source: SourceKind = SourceKind.REGULATORY_REPO,
        media_type: str = "application/pdf",
        title: str = "Payments Rulebook",
        approval_state: ApprovalState = ApprovalState.ADMITTED,
        effective_date: date | None = date(2026, 11, 16),
        details: DocumentDetails | None = None,
    ) -> SourceItemVersion:
        return SourceItemVersion(
            source=source,
            item_id=item_id,
            version=version,
            native_id=f"native-{item_id}",
            content_sha256="0" * 64,
            media_type=media_type,
            title=title,
            raw_location=f"raw/{item_id}/{version}",
            fetched_at=NOW,
            run_id=RUN_ID,
            approval_state=approval_state,
            effective_date=effective_date,
            details=details or DocumentDetails(domain="payments"),
        )

    return build


@pytest.fixture
def fetched() -> FetchFactory:
    """Wrap bytes as the sweep would hand them over."""

    def build(item: SourceItemVersion, content: bytes) -> FetchedItem:
        return FetchedItem(
            key=item.key,
            content=content,
            metadata=ItemMetadata(
                native_id=item.native_id, media_type=item.media_type, title=item.title
            ),
        )

    return build
