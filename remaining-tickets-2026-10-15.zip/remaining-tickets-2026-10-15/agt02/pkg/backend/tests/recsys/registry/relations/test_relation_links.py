"""Every published relation carries a stable key and the evidence behind it.

Repeated declarations of one relation stay one link; the repetition is visible as more
than one evidence entry, never as a second edge.
"""

from __future__ import annotations

import unittest

from app.recsys.contracts import LinkType
from app.recsys.registry.relations.diff import relation_facts
from app.recsys.registry.relations.evidence import evidence_digest, ordered_evidence
from app.recsys.registry.relations.keys import SHA256_HEX_PATTERN
from tests.recsys.registry.relations._builds import (
    OTHER_ROW,
    WIDGET_HELPER,
    agent_usage,
    build,
    build_export,
    relation,
    widget_row,
)

ALPHA = "skill:alpha-helper"
RESOLVED = {"resolved_exact", "resolved_reviewed_mapping"}


class RelationLinkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.build, cls.links = build()

    def test_every_link_carries_a_key_a_digest_and_its_evidence(self):
        self.assertTrue(self.links)
        for link in self.links:
            with self.subTest(src=link.src_id, dst=link.dst_id):
                self.assertRegex(link.relation_key or "", SHA256_HEX_PATTERN)
                self.assertTrue(link.evidence)
                self.assertEqual(link.evidence_digest, evidence_digest(link.evidence))
                self.assertEqual(link.evidence, ordered_evidence(link.evidence))

    def test_every_evidence_entry_names_its_source_position_and_rule(self):
        for link in self.links:
            for entry in link.evidence:
                with self.subTest(src=link.src_id, dst=link.dst_id, entry=entry):
                    self.assertTrue(entry.authority)
                    self.assertTrue(entry.collection)
                    self.assertTrue(entry.structural_locator)
                    self.assertTrue(entry.field_name)
                    self.assertTrue(entry.raw_token or entry.raw_token_digest)
                    self.assertIn(entry.resolution_outcome, RESOLVED)
                    self.assertIn(entry.matched_index, link.matched_indexes)
                    self.assertIsNotNone(entry.rule_id)
                    self.assertIsNotNone(entry.rule_version)

    def test_relation_keys_are_unique(self):
        self.assertEqual(len(relation_facts(self.links)), len(self.links))

    def test_a_rebuild_keeps_every_key_and_every_digest(self):
        _, again = build()
        self.assertEqual(
            {link.relation_key: link.evidence_digest for link in self.links},
            {link.relation_key: link.evidence_digest for link in again},
        )

    def test_only_the_closed_link_types_are_ever_published(self):
        # Recommended, executed, approved and native-Hub relationships are not link
        # types at all, so nothing can publish one.
        self.assertEqual(
            {link_type.value for link_type in LinkType},
            {"USES_SKILL", "USES_MCP", "USES_KNOWLEDGE", "DEPENDS_ON_SKILL", "ALLOWS_MCP"},
        )
        self.assertLessEqual({link.link_type for link in self.links}, set(LinkType))
        self.assertTrue(all(link.resolved for link in self.links))


class AggregationTests(unittest.TestCase):
    def test_a_repeated_declaration_is_one_relation_with_two_entries(self):
        _, links = build_export(agent_usage(widget_row("alpha-helper,alpha-helper")))

        matching = relation(links, WIDGET_HELPER, ALPHA)
        self.assertEqual(len(matching), 1)
        link = matching[0]
        self.assertIs(link.link_type, LinkType.uses_skill)
        self.assertEqual([entry.token_ordinal for entry in link.evidence], [0, 1])
        self.assertEqual(len({entry.structural_locator for entry in link.evidence}), 1)
        self.assertEqual(len({entry.field_name for entry in link.evidence}), 1)

    def test_repetition_changes_the_digest_and_keeps_the_key(self):
        _, once = build_export(agent_usage(widget_row("alpha-helper")))
        _, twice = build_export(agent_usage(widget_row("alpha-helper,alpha-helper")))

        (single,) = relation(once, WIDGET_HELPER, ALPHA)
        (double,) = relation(twice, WIDGET_HELPER, ALPHA)
        self.assertEqual(len(single.evidence), 1)
        self.assertEqual(single.relation_key, double.relation_key)
        self.assertNotEqual(single.evidence_digest, double.evidence_digest)

    def test_moving_the_declaration_to_another_row_keeps_the_key(self):
        _, first = build_export(agent_usage(widget_row()))
        _, moved = build_export(agent_usage(OTHER_ROW, widget_row()))

        (before,) = relation(first, WIDGET_HELPER, ALPHA)
        (after,) = relation(moved, WIDGET_HELPER, ALPHA)
        self.assertEqual(before.relation_key, after.relation_key)
        self.assertNotEqual(
            before.evidence[0].structural_locator, after.evidence[0].structural_locator
        )
        self.assertNotEqual(before.evidence_digest, after.evidence_digest)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
