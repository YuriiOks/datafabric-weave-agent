"""Seam: choosing where specs are published and where the Jira update goes.

Local mode writes a git repository under the data folder when a working git binary exists, and
otherwise records the publication in a small file (:class:`DryRunSpecPublisher`). The Jira side
is a dry run in local mode. Which publisher was chosen is reported, so a run states what it
really did.

Real mode has no writer yet. The gateway speaks JSON-RPC tool calls with a caller-identity
token, a use-case marker and a per-tool route, and the pull request and ticket calls have not
been proven against it (that is what ``kp connectivity discover`` is for). A plain REST writer
would fail with an opaque 401 or 404, so real mode refuses to choose one.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from kp.adapters.dry_run_publisher import DryRunSpecPublisher
from kp.clock import Clock
from kp.config import Mode, Settings
from kp.errors import ConfigurationError
from kp.sources.spec_repo import MergedSpecSource
from kp.writeback import (
    DryRunJiraUpdater,
    LocalGitPublisher,
    resolve_git_binary,
)
from kp.writeback.ports import JiraUpdater, SpecPublisher

LOCAL_REPOSITORY_FOLDER = "spec-repo"
DRY_RUN_RECORD = "spec-publications.json"


class PublisherKind(StrEnum):
    """Which publisher a run uses."""

    LOCAL_GIT = "local_git"
    DRY_RUN = "dry_run"


@dataclass(frozen=True, slots=True)
class Writers:
    """The two outward writers and a label for the publisher chosen."""

    publisher: SpecPublisher
    jira: JiraUpdater
    kind: PublisherKind


def choose_writers(settings: Settings, clock: Clock) -> Writers:
    """Choose the writers for the mode and the machine.

    :param settings: Platform settings
    :param clock: Time source for commit dates
    :return: The publisher, the Jira updater and which publisher kind was chosen
    :raises kp.errors.ConfigurationError: In real mode, which has no write route yet
    """
    repository = (settings.spec_repo or "").strip() or None
    if settings.mode is Mode.REAL:
        raise ConfigurationError(
            "Writing specs and ticket updates is not available with KP_MODE=real yet: it "
            "needs the gateway tool calls that the first live discover run confirms. Use "
            "local mode for drafting, or wait for the real write route"
        )
    git_binary = resolve_git_binary(preferred=settings.git_binary)
    if git_binary is None:
        return Writers(
            DryRunSpecPublisher(
                settings.data_dir / DRY_RUN_RECORD, repository=repository, clock=clock
            ),
            DryRunJiraUpdater(),
            PublisherKind.DRY_RUN,
        )
    return Writers(
        LocalGitPublisher.initialise(
            settings.data_dir / LOCAL_REPOSITORY_FOLDER,
            git_binary,
            clock=clock,
            repository=repository,
        ),
        DryRunJiraUpdater(),
        PublisherKind.LOCAL_GIT,
    )


def open_spec_source(settings: Settings, clock: Clock) -> MergedSpecSource | None:
    """The spec repository the local publisher keeps, when it exists. Nothing is created.

    The real route reads its spec repository through the gateway, which has no reader yet, so
    real mode has none here.

    :param settings: Platform settings
    :param clock: Time source for the publisher
    :return: Where the merged specs can be listed from, or ``None`` when nothing was published
    """
    if settings.mode is Mode.REAL:
        return None
    repository = (settings.spec_repo or "").strip() or None
    git_binary = resolve_git_binary(preferred=settings.git_binary)
    checkout = settings.data_dir / LOCAL_REPOSITORY_FOLDER
    if git_binary is not None and (checkout / ".git").exists():
        return LocalGitPublisher(checkout, git_binary, clock=clock, repository=repository)
    record = settings.data_dir / DRY_RUN_RECORD
    if record.exists():
        return DryRunSpecPublisher(record, repository=repository, clock=clock)
    return None
