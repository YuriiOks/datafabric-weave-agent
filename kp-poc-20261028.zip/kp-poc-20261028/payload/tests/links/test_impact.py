"""A rule change shows what is affected, up to three steps, stated or guessed (US-13)."""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest
from sqlalchemy import Connection

from kp.clock import FixedClock
from kp.domain import ClauseRef, ItemType, Link, LinkKind, LinkState, Relation
from kp.errors import InvalidClauseRefError
from kp.links import LinkCandidate, LinkService, LinkStatistics, UnknownClauseError
from links.builders import (
    clause,
    code,
    guess_link,
    item,
    requirement,
    spec,
    state_link,
    story,
    verifying_test,
)

CHANGED = "2026.1:4.2.1"


@pytest.fixture
def web(service: LinkService) -> LinkService:
    """Clause 4.2.1 with stated and guessed neighbours at one to four steps."""
    state_link(service, requirement("REQ-1"), Relation.CONSTRAINED_BY, clause("4.2.1"))
    state_link(service, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    state_link(service, spec("S2"), Relation.DERIVED_FROM, requirement("REQ-1"))
    state_link(service, story("PAY-1"), Relation.SPECIFIED_BY, spec("S1"))
    state_link(service, spec("S1"), Relation.IMPLEMENTED_BY, code("a.py::f"))
    state_link(service, code("a.py::f"), Relation.VERIFIED_BY, verifying_test("t.py::test_f"))
    state_link(service, spec("S2"), Relation.IMPLEMENTED_BY, code("b.py::g"))
    state_link(service, code("b.py::g"), Relation.VERIFIED_BY, verifying_test("t.py::test_g"))
    state_link(
        service, clause("4.2.1"), Relation.RESOLVES_TO, item(ItemType.SCHEMA_FIELD, "s.json#cur")
    )
    guess_link(service, spec("S3"), Relation.DERIVED_FROM, clause("4.2.1"))
    guess_link(service, spec("S3"), Relation.IMPLEMENTED_BY, code("c.py::h"))
    return service


def test_us13_changed_clause_lists_requirements_stories_specs_code_and_tests_within_three_steps(
    web: LinkService,
) -> None:
    report = web.impact(CHANGED)

    assert {i.ref.key for i in report.of_type(ItemType.REQUIREMENT)} == {"REQ-1"}
    assert {i.ref.key for i in report.of_type(ItemType.STORY)} == {"PAY-1"}
    assert {i.ref.key for i in report.of_type(ItemType.SPEC)} == {"S1", "S2", "S3"}
    assert {i.ref.key for i in report.of_type(ItemType.CODE)} == {"a.py::f", "b.py::g", "c.py::h"}
    assert {i.ref.key for i in report.of_type(ItemType.TEST)} == {"t.py::test_f"}
    assert {i.ref.key for i in report.of_type(ItemType.SCHEMA_FIELD)} == {"s.json#cur"}
    assert report.message is None


def test_us13_items_more_than_three_steps_away_are_left_out_unless_asked_for(
    web: LinkService,
) -> None:
    default = web.impact(CHANGED)
    deeper = web.impact(CHANGED, max_steps=4)

    assert "t.py::test_g" not in {i.ref.key for i in default.items}
    assert "t.py::test_g" in {i.ref.key for i in deeper.items}
    assert max(i.distance for i in default.items) == 3
    assert default.max_steps == 3


def test_us13_each_item_shows_whether_its_link_was_stated_or_guessed(web: LinkService) -> None:
    report = web.impact(CHANGED)
    by_key = {i.ref.key: i for i in report.items}

    assert by_key["REQ-1"].kind is LinkKind.STATED
    assert by_key["t.py::test_f"].kind is LinkKind.STATED
    assert by_key["S3"].kind is LinkKind.GUESSED
    assert by_key["c.py::h"].kind is LinkKind.GUESSED
    assert by_key["S3"].path[0].kind is LinkKind.GUESSED
    assert by_key["S3"].path[0].score == 0.8
    assert (report.stated_count, report.guessed_count) == (len(report.items) - 2, 2)


def test_us13_a_stated_path_wins_over_a_shorter_guessed_one(web: LinkService) -> None:
    guess_link(web, spec("S2"), Relation.DERIVED_FROM, clause("4.2.1"))

    by_key = {i.ref.key: i for i in web.impact(CHANGED).items}

    assert by_key["S2"].kind is LinkKind.STATED
    assert by_key["S2"].distance == 2
    assert [step.to_key for step in by_key["S2"].path] == ["REQ-1", "S2"]


def test_us13_the_path_shows_which_way_each_link_was_crossed(web: LinkService) -> None:
    by_key = {i.ref.key: i for i in web.impact(CHANGED).items}

    (first, second, third) = by_key["t.py::test_f"].path
    assert (first.from_key, first.relation, first.forward) == (
        CHANGED,
        Relation.DERIVED_FROM,
        False,
    )
    assert (second.relation, second.forward, second.to_key) == (
        Relation.IMPLEMENTED_BY,
        True,
        "a.py::f",
    )
    assert (third.relation, third.forward) == (Relation.VERIFIED_BY, True)


def test_us13_other_clauses_and_templates_are_never_walked_through(web: LinkService) -> None:
    state_link(web, spec("S1"), Relation.DERIVED_FROM, clause("4.2.2"))
    state_link(web, spec("S1"), Relation.USES_TEMPLATE, item(ItemType.TEMPLATE, "TPL"))
    state_link(web, spec("S9"), Relation.USES_TEMPLATE, item(ItemType.TEMPLATE, "TPL"))

    reported = {i.ref.key for i in web.impact(CHANGED).items}

    assert not {"2026.1:4.2.2", "TPL", "S9"} & reported


def test_us13_a_clause_with_no_links_says_so_instead_of_returning_an_empty_list(
    web: LinkService,
) -> None:
    report = web.impact("2026.1:6.2.1")

    assert report.items == ()
    assert report.message is not None
    assert "No links are recorded for clause 2026.1:6.2.1" in report.message
    assert "not proof of no impact" in report.message


def test_us13_links_waiting_for_review_do_not_count_as_links(service: LinkService) -> None:
    guess_link(
        service,
        spec("S1"),
        Relation.DERIVED_FROM,
        clause("4.2.1"),
        score=0.6,
        state=LinkState.REVIEW,
    )

    report = service.impact(CHANGED)

    assert report.items == ()
    assert report.message is not None


def test_us13_the_spoken_form_and_the_clause_object_are_accepted(web: LinkService) -> None:
    spoken = web.impact("2026.1 clause 4.2.1")
    parsed = web.impact(ClauseRef.parse(CHANGED))

    assert spoken.clause == CHANGED
    assert spoken == parsed


def test_us13_a_clause_that_is_neither_loaded_nor_linked_is_an_error(service: LinkService) -> None:
    with pytest.raises(UnknownClauseError, match=r"9\.9\.9"):
        service.impact("2026.1:9.9.9")
    with pytest.raises(InvalidClauseRefError):
        service.impact("not a reference")
    with pytest.raises(ValueError, match="at least 1"):
        service.impact(CHANGED, max_steps=0)


def test_us13_impact_can_be_read_as_the_links_were_earlier(
    service: LinkService, clock: FixedClock
) -> None:
    before = clock.now()
    clock.set(before + timedelta(days=1))
    state_link(service, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))

    earlier = service.impact(CHANGED, as_at=before + timedelta(hours=1))
    now = service.impact(CHANGED)

    assert earlier.items == ()
    assert earlier.message is not None
    assert {i.ref.key for i in now.items} == {"S1"}


class ListReader:
    """A link reader over a fixed list, as a graph database adapter would offer."""

    def __init__(self, links: list[Link]) -> None:
        self._links = links

    def in_use_links(self, as_at: datetime | None = None) -> list[Link]:
        return self._links

    def statistics(self) -> LinkStatistics:
        return LinkStatistics(
            in_use=len(self._links),
            stated=len(self._links),
            guessed=0,
            review=0,
            checked=len(self._links),
            nonconforming=0,
            average_guessed_score=None,
        )


def test_us13_queries_read_links_through_the_reader_interface(
    loaded: Connection, clock: FixedClock
) -> None:
    link = LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1")).to_link(
        "lnk-1", clock.now()
    )
    service = LinkService(loaded, clock=clock, reader=ListReader([link]))

    report = service.impact(CHANGED)

    assert [i.ref.key for i in report.items] == ["S1"]
    assert service.statistics().in_use == 1
