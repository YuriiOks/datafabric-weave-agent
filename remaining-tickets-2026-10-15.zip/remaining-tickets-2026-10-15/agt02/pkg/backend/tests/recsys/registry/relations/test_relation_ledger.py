"""An unresolved reference stays visible in the review ledger and never becomes an edge.

Each case checks both halves: no link is produced, and exactly one ledger entry names
the outcome, the declaring component and the relation kind it would have produced.
"""

from __future__ import annotations

import unittest

from app.recsys.contracts import LinkType, ResolutionOutcome
from app.recsys.registry.ledger import LedgerEntry, ReviewLedger
from tests.recsys.registry.relations._builds import (
    WIDGET_HELPER,
    agent_usage,
    build,
    build_export,
    widget_row,
)

RESOLVED = {
    ResolutionOutcome.resolved_exact.value,
    ResolutionOutcome.resolved_reviewed_mapping.value,
}

#: Three registrations that collapse onto one scoped source key.
THREE_ROW_COLLISION = (
    "ID,Name,Description,Tools\n"
    "widget-hub,Widget Hub,Use when widgets must be looked up.,widget_search\n"
    "Widget-Hub,Widget Hub Copy,A second registration of the hub.,\n"
    "WIDGET-HUB,Widget Hub Third,A third registration of the hub.,\n"
)


def _references(ledger: ReviewLedger, raw_value: str) -> list[LedgerEntry]:
    """:return: The ledger's reference entries carrying one raw value."""
    return [
        entry
        for entry in ledger.entries
        if entry.kind == "reference" and entry.raw_value == raw_value
    ]


class UnresolvedReferenceTests(unittest.TestCase):
    def test_an_unknown_skill_is_a_visible_missing_reference_and_no_edge(self):
        result, links = build_export(agent_usage(widget_row("no-such-skill")))

        self.assertEqual(
            [link for link in links if link.link_type is LinkType.uses_skill], []
        )
        (entry,) = _references(result.ledger, "no-such-skill")
        self.assertEqual(entry.resolution_outcome, ResolutionOutcome.missing.value)
        self.assertEqual(entry.link_type, LinkType.uses_skill.value)
        self.assertEqual(entry.owner_component_id, WIDGET_HELPER)
        self.assertEqual(entry.as_dict()["resolution_outcome"], "missing")
        self.assertEqual(entry.as_dict()["link_type"], "USES_SKILL")

    def test_a_skill_named_in_the_mcp_column_does_not_bind_to_the_skill(self):
        result, links = build_export(agent_usage(widget_row("", "alpha-helper")))

        self.assertEqual(
            [link for link in links if link.link_type is LinkType.uses_mcp], []
        )
        entries = [
            entry
            for entry in _references(result.ledger, "alpha-helper")
            if entry.link_type == LinkType.uses_mcp.value
        ]
        self.assertEqual(len(entries), 1)
        self.assertNotIn(entries[0].resolution_outcome, RESOLVED)
        self.assertEqual(entries[0].owner_component_id, WIDGET_HELPER)

    def test_a_three_row_collision_is_one_ambiguous_reference_with_three_candidates(self):
        result, links = build_export(
            {
                **agent_usage(widget_row("alpha-helper", "widget-hub")),
                "mcp_list.csv": THREE_ROW_COLLISION,
            }
        )

        self.assertEqual(
            [link for link in links if link.link_type is LinkType.uses_mcp], []
        )
        (entry,) = _references(result.ledger, "widget-hub")
        self.assertEqual(entry.resolution_outcome, ResolutionOutcome.ambiguous.value)
        self.assertEqual(len(entry.members), 3)
        self.assertEqual(entry.owner_component_id, WIDGET_HELPER)
        self.assertEqual(entry.link_type, LinkType.uses_mcp.value)


class LedgerFieldTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result, _ = build()

    def test_every_reference_entry_names_an_unresolved_outcome_and_its_link_type(self):
        references = [e for e in self.result.ledger.entries if e.kind == "reference"]
        self.assertTrue(references)
        outcomes = {outcome.value for outcome in ResolutionOutcome} - RESOLVED
        link_types = {link_type.value for link_type in LinkType}
        for entry in references:
            with self.subTest(entry=entry):
                self.assertIn(entry.resolution_outcome, outcomes)
                # A declaration that names no relation kind has nothing to name here.
                self.assertIn(entry.link_type, link_types | {None})
        self.assertTrue(any(entry.link_type is not None for entry in references))

    def test_every_ambiguous_reference_lists_its_candidates(self):
        for entry in self.result.ledger.entries:
            if entry.resolution_outcome == ResolutionOutcome.ambiguous.value:
                with self.subTest(entry=entry):
                    self.assertGreaterEqual(len(entry.members), 2)

    def test_record_entries_carry_no_reference_fields(self):
        records = [e for e in self.result.ledger.entries if e.kind == "record"]
        for entry in records:
            with self.subTest(entry=entry):
                self.assertIsNone(entry.resolution_outcome)
                self.assertIsNone(entry.owner_component_id)
                self.assertIsNone(entry.link_type)
                self.assertNotIn("resolution_outcome", entry.as_dict())


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
