"""The ``rule_as_at`` tool: the text of a clause as it stood on a date."""

from __future__ import annotations

from datetime import date
from typing import Annotated

from pydantic import Field, field_validator

from kp.domain import DomainModel, select_edition_as_at
from kp.domain.clause_ref import parse_clause_number
from kp.tools.access import ToolContext
from kp.tools.errors import NoEditionInForceError, RuleNotFoundError
from kp.tools.ports import RulePort
from kp.tools.registry import RegisteredTool, ToolArguments, ToolOutcome, define_tool

NAME = "rule_as_at"


class RuleAsAtArguments(ToolArguments):
    """Arguments of ``rule_as_at``. There is deliberately no domain argument."""

    number: Annotated[str, Field(max_length=64, description="Clause number, e.g. 4.2.1")]
    as_at: Annotated[
        date | None, Field(description="Read the rule as at this date; default is today")
    ] = None

    @field_validator("number")
    @classmethod
    def _is_clause_number(cls, value: str) -> str:
        parse_clause_number(value)
        return value


class RuleOutput(DomainModel):
    """The ``rule_as_at`` result."""

    reference: str
    edition: str
    number: str
    title: str
    text: str
    page: int
    char_start: int
    char_end: int
    effective_date: date
    superseded_from: date | None
    withdrawn_from: date | None
    as_at: date
    domain: str | None


def rule_as_at_tool(rules: RulePort) -> RegisteredTool:
    """Build the ``rule_as_at`` tool.

    :param rules: Rulebook editions and clauses
    :return: The registrable tool
    """

    def handle(context: ToolContext, arguments: RuleAsAtArguments) -> ToolOutcome:
        as_at = arguments.as_at or context.clock.today()
        edition = select_edition_as_at(rules.editions(), as_at)
        if edition is None:
            raise NoEditionInForceError(f"No edition was in force on {as_at.isoformat()}")
        found = rules.clause(edition.label, arguments.number)
        if found is None:
            # "No such clause" is only an answer for a caller who may read the edition. For
            # anyone else it would tell whether a clause exists there, so it is a refusal, the
            # same one an existing clause of that edition gets.
            context.require_visible(rules.edition_domain(edition.label))
            raise RuleNotFoundError(
                f"Edition {edition.label} has no clause {arguments.number} "
                f"(as at {as_at.isoformat()})"
            )
        context.require_visible(found.domain)
        clause = found.clause
        output = RuleOutput(
            reference=clause.ref.format(),
            edition=edition.label,
            number=clause.ref.number,
            title=clause.title,
            text=clause.text,
            page=clause.page,
            char_start=clause.char_start,
            char_end=clause.char_end,
            effective_date=edition.effective_date,
            superseded_from=edition.superseded_from,
            withdrawn_from=edition.withdrawn_from,
            as_at=as_at,
            domain=found.domain,
        )
        return ToolOutcome(payload=output.model_dump(mode="json"), items_returned=1)

    return define_tool(
        NAME,
        "Read one clause as it stood on a date: the edition in force that day, never the date "
        "it was loaded. Fails when no edition was in force; it never falls back to another.",
        RuleAsAtArguments,
        handle,
    )
