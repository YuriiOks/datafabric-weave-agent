"""US-10 ranking pieces: BM25, the embedder port, batching, fusion and the vector switch."""

from __future__ import annotations

import math
from collections.abc import Sequence
from datetime import date

import pytest

from kp.domain import EMBEDDING_DIMENSIONS, SourceKind
from kp.search import (
    EMBEDDING_BATCH_SIZE,
    EmbeddingError,
    HashingEmbedder,
    PassageStore,
    SearchSettings,
    embed_pending,
    embed_texts,
)
from kp.search.embedding import HASHING_MODEL_VERSION, cosine_ranking
from kp.search.fusion import RRF_CONSTANT, RRF_DEPTH, reciprocal_rank_fusion
from kp.search.keyword import Bm25Index
from kp.search.passages import DocumentText, page_passages
from kp.search.tokens import analyze
from search.search_support import SearchWorld, add_source_item, save_passages

AFTER_SWITCH = date(2026, 11, 16)


class RecordingEmbedder:
    """Delegates to the hashing embedder and records the size of every batch."""

    def __init__(self, model_version: str = "recording-v1") -> None:
        self._inner = HashingEmbedder()
        self._model_version = model_version
        self.batches: list[int] = []

    @property
    def model_version(self) -> str:
        return self._model_version

    def embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        self.batches.append(len(texts))
        return self._inner.embed(texts)


class SynonymEmbedder:
    """Puts 'car' words on axis 0 and everything else on axis 1: meaning without shared terms."""

    model_version = "synonym-v1"

    def embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        vectors = []
        for text in texts:
            vector = [0.0] * EMBEDDING_DIMENSIONS
            words = set(text.lower().split())
            vector[0 if words & {"car", "automobile"} else 1] = 1.0
            vectors.append(tuple(vector))
        return vectors


class WrongSizeEmbedder:
    model_version = "bad-v1"

    def embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return [(1.0, 2.0) for _ in texts]


def test_us10_bm25_ranks_the_document_with_more_and_rarer_matches_first() -> None:
    index = Bm25Index(
        [
            ("a", analyze("currency of inbound transfers")),
            ("b", analyze("inbound transfers inbound transfers inbound")),
            ("c", analyze("settlement cycle")),
        ]
    )

    ranked = index.search(analyze("currency inbound"), limit=10)

    assert [doc for doc, _ in ranked] == ["a", "b"]
    assert ranked[0][1] > ranked[1][1] > 0


def test_us10_bm25_ignores_documents_with_no_matching_term_and_is_deterministic() -> None:
    index = Bm25Index([("b", ["x"]), ("a", ["x"]), ("c", ["y"])])

    assert index.search(["x"], limit=10)[0][0] == "a"
    assert [doc for doc, _ in index.search(["x"], limit=10)] == ["a", "b"]
    assert index.search(["zzz"], limit=10) == []
    assert len(index) == 3


def test_us10_analyzer_stems_plurals_and_keeps_clause_numbers() -> None:
    assert analyze("Currencies of the inbound transfers, clause 4.2.1.") == [
        "currency",
        "inbound",
        "transfer",
        "clause",
        "4.2.1",
    ]


def test_us10_hashing_embedder_gives_768_normalised_deterministic_vectors() -> None:
    embedder = HashingEmbedder()

    first = embedder.embed(["inbound credit transfer currency"])[0]
    second = HashingEmbedder().embed(["inbound credit transfer currency"])[0]

    assert len(first) == EMBEDDING_DIMENSIONS == 768
    assert first == second
    assert math.isclose(math.sqrt(sum(v * v for v in first)), 1.0)
    assert embedder.model_version == HASHING_MODEL_VERSION


def test_us10_hashing_embedder_places_similar_texts_closer() -> None:
    embedder = HashingEmbedder()
    query, near, far = embedder.embed(
        [
            "currency of inbound credit transfers",
            "an inbound credit transfer may use euro currency",
            "records are kept for ten years",
        ]
    )

    ranked = cosine_ranking(query, [("near", near), ("far", far)], limit=5)

    assert ranked[0][0] == "near"


def test_us10_empty_text_embeds_to_the_zero_vector_and_never_ranks() -> None:
    zero = HashingEmbedder().embed(["the of and"])[0]

    assert set(zero) == {0.0}
    assert cosine_ranking(zero, [("a", (1.0,) * 3)], limit=5) == []
    assert cosine_ranking((1.0, 0.0), [("a", (0.0, 0.0))], limit=5) == []


def test_us10_embedding_goes_out_in_batches_of_96() -> None:
    embedder = RecordingEmbedder()

    vectors = embed_texts(embedder, [f"text {n}" for n in range(200)])

    assert EMBEDDING_BATCH_SIZE == 96
    assert embedder.batches == [96, 96, 8]
    assert len(vectors) == 200


def test_us10_embedder_returning_wrong_vectors_is_a_typed_error() -> None:
    with pytest.raises(EmbeddingError):
        embed_texts(WrongSizeEmbedder(), ["a"])


def test_us10_embedding_pending_passages_records_the_model_version(world: SearchWorld) -> None:
    embedder = RecordingEmbedder()

    with world.database.transaction() as connection:
        first = embed_pending(connection, embedder)
        second = embed_pending(connection, embedder)
        passage = PassageStore(connection).get("clause:2026.1:4.2.1")
        count = PassageStore(connection).count()

    assert first == count
    assert second == 0
    assert max(embedder.batches) == 96
    assert passage is not None
    assert passage.model_version == "recording-v1"
    assert passage.embedding is not None
    assert len(passage.embedding) == 768


def test_us10_a_new_model_version_re_embeds_everything(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        embed_pending(connection, RecordingEmbedder("v1"))
        again = embed_pending(connection, RecordingEmbedder("v2"))
        count = PassageStore(connection).count()

    assert again == count


def test_us10_reciprocal_rank_fusion_uses_top_50_and_constant_60() -> None:
    assert (RRF_DEPTH, RRF_CONSTANT) == (50, 60)
    keyword = [f"k{n}" for n in range(60)]
    keyword[1] = "shared"
    vector = ["shared", *[f"v{n}" for n in range(60)]]

    fused = reciprocal_rank_fusion([keyword, vector])

    assert fused["shared"] == pytest.approx(1 / 62 + 1 / 61)
    assert fused["k0"] == pytest.approx(1 / 61)
    assert "k50" not in fused
    assert "k49" in fused
    assert "v48" in fused
    assert "v49" not in fused


def test_us10_vector_side_is_off_by_default_even_when_vectors_exist(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        embed_pending(connection, HashingEmbedder())

    response = world.service().search(
        "which currency may inbound transfers use", as_at=AFTER_SWITCH
    )

    assert response.vector_used is False
    assert all(h.vector_rank is None for h in response.hits)


def test_us10_vector_side_contributes_when_switched_on(world: SearchWorld) -> None:
    service = world.service(SearchSettings(vector_enabled=True))
    assert service.embed_pending() > 0

    response = service.search("which currency may inbound transfers use", as_at=AFTER_SWITCH)

    assert response.vector_used is True
    assert response.hits[0].reference == "2026.1:4.2.1"
    assert response.hits[0].keyword_rank is not None
    assert response.hits[0].vector_rank is not None


def test_us10_rebuild_index_embeds_when_the_vector_side_is_on(world: SearchWorld) -> None:
    report = world.service(SearchSettings(vector_enabled=True)).rebuild_index()

    assert report.embedded == report.clauses


def test_us10_vector_side_finds_a_passage_that_shares_no_term_with_the_question(
    world: SearchWorld,
) -> None:
    document = DocumentText(
        SourceKind.DOCUMENT_LIBRARY, "garage", "1", "automobile loan", domain="payments"
    )
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "garage", "1")
        save_passages(connection, page_passages(document))
    keyword_only = world.service()
    with_vector = world.service(SearchSettings(vector_enabled=True), SynonymEmbedder())
    with_vector.embed_pending()

    assert not keyword_only.search("car", as_at=AFTER_SWITCH).hits
    hits = with_vector.search("car", as_at=AFTER_SWITCH).hits
    assert [h.item_id for h in hits] == ["garage"]
    assert hits[0].keyword_rank is None
    assert hits[0].vector_rank == 1


def test_us10_vectors_from_another_model_version_are_not_used(world: SearchWorld) -> None:
    world.service(SearchSettings(vector_enabled=True), RecordingEmbedder("old")).embed_pending()
    service = world.service(SearchSettings(vector_enabled=True), RecordingEmbedder("new"))

    response = service.search("currency", as_at=AFTER_SWITCH)

    assert response.vector_used is False
    assert response.hits


def test_us10_embed_pending_is_a_no_op_when_the_vector_side_is_off(world: SearchWorld) -> None:
    assert world.service().embed_pending() == 0
