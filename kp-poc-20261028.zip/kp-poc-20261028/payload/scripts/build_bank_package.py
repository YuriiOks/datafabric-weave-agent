"""Build the single-zip package of the knowledge platform for the bank workstation.

The package is one folder, then one zip of it::

    kp-poc-<YYYYMMDD>/
        install.py          standard library only; verifies SHA256SUMS first
        README-PACKAGE.txt  apply order and expected result
        SHA256SUMS          over every other file
        payload/            the deliverable tree, written to the install target

Before anything is written, every file is scrubbed. The build fails, writes nothing and prints
only ``path:line: rule`` (never the text that matched) when it finds:

* a non-ASCII byte in a text file;
* a match of the ``bank_hosts`` or ``staff_ids`` expressions of the local patterns file, which is
  read from the path given on the command line and is never copied into the package;
* an ``http`` or ``https`` URL other than localhost, 127.0.0.1, example.com and example.org
  (``--allow-url-host`` adds an explicit exception, announced in the output);
* an email address other than ``@example.com`` (``--allow-email-domain`` likewise);
* a string shaped like a token or a private key.

Nothing is uploaded or sent anywhere. Usage::

    python scripts/build_bank_package.py --patterns PATH [--out-root DIR] [--date YYYYMMDD]
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import shutil
import sys
import zipfile
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

PACKAGE_PREFIX = "kp-poc-"
PAYLOAD_DIR = "payload"
CHECKSUM_FILE = "SHA256SUMS"
README_FILE = "README-PACKAGE.txt"
INSTALL_FILE = "install.py"
INSTALL_TEMPLATE = "bank_install_template.py"

DELIVERABLE_DIRS = ("src", "tests", "fixtures", "scripts", "docs")
DELIVERABLE_FILES = (
    "pyproject.toml",
    "README.md",
    "ARCHITECTURE.md",
    "INSTALL-WORKSTATION.md",
    ".env.example",
    ".gitignore",
)

EXCLUDED_DIR_NAMES = frozenset(
    {
        ".venv",
        ".git",
        "__pycache__",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "htmlcov",
        "build",
        "dist",
        "kp-demo",
        "var",
    }
)
EXCLUDED_FILE_NAMES = frozenset({"SPEC.md", ".coverage", ".DS_Store", "kp-local.db"})
EXCLUDED_SUFFIXES = (".pyc", ".db", ".db-journal", ".egg-info")
KEPT_ENV_FILE = ".env.example"

BINARY_SUFFIXES = frozenset({".pdf", ".xlsx", ".docx", ".png", ".zip"})
ARCHIVE_SUFFIXES = frozenset({".xlsx", ".docx", ".zip"})
ALLOWED_URL_DOMAINS = ("localhost", "127.0.0.1", "example.com", "example.org")
ALLOWED_EMAIL_DOMAIN = "example.com"
EXECUTABLE_SUFFIXES = (".sh",)

EXIT_OK = 0
EXIT_SCRUB_FAILED = 1
EXIT_BAD_INPUT = 2

_URL = re.compile(r"https?://[^\s\"'`<>)\]},;]+", re.IGNORECASE)
_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@((?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,})")
_SECRET_SHAPES: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "secret-shaped:code-host-token",
        re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_\w{40,})"),
    ),
    ("secret-shaped:api-key", re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_-]{20,}")),
    ("secret-shaped:cloud-key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("secret-shaped:chat-token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("secret-shaped:jwt", re.compile(r"\beyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{10,}")),
    ("secret-shaped:private-key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("secret-shaped:bearer", re.compile(r"\bBearer\s+[\w.-]{24,}")),
)


class PackagingError(Exception):
    """Base of every error this script raises on purpose."""


class PatternsError(PackagingError):
    """The local patterns file is missing, unreadable or unusable."""


class ProjectError(PackagingError):
    """The project tree lacks something the package needs."""


@dataclass(frozen=True, slots=True)
class Violation:
    """One scrub finding. It names the place and the rule, never the matched text.

    :ivar path: Path of the file inside the package payload
    :ivar line: One-based line, or 0 for a finding about the path itself
    :ivar rule: Short name of the rule
    """

    path: str
    line: int
    rule: str

    def __str__(self) -> str:
        where = f"{self.path}:{self.line}" if self.line else self.path
        return f"{where}: {self.rule}"


class ScrubFailedError(PackagingError):
    """The scrub found something; the build stopped before writing anything."""

    def __init__(self, violations: Sequence[Violation]) -> None:
        super().__init__(f"scrub found {len(violations)} problem(s)")
        self.violations: tuple[Violation, ...] = tuple(violations)


@dataclass(frozen=True, slots=True)
class ScrubRules:
    """The expressions that must not occur anywhere in the package.

    :ivar bank_hosts: Expressions for bank host names
    :ivar staff_ids: Expressions for staff identifiers
    :ivar url_domains: Hosts and parent domains a URL may point to. The default is localhost,
        127.0.0.1, example.com and example.org; each extra entry is an explicit decision
    :ivar email_domains: Domains an email address may use; the default is example.com
    """

    bank_hosts: tuple[re.Pattern[str], ...]
    staff_ids: tuple[re.Pattern[str], ...]
    url_domains: tuple[str, ...] = ALLOWED_URL_DOMAINS
    email_domains: tuple[str, ...] = (ALLOWED_EMAIL_DOMAIN,)


@dataclass(frozen=True, slots=True)
class SourceFile:
    """One file of the deliverable tree.

    :ivar relative: Path inside the project, with forward slashes
    :ivar source: Where it is read from
    """

    relative: str
    source: Path


@dataclass(frozen=True, slots=True)
class BuildOptions:
    """What to build and where.

    :ivar project_root: The project folder
    :ivar out_root: Folder that receives the package folder and the zip
    :ivar patterns_file: The local patterns file (read only; never copied)
    :ivar build_date: The date that names the package
    :ivar extra_url_domains: URL hosts or parent domains allowed beyond the defaults (empty by
        default: the scrub is strict unless the caller names an exception)
    :ivar extra_email_domains: Email domains allowed beyond example.com
    """

    project_root: Path
    out_root: Path
    patterns_file: Path
    build_date: date
    extra_url_domains: tuple[str, ...] = ()
    extra_email_domains: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BuildResult:
    """What a build produced.

    :ivar package_dir: The package folder
    :ivar zip_path: The single zip
    :ivar payload_files: Number of files in the payload
    :ivar zip_size: Size of the zip in bytes
    :ivar zip_sha256: SHA-256 of the zip
    """

    package_dir: Path
    zip_path: Path
    payload_files: int
    zip_size: int
    zip_sha256: str


# --- patterns ----------------------------------------------------------------------------------


def _compile_group(raw: object, key: str) -> tuple[re.Pattern[str], ...]:
    if not isinstance(raw, list) or not raw:
        raise PatternsError(f"patterns file: '{key}' must be a non-empty list")
    compiled: list[re.Pattern[str]] = []
    for index, item in enumerate(raw):
        if not isinstance(item, str) or not item:
            raise PatternsError(f"patterns file: '{key}' entry {index} is not a string")
        try:
            compiled.append(re.compile(item))
        except re.error as exc:
            # The message of re.error may quote the expression: report the position only.
            raise PatternsError(
                f"patterns file: '{key}' entry {index} is not a valid expression"
            ) from exc
    return tuple(compiled)


def load_scrub_rules(
    patterns_file: Path,
    *,
    extra_url_domains: Sequence[str] = (),
    extra_email_domains: Sequence[str] = (),
) -> ScrubRules:
    """Read the ``bank_hosts`` and ``staff_ids`` expressions.

    The build fails closed: a missing file, key or empty list stops it.

    :param patterns_file: The local patterns JSON file
    :param extra_url_domains: URL hosts or parent domains allowed beyond the defaults
    :param extra_email_domains: Email domains allowed beyond the default
    :return: The compiled rules
    :raises PatternsError: If the file cannot be used
    """
    try:
        document = json.loads(patterns_file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise PatternsError("patterns file cannot be read as JSON") from exc
    if not isinstance(document, dict):
        raise PatternsError("patterns file must hold a JSON object")
    return ScrubRules(
        bank_hosts=_compile_group(document.get("bank_hosts"), "bank_hosts"),
        staff_ids=_compile_group(document.get("staff_ids"), "staff_ids"),
        url_domains=(*ALLOWED_URL_DOMAINS, *(d.lower() for d in extra_url_domains)),
        email_domains=(ALLOWED_EMAIL_DOMAIN, *(d.lower() for d in extra_email_domains)),
    )


# --- the deliverable tree ----------------------------------------------------------------------


def _is_excluded(relative: PurePosixPath) -> bool:
    name = relative.name
    if EXCLUDED_DIR_NAMES & set(relative.parts[:-1]):
        return True
    if name in EXCLUDED_FILE_NAMES or name.endswith(EXCLUDED_SUFFIXES):
        return True
    if any(part.endswith(".egg-info") for part in relative.parts):
        return True
    return (name == ".env" or name.startswith(".env.")) and name != KEPT_ENV_FILE


def collect_files(project_root: Path) -> list[SourceFile]:
    """List the files of the deliverable tree.

    :param project_root: The project folder
    :return: The files in path order
    :raises ProjectError: If a required folder or file is absent
    """
    files: list[SourceFile] = []
    for name in DELIVERABLE_DIRS:
        folder = project_root / name
        if not folder.is_dir():
            raise ProjectError(f"required folder is missing: {name}")
        for path in sorted(folder.rglob("*")):
            relative = PurePosixPath(path.relative_to(project_root).as_posix())
            if path.is_file() and not _is_excluded(relative):
                files.append(SourceFile(str(relative), path))
    for name in DELIVERABLE_FILES:
        path = project_root / name
        if not path.is_file():
            raise ProjectError(f"required file is missing: {name}")
        files.append(SourceFile(name, path))
    return sorted(files, key=lambda item: item.relative)


# --- the scrub ---------------------------------------------------------------------------------


def _segments(relative: str, data: bytes) -> Iterator[tuple[str, bytes]]:
    """The byte strings of a file that the patterns are matched against."""
    suffix = PurePosixPath(relative).suffix.lower()
    if suffix in ARCHIVE_SUFFIXES:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                for member in archive.namelist():
                    yield member, archive.read(member)
                return
        except zipfile.BadZipFile:
            pass
    yield relative, data


def _lines(data: bytes) -> Iterator[tuple[int, str]]:
    text = data.decode("latin-1")
    yield from enumerate(text.split("\n"), start=1)


def _url_is_allowed(url: str, rules: ScrubRules) -> bool:
    try:
        host = (urlsplit(url).hostname or "").lower()
    except ValueError:
        return False
    return any(host == domain or host.endswith(f".{domain}") for domain in rules.url_domains)


def _text_rules(line: str, rules: ScrubRules) -> Iterator[str]:
    """Rules broken by one line of a text file (hosts and ids are checked elsewhere)."""
    if not line.isascii():
        yield "non-ascii"
    if any(not _url_is_allowed(match.group(0), rules) for match in _URL.finditer(line)):
        yield "url-not-allowed"
    if any(m.group(1).lower() not in rules.email_domains for m in _EMAIL.finditer(line)):
        yield "email-not-allowed"
    for rule, pattern in _SECRET_SHAPES:
        if pattern.search(line):
            yield rule


def _pattern_rules(line: str, rules: ScrubRules) -> Iterator[str]:
    if any(pattern.search(line) for pattern in rules.bank_hosts):
        yield "bank-host-pattern"
    if any(pattern.search(line) for pattern in rules.staff_ids):
        yield "staff-id-pattern"


def scrub_file(relative: str, data: bytes, rules: ScrubRules) -> list[Violation]:
    """Scrub one file.

    :param relative: Its path inside the package payload
    :param data: Its bytes
    :param rules: The local expressions
    :return: Every finding, as places and rule names only
    """
    found: dict[tuple[str, int, str], Violation] = {}

    def record(path: str, line: int, rule: str) -> None:
        found.setdefault((path, line, rule), Violation(path, line, rule))

    for rule in _pattern_rules(relative, rules):
        record(relative, 0, rule)
    is_text = PurePosixPath(relative).suffix.lower() not in BINARY_SUFFIXES
    for name, segment in _segments(relative, data):
        label = relative if name == relative else f"{relative}!{name}"
        for number, line in _lines(segment):
            for rule in _pattern_rules(line, rules):
                record(label, number, rule)
            if is_text:
                for rule in _text_rules(line, rules):
                    record(label, number, rule)
    return sorted(found.values(), key=lambda item: (item.path, item.line, item.rule))


# --- generated files ---------------------------------------------------------------------------


def render_readme(build_name: str, payload: Sequence[SourceFile], payload_bytes: int) -> str:
    """Write the package README: apply order and the expected result.

    :param build_name: Name of the package folder
    :param payload: The payload files
    :param payload_bytes: Their total size
    :return: The README text (ASCII)
    """
    verified = len(payload) + 2  # the payload, install.py and this README
    return (
        f"{build_name}: knowledge platform proof of concept\n"
        "\n"
        "Contents\n"
        "  install.py          installer (standard library only)\n"
        f"  {README_FILE}  this file\n"
        f"  {CHECKSUM_FILE}          SHA-256 of every other file\n"
        f"  {PAYLOAD_DIR}/            the project tree ({len(payload)} files)\n"
        "\n"
        "Apply order (from the folder that holds the unzipped package)\n"
        f"  1. sha256sum -c {CHECKSUM_FILE}\n"
        "       expected: every line says OK\n"
        "  2. python3 install.py --inspect --target DIR\n"
        "       expected output, in this order:\n"
        f"         CHECKSUMS OK ({verified} files verified)\n"
        f"         PLAN new <path> (<n> bytes)   once per file, {len(payload)} lines\n"
        f"         PLAN {len(payload)} files, {payload_bytes} bytes, into DIR\n"
        "         INSPECT only: nothing was written\n"
        "       Apply only when this matches.\n"
        "  3. python3 install.py --target DIR\n"
        f"       expected: INSTALLED {len(payload)} files into DIR, then the next steps\n"
        "       DIR must be absent or empty; --force installs into a folder that is not empty.\n"
        "  4. cd DIR and follow INSTALL-WORKSTATION.md\n"
        "       (virtual environment, install, kp demo, tests).\n"
        "\n"
        "Nothing in this package holds a secret, a token or a real address. Real values are set\n"
        "on the workstation through KP_ environment variables (see .env.example).\n"
    )


def _install_script(scripts_dir: Path) -> bytes:
    path = scripts_dir / INSTALL_TEMPLATE
    try:
        return path.read_bytes()
    except OSError as exc:
        raise ProjectError(f"installer template is missing: {INSTALL_TEMPLATE}") from exc


# --- writing -----------------------------------------------------------------------------------


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_checksums(package_dir: Path) -> list[str]:
    """Write ``SHA256SUMS`` over every file of the package folder.

    :param package_dir: The package folder
    :return: The paths listed, in order
    """
    names = sorted(
        path.relative_to(package_dir).as_posix()
        for path in package_dir.rglob("*")
        if path.is_file() and path.name != CHECKSUM_FILE
    )
    lines = [f"{_sha256(package_dir / name)}  {name}\n" for name in names]
    (package_dir / CHECKSUM_FILE).write_text("".join(lines), encoding="ascii", newline="\n")
    return names


def _file_mode(name: str) -> int:
    executable = name == INSTALL_FILE or name.endswith(EXECUTABLE_SUFFIXES)
    return 0o755 if executable else 0o644


def write_zip(package_dir: Path, zip_path: Path, build_date: date) -> None:
    """Zip the package folder into one reproducible archive.

    :param package_dir: The package folder; its name becomes the top folder of the zip
    :param zip_path: The zip to write
    :param build_date: The date stamped on every entry
    """
    stamp = (build_date.year, build_date.month, build_date.day, 0, 0, 0)
    names = sorted(
        path.relative_to(package_dir).as_posix()
        for path in package_dir.rglob("*")
        if path.is_file()
    )
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in names:
            info = zipfile.ZipInfo(f"{package_dir.name}/{name}", date_time=stamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100000 | _file_mode(name)) << 16
            archive.writestr(info, (package_dir / name).read_bytes())


def _check_zip(zip_path: Path, package_name: str) -> int:
    """Re-read the zip and check every entry against SHA256SUMS. Returns the entry count."""
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip() is not None:
            raise PackagingError("the written zip is damaged")
        sums = archive.read(f"{package_name}/{CHECKSUM_FILE}").decode("ascii")
        expected = {line[66:]: line[:64] for line in sums.splitlines()}
        names = {n[len(package_name) + 1 :] for n in archive.namelist()} - {CHECKSUM_FILE}
        if names != set(expected):
            raise PackagingError("the zip and SHA256SUMS list different files")
        for name, digest in expected.items():
            if hashlib.sha256(archive.read(f"{package_name}/{name}")).hexdigest() != digest:
                raise PackagingError("a file in the zip does not match SHA256SUMS")
        return len(names)


def _clean_previous(out_root: Path, package_name: str) -> None:
    """Remove an earlier build of the same name (only names this script makes)."""
    if not package_name.startswith(PACKAGE_PREFIX):
        raise PackagingError("refusing to clean a folder this script did not name")
    package_dir = out_root / package_name
    if package_dir.exists():
        shutil.rmtree(package_dir)
    zip_path = out_root / f"{package_name}.zip"
    if zip_path.exists():
        zip_path.unlink()


def build_package(options: BuildOptions) -> BuildResult:
    """Scrub, assemble, checksum and zip the package.

    :param options: What to build and where
    :return: Where the package and the zip are, and the size and checksum of the zip
    :raises PatternsError: If the local patterns file cannot be used
    :raises ProjectError: If the project lacks a required file
    :raises ScrubFailedError: If any file breaks a scrub rule; nothing is written then
    """
    rules = load_scrub_rules(
        options.patterns_file,
        extra_url_domains=options.extra_url_domains,
        extra_email_domains=options.extra_email_domains,
    )
    payload = collect_files(options.project_root)
    package_name = f"{PACKAGE_PREFIX}{options.build_date:%Y%m%d}"
    contents = {item.relative: item.source.read_bytes() for item in payload}
    payload_bytes = sum(len(data) for data in contents.values())
    readme = render_readme(package_name, payload, payload_bytes).encode("ascii")
    install = _install_script(options.project_root / "scripts")

    generated = {INSTALL_FILE: install, README_FILE: readme}
    violations = [
        violation
        for name, data in [*contents.items(), *generated.items()]
        for violation in scrub_file(
            f"{PAYLOAD_DIR}/{name}" if name in contents else name, data, rules
        )
    ]
    if violations:
        raise ScrubFailedError(violations)

    options.out_root.mkdir(parents=True, exist_ok=True)
    _clean_previous(options.out_root, package_name)
    package_dir = options.out_root / package_name
    for name, data in contents.items():
        destination = package_dir / PAYLOAD_DIR / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    for name, data in generated.items():
        (package_dir / name).write_bytes(data)
    write_checksums(package_dir)

    zip_path = options.out_root / f"{package_name}.zip"
    write_zip(package_dir, zip_path, options.build_date)
    _check_zip(zip_path, package_name)
    return BuildResult(
        package_dir=package_dir,
        zip_path=zip_path,
        payload_files=len(payload),
        zip_size=zip_path.stat().st_size,
        zip_sha256=_sha256(zip_path),
    )


# --- command line ------------------------------------------------------------------------------


def _parse_date(text: str) -> date:
    try:
        return datetime.strptime(text, "%Y%m%d").date()
    except ValueError as exc:
        raise argparse.ArgumentTypeError("expected YYYYMMDD") from exc


def build_parser() -> argparse.ArgumentParser:
    """Build the command line parser.

    :return: The parser
    """
    project_root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(
        prog="build_bank_package.py", description="Build the single-zip bank package."
    )
    parser.add_argument(
        "--patterns",
        type=Path,
        required=True,
        metavar="PATH",
        help="local JSON file with the bank_hosts and staff_ids expressions (never copied)",
    )
    parser.add_argument(
        "--project-root", type=Path, default=project_root, metavar="DIR", help="project folder"
    )
    parser.add_argument(
        "--out-root",
        type=Path,
        default=project_root.parent / "build",
        metavar="DIR",
        help="folder for the package folder and the zip (default: ../build)",
    )
    parser.add_argument(
        "--date",
        type=_parse_date,
        default=None,
        metavar="YYYYMMDD",
        help="build date in the package name (default: today)",
    )
    parser.add_argument(
        "--allow-url-host",
        action="append",
        default=[],
        metavar="DOMAIN",
        help="also allow URLs to this host or parent domain (repeatable). Strict by default: "
        "only localhost, 127.0.0.1, example.com and example.org pass.",
    )
    parser.add_argument(
        "--allow-email-domain",
        action="append",
        default=[],
        metavar="DOMAIN",
        help="also allow email addresses at this domain (repeatable); default example.com only",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the build and print the outcome.

    :param argv: Arguments without the program name; the process arguments by default
    :return: 0 built, 1 the scrub failed, 2 the inputs were unusable
    """
    args = build_parser().parse_args(argv)
    options = BuildOptions(
        project_root=args.project_root.resolve(),
        out_root=args.out_root.resolve(),
        patterns_file=args.patterns,
        build_date=args.date or date.today(),
        extra_url_domains=tuple(args.allow_url_host),
        extra_email_domains=tuple(args.allow_email_domain),
    )
    try:
        result = build_package(options)
    except ScrubFailedError as exc:
        sys.stderr.write(f"SCRUB FAILED: {len(exc.violations)} finding(s), nothing was written\n")
        for violation in exc.violations:
            sys.stderr.write(f"  {violation}\n")
        return EXIT_SCRUB_FAILED
    except PackagingError as exc:
        sys.stderr.write(f"BUILD FAILED: {exc}\n")
        return EXIT_BAD_INPUT
    for domain in options.extra_url_domains:
        sys.stdout.write(f"NOTE scrub exception: URLs to {domain} allowed\n")
    for domain in options.extra_email_domains:
        sys.stdout.write(f"NOTE scrub exception: email at {domain} allowed\n")
    sys.stdout.write(f"Package folder: {result.package_dir}\n")
    sys.stdout.write(f"Payload files:  {result.payload_files}\n")
    sys.stdout.write(f"Zip:            {result.zip_path}\n")
    sys.stdout.write(f"Size:           {result.zip_size} bytes\n")
    sys.stdout.write(f"SHA256:         {result.zip_sha256}\n")
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
