---
name: km-verify
description: Use before /km-story or /km-risks to check claims about the code. Argument s1..s6, all.
argument-hint: s1..s6 or all
disable-model-invocation: true
---

# km-verify

Argument: $0 is s1..s6 or all. Anything else: print "usage: /km-verify s1..s6|all" and stop.
Run id: km-verify-$0-<date> (date from `date +%F`), for example km-verify-s3-2026-11-11.
Goal: every claim a design or the risk register may use has a verdict in kb/verified/;
nothing from claims.md or claims-2.md is used until it has one.

## Inputs
- Preferred: kb/private/claims.md (S1, S2) and kb/private/claims-2.md (S3 to S6, Both repos,
  Capture toolkit): numbered one-line claims grouped by story. Take the group for $0 from the
  file that holds it. For all, take every group of both files, one group at a time.
- If kb/private is missing or has no such group: build the list from the Observed lines of
  kb/base and kb/capture that the story depends on. Find them through kb/INDEX.md and the
  story's part of kb/seed/story-gaps.md. Number them K1, K2. Lines that came only from the
  wiki or seed stay Reported until the code gives a verdict.
- No claims and no Observed lines: write the reason to kb/log.d/<run>.txt, tell the owner in
  two lines which /km-read run is missing, stop.
- Clones: BASE_REPO has backend/ and frontend/; CAPTURE_REPO is the other. Never write in either.

## Batches
- Clone per claim: area [capture] = CAPTURE_REPO; a claim that says "either repo", "both" or
  "neither" gets both clone paths; all others BASE_REPO. Cut batches of at most 15 claims,
  related claims together.
- One km-verifier per batch. One at a time.
- Task for each, in this form and nothing else:
  goal: check these claims about <clone path> against the code and try to refute each;
  inputs: the clone path and the numbered claims pasted in the task;
  output: your standard table first, then at most 5 notes lines;
  skip: env, key and credential files; tests count as hints only;
  reply: table and notes, nothing else.
- The verifier cannot write. Save each returned table to work/verify/<run>-b<N>.txt at once.
  On a restart skip batches whose file exists.
- If a verifier ran out of turns, send the unfinished numbers once more. Then mark the rest
  Not checkable with the reason "not reached".
- Before saving, spot-check: Read 10 lines around the cited path:line of every Contradicted
  and Narrowed row and of 3 Confirmed rows per batch. If the line does not show what the row
  says, set the row Not checkable ("evidence did not match") and send it once more with the
  next batch. Note the spot-check count in the log.

## Result: kb/verified/<code>.md, code in lower case: s1 to s6 (for example kb/verified/s3.md)
- Groups not tied to a story: Both repos to kb/verified/repos.md, Capture toolkit to
  kb/verified/capture.md, same shape.
- Header: Date, Task, Status, Source (claims.md group or kb files used), counts per verdict.
- Section Verdicts: table Id | Verdict | Evidence (first path:line only, so lines stay within
  100 characters). Order: Contradicted, Narrowed, Not checkable, Confirmed.
- Section Claims: one entry per id, wrapped at 100 characters: the exact claim after
  checking. For Narrowed and Contradicted add "Was:" with the original and the counter-example.
- Section Notes: dependencies between claims and extra findings from the verifiers.
- Last lines: "Use: Confirmed and Narrowed (as rewritten) count as Observed. Contradicted is never
  used. Not checkable counts as Unverified."
- Observed is the label for every row but Not checkable. Over 150 lines: continue in
  <code>-2.md and name it in the first file. If the file exists, skip that story and say so.

## Finish
- Write kb/index.d/<run>.txt (one line per file: path | 12-word summary | date) and
  kb/log.d/<run>.txt (date, task, files, skipped and why). The log names batches run, claims
  not reached and anything denied.
- Print at most 10 lines: path, counts (Confirmed, Narrowed, Contradicted, Not checkable), the
  three most important Contradicted or Narrowed claims in one line each, and the next command.
