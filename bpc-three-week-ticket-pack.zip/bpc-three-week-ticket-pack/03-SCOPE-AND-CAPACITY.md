# Scope, capacity and gates

## A three-week adaptation plan, not a full rebuild estimate

The live bank checkout is not available here. All implementation estimates are **G0-confirmed reuse/adaptation estimates**, not measured implementation times or fixed-price commitments. In particular, graph lifecycle, durable jobs, bounded Hub decision paths and gateway coordination require reusable approved seams. Reconciliation can invalidate the entire downstream schedule. The plan never reduces authorization, source truth, lifecycle correctness or evaluation acceptance to make a date fit.

The default foundation profile follows the last clear graph/Hub architecture boundary: 26 subtasks and 134 engineering hours. The 31-task recommendation extension is 165 hours and finishes in the final slot on 29 September. The Jira parent deadline on 30 September adds one separate reserve day. It has zero final-chain contingency inside the three-week window; any unresolved credential, failed test, reviewer delay or absent reusable subsystem can move the date. That is a stretch scenario to review, not a promised full-engine delivery.

Engineering estimates include task implementation, targeted verification, peer review and one correction pass. Six focus hours/day leaves the rest of the normal workday for meetings and coordination; neither model parallelism nor subagents create additional human review capacity. Per-person assigned hours and occupied slots are distinct from elapsed completion time because dependencies create idle intervals.

## Gates before dependent implementation or enablement

| Gate | Due by planned boundary | Required evidence / owner | If unavailable |
|---|---|---|---|
| Jira import preflight | Before any issue creation | User scope/date; actual project/epic/types; uniquely resolved assignable users; field/link support | Keep affected mutation pending; no guessed IDs or dates |
| G0 reuse and authority | CORE-01 / D1 | Yurii records bank commit, reusable code, source/identity/graph/worker/model capabilities; platform/source owners validate their boundaries | Re-estimate new-build work; keep dependent features blocked |
| Contract handoff | CORE-02 / D2 | Typed task/source/identity/publication/error schemas and source fixtures | Adapters/UI may not invent incompatible shapes |
| Full source and publication integration | CORE-15 | All required source adapters, ordered source vector, exact identity joins, sealed graph, real durable job and current authorization | No refresh or graph activation |
| AI/quality authority | Before CORE-11 or recommendation tasks | Domain owner fixes evidence policy, labels, reviewers, per-task risk/quality criteria before results | Preserve baseline; no fabricated labels or quality claim |
| Release | CORE-09 → CORE-10 | Actual fault/access/load/replay/quality evidence, compatible rollout/rollback, operator handoff | Parent remains open or records a qualified partial milestone |

External owner decisions have real elapsed time. The calendar assumes their required input is ready at the shown boundary. Jira dependencies do not make corporate access approvals or domain adjudication instantaneous.

## What the two profiles actually deliver

**Foundation:** scoped source catalogue/graph, safe read/publication, controlled Git/workbook refresh where approved identity/worker exists, shared status/evidence UI, typed current-Hub baseline and evidence policy, shared budgets/configuration lineage, acceptance evidence and runbook. Skills/MCP/Agents parent Stories receive graph/evidence milestones and remain open if their live acceptance requires recommendations.

**Recommendation extension:** the foundation plus an authorized lexical baseline for all three types, shared truthful result contract and independent type-specific evaluation. It is not an LLM semantic fit engine, execution workflow or claim that lexical match proves suitability. Joseph must accept this exact baseline as the parent outcome; a Story with broader acceptance cannot be silently narrowed or closed.

## Retained architecture work outside this calendar

These are explicit backlog dispositions, not hidden work in the estimates and not automatic Jira creates. Use the same appropriate parent when later approved; do not create a fifth top-level programme from this register.

| Backlog item | Accountable technical owner | Prerequisite / next bounded experiment | Current disposition |
|---|---|---|---|
| Full future component engine: model assessments, bounded batches/cache, semantic-support handling | Yurii | Successful lexical baseline, model access, input/token limits and adjudicated cases | Not scheduled; estimate after baseline |
| Vector retrieval, RRF/weighted-fusion comparison, reranker and graph boosts | Yurii | Approved existing-stack query behavior, scoped retrieval, frozen held-out comparison and measured gain | Candidate experiments only; no automatic feature enablement |
| Field-aware embedding rebuild and safe index generations | Yurii | Verify current text builders/index behavior, memory/quota and compatible backfill/retention | Separate implementation estimate; active index never dropped for an unqualified backfill |
| Numeric confidence calibration and richer review workflows | Yurii; domain owner supplies labels | Sufficient adjudicated held-out cases, reviewer/queue ownership, calibration/risk criteria | Probabilities disabled until justified; basic review-state contract included in CORE-11 |
| Dependency/image pinning, non-root runtime and developer tooling | Yurii with platform owner; Mayank verifies UI types | Audit actual dependency/runtime/image/build setup and Nexus constraints | Retained hardening backlog; no historical runtime-version assumption |
| Secret injection, endpoint exposure and data retention audit | Yurii with platform/security owner | Current hosting/access policy and actual routes/logging | Immediate auth/secret safeguards are mandatory in planned tasks; wider estate hardening is separately estimated |
| Linting, OpenAPI → TypeScript freshness and CI content gates | Mayank with Yurii review | Actual bank build/CI/type-generation commands | Relevant touched-surface checks are included; wider pipeline modernization remains backlog |
| Scheduled refresh after manual button path | Mayank with Yurii review | Proved authorization, durable jobs, source/freshness contracts, recovery and operator ownership | Button/CLI first; scheduling not in this window |
| Optional native Hub Agent binding, richer explorer, Knowledge Sources, outward-facing MCP service | Yurii | Separate product/source mapping scope and exact approved contracts | Deferred; no invented bindings/API or component execution |
| Per-PR environments, AIRCO prefill/notifications, workflow framework or database replacement | Separate product/platform owner | Explicit programme decision and independent estimate | Outside these four parents’ current delivery scope |

## Parent and ticket ownership

Yurii owns the technical core, shared identity/policy/publication decisions and release acceptance. Mayank owns bounded source acquisition/parsing, evidence/UI integration and preparation. Per-task implementers are explicit; platform/domain/source approvers are named roles to resolve, not extra implementers. All four parent owners are proposed as Yurii and must map to the actual assignable account.

No additional work is made free by placing it under a shared parent: its hours and dependencies appear once. Source-specific parent estimates are rollups only; do not sum a parent rollup again into team capacity.

## Three document checks

1. Technical decomposition review: source contracts, current-vs-reported facts, identity ownership and source-only edge semantics.
2. Dependency/capacity and failure review: removed release-gate cycles; added monotonic source vectors, cross-type dependencies and a real final source-set integration owner; separated preparation from final handoff.
3. Final artifact review: validate Markdown/manifest parity, required files, calendar/dependency/resource consistency, import safety and the HTML in the browser. The verification receipt records completed document checks. None of these is an application or benchmark run.
