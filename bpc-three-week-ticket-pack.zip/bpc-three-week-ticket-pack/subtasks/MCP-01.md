---
pack_id: "bpc-sep26-v1"
local_id: "MCP-01"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1347"
summary: "Reconcile the MCP Excel source and current integration seams"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 4
scope: "foundation"
create_by_default: true
planned_start: "2026-09-09"
planned_due: "2026-09-10"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-01"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-mcp-01"
architecture_sections: ["mandate","boundaries","source-refresh","evidence"]
---

# Reconcile the MCP Excel source and current integration seams

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1347**. Local reference **MCP-01** is not a Jira key.
- Estimate: **4 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-09 → 2026-09-10 (D1–D2)**.
- Recommendation extension: **2026-09-09 → 2026-09-10 (D1–D2)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

The MCP flow relies on a workbook and current-bank integration seams that are unavailable here. Produce an evidence-backed reconciliation record before parser, API, or UI work is planned.

## Scope and contract

Map actual checkout paths, source acquisition, workbook identity, sheets, header aliases, source authority, scope/partition, refresh mechanism, and read/write/auth seams. For every observed workbook, record owner, capture time, digest, declared revision if supplied, and complete-snapshot versus delta status. Unknowns remain unresolved; no Agent Hub API, endpoint, role, worker, or MCP execution capability is assumed.

## Steps

1. Reconcile the current checkout and approved workbook with CORE-01.
2. Classify sheets/headers as required, optional, unknown, or unsupported, and identify authority for MCP IDs and relationship declarations.
3. Record conditions for complete-snapshot refresh versus publication blockers.
4. Hand the approved mapping and open questions to MCP-02 through MCP-04 without adding a route or worker.

## Acceptance and verification

- Actual locations/seams are evidenced or explicitly unavailable.
- Every later-used sheet/header has an approved mapping or blocker; inferred headers are rejected.
- Complete-snapshot status is explicit; missing/ambiguous input cannot imply deletion.
- The record explicitly excludes external MCP-server execution, Agent Hub API assumptions, and arbitrary URL fetch.

## Evidence, blockers and exclusions

Attach source descriptors, mappings, owner confirmations/open owners, seam inventory, and unresolved questions. Block on unavailable checkout access or an unapproved workbook. Parser work, identity, publication, ranking, and external actions are out of scope.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-01](CORE-01.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `mandate`, `boundaries`, `source-refresh`, `evidence`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
