"""Gateway source adapters for Confluence, Jira and GitHub."""

from kp.connectivity.adapters.base import GatewayToolAdapter
from kp.connectivity.adapters.confluence import ConfluenceAdapter
from kp.connectivity.adapters.github import GitHubAdapter
from kp.connectivity.adapters.jira import JiraAdapter, semantic_projection

__all__ = [
    "ConfluenceAdapter",
    "GatewayToolAdapter",
    "GitHubAdapter",
    "JiraAdapter",
    "semantic_projection",
]
