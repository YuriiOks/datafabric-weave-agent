"""Caller identity as asserted by the transport: environment for stdio, headers for HTTP.

Tool arguments never carry identity. The HTTP endpoint trusts its identity header, so it must
sit behind something that authenticates the user and sets it; it binds to loopback by default.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from kp.tools import Caller, build_caller

ENV_CALLER = "KP_CALLER"
ENV_AGENT = "KP_AGENT"
ENV_SESSION = "KP_SESSION_ID"
ENV_SPEC = "KP_SPEC_ID"


@dataclass(frozen=True, slots=True)
class IdentityHeaders:
    """Names of the HTTP headers that carry the caller's identity (case-insensitive)."""

    user: str = "X-KP-Caller"
    agent: str = "X-KP-Agent"
    session: str = "X-KP-Session"
    spec: str = "X-KP-Spec"


def caller_from_environment(environ: Mapping[str, str]) -> Caller:
    """Read the caller of a stdio server from its process environment.

    :param environ: The environment, e.g. ``os.environ``
    :return: The caller; unauthenticated when ``KP_CALLER`` is absent or malformed
    """
    return build_caller(
        user=environ.get(ENV_CALLER),
        agent=environ.get(ENV_AGENT),
        session_id=environ.get(ENV_SESSION),
        spec_id=environ.get(ENV_SPEC),
    )


def caller_from_headers(headers: Mapping[str, str], names: IdentityHeaders) -> Caller:
    """Read the caller of one HTTP request from its headers.

    A request without a session header belongs to a stable session of that user and agent
    instead of a fresh random one. With a random session, what a client read in one request
    could never be found by its next request, and every rule statement of a spec it published
    would be flagged as not retrieved. Clients that run several sessions at once send the header.

    :param headers: Request headers with lower-case names
    :param names: Which headers carry which claim
    :return: The caller; unauthenticated when the user header is absent or malformed
    """
    user = headers.get(names.user.lower())
    agent = headers.get(names.agent.lower())
    session = headers.get(names.session.lower())
    if session is None and user is not None:
        session = f"http-{agent or 'agent'}"
    return build_caller(
        user=user, agent=agent, session_id=session, spec_id=headers.get(names.spec.lower())
    )
