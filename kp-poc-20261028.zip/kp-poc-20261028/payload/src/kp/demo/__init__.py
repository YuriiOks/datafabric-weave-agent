"""``kp demo``: the whole platform end to end on the synthetic data, judged against the plan.

The demo builds a database, sweeps the five stand-in sources, ingests, indexes, links,
publishes a knowledge version, and then evaluates the three "done when" lines of the plan
(week 1 sources in, week 2 search and links, week 3 agent access and write-back) as PASS or
FAIL with the evidence behind each. It also runs the connectivity job against the local
stand-ins and prints the X-01..X-11 table. The exit code is 0 only if all three lines pass.
"""
