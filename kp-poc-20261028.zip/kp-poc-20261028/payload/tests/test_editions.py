"""The "as at" edition rule (US-11) and clause consistency."""

from __future__ import annotations

from datetime import UTC, date, datetime

import pytest
from pydantic import ValidationError

from kp.clock import FixedClock
from kp.domain import Clause, ClauseRef, Edition, EditionState, select_edition_as_at

E_2025_2 = Edition(
    label="2025.2",
    effective_date=date(2025, 6, 2),
    superseded_from=date(2026, 11, 16),
    item_id="rulebook",
    version="2025.2",
)
E_2026_1 = Edition(
    label="2026.1",
    effective_date=date(2026, 11, 16),
    item_id="rulebook",
    version="2026.1",
)


def test_day_before_effective_date_returns_the_earlier_edition() -> None:
    chosen = select_edition_as_at([E_2026_1, E_2025_2], date(2026, 11, 15))

    assert chosen is not None
    assert chosen.label == "2025.2"


def test_effective_date_itself_returns_the_new_edition() -> None:
    chosen = select_edition_as_at([E_2025_2, E_2026_1], date(2026, 11, 16))

    assert chosen is not None
    assert chosen.label == "2026.1"


def test_no_date_means_the_edition_in_force_today(fixed_clock: FixedClock) -> None:
    before = select_edition_as_at([E_2025_2, E_2026_1], fixed_clock.today())
    fixed_clock.set(datetime(2026, 12, 1, tzinfo=UTC))
    after = select_edition_as_at([E_2025_2, E_2026_1], fixed_clock.today())

    assert before is not None
    assert after is not None
    assert (before.label, after.label) == ("2025.2", "2026.1")


def test_nothing_in_force_before_the_first_edition_returns_none() -> None:
    assert select_edition_as_at([E_2025_2, E_2026_1], date(2025, 1, 1)) is None


def test_withdrawn_edition_is_not_selected_from_its_withdrawal_date() -> None:
    withdrawn = E_2025_2.model_copy(update={"withdrawn_from": date(2026, 1, 1)})

    assert select_edition_as_at([withdrawn], date(2025, 12, 31)) == withdrawn
    assert select_edition_as_at([withdrawn], date(2026, 1, 1)) is None


def test_load_order_is_irrelevant_and_latest_effective_wins_if_supersession_is_unrecorded() -> None:
    unrecorded = E_2025_2.model_copy(update={"superseded_from": None})

    chosen = select_edition_as_at([unrecorded, E_2026_1], date(2027, 1, 1))

    assert chosen is not None
    assert chosen.label == "2026.1"


def test_edition_state_on_dates() -> None:
    assert E_2025_2.state_on(date(2025, 6, 1)) is EditionState.NOT_YET_EFFECTIVE
    assert E_2025_2.state_on(date(2026, 11, 15)) is EditionState.CURRENT
    assert E_2025_2.state_on(date(2026, 11, 16)) is EditionState.SUPERSEDED


def _clause(**overrides: object) -> Clause:
    values: dict[str, object] = {
        "ref": ClauseRef("2026.1", "4.2.1"),
        "page": 5,
        "char_start": 10,
        "char_end": 20,
        "text": "x",
        "structure_score": 0.9,
        "parent_ref": ClauseRef("2026.1", "4.2"),
    }
    return Clause.model_validate(values | overrides)


def test_clause_requires_its_enclosing_clause_as_parent() -> None:
    assert _clause().parent_ref == ClauseRef("2026.1", "4.2")
    with pytest.raises(ValidationError):
        _clause(parent_ref=ClauseRef("2026.1", "4"))
    with pytest.raises(ValidationError):
        _clause(parent_ref=None)


def test_clause_rejects_inverted_positions_and_bad_scores() -> None:
    with pytest.raises(ValidationError):
        _clause(char_start=30)
    with pytest.raises(ValidationError):
        _clause(structure_score=1.5)
