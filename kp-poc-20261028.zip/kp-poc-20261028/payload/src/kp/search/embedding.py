"""The embedder port, a deterministic local stand-in, and batched embedding of passages.

The vector side of search sits behind :class:`Embedder`, so the shared AI services replace the
hashing stand-in by configuration. Nothing here talks to a network.
"""

from __future__ import annotations

import hashlib
import math
from collections.abc import Sequence
from itertools import pairwise
from typing import Final, Protocol

from sqlalchemy import Connection

from kp.domain import EMBEDDING_DIMENSIONS
from kp.search.errors import EmbeddingError
from kp.search.store import PassageStore
from kp.search.tokens import analyze

EMBEDDING_BATCH_SIZE: Final = 96
HASHING_MODEL_VERSION: Final = "hashing-768-v1"
_BIGRAM_WEIGHT: Final = 0.5
_DIGEST_BYTES: Final = 8


class Embedder(Protocol):
    """Turns texts into vectors of :data:`kp.domain.EMBEDDING_DIMENSIONS` values."""

    @property
    def model_version(self) -> str:
        """Identifier recorded next to every stored vector."""
        ...

    def embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        """Embed one batch.

        :param texts: At most :data:`EMBEDDING_BATCH_SIZE` texts
        :return: One vector per text, in order
        """
        ...


class HashingEmbedder:
    """A deterministic bag-of-words embedder using the hashing trick.

    Terms and adjacent term pairs are hashed into 768 signed buckets and the vector is
    L2-normalised. It carries lexical, not semantic, similarity: enough to exercise the whole
    vector path offline. It uses no randomness, so the same text always gives the same vector.
    """

    @property
    def model_version(self) -> str:
        """Identifier of this stand-in model."""
        return HASHING_MODEL_VERSION

    def embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        """Embed a batch of texts.

        :param texts: Texts to embed
        :return: One normalised vector per text; a text with no terms gives the zero vector
        """
        return [self._embed_one(text) for text in texts]

    @staticmethod
    def _embed_one(text: str) -> tuple[float, ...]:
        terms = analyze(text)
        vector = [0.0] * EMBEDDING_DIMENSIONS
        features = [(term, 1.0) for term in terms]
        features += [(f"{a} {b}", _BIGRAM_WEIGHT) for a, b in pairwise(terms)]
        for feature, weight in features:
            digest = hashlib.blake2b(feature.encode("utf-8"), digest_size=_DIGEST_BYTES).digest()
            number = int.from_bytes(digest, "big")
            sign = 1.0 if number & 1 else -1.0
            vector[(number >> 1) % EMBEDDING_DIMENSIONS] += sign * weight
        norm = math.sqrt(sum(value * value for value in vector))
        if norm == 0.0:
            return tuple(vector)
        return tuple(value / norm for value in vector)


def embed_texts(
    embedder: Embedder, texts: Sequence[str], batch_size: int = EMBEDDING_BATCH_SIZE
) -> list[tuple[float, ...]]:
    """Embed texts in batches, checking what comes back.

    :param embedder: The embedder to call
    :param texts: Texts in order
    :param batch_size: Largest batch sent to the embedder
    :return: One vector per text, in order
    :raises EmbeddingError: If a batch returns the wrong number of vectors or the wrong size
    """
    vectors: list[tuple[float, ...]] = []
    for start in range(0, len(texts), batch_size):
        batch = texts[start : start + batch_size]
        result = embedder.embed(batch)
        if len(result) != len(batch):
            raise EmbeddingError("Embedder returned a different number of vectors than texts")
        if any(len(vector) != EMBEDDING_DIMENSIONS for vector in result):
            raise EmbeddingError(f"Embedder vectors must have {EMBEDDING_DIMENSIONS} values")
        vectors.extend(result)
    return vectors


def embed_pending(
    connection: Connection, embedder: Embedder, batch_size: int = EMBEDDING_BATCH_SIZE
) -> int:
    """Embed every passage that has no vector from the embedder's current model.

    :param connection: An open connection; the caller commits
    :param embedder: The embedder to use
    :param batch_size: Largest batch sent to the embedder
    :return: The number of passages embedded
    """
    store = PassageStore(connection)
    embedded = 0
    while pending := store.unembedded(embedder.model_version, batch_size):
        vectors = embed_texts(embedder, [passage.text for passage in pending], batch_size)
        store.set_embeddings(
            {passage.passage_id: vector for passage, vector in zip(pending, vectors, strict=True)},
            embedder.model_version,
        )
        embedded += len(pending)
    return embedded


def cosine_ranking(
    query: Sequence[float], vectors: Sequence[tuple[str, Sequence[float]]], limit: int
) -> list[tuple[str, float]]:
    """Rank stored vectors by cosine similarity to a query vector.

    :param query: The query vector
    :param vectors: ``(passage id, vector)`` pairs
    :param limit: Maximum number of results
    :return: ``(passage id, similarity)`` best first, ties broken by id; vectors with no
        positive similarity are not returned
    """
    query_norm = math.sqrt(sum(value * value for value in query))
    if query_norm == 0.0:
        return []
    scored = []
    for passage_id, vector in vectors:
        norm = math.sqrt(sum(value * value for value in vector))
        if norm == 0.0:
            continue
        similarity = sum(a * b for a, b in zip(query, vector, strict=True)) / (query_norm * norm)
        if similarity > 0.0:
            scored.append((passage_id, similarity))
    scored.sort(key=lambda item: (-item[1], item[0]))
    return scored[:limit]
