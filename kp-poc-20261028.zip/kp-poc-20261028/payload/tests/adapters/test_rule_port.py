"""The rule port: editions and clauses with the domain of their document."""

from __future__ import annotations

from kp.adapters.rule_port import DatabaseRulePort
from world_support import World


def test_editions_are_listed_oldest_first(built_world: World) -> None:
    editions = DatabaseRulePort(built_world.application.database).editions()

    assert [edition.label for edition in editions] == ["2025.2", "2026.1"]
    assert editions[0].superseded_from == editions[1].effective_date


def test_a_clause_carries_its_page_position_and_domain(built_world: World) -> None:
    found = DatabaseRulePort(built_world.application.database).clause("2026.1", "4.2.1")

    assert found is not None
    assert found.domain == "payments"
    assert found.clause.page == 4
    assert found.clause.parent_ref is not None
    assert found.clause.parent_ref.number == "4.2"


def test_a_clause_that_does_not_exist_is_none(built_world: World) -> None:
    port = DatabaseRulePort(built_world.application.database)

    assert port.clause("2026.1", "99.9") is None
    assert port.clause("1999.1", "4.2.1") is None
