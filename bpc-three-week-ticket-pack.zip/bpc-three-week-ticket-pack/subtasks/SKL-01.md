---
pack_id: "bpc-sep26-v1"
local_id: "SKL-01"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1169"
summary: "Reconcile the registered Skills snapshot and Agent Hub workbook"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 4
scope: "foundation"
create_by_default: true
planned_start: "2026-09-11"
planned_due: "2026-09-11"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-01"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-skl-01"
architecture_sections: ["validation-gates","ingestion","source-refresh","delivery"]
---

# Reconcile the registered Skills snapshot and Agent Hub workbook

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1169**. Local reference **SKL-01** is not a Jira key.
- Estimate: **4 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-11 → 2026-09-11 (D3–D3)**.
- Recommendation extension: **2026-09-11 → 2026-09-11 (D3–D3)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

The marketplace repository and the Agent Hub export answer different questions. Establish a reviewed source map and immutable input manifest before any Skill is parsed or matched, so later work does not treat a reported historical count, a local checkout or a portal export as interchangeable.

## Scope

Inspect only the approved local marketplace Git checkout and approved Agent Hub workbook identified by CORE-01. Record source owner, scope and environment, acquisition method, revision or as-of marker, content hash, completeness expectation, available identity fields and known authority for each field. Produce the Skills-specific reconciliation report and source-manifest entries consumed by the shared contracts.

## Boundaries, inputs and outputs

Inputs are the registered Git/local checkout and the approved workbook. The output is a reviewed source map, immutable manifest entries, a count/reconciliation table and an open-gap register that labels every observation as observed, reported or proposed. This task does not fetch arbitrary URLs, call an Agent Hub API, execute marketplace scripts, create canonical identities or publish a catalogue.

## Technical steps

1. Verify the approved checkout revision and the workbook provenance, scope and as-of date with CORE-01.
2. Map Git definition content against workbook portal identifiers, status and environment fields without attempting a name-based join.
3. Record discovery rules for the Skills root, nested Skill documents and non-Skill directories; record workbook sheet, header and duplicate-key checks after inspecting the actual sources.
4. Reconcile current counts with the reported historically reported repository and workbook figures as a discrepancy to investigate, not an inferred deletion or missing registration.
5. Publish the source map and explicit blockers for absent access, incomplete export, unknown environment, missing identity authority or unapproved source scope.

## Acceptance criteria

- [ ] Each approved input has a reproducible revision or as-of marker, content hash, source owner, scope and authority statement in the shared source manifest.
- [ ] The repository and workbook fields are mapped to their separate authorities; no portal identifier is inferred from a directory or display name.
- [ ] The report identifies discovery treatment for nested Skill documents and the sibling scripts directory using the inspected checkout.
- [ ] Every count difference is accounted for as matched, unmatched-on-one-side, excluded-by-scope or unresolved; none is silently interpreted as removal.
- [ ] The open-gap register names the decision owner and blocked downstream contract for every unresolved authority or access gap.

## Meaningful verification cases

- A nested Skill definition and a non-Skill sibling directory exercise discovery rules.
- A repository-only record and a workbook-only record remain unmatched rather than being joined by a similar name.
- A workbook with an unexpected required sheet or header is marked incomplete and blocks dependent admission.
- The historically reported repository/workbook count gap remains visible with its denominator and snapshot dates.

## Evidence to attach

Attach the source map, manifest hashes and as-of markers, count-reconciliation table, field-authority matrix and open-gap register.

## Blockers

Approved source access, source owner confirmation and an approved PPD or other explicitly scoped workbook are required. A missing complete workbook blocks portal-identity claims but does not justify substituting a guessed mapping.

## Out of scope

Agent Hub API integration, refresh job implementation, parser implementation, identity policy, catalogue publication, recommendation ranking and Skill execution.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-01](CORE-01.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `validation-gates`, `ingestion`, `source-refresh`, `delivery`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
