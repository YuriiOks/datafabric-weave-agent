"""The narrow contract between content sources and the sweep.

A :class:`SourceReader` is the "fetch and stage" layer. Whatever sits behind it (a gateway
tool server, a direct service read, a local directory of synthetic data) implements these two
operations; the sweep, approval gate and change tracking sit above it and know nothing else
about the source. Swapping stand-ins for real routes is then configuration only.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import AwareDatetime, Field, JsonValue

from kp.domain.base import DomainModel
from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey


class ChangedItem(DomainModel):
    """An item version a source reports as new or changed (or gone) since a cursor.

    :ivar deleted: True when the source reports the item as removed. History is kept; the
        sweep decides what that means for approval.
    """

    key: ItemKey
    title: str = ""
    modified_at: AwareDatetime | None = None
    deleted: bool = False


class ChangeBatch(DomainModel):
    """One page of changes plus the cursor to continue from.

    The cursor is opaque. Persist ``next_cursor`` only after the page has been processed so a
    stopped run restarts from the last saved point without duplicates. ``exhausted`` is True
    when no further page exists; the cursor is then the position for the next sweep.
    """

    items: tuple[ChangedItem, ...] = ()
    next_cursor: str | None = None
    exhausted: bool = True


class ItemMetadata(DomainModel):
    """What a source tells us about one fetched item version.

    ``attributes`` carries source-specific facts the approval gate needs (labels, workflow
    status, merge state, the document details, an effective date). Keys are the source's own;
    the sweep never interprets them outside the approval rules of that source.
    """

    native_id: str
    media_type: str
    title: str
    author: str | None = None
    modified_at: AwareDatetime | None = None
    attributes: dict[str, JsonValue] = Field(default_factory=dict)


class FetchedItem(DomainModel):
    """Raw bytes of one item version with its metadata. Bytes are never altered."""

    key: ItemKey
    content: bytes
    metadata: ItemMetadata


@runtime_checkable
class SourceReader(Protocol):
    """Read access to one source (or one scope of it)."""

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves."""
        ...

    def list_changed(self, cursor: str | None, *, limit: int = 100) -> ChangeBatch:
        """List item versions changed since ``cursor``.

        :param cursor: The saved position, or ``None`` for a first sweep
        :param limit: Maximum items per page
        :return: A page of changes with the cursor to continue from
        :raises kp.errors.SourceUnavailableError: If the source cannot be reached
        :raises kp.errors.SourceRateLimitedError: If the source asks the caller to wait
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after renewal
        """
        ...

    def fetch(self, key: ItemKey) -> FetchedItem:
        """Fetch the bytes and metadata of one item version.

        :param key: The version to fetch
        :return: Its content and metadata
        :raises kp.errors.SourceItemNotFoundError: If the version does not exist
        :raises kp.errors.SourceUnavailableError: If the source cannot be reached
        :raises kp.errors.SourceRateLimitedError: If the source asks the caller to wait
        :raises kp.errors.SourceAuthRefusedError: If the credential is refused after renewal
        """
        ...
