"""Pre-production authority: scope refusal, allow-list and activation re-checks."""

from __future__ import annotations

import unittest
from datetime import timedelta

from app.recsys.contracts import PublicationScope, SourceEnvironment
from app.recsys.refresh.integration.authority import (
    ACTIVATION_AUTHORIZATION_TTL,
    POLICY_REVISION,
    PreproductionAuthorityPort,
    parse_operators,
)
from app.recsys.refresh.ports import AuthorizationRevoked, ConfigurationChanged, StaleFence

from . import protocol_fixtures as fixtures

OPERATOR = fixtures.PRINCIPAL.principal_id


class _Configurations:
    def __init__(self, changed: bool = False) -> None:
        self.changed = changed

    async def resolve(self, configuration_id, identity):
        return fixtures.SNAPSHOT

    async def verify_revision(self, snapshot):
        if self.changed:
            raise ConfigurationChanged("source_configuration_digest")
        return snapshot


def _port(operators=(OPERATOR,), configurations=None) -> PreproductionAuthorityPort:
    return PreproductionAuthorityPort(
        scope=fixtures.SCOPE,
        operators=operators,
        configurations=configurations or _Configurations(),
        clock=lambda: fixtures.UTC_NOW,
    )


class PreproductionAuthorityTests(unittest.IsolatedAsyncioTestCase):
    def test_production_scope_is_refused_at_construction(self) -> None:
        production = PublicationScope(environment=SourceEnvironment.prod, partition="shared")

        with self.assertRaises(ValueError):
            PreproductionAuthorityPort(
                scope=production,
                operators=[OPERATOR],
                configurations=_Configurations(),
            )

    def test_empty_allow_list_is_refused_at_construction(self) -> None:
        with self.assertRaises(ValueError):
            _port(operators=parse_operators(" , ,"))

    async def test_listed_operator_may_run_every_refresh_command(self) -> None:
        port = _port()

        for action in ("submit", "status", "cancel", "retry"):
            principal = await port.authorize(fixtures.IDENTITY, action, fixtures.SCOPE)
            self.assertEqual(principal, fixtures.PRINCIPAL)

    async def test_other_actions_and_principals_are_refused(self) -> None:
        with self.assertRaises(AuthorizationRevoked):
            await _port().authorize(fixtures.IDENTITY, "activate", fixtures.SCOPE)
        with self.assertRaises(AuthorizationRevoked):
            await _port(operators=["someone-else"]).authorize(
                fixtures.IDENTITY, "submit", fixtures.SCOPE
            )

    async def test_activation_is_bound_to_job_fence_and_configuration(self) -> None:
        authorization = await _port().reauthorize_activation(
            OPERATOR, fixtures.SNAPSHOT, fixtures.LEASE, fixtures.CANDIDATE
        )

        self.assertEqual(authorization.job_id, fixtures.LEASE.job_id)
        self.assertEqual(authorization.candidate_id, fixtures.CANDIDATE.candidate_id)
        self.assertEqual(authorization.fence, fixtures.LEASE.fence)
        self.assertEqual(
            authorization.config_digest, fixtures.SNAPSHOT.source_configuration_digest
        )
        self.assertEqual(authorization.policy_revision, POLICY_REVISION)
        self.assertEqual(authorization.expires_at, fixtures.UTC_NOW + ACTIVATION_AUTHORIZATION_TTL)
        self.assertLessEqual(ACTIVATION_AUTHORIZATION_TTL, timedelta(minutes=5))

    async def test_removed_initiating_operator_cannot_activate(self) -> None:
        with self.assertRaises(AuthorizationRevoked):
            await _port(operators=["someone-else"]).reauthorize_activation(
                OPERATOR, fixtures.SNAPSHOT, fixtures.LEASE, fixtures.CANDIDATE
            )

    async def test_candidate_from_another_fence_cannot_activate(self) -> None:
        stale = fixtures.CANDIDATE.model_copy(update={"fence": fixtures.LEASE.fence + 1})

        with self.assertRaises(StaleFence):
            await _port().reauthorize_activation(
                OPERATOR, fixtures.SNAPSHOT, fixtures.LEASE, stale
            )

    async def test_changed_configuration_cannot_activate(self) -> None:
        with self.assertRaises(ConfigurationChanged):
            await _port(configurations=_Configurations(changed=True)).reauthorize_activation(
                OPERATOR, fixtures.SNAPSHOT, fixtures.LEASE, fixtures.CANDIDATE
            )
