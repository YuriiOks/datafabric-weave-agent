"""US-22: write tools only write where agreed (server-side limits)."""

from __future__ import annotations

import pytest

from kp.config import Settings
from kp.errors import ConfigurationError, WriteNotPermittedError
from kp.writeback import (
    BranchNotPermittedError,
    InvalidStoryKeyError,
    JiraFieldNotPermittedError,
    PathNotPermittedError,
    RepositoryNotPermittedError,
    WriteGuard,
    branch_for_story,
    spec_id_for_story,
)

REPOSITORY = "example-org/example-specs"


def test_us22_target_is_derived_from_settings_and_story_key(settings: Settings) -> None:
    target = WriteGuard(settings).authorise_publish("PAY-101")

    assert target.repository == REPOSITORY
    assert target.path == "specs/PAY-101.md"
    assert target.branch == branch_for_story("PAY-101") == "spec/pay-101"
    assert spec_id_for_story("PAY-101") == "spec-pay-101"


def test_us22_naming_the_agreed_target_is_accepted(settings: Settings) -> None:
    target = WriteGuard(settings).authorise_publish(
        "PAY-101",
        repository=REPOSITORY.upper(),
        path="specs/PAY-101.md",
        branch="spec/pay-101",
    )

    assert target.repository == REPOSITORY


@pytest.mark.parametrize(
    ("overrides", "error"),
    [
        ({"repository": "other-org/other-repo"}, RepositoryNotPermittedError),
        ({"path": "other/PAY-101.md"}, PathNotPermittedError),
        ({"path": "specs/../etc/PAY-101.md"}, PathNotPermittedError),
        ({"path": "/specs/PAY-101.md"}, PathNotPermittedError),
        ({"path": "specs/OTHER-1.md"}, PathNotPermittedError),
        ({"branch": "main"}, BranchNotPermittedError),
        ({"branch": "MAIN"}, BranchNotPermittedError),
        ({"branch": "spec/other"}, BranchNotPermittedError),
    ],
)
def test_us22_other_targets_are_refused(
    settings: Settings, overrides: dict[str, str], error: type[WriteNotPermittedError]
) -> None:
    with pytest.raises(error):
        WriteGuard(settings).authorise_publish("PAY-101", **overrides)


@pytest.mark.parametrize(
    "key", ["pay-101", "PAY-101/../x", "PAY-", "../PAY-1", "PAY-101 ", "PAY-101\n", ""]
)
def test_us22_story_key_must_be_a_plain_tracker_key(settings: Settings, key: str) -> None:
    with pytest.raises(InvalidStoryKeyError):
        WriteGuard(settings).authorise_publish(key)
    with pytest.raises(InvalidStoryKeyError):
        WriteGuard(settings).authorise_jira_fields(key, None)


@pytest.mark.parametrize(
    "overrides",
    [
        {"spec_repo": None},
        {"spec_path": None},
        {"spec_repo": "<org>/<repository>"},
        {"spec_path": "  "},
    ],
)
def test_us22_unset_write_targets_refuse_everything(overrides: dict[str, str | None]) -> None:
    unset = Settings(_env_file=None, spec_repo=REPOSITORY, spec_path="specs").model_copy(
        update=overrides
    )

    with pytest.raises(ConfigurationError):
        WriteGuard(unset).authorise_publish("PAY-101")


def test_us22_default_settings_write_nowhere() -> None:
    guard = WriteGuard(Settings(_env_file=None))

    with pytest.raises(ConfigurationError):
        guard.authorise_publish("PAY-101")
    with pytest.raises(ConfigurationError):
        guard.authorise_jira_fields("PAY-101", None)


def test_us22_jira_target_is_status_and_the_configured_link_field(settings: Settings) -> None:
    target = WriteGuard(settings).authorise_jira_fields("PAY-101", None)

    assert (target.status_field, target.link_field) == ("status", "spec_link")


@pytest.mark.parametrize("fields", [{"priority": "High"}, {"status": "Done", "assignee": "x"}])
def test_us22_a_third_jira_field_is_refused(settings: Settings, fields: dict[str, str]) -> None:
    with pytest.raises(JiraFieldNotPermittedError):
        WriteGuard(settings).authorise_jira_fields("PAY-101", fields)


def test_us22_a_different_status_or_link_value_is_refused(settings: Settings) -> None:
    guard = WriteGuard(settings)
    target = guard.authorise_jira_fields("PAY-101", None)

    guard.verify_jira_values(
        target, {"status": "Spec drafted", "spec_link": "local-pr:1"}, link="local-pr:1"
    )
    with pytest.raises(JiraFieldNotPermittedError):
        guard.verify_jira_values(target, {"status": "Done"}, link="local-pr:1")
    with pytest.raises(JiraFieldNotPermittedError):
        guard.verify_jira_values(target, {"spec_link": "elsewhere"}, link="local-pr:1")


def test_us22_verifying_a_field_that_was_never_authorised_is_a_refusal_not_a_key_error(
    settings: Settings,
) -> None:
    guard = WriteGuard(settings)
    target = guard.authorise_jira_fields("PAY-101", None)

    with pytest.raises(JiraFieldNotPermittedError):
        guard.verify_jira_values(target, {"priority": "High"}, link="local-pr:1")


@pytest.mark.parametrize(
    "allowed",
    [("status",), ("status", "a", "b"), ("a", "b"), ("status", "status")],
)
def test_us22_jira_needs_exactly_two_fields_one_of_them_status(allowed: tuple[str, ...]) -> None:
    configured = Settings(_env_file=None).model_copy(update={"jira_fields_allowed": allowed})

    with pytest.raises(ConfigurationError):
        WriteGuard(configured).authorise_jira_fields("PAY-101", None)
