"""Server-side write limits: one repository, one spec path, two Jira fields.

Everything an agent could aim a write at is derived here from settings and the story key.
A request that names a different target is refused with a typed error (the caller records
it); a request that names the agreed target is simply accepted. Unset or placeholder
settings refuse everything: a missing limit is never read as "no limit".
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass

from kp.config import Settings
from kp.errors import ConfigurationError
from kp.writeback.errors import (
    BranchNotPermittedError,
    InvalidStoryKeyError,
    JiraFieldNotPermittedError,
    PathNotPermittedError,
    RepositoryNotPermittedError,
)
from kp.writeback.models import SPEC_DRAFTED_STATUS

BRANCH_PREFIX = "spec/"
STATUS_FIELD = "status"

_STORY_KEY = re.compile(r"[A-Z][A-Z0-9]{1,15}-[1-9][0-9]{0,8}")
_ALLOWED_JIRA_FIELDS = 2


@dataclass(frozen=True, slots=True)
class PublishTarget:
    """The one place a spec may be written for a story."""

    repository: str
    path: str
    branch: str


@dataclass(frozen=True, slots=True)
class JiraTarget:
    """The two Jira fields that may be written."""

    status_field: str
    link_field: str


def require_story_key(story_key: str) -> str:
    """Check that a story key is a plain tracker key.

    :param story_key: The key an agent named
    :return: The same key
    :raises InvalidStoryKeyError: If it is not of the form ``ABC-123``
    """
    if not _STORY_KEY.fullmatch(story_key):
        raise InvalidStoryKeyError("Story key is not a plain tracker key")
    return story_key


def spec_id_for_story(story_key: str) -> str:
    """Derive the spec identifier of a story.

    :param story_key: A valid story key
    :return: ``spec-<key in lower case>``
    """
    return f"spec-{story_key.lower()}"


def branch_for_story(story_key: str) -> str:
    """Derive the spec branch of a story. The same story always gets the same branch.

    :param story_key: A valid story key
    :return: ``spec/<key in lower case>``
    """
    return f"{BRANCH_PREFIX}{story_key.lower()}"


def _configured(value: str | None, setting: str) -> str:
    stripped = (value or "").strip()
    if not stripped or (stripped.startswith("<") and stripped.endswith(">")):
        raise ConfigurationError(f"{setting} must be set before the write tools can write")
    return stripped


class WriteGuard:
    """Applies the write limits from settings.

    :param settings: Platform settings; ``spec_repo``, ``spec_path`` and
        ``jira_fields_allowed`` are the server-side constants
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings

    def authorise_publish(
        self,
        story_key: str,
        *,
        repository: str | None = None,
        path: str | None = None,
        branch: str | None = None,
    ) -> PublishTarget:
        """Resolve the publish target for a story and refuse anything else.

        :param story_key: The story the spec belongs to
        :param repository: A repository the agent asked for, if any
        :param path: A path the agent asked for, if any
        :param branch: A branch the agent asked for, if any
        :return: The repository, path and branch to use
        :raises InvalidStoryKeyError: If the story key is not a plain key
        :raises RepositoryNotPermittedError: If another repository was requested
        :raises PathNotPermittedError: If another path was requested
        :raises BranchNotPermittedError: If another branch (or a protected one) was requested
        :raises kp.errors.ConfigurationError: If the write targets are not configured
        """
        require_story_key(story_key)
        allowed_repository = _configured(self._settings.spec_repo, "KP_SPEC_REPO")
        prefix = _configured(self._settings.spec_path, "KP_SPEC_PATH").strip("/")
        expected_path = f"{prefix}/{story_key}.md"
        expected_branch = branch_for_story(story_key)
        if (
            repository is not None
            and repository.strip().casefold() != allowed_repository.casefold()
        ):
            raise RepositoryNotPermittedError("Repository is not the configured spec repository")
        if path is not None and path != expected_path:
            raise PathNotPermittedError("Path is not the story's spec path")
        # The expected branch always starts with BRANCH_PREFIX, so it is never a protected
        # name; refusing everything else therefore refuses every protected branch as well.
        if branch is not None and branch != expected_branch:
            raise BranchNotPermittedError("Branch is not the story's spec branch")
        return PublishTarget(allowed_repository, expected_path, expected_branch)

    def authorise_jira_fields(
        self, story_key: str, requested: Mapping[str, str] | None
    ) -> JiraTarget:
        """Resolve the two writable Jira fields and refuse any other field name.

        :param story_key: The story to update
        :param requested: Field names the agent asked to change, if any
        :return: The status field and the link field
        :raises InvalidStoryKeyError: If the story key is not a plain key
        :raises JiraFieldNotPermittedError: If a field other than the two agreed was named
        :raises kp.errors.ConfigurationError: If the allowed fields are not exactly two,
            one of them ``status``
        """
        require_story_key(story_key)
        allowed = self._settings.jira_fields_allowed
        if len(set(allowed)) != _ALLOWED_JIRA_FIELDS or STATUS_FIELD not in allowed:
            raise ConfigurationError(
                f"KP_JIRA_FIELDS_ALLOWED must name exactly two fields, one of them {STATUS_FIELD}"
            )
        link_field = next(name for name in allowed if name != STATUS_FIELD)
        if requested is not None and not set(requested) <= set(allowed):
            raise JiraFieldNotPermittedError("A Jira field outside the agreed two was requested")
        return JiraTarget(STATUS_FIELD, link_field)

    @staticmethod
    def verify_jira_values(
        target: JiraTarget, requested: Mapping[str, str] | None, *, link: str
    ) -> None:
        """Refuse values other than the ones the server would write anyway.

        :param target: The writable fields
        :param requested: The agent's view of the change, if any
        :param link: The pull request link the server will write
        :raises JiraFieldNotPermittedError: If the agent asked for a different value, or for a
            field other than the two writable ones
        """
        if requested is None:
            return
        expected = {target.status_field: SPEC_DRAFTED_STATUS, target.link_field: link}
        if any(expected.get(name) != value for name, value in requested.items()):
            raise JiraFieldNotPermittedError("A Jira field value differs from the agreed update")
