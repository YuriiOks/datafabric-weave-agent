"""Errors raised by the publication package."""

from __future__ import annotations

from kp.errors import KpError


class PublishError(KpError):
    """Base class of failures in the publish package."""


class UnknownKnowledgeVersionError(PublishError):
    """No knowledge version with the requested identity exists."""
