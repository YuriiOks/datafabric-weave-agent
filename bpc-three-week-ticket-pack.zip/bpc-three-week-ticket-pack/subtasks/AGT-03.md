---
pack_id: "bpc-sep26-v1"
local_id: "AGT-03"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1345"
summary: "Publish evidence-backed Agent-to-Skill and Agent-to-MCP declarations"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-18"
planned_due: "2026-09-18"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["AGT-01","AGT-02","CORE-03","CORE-04","SKL-03","MCP-03"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-agt-03"
architecture_sections: ["graph model","identity","ingestion","publication"]
---

# Publish evidence-backed Agent-to-Skill and Agent-to-MCP declarations

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1345**. Local reference **AGT-03** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-18 → 2026-09-18 (D8–D8)**.
- Recommendation extension: **2026-09-18 → 2026-09-18 (D8–D8)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

Build the Agent-specific adapter from approved workbook declarations into shared relation facts. The active graph must show only exactly resolved Agent `USES_SKILL` and `USES_MCP` facts, with source provenance and an honest unresolved-reference ledger.

## Scope

- Extract only declared Agent references from the reconciled workbook fields.
- Resolve Skill and MCP targets through the shared typed alias/resolution contract. A tool-to-server mapping is permitted only when it has exact mapping evidence.
- Persist each resolved relation with publication, source/target component IDs, relation kind, qualifier, stable relation key and evidence-set digest. Aggregate repeated source evidence into one logical relation.
- Record original token, field/row locator, method and outcome in restricted resolution evidence; unresolved, conflicting or unknown tokens stay outside the resolved edge set.

## Boundaries

A source declaration is neither execution telemetry nor a relevance, permission, recommendation or approval signal. Do not use string heuristics to turn a plausible MCP tool name into a server relation. Do not execute MCP servers or Skills.

## Technical steps

1. Consume the AGT-01 typed field map and AGT-02 identity outcomes.
2. Normalise declared reference tokens without discarding the protected original evidence.
3. Resolve each token by expected type and scope; quarantine non-exact outcomes.
4. Produce shared relation facts and the corresponding graph projection through CORE-04.
5. Compare consecutive complete snapshots so a removed declaration is retired only through the shared publication lifecycle.

## Acceptance criteria

- Every published Agent relation identifies its source snapshot/field locator and exact resolved target.
- Repeated declarations from several source rows produce one stable logical relation with aggregated evidence, not duplicate edges.
- An unrecognised Skill token, ambiguous MCP mapping or wrong-scope target creates a visible unresolved reference and no edge.
- A later approved complete snapshot without a previously declared relation removes it only through the shared immutable publication/retirement process; the active graph never mixes old and new relation sets.
- Graph output contains no inferred `recommended`, `executed`, `approved` or native-Hub relationship.

## Evidence to attach

Redacted relation-fixture manifest, resolved/unresolved ledger, source-to-edge evidence sample, publication diff and retirement evidence.

## Dependencies / blockers

Requires AGT-01, AGT-02, CORE-03 and CORE-04. Blocks AGT-04 and conditional AGT-05.

## Out of scope

Skill-owned dependency parsing, MCP transport/execution, any Agent Hub API and recommendation scoring.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [AGT-01](AGT-01.md) must finish its stated contract boundary before this task starts.
- [AGT-02](AGT-02.md) must finish its stated contract boundary before this task starts.
- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.
- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [SKL-03](SKL-03.md) must finish its stated contract boundary before this task starts.
- [MCP-03](MCP-03.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `graph model`, `identity`, `ingestion`, `publication`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
