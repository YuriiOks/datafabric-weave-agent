"""The freshness check (US-08): which sources are stale and which keep failing."""

from __future__ import annotations

import logging
from collections.abc import Collection
from datetime import datetime, timedelta

from kp.config import Thresholds
from kp.domain import SourceKind, SweepCursor
from kp.sweep.models import Alert, FreshnessReport, SourceFreshness
from kp.sweep.store import SweepStore

logger = logging.getLogger(__name__)


def check_freshness(
    store: SweepStore,
    *,
    now: datetime,
    thresholds: Thresholds | None = None,
    expected: Collection[SourceKind] = (),
) -> FreshnessReport:
    """List sources without a recent successful sweep and sources that keep failing.

    A source is stale when its last successful sweep is older than
    ``thresholds.stale_after_hours``, or when it never succeeded. An alert stands for every
    source whose last ``thresholds.fetch_failures_before_alert`` sweeps in a row failed.

    :param store: Store on an open connection
    :param now: The time to measure against
    :param thresholds: Staleness and alert limits; the defaults when omitted
    :param expected: Sources that must have been swept; one with no saved cursor is stale
    :return: The stale sources (with last success time) and the alerts
    """
    limits = thresholds or Thresholds()
    cursors = store.list_cursors()
    if expected:
        cursors = [cursor for cursor in cursors if cursor.source in expected]
    stale = [_freshness(cursor, now) for cursor in cursors if _is_stale(cursor, now, limits)]
    swept = {cursor.source for cursor in cursors}
    stale.extend(SourceFreshness(source=source) for source in sorted(set(expected) - swept))
    alerts = [
        Alert(
            source=cursor.source,
            scope=cursor.scope,
            consecutive_failures=cursor.consecutive_failures,
            last_attempt_at=cursor.last_attempt_at,
            raised_at=now,
        )
        for cursor in cursors
        if cursor.consecutive_failures >= limits.fetch_failures_before_alert
    ]
    report = FreshnessReport(checked_at=now, stale=tuple(stale), alerts=tuple(alerts))
    if report.stale:
        logger.warning("Stale sources found", extra={"count": len(report.stale)})
    return report


def _is_stale(cursor: SweepCursor, now: datetime, limits: Thresholds) -> bool:
    if cursor.last_success_at is None:
        return True
    return now - cursor.last_success_at > timedelta(hours=limits.stale_after_hours)


def _freshness(cursor: SweepCursor, now: datetime) -> SourceFreshness:
    age = None
    if cursor.last_success_at is not None:
        age = (now - cursor.last_success_at).total_seconds() / 3600
    return SourceFreshness(
        source=cursor.source,
        scope=cursor.scope,
        last_success_at=cursor.last_success_at,
        age_hours=age,
        consecutive_failures=cursor.consecutive_failures,
    )
