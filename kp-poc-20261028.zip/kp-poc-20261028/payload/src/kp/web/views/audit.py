"""Audit: the recorded tool calls, refusals included, optionally for one spec.

A record is shown to a viewer only when every domain it applied lies within the viewer's own, so
the trail never shows what the viewer's access would not have returned. The platform keeps no
list of every record: this page lists the calls behind each spec, plus the calls made from this
interface. A call made elsewhere and tagged with no spec is not listed.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime

from kp.domain import ToolCallRecord
from kp.errors import AccessForbiddenError, KpError
from kp.links.rules import loaded_story_keys
from kp.tools import AuditStore
from kp.web.errors import Problem, problem_from
from kp.web.identity import Viewer, session_id_for
from kp.web.query import QueryForm
from kp.web.state import WebState
from kp.writeback import SpecRepository, load_story

_REQUEST_PREVIEW = 160


@dataclass(frozen=True, slots=True)
class AuditRow:
    """One recorded call, ready to draw."""

    called_at: datetime
    caller: str
    agent: str
    tool: str
    spec_id: str
    domains: str
    items_returned: int
    filtered_count: int
    latency_ms: float
    outcome: str
    detail: str
    request: str


@dataclass(frozen=True, slots=True)
class AuditView:
    """The audit page.

    :ivar spec: The spec filtered on (empty for every record the viewer may see).
    :ivar specs: The specs the viewer may filter on.
    :ivar total: How many records match, before the list is cut.
    """

    spec: str = ""
    specs: tuple[str, ...] = ()
    rows: tuple[AuditRow, ...] = ()
    total: int = 0
    problem: Problem | None = None


def read_audit(state: WebState, viewer: Viewer, form: QueryForm) -> AuditView:
    """List the recorded calls the viewer may see.

    :param state: The shared state
    :param viewer: Who is asking
    :param form: The query string of the request
    :return: The view
    """
    spec = ""
    specs: tuple[str, ...] = ()
    try:
        state.require_access(viewer)
        spec = form.text("spec")
        specs = _visible_specs(state, viewer)
        # A spec the viewer may not see is refused whether or not it exists.
        if spec and spec not in specs:
            raise AccessForbiddenError("The spec is unknown or belongs to a domain not readable")
        records = _records(state, viewer, spec, specs)
        visible = sorted(
            (record for record in records if set(record.domains_applied) <= viewer.domains),
            key=lambda record: (record.called_at, record.call_id),
            reverse=True,
        )
        shown = visible[: state.settings.audit_limit]
        return AuditView(spec, specs, tuple(_row(record) for record in shown), len(visible))
    except KpError as exc:
        return AuditView(spec, specs, problem=problem_from(exc))


def _visible_specs(state: WebState, viewer: Viewer) -> tuple[str, ...]:
    found = []
    with state.application.database.transaction() as connection:
        repository = SpecRepository(connection)
        for key in loaded_story_keys(connection):
            if not viewer.may_read(load_story(connection, key).domain):
                continue
            spec = repository.get_by_story(key)
            if spec is not None:
                found.append(spec.spec_id)
    return tuple(sorted(found))


def _records(
    state: WebState, viewer: Viewer, spec: str, specs: tuple[str, ...]
) -> list[ToolCallRecord]:
    sessions = {viewer.caller.session_id} | {
        session_id_for(user) for user in state.identity.selectable_users
    }
    records: dict[str, ToolCallRecord] = {}
    with state.application.database.transaction() as connection:
        store = AuditStore(connection)
        for found in store.list_for_spec(spec) if spec else _everything(store, specs, sessions):
            records[found.call_id] = found
    return list(records.values())


def _everything(
    store: AuditStore, specs: tuple[str, ...], sessions: set[str]
) -> list[ToolCallRecord]:
    return [
        *(record for spec in specs for record in store.list_for_spec(spec)),
        *(record for session in sorted(sessions) for record in store.list_for_session(session)),
    ]


def _row(record: ToolCallRecord) -> AuditRow:
    if record.refused:
        outcome, detail = "Refused", record.refusal_reason or ""
    elif record.error_class:
        outcome, detail = "Failed", record.error_class
    else:
        outcome, detail = "Answered", ""
    request = json.dumps(record.request, sort_keys=True, ensure_ascii=True)
    return AuditRow(
        called_at=record.called_at,
        caller=record.caller,
        agent=record.agent,
        tool=record.tool,
        spec_id=record.spec_id or "",
        domains=", ".join(record.domains_applied) or "none",
        items_returned=record.items_returned,
        filtered_count=record.filtered_count,
        latency_ms=record.latency_ms,
        outcome=outcome,
        detail=detail,
        request=request[:_REQUEST_PREVIEW] + ("..." if len(request) > _REQUEST_PREVIEW else ""),
    )
