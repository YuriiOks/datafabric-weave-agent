"""The pages work offline and read well to assistive technology; bad input gets a plain message."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from kp.web import render
from kp.web.app import create_app
from kp.web.settings import WebSettings
from web.conftest import WebWorld
from web.web_support import BARE_PAGES, PAGES, structure_of

FORBIDDEN_IN_ASSETS = ("http:", "https:", "@import", "<script", "<img", "url(", "//cdn")


@pytest.mark.parametrize("path", [*PAGES, *BARE_PAGES])
def test_every_page_is_semantic_labelled_and_self_contained(client: TestClient, path: str) -> None:
    response = client.get(path)
    found = structure_of(response.text)

    assert response.status_code == 200
    assert found.language == "en"
    assert found.landmarks >= {"header", "nav", "main", "footer"}
    assert found.skip_link
    assert [level for level, _ in found.headings].count("h1") == 1
    assert found.scripts == 0
    assert found.images == 0
    assert found.external == []
    assert found.table_headers_without_scope == 0
    # Every visible control has a label that points at it.
    assert set(found.controls) <= found.labels_for
    response.text.encode("ascii")


def test_the_assets_name_no_other_host_and_load_no_script_font_or_image() -> None:
    assets = [*render.TEMPLATES.glob("*.html"), *render.STATIC.glob("*")]

    assert assets
    for path in assets:
        text = path.read_text(encoding="utf-8")
        text.encode("ascii")
        for forbidden in FORBIDDEN_IN_ASSETS:
            assert forbidden not in text, f"{path.name} contains {forbidden!r}"


def test_the_stylesheet_is_served_by_the_application_and_is_small(client: TestClient) -> None:
    response = client.get("/static/kp.css")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/css")
    assert ":focus-visible" in response.text
    assert len(Path(render.STATIC / "kp.css").read_bytes()) < 20_000


def test_pages_carry_headers_that_keep_them_self_contained(client: TestClient) -> None:
    headers = client.get("/").headers

    assert "default-src 'none'" in headers["content-security-policy"]
    assert headers["x-content-type-options"] == "nosniff"
    assert headers["referrer-policy"] == "no-referrer"


def test_a_page_is_never_stored_by_a_shared_cache(client: TestClient) -> None:
    headers = client.get("/").headers

    assert headers["cache-control"] == "no-store"
    assert headers["vary"] == "X-KP-Caller"
    assert "cache-control" not in client.get("/static/kp.css").headers


def test_an_unexpected_failure_is_a_plain_500_that_still_carries_the_headers(
    web_world: WebWorld,
) -> None:
    def explode() -> None:
        raise RuntimeError("a secret-looking detail")

    application = web_world.world.application
    app = create_app(application, settings=WebSettings(), connectivity=web_world.connectivity)
    app.add_api_route("/boom", explode)

    response = TestClient(app, raise_server_exceptions=False).get("/boom")

    assert response.status_code == 500
    assert response.text == "The request could not be completed."
    assert "secret-looking" not in response.text
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["cache-control"] == "no-store"


def test_the_interactive_api_documentation_is_off(client: TestClient) -> None:
    assert client.get("/docs").status_code == 404
    assert client.get("/openapi.json").status_code == 404


@pytest.mark.parametrize(
    ("path", "params", "message"),
    [
        ("/search", {"q": "currency", "as_at": "yesterday"}, "As at must be a date written as"),
        ("/search", {"q": "x" * 501}, "Enter at most 500 characters."),
        ("/rule", {"number": "four"}, "Use a clause number such as 4.2.1"),
        ("/rule", {"number": "4.2.1", "as_at": "2026-13-45"}, "As at must be a date"),
        ("/coverage", {"offset": "-1"}, "The start must be a whole number"),
        ("/impact", {"clause": "no-such-thing"}, "Use a clause number such as 4.2.1"),
    ],
)
def test_input_that_cannot_be_used_gets_a_plain_message_and_a_400(
    client: TestClient, path: str, params: dict[str, str], message: str
) -> None:
    response = client.get(path, params=params)

    assert response.status_code == 400
    assert message in response.text
    assert "Check what you entered" in response.text
    assert "Traceback" not in response.text


def test_a_date_before_any_edition_says_no_edition_was_in_force(client: TestClient) -> None:
    response = client.get("/rule", params={"number": "4.2.1", "as_at": "2001-01-01"})

    assert response.status_code == 200
    assert "No edition was in force on 2001-01-01" in response.text


def test_an_unknown_page_is_not_found(client: TestClient) -> None:
    assert client.get("/no-such-page").status_code == 404
