"""Produce the relation evidence for one build, and optionally its publication diff.

A dry run in the strictest sense: it reads an export and a skills checkout, builds the
catalogue exactly as the ingest does, and writes one JSON report. It opens no database,
calls no gateway and computes no embedding.

The report carries, per link type, what the sources declared against what was
published; the review ledger's unresolved references by outcome; a sample of relations
with their evidence; and, when a previous export and checkout are given, the
relation-level diff and the transition gate's verdict on it. Component names, raw
tokens and component ids are replaced by digests unless ``--include-ids`` is passed, so
the default report can be attached to a ticket.

The transition gate has no production caller yet; this command is the only path that
evaluates the relation retirement rule end to end.

Usage::

    python -m app.recsys.relation_evidence --export DIR --skills-repo DIR \\
        --environment ppd --partition default --out report.json \\
        [--reference-rules FILE] [--previous-export DIR --previous-skills-repo DIR] \\
        [--sample N] [--include-ids]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from app.recsys.contracts import LinkType, PublicationScope, SourceEnvironment
from app.recsys.ingest import read_skills_repo
from app.recsys.registry import INGEST_CODE_VERSION
from app.recsys.registry.catalogue_build import BuildResult, build_components
from app.recsys.registry.excel_reader import ExportError, read_export
from app.recsys.registry.flags import apply_flags
from app.recsys.registry.links import build_links
from app.recsys.registry.models import ComponentLink
from app.recsys.registry.owner_rules import ReferenceRuleFileError, load_reference_rules
from app.recsys.registry.relations.counts import count_relations
from app.recsys.registry.relations.diff import relation_facts
from app.recsys.registry.transition.gate import evaluate_transition, row_fact
from app.recsys.registry.transition.models import (
    DEFAULT_RETIREMENT_POLICY,
    PriorPublication,
    TransitionDecision,
)
from app.recsys.registry.writer import compute_version

#: Report layout version; bump when a key changes meaning.
REPORT_VERSION = "relation-evidence-v1"

#: A locator that names only a sheet and a row number.
_SHEET_ROW = re.compile(r"sheet=[^;]+;row=\d+")


@dataclass(slots=True)
class _Built:
    """One build and the version id its inputs would get."""

    version: str
    build: BuildResult
    links: list[ComponentLink]


def _digest(text: str | None) -> str | None:
    """:return: A short ``sha256:`` digest of the text, or ``None``."""
    if text is None:
        return None
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _build(
    export: Path,
    skills_repo: Path,
    scope: PublicationScope,
    reference_rules: Path | None,
) -> _Built:
    """Build components and links exactly as the ingest does, without persisting.

    :param export: The export directory or workbook.
    :param skills_repo: The skills checkout root.
    :param scope: The publication scope.
    :param reference_rules: An owner reference-rule file, if any.
    :return: The build, its links and the version id its inputs would get.
    """
    tables = read_export(export)
    skills, repo_input = read_skills_repo(skills_repo)
    rules = (
        load_reference_rules(reference_rules, scope).rules
        if reference_rules is not None
        else None
    )
    build = build_components(
        tables,
        skills,
        scope,
        code_version=INGEST_CODE_VERSION,
        reference_rules=rules,
    )
    links = build_links(build.catalogue, build.rows).links
    apply_flags(build.rows)
    version = compute_version(
        descriptor.hash for descriptor in [*tables.inputs, repo_input]
    )
    return _Built(version=version, build=build, links=links)


def _render_link(link: ComponentLink, include_ids: bool) -> dict[str, Any]:
    """Render one relation and its evidence.

    :param link: The link, carrying its key, digest and evidence.
    :param include_ids: Keep component ids and raw tokens instead of digests.
    :return: A JSON-serialisable mapping.
    """
    evidence = []
    for entry in link.evidence:
        rendered = entry.as_dict()
        if not include_ids:
            rendered["raw_value"] = _digest(rendered["raw_value"])
            # A sheet row locator is structure only; any other locator may carry a
            # folder or file name, which is a component name.
            if not _SHEET_ROW.fullmatch(rendered["structural_locator"]):
                rendered["structural_locator"] = _digest(rendered["structural_locator"])
        evidence.append(rendered)
    return {
        "relation_key": link.relation_key,
        "link_type": link.link_type.value,
        "src_id": link.src_id if include_ids else _digest(link.src_id),
        "dst_id": link.dst_id if include_ids else _digest(link.dst_id),
        "source": link.source,
        "matched_indexes": list(link.matched_indexes),
        "resolution_rules": list(link.resolution_rules),
        "evidence_digest": link.evidence_digest,
        "evidence": evidence,
    }


def _ledger_section(build: BuildResult, include_ids: bool) -> dict[str, Any]:
    """Summarise the unresolved references; list them only with ``include_ids``.

    :param build: The candidate build.
    :param include_ids: Also list every reference entry.
    :return: Counts by link type, outcome and reason, and optionally the entries.
    """
    histogram: dict[str, int] = {}
    entries = [entry for entry in build.ledger.entries if entry.kind == "reference"]
    for entry in entries:
        key = "|".join(
            [
                entry.link_type or "unknown",
                entry.resolution_outcome or "unknown",
                entry.reason,
            ]
        )
        histogram[key] = histogram.get(key, 0) + 1
    section: dict[str, Any] = {
        "unresolved_references": len(entries),
        "unattributed_references": sum(
            1 for entry in entries if entry.owner_component_id is None
        ),
        "by_link_type_outcome_reason": dict(sorted(histogram.items())),
    }
    if include_ids:
        section["entries"] = [entry.as_dict() for entry in entries]
    return section


def _transition_section(
    previous: _Built,
    candidate: _Built,
    scope: PublicationScope,
    include_ids: bool,
) -> dict[str, Any]:
    """Evaluate the candidate against the previous build through the transition gate.

    :param previous: The build that stands in for the current publication.
    :param candidate: The candidate build.
    :param scope: The publication scope both builds ran under.
    :param include_ids: Keep component ids in the component-level diff.
    :return: The relation diff, the component diff counts and the gate's verdict.
    """
    decision: TransitionDecision = evaluate_transition(
        prior=PriorPublication(
            version=previous.version,
            scope=scope,
            components={row.component_id: row_fact(row) for row in previous.build.rows},
        ),
        to_version=candidate.version,
        scope=scope,
        candidate={row.component_id: row_fact(row) for row in candidate.build.rows},
        manifests=[
            batch.manifest
            for batch in candidate.build.catalogue.source_batches
            if batch.manifest is not None
        ],
        policy=DEFAULT_RETIREMENT_POLICY,
        prior_relations=relation_facts(previous.links),
        candidate_relations=relation_facts(candidate.links),
    )
    relation_diff = decision.relation_diff
    if relation_diff is None:
        raise RuntimeError("the gate returned no relation diff for two relation maps")
    breaches = []
    for breach in decision.breaches:
        rendered = breach.model_dump(mode="json")
        if not include_ids:
            rendered["component_ids"] = [
                _digest(item) for item in rendered["component_ids"]
            ]
        breaches.append(rendered)
    return {
        "from_version": decision.from_version,
        "to_version": decision.to_version,
        "allowed": decision.allowed,
        "breaches": breaches,
        "declarations": [
            item.model_dump(mode="json") for item in decision.declarations
        ],
        "component_diff": {
            name: len(getattr(decision.diff, name))
            for name in ("added", "retired", "changed", "unchanged")
        },
        "relation_diff": {
            "added": len(relation_diff.added),
            "retired": len(relation_diff.retired),
            "changed": len(relation_diff.changed),
            "unchanged": len(relation_diff.unchanged),
            "retired_keys": relation_diff.retired,
            "changed_keys": relation_diff.changed,
        },
    }


def build_report(
    *,
    export: Path,
    skills_repo: Path,
    scope: PublicationScope,
    reference_rules: Path | None = None,
    previous_export: Path | None = None,
    previous_skills_repo: Path | None = None,
    sample: int = 5,
    include_ids: bool = False,
) -> dict[str, Any]:
    """Build the relation evidence report.

    :param export: The candidate export.
    :param skills_repo: The candidate skills checkout.
    :param scope: The publication scope.
    :param reference_rules: An owner reference-rule file, applied to both builds.
    :param previous_export: The export standing in for the current publication.
    :param previous_skills_repo: The checkout standing in for the current publication.
    :param sample: How many relations to show with their evidence.
    :param include_ids: Keep component ids and raw tokens instead of digests.
    :return: The report.
    :raises ValueError: If only one of the two previous inputs is given.
    """
    if (previous_export is None) != (previous_skills_repo is None):
        raise ValueError("--previous-export and --previous-skills-repo go together")
    candidate = _build(export, skills_repo, scope, reference_rules)
    counts = count_relations(candidate.build.catalogue, candidate.links)
    ordered = sorted(candidate.links, key=lambda link: link.relation_key or "")
    report: dict[str, Any] = {
        "report_version": REPORT_VERSION,
        "ingest_code_version": INGEST_CODE_VERSION,
        "candidate_version": candidate.version,
        "scope": {"environment": scope.environment.value, "partition": scope.partition},
        "closed_link_types": [link_type.value for link_type in LinkType],
        "link_types_present": sorted({link.link_type.value for link in candidate.links}),
        "relations": len(candidate.links),
        "evidence_entries": sum(len(link.evidence) for link in candidate.links),
        "by_link_type": {name: bucket.as_dict() for name, bucket in counts.items()},
        "ledger": _ledger_section(candidate.build, include_ids),
        "evidence_sample": [
            _render_link(link, include_ids) for link in ordered[: max(sample, 0)]
        ],
    }
    if previous_export is not None and previous_skills_repo is not None:
        previous = _build(previous_export, previous_skills_repo, scope, reference_rules)
        report["transition"] = _transition_section(
            previous, candidate, scope, include_ids
        )
    return report


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m app.recsys.relation_evidence",
        description="Write the relation evidence report for one build (no database).",
    )
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--skills-repo", type=Path, required=True)
    parser.add_argument("--reference-rules", type=Path)
    parser.add_argument("--previous-export", type=Path)
    parser.add_argument("--previous-skills-repo", type=Path)
    parser.add_argument(
        "--environment",
        required=True,
        choices=[environment.value for environment in SourceEnvironment],
    )
    parser.add_argument("--partition", required=True)
    parser.add_argument("--sample", type=int, default=5)
    parser.add_argument("--include-ids", action="store_true")
    parser.add_argument("--out", type=Path, required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command.

    :param argv: Arguments; defaults to the process arguments.
    :return: The process exit code.
    """
    args = _parser().parse_args(argv)
    scope = PublicationScope(
        environment=SourceEnvironment(args.environment), partition=args.partition
    )
    try:
        report = build_report(
            export=args.export,
            skills_repo=args.skills_repo,
            scope=scope,
            reference_rules=args.reference_rules,
            previous_export=args.previous_export,
            previous_skills_repo=args.previous_skills_repo,
            sample=args.sample,
            include_ids=args.include_ids,
        )
    except (ValueError, ExportError, ReferenceRuleFileError) as error:
        print(f"relation_evidence: {error}", file=sys.stderr)
        return 2
    args.out.write_text(
        json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
