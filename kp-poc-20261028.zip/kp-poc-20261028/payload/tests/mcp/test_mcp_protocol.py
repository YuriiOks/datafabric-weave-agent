"""JSON-RPC 2.0 and MCP behaviour of the server, tested in-process."""

from __future__ import annotations

import importlib.metadata
import json
import logging

import pytest
from mcp_fixtures import *  # noqa: F403 - pytest fixtures
from pydantic import JsonValue

from kp.log import JsonFormatter
from kp.mcp import ErrorCode, McpServer
from kp.mcp.server import SERVER_VERSION
from kp.tools import Caller, build_caller
from kp.tools.testing import InMemoryAudit

FULL = build_caller(user="user-full-access", agent="spec-agent", session_id="s-full")
NONE = build_caller(user="user-no-access", agent="spec-agent", session_id="s-none")
ONE = build_caller(user="user-one-domain", agent="spec-agent", session_id="s-one")


def rpc(
    server: McpServer,
    method: str,
    params: dict[str, JsonValue] | None = None,
    *,
    caller: Caller = FULL,
    request_id: JsonValue = 1,
) -> dict[str, JsonValue]:
    message: dict[str, JsonValue] = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        message["params"] = params
    response = server.handle(message, caller)
    assert response is not None
    return response


def error_of(response: dict[str, JsonValue]) -> dict[str, JsonValue]:
    error = response["error"]
    assert isinstance(error, dict)
    return error


def result_of(response: dict[str, JsonValue]) -> dict[str, JsonValue]:
    result = response["result"]
    assert isinstance(result, dict)
    return result


def call_tool(
    server: McpServer, name: str, arguments: dict[str, JsonValue], *, caller: Caller = FULL
) -> dict[str, JsonValue]:
    return rpc(server, "tools/call", {"name": name, "arguments": arguments}, caller=caller)


def test_us16_initialize_reports_server_info_and_tools_capability(read_server: McpServer) -> None:
    response = rpc(
        read_server,
        "initialize",
        {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "c"}},
    )

    result = result_of(response)
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert result["protocolVersion"] == "2025-03-26"
    assert result["capabilities"] == {"tools": {"listChanged": False}}
    assert result["serverInfo"] == {"name": "kp-read", "version": SERVER_VERSION}


def test_us16_the_reported_version_is_the_installed_package_version() -> None:
    try:
        installed = importlib.metadata.version("kp")
    except importlib.metadata.PackageNotFoundError:
        pytest.skip("kp is not installed as a distribution")

    assert installed == SERVER_VERSION


def test_us16_initialize_offers_its_latest_version_for_an_unknown_one(
    read_server: McpServer,
) -> None:
    result = result_of(rpc(read_server, "initialize", {"protocolVersion": "1999-01-01"}))

    assert result["protocolVersion"] == "2025-06-18"


def test_us16_ping_answers_with_an_empty_result(read_server: McpServer) -> None:
    assert result_of(rpc(read_server, "ping")) == {}


def test_us16_tools_list_carries_json_input_schemas(read_server: McpServer) -> None:
    tools = result_of(rpc(read_server, "tools/list"))["tools"]

    assert isinstance(tools, list)
    by_name = {t["name"]: t for t in tools if isinstance(t, dict)}
    assert set(by_name) == {"search", "links", "template", "rule_as_at", "coverage"}
    schema = by_name["search"]["inputSchema"]
    assert isinstance(schema, dict)
    assert schema["type"] == "object"
    assert schema["required"] == ["query"]
    assert schema["additionalProperties"] is False
    assert json.dumps(by_name)  # fully JSON serialisable


def test_us16_tools_call_returns_text_and_structured_content(read_server: McpServer) -> None:
    result = result_of(call_tool(read_server, "search", {"query": "currency"}))

    assert result["isError"] is False
    structured = result["structuredContent"]
    assert isinstance(structured, dict)
    content = result["content"]
    assert isinstance(content, list)
    first = content[0]
    assert isinstance(first, dict)
    assert first["type"] == "text"
    assert json.loads(str(first["text"])) == structured
    meta = result["_meta"]
    assert isinstance(meta, dict)
    assert isinstance(meta["kp/callId"], str)


def test_us16_request_ids_round_trip_including_zero_and_strings(read_server: McpServer) -> None:
    assert rpc(read_server, "ping", request_id=0)["id"] == 0
    assert rpc(read_server, "ping", request_id="abc")["id"] == "abc"


def test_us16_notifications_get_no_response(read_server: McpServer) -> None:
    message: dict[str, JsonValue] = {"jsonrpc": "2.0", "method": "notifications/initialized"}

    assert read_server.handle(message, FULL) is None


def test_us16_a_notification_never_runs_a_tool(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    message: dict[str, JsonValue] = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {"name": "search", "arguments": {"query": "x"}},
    }

    assert read_server.handle(message, FULL) is None
    assert audit.records == []


def test_us16_responses_sent_by_the_peer_are_ignored(read_server: McpServer) -> None:
    assert read_server.handle({"jsonrpc": "2.0", "id": 1, "result": {}}, FULL) is None


def test_us16_unknown_method_is_method_not_found(read_server: McpServer) -> None:
    error = error_of(rpc(read_server, "resources/list"))

    assert error["code"] == -32601


def test_us16_unparseable_text_is_a_parse_error_with_null_id(read_server: McpServer) -> None:
    response = read_server.handle_text("{not json", FULL)

    assert response is not None
    assert error_of(response)["code"] == -32700
    assert response["id"] is None


@pytest.mark.parametrize(
    "message",
    [
        [],
        [{"jsonrpc": "2.0", "id": 1, "method": "ping"}],
        "ping",
        {"id": 1, "method": "ping"},
        {"jsonrpc": "1.0", "id": 1, "method": "ping"},
        {"jsonrpc": "2.0", "id": 1},
        {"jsonrpc": "2.0", "id": 1, "method": 5},
        {"jsonrpc": "2.0", "id": 1.5, "method": "ping"},
        {"jsonrpc": "2.0", "id": True, "method": "ping"},
        {"jsonrpc": "2.0", "id": None, "method": "ping"},
    ],
)
def test_us16_invalid_requests_are_rejected_with_32600(
    read_server: McpServer, message: JsonValue
) -> None:
    response = read_server.handle(message, FULL)

    assert response is not None
    assert error_of(response)["code"] == -32600


def test_us16_non_object_params_are_invalid_params(read_server: McpServer) -> None:
    response = read_server.handle(
        {"jsonrpc": "2.0", "id": 1, "method": "ping", "params": [1]}, FULL
    )

    assert response is not None
    assert error_of(response)["code"] == ErrorCode.INVALID_PARAMS


@pytest.mark.parametrize(
    "params",
    [{}, {"name": ""}, {"name": 5}, {"name": "search", "arguments": [1]}],
)
def test_us16_malformed_tools_call_params_are_invalid_params(
    read_server: McpServer, params: dict[str, JsonValue]
) -> None:
    assert error_of(rpc(read_server, "tools/call", params))["code"] == ErrorCode.INVALID_PARAMS


def test_us16_unknown_tool_is_invalid_params_with_a_kind(read_server: McpServer) -> None:
    error = error_of(call_tool(read_server, "delete_everything", {}))

    assert error["code"] == ErrorCode.INVALID_PARAMS
    assert error["data"] == {"kind": "unknown_tool"}


def test_us16_bad_arguments_are_invalid_params_with_a_reason(read_server: McpServer) -> None:
    error = error_of(call_tool(read_server, "search", {"query": ""}))

    assert error["code"] == ErrorCode.INVALID_PARAMS
    assert "query" in str(error["message"])


def test_us16_missing_arguments_default_to_an_empty_object(read_server: McpServer) -> None:
    response = rpc(read_server, "tools/call", {"name": "coverage"})

    assert result_of(response)["isError"] is False


def test_us16_missing_template_is_a_not_found_error_never_a_fallback(
    read_server: McpServer,
) -> None:
    error = error_of(call_tool(read_server, "template", {"spec_type": "technical"}))

    assert error["code"] == ErrorCode.NOT_FOUND
    assert error["data"] == {"kind": "template_not_found"}


def test_us16_rule_as_at_through_the_transport(read_server: McpServer) -> None:
    result = result_of(
        call_tool(read_server, "rule_as_at", {"number": "4.2.1", "as_at": "2026-11-20"})
    )

    structured = result["structuredContent"]
    assert isinstance(structured, dict)
    assert structured["reference"] == "2026.1:4.2.1"


def test_us16_no_edition_in_force_is_not_found(read_server: McpServer) -> None:
    error = error_of(
        call_tool(read_server, "rule_as_at", {"number": "4.2.1", "as_at": "2026-11-15"})
    )

    assert error["data"] == {"kind": "no_edition_in_force"}


def test_us17_a_user_without_access_gets_a_forbidden_error_not_an_empty_result(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    response = call_tool(read_server, "search", {"query": "currency"}, caller=NONE)

    assert "result" not in response
    error = error_of(response)
    assert error["code"] == -32010
    assert error["data"] == {"kind": "forbidden"}
    assert audit.records[0].refused is True


def test_us17_partial_access_through_the_transport_reports_the_filtered_count(
    read_server: McpServer,
) -> None:
    result = result_of(call_tool(read_server, "search", {"query": "credit transfer"}, caller=ONE))

    structured = result["structuredContent"]
    assert isinstance(structured, dict)
    hits = structured["hits"]
    assert isinstance(hits, list)
    assert [h["passage_id"] for h in hits if isinstance(h, dict)] == ["p1"]
    assert structured["filtered_out"] == 1


def test_us17_identity_in_the_message_is_ignored_the_transport_caller_decides(
    read_server: McpServer,
) -> None:
    message: dict[str, JsonValue] = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "caller": "user-full-access",
        "params": {
            "name": "search",
            "arguments": {"query": "currency"},
            "caller": "user-full-access",
            "_meta": {"user": "user-full-access"},
        },
    }

    response = read_server.handle(message, NONE)

    assert response is not None
    assert error_of(response)["code"] == ErrorCode.FORBIDDEN


def test_us17_identity_inside_tool_arguments_is_rejected(read_server: McpServer) -> None:
    error = error_of(
        call_tool(read_server, "search", {"query": "x", "caller": "user-full-access"}, caller=NONE)
    )

    # The caller is refused for lack of access before arguments are even looked at.
    assert error["code"] == ErrorCode.FORBIDDEN
    error = error_of(call_tool(read_server, "search", {"query": "x", "caller": "user-full-access"}))
    assert error["code"] == ErrorCode.INVALID_PARAMS


def test_us18_logs_of_an_unexpected_failure_carry_no_exception_text(
    read_server: McpServer,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    needle = "distinctive-needle-in-exception"

    def explode(self: McpServer, request: object, caller: Caller) -> JsonValue:
        raise RuntimeError(needle)

    monkeypatch.setattr(McpServer, "_dispatch", explode)
    caplog.set_level(logging.DEBUG)

    rpc(read_server, "ping")

    failure = next(r for r in caplog.records if r.name == "kp.mcp.server")
    assert failure.__dict__["error_class"] == "RuntimeError"
    assert all(r.exc_info is None and r.exc_text is None for r in caplog.records)
    assert needle not in JsonFormatter().format(failure)
    assert needle not in json.dumps([r.__dict__ for r in caplog.records], default=str)


def test_us16_deeply_nested_json_is_a_parse_error(read_server: McpServer) -> None:
    response = read_server.handle_text("[" * 100_000 + "]" * 100_000, FULL)

    assert response is not None
    assert error_of(response)["code"] == ErrorCode.PARSE_ERROR


def test_us16_an_unexpected_failure_is_an_internal_error_without_detail(
    read_server: McpServer, monkeypatch: pytest.MonkeyPatch
) -> None:
    def explode(self: McpServer, request: object, caller: Caller) -> JsonValue:
        raise RuntimeError("secret detail")

    monkeypatch.setattr(McpServer, "_dispatch", explode)

    error = error_of(rpc(read_server, "ping"))

    assert error["code"] == -32603
    assert "secret" not in json.dumps(error)
