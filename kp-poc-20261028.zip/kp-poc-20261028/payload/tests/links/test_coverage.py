"""Rules with no test, coverage, and the stories tied to no requirement or clause (US-12)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import Connection

from kp.clock import FixedClock
from kp.domain import LinkState, Relation
from kp.errors import KpError
from kp.links import CoverageEvidence, LinkService, NoEditionInForceError
from kp.testing.dataset import SyntheticDataset
from links.builders import (
    clause,
    code,
    guess_link,
    requirement,
    spec,
    state_link,
    story,
    verifying_test,
)
from links.seed import exported_stories, insert_stories


def _leaf_rules(dataset: SyntheticDataset, label: str) -> list[str]:
    numbers = {item.number for item in dataset.truth.edition(label).clauses}
    parents = {number.rsplit(".", 1)[0] for number in numbers if "." in number}
    return sorted(f"{label}:{number}" for number in numbers - parents)


@pytest.fixture
def chain(service: LinkService) -> LinkService:
    """Rule 4.2.1 has stories, a spec and code but no test yet."""
    state_link(service, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    state_link(service, story("PAY-104"), Relation.SPECIFIED_BY, spec("S1"))
    guess_link(service, story("PAY-105"), Relation.SPECIFIED_BY, spec("S1"))
    state_link(service, spec("S1"), Relation.IMPLEMENTED_BY, code("src/a.py::f"))
    return service


def test_us12_every_rule_is_listed_with_its_reference_and_story_count(
    service: LinkService, dataset: SyntheticDataset
) -> None:
    answer = service.rules_without_tests()

    expected = _leaf_rules(dataset, "2026.1")
    assert answer.edition == "2026.1"
    assert [rule.reference for rule in answer.rules] == sorted(
        expected, key=lambda ref: [int(part) for part in ref.split(":")[1].split(".")]
    )
    assert answer.total_rules == len(expected)
    assert all(rule.story_count == 0 for rule in answer.rules)
    assert all(rule.test_evidence is CoverageEvidence.NONE for rule in answer.rules)


def test_us12_parent_clauses_are_not_rules_unless_asked(
    service: LinkService, dataset: SyntheticDataset
) -> None:
    leaves = service.rules_without_tests()
    every = service.rules_without_tests(leaf_only=False)

    assert every.total_rules == len(dataset.truth.edition("2026.1").clauses)
    assert every.total_rules > leaves.total_rules
    assert "2026.1:4.2" in {rule.reference for rule in every.rules}
    assert "2026.1:4.2" not in {rule.reference for rule in leaves.rules}


def test_us12_the_story_count_counts_distinct_linked_stories(chain: LinkService) -> None:
    answer = chain.rules_without_tests()

    (currency,) = (rule for rule in answer.rules if rule.reference == "2026.1:4.2.1")
    assert currency.story_count == 2
    assert currency.test_evidence is CoverageEvidence.NONE


def test_us12_the_answer_states_how_many_links_were_stated_and_how_many_guessed(
    chain: LinkService,
) -> None:
    answer = chain.rules_without_tests()

    assert (answer.stated_links, answer.guessed_links) == (3, 1)
    assert "4 links (3 stated, 1 guessed)" in answer.summary
    assert answer.summary.startswith(f"{len(answer.rules)} of {answer.total_rules} rules")


def test_us12_after_a_test_is_linked_the_rule_no_longer_appears(
    chain: LinkService, clock: FixedClock
) -> None:
    before = chain.rules_without_tests()
    clock.set(clock.now() + timedelta(hours=1))
    state_link(
        chain, code("src/a.py::f"), Relation.VERIFIED_BY, verifying_test("tests/test_a.py::test_f")
    )

    after = chain.rules_without_tests()

    assert "2026.1:4.2.1" in {rule.reference for rule in before.rules}
    assert "2026.1:4.2.1" not in {rule.reference for rule in after.rules}
    assert after.total_rules == before.total_rules
    assert len(after.rules) == len(before.rules) - 1
    assert (after.stated_links, after.guessed_links) == (0, 0)


def test_us12_a_test_known_only_through_a_guess_counts_but_is_marked_guessed(
    chain: LinkService,
) -> None:
    guess_link(
        chain, code("src/a.py::f"), Relation.VERIFIED_BY, verifying_test("tests/test_a.py::test_f")
    )

    report = chain.coverage()

    (currency,) = (rule for rule in report.with_tests if rule.reference == "2026.1:4.2.1")
    assert currency.test_evidence is CoverageEvidence.GUESSED
    assert currency.guessed_links == 2
    assert currency.has_test


def test_us12_a_test_reached_through_a_requirement_and_a_spec_counts(
    service: LinkService,
) -> None:
    state_link(service, requirement("REQ-2"), Relation.CONSTRAINED_BY, clause("4.2.2"))
    state_link(service, spec("S2"), Relation.DERIVED_FROM, requirement("REQ-2"))
    state_link(service, story("PAY-103"), Relation.SPECIFIED_BY, spec("S2"))
    state_link(service, spec("S2"), Relation.IMPLEMENTED_BY, code("src/b.py::g"))
    state_link(
        service,
        code("src/b.py::g"),
        Relation.VERIFIED_BY,
        verifying_test("tests/test_b.py::test_g"),
    )

    report = service.coverage()

    (limit,) = (rule for rule in report.with_tests if rule.reference == "2026.1:4.2.2")
    assert limit.test_evidence is CoverageEvidence.STATED
    assert limit.story_count == 1
    assert (limit.stated_links, limit.guessed_links) == (5, 0)


def test_us12_links_waiting_for_review_are_not_used(chain: LinkService) -> None:
    guess_link(
        chain,
        code("src/a.py::f"),
        Relation.VERIFIED_BY,
        verifying_test("tests/test_a.py::test_f"),
        score=0.6,
        state=LinkState.REVIEW,
    )

    answer = chain.rules_without_tests()

    assert "2026.1:4.2.1" in {rule.reference for rule in answer.rules}


def test_us11_the_edition_in_force_on_the_date_decides_which_rules_are_measured(
    service: LinkService,
) -> None:
    before = service.coverage(as_at=datetime(2026, 11, 15, 12, 0, tzinfo=UTC))
    on_the_day = service.coverage(as_at=datetime(2026, 11, 16, 0, 0, tzinfo=UTC))

    assert before.edition == "2025.2"
    assert on_the_day.edition == "2026.1"


def test_us11_no_edition_in_force_is_reported_not_replaced_by_another_one(
    service: LinkService,
) -> None:
    with pytest.raises(NoEditionInForceError, match="2025-01-01"):
        service.coverage(as_at=datetime(2025, 1, 1, tzinfo=UTC))
    assert issubclass(NoEditionInForceError, KpError)


def test_us12_stories_with_no_requirement_or_clause_are_reported_only(
    chain: LinkService, loaded: Connection, dataset: SyntheticDataset
) -> None:
    stories = exported_stories(dataset, "jira/export-1.json")
    insert_stories(loaded, stories)

    report = chain.coverage()

    linked = {"PAY-104", "PAY-105"}  # PAY-105 is tied by a guessed link, which counts as used
    expected = sorted(item.story_key for item in stories if item.story_key not in linked)
    assert report.stories_without_requirement_or_clause == tuple(expected)
    assert not linked & set(report.stories_without_requirement_or_clause)


def test_us12_coverage_is_recomputed_from_the_current_links_every_time(
    chain: LinkService, clock: FixedClock
) -> None:
    first = chain.coverage()
    clock.set(clock.now() + timedelta(hours=1))
    chain.retire_item(spec("S1"))

    second = chain.coverage()

    assert first.stated_links + first.guessed_links == 4
    assert second.stated_links + second.guessed_links == 0
