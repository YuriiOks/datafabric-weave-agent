"""Gathering the evidence the exit-criteria report scores.

The report never trusts memory of what a run did. It reads what the run left behind: the
``source_item`` and ``mcp_call`` rows, the stored objects, the kept tool signatures and the
run evidence files. A different job (the architect's harness) that leaves the same traces is
scored the same way.
"""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import Field, ValidationError

from kp.config import Mode
from kp.connectivity.digest import sha256_hex
from kp.connectivity.discovery import SignatureStore
from kp.connectivity.ledger import load_run_results
from kp.connectivity.models import Manifest, RunResult
from kp.connectivity.ports import ObjectStore
from kp.connectivity.records import ConnectivityStore
from kp.domain import ExtractionStatus, McpCallRecord, SourceItemVersion, SourceKind
from kp.domain.base import DomainModel
from kp.store import Database

TOKEN_LIFETIME_REFERENCE_SECONDS = 1800.0


class ItemEvidence(DomainModel):
    """What the stores hold for one recorded item version.

    ``None`` means the object could not be found or read; it is not the same as empty.
    """

    item_id: str
    source: SourceKind
    media_type: str
    extraction_status: ExtractionStatus
    row_sha256: str
    raw_sha256: str | None
    markdown_chars: int | None
    manifest_sha256: str | None
    manifest_problems: tuple[str, ...] | None


class Evidence(DomainModel):
    """Everything the scorer needs, gathered once.

    :ivar namespaces: The tool route of each source, as used in call records.
    :ivar sample_total: How many sample items the run is supposed to cover.
    :ivar signature_counts: Tools kept per namespace; a missing namespace was never discovered.
    """

    mode: Mode
    namespaces: dict[SourceKind, str]
    sample_total: int
    token_lifetime_seconds: float = TOKEN_LIFETIME_REFERENCE_SECONDS
    runs: tuple[RunResult, ...] = ()
    calls: tuple[McpCallRecord, ...] = ()
    items: tuple[ItemEvidence, ...] = ()
    signature_counts: dict[str, int] = Field(default_factory=dict)


def collect_evidence(
    *,
    database: Database,
    mode: Mode,
    namespaces: dict[SourceKind, str],
    sample_total: int,
    ledger_dir: Path,
    signatures: SignatureStore,
    raw_store: ObjectStore,
    markdown_store: ObjectStore,
) -> Evidence:
    """Read the traces of every run and check the stored objects.

    :param database: Where the rows are
    :param mode: Whether this is the local or the real route
    :param namespaces: The tool route of each source
    :param sample_total: The number of sample items expected
    :param ledger_dir: Where run evidence files are kept
    :param signatures: Where tool signatures are kept
    :param raw_store: The raw object store
    :param markdown_store: The Markdown and manifest store
    :return: The gathered evidence
    """
    runs = load_run_results(ledger_dir)
    with database.transaction() as connection:
        store = ConnectivityStore(connection)
        rows = store.items(namespaces)
        calls = store.calls([run.run_id for run in runs])
    counts: dict[str, int] = {}
    for namespace in namespaces.values():
        listed = signatures.load_latest(namespace)
        if listed is not None:
            counts[namespace] = len(listed)
    return Evidence(
        mode=mode,
        namespaces=namespaces,
        sample_total=sample_total,
        runs=runs,
        calls=calls,
        items=tuple(_inspect(row, raw_store, markdown_store) for row in rows),
        signature_counts=counts,
    )


def _inspect(row: SourceItemVersion, raw: ObjectStore, markdown: ObjectStore) -> ItemEvidence:
    raw_bytes = _read(raw, row.raw_location)
    markdown_bytes = _read(markdown, row.markdown_location)
    manifest_bytes = _read(markdown, row.manifest_location)
    manifest_sha, problems = _manifest_facts(manifest_bytes)
    return ItemEvidence(
        item_id=row.item_id,
        source=row.source,
        media_type=row.media_type,
        extraction_status=row.extraction_status,
        row_sha256=row.content_sha256,
        raw_sha256=sha256_hex(raw_bytes) if raw_bytes is not None else None,
        markdown_chars=_char_count(markdown_bytes),
        manifest_sha256=manifest_sha,
        manifest_problems=problems,
    )


def _read(store: ObjectStore, location: str | None) -> bytes | None:
    if location is None:
        return None
    try:
        return store.get(store.key_of(location))
    except (KeyError, ValueError):
        return None


def _char_count(data: bytes | None) -> int | None:
    return None if data is None else len(data.decode("utf-8", errors="replace").strip())


def _manifest_facts(data: bytes | None) -> tuple[str | None, tuple[str, ...] | None]:
    if data is None:
        return None, None
    try:
        document = json.loads(data)
    except ValueError:
        return None, ("not valid JSON",)
    if not isinstance(document, dict):
        return None, ("not an object",)
    missing = [name for name in Manifest.model_fields if name not in document]
    try:
        Manifest.model_validate(document)
    except ValidationError as exc:
        invalid = {str(error["loc"][0]) for error in exc.errors() if error["loc"]}
        missing = sorted({*missing, *invalid})
    sha = document.get("content_sha256")
    return (sha if isinstance(sha, str) else None), tuple(missing)
