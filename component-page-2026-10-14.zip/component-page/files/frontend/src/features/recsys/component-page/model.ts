import type { ComponentSummary, ComponentType } from '../types'

/**
 * Everything the component page shows, in one shape the page builds from the registry detail.
 * Optional parts render only when present, so the page works before the catalogue carries the
 * full definition and its provenance.
 */
export type ComponentPageModel = {
  id: string
  type: ComponentType
  name: string
  description: string | null
  version: string | null
  nativeBinding: string | null
  tenants: string[]
  eligible: boolean
  qualityFlags: string[]
  triggers: string[]
  tools: string[]
  tags: string[]
  /** The full .md the component was built from, when the catalogue has it. */
  definition: ComponentDefinition | null
  source: ComponentSource
  relations: ComponentRelations
}

export type ComponentDefinition = {
  markdown: string
  /** Path of the file in its source, e.g. `skills/alpha-ticket-helper/SKILL.md`. */
  path: string | null
}

export type ComponentSource = {
  /** Where the component came from, e.g. "GitHub skills repository" or "GroupAI platform". */
  originSystem: string | null
  /** The platform environment it was taken from. Only Prod is ingested. */
  environment: string | null
  path: string | null
  revision: string | null
  /** When it was last synced, already formatted for display. */
  lastSynced: string | null
  /** What triggered the last sync, e.g. "GitHub Actions on push" or "scheduled pull". */
  syncTrigger: string | null
  /** Who pulled it, e.g. "Service account". */
  pulledBy: string | null
  /** A link to the file at its revision. */
  url: string | null
  source: string | null
  sourceReference: string | null
  externalIds: Array<[string, string]>
  catalogueVersion: string | null
}

export type RelatedComponent = {
  id: string
  name: string
  type: ComponentType | null
  /** The registry summary when the page has it; the related list then shows the full card. */
  summary: ComponentSummary | null
}

export type RelationGroup = {
  items: RelatedComponent[]
  /** Declarations the registry withheld because they did not resolve to a component. */
  withheld: number
}

export type ComponentRelations = {
  usedBy: RelationGroup
  uses: RelationGroup
  dependsOn: RelationGroup
}

export const EMPTY_SOURCE: ComponentSource = {
  originSystem: null,
  environment: null,
  path: null,
  revision: null,
  lastSynced: null,
  syncTrigger: null,
  pulledBy: null,
  url: null,
  source: null,
  sourceReference: null,
  externalIds: [],
  catalogueVersion: null,
}

export const EMPTY_GROUP: RelationGroup = { items: [], withheld: 0 }

/** Whether the component was taken from the Prod environment of its platform. */
export function isProd(environment: string | null): boolean {
  return (environment ?? '').trim().toLowerCase() === 'prod'
}

/** Total number of related components across the three groups. */
export function relationCount(relations: ComponentRelations): number {
  return relations.usedBy.items.length + relations.uses.items.length + relations.dependsOn.items.length
}

/**
 * Whether the component may be recommended: it is eligible and, when its platform has
 * environments, it was taken from Prod. Untested components are never recommended.
 */
export function canRecommend(model: ComponentPageModel): boolean {
  return model.eligible && (model.source.environment === null || isProd(model.source.environment))
}

/** A one-word name for where the component came from, for the summary tile. */
export function shortSource(originSystem: string | null, prod: boolean): string {
  const origin = (originSystem ?? '').toLowerCase()
  if (origin.includes('github')) return 'GitHub'
  if (origin.includes('groupai')) return 'GroupAI'
  if (prod) return 'Prod'
  return originSystem ?? '\u2014'
}

/** Total number of withheld declarations across the three groups. */
export function withheldCount(relations: ComponentRelations): number {
  return relations.usedBy.withheld + relations.uses.withheld + relations.dependsOn.withheld
}
