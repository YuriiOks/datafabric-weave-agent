# Knowledge-base design work: canon

Rules for every coding agent that starts in /home/user/km. If another file disagrees, this wins.

## The work
- A new knowledge product is being designed on top of an existing catalogue application.
- The design and review stories S1 to S6 each end in one document under designs/. Code
  changes are not part of these stories.
- BASE_REPO is the clone in this folder that has both backend/ and frontend/. It is the
  existing application. CAPTURE_REPO is the other clone: a source-capture toolkit.
- LEGACY_ORG is an older knowledge project: a source of lessons, not of code to copy.
- Real names for the placeholders are in kb/private/names.md when that file exists.
  Written output uses the placeholders unless the owner asks for real names.

## Map
| Path | Holds |
|---|---|
| kb/INDEX.md | one line per knowledge file. Read it before reading any code. |
| kb/seed/ | glossary, what each story leaves out, reference patterns |
| kb/private/ | optional: names, claims from an earlier read of both repos, chat context |
| kb/verified/ | claims checked against code. Only these may carry a design. |
| kb/base, capture, legacy, wiki, stories, risks, packs | written by the runs |
| designs/ | the story deliverables, one file per story |
| work/ | scratch and extra clones. Nothing here is a source of truth. |

In this folder use only skills and agents whose names start with km-.

## How to work
- kb first. Answer from the kb when it can answer. Read code only for what it cannot, then
  write the finding back so the next session does not read the same code.
- Code wins over documents. The large design documents in BASE_REPO are proposals. A document's
  claim about behaviour is Reported until code confirms it.
- Every factual line in the kb or in a design carries one label and, if Observed, a source
  (path:line or page number). Labels: Observed (read in a named file or page this run),
  Reported (said by a person or a document, not confirmed in code), Proposed (not in effect),
  Unverified (not checked), Historical (true at a dated moment).
- kb files: a title line, then Date:, Task: and Status: lines; one topic; at most 150 lines of
  at most 100 characters; Open questions last. Quote at most three lines; prefer path:line.
- Write each file as soon as its topic is done. On a restart, skip files that already exist.
- Each run records itself in kb/index.d/<run>.txt (path, 12-word summary, date per file) and
  kb/log.d/<run>.txt (date, task, files, what was skipped and why). Do not edit kb/INDEX.md.

## Delegation
- The main session plans, decides and writes conclusions. It does not bulk-read.
- Delegate when one answer needs more than 5 files or about 60 KB of reading.
- Up to 3 km-reader at once; 1 while a clone or a whole-tree search runs. 1 km-verifier or
  km-reviewer at a time.
- A subagent sees none of this conversation. Write the whole task into the task text: goal in
  one sentence; inputs as exact paths; output path and section headings; size limit; what to
  skip; reply format. Do not point a subagent at a file of instructions.
- After a reader returns, read its kb file, not the sources it read.

## Safety
- The clones are read-only. No edit, commit, push, pull request, comment, review or ticket
  change, unless the owner asks for one in this session and /km-pr has been followed.
- Do not run the applications, their tests or builds. Do not delete anything; scratch stays
  in work/ and the owner cleans up.
- Never open env files, key files or credential files. Never print environment values. If a
  secret is seen, record only "a credential is present at <path>" as a risk.
- No credential, token, staff id or email address in any file or answer.
- If a command is denied or asks for approval, log it and skip it. Do not try a variant.
  If a file read is blocked, log the path, mark the topic Unverified and move on.
- Nothing from this folder goes into a commit: not this file, the kb, designs, skills or agents.
- Do not change files under .claude/ or any settings, and do not inspect your own
  configuration beyond what /km-start lists.

## When blocked
- A command fails twice for the same reason, a simple command takes over 30 seconds, or a step
  needs a login, a code or an approval: stop that task, write the reason to the run's log file,
  tell the owner in two lines what is needed.
