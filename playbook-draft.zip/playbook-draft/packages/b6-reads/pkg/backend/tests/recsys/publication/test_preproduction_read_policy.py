"""Pre-production read policy: reader allow-list, one scope, traversable relations only."""

from __future__ import annotations

import unittest

from app.recsys.contracts import LinkType, PublicationScope, SourceEnvironment
from app.recsys.publication.models import TRAVERSABLE_LINK_TYPES
from app.recsys.publication.preproduction_policy import (
    PreproductionReadPolicy,
    parse_readers,
)

PPD = PublicationScope(environment=SourceEnvironment.ppd, partition="shared")
OTHER_PARTITION = PublicationScope(environment=SourceEnvironment.ppd, partition="other")
PROD = PublicationScope(environment=SourceEnvironment.prod, partition="shared")


def _policy(principal_id: str = "reader-1", readers=("reader-1", "reader-2")):
    return PreproductionReadPolicy(scope=PPD, principal_id=principal_id, readers=readers)


class ReaderListTests(unittest.TestCase):
    def test_reader_list_ignores_blanks_and_spaces(self) -> None:
        self.assertEqual(parse_readers(" reader-1, ,reader-2 ,"), {"reader-1", "reader-2"})
        self.assertEqual(parse_readers(""), frozenset())

    def test_production_is_refused_when_built(self) -> None:
        with self.assertRaisesRegex(ValueError, "outside ppd"):
            PreproductionReadPolicy(scope=PROD, principal_id="reader-1", readers=["reader-1"])

    def test_an_empty_reader_list_is_refused_when_built(self) -> None:
        with self.assertRaisesRegex(ValueError, "at least one reader"):
            PreproductionReadPolicy(scope=PPD, principal_id="reader-1", readers=[" "])

    def test_revision_changes_with_the_list_and_the_scope_only(self) -> None:
        self.assertEqual(_policy().revision, _policy(principal_id="reader-2").revision)
        self.assertEqual(
            _policy().revision, _policy(readers=("reader-2", "reader-1")).revision
        )
        self.assertNotEqual(_policy().revision, _policy(readers=("reader-1",)).revision)
        other = PreproductionReadPolicy(
            scope=OTHER_PARTITION, principal_id="reader-1", readers=("reader-1", "reader-2")
        )
        self.assertNotEqual(_policy().revision, other.revision)


class AnswerTests(unittest.IsolatedAsyncioTestCase):
    async def test_a_listed_reader_sees_components_and_traversable_relations(self) -> None:
        policy = _policy()

        self.assertTrue(policy.admits_caller)
        self.assertTrue(await policy.may_see_component("agent:any", scope=PPD))
        for link_type in TRAVERSABLE_LINK_TYPES:
            self.assertTrue(await policy.may_traverse(link_type, scope=PPD), link_type)

    async def test_an_unlisted_caller_sees_nothing(self) -> None:
        policy = _policy(principal_id="someone-else")

        self.assertFalse(policy.admits_caller)
        self.assertFalse(await policy.may_see_component("agent:any", scope=PPD))
        for link_type in LinkType:
            self.assertFalse(await policy.may_traverse(link_type, scope=PPD), link_type)

    async def test_no_other_scope_is_answered(self) -> None:
        policy = _policy()

        for scope in (OTHER_PARTITION, PROD):
            self.assertFalse(await policy.may_see_component("agent:any", scope=scope))
            self.assertFalse(
                await policy.may_traverse(next(iter(TRAVERSABLE_LINK_TYPES)), scope=scope)
            )

    async def test_a_relation_outside_the_traversable_set_is_refused(self) -> None:
        policy = _policy()

        for link_type in set(LinkType) - set(TRAVERSABLE_LINK_TYPES):
            self.assertFalse(await policy.may_traverse(link_type, scope=PPD), link_type)


if __name__ == "__main__":
    unittest.main()
