---
name: km-write
description: "Use to draft text for non-engineers: sprint summary, status note, decision card or ticket text. Argument is the kind (sprint, status, card, ticket) and the subject. Drafts only; the owner sends."
argument-hint: <sprint|status|card|ticket> <subject or source path>
disable-model-invocation: true
effort: medium
---

# km-write

Goal: a short draft the owner can send or paste as it stands, in plain product language, with
every number traceable. You draft; you never send, post, comment or change a ticket. The
owner acts, each time, after reading the draft.

Argument: $0 is the kind: sprint, status, card or ticket. The rest of $ARGUMENTS is the
subject (a task id, a design file, a topic, or a path). Anything else: print "usage:
/km-write <sprint|status|card|ticket> <subject>" and stop. Templates and one before/after
example per kind: ${CLAUDE_SKILL_DIR}/references/templates.md. Read the section of your kind.

## Facts first
- Git is the truth, the tracker is not. Count done work from merged changes
  (`git -C /home/user/km/<clone> log`,
  `(cd /home/user/km/<clone> && gh pr list --state merged)`, read-only; choose the clone as
  km-review-pr does), from work/builds/ and from kb files. A ticket
  shown Done but not merged is not done.
- Every number in the draft comes from a command or a file you name in the Evidence block.
  Cannot source it: leave it out or write "not yet known". Never invent a number, a key, a
  date or a name.
- Ticket keys come from the owner or kb/private. If absent, write the placeholder
  <TICKET-KEY> and say so in the reply.

## Voice rules (all kinds)
- Product language: what a person can now do, see or decide. No class, module, service or
  file names, no hosts or addresses, no ticket numbers in prose, no test counts, no talk of
  pipelines, builds or checks, no "prototype" or "proof of concept".
- Numbers instead of adjectives: "12 of 31 done", not "good progress".
- At most two questions per message, each answerable in one line. Roles, not names.
- Short sentences. No hedging, apology, praise or filler. Plain hyphen, never a long dash.
- If the owner replies "I don't get it": rewrite shorter and simpler; do not explain.

## Ticket rules (kind ticket, and any status text that mentions tickets)
- A ticket exists before fix work starts. A sub-task sits under a parent.
- Summary: `<Product> - <Area>: <outcome in product language>`, plain hyphen.
- Description: the problem as a person meets it, the outcome wanted, and "Done when" with
  checks that can fail. Local-only material (plans, skills, harness files) is never in it.
- You draft the status the owner might set; the owner sets it. Done only after the change is
  merged on the main line.

## Output
1. Write the draft to work/drafts/<kind>-<date>.md (create the folder if absent): the text
   to send first, then a block "Evidence (not for sending)": each number or claim, its
   label (Observed, Reported, Proposed, Unverified, Historical) and its source. Text that
   states something not Observed says so in plain words ("planned", "not yet checked").
2. Check the draft against the voice rules once, line by line, and fix what fails.
3. Reply: the draft text, the evidence block in at most 6 lines, any placeholder left, and one
   next action: "read it, then send it yourself". Stop; offer nothing outbound.

Source data missing or two sources disagree: ask at most two questions, then stop.
