"""Coverage: the rules that have no test, with how many stories are tied to each."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from pydantic import JsonValue

from kp.errors import KpError
from kp.tools.coverage import CoverageOutput
from kp.web.errors import Problem, problem_from
from kp.web.identity import Viewer
from kp.web.query import QueryForm
from kp.web.state import WebState

PAGE_SIZE = 50
_MAX_OFFSET = 1_000_000


@dataclass(frozen=True, slots=True)
class CoverageView:
    """The coverage page.

    :ivar as_at: The date typed, if any.
    :ivar offset: How many entries of each list are skipped.
    :ivar output: The tool's answer; ``None`` when the viewer was refused.
    """

    as_at: date | None = None
    offset: int = 0
    output: CoverageOutput | None = None
    problem: Problem | None = None

    @property
    def previous_offset(self) -> int | None:
        """Where the previous page starts, or ``None`` on the first page."""
        return None if self.offset == 0 else max(0, self.offset - PAGE_SIZE)

    @property
    def next_offset(self) -> int | None:
        """Where the next page starts, or ``None`` on the last page."""
        return self.offset + PAGE_SIZE if self.output and self.output.truncated else None

    @property
    def summary(self) -> str:
        """One sentence with the count of untested rules and the stated and guessed links."""
        if self.output is None:
            return ""
        output = self.output
        total = output.total_rules_with_tests + output.total_rules_without_tests
        links = output.stated_links + output.guessed_links
        return (
            f"{output.total_rules_without_tests} of {total} rules have no test; the answer rests "
            f"on {links} links ({output.stated_links} stated, {output.guessed_links} guessed)."
        )


def read_coverage(state: WebState, viewer: Viewer, form: QueryForm) -> CoverageView:
    """Read which rules have no test, as the viewer.

    :param state: The shared state
    :param viewer: Who is asking
    :param form: The query string of the request
    :return: The view
    """
    as_at: date | None = None
    offset = 0
    try:
        as_at = form.day("as_at", "As at")
        offset = form.number("offset", "The start", default=0, low=0, high=_MAX_OFFSET)
        arguments: dict[str, JsonValue] = {"limit": PAGE_SIZE, "offset": offset}
        if as_at is not None:
            arguments["as_at"] = as_at.isoformat()
        payload = state.call(viewer, "coverage", arguments)
        return CoverageView(as_at, offset, CoverageOutput.model_validate(payload))
    except KpError as exc:
        return CoverageView(as_at, offset, problem=problem_from(exc))
