## What changed
- The Registry, Recommend, card and component pages show built-in sample components only when demo mode is switched on (`VITE_RECSYS_MOCK=1`). The search panel already works this way.
- Without demo mode, when the recommender does not answer, the source bar says "Unavailable", the card panel says suggestions are unavailable, and the component page shows its registry-unavailable message. No sample component is presented as a real one.

## Why
Production runs without demo mode. Today a recommender that is switched off or down makes these pages show invented components labelled Demo data, which reads as real catalogue content.

## How to verify
1. Run the frontend with the recommender off and without `VITE_RECSYS_MOCK`: the Registry bar shows Unavailable and no sample component appears.
2. Run it with `VITE_RECSYS_MOCK=1`: the pages show the sample components with the Demo data tag, as before.
3. Negative case: with the recommender on, every page shows live components and neither tag.

## Review focus
`client.ts`: every call now goes to the live API unless demo mode is on. The live probe only drives the labels.
