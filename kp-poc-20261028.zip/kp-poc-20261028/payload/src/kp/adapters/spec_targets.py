"""Seam: the spec repository joins the sweep as a target beside the code repository.

The spec repository is where the platform's own spec pull requests land. Once a person merges
one, the sweep reads the file back like any other item (US-23). The reader lives in
:mod:`kp.sources.spec_repo`; where its files come from is decided by the publisher the machine
uses (:func:`kp.adapters.publishers.open_spec_source`). This provider adds that target to the
targets of the factory, under its own cursor scope.
"""

from __future__ import annotations

from collections.abc import Sequence

from kp.adapters.publishers import open_spec_source
from kp.clock import Clock
from kp.config import Settings
from kp.domain import SourceKind
from kp.sources.spec_repo import SPEC_SCOPE, SpecRepoReader
from kp.sweep import SweepTarget, TargetProvider


class SpecAwareTargets:
    """Adds the spec repository to the sweep targets of another provider.

    :param inner: The provider of the five source readers
    :param settings: Platform settings
    :param clock: Time source for the spec repository's publisher
    """

    def __init__(self, inner: TargetProvider, settings: Settings, clock: Clock) -> None:
        self._inner = inner
        self._settings = settings
        self._clock = clock

    def targets(self, sources: Sequence[SourceKind]) -> Sequence[SweepTarget]:
        """Build the targets of the named sources, or of every source when none is named.

        The spec repository belongs to the code source: it is swept whenever that source is,
        and only once something has been published to it.

        :param sources: Sources to sweep; empty means all
        :return: The inner provider's targets, plus the spec repository when it exists
        :raises kp.errors.ConfigurationError: As the inner provider
        """
        targets = list(self._inner.targets(sources))
        if sources and SourceKind.GITHUB not in sources:
            return targets
        source = open_spec_source(self._settings, self._clock)
        if source is not None:
            targets.append(SweepTarget(SpecRepoReader(source), scope=SPEC_SCOPE))
        return targets
