"""The database item catalog, and publication over the synthetic dataset (US-15)."""

from __future__ import annotations

import pytest
from sqlalchemy import Connection

from kp.clock import FixedClock
from kp.domain import SourceKind
from kp.links import KeyIndex, LinkService, RepositoryScanner, register_link_set, story_link_set
from kp.publish import (
    CLAUSES_WITHOUT_FIELD_LINK,
    ITEMS_HAVE_SOURCE,
    ITEMS_WITHOUT_LINKS,
    STORIES_WITHOUT_REQUIREMENT_OR_CLAUSE,
    DatabaseItemCatalog,
    KnowledgePublisher,
)
from kp.testing.dataset import SyntheticDataset
from links.seed import (
    exported_stories,
    insert_passage,
    insert_requirements,
    insert_source_item,
    insert_stories,
    register_requirements,
    seed_rulebook,
    x_clause_field_count,
)
from publish.conftest import NOW


@pytest.fixture
def world(connection: Connection, dataset: SyntheticDataset) -> Connection:
    """Rulebook, register and stories loaded, each with its source item."""
    seed_rulebook(connection, dataset)
    insert_source_item(connection, SourceKind.GITHUB, "register")
    insert_requirements(connection, register_requirements(dataset))
    insert_stories(connection, exported_stories(dataset, "jira/export-1.json"))
    return connection


def test_us15_the_catalog_lists_clauses_requirements_and_stories_with_their_sources(
    world: Connection, dataset: SyntheticDataset
) -> None:
    items = DatabaseItemCatalog(world).items()

    by_kind: dict[str, int] = {}
    for entry in items:
        by_kind[entry.kind] = by_kind.get(entry.kind, 0) + 1
    assert by_kind == {
        "clause": sum(len(e.clauses) for e in dataset.truth.editions),
        "requirement": dataset.truth.requirements_register.data_row_count,
        "story": dataset.truth.stories.story_count,
    }
    assert all(entry.has_source for entry in items)
    assert {entry.key for entry in items if entry.kind == "clause"} >= {
        "2026.1:4.2.1",
        "2025.2:4.2.1",
    }


def test_us15_an_item_whose_source_row_is_missing_is_flagged(
    connection: Connection, dataset: SyntheticDataset
) -> None:
    seed_rulebook(connection, dataset)
    insert_source_item(connection, SourceKind.GITHUB, "register")
    insert_requirements(connection, register_requirements(dataset)[:1])
    insert_stories(
        connection, exported_stories(dataset, "jira/export-1.json")[:2], with_source=False
    )
    insert_passage(connection, "p-ok", "2026.1")
    insert_passage(connection, "p-orphan", "no-such-item")

    items = {entry.key: entry for entry in DatabaseItemCatalog(connection).items()}

    assert items["p-ok"].has_source
    assert not items["p-orphan"].has_source
    assert items["p-ok"].ref is None
    assert not items["PAY-100"].has_source
    assert items["register:Requirements:5"].has_source


def test_us15_an_orphan_passage_blocks_publication(world: Connection, clock: FixedClock) -> None:
    insert_passage(world, "p-orphan", "no-such-item")

    result = KnowledgePublisher(world, clock=clock).publish()

    assert not result.published
    assert [check.name for check in result.failed_checks] == [ITEMS_HAVE_SOURCE]


def test_us15_stated_links_from_all_sources_publish_with_warnings_for_the_gaps(
    world: Connection, clock: FixedClock, dataset: SyntheticDataset
) -> None:
    links = LinkService(world, clock=clock)
    code_repo = dataset.root / "code_repo"
    clauses = sum(len(e.clauses) for e in dataset.truth.editions)
    stories = exported_stories(dataset, "jira/export-1.json")
    requirements = register_requirements(dataset)
    links.apply_stated(register_link_set(requirements))
    links.apply_stated(RepositoryScanner().scan(code_repo))
    links.apply_stated(
        story_link_set(
            stories,
            KeyIndex.build(requirements=requirements, story_keys=[s.story_key for s in stories]),
        )
    )
    clock.set(NOW)

    result = KnowledgePublisher(world, clock=clock).publish()

    by_name = {check.name: check for check in result.version.checks}
    assert result.published
    assert result.version.item_count == (
        clauses
        + dataset.truth.requirements_register.data_row_count
        + dataset.truth.stories.story_count
    )
    assert not by_name[ITEMS_WITHOUT_LINKS].passed
    assert not by_name[CLAUSES_WITHOUT_FIELD_LINK].passed
    assert by_name[CLAUSES_WITHOUT_FIELD_LINK].detail == (
        f"{clauses - x_clause_field_count(code_repo)} of {clauses} clauses "
        "have no schema-field link."
    )
    assert by_name[STORIES_WITHOUT_REQUIREMENT_OR_CLAUSE].value == float(
        dataset.truth.stories.story_count
    )
