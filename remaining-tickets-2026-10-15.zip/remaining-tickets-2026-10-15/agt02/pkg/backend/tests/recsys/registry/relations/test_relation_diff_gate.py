"""A relation leaves the graph only when a complete, current source says it should.

The gate is pure, so these tests drive it with hand-built facts and manifests. A
relation's retirement must be declared by every authority whose declaration supported
it and by every authority behind its target component.
"""

from __future__ import annotations

import unittest
from datetime import datetime, timezone
from types import SimpleNamespace

from app.recsys.contracts import (
    CompletenessState,
    ComponentType,
    DeletionSemantics,
    FreshnessState,
    LinkType,
    PublicationScope,
    SourceAuthority,
    SourceEnvironment,
)
from app.recsys.registry.models import ComponentLink
from app.recsys.registry.relations.diff import RelationFact, diff_relations, relation_facts
from app.recsys.registry.transition.gate import evaluate_transition
from app.recsys.registry.transition.models import (
    DEFAULT_RETIREMENT_POLICY,
    BreachKind,
    ComponentFact,
    PriorPublication,
    RetirementApproval,
    TransitionDecision,
)

SCOPE = PublicationScope(environment=SourceEnvironment.ppd, partition="default")
AGENT = "agent:tenant-one/widget-helper"
SKILL = "skill:alpha-helper"
KEY = "a" * 64
OTHER_KEY = "c" * 64

COMPONENTS = {
    AGENT: ComponentFact(AGENT, ComponentType.agent, "agenthub_export", "1" * 64),
    SKILL: ComponentFact(SKILL, ComponentType.skill, "merged", "2" * 64),
}

RELATION = RelationFact(
    relation_key=KEY,
    src_id=AGENT,
    link_type=LinkType.uses_skill,
    dst_id=SKILL,
    evidence_digest="b" * 64,
    evidence_authorities=(SourceAuthority.agent_hub_export.value,),
)


def _manifest(authority: SourceAuthority, *, deleting: bool) -> SimpleNamespace:
    """Build the declaration fields of one source manifest.

    :param authority: The source authority.
    :param deleting: Declare ``absence_is_deletion`` on a complete, current snapshot.
    :return: An object carrying exactly the fields the gate reads.
    """
    return SimpleNamespace(
        authority=authority,
        resolved_revision="revision-1",
        content_hash="c" * 64,
        completeness=(
            CompletenessState.complete_snapshot if deleting else CompletenessState.incomplete
        ),
        freshness=FreshnessState.current,
        deletion_semantics=(
            DeletionSemantics.absence_is_deletion
            if deleting
            else DeletionSemantics.absence_is_not_deletion
        ),
    )


def _approval(relation_keys: tuple[str, ...], version: str = "v2") -> RetirementApproval:
    """:return: An approval for one exact relation retirement and no component one."""
    return RetirementApproval(
        approved_by="reviewer",
        reason="The owner confirmed the relation was removed.",
        candidate_version=version,
        retired_component_ids=(),
        retired_relation_keys=relation_keys,
        approved_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
    )


def _decide(
    candidate_relations: dict[str, RelationFact] | None,
    *,
    agent_deletes: bool = False,
    skills_delete: bool = False,
    approval: RetirementApproval | None = None,
    prior_relations: dict[str, RelationFact] | None = None,
) -> TransitionDecision:
    """Evaluate one transition whose components are unchanged.

    :return: The gate's decision.
    """
    return evaluate_transition(
        prior=PriorPublication(version="v1", scope=SCOPE, components=COMPONENTS),
        to_version="v2",
        scope=SCOPE,
        candidate=dict(COMPONENTS),
        manifests=[
            _manifest(SourceAuthority.agent_hub_export, deleting=agent_deletes),
            _manifest(SourceAuthority.skills_repo, deleting=skills_delete),
        ],
        policy=DEFAULT_RETIREMENT_POLICY,
        approval=approval,
        prior_relations={KEY: RELATION} if prior_relations is None else prior_relations,
        candidate_relations=candidate_relations,
    )


def _relation_breaches(decision: TransitionDecision) -> list[list[str]]:
    """:return: The relation keys named by every relation breach."""
    return [
        breach.relation_keys
        for breach in decision.breaches
        if breach.kind is BreachKind.relation_retirement_not_declared
    ]


class RelationDiffTests(unittest.TestCase):
    def test_the_diff_sorts_every_key_into_exactly_one_bucket(self):
        changed = RELATION.model_copy(update={"evidence_digest": "d" * 64})
        added = RELATION.model_copy(update={"relation_key": OTHER_KEY})
        diff = diff_relations({KEY: RELATION}, {KEY: changed, OTHER_KEY: added})
        self.assertEqual(diff.added, [OTHER_KEY])
        self.assertEqual(diff.retired, [])
        self.assertEqual(diff.changed, [KEY])
        self.assertEqual(diff.unchanged, [])

    def test_a_link_without_a_key_cannot_enter_the_diff(self):
        link = ComponentLink(
            src_id=AGENT,
            dst_id=SKILL,
            link_type=LinkType.uses_skill,
            source="agent_usage_sheet",
            resolved=True,
        )
        with self.assertRaises(ValueError):
            relation_facts([link])


class RelationRetirementGateTests(unittest.TestCase):
    def test_an_unchanged_rebuild_retires_nothing(self):
        decision = _decide({KEY: RELATION})
        self.assertTrue(decision.allowed)
        self.assertEqual(decision.breaches, [])
        self.assertIsNotNone(decision.relation_diff)
        self.assertEqual(decision.relation_diff.unchanged, [KEY])

    def test_changed_evidence_is_not_a_retirement(self):
        changed = RELATION.model_copy(update={"evidence_digest": "d" * 64})
        decision = _decide({KEY: changed})
        self.assertTrue(decision.allowed)
        self.assertEqual(decision.relation_diff.changed, [KEY])

    def test_a_dropped_declaration_in_an_incomplete_capture_is_refused(self):
        decision = _decide({})
        self.assertFalse(decision.allowed)
        self.assertEqual(decision.relation_diff.retired, [KEY])
        self.assertEqual(_relation_breaches(decision), [[KEY]])

    def test_a_complete_agent_capture_with_an_incomplete_target_source_is_refused(self):
        decision = _decide({}, agent_deletes=True, skills_delete=False)
        self.assertFalse(decision.allowed)
        self.assertEqual(_relation_breaches(decision), [[KEY]])

    def test_both_sources_declaring_deletion_retire_the_relation(self):
        decision = _decide({}, agent_deletes=True, skills_delete=True)
        self.assertTrue(decision.allowed)
        self.assertEqual(decision.breaches, [])
        self.assertEqual(decision.relation_diff.retired, [KEY])

    def test_a_target_the_current_version_does_not_know_is_refused(self):
        unknown = RELATION.model_copy(update={"dst_id": "skill:gone"})
        decision = _decide(
            {}, agent_deletes=True, skills_delete=True, prior_relations={KEY: unknown}
        )
        self.assertFalse(decision.allowed)
        self.assertEqual(_relation_breaches(decision), [[KEY]])

    def test_an_approval_naming_this_exact_retirement_lifts_it(self):
        decision = _decide({}, approval=_approval((KEY,)))
        self.assertTrue(decision.approval_applied)
        self.assertTrue(decision.allowed)

    def test_an_approval_for_another_relation_set_does_not(self):
        decision = _decide({}, approval=_approval(()))
        self.assertFalse(decision.approval_applied)
        self.assertFalse(decision.allowed)

    def test_an_approval_for_another_candidate_does_not(self):
        decision = _decide({}, approval=_approval((KEY,), version="v3"))
        self.assertFalse(decision.approval_applied)
        self.assertFalse(decision.allowed)

    def test_without_relations_the_rule_is_not_evaluated(self):
        decision = _decide(None)
        self.assertIsNone(decision.relation_diff)
        self.assertEqual(_relation_breaches(decision), [])
        self.assertTrue(decision.allowed)

    def test_candidate_relations_need_the_current_versions_relations(self):
        with self.assertRaises(ValueError):
            evaluate_transition(
                prior=PriorPublication(version="v1", scope=SCOPE, components=COMPONENTS),
                to_version="v2",
                scope=SCOPE,
                candidate=dict(COMPONENTS),
                manifests=[],
                policy=DEFAULT_RETIREMENT_POLICY,
                candidate_relations={KEY: RELATION},
            )

    def test_approval_keys_are_stored_in_one_canonical_order(self):
        approval = _approval((OTHER_KEY, KEY, KEY))
        self.assertEqual(approval.retired_relation_keys, (KEY, OTHER_KEY))


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
