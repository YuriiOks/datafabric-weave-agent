---
pack_id: "bpc-sep26-v1"
local_id: "CORE-02"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Define shared task, source, identity and publication contracts"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 4
scope: "foundation"
create_by_default: true
planned_start: "2026-09-09"
planned_due: "2026-09-10"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-01"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-02"
architecture_sections: ["ai-contracts","decision-authority","identity","ingestion"]
---

# Define shared task, source, identity and publication contracts

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-02** is not a Jira key.
- Estimate: **4 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-09 → 2026-09-10 (D1–D2)**.
- Recommendation extension: **2026-09-09 → 2026-09-10 (D1–D2)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Give source adapters, graph reads and AI consumers one versioned boundary so the three component tickets do not invent incompatible DTOs.

## Scope and contract

Common RequestContext plus discriminated HubDecisionRequest, CompletenessRequest and ComponentRecommendationRequest. Source manifests bind approved authority/scope, immutable revision/hash, captured-at, completeness and deletion semantics. CandidateHit uses typed EntityRef; graph eligibility, recommendation eligibility and execution permission are independent.

## Implementation sequence

1. Translate the architecture into executable request/response/schema records at verified existing seams; publish schema/version and compatibility rules.
2. Define durable component IDs, scoped source keys, alias history and unresolved/collision reason enums. Separate component Agent from optional native Hub binding.
3. Define row-accounting and relation-resolution output, including missing evidence versus known unsupported states.
4. Define publication descriptor, policy generation, current-auth requirements, run outcome and error vocabularies; make unknown fields/task mismatches explicit errors.
5. Share concrete sanitized fixtures and generated frontend type expectations with Mayank before parallel adapters begin.

## Acceptance criteria

- [ ] Cross-task fields are rejected and clients cannot set principal, policy or resolved model configuration.
- [ ] DTO examples cover resolved, ambiguous, incomplete, denied and unavailable outcomes.
- [ ] Graph membership does not imply suitability or execution permission.
- [ ] All type adapters consume the same contract/version and UI code consumes generated or verified compatible types.

## Verification

- Schema contract tests cover wrong discriminator, foreign task fields, unknown type, invalid source scope and missing required lineage.
- Run request/response compatibility checks through the real application serializers in approved CI.

## Evidence to attach

- Schema/DTO diff, fixture examples, compatibility table and CI reference.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

No framework migration or parallel implementation of three recommendation engines. The illustrative interface names in the architecture are not pre-existing routes.

## Monotonic source collections

The manifest includes a monotonic collection revision for each authority/partition/collection, separate from content hash, capture time and individual source record version. Validate the source-authoritative ordering rule; never sort hashes or substitute local ingestion order for source chronology. Preserve original age and revision when carrying an unchanged source. Unknown or ambiguous source ordering blocks automatic promotion until the authority supplies a verifiable ordering decision. Attach vector fixtures for an old complete source arriving after a newer active publication.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-01](CORE-01.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `ai-contracts`, `decision-authority`, `identity`, `ingestion`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
