"""Loading the fixed sample items from YAML."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import ValidationError

from kp.connectivity.errors import SampleItemsError
from kp.connectivity.models import SampleSet


def default_sample_items_path() -> Path:
    """Return the synthetic sample file that ships with the package.

    :return: Path of ``sample_items.yaml``
    """
    return Path(__file__).resolve().parent / "data" / "sample_items.yaml"


def load_sample_items(path: Path) -> SampleSet:
    """Read and validate the sample items file.

    :param path: A YAML file with an ``items`` list
    :return: The nine items, three per source
    :raises kp.connectivity.errors.SampleItemsError: If the file is missing, not valid YAML or
        not the fixed set
    """
    try:
        document = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise SampleItemsError(f"Cannot read the sample items file {path.name}") from exc
    if not isinstance(document, dict) or "items" not in document:
        raise SampleItemsError("The sample items file needs a top-level 'items' list")
    try:
        return SampleSet.model_validate({"items": document["items"]})
    except ValidationError as exc:
        problems = "; ".join(
            f"{'.'.join(str(part) for part in err['loc'])}: {err['msg']}"
            for err in exc.errors(include_input=False, include_url=False)
        )
        raise SampleItemsError(f"Invalid sample items: {problems}") from exc
