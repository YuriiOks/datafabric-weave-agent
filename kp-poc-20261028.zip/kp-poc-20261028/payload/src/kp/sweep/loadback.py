"""Load-back of merged specs as knowledge (US-23).

A merged spec file is admitted like any other item. This module then links it to its story,
to the clauses and register rows it cites and to the template it was written from, in the
shared ``link`` table, as stated facts with a validity period. A later merged version, typically
edited by a person, closes the facts it no longer states and opens its own from its merge date.
Nothing is overwritten.

The merge is also recorded on the spec row the write side keeps (state ``merged``, the merge
date, whether the file is still machine-authored). That row is what keeps a merged spec from
being drafted or published again.
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime

from sqlalchemy import Connection, and_, insert, or_, select, update

from kp.domain import (
    MERGED_SPEC_EVIDENCE,
    ItemRef,
    ItemType,
    Link,
    LinkKind,
    LinkState,
    Relation,
    SourceItemVersion,
)
from kp.domain.clause_ref import ClauseRef
from kp.domain.enums import SpecState
from kp.errors import InvalidClauseRefError
from kp.store import schema
from kp.sweep.gate import SpecMarker
from kp.sweep.models import LoadedSpec

# Matches the canonical "2026.1:4.2.1" and the spoken "2026.1 clause 4.2.1". The edition label
# must have the shape rulebook editions use (a four-digit year, a dot, a sequence number), so
# times ("09:30"), ratios ("1:2"), ports ("8080:443") and software versions ("2.0 clause 3")
# are never read as clause references. ``ClauseRef`` validates each candidate further.
_CLAUSE_TEXT = re.compile(r"(?<![\w.:])\d{4}\.\d+(?::|\s+clause\s+)\d+(?:\.\d+)*")

# The register column that holds a row's own id, as the tracker's issue links name it.
_REQUIREMENT_ID_FIELD = "Req ID"

_Fact = tuple[ItemRef, Relation, ItemRef]


def extract_clause_refs(content: bytes) -> tuple[str, ...]:
    """Find the clause references a spec cites.

    :param content: The spec file's bytes, read as UTF-8
    :return: Distinct canonical references (``<edition>:<number>``) in sorted order
    """
    found: set[ClauseRef] = set()
    for match in _CLAUSE_TEXT.finditer(content.decode("utf-8", errors="replace")):
        try:
            found.add(ClauseRef.parse(match.group()))
        except InvalidClauseRefError:
            continue
    return tuple(ref.format() for ref in sorted(found))


def _link_id(fact: _Fact, valid_from: datetime) -> str:
    source, relation, target = fact
    parts = (
        source.item_type.value,
        source.key,
        relation.value,
        target.item_type.value,
        target.key,
        valid_from.isoformat(),
    )
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:32]


class SpecLoader:
    """Links a loaded spec version to its story and clauses.

    :param connection: The open connection of the page being applied
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def load(
        self,
        version: SourceItemVersion,
        marker: SpecMarker,
        content: bytes,
        *,
        replaces_earlier: bool,
    ) -> LoadedSpec:
        """Record the links a merged spec version states.

        :param version: The admitted spec file version
        :param marker: Story and spec identity reported by the reader
        :param content: The spec file's bytes
        :param replaces_earlier: True when an earlier version of this spec was already loaded
        :return: What was loaded, including whether it may trigger a new draft
        """
        spec = ItemRef(item_type=ItemType.SPEC, key=marker.spec_id or version.item_id)
        valid_from = marker.merged_at or version.modified_at or version.fetched_at
        clause_refs = extract_clause_refs(content)
        requirement_ids = self._cited_requirements(content)
        desired: list[_Fact] = [
            (ItemRef(item_type=ItemType.STORY, key=marker.story_key), Relation.SPECIFIED_BY, spec),
            *(
                (spec, Relation.DERIVED_FROM, ItemRef(item_type=ItemType.CLAUSE, key=ref))
                for ref in clause_refs
            ),
            *(
                (spec, Relation.DERIVED_FROM, ItemRef(item_type=ItemType.REQUIREMENT, key=key))
                for key in requirement_ids
            ),
        ]
        if marker.template is not None:
            template = ItemRef(item_type=ItemType.TEMPLATE, key=marker.template)
            desired.append((spec, Relation.USES_TEMPLATE, template))
        self._reconcile(spec, desired, valid_from, f"{MERGED_SPEC_EVIDENCE}{version.key}")
        self._record_merge(spec.key, version, valid_from)
        return LoadedSpec(
            key=version.key,
            story_key=marker.story_key,
            spec_key=spec.key,
            clause_refs=clause_refs,
            requirement_ids=requirement_ids,
            machine_authored=version.machine_authored,
            triggers_draft=not version.machine_authored and not replaces_earlier,
        )

    def _cited_requirements(self, content: bytes) -> tuple[str, ...]:
        """Find the register rows a spec cites, by row id or by the row's own id column."""
        text = content.decode("utf-8", errors="replace")
        table = schema.requirement
        found: list[str] = []
        for row in self._connection.execute(
            select(table.c.requirement_id, table.c.fields).order_by(table.c.requirement_id)
        ):
            native = row.fields.get(_REQUIREMENT_ID_FIELD)
            names = [row.requirement_id, native if isinstance(native, str) else ""]
            # Whole names only: "...:5" must not be found inside "...:50".
            if any(
                name and re.search(rf"(?<![\w-]){re.escape(name)}(?![\w-])", text) for name in names
            ):
                found.append(row.requirement_id)
        return tuple(found)

    def _record_merge(self, spec_key: str, version: SourceItemVersion, merged_at: datetime) -> None:
        """Mark the write side's spec row merged; a spec only a person wrote has no row."""
        table = schema.spec
        self._connection.execute(
            update(table)
            .where(table.c.spec_id == spec_key)
            .values(
                state=SpecState.MERGED.value,
                merged_at=merged_at,
                machine_authored=version.machine_authored,
                content_sha256=version.content_sha256,
            )
        )

    def spec_keys_for_story(self, story_key: str) -> tuple[str, ...]:
        """List the specs a story is currently specified by.

        :param story_key: The story
        :return: Natural keys of specs with an open link from the story
        """
        table = schema.link
        rows = self._connection.execute(
            select(table.c.target_key)
            .where(
                table.c.source_item_type == ItemType.STORY.value,
                table.c.source_key == story_key,
                table.c.relation == Relation.SPECIFIED_BY.value,
                table.c.valid_to.is_(None),
            )
            .order_by(table.c.target_key)
        )
        return tuple(row.target_key for row in rows)

    def _reconcile(
        self, spec: ItemRef, desired: list[_Fact], valid_from: datetime, evidence: str
    ) -> None:
        table = schema.link
        open_rows = self._connection.execute(
            select(table).where(
                table.c.valid_to.is_(None),
                or_(
                    and_(
                        table.c.source_item_type == ItemType.SPEC.value,
                        table.c.source_key == spec.key,
                        table.c.relation.in_(
                            (Relation.DERIVED_FROM.value, Relation.USES_TEMPLATE.value)
                        ),
                    ),
                    and_(
                        table.c.target_item_type == ItemType.SPEC.value,
                        table.c.target_key == spec.key,
                        table.c.relation == Relation.SPECIFIED_BY.value,
                    ),
                ),
            )
        ).mappings()
        stated: dict[_Fact, tuple[str, datetime]] = {
            (
                ItemRef(item_type=ItemType(row["source_item_type"]), key=row["source_key"]),
                Relation(row["relation"]),
                ItemRef(item_type=ItemType(row["target_item_type"]), key=row["target_key"]),
            ): (row["link_id"], row["valid_from"])
            for row in open_rows
        }
        wanted = set(desired)
        for fact, (link_id, opened) in stated.items():
            if fact not in wanted:
                self._close(link_id, max(valid_from, opened))
        for fact in desired:
            if fact not in stated:
                self._open(fact, valid_from, evidence)

    def _close(self, link_id: str, closed_at: datetime) -> None:
        table = schema.link
        self._connection.execute(
            update(table).where(table.c.link_id == link_id).values(valid_to=closed_at)
        )

    def _open(self, fact: _Fact, valid_from: datetime, evidence: str) -> None:
        source, relation, target = fact
        link = Link(
            link_id=_link_id(fact, valid_from),
            source_ref=source,
            relation=relation,
            target_ref=target,
            kind=LinkKind.STATED,
            state=LinkState.STATED,
            evidence=evidence,
            valid_from=valid_from,
        )
        self._connection.execute(
            insert(schema.link).values(
                link_id=link.link_id,
                source_item_type=source.item_type.value,
                source_key=source.key,
                relation=relation.value,
                target_item_type=target.item_type.value,
                target_key=target.key,
                kind=link.kind.value,
                state=link.state.value,
                score=link.score,
                evidence=link.evidence,
                valid_from=link.valid_from,
                valid_to=link.valid_to,
            )
        )
