"""Persistence of passages in the ``passage`` table, and the eligibility-filtered read of them.

Everything takes a :class:`sqlalchemy.Connection` from ``Database.transaction()``. Reading is
where the filters live: only passages of approved, in-force, non-withdrawn documents in the
caller's domains are returned, so ranking never sees anything else.

Design limit: :meth:`PassageStore.candidates` loads every eligible passage into memory and the
service ranks them per question (the keyword index is built per call). That is right for the
proof of concept corpus (hundreds to a few thousand passages). A larger corpus needs a
persistent keyword index and a vector index in the database, which the passage table already
has the columns for.
"""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from datetime import date
from typing import Any

from sqlalchemy import Column, Connection, RowMapping, bindparam, delete, func, select, update

from kp.domain import ApprovalState, Edition, Passage, PassageType, SourceKind
from kp.domain.editions import select_edition_as_at
from kp.store.schema import clause as clause_table
from kp.store.schema import edition as edition_table
from kp.store.schema import passage as passage_table
from kp.store.schema import source_item

SEARCHABLE_STATES: tuple[ApprovalState, ...] = (ApprovalState.ADMITTED, ApprovalState.SUPERSEDED)
_PASSAGE_COLUMNS = (
    "passage_id",
    "passage_type",
    "parent_ref",
    "source",
    "item_id",
    "version",
    "text",
    "tokens",
    "domain",
    "edition_label",
    "page",
    "char_start",
    "char_end",
    "part_index",
)


class PassageStore:
    """Reads and writes passages.

    :param connection: An open connection, usually from ``Database.transaction()``
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def replace_item(
        self, source: SourceKind, item_id: str, version: str, passages: Sequence[Passage]
    ) -> int:
        """Replace every passage of one item version, so a rebuild is idempotent.

        Embeddings held by the replaced rows are dropped with them; embed again afterwards.

        :param source: Source of the item
        :param item_id: Item identity
        :param version: Item version
        :param passages: The new passages; each must belong to this item version
        :return: The number of passages written
        :raises ValueError: If a passage belongs to a different item version
        """
        for passage in passages:
            if (passage.source, passage.item_id, passage.version) != (source, item_id, version):
                raise ValueError(f"Passage {passage.passage_id} belongs to another item version")
        self._connection.execute(
            delete(passage_table).where(
                passage_table.c.source == source.value,
                passage_table.c.item_id == item_id,
                passage_table.c.version == version,
            )
        )
        if passages:
            self._connection.execute(
                passage_table.insert(), [_to_row(passage) for passage in passages]
            )
        return len(passages)

    def count(self) -> int:
        """Count all stored passages.

        :return: The number of rows in ``passage``
        """
        return int(
            self._connection.execute(select(func.count()).select_from(passage_table)).scalar_one()
        )

    def get(self, passage_id: str) -> Passage | None:
        """Load one passage, embedding included.

        :param passage_id: The passage identity
        :return: The passage, or ``None`` when absent
        """
        row = (
            self._connection.execute(
                select(*_columns(with_embedding=True)).where(
                    passage_table.c.passage_id == passage_id
                )
            )
            .mappings()
            .first()
        )
        return None if row is None else _from_row(row, with_embedding=True)

    def unembedded(self, model_version: str, limit: int) -> list[Passage]:
        """List passages with no embedding from ``model_version``.

        :param model_version: The embedding model currently in use
        :param limit: Maximum number of passages to return
        :return: Passages whose embedding is missing or was made by another model
        """
        rows = self._connection.execute(
            select(*_columns(with_embedding=False))
            .where(
                passage_table.c.model_version.is_(None)
                | (passage_table.c.model_version != model_version)
            )
            .order_by(passage_table.c.passage_id)
            .limit(limit)
        ).mappings()
        return [_from_row(row, with_embedding=False) for row in rows]

    def set_embeddings(self, vectors: Mapping[str, Sequence[float]], model_version: str) -> None:
        """Store embeddings together with the model version that produced them.

        :param vectors: Vector per passage id
        :param model_version: The model that produced all of them
        """
        if not vectors:
            return
        self._connection.execute(
            update(passage_table)
            .where(passage_table.c.passage_id == bindparam("target_id"))
            .values(embedding=bindparam("vector"), model_version=bindparam("model")),
            [
                {"target_id": passage_id, "vector": list(vector), "model": model_version}
                for passage_id, vector in vectors.items()
            ],
        )

    def searchable_editions(self, domains: Sequence[str] = ()) -> list[Edition]:
        """List the editions of approved documents.

        Withdrawn, excluded, pending and non-conforming documents are left out, so they can
        never be selected as "in force".

        :param domains: Only editions of documents in these domains; empty means all
        :return: Editions in any order
        """
        return [edition for edition, _ in self.editions_with_domain(domains)]

    def edition_domains(self) -> dict[str, str | None]:
        """Map each searchable edition label to the domain of its document.

        :return: Domain per edition label; ``None`` where the document declares none
        """
        return {edition.label: domain for edition, domain in self.editions_with_domain(())}

    def clause_titles(self, labels: Collection[str]) -> dict[tuple[str, str], str]:
        """Look up clause titles, which are searched alongside the clause text.

        :param labels: Edition labels
        :return: Title per ``(edition label, clause number)``
        """
        if not labels:
            return {}
        rows = self._connection.execute(
            select(clause_table.c.edition, clause_table.c.number, clause_table.c.title).where(
                clause_table.c.edition.in_(list(labels))
            )
        )
        return {(row.edition, row.number): row.title for row in rows}

    def editions_with_domain(self, domains: Sequence[str] = ()) -> list[tuple[Edition, str | None]]:
        """List the editions of approved documents together with each document's domain.

        One query serves both :meth:`searchable_editions` and :meth:`edition_domains`, so a
        caller that needs both reads the editions once.

        :param domains: Only editions of documents in these domains; empty means all
        :return: ``(edition, domain)`` pairs in any order
        """
        statement = (
            select(edition_table, source_item.c.domain.label("document_domain"))
            .join(
                source_item,
                (edition_table.c.source == source_item.c.source)
                & (edition_table.c.item_id == source_item.c.item_id)
                & (edition_table.c.version == source_item.c.version),
            )
            .where(source_item.c.approval_state.in_([s.value for s in SEARCHABLE_STATES]))
        )
        if domains:
            statement = statement.where(source_item.c.domain.in_(list(domains)))
        found = []
        for row in self._connection.execute(statement).mappings():
            values = dict(row)
            domain = values.pop("document_domain")
            found.append((Edition.model_validate(values), domain))
        return found

    def candidates(
        self,
        *,
        as_at: date,
        domains: Sequence[str] = (),
        with_embeddings: bool = False,
        editions: Sequence[Edition] | None = None,
    ) -> list[Passage]:
        """Load the passages a question may be answered from.

        Filters are applied here, before any ranking:

        * the document is approved (admitted or superseded), never withdrawn;
        * ``domains``, when given, contains the passage's domain (a passage without a domain
          never matches a domain filter);
        * clause passages belong to the edition in force on ``as_at``
          (:func:`kp.domain.select_edition_as_at`);
        * other passages belong to the newest version of their item that applies on
          ``as_at`` (effective, not superseded or withdrawn by then).

        :param as_at: The date to read at
        :param domains: Allowed domains; empty means no domain filter
        :param with_embeddings: Whether to load the (large) embedding column
        :param editions: The searchable editions already read for ``domains``; read here when
            ``None``
        :return: Passages ordered by id
        """
        known = self.searchable_editions(domains) if editions is None else editions
        in_force = select_edition_as_at(known, as_at)
        statement = (
            select(
                *_columns(with_embedding=with_embeddings),
                source_item.c.approval_state,
                source_item.c.effective_date,
                source_item.c.superseded_at,
                source_item.c.withdrawn_at,
                source_item.c.modified_at,
                source_item.c.fetched_at,
            )
            .join(
                source_item,
                (passage_table.c.source == source_item.c.source)
                & (passage_table.c.item_id == source_item.c.item_id)
                & (passage_table.c.version == source_item.c.version),
            )
            .where(source_item.c.approval_state.in_([s.value for s in SEARCHABLE_STATES]))
            .order_by(passage_table.c.passage_id)
        )
        if domains:
            statement = statement.where(passage_table.c.domain.in_(list(domains)))
        rows = list(self._connection.execute(statement).mappings())
        newest = _newest_versions([row for row in rows if row["edition_label"] is None], as_at)
        kept = [row for row in rows if _is_kept(row, in_force, newest)]
        return [_from_row(row, with_embedding=with_embeddings) for row in kept]


def _columns(*, with_embedding: bool) -> list[Column[Any]]:
    names = [*_PASSAGE_COLUMNS, *(("embedding", "model_version") if with_embedding else ())]
    return [passage_table.c[name] for name in names]


def _is_kept(row: RowMapping, in_force: Edition | None, newest: set[tuple[str, str, str]]) -> bool:
    if row["edition_label"] is not None:
        return in_force is not None and row["edition_label"] == in_force.label
    return bool((row["source"], row["item_id"], row["version"]) in newest)


def _applies(row: RowMapping, as_at: date) -> bool:
    """Whether a non-edition item version applies on ``as_at`` by its own dates."""
    effective, superseded, withdrawn = (
        row["effective_date"],
        row["superseded_at"],
        row["withdrawn_at"],
    )
    if effective is not None and effective > as_at:
        return False
    if withdrawn is not None and withdrawn <= as_at:
        return False
    if superseded is not None:
        return bool(superseded > as_at)
    return bool(row["approval_state"] != ApprovalState.SUPERSEDED.value)


def _newest_versions(rows: Sequence[RowMapping], as_at: date) -> set[tuple[str, str, str]]:
    """Pick, per item, the newest version that applies on ``as_at``.

    Newest means latest effective date, then latest modification time, then latest fetch.
    """
    best: dict[tuple[str, str], tuple[tuple[float, float, float], str]] = {}
    for row in rows:
        if not _applies(row, as_at):
            continue
        effective = row["effective_date"]
        modified = row["modified_at"]
        rank = (
            float(effective.toordinal()) if effective is not None else 0.0,
            modified.timestamp() if modified is not None else 0.0,
            row["fetched_at"].timestamp(),
        )
        item = (row["source"], row["item_id"])
        if item not in best or rank > best[item][0]:
            best[item] = (rank, row["version"])
    return {(source, item_id, version) for (source, item_id), (_, version) in best.items()}


def _to_row(passage: Passage) -> dict[str, object]:
    row: dict[str, object] = {
        name: getattr(passage, name) for name in _PASSAGE_COLUMNS if name != "passage_type"
    }
    row["passage_type"] = passage.passage_type.value
    row["source"] = passage.source.value
    row["embedding"] = list(passage.embedding) if passage.embedding is not None else None
    row["model_version"] = passage.model_version
    return row


def _from_row(row: RowMapping, *, with_embedding: bool) -> Passage:
    values = {name: row[name] for name in _PASSAGE_COLUMNS}
    values["passage_type"] = PassageType(values["passage_type"])
    values["source"] = SourceKind(values["source"])
    if with_embedding and row["embedding"] is not None:
        values["embedding"] = tuple(float(x) for x in row["embedding"])
        values["model_version"] = row["model_version"]
    return Passage.model_validate(values)
