"""Base class of the domain entities."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class DomainModel(BaseModel):
    """Immutable, strictly-shaped value object. Change one with ``model_copy(update=...)``."""

    model_config = ConfigDict(frozen=True, extra="forbid")
