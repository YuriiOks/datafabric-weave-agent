---
name: km-story
description: Use to produce the deliverable of one story in designs/. Argument s1..s6.
argument-hint: s1..s6
disable-model-invocation: true
effort: xhigh
---

# km-story

Argument: $0 is s1..s6, else print "usage: /km-story s1..s6" and stop. Run id: km-story-$0-<date>
(for example km-story-s3-2026-11-11). Think hard: the owner signs and defends this document.
Output: kb/packs/$0.md, then designs/$0-<slug>.md.

| Story | Slug | Deliverable |
|---|---|---|
| s1 | components-review | status table with reuse verdicts |
| s2 | gaps-risks | risk register for the owner |
| s3 | product-model | schema proposal |
| s4 | roles-permissions | role x action x scope matrix |
| s5 | extraction-graph | workflow design |
| s6 | ingestion | ingestion design |

## 1 Gather
- kb/stories/$0.md: the ask, word for word. Missing: if kb/private/seed-context-2.md section 10
  has the text, write it there as a quote, label Reported (source seed-context-2 section 10),
  go on; else log it, tell the owner in two lines to run /km-read wiki or paste it, stop.
- The story's part of kb/seed/story-gaps.md, kb/seed/glossary.md, and the reference patterns in
  kb/seed/reference-patterns-1.md and -2.md that ${CLAUDE_SKILL_DIR}/references/$0.md names.
- kb/verified/$0.md. Missing: say "run /km-verify $0 first", ask the owner one yes/no question
  whether to continue. Yes: mark every claim without a verdict Unverified, in pack and design.
  No: stop.
- The kb areas named in the reference for $0, found through kb/INDEX.md. Rows of
  kb/risks/register.md that touch the story. Register missing: note it in the pack (s2 stops).
- kb/private is optional. When present, read seed-context.md and seed-context-2.md (cite as
  Reported, source seed-context section N). Without it, use code, wiki, kb/seed; mark Unverified.
- More than 30 kb files, or an answer over more than 3: ask km-scout. Code only via km-verifier.
- Observed needs an Observed kb line with a source, or a Confirmed or Narrowed verdict.
  Contradicted is never used. Document and code disagree: code wins, pack records both.

## 2 Pack: kb/packs/$0.md (kb rules, at most 150 lines)
Sections in order: Ask (quoted), Left out (each item from story-gaps, marked answered by the
kb with a link, or still open), Facts (one bullet each: label, text, kb link), Patterns that
fit (pattern number, one line on fit and on what is new), Decisions (question, 2 to 4 options
with one line of pro and con), Dependencies (on and from other stories), Risks (register ids),
Questions (by role, what each blocks). If the file exists, read it and update it.

## 3 Deliverable: designs/$0-<slug>.md
- Follow ${CLAUDE_SKILL_DIR}/references/$0.md: skeleton, facts to cover, decisions to make,
  acceptance criteria, mistakes to avoid. Also read ${CLAUDE_SKILL_DIR}/references/common.md.
- Make the decisions. For each: recommend one option, give the reason, name the role who
  confirms. Do not defer. Everything that is not in the code today is Proposed.
- Cover every Left out item, or say in one line why it is out of scope. Product language,
  numbers instead of adjectives, a label on every factual line.
- About 250 lines; longer detail to designs/$0-<slug>-annex.md. If designs/$0-<slug>.md exists,
  update it in place: keep decision ids D1..Dn and the Review notes, date changed decisions.

## 4 Review
- One km-reviewer pass, task in the canon form: goal, sign-off review; inputs,
  designs/$0-<slug>.md and story code $0; output, your reply format; skip, editing anything.
- Fix every high finding in the document. List the rest under "Review notes" at the end with
  severity and the reviewer's "could not verify" lines. Do not run a second review.

## 5 Finish
- Write kb/index.d/<run>.txt and kb/log.d/<run>.txt; the log lists missing inputs, Unverified claims
- Print at most 10 lines: the design path; the 3 decisions that need the owner, each as id,
  recommended option and confirming role; open questions, at most 2 per role.
