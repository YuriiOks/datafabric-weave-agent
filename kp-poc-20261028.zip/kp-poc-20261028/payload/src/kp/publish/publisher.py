"""The knowledge publisher: stage a version, check it, and switch to it only if it passes."""

from __future__ import annotations

import logging
import uuid
from datetime import timedelta

from sqlalchemy import Connection, insert, select, update

from kp.clock import Clock, SystemClock
from kp.config import Thresholds
from kp.domain import (
    CheckResult,
    DomainModel,
    KnowledgeVersion,
    KnowledgeVersionState,
    RunKind,
    RunOutcome,
)
from kp.errors import PublicationBlockedError
from kp.links import LinkGraph, LinkReader, SqlLinkStore
from kp.publish.catalog import DatabaseItemCatalog, ItemCatalogPort
from kp.publish.checks import evaluate_checks
from kp.publish.measure import Measurements, measure
from kp.publish.versions import KnowledgeVersionStore
from kp.store.schema import run as run_table

logger = logging.getLogger(__name__)


class PublicationResult(DomainModel):
    """The outcome of one publication attempt.

    ``serving`` is the version readers see after the attempt: the new one when it passed,
    otherwise the one that keeps serving (``None`` if nothing was ever published).
    """

    version: KnowledgeVersion
    serving: KnowledgeVersion | None
    published: bool

    @property
    def failed_checks(self) -> tuple[CheckResult, ...]:
        """The blocking checks that failed."""
        return self.version.blocking_failures()

    def require_published(self) -> KnowledgeVersion:
        """Return the new version, or raise when a blocking check stopped it.

        :return: The published version
        :raises PublicationBlockedError: If any blocking check failed
        """
        if not self.published:
            names = ", ".join(check.name for check in self.failed_checks)
            raise PublicationBlockedError(
                f"Knowledge version {self.version.version_id} was not published; "
                f"blocking checks failed: {names}"
            )
        return self.version


class KnowledgePublisher:
    """Publishes knowledge versions only when the checks pass.

    A version is staged, measured, and then either switched on or kept as failed. Switching
    on is one transaction step: the new version becomes ``published`` and the one before
    becomes ``retired`` with a retention date, so readers never see two. When a blocking
    check fails the previous version keeps serving and the failed one stays for inspection.
    Warnings and report-only items are recorded and never block.

    :param connection: A connection inside the caller's unit of work
    :param thresholds: The limits; the platform defaults when omitted
    :param clock: Time source; the system clock when omitted
    :param catalog: What a version would publish; read from the tables when omitted
    :param reader: Where links are read from; the SQL link store when omitted
    """

    def __init__(
        self,
        connection: Connection,
        *,
        thresholds: Thresholds | None = None,
        clock: Clock | None = None,
        catalog: ItemCatalogPort | None = None,
        reader: LinkReader | None = None,
    ) -> None:
        self._connection = connection
        self._thresholds = thresholds if thresholds is not None else Thresholds()
        self._clock: Clock = clock if clock is not None else SystemClock()
        self._catalog: ItemCatalogPort = (
            catalog if catalog is not None else DatabaseItemCatalog(connection)
        )
        self._versions = KnowledgeVersionStore(connection)
        self._links: LinkReader = (
            reader if reader is not None else SqlLinkStore(connection, self._clock)
        )

    def current(self) -> KnowledgeVersion | None:
        """Return the version now serving.

        :return: The published version, or ``None`` before the first publication
        """
        return self._versions.current()

    def versions(self) -> list[KnowledgeVersion]:
        """List every version, newest first.

        :return: All versions in any state
        """
        return self._versions.all()

    def measure(self) -> Measurements:
        """Measure a candidate version from the current links and items. Writes nothing.

        :return: The measurements the checks judge
        """
        serving = self._versions.current()
        return measure(
            self._catalog.items(),
            LinkGraph(self._links.in_use_links()),
            self._links.statistics(),
            serving.item_count if serving is not None else None,
        )

    def check(self) -> tuple[CheckResult, ...]:
        """Run the publication checks without staging or publishing anything.

        :return: One result per check
        """
        return evaluate_checks(self.measure(), self._thresholds)

    def publish(self, run_id: str | None = None) -> PublicationResult:
        """Stage a version, run the checks, and switch to it if no blocking check failed.

        Previous versions whose retention has run out are removed at the end.

        :param run_id: The build run this version belongs to; a new build run is recorded
            when omitted or not yet known
        :return: What happened and which version is serving now
        """
        now = self._clock.now()
        serving = self._versions.current()
        build_id = run_id if run_id is not None else f"build-{uuid.uuid4().hex[:12]}"
        owns_run = self._ensure_run(build_id)
        measured = self.measure()
        staged = KnowledgeVersion(
            version_id=f"kv-{uuid.uuid4().hex[:12]}",
            run_id=build_id,
            item_count=measured.item_count,
            created_at=now,
        )
        self._versions.add(staged)
        checking = staged.model_copy(
            update={
                "state": KnowledgeVersionState.CHECKING,
                "checks": evaluate_checks(measured, self._thresholds),
            }
        )
        self._versions.save(checking)
        if checking.blocking_failures():
            result = self._keep_failed(checking, serving)
        else:
            result = self._switch(checking, serving)
        if owns_run:
            self._finish_run(build_id, result)
        expired = self.expire_retired()
        logger.info(
            "Knowledge version checked",
            extra={
                "version": result.version.version_id,
                "published": result.published,
                "items": result.version.item_count,
                "blocking_failures": len(result.failed_checks),
                "expired": expired,
            },
        )
        return result

    def expire_retired(self) -> int:
        """Remove previous versions whose retention has run out.

        :return: How many were removed
        """
        return self._versions.delete_retired_before(self._clock.today())

    def _keep_failed(
        self, version: KnowledgeVersion, serving: KnowledgeVersion | None
    ) -> PublicationResult:
        failed = version.model_copy(update={"state": KnowledgeVersionState.FAILED_KEPT})
        self._versions.save(failed)
        return PublicationResult(version=failed, serving=serving, published=False)

    def _switch(
        self, version: KnowledgeVersion, serving: KnowledgeVersion | None
    ) -> PublicationResult:
        published = version.model_copy(
            update={
                "state": KnowledgeVersionState.PUBLISHED,
                "published_at": self._clock.now(),
            }
        )
        if serving is not None:
            retired = serving.model_copy(
                update={
                    "state": KnowledgeVersionState.RETIRED,
                    "retained_until": self._clock.today()
                    + timedelta(days=self._thresholds.previous_version_retention_days),
                }
            )
            self._versions.save(retired)
        self._versions.save(published)
        return PublicationResult(version=published, serving=published, published=True)

    def _ensure_run(self, run_id: str) -> bool:
        """Record a build run unless it exists; True when this publisher created it."""
        known = self._connection.execute(
            select(run_table.c.run_id).where(run_table.c.run_id == run_id)
        ).first()
        if known is not None:
            return False
        self._connection.execute(
            insert(run_table).values(
                run_id=run_id,
                kind=RunKind.BUILD.value,
                sources=[],
                started_at=self._clock.now(),
                ended_at=None,
                outcome=RunOutcome.RUNNING.value,
                items_touched=0,
            )
        )
        return True

    def _finish_run(self, run_id: str, result: PublicationResult) -> None:
        self._connection.execute(
            update(run_table)
            .where(run_table.c.run_id == run_id)
            .values(
                ended_at=self._clock.now(),
                outcome=(RunOutcome.SUCCEEDED if result.published else RunOutcome.FAILED).value,
                items_touched=result.version.item_count,
            )
        )
