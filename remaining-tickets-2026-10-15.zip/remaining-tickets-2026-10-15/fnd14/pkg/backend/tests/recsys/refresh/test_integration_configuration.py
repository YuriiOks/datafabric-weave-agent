"""Configuration snapshot over registered sources: identity, digest and drift."""

from __future__ import annotations

import json
import unittest

from app.recsys.refresh.integration.configuration import (
    RegisteredConfigurationPort,
    canonical,
    source_set_digest,
)
from app.recsys.refresh.ports import ConfigurationChanged

from . import integration_support as support
from . import protocol_fixtures as fixtures

CREDENTIALS = {
    support.WORKBOOK_ID: "credential-ref:workspace-file",
    support.SKILLS_ID: "credential-ref:operator-askpass",
}


class _Registrations:
    def __init__(self) -> None:
        self.workbook_revision = 7
        self.unavailable: Exception | None = None

    def __call__(self):
        if self.unavailable is not None:
            raise self.unavailable
        return (support.workbook_source(self.workbook_revision), support.skills_source())


def _port(registrations: _Registrations) -> RegisteredConfigurationPort:
    return RegisteredConfigurationPort(
        configuration_id="ppd-catalogue",
        load_sources=registrations,
        credential_references=CREDENTIALS,
    )


class RegisteredConfigurationTests(unittest.IsolatedAsyncioTestCase):
    def test_snapshot_names_sources_without_locations(self) -> None:
        snapshot = _port(_Registrations()).current_snapshot()

        self.assertEqual(snapshot.adapter_ids, (support.SKILLS_ID, support.WORKBOOK_ID))
        self.assertEqual(snapshot.scope, fixtures.SCOPE)
        self.assertEqual(dict(snapshot.credential_references), CREDENTIALS)
        self.assertIn("skill_content", snapshot.required_collections)
        exposed = json.dumps(canonical(snapshot.adapter_parameters))
        self.assertNotIn(str(support.WORKBOOK_PATH.parent), exposed)
        self.assertNotIn(support.SKILLS_HOST, exposed)

    def test_digest_ignores_registration_and_set_order(self) -> None:
        sources = (support.workbook_source(), support.skills_source())

        self.assertEqual(
            source_set_digest("ppd-catalogue", sources),
            source_set_digest("ppd-catalogue", tuple(reversed(sources))),
        )
        self.assertEqual(canonical(frozenset({"b", "a"})), ["a", "b"])
        self.assertNotEqual(
            source_set_digest("ppd-catalogue", sources),
            source_set_digest("other-catalogue", sources),
        )

    async def test_admitted_snapshot_is_refused_after_a_registration_changes(self) -> None:
        registrations = _Registrations()
        port = _port(registrations)
        snapshot = await port.resolve("ppd-catalogue", fixtures.IDENTITY)

        self.assertIs(await port.verify_revision(snapshot), snapshot)
        registrations.workbook_revision = 8
        with self.assertRaises(ConfigurationChanged):
            await port.verify_revision(snapshot)

    async def test_unknown_configuration_is_refused(self) -> None:
        with self.assertRaises(ConfigurationChanged):
            await _port(_Registrations()).resolve("another-catalogue", fixtures.IDENTITY)

    async def test_unavailable_registration_is_refused_without_a_snapshot(self) -> None:
        registrations = _Registrations()
        registrations.unavailable = FileNotFoundError("workbook absent")

        with self.assertRaises(ConfigurationChanged):
            await _port(registrations).resolve("ppd-catalogue", fixtures.IDENTITY)

    def test_missing_credential_reference_is_refused(self) -> None:
        port = RegisteredConfigurationPort(
            configuration_id="ppd-catalogue",
            load_sources=_Registrations(),
            credential_references={support.WORKBOOK_ID: "credential-ref:workspace-file"},
        )

        with self.assertRaises(ConfigurationChanged):
            port.current_snapshot()
