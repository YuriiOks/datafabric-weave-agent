"""US-01, US-03 (gate side) and US-04: what the approval gate admits, holds and withdraws."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import pytest
from pydantic import JsonValue
from sqlalchemy import func, select

from kp.domain import DETAIL_NAMES, ApprovalState, ChangeKind, ItemKey, ReviewKind, SourceKind
from kp.store import schema as tables
from kp.sweep import SweepStore, WorkReason

from .conftest import Harness
from .support import (
    ScriptedReader,
    confluence_entries,
    entry,
    governed_attributes,
    library_entries,
)

LIBRARY = SourceKind.DOCUMENT_LIBRARY
CONFLUENCE = SourceKind.CONFLUENCE
TODAY = date(2026, 11, 1)


def _library_reader(root: Path) -> ScriptedReader:
    reader = ScriptedReader(LIBRARY)
    reader.add(*library_entries(root))
    return reader


def test_us01_draft_is_recorded_as_excluded_and_never_processed(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    harness.sweep(_library_reader(committed_fixtures_dir))

    assert harness.version(LIBRARY, "operating-guide", "2").approval_state is ApprovalState.ADMITTED
    assert harness.version(LIBRARY, "operating-guide", "3").approval_state is ApprovalState.EXCLUDED
    draft = ItemKey(source=LIBRARY, item_id="operating-guide", version="3")
    assert draft not in harness.processor.processed
    admitted = [v for v in harness.versions(LIBRARY) if v.approval_state is ApprovalState.ADMITTED]
    assert [(v.item_id, v.version) for v in admitted] == [("operating-guide", "2")]


def test_us01_older_approved_version_is_the_only_one_handed_on(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    summary = harness.sweep(_library_reader(committed_fixtures_dir))

    handed_on = {(item.key.item_id, item.key.version) for item in summary.work_items}
    assert handed_on == {("operating-guide", "2")}
    assert {item.reason for item in summary.work_items} == {WorkReason.NEW}


def test_us01_draft_later_approved_is_loaded_and_old_version_superseded_not_deleted(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = _library_reader(committed_fixtures_dir)
    harness.sweep(reader)
    draft_body = harness.raw_store.get("document_library/operating-guide/3")

    reader.add(
        entry(
            LIBRARY,
            "operating-guide",
            "3",
            content=draft_body,
            title="operating-guide",
            attributes=governed_attributes(),
            modified_at="2026-10-05T09:00:00+00:00",
        )
    )
    summary = harness.sweep(reader)

    new = harness.version(LIBRARY, "operating-guide", "3")
    old = harness.version(LIBRARY, "operating-guide", "2")
    assert new.approval_state is ApprovalState.ADMITTED
    assert old.approval_state is ApprovalState.SUPERSEDED
    assert old.superseded_at == TODAY
    assert harness.raw_store.get(old.raw_location)
    assert [(i.key.version, i.reason) for i in summary.work_items] == [("3", WorkReason.CHANGED)]
    kinds = {event.kind for event in harness.events() if event.new_version == "3"}
    assert kinds == {ChangeKind.CHANGED, ChangeKind.SUPERSEDED}


def test_us01_confluence_page_without_the_label_is_pending_and_not_loaded(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(CONFLUENCE)
    reader.add(*confluence_entries(committed_fixtures_dir))

    harness.sweep(reader)

    assert harness.version(CONFLUENCE, "page-1002", "1").approval_state is ApprovalState.PENDING
    assert harness.version(CONFLUENCE, "page-1001", "1").approval_state is ApprovalState.ADMITTED
    assert "page-1002" not in harness.processor.processed_ids(CONFLUENCE)


def test_us01_confluence_newer_draft_version_is_excluded_older_published_stays(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(CONFLUENCE)
    reader.add(*confluence_entries(committed_fixtures_dir))

    harness.sweep(reader)

    states = {
        version: harness.version(CONFLUENCE, "page-1003", version).approval_state
        for version in ("1", "2", "3")
    }
    assert states == {
        "1": ApprovalState.SUPERSEDED,
        "2": ApprovalState.ADMITTED,
        "3": ApprovalState.EXCLUDED,
    }


def test_us01_page_gets_loaded_on_the_sweep_after_the_label_is_added(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(CONFLUENCE)
    reader.add(*confluence_entries(committed_fixtures_dir))
    harness.sweep(reader)

    reader.add(
        entry(
            CONFLUENCE,
            "page-1002",
            "1",
            content=harness.raw_store.get("confluence/page-1002/1"),
            attributes={"labels": ["approved", "payments"], "state": "published"},
        )
    )
    harness.sweep(reader)

    assert harness.version(CONFLUENCE, "page-1002", "1").approval_state is ApprovalState.ADMITTED
    assert "page-1002" in harness.processor.processed_ids(CONFLUENCE)


@pytest.mark.parametrize("missing", DETAIL_NAMES)
def test_us03_missing_detail_is_non_conforming_with_review_item(
    harness: Harness, missing: str
) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(
        entry(
            LIBRARY,
            "handbook",
            "1",
            title="Handbook",
            attributes=governed_attributes(**{missing: None}),
        )
    )

    harness.sweep(reader)

    version = harness.version(LIBRARY, "handbook", "1")
    assert version.approval_state is ApprovalState.NON_CONFORMING
    assert harness.processor.processed == []
    (review,) = harness.reviews()
    assert review.kind is ReviewKind.MISSING_DETAIL
    assert (review.item_id, review.version) == ("handbook", "1")
    assert "Handbook" in review.detail
    assert review.missing_details == (missing,)
    expected_owner = None if missing == "content_owner" else "owner-role-payments"
    assert review.content_owner == expected_owner


def test_us03_fixture_without_content_owner_is_flagged_with_no_owner_named(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    harness.sweep(_library_reader(committed_fixtures_dir))

    note = harness.version(LIBRARY, "escalation-note", "1")
    assert note.approval_state is ApprovalState.NON_CONFORMING
    review = next(r for r in harness.reviews() if r.item_id == "escalation-note")
    assert review.missing_details == ("content_owner",)
    assert review.content_owner is None


def test_us03_every_missing_detail_is_named(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    attributes = governed_attributes(domain=None, authority="  ")
    reader.add(entry(LIBRARY, "partial", "1", attributes=attributes))

    harness.sweep(reader)

    (review,) = harness.reviews()
    assert review.missing_details == ("domain", "authority")


def test_us03_unknown_document_type_is_held_not_processed(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    harness.sweep(_library_reader(committed_fixtures_dir))

    memo = harness.version(LIBRARY, "unclassified-memo", "1")
    assert memo.approval_state is ApprovalState.PENDING
    assert "unclassified-memo" not in harness.processor.processed_ids(LIBRARY)
    review = next(r for r in harness.reviews() if r.item_id == "unclassified-memo")
    assert review.kind is ReviewKind.UNKNOWN_DOCUMENT_TYPE
    assert review.content_owner == "owner-role-cards"


def test_us03_rerun_does_not_open_a_second_review_item(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = _library_reader(committed_fixtures_dir)
    reader.honour_cursor = False
    harness.sweep(reader)
    first = len(harness.reviews())

    harness.sweep(reader)

    assert first == 2
    assert len(harness.reviews()) == first


def test_us03_review_closes_once_the_document_is_fixed(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(entry(LIBRARY, "handbook", "1", attributes=governed_attributes(authority=None)))
    harness.sweep(reader)

    reader.add(entry(LIBRARY, "handbook", "1", attributes=governed_attributes()))
    harness.sweep(reader)

    fixed = harness.version(LIBRARY, "handbook", "1")
    assert fixed.approval_state is ApprovalState.ADMITTED
    assert fixed.details.authority == "Example Scheme"
    assert fixed.details.is_complete
    (review,) = harness.reviews()
    assert review.state.value == "resolved"


def test_us03_review_fix_refreshes_the_details_downstream_filters_read(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(entry(LIBRARY, "handbook", "1", attributes=governed_attributes(domain=None)))
    harness.sweep(reader)
    assert harness.version(LIBRARY, "handbook", "1").details.domain is None

    reader.add(
        entry(
            LIBRARY,
            "handbook",
            "1",
            attributes=governed_attributes(domain="cards", content_owner="owner-role-cards"),
        )
    )
    harness.sweep(reader)

    fixed = harness.version(LIBRARY, "handbook", "1")
    assert fixed.approval_state is ApprovalState.ADMITTED
    assert fixed.details.domain == "cards"
    assert fixed.details.content_owner == "owner-role-cards"


def test_us03_document_without_status_or_sidecar_gets_a_review_item(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(
        entry(
            LIBRARY,
            "orphan",
            "1",
            title="Orphan Guide",
            attributes={"approval_status": None, "sidecar_present": False},
        )
    )

    summary = harness.sweep(reader)

    assert summary.work_items == ()
    assert harness.version(LIBRARY, "orphan", "1").approval_state is ApprovalState.NON_CONFORMING
    (review,) = harness.reviews()
    assert review.kind is ReviewKind.MISSING_DETAIL
    assert "Orphan Guide" in review.detail
    assert "no metadata sidecar" in review.detail
    assert review.missing_details == (*DETAIL_NAMES, "approval_status")


def test_us03_document_in_review_with_all_details_is_pending_without_a_review_item(
    harness: Harness,
) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(
        entry(LIBRARY, "draftish", "1", attributes=governed_attributes(approval_status="in review"))
    )

    harness.sweep(reader)

    assert harness.version(LIBRARY, "draftish", "1").approval_state is ApprovalState.PENDING
    assert harness.reviews() == []


@pytest.mark.parametrize("reverse", [False, True])
def test_us02_numeric_versions_stamped_alike_supersede_in_numeric_order(
    harness: Harness, reverse: bool
) -> None:
    entries = [
        entry(
            LIBRARY,
            "handbook",
            number,
            attributes=governed_attributes(),
            modified_at="2026-10-01T09:00:00+00:00",
        )
        for number in ("9", "10")
    ]
    if reverse:
        entries.reverse()
    reader = ScriptedReader(LIBRARY)
    reader.add(*entries)

    summary = harness.sweep(reader)

    assert harness.version(LIBRARY, "handbook", "9").approval_state is ApprovalState.SUPERSEDED
    assert harness.version(LIBRARY, "handbook", "10").approval_state is ApprovalState.ADMITTED
    assert summary.outcome.value == "succeeded"


def test_us04_revoked_approval_withdraws_the_version_from_today_and_keeps_its_predecessor(
    harness: Harness,
) -> None:
    reader = ScriptedReader(CONFLUENCE)
    approved: dict[str, JsonValue] = {"labels": ["approved"], "state": "published"}
    first, second = (
        entry(CONFLUENCE, "page", "1", attributes=approved, modified_at="2026-10-01T09:00:00"),
        entry(CONFLUENCE, "page", "2", attributes=approved, modified_at="2026-10-02T09:00:00"),
    )
    reader.add(first, second)
    harness.sweep(reader)
    harness.advance(days=2)
    reader.add(
        entry(
            CONFLUENCE,
            "page",
            "2",
            content=harness.raw_store.get("confluence/page/2"),
            attributes={"labels": [], "state": "published"},
            modified_at="2026-10-02T09:00:00",
        )
    )

    summary = harness.sweep(reader)

    revoked = harness.version(CONFLUENCE, "page", "2")
    assert revoked.approval_state is ApprovalState.WITHDRAWN
    assert revoked.withdrawn_at == date(2026, 11, 3)
    # Nothing is in force until a new approved version arrives: the predecessor stays replaced.
    assert harness.version(CONFLUENCE, "page", "1").approval_state is ApprovalState.SUPERSEDED
    (event,) = harness.events(ChangeKind.WITHDRAWN)
    assert (event.old_version, event.new_version) == ("2", None)
    assert summary.work_items == ()
    with harness.database.transaction() as connection:
        status = SweepStore(connection).citation_status(revoked.key)
    assert status is not None
    assert status.withdrawn_at == date(2026, 11, 3)


def test_us01_excluded_draft_leaves_nothing_downstream_of_its_stored_row(
    harness: Harness,
) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(
        entry(
            LIBRARY,
            "handbook",
            "1",
            content=b"Per 2026.1:4.2.1 the limit applies.",
            attributes=governed_attributes(approval_status="draft"),
        )
    )

    summary = harness.sweep(reader)

    # The draft is kept as a stored row (state excluded) so a later approval can be matched
    # to the same bytes; it is never processed, never announced, and never linked.
    assert harness.version(LIBRARY, "handbook", "1").approval_state is ApprovalState.EXCLUDED
    assert summary.work_items == ()
    assert harness.processor.processed == []
    assert harness.events() == []
    with harness.database.transaction() as connection:
        for name in ("link", "passage", "clause"):
            table = tables.metadata.tables[name]
            assert connection.execute(select(func.count()).select_from(table)).scalar_one() == 0


def test_us04_removed_document_is_withdrawn_kept_and_still_citable(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(
        entry(LIBRARY, "handbook", "1", content=b"clause text", attributes=governed_attributes())
    )
    harness.sweep(reader)

    reader.add_deleted(LIBRARY, "handbook", "1")
    summary = harness.sweep(reader)

    version = harness.version(LIBRARY, "handbook", "1")
    assert version.approval_state is ApprovalState.WITHDRAWN
    assert version.withdrawn_at == TODAY
    assert harness.raw_store.get(version.raw_location) == b"clause text"
    assert summary.work_items == ()
    (event,) = harness.events(ChangeKind.WITHDRAWN)
    assert (event.old_version, event.new_version) == ("1", None)
    with harness.database.transaction() as connection:
        status = SweepStore(connection).citation_status(version.key)
    assert status is not None
    assert status.approval_state is ApprovalState.WITHDRAWN
    assert status.withdrawn_at == TODAY


def test_us04_withdrawn_document_is_no_longer_admitted_anywhere(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(entry(LIBRARY, "handbook", "1", attributes=governed_attributes()))
    harness.sweep(reader)
    reader.add(
        entry(LIBRARY, "handbook", "1", attributes=governed_attributes(approval_status="withdrawn"))
    )

    harness.sweep(reader)

    assert [v for v in harness.versions() if v.approval_state is ApprovalState.ADMITTED] == []
    assert harness.version(LIBRARY, "handbook", "1").approval_state is ApprovalState.WITHDRAWN


def test_us04_withdrawal_happens_once(harness: Harness) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add(entry(LIBRARY, "handbook", "1", attributes=governed_attributes()))
    harness.sweep(reader)
    reader.add_deleted(LIBRARY, "handbook", "1")
    harness.sweep(reader)
    harness.advance(days=3)

    reader.honour_cursor = False
    harness.sweep(reader)

    assert harness.version(LIBRARY, "handbook", "1").withdrawn_at == TODAY
    assert len(harness.events(ChangeKind.WITHDRAWN)) == 1


def test_us04_removal_of_an_item_that_was_never_admitted_changes_nothing(
    harness: Harness,
) -> None:
    reader = ScriptedReader(LIBRARY)
    reader.add_deleted(LIBRARY, "ghost", "1")

    summary = harness.sweep(reader)

    assert summary.state_changes == 0
    assert harness.events() == []
