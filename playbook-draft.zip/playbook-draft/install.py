"""Inspect or apply the change packages in this folder. Harness file: never committed.

usage:
  python3 install.py --inspect                     read-only: every package, its branch,
                                                   the files it touches and its edit count
  python3 install.py <package> <worktree> --check  read-only: would the package apply?
  python3 install.py <package> <worktree>          apply one package, uncommitted

Applying never stages, commits, pushes or runs tests. See README.md for the order.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGES = HERE / "packages"


def inspect() -> int:
    order = json.loads((HERE / "ORDER.json").read_text(encoding="ascii"))
    for name in order:
        folder = PACKAGES / name
        meta = json.loads((folder / "package.json").read_text(encoding="ascii"))
        edits = json.loads((folder / "edits.json").read_text(encoding="ascii"))
        new_files = sorted(
            path.relative_to(folder / "pkg").as_posix()
            for path in (folder / "pkg").rglob("*")
            if path.is_file()
        )
        print(f"{name}: branch {meta['branch']}")
        for rel in sorted({edit["path"] for edit in edits}):
            count = sum(1 for edit in edits if edit["path"] == rel)
            print(f"  edit {rel} ({count} hunks)")
        for rel in new_files:
            print(f"  new  {rel}")
    return 0


def main(argv: list[str]) -> int:
    if argv == ["--inspect"]:
        return inspect()
    if len(argv) < 2 or argv[0].startswith("-"):
        print(__doc__)
        return 2
    folder = PACKAGES / argv[0]
    if not (folder / "package.json").is_file():
        print(f"unknown package: {argv[0]}")
        return 2
    command = [sys.executable, str(HERE / "applylib.py"), str(folder), *argv[1:]]
    return subprocess.run(command, check=False).returncode


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
