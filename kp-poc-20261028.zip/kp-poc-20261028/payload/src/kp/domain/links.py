"""Links between items. Links are facts with a validity period; nothing is overwritten."""

from __future__ import annotations

from typing import Annotated, Self

from pydantic import AwareDatetime, Field, model_validator

from kp.domain.base import DomainModel
from kp.domain.enums import ItemType, LinkKind, LinkState
from kp.domain.relations import Relation

MERGED_SPEC_EVIDENCE = "merged spec "
"""Start of the evidence of a link stated by a merged spec file (see ``kp.sweep.loadback``).

Such a link is closed only when a newer version of the same spec stops stating it. A loader that
syncs other links of the same relation (the tracker's issue links) must leave it alone.
"""


class ItemRef(DomainModel):
    """Natural key of a link endpoint.

    ``key`` is the clause reference text (``2026.1:4.2.1``), a story key, a requirement id,
    a commit-qualified code path, and so on.
    """

    item_type: ItemType
    key: str


class Link(DomainModel):
    """A directed, typed connection between two items, valid over a period.

    A change closes the old fact (``valid_to``) and opens a new one (``valid_from``).
    Stated links come from a source (tracker links, register columns, repository files) and
    have no score. Guessed links carry a 0-1 score and the evidence behind it.
    """

    link_id: str
    source_ref: ItemRef
    relation: Relation
    target_ref: ItemRef
    kind: LinkKind
    state: LinkState
    score: Annotated[float, Field(ge=0, le=1)] | None = None
    evidence: str = ""
    valid_from: AwareDatetime
    valid_to: AwareDatetime | None = None

    @model_validator(mode="after")
    def _conforms_to_model(self) -> Self:
        if not self.relation.allows(self.source_ref.item_type, self.target_ref.item_type):
            raise ValueError(
                f"{self.relation.value} cannot connect {self.source_ref.item_type.value} "
                f"to {self.target_ref.item_type.value}"
            )
        if self.kind is LinkKind.STATED and (
            self.state is not LinkState.STATED or self.score is not None
        ):
            raise ValueError("a stated link has state 'stated' and no score")
        if self.kind is LinkKind.GUESSED and (self.state is LinkState.STATED or self.score is None):
            raise ValueError("a guessed link has a score and a state other than 'stated'")
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError("valid_to must not precede valid_from")
        return self

    @property
    def is_open(self) -> bool:
        """True while the link has not been closed by a later fact."""
        return self.valid_to is None
