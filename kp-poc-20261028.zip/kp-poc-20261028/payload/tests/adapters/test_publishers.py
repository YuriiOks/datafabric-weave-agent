"""Choosing where specs are published, for the mode and the machine."""

from __future__ import annotations

from pathlib import Path

import pytest

from kp.adapters.dry_run_publisher import DryRunSpecPublisher
from kp.adapters.publishers import PublisherKind, choose_writers
from kp.clock import SystemClock
from kp.config import Mode, Settings
from kp.errors import ConfigurationError
from kp.writeback import DryRunJiraUpdater, LocalGitPublisher

LOCAL_TARGETS = {
    "spec_repo": "example-org/example-specs",
    "spec_path": "specs",
    "jira_fields_allowed": ("status", "spec_link"),
}


def _local(tmp_path: Path) -> Settings:
    return Settings(_env_file=None, mode=Mode.LOCAL, data_dir=tmp_path, **LOCAL_TARGETS)  # type: ignore[arg-type]


def test_without_a_working_git_binary_specs_are_recorded_in_a_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("kp.adapters.publishers.resolve_git_binary", lambda **_: None)

    writers = choose_writers(_local(tmp_path), SystemClock())

    assert writers.kind is PublisherKind.DRY_RUN
    assert isinstance(writers.publisher, DryRunSpecPublisher)
    assert isinstance(writers.jira, DryRunJiraUpdater)


def test_with_a_working_git_binary_specs_go_to_a_local_repository(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("kp.adapters.publishers.resolve_git_binary", lambda **_: "git")
    monkeypatch.setattr(
        LocalGitPublisher,
        "initialise",
        classmethod(lambda cls, path, binary, **kwargs: cls(path, binary, **kwargs)),
    )

    writers = choose_writers(_local(tmp_path), SystemClock())

    assert writers.kind is PublisherKind.LOCAL_GIT
    assert isinstance(writers.publisher, LocalGitPublisher)


def test_real_mode_has_no_writer_and_says_why(tmp_path: Path) -> None:
    settings = _local(tmp_path).model_copy(update={"mode": Mode.REAL})

    with pytest.raises(ConfigurationError, match="not available with KP_MODE=real"):
        choose_writers(settings, SystemClock())
