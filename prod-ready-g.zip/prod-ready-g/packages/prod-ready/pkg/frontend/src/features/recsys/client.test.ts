import { afterEach, describe, expect, it, vi } from 'vitest'

const { realApi, mockApi } = vi.hoisted(() => ({
  realApi: { getCatalogueStatus: vi.fn() },
  mockApi: { getCatalogueStatus: vi.fn() },
}))

vi.mock('./api', () => ({ realApi }))
vi.mock('./mock', () => ({ mockApi }))

afterEach(() => {
  vi.unstubAllEnvs()
  vi.resetModules()
  vi.clearAllMocks()
})

describe('recsysApi', () => {
  it('asks the live recommender, never the sample data, when demo mode is off', async () => {
    vi.stubEnv('VITE_RECSYS_MOCK', '')
    realApi.getCatalogueStatus.mockRejectedValue(new Error('not mounted'))
    const { recsysApi, recsysLive } = await import('./client')

    expect(await recsysLive()).toBe(false)
    await expect(recsysApi.getCatalogueStatus()).rejects.toThrow('not mounted')
    expect(mockApi.getCatalogueStatus).not.toHaveBeenCalled()
  })

  it('serves the sample data only when demo mode is switched on', async () => {
    vi.stubEnv('VITE_RECSYS_MOCK', '1')
    mockApi.getCatalogueStatus.mockResolvedValue({ version: 'sample' })
    const { recsysApi } = await import('./client')

    await recsysApi.getCatalogueStatus()
    expect(mockApi.getCatalogueStatus).toHaveBeenCalledTimes(1)
    expect(realApi.getCatalogueStatus).not.toHaveBeenCalled()
  })
})
