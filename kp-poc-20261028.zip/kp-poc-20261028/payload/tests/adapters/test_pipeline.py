"""The pipeline processor: ingest, passages and stated links in the sweep's transaction."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import func, select

from kp.app import Application, build_application
from kp.clock import FixedClock
from kp.demo.runner import demo_settings
from kp.demo.staging import find_dataset, stage
from kp.domain import LinkState, PassageType, Relation, SourceKind
from kp.store import schema
from kp.sweep import SweepStore
from world_support import World

REGISTER_ROWS_WITH_A_RULE = 10  # of twelve; two card rows cite none


def test_a_swept_world_has_passages_of_every_kind_it_loads(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        found = set(connection.execute(select(schema.passage.c.passage_type)).scalars())

    assert {
        PassageType.CLAUSE.value,
        PassageType.REGISTER_ROW.value,
        PassageType.STORY.value,
        PassageType.ACCEPTANCE_CRITERIA.value,
    } <= found


def test_register_rows_become_constrained_by_links_to_the_clauses_they_cite(
    built_world: World,
) -> None:
    with built_world.application.database.transaction() as connection:
        stated = connection.execute(
            select(func.count()).where(
                schema.link.c.relation == Relation.CONSTRAINED_BY.value,
                schema.link.c.state == LinkState.STATED.value,
            )
        ).scalar_one()

    assert stated == REGISTER_ROWS_WITH_A_RULE


def test_a_register_swept_before_the_rulebook_is_linked_once_the_rulebook_arrives(
    committed_fixtures_dir: Path, tmp_path: Path
) -> None:
    staged = stage(find_dataset(committed_fixtures_dir), tmp_path)
    application = build_application(
        demo_settings(staged, tmp_path, tmp_path / "order.db"),
        clock=FixedClock(staged.demo_instant()),
        sleeper=lambda _seconds: None,
    )
    try:
        application.database.create_all()
        application.sweep([SourceKind.DOCUMENT_LIBRARY])
        before = _links(application)
        application.sweep([SourceKind.REGULATORY_REPO])
        after = _links(application)
    finally:
        application.close()

    assert before == 0
    assert after == REGISTER_ROWS_WITH_A_RULE


def _links(application: Application) -> int:

    with application.database.transaction() as connection:
        return int(connection.execute(select(func.count()).select_from(schema.link)).scalar_one())


def test_a_board_move_keeps_the_fingerprint_and_a_criteria_change_does_not(
    built_world: World,
) -> None:
    application = built_world.application
    processor = application.processor()
    raw = application.sweep_runtime().raw_store
    truth = built_world.staged.dataset.truth.stories

    def fingerprints(story_key: str) -> list[str | None]:
        with application.database.transaction() as connection:
            versions = SweepStore(connection).list_versions(SourceKind.JIRA, story_key)
        return [
            processor.fingerprint(version, raw.get(version.raw_location))
            for version in sorted(versions, key=lambda item: item.version)
        ]

    moved = fingerprints(truth.status_only_key)
    changed = fingerprints(truth.criteria_changed_key)

    assert len(moved) == len(changed) == 2
    assert moved[0] == moved[1]
    assert changed[0] != changed[1]
