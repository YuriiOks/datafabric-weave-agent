"""The template port: a governed template, or nothing."""

from __future__ import annotations

from kp.adapters.template_port import DatabaseTemplatePort
from world_support import World


def test_the_newest_template_of_a_type_is_returned(built_world: World) -> None:
    template = DatabaseTemplatePort(built_world.application.database).get("functional")

    assert template is not None
    assert template.template_id == "functional-spec"
    assert template.version == "1.0.0"


def test_a_named_version_is_returned_and_an_unknown_one_is_none(built_world: World) -> None:
    port = DatabaseTemplatePort(built_world.application.database)

    assert port.get("functional", "1.0.0") is not None
    assert port.get("functional", "9.9.9") is None


def test_a_type_with_no_governed_template_is_none_never_a_fallback(built_world: World) -> None:
    assert DatabaseTemplatePort(built_world.application.database).get("migration") is None
