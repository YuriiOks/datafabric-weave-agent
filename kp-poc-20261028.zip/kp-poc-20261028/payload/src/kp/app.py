"""The composition root: one function builds the whole application from the settings.

Nothing else in the package wires lane packages together. :func:`build_application` returns an
:class:`Application` whose methods are the things the platform does: sweep the sources (with a
processor that parses, indexes and links), run the steps that need the whole picture (code
repository links, guessed links), publish a knowledge version, and build the agent servers.

Switching from stand-in data to the real route is a settings change (``KP_MODE=real`` plus the
gateway settings): the readers come from :mod:`kp.adapters.real_route`, the raw copies go to the
raw bucket, the code links are read from the swept files, and the database must be PostgreSQL.
Real mode never creates tables on its own; ``kp init-db`` does.
"""

from __future__ import annotations

import time
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import Connection

from kp.adapters.code_checkout import swept_code_checkout
from kp.adapters.coverage_port import LinkServiceCoveragePort
from kp.adapters.domains import ItemDomains
from kp.adapters.guessing import LinkGuesser
from kp.adapters.link_port import StoreLinkPort
from kp.adapters.pipeline import PipelineProcessor
from kp.adapters.publishers import Writers, choose_writers, open_spec_source
from kp.adapters.raw_store import choose_raw_store
from kp.adapters.real_route import RealRoute, real_reader_builders
from kp.adapters.retrievals import DatabaseSessionRetrievals, RetrievalRecorder
from kp.adapters.rule_port import DatabaseRulePort
from kp.adapters.search_port import SearchServicePort
from kp.adapters.spec_targets import SpecAwareTargets
from kp.adapters.stated_links import StatedLinkLoader
from kp.adapters.template_port import DatabaseTemplatePort
from kp.adapters.write_port import WriteToolsPort
from kp.clock import Clock, SystemClock
from kp.config import Mode, Settings
from kp.domain import ItemRef, SourceKind
from kp.errors import ConfigurationError
from kp.links import GuessReport, NoEditionInForceError, SyncReport
from kp.mcp import ServeWiring
from kp.mcp.server import McpServer
from kp.mcp.servers import build_read_server, build_write_server
from kp.publish import KnowledgePublisher, PublicationResult
from kp.search import SearchService
from kp.sources.factory import RealReaderBuilder, StandInLocations
from kp.sources.spec_repo import MergedSpecSource
from kp.store import Database
from kp.sweep import (
    ApprovalGate,
    FactoryTargetProvider,
    RawStore,
    Sleeper,
    Sweeper,
    SweepSummary,
    TargetProvider,
)
from kp.sweep.cli import SweepRuntime, build_runtime
from kp.tools import (
    DatabaseAuditSink,
    IdentityMapping,
    ReadPorts,
    ToolObserver,
    WriteToolPort,
)
from kp.writeback import DatabaseAuditSink as WritebackAuditSink
from kp.writeback import (
    DraftSpecRuntime,
    InMemorySessionRetrievals,
    JiraSyncService,
    MergeResult,
    SpecMerger,
    SpecPublishingService,
    TemplateRepository,
    WriteTools,
    branch_for_story,
    parse_template,
)
from kp.writeback.limits import require_story_key
from kp.writeback.ports import SessionRetrievals

_CODE_REPO_FOLDER = "code_repo"


@dataclass(frozen=True)
class AfterSweepReport:
    """What the steps after a sweep did.

    :ivar repository: Links stated by the code repository's files, when a checkout exists.
    :ivar citations: Clause citations in code and tests that the model cannot store as links.
    :ivar guessed: One report per relation guessed; empty when no edition was in force.
    """

    repository: SyncReport | None
    citations: int
    guessed: tuple[GuessReport, ...]

    @property
    def proposed(self) -> int:
        """Guessed links stored as proposed."""
        return sum(len(report.proposed) for report in self.guessed)

    @property
    def review(self) -> int:
        """Guessed links put on the review list."""
        return sum(len(report.review) for report in self.guessed)

    @property
    def dropped(self) -> int:
        """Scored pairs that were not kept."""
        return sum(report.dropped for report in self.guessed)

    @property
    def guessed_share(self) -> float:
        """The guessed share of all links in use after the last guess."""
        return self.guessed[-1].guessed_share if self.guessed else 0.0

    @property
    def share_within_limit(self) -> bool:
        """True when the guessed share does not exceed its limit."""
        return all(report.share_within_limit for report in self.guessed)


class Application:
    """The assembled platform. Build one with :func:`build_application`.

    :param settings: Platform settings
    :param database: The platform database
    :param clock: Time source
    :param targets: Builds the source readers a sweep runs
    :param sleeper: Called with the seconds a rate-limited source asked to wait
    :param owns_database: Whether :meth:`close` disposes of the database
    :param raw_store: Where the sweep keeps the raw bytes; chosen by the mode when omitted
    :param route: The gateway route of the real mode readers, closed with the application
    """

    def __init__(
        self,
        settings: Settings,
        database: Database,
        clock: Clock,
        targets: TargetProvider,
        sleeper: Sleeper,
        *,
        owns_database: bool,
        raw_store: RawStore | None = None,
        route: RealRoute | None = None,
    ) -> None:
        self.settings = settings
        self.database = database
        self.clock = clock
        self.targets = targets
        self.search = SearchService(database, clock)
        if self.search.embedder is not None and settings.mode is Mode.REAL:
            # The only embedder there is hashes words: it ranks like keyword search and would be
            # recorded as a model version. The real route needs an embedding model first.
            raise ConfigurationError(
                "KP_SEARCH_VECTOR_ENABLED needs an embedding model; the hashing stand-in is not "
                "allowed with KP_MODE=real"
            )
        self._raw_store = raw_store
        self._sleeper = sleeper
        self._owns_database = owns_database
        self._route = route

    @property
    def raw_store(self) -> RawStore:
        """Where the sweep keeps the raw bytes; the mode's store, chosen on first use.

        :raises kp.errors.ConfigurationError: If real mode has no raw bucket
        """
        if self._raw_store is None:
            self._raw_store = choose_raw_store(self.settings)
        return self._raw_store

    def close(self) -> None:
        """Release the database when this application created it, and the gateway route."""
        if self._route is not None:
            self._route.close()
        if self._owns_database:
            self.database.dispose()

    # Sources -------------------------------------------------------------------------------

    def processor(self) -> PipelineProcessor:
        """The content processor of a sweep: parse, index passages, load stated links.

        :return: A new processor
        """
        return PipelineProcessor(
            self.settings.thresholds,
            self.clock,
            embedder=self.search.embedder,
            embedding_batch_size=self.search.embedding_batch_size,
        )

    def gate(self) -> ApprovalGate:
        """The approval gate configured by the settings.

        :return: The gate
        """
        return ApprovalGate(
            approved_label=self.settings.confluence_approved_label,
            document_types=frozenset(self.settings.document_types),
        )

    def sweep(self, sources: Sequence[SourceKind] = ()) -> SweepSummary:
        """Sweep the named sources, or every configured source.

        :param sources: Sources to sweep; empty means all
        :return: What the run did
        """
        self.database.ensure_schema(self.settings)
        sweeper = Sweeper(
            self.database,
            clock=self.clock,
            processor=self.processor(),
            raw_store=self.raw_store,
            sleeper=self._sleeper,
            gate=self.gate(),
            thresholds=self.settings.thresholds,
        )
        return sweeper.run(list(self.targets.targets(sources)))

    def sweep_runtime(self) -> SweepRuntime:
        """The runtime ``kp sweep`` needs, wired to this application.

        :return: The runtime, with the pipeline processor
        """
        return build_runtime(
            self.settings,
            self.targets,
            processor=self.processor(),
            raw_store=self.raw_store,
            database=self.database,
            clock=self.clock,
            sleeper=self._sleeper,
        )

    # Links and publication -----------------------------------------------------------------

    def after_sweep(self) -> AfterSweepReport:
        """Run the steps that need the whole picture: repository links, then guessed links.

        The code repository's files state which code a test verifies and which clause a schema
        field resolves to; register rows that no source ties to a clause are then scored against
        the rules in force. Both are idempotent.

        The code repository is the configured checkout when there is one (local mode looks in the
        data folder too). Without a checkout, in either mode, it is laid out from the code items
        the sweep stored, so real mode needs no folder.

        :return: What each step did
        """
        thresholds = self.settings.thresholds
        with self.database.transaction() as connection:
            loader = StatedLinkLoader(connection, thresholds=thresholds, clock=self.clock)
            synced: SyncReport | None = None
            citations = 0
            fields: list[ItemRef] = []
            with self._code_checkout(connection) as repository:
                if repository is not None:
                    scan, synced = loader.sync_repository(repository)
                    citations = len(scan.citations)
                    fields = sorted(scan.owned_targets, key=lambda ref: ref.key)
            try:
                guessed = LinkGuesser(connection, thresholds=thresholds, clock=self.clock).guess(
                    fields
                )
            except NoEditionInForceError:
                guessed = ()
        return AfterSweepReport(repository=synced, citations=citations, guessed=guessed)

    @contextmanager
    def _code_checkout(self, connection: Connection) -> Iterator[Path | None]:
        """The code repository as a folder: the configured checkout, else the swept files."""
        configured = self.settings.code_repo_path
        if configured is None and self.settings.mode is Mode.LOCAL:
            configured = self.settings.data_dir / _CODE_REPO_FOLDER
        if configured is not None and configured.is_dir():
            yield configured
            return
        with swept_code_checkout(connection, self.raw_store) as swept:
            yield swept

    def spec_source(self) -> MergedSpecSource | None:
        """Where the merged specs can be listed from, once something was published.

        :return: The local spec repository, or ``None`` when it does not exist
        """
        return open_spec_source(self.settings, self.clock)

    def merge_spec(self, story_key: str) -> MergeResult:
        """Merge the pull request of a story's spec in the local spec repository.

        Stands in for the reviewer who presses the merge button on the repository host; the
        next sweep then loads the merged file back as knowledge.

        :param story_key: The story whose spec to merge
        :return: The merge, with its date
        :raises kp.errors.ConfigurationError: If this machine's publisher cannot merge
        :raises kp.writeback.PublishError: If the story's branch has no open pull request
        :raises kp.writeback.InvalidStoryKeyError: If the story key is not valid
        """
        publisher = self.writers().publisher
        if not isinstance(publisher, SpecMerger):
            raise ConfigurationError("The spec publisher of this mode cannot merge a pull request")
        return publisher.merge(branch_for_story(require_story_key(story_key)))

    def publish_knowledge(self, run_id: str | None = None) -> PublicationResult:
        """Run the publication checks and switch to a new knowledge version if they pass.

        :param run_id: The build run the version belongs to; one is created when omitted
        :return: The attempt; a blocked version is kept for inspection and the old one serves
        """
        with self.database.transaction() as connection:
            publisher = KnowledgePublisher(
                connection, thresholds=self.settings.thresholds, clock=self.clock
            )
            return publisher.publish(run_id)

    def load_templates(self, folder: Path) -> int:
        """Load the governed templates of a folder (``*.md`` with front matter).

        :param folder: A folder of template files
        :return: The number of template files read
        :raises kp.errors.TemplateNotFoundError: If a file has no usable front matter
        """
        count = 0
        with self.database.transaction() as connection:
            repository = TemplateRepository(connection)
            for path in sorted(folder.glob("*.md")):
                repository.save(parse_template(path.read_text(encoding="utf-8")))
                count += 1
        return count

    # Agent tools ---------------------------------------------------------------------------

    def read_ports(self) -> ReadPorts:
        """The five ports of the read tools, backed by search, links, rules and templates.

        :return: The ports
        """
        return ReadPorts(
            search=SearchServicePort(self.search),
            links=StoreLinkPort(self.database, self.clock),
            rules=DatabaseRulePort(self.database),
            templates=DatabaseTemplatePort(self.database),
            coverage=LinkServiceCoveragePort(self.database, self.clock, self.settings.thresholds),
        )

    def identity_mapping(self) -> IdentityMapping:
        """The written mapping from user identity to allowed domains.

        :return: The mapping
        :raises kp.errors.ConfigurationError: If ``KP_IDENTITY_MAPPING_FILE`` is not set
        """
        path = self.settings.identity_mapping_file
        if path is None:
            raise ConfigurationError("KP_IDENTITY_MAPPING_FILE is required to serve agents")
        return IdentityMapping.from_file(path)

    def retrieval_observer(self) -> ToolObserver:
        """The observer that remembers what each session was shown by the read tools.

        :return: The observer
        """
        return RetrievalRecorder(self.database, self.clock)

    def read_server(self, directory: IdentityMapping | None = None) -> McpServer:
        """The read MCP server: search, links, template, rule as at, coverage.

        :param directory: Identity to domains; read from the settings when omitted
        :return: The server
        """
        return build_read_server(
            self.read_ports(),
            directory or self.identity_mapping(),
            DatabaseAuditSink(self.database),
            clock=self.clock,
            observer=self.retrieval_observer(),
        )

    def writers(self) -> Writers:
        """Where specs are published and Jira is updated, for the mode and the machine.

        :return: The publisher, the Jira updater and which publisher was chosen
        """
        return choose_writers(self.settings, self.clock)

    def write_tools(
        self,
        *,
        writers: Writers | None = None,
        retrievals: SessionRetrievals | None = None,
        record_calls: bool = False,
    ) -> WriteTools:
        """The write-back tools, citing against what the read tools showed each session.

        :param writers: The publisher and Jira updater; chosen by :meth:`writers` when omitted
        :param retrievals: What each session retrieved; the recorded retrievals of the read
            tools (shared through the database) when omitted
        :param record_calls: Record every call in the audit trail from the tools themselves.
            Leave off behind the write server, whose registry already records every call.
        :return: The tools
        """
        chosen = writers or self.writers()
        return WriteTools(
            publishing=SpecPublishingService(
                database=self.database,
                settings=self.settings,
                publisher=chosen.publisher,
                clock=self.clock,
            ),
            jira=JiraSyncService(
                database=self.database,
                settings=self.settings,
                jira=chosen.jira,
                sleep=self._sleeper,
            ),
            retrievals=retrievals or DatabaseSessionRetrievals(self.database),
            audit=WritebackAuditSink(self.database) if record_calls else None,
            clock=self.clock,
        )

    def write_port(self, *, writers: Writers | None = None) -> WriteToolPort:
        """The write tools as the write server's port.

        :param writers: The publisher and Jira updater; chosen by :meth:`writers` when omitted
        :return: The port
        """
        return WriteToolsPort(self.write_tools(writers=writers))

    def write_server(
        self, directory: IdentityMapping | None = None, *, writers: Writers | None = None
    ) -> McpServer:
        """The write MCP server: publish spec, update Jira.

        :param directory: Identity to domains; read from the settings when omitted
        :param writers: The publisher and Jira updater; chosen by :meth:`writers` when omitted
        :return: The server
        """
        return build_write_server(
            self.write_port(writers=writers),
            directory or self.identity_mapping(),
            DatabaseAuditSink(self.database),
            clock=self.clock,
        )

    def draft_runtime(self) -> DraftSpecRuntime:
        """The runtime of the reference drafting client (``kp draft-spec``).

        :return: A runtime whose write tools use the writers chosen for this machine
        """

        def tools(retrievals: InMemorySessionRetrievals) -> WriteTools:
            return self.write_tools(retrievals=retrievals, record_calls=True)

        return DraftSpecRuntime(
            database=self.database,
            settings=self.settings,
            tools_factory=tools,
            reference_domains=lambda connection: ItemDomains(connection).of_reference,
            clock=self.clock,
        )


def build_application(
    settings: Settings,
    *,
    clock: Clock | None = None,
    sleeper: Sleeper = time.sleep,
    database: Database | None = None,
    locations: StandInLocations | None = None,
    real_builders: Mapping[SourceKind, RealReaderBuilder] | None = None,
    raw_store: RawStore | None = None,
) -> Application:
    """Build the whole application from the settings.

    :param settings: Platform settings (``KP_*`` environment variables)
    :param clock: Time source; the system clock when omitted
    :param sleeper: Waits out a rate-limited source; ``time.sleep`` when omitted
    :param database: An existing database to use instead of building one from the settings;
        the caller then owns it
    :param locations: Overrides for the stand-in export folders (local mode)
    :param real_builders: Readers of the real route, consulted in real mode; the gateway-backed
        readers of :mod:`kp.adapters.real_route` when omitted
    :param raw_store: Where the sweep keeps raw bytes instead of the mode's own store (the raw
        bucket in real mode, a folder under the data directory otherwise)
    :return: The application; call :meth:`Application.close` when done
    """
    now = clock or SystemClock()
    route: RealRoute | None = None
    if real_builders is None and settings.mode is Mode.REAL:
        route = RealRoute(settings, now, sleep=sleeper)
        real_builders = real_reader_builders(route)
    return Application(
        settings,
        database or Database.from_settings(settings),
        now,
        SpecAwareTargets(
            FactoryTargetProvider(settings, locations=locations, real_builders=real_builders),
            settings,
            now,
        ),
        sleeper,
        owns_database=database is None,
        raw_store=raw_store,
        route=route,
    )


def serve_wiring() -> ServeWiring:
    """How ``kp serve-read`` and ``kp serve-write`` get their ports from the settings.

    One application is built per database and shared by the three parts of the wiring, so a
    server start does not assemble the platform three times.

    :return: The wiring for :func:`kp.mcp.add_parser`
    """
    built: dict[int, Application] = {}

    def application(settings: Settings, database: Database) -> Application:
        return built.setdefault(id(database), build_application(settings, database=database))

    return ServeWiring(
        read_ports=lambda settings, database: application(settings, database).read_ports(),
        write_port=lambda settings, database: application(settings, database).write_port(),
        read_observer=lambda settings, database: application(
            settings, database
        ).retrieval_observer(),
    )
