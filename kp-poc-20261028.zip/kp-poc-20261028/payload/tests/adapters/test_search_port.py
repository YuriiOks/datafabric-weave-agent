"""The search port: domains applied before ranking, hidden matches counted."""

from __future__ import annotations

from datetime import date

from kp.adapters.search_port import SearchServicePort
from world_support import World

QUESTION = "which currency may an inbound credit transfer use?"
DAY = date(2026, 11, 20)


def _port(world: World) -> SearchServicePort:
    return SearchServicePort(world.application.search)


def test_a_caller_with_the_domain_gets_the_clause_with_page_and_position(
    built_world: World,
) -> None:
    response = _port(built_world).search(
        QUESTION, domains=frozenset({"payments"}), as_at=DAY, limit=5
    )

    top = response.hits[0]
    assert top.reference == "2026.1:4.2.1"
    assert top.page == 4
    assert top.char_start is not None
    assert top.domain == "payments"


def test_a_caller_with_another_domain_sees_none_of_it_and_the_hidden_matches_are_counted(
    built_world: World,
) -> None:
    response = _port(built_world).search(QUESTION, domains=frozenset({"cards"}), as_at=DAY, limit=5)

    assert {hit.domain for hit in response.hits} <= {"cards"}
    assert response.filtered_out > 0


def test_a_caller_without_any_domain_gets_no_hits_but_the_count_of_what_was_hidden(
    built_world: World,
) -> None:
    response = _port(built_world).search(QUESTION, domains=frozenset(), as_at=DAY, limit=5)

    assert response.hits == ()
    assert response.filtered_out > 0
