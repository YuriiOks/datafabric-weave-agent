"""Natural keys of link endpoints.

Clause keys are the canonical clause reference (``2026.1:4.2.1``). The repository loaders
build the other keys from repository-relative paths:

* code: ``<path>::<symbol>``
* test: ``<path>::<name>``
* schema field: ``<path>#<property>``

A commit can qualify the path (``<path>@<revision>::<symbol>``). The *source path* of any of
these keys is the part before the first ``@``, ``::`` or ``#``.
"""

from __future__ import annotations

import re
from collections.abc import Collection

from kp.domain import ClauseRef, ItemRef, ItemType
from kp.errors import InvalidClauseRefError

_PATH_END = re.compile(r"@|::|#")


def clause_item(ref: ClauseRef) -> ItemRef:
    """Build the endpoint of a clause.

    :param ref: The clause reference
    :return: A clause item keyed by the canonical reference text
    """
    return ItemRef(item_type=ItemType.CLAUSE, key=ref.format())


def spec_item(spec_id: str) -> ItemRef:
    """Build the endpoint of a spec.

    :param spec_id: The spec identity (``spec-<story key in lower case>`` for a drafted one)
    :return: A spec item
    """
    return ItemRef(item_type=ItemType.SPEC, key=spec_id)


def _repository_key(path: str, symbol: str, revision: str | None, separator: str) -> str:
    qualified = path if revision is None else f"{path}@{revision}"
    return f"{qualified}{separator}{symbol}"


def code_item(path: str, symbol: str, revision: str | None = None) -> ItemRef:
    """Build the endpoint of a function or class in a repository file.

    :param path: Repository-relative file path
    :param symbol: Function, class or ``Class.method`` name
    :param revision: Optional commit that qualifies the path
    :return: A code item
    """
    return ItemRef(item_type=ItemType.CODE, key=_repository_key(path, symbol, revision, "::"))


def unit_test_item(path: str, name: str, revision: str | None = None) -> ItemRef:
    """Build the endpoint of a test function.

    :param path: Repository-relative file path
    :param name: Test function or ``Class.method`` name
    :param revision: Optional commit that qualifies the path
    :return: A test item
    """
    return ItemRef(item_type=ItemType.TEST, key=_repository_key(path, name, revision, "::"))


def schema_field_item(path: str, field: str, revision: str | None = None) -> ItemRef:
    """Build the endpoint of one property of a schema file.

    :param path: Repository-relative schema file path
    :param field: Property name
    :param revision: Optional commit that qualifies the path
    :return: A schema field item
    """
    return ItemRef(item_type=ItemType.SCHEMA_FIELD, key=_repository_key(path, field, revision, "#"))


def source_path_of(ref: ItemRef) -> str:
    """Return the repository path part of a code, test or schema-field key.

    :param ref: An endpoint built by one of the helpers above
    :return: The key up to the first ``@``, ``::`` or ``#``
    """
    return _PATH_END.split(ref.key, maxsplit=1)[0]


# An edition label (digits, letters, dots, dashes) then ``:`` or `` clause `` and a number.
# The number group is atomic so a longer or malformed number such as ``4.2.1a`` is rejected
# as a whole and never truncated to its parent clause.
_CLAUSE_REF_IN_TEXT = re.compile(
    r"(?<![\w.])(?P<edition>[A-Za-z0-9][A-Za-z0-9._-]*?)(?::|\s+clause\s+)"
    r"(?P<number>(?>(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))*))(?![\w])",
    re.IGNORECASE,
)


def find_clause_refs(text: str, editions: Collection[str] | None = None) -> list[ClauseRef]:
    """Find clause references written as ``2026.1:4.2.1`` or ``2026.1 clause 4.2.1`` in text.

    Only references whose edition label contains a digit are returned, so prose such as
    "see note:3" is not mistaken for a clause. Times and ratios ("10:30", "3:1") look like
    references too; pass the loaded edition labels to keep only references to an edition
    that exists.

    :param text: Free text such as a docstring, a register cell or a description
    :param editions: Loaded edition labels; when given, references to other editions are left out
    :return: The distinct references in order of first appearance
    """
    found: dict[str, ClauseRef] = {}
    for match in _CLAUSE_REF_IN_TEXT.finditer(text):
        edition = match["edition"]
        if not any(char.isdigit() for char in edition):
            continue
        try:
            ref = ClauseRef(edition.rstrip(".-_"), match["number"])
        except InvalidClauseRefError:
            continue
        if editions is not None and ref.edition not in editions:
            continue
        found.setdefault(ref.format(), ref)
    return list(found.values())


def split_clause_refs(
    text: str, editions: Collection[str] | None
) -> tuple[list[ClauseRef], list[ClauseRef]]:
    """Find clause references in text and split them by whether their edition is loaded.

    :param text: Free text such as a register cell or a schema annotation
    :param editions: Loaded edition labels; ``None`` treats every edition as known
    :return: The references to a known edition and the references to any other edition
    """
    known: list[ClauseRef] = []
    unknown: list[ClauseRef] = []
    for ref in find_clause_refs(text):
        (known if editions is None or ref.edition in editions else unknown).append(ref)
    return known, unknown
