"""The numbers the publication checks judge, measured from the link store and the catalog."""

from __future__ import annotations

from collections.abc import Sequence

from kp.domain import DomainModel, ItemRef, Relation
from kp.links import LinkStatistics
from kp.links.graph import LinkGraph, reaches_requirement_or_clause
from kp.publish.catalog import KIND_CLAUSE, KIND_STORY, CatalogItem


class Measurements(DomainModel):
    """Everything the checks need, measured once for one candidate knowledge version.

    ``previous_item_count`` is the size of the version now serving, or ``None`` when
    nothing has been published yet.
    """

    links: LinkStatistics
    item_count: int
    items_without_source: int
    linkable_items: int
    items_without_links: int
    clauses: int
    clauses_without_field_link: int
    stories_without_requirement_or_clause: tuple[str, ...]
    previous_item_count: int | None


def measure(
    items: Sequence[CatalogItem],
    graph: LinkGraph,
    statistics: LinkStatistics,
    previous_item_count: int | None,
) -> Measurements:
    """Measure a candidate version.

    :param items: What the version would publish
    :param graph: The links in use
    :param statistics: Counts over the open links
    :param previous_item_count: Size of the serving version, if any
    :return: The measurements
    """
    linked = graph.linked_items()
    linkable = [item.ref for item in items if item.ref is not None]
    clauses = [item.ref for item in items if item.kind == KIND_CLAUSE and item.ref is not None]
    stories = [item.ref for item in items if item.kind == KIND_STORY and item.ref is not None]
    return Measurements(
        links=statistics,
        item_count=len(items),
        items_without_source=sum(1 for item in items if not item.has_source),
        linkable_items=len(linkable),
        items_without_links=sum(1 for ref in linkable if ref not in linked),
        clauses=len(clauses),
        clauses_without_field_link=sum(1 for ref in clauses if not _resolves_to_field(graph, ref)),
        stories_without_requirement_or_clause=tuple(
            sorted(ref.key for ref in stories if not reaches_requirement_or_clause(graph, ref))
        ),
        previous_item_count=previous_item_count,
    )


def _resolves_to_field(graph: LinkGraph, clause: ItemRef) -> bool:
    return bool(graph.follow(clause, Relation.RESOLVES_TO, forward=True))
