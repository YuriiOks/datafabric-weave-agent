"""Regulatory editions, their clauses, and the single "as at" rule."""

from __future__ import annotations

from collections.abc import Iterable
from datetime import date
from typing import Annotated, Self

from pydantic import Field, model_validator

from kp.domain.base import DomainModel
from kp.domain.clause_ref import ClauseRef, edition_sort_key
from kp.domain.enums import EditionState, SourceKind


class Edition(DomainModel):
    """One edition of a regulatory document.

    Dates are inclusive from-dates: an edition superseded from 16 Nov no longer applies on
    16 Nov. Load time is never used; only these dates decide what was in force.
    """

    label: str
    effective_date: date
    superseded_from: date | None = None
    withdrawn_from: date | None = None
    title: str = ""
    source: SourceKind = SourceKind.REGULATORY_REPO
    item_id: str
    version: str

    def state_on(self, day: date) -> EditionState:
        """Return the state of this edition on ``day``.

        :param day: The date to evaluate
        :return: Not yet effective, current, superseded or withdrawn
        """
        if day < self.effective_date:
            return EditionState.NOT_YET_EFFECTIVE
        if self.withdrawn_from is not None and self.withdrawn_from <= day:
            return EditionState.WITHDRAWN
        if self.superseded_from is not None and self.superseded_from <= day:
            return EditionState.SUPERSEDED
        return EditionState.CURRENT

    def in_force_on(self, day: date) -> bool:
        """Tell whether this edition applies on ``day``.

        :param day: The date to evaluate
        :return: True when effective by then and neither superseded nor withdrawn by then
        """
        return self.state_on(day) is EditionState.CURRENT


def select_edition_as_at(editions: Iterable[Edition], as_at: date) -> Edition | None:
    """Select the edition in force on ``as_at``.

    The one "as at" semantic shared by search, links and tools: effective on or before the
    date, and not superseded or withdrawn by the date. If several qualify (a superseded-from
    date was not recorded), the latest effective date wins, then the newest label.

    :param editions: Candidate editions, in any order
    :param as_at: The date to read the rules at; callers pass ``clock.today()`` for "now"
    :return: The edition in force, or ``None`` when nothing was in force (callers decide
        whether that is an error; it is never silently replaced by another edition)
    """
    in_force = [edition for edition in editions if edition.in_force_on(as_at)]
    if not in_force:
        return None
    return max(in_force, key=lambda e: (e.effective_date, edition_sort_key(e.label)))


class Clause(DomainModel):
    """One numbered clause with its position in the source document.

    ``parent_ref`` is the enclosing clause (``4.2`` for ``4.2.1``). Split parts of a long
    clause are passages, not clauses; they carry this clause as their parent.
    """

    ref: ClauseRef
    title: str = ""
    page: Annotated[int, Field(ge=1)]
    char_start: Annotated[int, Field(ge=0)]
    char_end: Annotated[int, Field(ge=0)]
    text: str
    structure_score: Annotated[float, Field(ge=0, le=1)]
    parent_ref: ClauseRef | None = None

    @model_validator(mode="after")
    def _consistent(self) -> Self:
        if self.char_end < self.char_start:
            raise ValueError("char_end must not precede char_start")
        if self.parent_ref != self.ref.parent():
            raise ValueError("parent_ref must be the enclosing clause of ref")
        return self
