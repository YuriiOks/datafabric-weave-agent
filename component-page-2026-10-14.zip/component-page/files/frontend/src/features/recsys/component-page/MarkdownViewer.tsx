import { createElement, useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import { parseMarkdown, safeHref } from './markdown'
import type { AlertVariant, Block, FrontmatterEntry, Inline, TocEntry } from './markdown'
import {
  chipStyle,
  linkStyle,
  monoStyle,
  sectionCardStyle,
  sectionHeaderStyle,
  sectionLabelStyle,
} from './styles'

type Props = {
  /** The whole .md file, frontmatter included. */
  markdown: string
  /** Path of the file in its source, shown above the content. */
  path?: string | null | undefined
  /** Link to the file at its revision; opens in the same tab. */
  sourceUrl?: string | null | undefined
  /** Prefix for heading ids, so two viewers on one page never share an anchor. */
  idPrefix?: string | undefined
}

type Mode = 'rendered' | 'markdown'

/**
 * The full definition of a component: the .md rendered with its frontmatter as a card and an
 * "On this page" list, or the raw Markdown, with a toggle between the two.
 */
export function MarkdownViewer({ markdown, path, sourceUrl, idPrefix = 'md' }: Props) {
  const [mode, setMode] = useState<Mode>('rendered')
  const parsed = useMemo(() => parseMarkdown(markdown), [markdown])
  const href = sourceUrl ? safeHref(sourceUrl) : null

  return (
    <section style={sectionCardStyle} aria-label="Definition">
      <div style={sectionHeaderStyle}>
        <h2 style={sectionLabelStyle}>Definition</h2>
        {href && (
          <a href={href} style={linkStyle}>
            Open source
            <ExternalIcon />
          </a>
        )}
      </div>
      <div style={toolbarStyle}>
        <span style={{ ...monoStyle, ...pathStyle }} title={path ?? undefined}>
          {path ?? ''}
        </span>
        <div role="group" aria-label="Definition view" style={toggleStyle}>
          <ToggleButton active={mode === 'rendered'} onClick={() => setMode('rendered')}>
            Rendered
          </ToggleButton>
          <ToggleButton active={mode === 'markdown'} onClick={() => setMode('markdown')}>
            Markdown
          </ToggleButton>
        </div>
      </div>
      <div style={{ padding: 'var(--space-4)' }}>
        {mode === 'markdown' ? (
          <pre style={rawStyle} aria-label="Markdown source">
            {markdown}
          </pre>
        ) : (
          <>
            {parsed.frontmatter.length > 0 && <FrontmatterCard entries={parsed.frontmatter} />}
            {parsed.toc.length > 1 && <OnThisPage toc={parsed.toc} idPrefix={idPrefix} />}
            <div style={bodyStyle}>{renderBlocks(parsed.blocks, idPrefix, 'b')}</div>
          </>
        )}
      </div>
    </section>
  )
}

function ToggleButton({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: ReactNode
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      style={{
        ...toggleButtonStyle,
        background: active ? 'var(--color-surface)' : 'transparent',
        color: active ? 'var(--color-primary)' : 'var(--color-text-secondary)',
        boxShadow: active ? '0 1px 2px rgba(0, 0, 0, 0.08)' : 'none',
      }}
    >
      {children}
    </button>
  )
}

function FrontmatterCard({ entries }: { entries: FrontmatterEntry[] }) {
  return (
    <div style={frontmatterStyle}>
      <div style={{ ...sectionLabelStyle, padding: 'var(--space-3) var(--space-4) var(--space-2)' }}>
        Frontmatter
      </div>
      <dl style={{ margin: 0 }}>
        {entries.map((entry) => (
          <div key={entry.key} style={frontmatterRowStyle}>
            <dt style={{ ...monoStyle, color: 'var(--color-primary)' }}>{entry.key}</dt>
            <dd style={{ margin: 0, minWidth: 0, overflowWrap: 'anywhere' }}>
              {entry.items
                ? entry.items.map((item) => (
                    <span key={item} style={chipStyle}>
                      {item}
                    </span>
                  ))
                : entry.value}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  )
}

function OnThisPage({ toc, idPrefix }: { toc: TocEntry[]; idPrefix: string }) {
  const [open, setOpen] = useState(true)
  return (
    <nav aria-label="On this page" style={tocStyle}>
      <button type="button" aria-expanded={open} onClick={() => setOpen(!open)} style={tocToggleStyle}>
        <span aria-hidden="true" style={{ display: 'inline-block', width: 10 }}>
          {open ? '\u25be' : '\u25b8'}
        </span>
        On this page
      </button>
      {open && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--space-1) var(--space-4)' }}>
          {toc.map((entry) => (
            <a
              key={entry.slug}
              href={'#' + idPrefix + '-' + entry.slug}
              style={{ ...linkStyle, paddingLeft: entry.level === 3 ? 'var(--space-3)' : 0 }}
              onClick={(event) => {
                event.preventDefault()
                document
                  .getElementById(idPrefix + '-' + entry.slug)
                  ?.scrollIntoView({ behavior: 'smooth', block: 'start' })
              }}
            >
              {entry.text}
            </a>
          ))}
        </div>
      )}
    </nav>
  )
}

function CodeBlock({ lang, text }: { lang: string | null; text: string }) {
  const [state, setState] = useState<'idle' | 'copied' | 'failed'>('idle')
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current)
    },
    [],
  )

  const copy = async () => {
    let next: 'copied' | 'failed' = 'failed'
    try {
      await navigator.clipboard.writeText(text)
      next = 'copied'
    } catch {
      next = 'failed'
    }
    setState(next)
    if (timer.current) clearTimeout(timer.current)
    timer.current = setTimeout(() => setState('idle'), 1500)
  }

  const label = state === 'copied' ? 'Copied' : state === 'failed' ? 'Select to copy' : 'Copy'
  return (
    <div style={codeFrameStyle}>
      <div style={codeHeaderStyle}>
        <span style={{ ...monoStyle, fontSize: '0.6875rem', textTransform: 'uppercase' }}>
          {lang ?? 'text'}
        </span>
        <button type="button" onClick={() => void copy()} style={copyButtonStyle} aria-live="polite">
          {label}
        </button>
      </div>
      <pre style={codeStyle}>
        <code>{text}</code>
      </pre>
    </div>
  )
}

const ALERTS: Record<AlertVariant, { label: string; colour: string; tint: string }> = {
  note: { label: 'Note', colour: '#1d5fa8', tint: 'rgba(29, 95, 168, 0.06)' },
  tip: { label: 'Tip', colour: '#1f7a5a', tint: 'rgba(31, 122, 90, 0.06)' },
  important: { label: 'Important', colour: '#db0011', tint: 'rgba(219, 0, 17, 0.05)' },
  warning: { label: 'Warning', colour: '#ad6800', tint: 'rgba(250, 173, 20, 0.1)' },
  caution: { label: 'Caution', colour: '#a8000b', tint: 'rgba(168, 0, 11, 0.06)' },
}

function renderBlocks(blocks: Block[], idPrefix: string, keyPrefix: string): ReactNode[] {
  return blocks.map((block, index) => {
    const key = keyPrefix + '-' + String(index)
    switch (block.kind) {
      case 'heading':
        return createElement(
          'h' + String(Math.min(6, Math.max(1, block.level))),
          {
            key,
            id: idPrefix + '-' + block.slug,
            style: headingStyle(block.level, index === 0),
          },
          renderInline(block.inline, key),
        )
      case 'paragraph':
        return (
          <p key={key} style={paragraphStyle}>
            {renderInline(block.inline, key)}
          </p>
        )
      case 'list': {
        const items = block.items.map((item, itemIndex) => (
          <li key={key + '-' + String(itemIndex)} style={{ marginBottom: 'var(--space-1)' }}>
            {renderInline(item.inline, key + '-' + String(itemIndex))}
            {item.children.length > 0 && renderBlocks(item.children, idPrefix, key + '-' + String(itemIndex))}
          </li>
        ))
        return block.ordered ? (
          <ol key={key} start={block.start} style={listStyle}>
            {items}
          </ol>
        ) : (
          <ul key={key} style={listStyle}>
            {items}
          </ul>
        )
      }
      case 'code':
        return <CodeBlock key={key} lang={block.lang} text={block.text} />
      case 'alert': {
        const alert = ALERTS[block.variant]
        return (
          <div
            key={key}
            role="note"
            style={{ ...alertStyle, borderColor: alert.colour, background: alert.tint }}
          >
            <div style={{ fontWeight: 600, color: alert.colour, marginBottom: 'var(--space-1)' }}>
              {alert.label}
            </div>
            {renderBlocks(block.blocks, idPrefix, key)}
          </div>
        )
      }
      case 'quote':
        return (
          <blockquote key={key} style={quoteStyle}>
            {renderBlocks(block.blocks, idPrefix, key)}
          </blockquote>
        )
      case 'table':
        return (
          <div key={key} style={{ overflowX: 'auto', margin: 'var(--space-3) 0' }}>
            <table style={tableStyle}>
              <thead>
                <tr>
                  {block.header.map((cell, cellIndex) => (
                    <th
                      key={String(cellIndex)}
                      style={{ ...cellStyle, fontWeight: 600, textAlign: block.align[cellIndex] ?? 'left' }}
                    >
                      {renderInline(cell, key + '-h' + String(cellIndex))}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {block.rows.map((row, rowIndex) => (
                  <tr key={String(rowIndex)}>
                    {row.map((cell, cellIndex) => (
                      <td
                        key={String(cellIndex)}
                        style={{ ...cellStyle, textAlign: block.align[cellIndex] ?? 'left' }}
                      >
                        {renderInline(cell, key + '-' + String(rowIndex) + '-' + String(cellIndex))}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      case 'rule':
        return <hr key={key} style={ruleStyle} />
      default:
        return null
    }
  })
}

function renderInline(nodes: Inline[], keyPrefix: string): ReactNode[] {
  return nodes.map((node, index) => {
    const key = keyPrefix + '-i' + String(index)
    switch (node.kind) {
      case 'text':
        return node.text
      case 'code':
        return (
          <code key={key} style={inlineCodeStyle}>
            {node.text}
          </code>
        )
      case 'strong':
        return <strong key={key}>{renderInline(node.children, key)}</strong>
      case 'em':
        return <em key={key}>{renderInline(node.children, key)}</em>
      case 'link':
        return node.href ? (
          <a key={key} href={node.href} style={{ color: 'var(--color-link, #1677ff)' }}>
            {renderInline(node.children, key)}
          </a>
        ) : (
          <span key={key}>{renderInline(node.children, key)}</span>
        )
      default:
        return null
    }
  })
}

function ExternalIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <path d="M6 3H3v10h10v-3M9 3h4v4M13 3 7.5 8.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function headingStyle(level: number, first: boolean): CSSProperties {
  const size = level <= 1 ? '1.25rem' : level === 2 ? '1.0625rem' : level === 3 ? '0.9375rem' : '0.875rem'
  return {
    fontSize: size,
    fontWeight: 600,
    color: 'var(--color-text-primary)',
    margin: first ? '0 0 var(--space-2)' : 'var(--space-5) 0 var(--space-2)',
    paddingTop: level === 2 && !first ? 'var(--space-4)' : 0,
    borderTop: level === 2 && !first ? '1px solid var(--color-border-light)' : 'none',
    scrollMarginTop: 80,
    lineHeight: 1.35,
  }
}

const toolbarStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 'var(--space-3)',
  flexWrap: 'wrap',
  padding: 'var(--space-3) var(--space-4)',
  borderBottom: '1px solid var(--color-border-light)',
}

const pathStyle: CSSProperties = {
  color: 'var(--color-text-secondary)',
  minWidth: 0,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  flex: '1 1 160px',
}

const toggleStyle: CSSProperties = {
  display: 'inline-flex',
  padding: 3,
  gap: 2,
  borderRadius: 'var(--radius-full)',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.05))',
  flexShrink: 0,
}

const toggleButtonStyle: CSSProperties = {
  border: 'none',
  borderRadius: 'var(--radius-full)',
  padding: '4px 14px',
  fontSize: 'var(--text-sm)',
  fontFamily: 'inherit',
  cursor: 'pointer',
}

const rawStyle: CSSProperties = {
  ...monoStyle,
  margin: 0,
  padding: 'var(--space-4)',
  whiteSpace: 'pre',
  overflowX: 'auto',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.03))',
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-md)',
  lineHeight: 1.55,
}

const frontmatterStyle: CSSProperties = {
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-md)',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.015))',
  marginBottom: 'var(--space-3)',
}

const frontmatterRowStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'minmax(90px, 22%) minmax(0, 1fr)',
  gap: 'var(--space-3)',
  padding: 'var(--space-2) var(--space-4)',
  borderTop: '1px solid var(--color-border-light)',
  fontSize: 'var(--text-sm)',
  lineHeight: 1.5,
}

const tocStyle: CSSProperties = {
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-2) var(--space-4) var(--space-3)',
  marginBottom: 'var(--space-4)',
}

const tocToggleStyle: CSSProperties = {
  ...sectionLabelStyle,
  border: 'none',
  background: 'transparent',
  padding: 'var(--space-1) 0',
  marginBottom: 'var(--space-1)',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  gap: 4,
  fontFamily: 'inherit',
}

const bodyStyle: CSSProperties = {
  fontSize: 'var(--text-sm)',
  lineHeight: 1.6,
  color: 'var(--color-text-primary)',
  minWidth: 0,
}

const paragraphStyle: CSSProperties = { margin: '0 0 var(--space-3)' }

const listStyle: CSSProperties = { margin: '0 0 var(--space-3)', paddingLeft: 'var(--space-5)' }

const inlineCodeStyle: CSSProperties = {
  ...monoStyle,
  fontSize: '0.75rem',
  padding: '1px 6px',
  borderRadius: 'var(--radius-sm)',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.05))',
}

const codeFrameStyle: CSSProperties = {
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-md)',
  margin: '0 0 var(--space-3)',
  overflow: 'hidden',
}

const codeHeaderStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: 'var(--space-1) var(--space-2) var(--space-1) var(--space-3)',
  borderBottom: '1px solid var(--color-border-light)',
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.03))',
  color: 'var(--color-text-secondary)',
}

const copyButtonStyle: CSSProperties = {
  border: '1px solid var(--color-border-light)',
  background: 'var(--color-surface)',
  borderRadius: 'var(--radius-sm)',
  padding: '2px 10px',
  fontSize: '0.75rem',
  fontFamily: 'inherit',
  cursor: 'pointer',
  color: 'var(--color-text-primary)',
}

const codeStyle: CSSProperties = {
  ...monoStyle,
  margin: 0,
  padding: 'var(--space-3)',
  overflowX: 'auto',
  whiteSpace: 'pre',
  lineHeight: 1.55,
  background: 'var(--color-surface-secondary, rgba(0, 0, 0, 0.02))',
}

const alertStyle: CSSProperties = {
  borderLeft: '3px solid',
  borderRadius: 'var(--radius-md)',
  padding: 'var(--space-3) var(--space-4)',
  margin: '0 0 var(--space-3)',
}

const quoteStyle: CSSProperties = {
  margin: '0 0 var(--space-3)',
  padding: '0 var(--space-4)',
  borderLeft: '3px solid var(--color-border)',
  color: 'var(--color-text-secondary)',
}

const tableStyle: CSSProperties = {
  borderCollapse: 'collapse',
  width: '100%',
  fontSize: 'var(--text-sm)',
}

const cellStyle: CSSProperties = {
  border: '1px solid var(--color-border-light)',
  padding: 'var(--space-2) var(--space-3)',
  verticalAlign: 'top',
}

const ruleStyle: CSSProperties = {
  border: 'none',
  borderTop: '1px solid var(--color-border-light)',
  margin: 'var(--space-4) 0',
}
