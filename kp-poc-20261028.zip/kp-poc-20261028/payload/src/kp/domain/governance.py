"""Review items, publication checks, citations and the audit record of tool calls."""

from __future__ import annotations

from datetime import date
from typing import Annotated

from pydantic import AwareDatetime, Field, JsonValue

from kp.domain.base import DomainModel
from kp.domain.enums import (
    CheckSeverity,
    KnowledgeVersionState,
    ReviewKind,
    ReviewState,
    SourceKind,
)


class ReviewItem(DomainModel):
    """A question for a person: a missing detail, header candidates, a low structure score.

    :ivar missing_details: Names of absent required details (see ``DETAIL_NAMES``).
    :ivar candidates: Options offered to the reviewer, e.g. candidate header row numbers.
    """

    review_id: str
    kind: ReviewKind
    state: ReviewState = ReviewState.OPEN
    source: SourceKind
    item_id: str
    version: str | None = None
    detail: str = ""
    missing_details: tuple[str, ...] = ()
    content_owner: str | None = None
    candidates: tuple[str, ...] = ()
    run_id: str
    created_at: AwareDatetime
    resolved_at: AwareDatetime | None = None


class CheckResult(DomainModel):
    """Outcome of one publication check. Only blocking failures stop publication."""

    name: str
    severity: CheckSeverity
    passed: bool
    value: float | None = None
    threshold: float | None = None
    detail: str = ""


class KnowledgeVersion(DomainModel):
    """A staged, checked and possibly published snapshot of the knowledge base.

    Publication is one switch. A failed version is kept for inspection and the previous
    published version keeps serving until ``retained_until`` after its replacement.
    """

    version_id: str
    run_id: str
    state: KnowledgeVersionState = KnowledgeVersionState.STAGED
    checks: tuple[CheckResult, ...] = ()
    item_count: Annotated[int, Field(ge=0)] = 0
    created_at: AwareDatetime
    published_at: AwareDatetime | None = None
    retained_until: date | None = None

    def blocking_failures(self) -> tuple[CheckResult, ...]:
        """List the blocking checks that failed.

        :return: The failed blocking checks; empty means the version may be published
        """
        return tuple(
            check
            for check in self.checks
            if check.severity is CheckSeverity.BLOCKING and not check.passed
        )


class Citation(DomainModel):
    """One statement of a drafted spec and what it cites.

    ``reference`` is ``None`` for an uncited statement. Citation rate is the share of rule
    statements that are cited and valid.
    """

    citation_id: str
    spec_id: str
    statement_index: Annotated[int, Field(ge=0)]
    statement: str
    is_rule_statement: bool
    reference: str | None = None
    resolved: bool = False
    retrieved_in_session: bool = False

    @property
    def is_valid(self) -> bool:
        """True when cited, resolving to an existing clause or row, and retrieved this session."""
        return self.reference is not None and self.resolved and self.retrieved_in_session


class ToolCallRecord(DomainModel):
    """Audit record of one agent tool call, refusals included.

    Shares ``call_id``, ``request_digest``, ``latency_ms`` and ``called_at`` with the
    connectivity call record. ``request`` holds the agent's arguments (the audited fact);
    it is never written to logs. ``spec_id`` lets all calls behind a spec be listed.
    """

    call_id: str
    session_id: str
    caller: str
    agent: str
    tool: str
    request: dict[str, JsonValue]
    request_digest: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    domains_applied: tuple[str, ...] = ()
    items_returned: Annotated[int, Field(ge=0)] = 0
    filtered_count: Annotated[int, Field(ge=0)] = 0
    latency_ms: Annotated[float, Field(ge=0)]
    called_at: AwareDatetime
    refused: bool = False
    refusal_reason: str | None = None
    error_class: str | None = None
    spec_id: str | None = None
