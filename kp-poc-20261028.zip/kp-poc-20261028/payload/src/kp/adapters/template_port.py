"""Seam: the read tools' template port, backed by the governed template table."""

from __future__ import annotations

from kp.domain import Template
from kp.errors import TemplateNotFoundError
from kp.store import Database
from kp.writeback.store import TemplateRepository


class DatabaseTemplatePort:
    """Governed templates for the agent tools. Absence is reported, never replaced.

    :param database: The platform database
    """

    def __init__(self, database: Database) -> None:
        self._database = database

    def get(self, spec_type: str, version: str | None = None) -> Template | None:
        """Fetch a governed template.

        :param spec_type: The kind of spec the template is for
        :param version: A specific version, or ``None`` for the newest
        :return: The template, or ``None`` when none is governed for the type or version
        """
        with self._database.transaction() as connection:
            repository = TemplateRepository(connection)
            try:
                latest = repository.latest(spec_type)
                return latest if version is None else repository.get(latest.template_id, version)
            except TemplateNotFoundError:
                return None
