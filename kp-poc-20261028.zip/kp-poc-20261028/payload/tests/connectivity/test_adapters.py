"""US-25: the three source adapters, their version tokens, and R-02 (prose instead of fields)."""

from __future__ import annotations

import pytest
from sqlalchemy import func, select

from connectivity.support import Stack
from kp.connectivity import (
    ConfluenceAdapter,
    FidelityError,
    GitHubAdapter,
    JiraAdapter,
    object_key,
)
from kp.connectivity.digest import canonical_json, sha256_hex
from kp.connectivity.models import SampleItem
from kp.connectivity.stand_in_content import git_blob_sha
from kp.domain import ItemKey, SourceKind
from kp.errors import SourceItemNotFoundError
from kp.sources.base import SourceReader
from kp.store.schema import mcp_call


def _item(stack: Stack, item_id: str) -> SampleItem:
    return next(item for item in stack.samples.items if item.item_id == item_id)


def _adapters(stack: Stack) -> dict[SourceKind, ConfluenceAdapter | JiraAdapter | GitHubAdapter]:
    client = stack.client_for()
    return {
        SourceKind.CONFLUENCE: ConfluenceAdapter(
            client,
            stack.routes[SourceKind.CONFLUENCE],
            stack.samples.for_source(SourceKind.CONFLUENCE),
        ),
        SourceKind.JIRA: JiraAdapter(
            client, stack.routes[SourceKind.JIRA], stack.samples.for_source(SourceKind.JIRA)
        ),
        SourceKind.GITHUB: GitHubAdapter(
            client, stack.routes[SourceKind.GITHUB], stack.samples.for_source(SourceKind.GITHUB)
        ),
    }


def test_us25_confluence_version_is_the_page_version_number(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.CONFLUENCE]
    before = adapter.fetch_current(_item(stack, "conf-headings"))
    stack.fake.edit_page("7001", "<p>new</p>")
    after = adapter.fetch_current(_item(stack, "conf-headings"))

    assert before.key.version == "1"
    assert after.key.version == "2"
    assert after.content == b"<p>new</p>"
    assert before.metadata.title == "Payment operations overview"
    assert before.metadata.modified_at is not None
    assert before.metadata.media_type == "text/html"


def test_us25_confluence_attachment_returns_the_exact_bytes(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.CONFLUENCE]

    fetched = adapter.fetch_current(_item(stack, "conf-pdf"))

    assert fetched.content.startswith(b"%PDF-")
    assert fetched.metadata.attributes == {"attachment_parent": "7003"}
    assert fetched.key.version == "1"


def test_us25_jira_version_is_a_hash_of_the_semantic_fields(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.JIRA]
    item = _item(stack, "jira-comments")
    first = adapter.fetch_current(item)

    assert first.key.version == sha256_hex(first.content)
    assert len(first.key.version) == 64

    stack.fake.edit_issue("SYN-102", updated="2026-11-02T10:00:00+00:00")
    assert adapter.fetch_current(item).key.version == first.key.version

    stack.fake.edit_issue("SYN-102", summary="A different summary")
    changed = adapter.fetch_current(item)
    assert changed.key.version != first.key.version
    assert changed.metadata.title == "A different summary"


def test_us25_jira_comments_and_links_are_part_of_the_meaning(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.JIRA]
    item = _item(stack, "jira-comments")
    first = adapter.fetch_current(item)

    stack.fake.edit_issue(
        "SYN-102", comment={"comments": [{"id": "c1", "body": "A new comment.", "author": "x"}]}
    )

    assert adapter.fetch_current(item).key.version != first.key.version
    assert b"Agreed with the business analyst." in first.content


def test_us25_jira_attachment_version_is_the_content_hash(stack: Stack) -> None:
    fetched = _adapters(stack)[SourceKind.JIRA].fetch_current(_item(stack, "jira-word"))

    assert fetched.key.version == sha256_hex(fetched.content)
    assert fetched.metadata.title == "procedure.docx"
    assert fetched.metadata.attributes == {"attachment_parent": "SYN-103"}


def test_us25_github_version_is_the_blob_sha(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.GITHUB]

    fetched = adapter.fetch_current(_item(stack, "gh-markdown"))

    assert fetched.key.version == git_blob_sha(fetched.content)
    assert fetched.metadata.native_id == "docs/overview.md"
    assert fetched.metadata.title == "overview.md"
    assert fetched.metadata.attributes == {"commit": "0123456789abcdef0123456789abcdef01234567"}


def test_us25_binary_files_arrive_byte_for_byte(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.GITHUB]

    for item_id in ("gh-word", "gh-excel"):
        fetched = adapter.fetch_current(_item(stack, item_id))
        assert fetched.content.startswith(b"PK")
        assert fetched.key.version == git_blob_sha(fetched.content)


@pytest.mark.parametrize(
    ("source", "item_id"),
    [
        (SourceKind.CONFLUENCE, "conf-headings"),
        (SourceKind.JIRA, "jira-description"),
        (SourceKind.GITHUB, "gh-markdown"),
    ],
)
def test_us25_prose_instead_of_an_object_is_a_fidelity_error(
    stack: Stack, source: SourceKind, item_id: str
) -> None:
    stack.fake.prose_namespaces = {"confluence", "jira", "github"}

    with pytest.raises(FidelityError) as caught:
        _adapters(stack)[source].fetch_current(_item(stack, item_id))

    assert caught.value.item_id == item_id
    assert "prose" in caught.value.reason


def test_us25_an_object_that_lost_the_version_field_is_a_fidelity_error(stack: Stack) -> None:
    page = stack.fake.data.pages["7001"]
    del page["version"]

    with pytest.raises(FidelityError, match=r"version\.number"):
        _adapters(stack)[SourceKind.CONFLUENCE].fetch_current(_item(stack, "conf-headings"))


def test_us25_a_summary_in_place_of_the_issue_fields_is_a_fidelity_error(stack: Stack) -> None:
    stack.fake.data.issues["SYN-101"] = {"key": "SYN-101", "summary_text": "A short summary."}

    with pytest.raises(FidelityError, match="fields"):
        _adapters(stack)[SourceKind.JIRA].fetch_current(_item(stack, "jira-description"))


def test_us25_content_that_is_not_base64_is_a_fidelity_error(stack: Stack) -> None:
    for (_, path, _), payload in stack.fake.data.files.items():
        if path == "data/limits.xlsx":
            payload["encoding"] = "utf-8"

    with pytest.raises(FidelityError, match="base64"):
        _adapters(stack)[SourceKind.GITHUB].fetch_current(_item(stack, "gh-excel"))


def test_us25_a_missing_object_is_reported_as_not_found(stack: Stack) -> None:
    del stack.fake.data.issues["SYN-101"]

    with pytest.raises(SourceItemNotFoundError):
        _adapters(stack)[SourceKind.JIRA].fetch_current(_item(stack, "jira-description"))


def test_us25_adapters_satisfy_the_source_reader_contract(stack: Stack) -> None:
    for kind, adapter in _adapters(stack).items():
        assert isinstance(adapter, SourceReader)
        assert adapter.kind is kind
        batch = adapter.list_changed(None)
        assert batch.exhausted
        assert len(batch.items) == 3
        assert {changed.key.source for changed in batch.items} == {kind}


def test_us25_fetch_by_key_succeeds_only_while_that_version_is_current(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.CONFLUENCE]
    current = adapter.fetch_current(_item(stack, "conf-headings")).key

    assert adapter.fetch(current).key == current
    stack.fake.edit_page("7001", "<p>moved on</p>")
    with pytest.raises(SourceItemNotFoundError):
        adapter.fetch(current)
    with pytest.raises(SourceItemNotFoundError):
        adapter.fetch(ItemKey(source=SourceKind.CONFLUENCE, item_id="nope", version="1"))


def test_us25_an_adapter_refuses_an_item_of_another_source(stack: Stack) -> None:
    with pytest.raises(ValueError, match="belongs to jira"):
        _adapters(stack)[SourceKind.CONFLUENCE].fetch_current(_item(stack, "jira-description"))


def test_us25_object_keys_are_source_item_version(stack: Stack) -> None:
    fetched = _adapters(stack)[SourceKind.CONFLUENCE].fetch_current(_item(stack, "conf-table"))

    assert object_key("confluence", "conf-table", fetched.key.version) == "confluence/conf-table/1"
    assert canonical_json({"b": 1, "a": 2}) == b'{"a":2,"b":1}'


def _set_attachment_content(stack: Stack, namespace: str, content: str) -> None:
    attachments = (
        stack.fake.data.page_attachments
        if namespace == "confluence"
        else stack.fake.data.issue_attachments
    )
    for payload in attachments.values():
        payload["content_base64"] = content


@pytest.mark.parametrize(
    ("source", "item_id", "namespace"),
    [
        (SourceKind.CONFLUENCE, "conf-pdf", "confluence"),
        (SourceKind.JIRA, "jira-word", "jira"),
    ],
)
@pytest.mark.parametrize("content", ["!!!not base64!!!", "This looks like prose, not bytes."])
def test_us25_attachment_content_outside_the_base64_alphabet_is_a_fidelity_error(
    stack: Stack, source: SourceKind, item_id: str, namespace: str, content: str
) -> None:
    _set_attachment_content(stack, namespace, content)

    with pytest.raises(FidelityError, match="not base64"):
        _adapters(stack)[source].fetch_current(_item(stack, item_id))


@pytest.mark.parametrize(
    ("source", "item_id", "namespace"),
    [
        (SourceKind.CONFLUENCE, "conf-pdf", "confluence"),
        (SourceKind.JIRA, "jira-word", "jira"),
    ],
)
def test_us25_an_empty_attachment_payload_is_a_fidelity_error(
    stack: Stack, source: SourceKind, item_id: str, namespace: str
) -> None:
    _set_attachment_content(stack, namespace, "")

    with pytest.raises(FidelityError, match="empty"):
        _adapters(stack)[source].fetch_current(_item(stack, item_id))


def test_us25_base64_wrapped_over_several_lines_still_decodes(stack: Stack) -> None:
    adapter = _adapters(stack)[SourceKind.GITHUB]
    expected = adapter.fetch_current(_item(stack, "gh-word")).content
    for (_, path, _), payload in stack.fake.data.files.items():
        if path.endswith(".docx"):
            encoded = str(payload["content"])
            payload["content"] = "\n".join(encoded[i : i + 60] for i in range(0, len(encoded), 60))

    assert adapter.fetch_current(_item(stack, "gh-word")).content == expected


def test_us25_adapters_can_be_used_by_a_sweep_outside_a_connectivity_run(stack: Stack) -> None:
    adapter = JiraAdapter(
        stack.client, stack.routes[SourceKind.JIRA], stack.samples.for_source(SourceKind.JIRA)
    )

    batch = adapter.list_changed(None)
    fetched = adapter.fetch(batch.items[0].key)

    assert len(batch.items) == 3
    assert fetched.key == batch.items[0].key
    with stack.database.transaction() as connection:
        assert connection.execute(select(func.count()).select_from(mcp_call)).scalar_one() == 0
