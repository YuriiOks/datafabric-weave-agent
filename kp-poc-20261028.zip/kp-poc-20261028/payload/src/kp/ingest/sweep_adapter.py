"""Adapter that lets the sweep call the ingest processor.

The sweep defines its own content-processor port (``fingerprint`` and
``process(connection, version, content)``) and never imports this package. This module
implements that shape structurally, so the integrator can pass :class:`SweepContentProcessor`
wherever the sweep wants a processor, without an import in either direction.
"""

from __future__ import annotations

import hashlib
import json
from typing import Final

from sqlalchemy import Connection

from kp.domain import SourceItemVersion, SourceKind
from kp.ingest.errors import StoryParseError
from kp.ingest.processor import ContentProcessor
from kp.ingest.stories import parse_story_export
from kp.sources.base import FetchedItem, ItemMetadata

_JSON: Final = "application/json"


class SweepContentProcessor:
    """The sweep's processor port, backed by an ingest processor.

    :param processor: The ingest processor that stores clauses, requirements and stories
    """

    def __init__(self, processor: ContentProcessor) -> None:
        self._processor = processor

    def fingerprint(self, version: SourceItemVersion, content: bytes) -> str | None:
        """Hash the parts of a tracker export whose change means rework (US-05).

        The hash covers every story's own fingerprint, which ignores the status, so an export
        in which stories only moved on the board has the same fingerprint as the one before.

        :param version: The version being considered
        :param content: Its raw bytes
        :return: A hash for a tracker JSON export; ``None`` for anything else and for content
            that cannot be read (processing then reports the failure)
        """
        media_type = version.media_type.split(";")[0].strip().casefold()
        if version.source is not SourceKind.JIRA or media_type != _JSON:
            return None
        try:
            stories = parse_story_export(content, default_version=version.version)
        except StoryParseError:
            return None
        pairs = sorted((story.story_key, story.fingerprint()) for story in stories)
        return hashlib.sha256(json.dumps(pairs).encode("ascii")).hexdigest()

    def process(self, connection: Connection, version: SourceItemVersion, content: bytes) -> None:
        """Process one admitted version inside the sweep's page transaction.

        :param connection: The page's open connection
        :param version: The admitted version
        :param content: Its raw bytes
        :raises kp.ingest.errors.IngestError: If the content is unreadable or conflicts with
            what is stored
        """
        fetched = FetchedItem(
            key=version.key,
            content=content,
            metadata=ItemMetadata(
                native_id=version.native_id, media_type=version.media_type, title=version.title
            ),
        )
        self._processor.process(version, fetched, connection)
