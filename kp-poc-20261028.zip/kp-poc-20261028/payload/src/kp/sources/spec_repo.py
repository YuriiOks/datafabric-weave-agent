"""Spec repository reader: the merged spec files of the repository that receives spec pull requests.

A spec drafted by the platform reaches this repository as a pull request; when a person merges
it, the file is knowledge like any other item and is loaded back (US-23). This reader lists the
files that are on the base branch, never an open branch, so an unreviewed draft is never read.

The reader does not know how the repository is kept. It asks a :class:`MergedSpecSource` for the
merged files (a git repository, a record file, or the repository host in the real route), and
reads three facts from each file's front matter, which the platform writes into every spec it
publishes and a person keeps when editing:

``story``
    The story the spec belongs to. A file without one is listed as a plain file.
``spec``
    The spec identity; ``spec-<story key in lower case>`` when absent, which is what the write
    side derives for a story.
``machine_authored``
    ``true`` while the file is as the platform wrote it. A person who edits the file removes the
    line (or sets it to ``false``), and the merged edit then replaces the machine version.

The attribute names are the ones the approval gate reads (``kp.sweep.gate``). Every listed file
is merged by construction, so ``merged`` is always ``True``.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from functools import partial
from typing import Protocol

import yaml
from pydantic import JsonValue

from kp.domain.base import DomainModel
from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.sources import attributes as attr
from kp.sources.base import ItemMetadata
from kp.sources.files import sha256_hex
from kp.sources.snapshot import ReadItem, ScannedItem, SnapshotReader, fingerprint

logger = logging.getLogger(__name__)

VERSION_LENGTH = 16
SPEC_SCOPE = "specs"
"""The sweep scope the spec repository is swept under, beside the code repository's own."""

_FRONT_MATTER = re.compile(r"\A---[ \t]*\n(?P<header>.*?)\n---[ \t]*(?:\n|\Z)", re.DOTALL)


class MergedSpecFile(DomainModel):
    """A spec file as it stands on the base branch.

    :ivar path: Path inside the repository.
    :ivar content: The file's bytes.
    :ivar merged_at: When the pull request that last changed the file was merged.
    """

    path: str
    content: bytes
    merged_at: datetime


class MergedSpecSource(Protocol):
    """Where the merged spec files come from."""

    def merged_specs(self) -> Sequence[MergedSpecFile]:
        """List the spec files on the base branch.

        :return: One entry per file, with the merge date of its newest version
        :raises kp.errors.SourceUnavailableError: If the repository cannot be read
        """
        ...


@dataclass(frozen=True, slots=True)
class SpecFrontMatter:
    """What a spec file says about itself.

    :ivar story_key: The story, or ``None`` when the file names none.
    :ivar spec_id: The spec identity.
    :ivar template: The ``<template id>@<version>`` the spec was written from, if stated.
    :ivar machine_authored: True while the file carries the platform's own mark.
    """

    story_key: str | None
    spec_id: str | None
    template: str | None
    machine_authored: bool


def read_front_matter(content: bytes) -> SpecFrontMatter:
    """Read the front matter of a spec file.

    A file without front matter, or whose front matter is not a mapping, names nothing.

    :param content: The file's bytes
    :return: The facts the file states about itself
    """
    text = content.decode("utf-8", errors="replace")
    match = _FRONT_MATTER.match(text)
    fields: object = None
    if match is not None:
        try:
            fields = yaml.safe_load(match["header"])
        except yaml.YAMLError:
            logger.warning("Spec front matter is not valid YAML; the file names no story")
    if not isinstance(fields, dict):
        return SpecFrontMatter(None, None, None, machine_authored=False)
    story = _text(fields.get("story"))
    spec = _text(fields.get("spec")) or (None if story is None else f"spec-{story.lower()}")
    return SpecFrontMatter(
        story_key=story,
        spec_id=spec,
        template=_text(fields.get("template")),
        machine_authored=fields.get("machine_authored") is True,
    )


def _text(value: object) -> str | None:
    return value.strip() or None if isinstance(value, str) else None


class SpecRepoReader(SnapshotReader):
    """Read the merged spec files of the spec repository.

    :param source: Where the merged files come from
    """

    supersedes_older_versions = True

    def __init__(self, source: MergedSpecSource) -> None:
        super().__init__()
        self._source = source

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves.

        :return: The code host, which also holds the spec repository
        """
        return SourceKind.GITHUB

    def _scan(self) -> list[ScannedItem]:
        return [
            ScannedItem.of(self._read(merged), partial(self._reread, merged.path))
            for merged in sorted(self._source.merged_specs(), key=lambda item: item.path)
        ]

    def _reread(self, path: str) -> ReadItem | None:
        """Read one file again, as the repository has it now; ``None`` when it is gone."""
        current = next((item for item in self._source.merged_specs() if item.path == path), None)
        return None if current is None else self._read(current)

    def _read(self, merged: MergedSpecFile) -> ReadItem:
        content_sha256 = sha256_hex(merged.content)
        front = read_front_matter(merged.content)
        signals: dict[str, JsonValue] = {
            attr.MERGED: True,
            attr.CONTENT_SHA256: content_sha256,
            attr.FILE_KIND: "spec",
            "merged_at": merged.merged_at.isoformat(),
            "machine_authored": front.machine_authored,
        }
        if front.story_key is not None:
            signals.update(story_key=front.story_key, spec_id=front.spec_id)
        if front.template is not None:
            signals["template"] = front.template
        return ReadItem(
            key=ItemKey(
                source=self.kind, item_id=merged.path, version=content_sha256[:VERSION_LENGTH]
            ),
            fingerprint=fingerprint(content_sha256, signals),
            title=merged.path,
            modified_at=merged.merged_at,
            content=merged.content,
            metadata=ItemMetadata(
                native_id=merged.path,
                media_type="text/markdown",
                title=merged.path,
                modified_at=merged.merged_at,
                attributes=signals,
            ),
        )


__all__ = [
    "SPEC_SCOPE",
    "MergedSpecFile",
    "MergedSpecSource",
    "SpecFrontMatter",
    "SpecRepoReader",
    "read_front_matter",
]
