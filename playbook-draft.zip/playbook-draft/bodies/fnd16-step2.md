## What changed

Three steps towards the release-readiness check, in three commits:

- **Checklist evidence.** Five more requirements name the tests that cover them, so they move from planned to not run. One stays planned with a narrower gap.
- **Previous candidate.** Each refresh builds against the catalogue the scope's active publication projects. Source revisions are ordered against that catalogue, a complete and current snapshot that declares absence as deletion can propose retirements, and a source whose revision did not change is accepted as captured again. Before the first activation the build runs as before.
- **Owner reference rules.** The source owner's MCP reference-rule file can be part of the refresh configuration (`RECSYS_REFRESH_REFERENCE_RULES`, a path relative to the workspace root). The configuration digest covers its bytes, and the build uses exactly the file the job was admitted with, or refuses the candidate.

Blockers B5 and B7 leave the checklist.

## Why

Without the previous candidate a refresh could not tell a newer source revision from an older one, and could never retire anything. Without the rule file in the configuration, tool-level MCP references can never bind to their servers, and a changed rule file would not be noticed.

## How to verify

1. Unit tests: `tests/recsys/qualification/`, `tests/recsys/refresh/test_integration_catalogue_version.py`, `tests/recsys/refresh/test_integration_configuration.py`.
2. No active publication in the scope: a refresh builds without a previous candidate, as before.
3. Active publication on a validated catalogue: the new snapshot names that catalogue as its previous one, and a source captured at the same revision is listed as reused.
4. Negative case: the active publication points at a catalogue that is not a validated snapshot. The job ends as "publication rejected" with reason `previous_candidate_unavailable`, and nothing is built.
5. Set `RECSYS_REFRESH_REFERENCE_RULES`, submit a refresh, then change the file before it activates: the job ends as "source configuration changed". With the variable pointing at a missing file, the app refuses to start.

## Not in this PR

- An approved owner rule file. Agents show no MCP servers until the source owner signs one; a tools-column composition rule needs only the separator and the tool normalisation.
- B1-B4, B6, B8, Q1 and Q2.

## Review focus

- `refresh_policy` marks every required source reusable because each attempt captures every source again; `verify_revision_vector` still requires that capture for every reused collection.
- The previous-candidate loader rebuilds only what the builder reads (snapshot, source manifests, records with their evidence). The result is a build input and is never written.
- A database error while loading the previous candidate is not turned into a refusal, so the worker retries it.
