"""One reader per page: each turns platform services into a plain view the template draws.

A reader never raises for something a person can fix or be refused: it returns the view with a
:class:`~kp.web.errors.Problem`, so the page can show the state in place.
"""
