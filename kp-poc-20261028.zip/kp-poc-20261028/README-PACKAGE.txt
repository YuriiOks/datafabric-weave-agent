kp-poc-20261028: knowledge platform proof of concept

Contents
  install.py          installer (standard library only)
  README-PACKAGE.txt  this file
  SHA256SUMS          SHA-256 of every other file
  payload/            the project tree (435 files)

Apply order (from the folder that holds the unzipped package)
  1. sha256sum -c SHA256SUMS
       expected: every line says OK
  2. python3 install.py --inspect --target DIR
       expected output, in this order:
         CHECKSUMS OK (437 files verified)
         PLAN new <path> (<n> bytes)   once per file, 435 lines
         PLAN 435 files, 2502104 bytes, into DIR
         INSPECT only: nothing was written
       Apply only when this matches.
  3. python3 install.py --target DIR
       expected: INSTALLED 435 files into DIR, then the next steps
       DIR must be absent or empty; --force installs into a folder that is not empty.
  4. cd DIR and follow INSTALL-WORKSTATION.md
       (virtual environment, install, kp demo, tests).

Nothing in this package holds a secret, a token or a real address. Real values are set
on the workstation through KP_ environment variables (see .env.example).
