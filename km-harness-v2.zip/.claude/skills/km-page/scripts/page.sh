#!/bin/bash
# Helper for km-page. Run with bash.
#   page.sh new <name>     copy the template to designs/pages/<name>.html
#   page.sh check <name>   check the page and its markdown twin, print PASS or FAIL
# <name> is a bare name (no folder, no extension).
set -u
KM="$(cd "$(dirname "$0")/../../../.." && pwd)"
TPL="$KM/.claude/skills/km-page/assets/page-template.html"
DIR="$KM/designs/pages"
cmd="${1:-}"; name="${2:-}"
case "$name" in
  ""|*/*|*.*) echo "usage: page.sh new|check <name>"; exit 2 ;;
esac
HTML="$DIR/$name.html"; MD="$DIR/$name.md"

check() {
  local errs=""
  [ -f "$HTML" ] || { echo "FAIL: $HTML not found"; return 1; }
  [ -f "$MD" ] || errs="$errs"$'\n'"markdown twin missing: designs/pages/$name.md"
  local left hex pal
  left="$(grep -o '\[\[[^]]*\]\]' "$HTML" | head -3 | tr '\n' ' ')"
  [ -n "$left" ] && errs="$errs"$'\n'"unfilled placeholder: $left"
  for f in "$HTML" "$MD"; do
    [ -f "$f" ] || continue
    if LC_ALL=C grep -q '[^[:print:][:space:]]' "$f"; then
      errs="$errs"$'\n'"non-ASCII text in $(basename "$f")"
    fi
  done
  if [ -f "$MD" ] && [ -n "$(awk 'length > 100' "$MD")" ]; then
    errs="$errs"$'\n'"line over 100 characters in the twin"
  fi
  grep -qiE 'https?://|src="//' "$HTML" && errs="$errs"$'\n'"outside address in the page"
  pal='#(db0011|333333|5f5f5f|f3f3f3|ffffff|d7d8d6|101010|1b1b1b|eaeaea|a9a9a9|3a3a3a|ff3d47)'
  hex="$(grep -oiE '#[0-9a-f]{6}\b' "$HTML" | tr 'A-F' 'a-f' | sort -u | grep -vxE "$pal")"
  [ -n "$hex" ] && errs="$errs"$'\n'"colour outside the palette: $(echo $hex)"
  if [ -f "$MD" ]; then
    local nh nm
    nh="$(grep -c '<section id=' "$HTML")"
    nm="$(grep -c '^## ' "$MD")"
    [ "$nh" != "$nm" ] && errs="$errs"$'\n'"sections differ: html $nh, twin $nm"
  fi
  errs="$(echo "$errs" | sed '/^$/d')"
  if [ -n "$errs" ]; then echo "$errs" | sed 's/^/FAIL: /'; return 1; fi
  echo "PASS: $name ($(grep -c '<section id=' "$HTML") sections)"
}

case "$cmd" in
  new)
    mkdir -p "$DIR"
    [ -e "$HTML" ] && { echo "FAIL: $HTML exists"; exit 1; }
    cp "$TPL" "$HTML" && echo "created $HTML" ;;
  check) check ;;
  *) echo "usage: page.sh new|check <name>"; exit 2 ;;
esac
