"""Values returned by search and rule lookup."""

from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import Field

from kp.domain import ClauseRef, DomainModel, EditionState, Passage, PassageType, SourceKind


class SearchHit(DomainModel):
    """One search result.

    ``text`` is the quoted passage. For passages cut from a source file it equals the source
    text at ``char_start:char_end``; :func:`quote_matches` checks that.

    :ivar passage_id: Identity of the passage. For an exact-reference hit it is
        ``clause:<reference>`` and ``text`` is the whole clause, even if the clause is stored
        as several parts.
    :ivar reference: Canonical reference: ``<edition>:<number>`` for clauses, the parent
        (story key, requirement id, file path, ...) otherwise.
    :ivar part_index: Which part of a long clause or document this is, when split.
    :ivar match: ``reference`` for an exact-reference hit, ``ranked`` for a scored one.
    :ivar keyword_rank: Rank in the keyword list, if it appeared there.
    :ivar vector_rank: Rank in the vector list, if it appeared there.
    :ivar state: The state on the search date of the edition an exact-reference hit was read
        from, so a caller can tell that a named edition was not the one in force. ``None`` for
        ranked hits, which only ever come from the edition in force.
    """

    passage_id: str
    passage_type: PassageType
    reference: str
    edition: str | None = None
    version: str
    source: SourceKind
    item_id: str
    domain: str | None = None
    title: str = ""
    page: Annotated[int, Field(ge=1)] | None = None
    char_start: Annotated[int, Field(ge=0)] | None = None
    char_end: Annotated[int, Field(ge=0)] | None = None
    part_index: Annotated[int, Field(ge=0)] | None = None
    text: str
    score: float
    match: Literal["reference", "ranked"] = "ranked"
    keyword_rank: int | None = None
    vector_rank: int | None = None
    state: EditionState | None = None

    @classmethod
    def from_rule(cls, rule: RuleText, score: float) -> SearchHit:
        """Build the exact-reference hit of a clause read by number.

        :param rule: The clause as read
        :param score: The score to give the hit
        :return: A hit with ``match="reference"`` and the edition's state
        """
        return cls(
            passage_id=f"clause:{rule.ref.format()}",
            passage_type=PassageType.CLAUSE,
            reference=rule.ref.format(),
            edition=rule.ref.edition,
            version=rule.version,
            source=rule.source,
            item_id=rule.item_id,
            domain=rule.domain,
            title=rule.title,
            page=rule.page,
            char_start=rule.char_start,
            char_end=rule.char_end,
            text=rule.text,
            score=score,
            match="reference",
            state=rule.state,
        )

    @classmethod
    def from_passage(
        cls,
        passage: Passage,
        *,
        title: str,
        score: float,
        keyword_rank: int | None,
        vector_rank: int | None,
    ) -> SearchHit:
        """Build a ranked hit from a stored passage.

        :param passage: The passage
        :param title: The clause title for clause passages, else empty
        :param score: The fused, authority-weighted score
        :param keyword_rank: Rank in the keyword list, if present
        :param vector_rank: Rank in the vector list, if present
        :return: A hit with ``match="ranked"``
        """
        return cls(
            passage_id=passage.passage_id,
            passage_type=passage.passage_type,
            reference=passage.parent_ref,
            edition=passage.edition_label,
            version=passage.version,
            source=passage.source,
            item_id=passage.item_id,
            domain=passage.domain,
            title=title,
            page=passage.page,
            char_start=passage.char_start,
            char_end=passage.char_end,
            part_index=passage.part_index,
            text=passage.text,
            score=score,
            keyword_rank=keyword_rank,
            vector_rank=vector_rank,
        )

    @property
    def human_reference(self) -> str:
        """The spoken form for clauses (``2026.1 clause 4.2.1``), else ``reference``."""
        if self.edition is not None and self.passage_type is PassageType.CLAUSE:
            return ClauseRef.parse(self.reference).human()
        return self.reference


class SearchResponse(DomainModel):
    """The answer to one question.

    :ivar as_at: The date the question was answered at (the clock's today when none was given).
    :ivar edition_in_force: The edition that applied on ``as_at``, if any.
    :ivar vector_used: Whether the vector side contributed to the ranking.
    """

    question: str
    as_at: date
    edition_in_force: str | None
    vector_used: bool
    hits: tuple[SearchHit, ...]


class RuleText(DomainModel):
    """A rule (clause) as written in one edition, read at a date.

    :ivar as_at: The date the rule was read at.
    :ivar state: The edition's state on ``as_at``; an edition asked for by name may be
        superseded or not yet effective.
    """

    ref: ClauseRef
    title: str
    version: str
    source: SourceKind
    item_id: str
    domain: str | None = None
    page: Annotated[int, Field(ge=1)]
    char_start: Annotated[int, Field(ge=0)]
    char_end: Annotated[int, Field(ge=0)]
    text: str
    as_at: date
    state: EditionState


def quote_matches(hit: SearchHit | RuleText, source_text: str) -> bool:
    """Check that a quoted text equals the source text at its recorded position.

    :param hit: A search hit or rule text
    :param source_text: The full text of the document it was cut from
    :return: True when ``source_text[char_start:char_end] == hit.text``; False when the hit
        has no position
    """
    if hit.char_start is None or hit.char_end is None:
        return False
    return source_text[hit.char_start : hit.char_end] == hit.text
