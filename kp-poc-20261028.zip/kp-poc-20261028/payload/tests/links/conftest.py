"""Fixtures of the links tests: a connection, the loaded rulebook and a link service."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime

import pytest
from sqlalchemy import Connection

from kp.clock import FixedClock
from kp.links import LinkService
from kp.store import Database
from kp.testing.dataset import SyntheticDataset
from links.seed import seed_rulebook

# After 2026.1 takes effect (16 Nov 2026), so the edition in force is 2026.1.
IN_FORCE_NOW = datetime(2026, 11, 20, 9, 0, tzinfo=UTC)


@pytest.fixture
def connection(database: Database) -> Iterator[Connection]:
    """A connection inside one transaction, rolled back at the end."""
    with database.transaction() as conn:
        yield conn


@pytest.fixture
def clock() -> FixedClock:
    """A clock after the 2026.1 edition took effect."""
    return FixedClock(IN_FORCE_NOW)


@pytest.fixture
def loaded(connection: Connection, dataset: SyntheticDataset) -> Connection:
    """The connection with both rulebook editions loaded."""
    seed_rulebook(connection, dataset)
    return connection


@pytest.fixture
def service(loaded: Connection, clock: FixedClock) -> LinkService:
    """A link service over the loaded rulebook."""
    return LinkService(loaded, clock=clock)
