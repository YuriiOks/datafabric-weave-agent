"""The stable key of one relation.

A relation key is derived from the two durable component UUIDs and the link type only.
The UUIDs already fold in the publication scope, so the key needs nothing else. It is
deliberately independent of the catalogue id, the capture time, the reference
occurrence ids and the row a declaration sits on: rebuilding the same sources, or
moving a declaration to another row, keeps the key and changes only the evidence
digest.
"""

from __future__ import annotations

import hashlib
import json
import re
from uuid import UUID

from app.recsys.contracts import LinkType

#: Versioned namespace mixed into every relation key. Changing the derivation means a
#: new namespace, never a silent redefinition of existing keys.
RELATION_KEY_NAMESPACE = "bpc-relation-v1"

#: The shape every key and digest in this package has.
SHA256_HEX_PATTERN = re.compile(r"^[0-9a-f]{64}$")


def canonical_sha256(payload: object) -> str:
    """Digest a JSON-compatible value in one canonical encoding.

    :param payload: A JSON-compatible value; lists keep their order.
    :return: The full lower-case hex sha256 digest.
    """
    encoded = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def relation_key(
    source_uuid: UUID | str, link_type: LinkType, target_uuid: UUID | str
) -> str:
    """Return the stable key of one relation.

    :param source_uuid: The durable UUID of the declaring component.
    :param link_type: The relation kind.
    :param target_uuid: The durable UUID of the resolved target.
    :return: The lower-case hex sha256 of the namespaced triple.
    """
    return canonical_sha256(
        [RELATION_KEY_NAMESPACE, str(source_uuid), link_type.value, str(target_uuid)]
    )
