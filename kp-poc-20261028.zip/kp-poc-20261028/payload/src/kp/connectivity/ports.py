"""The ports of the connectivity harness.

The architect's own harness can replace this implementation by satisfying
:class:`ConnectivityJob` and writing the same evidence (the ``source_item`` and ``mcp_call``
rows, the stored objects, the signature files and the run files). Everything else in this
package reads that evidence, not the job.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Protocol

from kp.connectivity.models import ExtractionRequest, ExtractionResponse, RunResult, SampleItem
from kp.sources.base import FetchedItem


class PutOutcome(StrEnum):
    """What a write to an immutable store did."""

    CREATED = "created"
    EXISTING = "existing"


class ObjectStore(Protocol):
    """An immutable key-addressed store (the raw bucket or the Markdown bucket)."""

    def put_if_absent(self, key: str, data: bytes) -> PutOutcome:
        """Write ``data`` under ``key`` unless the key already exists.

        :param key: The object key, for example ``jira/item-1/<version>``
        :param data: The bytes to store
        :return: ``CREATED``, or ``EXISTING`` when identical bytes were already there
        :raises kp.connectivity.errors.ImmutableObjectError: If the key exists with other bytes
        :raises kp.connectivity.errors.InvalidObjectKeyError: If the key is not acceptable
        """
        ...

    def get(self, key: str) -> bytes:
        """Read an object.

        :param key: The object key
        :return: Its bytes
        :raises KeyError: If there is no such object
        """
        ...

    def exists(self, key: str) -> bool:
        """Say whether an object exists.

        :param key: The object key
        :return: True when it exists
        """
        ...

    def location(self, key: str) -> str:
        """Return the storage reference other services use to find the object.

        :param key: The object key
        :return: A reference string; stable for the same key
        """
        ...

    def key_of(self, location: str) -> str:
        """Return the key a storage reference points at.

        :param location: A reference produced by :meth:`location`
        :return: The object key
        :raises kp.connectivity.errors.InvalidObjectKeyError: If it is not one of this store's
        """
        ...


class ExtractionPort(Protocol):
    """The document extraction service, real or stand-in."""

    def extract(self, request: ExtractionRequest) -> ExtractionResponse:
        """Convert one stored object to Markdown with a manifest beside it.

        :param request: Identity, storage reference, declared media type and source type
        :return: Where the outputs are and which extractor version produced them
        :raises kp.connectivity.errors.ExtractionError: If this object cannot be converted
        :raises kp.connectivity.errors.MissingExtractorVersionError: If the answer lacks one
        :raises kp.connectivity.errors.ExtractionUnavailableError: If the service is down
        """
        ...


class SampleFetcher(Protocol):
    """Fetches the current version of a sample item through some route."""

    def fetch_current(self, item: SampleItem) -> FetchedItem:
        """Fetch the item as it is now.

        :param item: The sample item to fetch
        :return: The bytes and metadata, with the version derived from returned fields
        :raises kp.connectivity.errors.FidelityError: If the tool lost the source's fields
        :raises kp.errors.SourceItemNotFoundError: If the source has no such item
        """
        ...


class ConnectivityJob(Protocol):
    """The job the CLI drives. Replaceable by the architect's harness."""

    def discover(self) -> RunResult:
        """List and keep the tool signatures of all three servers.

        :return: The evidence of the discovery run
        """
        ...

    def run(self, *, skip_extraction: bool = False) -> RunResult:
        """Fetch, store and extract the nine sample items.

        :param skip_extraction: Store raw objects only, to prove the route first
        :return: The evidence of the run
        """
        ...

    def probe_errors(self) -> RunResult:
        """Provoke a bad credential and a bad parameter so the gateway errors are on record.

        :return: The evidence of the probe run
        """
        ...
