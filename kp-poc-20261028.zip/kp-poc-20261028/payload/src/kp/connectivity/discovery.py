"""Pre-build discovery: list the tools of the three servers and keep what they said.

Answers the questions the design leaves open before any adapter is trusted: which tools exist,
what arguments they take (can one object be addressed deterministically), and, together with
the first fetch, whether the fields come back structured. Each discovery keeps the raw tool
objects in its own file; a later discovery never replaces an earlier one.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from kp.connectivity.gateway import GatewayClient, signature_from_tool
from kp.connectivity.models import JsonObject, Route, ToolSignature
from kp.connectivity.storage import LocalObjectStore


class SignatureStore:
    """Keeps tool signatures on disk, one immutable file per server per discovery run.

    :param root: Directory that holds the signature files
    """

    def __init__(self, root: Path) -> None:
        self._root = root
        self._objects = LocalObjectStore(root)

    def save(
        self, namespace: str, run_id: str, captured_at: datetime, raw_tools: tuple[JsonObject, ...]
    ) -> None:
        """Keep the raw tool objects one server listed.

        :param namespace: The server's route
        :param run_id: The discovery run
        :param captured_at: When they were captured
        :param raw_tools: The tool objects exactly as returned
        :raises kp.connectivity.errors.ImmutableObjectError: If this run already kept different
            tools for this server
        """
        document = {
            "namespace": namespace,
            "run_id": run_id,
            "captured_at": captured_at.isoformat(),
            "tools": list(raw_tools),
        }
        data = (json.dumps(document, sort_keys=True, indent=2) + "\n").encode("utf-8")
        self._objects.put_if_absent(f"{namespace}/{run_id}.json", data)

    def load_latest(self, namespace: str) -> tuple[ToolSignature, ...] | None:
        """Read the signatures from the most recent discovery of a server.

        :param namespace: The server's route
        :return: The signatures, or ``None`` when the server was never discovered
        """
        folder = self._root / namespace
        files = sorted(folder.glob("*.json")) if folder.is_dir() else []
        if not files:
            return None
        document = json.loads(files[-1].read_text(encoding="utf-8"))
        return tuple(signature_from_tool(namespace, tool) for tool in document["tools"])


def discover_routes(
    client: GatewayClient,
    routes: tuple[Route, ...],
    store: SignatureStore,
    *,
    run_id: str,
    captured_at: datetime,
) -> dict[str, int]:
    """List and keep the tools of each server.

    :param client: The gateway client
    :param routes: The servers to discover
    :param store: Where to keep the signatures
    :param run_id: The discovery run id
    :param captured_at: Capture time
    :return: The number of tools each server listed, by namespace
    :raises kp.errors.SourceAuthRefusedError: If the credential is refused after one renewal
    :raises kp.connectivity.errors.GatewayForbiddenError: If the group does not allow the call
    :raises kp.errors.SourceUnavailableError: If the gateway cannot be reached
    """
    counts: dict[str, int] = {}
    for route in routes:
        listing = client.list_tools(route)
        store.save(route.namespace, run_id, captured_at, listing.raw_tools)
        counts[route.namespace] = len(listing.signatures)
    return counts
