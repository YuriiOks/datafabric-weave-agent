fnd18-review: PR 82 review fixes (feat/fnd-18 at 0c92927)

Unzip in /home/user/bpc-port, then from /home/user/bpc-port/fnd18-review:
  sha256sum -c --quiet SHA256SUMS && echo SUMS-OK
  bash ap15.sh      (checks the branch and a clean tree, apply_t.py --check, apply,
                     ruff fix/format on the two Python files, the named backend and
                     frontend tests, tsc, eslint, invariants, restarts the demo)
  bash commit9.sh   (two commits and a fast-forward push; only after a click-through)

apply_t.py edits 7 files and writes nothing if any anchor is missing:
  backend/app/recsys/registry/agent_hub_api.py   gateway-only token, MCP answer by id,
                                                 initialized status, tools/list pages,
                                                 stale MCP List column counts dropped
  backend/app/recsys/config.py                   RECSYS_AGENT_HUB_MCP_GATEWAY_URL
  backend/tests/recsys/registry/test_agent_hub_api.py   10 new tests
  frontend/src/features/recsys/components/RecommendationCard.tsx (+ test)   tool chips once
  frontend/src/features/recsys/component-page/fromRegistry.ts (+ test)      no hub row number
