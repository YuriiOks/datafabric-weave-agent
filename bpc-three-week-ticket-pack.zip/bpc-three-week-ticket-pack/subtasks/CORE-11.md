---
pack_id: "bpc-sep26-v1"
local_id: "CORE-11"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Apply evidence-state policy to the existing bounded Hub decision path"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-22"
planned_due: "2026-09-23"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-07"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-11"
architecture_sections: ["decision-authority","ai-contracts","validation-gates"]
---

# Apply evidence-state policy to the existing bounded Hub decision path

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-11** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-22 → 2026-09-23 (D10–D11)**.
- Recommendation extension: **2026-09-23 → 2026-09-24 (D11–D12)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Improve one existing AI decision path using explicit material evidence instead of treating schema-valid model prose as proven coverage.

## Scope and contract

Independent evidence lifecycle (implemented/planned/retired/unknown), freshness and conflict axes; a frozen deterministic task policy owns DECIDED/NOVEL/PARTIAL/COVERED and non-verdict states. Model output is attributed data, not authorization, execution permission or semantic truth.

## Implementation sequence

1. Freeze required evidence, admissible lifecycle/freshness combinations, conflict routing and false-COVERED/false-NOVEL risk policy with the domain owner.
2. Use typed SourceEvidence and verified source anchors; record missing material, contradictions and unreviewed semantic support explicitly.
3. Adapt the existing bounded path to deterministic decision gates and explicit needs-information/review-required/dependency-failed outcomes.
4. Implement review records, current access, reviewer identity, evidence/version, override reason and queue ownership using existing approved surfaces.
5. Compare the candidate with CORE-07 baseline under the same immutable manifest and frozen labels; keep it behind the existing evaluated feature boundary until CORE-09.

## Acceptance criteria

- [ ] Planned-only or contradictory evidence cannot silently establish implemented COVERED status.
- [ ] Only DECIDED carries a business verdict; missing input, evidence abstention and unavailable dependencies are distinct.
- [ ] Quotes matching source offsets are not labelled semantically verified without the required adjudication.
- [ ] Review feedback nominates future cases but is not automatically ground truth or training data.
- [ ] The candidate earns promotion through task-specific evidence and agreed risk limits.

## Verification

- Cases cover planned vs implemented, stale/retired evidence, conflicting claims, incomplete requests, missing dependencies and reviewer overrides.
- Measure false-COVERED and false-NOVEL separately and document abstention/coverage trade-offs.

## Evidence to attach

- Versioned evidence policy, adjudicated cases, paired baseline/candidate report and review audit examples.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Estimate assumes the bounded deterministic route already exists as reported. If it does not, this is a new implementation requiring replan. Calibrated numeric probabilities remain disabled without sufficient held-out evidence.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `decision-authority`, `ai-contracts`, `validation-gates`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
