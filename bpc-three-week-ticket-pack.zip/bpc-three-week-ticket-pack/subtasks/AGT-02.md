---
pack_id: "bpc-sep26-v1"
local_id: "AGT-02"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1345"
summary: "Apply durable scoped identity and duplicate policy for Agents"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-16"
planned_due: "2026-09-16"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["AGT-01","CORE-02","CORE-03"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-agt-02"
architecture_sections: ["identity","ingestion","publication"]
---

# Apply durable scoped identity and duplicate policy for Agents

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1345**. Local reference **AGT-02** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-16 → 2026-09-16 (D6–D6)**.
- Recommendation extension: **2026-09-16 → 2026-09-16 (D6–D6)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

Agent names and row order are not durable identity. Configure the shared identity and resolution contracts for workbook Agents so reordering, a reviewed rename or an alias change cannot corrupt Agent nodes or their declared relations.

## Scope

- Use the owner-confirmed scoped source key for an Agent only when it is stable and unique in the approved authority/environment/partition.
- Preserve one durable component ID across snapshots; keep external identifiers and display names as typed aliases with lifecycle history.
- Quarantine duplicate or ambiguous source identifiers; do not mint order-based suffixes or merge by name similarity.
- Feed Agent reference-resolution outcomes to relation construction: exact/authorised aliases may resolve; ambiguous or unknown references remain ledger entries.

## Boundaries

Use CORE-02 and CORE-03 rather than introducing a parallel identity store. Do not assume a portal identifier is stable until the source owner confirms it. Do not map a component Agent to a native Hub Agent here.

## Technical steps

1. Bind the AGT-01 field map to the shared identity namespace and alias model.
2. Define Agent-specific resolution precedence only where source authority has supplied evidence.
3. Make duplicate, missing-key and collision outcomes quarantined and diagnosable.
4. Preserve reviewed rename/alias history without replacing the durable Agent ID.
5. Exercise identity changes through the shared catalogue oracle before publication.

## Acceptance criteria

- Reordering identical workbook rows leaves durable Agent IDs and relation targets unchanged.
- An owner-reviewed rename retains the durable ID and appends alias history.
- Two rows sharing an unresolved external ID remain separately quarantined; no `#2`-style identity or name-based merge is produced.
- A reference with multiple candidate Agents is reported as ambiguous and creates no resolved graph edge.
- Identity decisions expose source evidence, mapping version and reviewer/owner decision where required.

## Evidence to attach

Synthetic/redacted source fixtures covering reorder, rename, duplicate and ambiguous-reference cases; resulting resolution ledger; identity mapping/version record.

## Dependencies / blockers

Requires AGT-01, CORE-02 and CORE-03, plus owner confirmation of the Agent namespace and ID lifetime. Blocks AGT-03 and AGT-04.

## Out of scope

Native Hub Agent joins, display-name reconciliation, recommendation eligibility and any new graph database or migration decision.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [AGT-01](AGT-01.md) must finish its stated contract boundary before this task starts.
- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.
- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `identity`, `ingestion`, `publication`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
