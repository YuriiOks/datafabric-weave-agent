"""Relational schema for the whole build, as SQLAlchemy Core tables.

Conventions every lane relies on:

* Column names equal the domain field names. Where a domain value is composite it is
  flattened: ``Clause.ref`` is ``edition`` + ``number``; ``Clause.parent_ref`` is
  ``parent_number``; ``SourceItemVersion.details`` is five ``details`` columns; ``Link``
  endpoints are ``source_item_type``/``source_key`` and ``target_item_type``/``target_key``.
* Only dialect-neutral types: strings, text, integers, floats, booleans, dates, UTC
  datetimes and JSON. Enums are stored as their string value with a CHECK constraint.
* Lists and mappings (``sources``, ``checks``, ``links``, ``embedding`` ...) are JSON.
* ``source_item`` rows are keyed by source + item + version and never rewritten, except for
  the approval columns (state and the three dates).
"""

from __future__ import annotations

from enum import StrEnum

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    Column,
    Date,
    Float,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    Integer,
    MetaData,
    PrimaryKeyConstraint,
    String,
    Table,
    Text,
    UniqueConstraint,
)

from kp.domain.enums import (
    ApprovalState,
    ChangeKind,
    ExtractionStatus,
    ItemType,
    KnowledgeVersionState,
    LinkKind,
    LinkState,
    PassageType,
    ReviewKind,
    ReviewState,
    RunKind,
    RunOutcome,
    SourceKind,
    SpecState,
)
from kp.domain.relations import Relation
from kp.store.types import UtcDateTime

NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

metadata = MetaData(naming_convention=NAMING_CONVENTION)

_KEY = 255
_SHA256 = 64


def _choice(name: str, values: type[StrEnum], *, nullable: bool = False) -> Column[str]:
    """A string column restricted to the values of an enum."""
    # Enum values are code-defined identifiers, never user input, so inlining them is safe.
    allowed = ", ".join(f"'{member.value}'" for member in values)
    return Column(
        name,
        String(40),
        CheckConstraint(f"{name} IN ({allowed})", name=f"{name}_valid"),
        nullable=nullable,
    )


def _key(name: str, *, nullable: bool = False) -> Column[str]:
    return Column(name, String(_KEY), nullable=nullable)


run = Table(
    "run",
    metadata,
    _key("run_id"),
    _choice("kind", RunKind),
    Column("sources", JSON, nullable=False),
    Column("started_at", UtcDateTime, nullable=False),
    Column("ended_at", UtcDateTime),
    _choice("outcome", RunOutcome),
    Column("items_touched", Integer, nullable=False, default=0),
    PrimaryKeyConstraint("run_id"),
)

sweep_cursor = Table(
    "sweep_cursor",
    metadata,
    _choice("source", SourceKind),
    Column("scope", String(_KEY), nullable=False, default=""),
    Column("position", Text),
    Column("last_success_at", UtcDateTime),
    Column("last_attempt_at", UtcDateTime),
    Column("consecutive_failures", Integer, nullable=False, default=0),
    Column("updated_at", UtcDateTime, nullable=False),
    PrimaryKeyConstraint("source", "scope"),
)

source_item = Table(
    "source_item",
    metadata,
    _choice("source", SourceKind),
    _key("item_id"),
    _key("version"),
    _key("native_id"),
    Column("content_sha256", String(_SHA256), nullable=False),
    Column("media_type", String(_KEY), nullable=False),
    Column("title", Text, nullable=False),
    Column("author", String(_KEY)),
    Column("modified_at", UtcDateTime),
    Column("raw_location", Text, nullable=False),
    Column("markdown_location", Text),
    Column("fetched_at", UtcDateTime, nullable=False),
    Column("run_id", ForeignKey("run.run_id"), nullable=False),
    _key("attachment_parent", nullable=True),
    _choice("extraction_status", ExtractionStatus),
    Column("extraction_failure", Text),
    Column("manifest_location", Text),
    Column("extractor_version", String(_KEY)),
    _choice("approval_state", ApprovalState),
    Column("effective_date", Date),
    Column("superseded_at", Date),
    Column("withdrawn_at", Date),
    Column("document_type", String(_KEY)),
    Column("domain", String(_KEY)),
    Column("authority", String(_KEY)),
    Column("classification", String(_KEY)),
    Column("content_owner", String(_KEY)),
    Column("machine_authored", Boolean, nullable=False, default=False),
    PrimaryKeyConstraint("source", "item_id", "version"),
    Index("ix_source_item_identity", "source", "item_id"),
    Index("ix_source_item_approval", "approval_state", "domain"),
)

mcp_call = Table(
    "mcp_call",
    metadata,
    _key("call_id"),
    Column("run_id", ForeignKey("run.run_id"), nullable=False),
    _key("tool"),
    _key("operation"),
    Column("request_digest", String(_SHA256), nullable=False),
    Column("http_status", Integer),
    Column("error_class", String(_KEY)),
    Column("object_count", Integer, nullable=False, default=0),
    Column("truncated", Boolean, nullable=False, default=False),
    Column("latency_ms", Float, nullable=False),
    Column("token_refreshed", Boolean, nullable=False, default=False),
    Column("surviving_fields", JSON, nullable=False),
    Column("called_at", UtcDateTime, nullable=False),
    PrimaryKeyConstraint("call_id"),
    Index("ix_mcp_call_run", "run_id"),
)

edition = Table(
    "edition",
    metadata,
    _key("label"),
    Column("effective_date", Date, nullable=False),
    Column("superseded_from", Date),
    Column("withdrawn_from", Date),
    Column("title", Text, nullable=False, default=""),
    _choice("source", SourceKind),
    _key("item_id"),
    _key("version"),
    PrimaryKeyConstraint("label"),
    ForeignKeyConstraint(
        ["source", "item_id", "version"],
        ["source_item.source", "source_item.item_id", "source_item.version"],
    ),
)

clause = Table(
    "clause",
    metadata,
    Column("edition", ForeignKey("edition.label"), nullable=False),
    Column("number", String(_KEY), nullable=False),
    Column("title", Text, nullable=False, default=""),
    Column("page", Integer, nullable=False),
    Column("char_start", Integer, nullable=False),
    Column("char_end", Integer, nullable=False),
    Column("text", Text, nullable=False),
    Column("structure_score", Float, nullable=False),
    Column("parent_number", String(_KEY)),
    PrimaryKeyConstraint("edition", "number"),
)

requirement = Table(
    "requirement",
    metadata,
    _key("requirement_id"),
    _choice("source", SourceKind),
    _key("item_id"),
    _key("version"),
    Column("sheet", String(_KEY), nullable=False),
    Column("row_number", Integer, nullable=False),
    Column("header_confidence", Float, nullable=False),
    Column("domain", String(_KEY)),
    Column("fields", JSON, nullable=False),
    PrimaryKeyConstraint("requirement_id"),
    ForeignKeyConstraint(
        ["source", "item_id", "version"],
        ["source_item.source", "source_item.item_id", "source_item.version"],
    ),
)

story = Table(
    "story",
    metadata,
    _key("story_key"),
    _key("version"),
    Column("summary", Text, nullable=False),
    Column("description", Text, nullable=False, default=""),
    Column("acceptance_criteria", Text, nullable=False, default=""),
    Column("links", JSON, nullable=False),
    _key("parent_key", nullable=True),
    Column("status", String(_KEY), nullable=False, default=""),
    Column("domain", String(_KEY)),
    Column("fingerprint", String(_SHA256), nullable=False),
    PrimaryKeyConstraint("story_key", "version"),
    Index("ix_story_fingerprint", "story_key", "fingerprint"),
)

passage = Table(
    "passage",
    metadata,
    _key("passage_id"),
    _choice("passage_type", PassageType),
    Column("parent_ref", String(_KEY), nullable=False),
    _choice("source", SourceKind),
    _key("item_id"),
    _key("version"),
    Column("text", Text, nullable=False),
    Column("tokens", Integer, nullable=False),
    Column("domain", String(_KEY)),
    Column("edition_label", String(_KEY)),
    Column("page", Integer),
    Column("char_start", Integer),
    Column("char_end", Integer),
    Column("part_index", Integer),
    # 768 floats; the vector side may move to a dedicated extension behind its interface.
    Column("embedding", JSON),
    Column("model_version", String(_KEY)),
    PrimaryKeyConstraint("passage_id"),
    Index("ix_passage_parent", "parent_ref"),
    Index("ix_passage_filter", "domain", "edition_label", "passage_type"),
    Index("ix_passage_item", "source", "item_id", "version"),
)

link = Table(
    "link",
    metadata,
    _key("link_id"),
    _choice("source_item_type", ItemType),
    _key("source_key"),
    _choice("relation", Relation),
    _choice("target_item_type", ItemType),
    _key("target_key"),
    _choice("kind", LinkKind),
    _choice("state", LinkState),
    Column("score", Float),
    Column("evidence", Text, nullable=False, default=""),
    Column("valid_from", UtcDateTime, nullable=False),
    Column("valid_to", UtcDateTime),
    PrimaryKeyConstraint("link_id"),
    UniqueConstraint(
        "source_item_type",
        "source_key",
        "relation",
        "target_item_type",
        "target_key",
        "valid_from",
        name="uq_link_fact",
    ),
    Index("ix_link_source", "source_item_type", "source_key"),
    Index("ix_link_target", "target_item_type", "target_key"),
)

change_event = Table(
    "change_event",
    metadata,
    _key("event_id"),
    _choice("source", SourceKind),
    _key("item_id"),
    _key("old_version", nullable=True),
    _key("new_version", nullable=True),
    _choice("kind", ChangeKind),
    Column("detected_at", UtcDateTime, nullable=False),
    Column("run_id", ForeignKey("run.run_id"), nullable=False),
    PrimaryKeyConstraint("event_id"),
    Index("ix_change_event_item", "source", "item_id"),
)

knowledge_version = Table(
    "knowledge_version",
    metadata,
    _key("version_id"),
    Column("run_id", ForeignKey("run.run_id"), nullable=False),
    _choice("state", KnowledgeVersionState),
    Column("checks", JSON, nullable=False),
    Column("item_count", Integer, nullable=False, default=0),
    Column("created_at", UtcDateTime, nullable=False),
    Column("published_at", UtcDateTime),
    Column("retained_until", Date),
    PrimaryKeyConstraint("version_id"),
)

review_item = Table(
    "review_item",
    metadata,
    _key("review_id"),
    _choice("kind", ReviewKind),
    _choice("state", ReviewState),
    _choice("source", SourceKind),
    _key("item_id"),
    _key("version", nullable=True),
    Column("detail", Text, nullable=False, default=""),
    Column("missing_details", JSON, nullable=False),
    Column("content_owner", String(_KEY)),
    Column("candidates", JSON, nullable=False),
    Column("run_id", ForeignKey("run.run_id"), nullable=False),
    Column("created_at", UtcDateTime, nullable=False),
    Column("resolved_at", UtcDateTime),
    PrimaryKeyConstraint("review_id"),
    Index("ix_review_item_open", "state", "kind"),
)

tool_call = Table(
    "tool_call",
    metadata,
    _key("call_id"),
    _key("session_id"),
    _key("caller"),
    _key("agent"),
    _key("tool"),
    Column("request", JSON, nullable=False),
    Column("request_digest", String(_SHA256), nullable=False),
    Column("domains_applied", JSON, nullable=False),
    Column("items_returned", Integer, nullable=False, default=0),
    Column("filtered_count", Integer, nullable=False, default=0),
    Column("latency_ms", Float, nullable=False),
    Column("called_at", UtcDateTime, nullable=False),
    Column("refused", Boolean, nullable=False, default=False),
    Column("refusal_reason", Text),
    Column("error_class", String(_KEY)),
    # Deliberately not a foreign key: audit rows are append-only and may precede the spec.
    _key("spec_id", nullable=True),
    PrimaryKeyConstraint("call_id"),
    Index("ix_tool_call_session", "session_id"),
    Index("ix_tool_call_spec", "spec_id"),
)

# What each agent session was shown by the read tools. The write side checks citations against
# it ("retrieved in the same session"); the read and write servers may be separate processes,
# so it lives in the database. Deliberately not a foreign key: it is an append-only record.
session_retrieval = Table(
    "session_retrieval",
    metadata,
    _key("session_id"),
    _key("reference"),
    _key("tool"),
    Column("retrieved_at", UtcDateTime, nullable=False),
    PrimaryKeyConstraint("session_id", "reference"),
)

template = Table(
    "template",
    metadata,
    _key("template_id"),
    _key("version"),
    _key("spec_type"),
    Column("body", Text, nullable=False),
    Column("content_sha256", String(_SHA256), nullable=False),
    PrimaryKeyConstraint("template_id", "version"),
    Index("ix_template_spec_type", "spec_type"),
)

spec = Table(
    "spec",
    metadata,
    _key("spec_id"),
    _key("story_key"),
    Column("path", Text, nullable=False),
    _key("template_id"),
    _key("template_version"),
    # The same branch name always means the same pull request.
    Column("branch", String(_KEY), nullable=False, unique=True),
    _key("pr_identity", nullable=True),
    _choice("state", SpecState),
    Column("machine_authored", Boolean, nullable=False, default=True),
    Column("coverage", JSON, nullable=False),
    Column("open_items", JSON, nullable=False),
    Column("content_sha256", String(_SHA256), nullable=False),
    Column("created_at", UtcDateTime, nullable=False),
    Column("merged_at", UtcDateTime),
    PrimaryKeyConstraint("spec_id"),
    ForeignKeyConstraint(
        ["template_id", "template_version"], ["template.template_id", "template.version"]
    ),
    Index("ix_spec_story", "story_key"),
)

citation = Table(
    "citation",
    metadata,
    _key("citation_id"),
    Column("spec_id", ForeignKey("spec.spec_id"), nullable=False),
    Column("statement_index", Integer, nullable=False),
    Column("statement", Text, nullable=False),
    Column("is_rule_statement", Boolean, nullable=False),
    Column("reference", String(_KEY)),
    Column("resolved", Boolean, nullable=False, default=False),
    Column("retrieved_in_session", Boolean, nullable=False, default=False),
    PrimaryKeyConstraint("citation_id"),
    UniqueConstraint("spec_id", "statement_index", name="uq_citation_statement"),
)

spec_correction = Table(
    "spec_correction",
    metadata,
    _key("correction_id"),
    Column("spec_id", ForeignKey("spec.spec_id"), nullable=False),
    Column("correction", Text, nullable=False),
    Column("reason", Text, nullable=False),
    Column("wrong_clause", Boolean, nullable=False, default=False),
    Column("recorded_at", UtcDateTime, nullable=False),
    PrimaryKeyConstraint("correction_id"),
    Index("ix_spec_correction_spec", "spec_id"),
)
