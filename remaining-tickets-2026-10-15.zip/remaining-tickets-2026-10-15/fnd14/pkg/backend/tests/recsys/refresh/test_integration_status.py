"""Status reports the publication the pointer marks active, or nothing."""

from __future__ import annotations

import unittest

from app.recsys.contract_fixtures import ACTIVE_PUBLICATION
from app.recsys.refresh.integration.status import ActivePublicationStatusPort

from . import protocol_fixtures as fixtures


class _Repository:
    def __init__(self, descriptor) -> None:
        self.descriptor = descriptor
        self.scopes = []

    async def active_descriptor(self, scope):
        self.scopes.append(scope)
        return self.descriptor


class ActivePublicationStatusTests(unittest.IsolatedAsyncioTestCase):
    async def test_active_descriptor_is_reported(self) -> None:
        descriptor = ACTIVE_PUBLICATION.model_copy(
            update={"scope": fixtures.SCOPE, "activated_at": fixtures.UTC_NOW}
        )
        repository = _Repository(descriptor)

        status = await ActivePublicationStatusPort(repository).current_publication(fixtures.SCOPE)

        self.assertEqual(repository.scopes, [fixtures.SCOPE])
        self.assertEqual(status.publication_uuid, descriptor.publication_uuid)
        self.assertEqual(status.catalogue_id, descriptor.catalogue_id)
        self.assertEqual(status.snapshot_id, descriptor.manifest_digest)
        self.assertEqual(status.activated_at, fixtures.UTC_NOW)

    async def test_no_active_publication_reports_nothing(self) -> None:
        port = ActivePublicationStatusPort(_Repository(None))

        self.assertIsNone(await port.current_publication(fixtures.SCOPE))
