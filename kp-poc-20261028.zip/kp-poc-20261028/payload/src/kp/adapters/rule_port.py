"""Seam: the read tools' rule port, backed by the edition and clause tables."""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import select

from kp.domain import Clause, ClauseRef, Edition
from kp.store import Database, schema
from kp.tools import RuleClause


class DatabaseRulePort:
    """Rulebook editions and clauses for the agent tools.

    The domain of a clause is the domain of the document version its edition came from.

    :param database: The platform database
    """

    def __init__(self, database: Database) -> None:
        self._database = database

    def editions(self) -> Sequence[Edition]:
        """List every edition, whatever its state.

        :return: The editions, ordered by effective date then label
        """
        with self._database.transaction() as connection:
            rows = connection.execute(
                select(schema.edition).order_by(
                    schema.edition.c.effective_date, schema.edition.c.label
                )
            )
            return [Edition.model_validate(dict(row._mapping)) for row in rows]

    def edition_domain(self, edition: str) -> str | None:
        """Tell the access domain of an edition's document.

        :param edition: Edition label
        :return: The domain, or ``None`` when the edition is unknown or unlabelled
        """
        with self._database.transaction() as connection:
            return connection.execute(
                select(schema.source_item.c.domain)
                .select_from(
                    schema.edition.join(
                        schema.source_item,
                        (schema.source_item.c.source == schema.edition.c.source)
                        & (schema.source_item.c.item_id == schema.edition.c.item_id)
                        & (schema.source_item.c.version == schema.edition.c.version),
                    )
                )
                .where(schema.edition.c.label == edition)
            ).scalar()

    def clause(self, edition: str, number: str) -> RuleClause | None:
        """Fetch one clause with the domain of its document.

        :param edition: Edition label
        :param number: Dotted clause number
        :return: The clause, or ``None`` when the edition has no such clause
        """
        with self._database.transaction() as connection:
            row = (
                connection.execute(
                    select(schema.clause, schema.source_item.c.domain)
                    .select_from(
                        schema.clause.join(
                            schema.edition, schema.clause.c.edition == schema.edition.c.label
                        ).join(
                            schema.source_item,
                            (schema.source_item.c.source == schema.edition.c.source)
                            & (schema.source_item.c.item_id == schema.edition.c.item_id)
                            & (schema.source_item.c.version == schema.edition.c.version),
                        )
                    )
                    .where(schema.clause.c.edition == edition, schema.clause.c.number == number)
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        ref = ClauseRef(row["edition"], row["number"])
        parent = row["parent_number"]
        return RuleClause(
            clause=Clause(
                ref=ref,
                title=row["title"],
                page=row["page"],
                char_start=row["char_start"],
                char_end=row["char_end"],
                text=row["text"],
                structure_score=row["structure_score"],
                parent_ref=ClauseRef(ref.edition, parent) if parent else None,
            ),
            domain=row["domain"],
        )
