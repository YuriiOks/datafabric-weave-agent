"""The pin shared by a corpus manifest, its cases and every run measured against them."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from enum import Enum
from typing import TYPE_CHECKING, Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.recsys.contracts.scope import PublicationScope

if TYPE_CHECKING:
    from app.recsys.contracts.resolution import CanonicalRecord

DIGEST_DOMAIN = "recsys-casepack-v1"


class CasePackError(ValueError):
    """A corpus, case pack, split, log or run record that breaks the case-pack contract."""


def enum_value(value: Any) -> Any:
    """Return an enum member's value, or the value itself.

    :param value: An enum member or a plain value.
    :return: The plain value.
    """
    return value.value if isinstance(value, Enum) else value


def canonical_digest(value: Any) -> str:
    """Hash JSON-shaped data deterministically.

    :param value: Data already in JSON shape, for example ``model_dump(mode="json")``.
    :return: The sha256 hex digest of the domain-separated canonical JSON.
    """
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(f"{DIGEST_DOMAIN}\n{payload}".encode("ascii")).hexdigest()


class SourcePin(BaseModel):
    """One source revision the pinned catalogue was built from."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    authority: str = Field(min_length=1, max_length=64)
    source_configuration_version: str = Field(min_length=1, max_length=64)
    resolved_revision: str = Field(min_length=1, max_length=128)

    def key(self) -> tuple[str, str, str]:
        """:return: The pin as a sortable, hashable tuple."""
        return (self.authority, self.source_configuration_version, self.resolved_revision)


class CasePackLineage(BaseModel):
    """The catalogue, publication, policy and source revisions a case pack is pinned to.

    ``access_policy_revision`` stays ``None`` until a read policy decides visibility. Cases
    that depend on access can then be planned but not measured.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    catalogue_id: str = Field(min_length=1, max_length=128)
    manifest_digest: str = Field(min_length=1, max_length=128)
    scope: PublicationScope
    policy_version: str = Field(min_length=1, max_length=64)
    code_version: str = Field(min_length=1, max_length=64)
    publication_uuid: UUID | None = None
    access_policy_revision: str | None = Field(default=None, min_length=1, max_length=128)
    sources: tuple[SourcePin, ...] = Field(min_length=1)

    @field_validator("sources")
    @classmethod
    def _one_revision_per_authority(cls, value: tuple[SourcePin, ...]) -> tuple[SourcePin, ...]:
        """Sort the pins and allow each authority once.

        :param value: The source pins.
        :return: The pins in canonical order.
        :raises ValueError: When an authority is pinned twice.
        """
        authorities = [pin.authority for pin in value]
        if len(set(authorities)) != len(authorities):
            raise ValueError("each source authority is pinned at exactly one revision")
        return tuple(sorted(value, key=SourcePin.key))

    def digest(self) -> str:
        """:return: The digest that cases and run observations carry as their pin."""
        return canonical_digest(self.model_dump(mode="json"))

    def pin_keys(self) -> frozenset[tuple[str, str, str]]:
        """:return: The pinned source revisions as tuples."""
        return frozenset(pin.key() for pin in self.sources)


def evidence_pin(evidence: Any) -> SourcePin:
    """Read the source pin of one piece of record evidence.

    :param evidence: A ``SourceEvidence`` of a canonical record.
    :return: The pin it names.
    """
    return SourcePin(
        authority=enum_value(evidence.authority),
        source_configuration_version=evidence.source_configuration_version,
        resolved_revision=evidence.resolved_revision,
    )


def lineage_for(
    snapshot: Any,
    records: Iterable[CanonicalRecord],
    *,
    publication_uuid: UUID | None = None,
    access_policy_revision: str | None = None,
) -> CasePackLineage:
    """Pin a lineage to one validated catalogue snapshot and the evidence of its records.

    :param snapshot: The ``CatalogueSnapshot`` the records belong to.
    :param records: The canonical records of that snapshot.
    :param publication_uuid: The publication that serves the snapshot, when one does.
    :param access_policy_revision: The read policy revision that decides visibility.
    :return: The lineage.
    :raises CasePackError: When the snapshot is not validated, a record belongs to another
        catalogue, or one authority appears at two revisions.
    """
    if enum_value(snapshot.state) != "validated":
        raise CasePackError("a case pack is pinned to a validated catalogue snapshot only")
    pins: dict[str, SourcePin] = {}
    for record in records:
        if record.catalogue_id != snapshot.catalogue_id:
            raise CasePackError("a record belongs to another catalogue than the snapshot")
        for evidence in record.source_evidence:
            pin = evidence_pin(evidence)
            known = pins.setdefault(pin.authority, pin)
            if known.key() != pin.key():
                raise CasePackError(f"source {pin.authority} appears at more than one revision")
    if not pins:
        raise CasePackError("the records carry no source evidence to pin")
    return CasePackLineage(
        catalogue_id=snapshot.catalogue_id,
        manifest_digest=snapshot.manifest_digest,
        scope=snapshot.scope,
        policy_version=snapshot.policy_version,
        code_version=snapshot.code_version,
        publication_uuid=publication_uuid,
        access_policy_revision=access_policy_revision,
        sources=tuple(pins.values()),
    )
