> [!IMPORTANT]
> **Additive schema change, and a new catalogue version on the next ingest.** The link table gains two nullable columns, the review ledger gains three, and a new evidence table hangs off the links. The existing schema setup creates them, and the human-only reversal is in `docs/recsys/catalogue-reversal.sql`. The ingest code version moves from 5 to 6, so the next ingest writes a fresh catalogue version that carries the evidence.

## Problem

Declared agent dependencies became links with no record of which declaration supported them. A declaration that did not resolve vanished from the graph and survived only as a quality flag, with no owner, no link type and no candidates. Nothing gave a relation a key that survives a rebuild, and nothing decided when a relation is allowed to leave the graph.

## Solution

- **Relations.** One relation per accepted (source, link type, target) fact, over the closed set of link types the sources declare. A recommendation, an execution, an approval or a native Hub binding is never an edge: the evidence table and the ledger refuse any other link type.
- **Stable key.** Every published link carries a relation key derived from the two component ids and the link type only. Rebuilding the same sources keeps every key, and so does moving a declaration to another row.
- **Evidence.** Each relation keeps one entry per supporting declaration. An entry records:
  - the source and collection;
  - the structural locator;
  - the field and token position;
  - the raw token, shown as a digest when it looks like a path, a credential, an address or a staff number;
  - the resolution outcome and the matched index;
  - the rule and rule version that bound it.

  A repeated declaration adds an entry, never a second edge. The link's evidence digest changes exactly when its evidence changes.
- **Unresolved declarations.** A declaration that does not resolve to exactly one accepted component produces no edge and stays in the review ledger. The ledger records the resolver's outcome, the component that made the declaration (or nothing when that record has no accepted identity), the link type it would have produced and, for an ambiguous reference, every candidate.
- **Counts.** Per link type, declared occurrences always equal accepted plus unresolved, and folded duplicates are counted apart from relations. The counts are computed, never persisted.
- **Retirement.** The transition gate can now decide relations as well as components. A relation absent from the candidate is a declared retirement only when every authority behind its declarations and behind its target declares deletion on a complete, current snapshot. Anything else refuses the candidate and names the relation keys it would have retired. An approval lifts the refusal only when it names this exact candidate, component set and relation set.
- **Evidence command.** `python -m app.recsys.relation_evidence` builds the catalogue exactly as the ingest does and writes a report of counts, unresolved references, sample relations with evidence and, given a previous export, the relation diff and the gate's verdict. It opens no database, calls no gateway and computes no embedding.

Unchanged: no new link type and no contract change. The resolver is untouched, so there is still no prefix or similarity matching. Every route, the status readers' per-type counts and the publication path are untouched too.

## How to verify

1. Unit tests: `tests/recsys/registry/relations/*.py`. The Postgres-tier store test runs where the test database is configured. CI runs them.
2. Run the evidence command against the pre-production export and the skills checkout. For every link type, declared occurrences equal accepted plus unresolved, and the unresolved references are grouped by outcome and reason.
3. Ingest twice from the same sources. Every relation key and every evidence digest stays the same.
4. Negative case: build a candidate that drops a declaration while the captures declare that absence is not deletion. The gate refuses it and names the relation key.

## Not in this PR

- **A production caller for the gate.** Until publication goes through the gate, the evidence command is the only path that evaluates the retirement rule end to end. Today's captures declare that absence is not deletion, so any dropped declaration would be refused.
- **Out-of-scope and type-mismatch outcomes.** The resolver reports both as missing today. Telling them apart is a resolver change.
- **Tool-to-server mapping.** Consumed from the owner rules, never derived here.
- **An API for the counts.** They appear in the ingest summary and the evidence report only.

## Review focus

- Relation key material: the component ids already fold in the publication scope, so the key adds nothing else.
- Retirement requires both the declaring and the target authorities to declare deletion on complete, current snapshots. Is that too strict for the first real refresh?
- Which raw tokens are shown as digests.

## CI

- The checks posted on this head are the result.
