"""Ordering of the versions of one item and the supersession that follows from it."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date, datetime
from itertools import pairwise

from kp.domain import ApprovalState, SourceItemVersion
from kp.domain.clause_ref import edition_sort_key

LIVE_STATES: frozenset[ApprovalState] = frozenset(
    {ApprovalState.ADMITTED, ApprovalState.SUPERSEDED}
)

OrderKey = tuple[date, datetime, tuple[tuple[int, int, str], ...]]


@dataclass(frozen=True)
class Supersession:
    """An older version that a newer one replaces from ``when``."""

    older: SourceItemVersion
    newer: SourceItemVersion
    when: date


def order_key(version: SourceItemVersion) -> OrderKey:
    """Position of a version among the versions of its item.

    The effective date wins, then the source's modification date, then the fetch date. Load
    time only breaks ties, so a backfilled older edition never replaces a newer one. The
    version label is the last tiebreak and compares in natural order (``10`` after ``9``).

    :param version: Any version
    :return: A sortable key; later versions sort higher
    """
    when = (
        version.effective_date
        or (version.modified_at.date() if version.modified_at else None)
        or version.fetched_at.date()
    )
    return (when, version.fetched_at, edition_sort_key(version.version))


def plan_supersession(versions: Sequence[SourceItemVersion], today: date) -> list[Supersession]:
    """Work out which live versions are now replaced by a newer live one.

    A version already carrying a ``superseded_at`` keeps it. The replacement date is the
    newer version's effective date, or ``today`` when that version has none.

    :param versions: Every version of one item
    :param today: The date to use when the newer version names no effective date
    :return: One entry per older version that still lacks a supersession date
    """
    live = sorted((v for v in versions if v.approval_state in LIVE_STATES), key=order_key)
    return [
        Supersession(older, newer, newer.effective_date or today)
        for older, newer in pairwise(live)
        if older.superseded_at is None
    ]
