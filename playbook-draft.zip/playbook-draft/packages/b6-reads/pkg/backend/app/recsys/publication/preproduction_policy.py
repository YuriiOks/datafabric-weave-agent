"""Pre-production read policy over an explicit reader allow-list.

The bounded reader asks a ``ReadPolicyPort`` about every node and every relation it
walks, and again before it answers. Until the entitlement service exists, pre-production
answers from a reader allow-list: a listed principal may see every component of the one
pre-production scope and traverse every traversable relation in it; anyone else sees
nothing, and no other scope is answered at all.

The list comes from configuration, so revoking a reader is a configuration change. The
revision names the list, which makes a cursor opened under an earlier list fail as a
changed policy rather than resume. Production is refused when the policy is built.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterable

from app.recsys.contracts import LinkType, PublicationScope, SourceEnvironment

from .models import TRAVERSABLE_LINK_TYPES

POLICY_NAME = "preproduction-readers-1"


def parse_readers(raw: str) -> frozenset[str]:
    """Split a comma-separated reader list, ignoring blanks.

    :param raw: The configured list.
    :return: The principal ids.
    """
    return frozenset(part.strip() for part in raw.split(",") if part.strip())


class PreproductionReadPolicy:
    """``ReadPolicyPort`` for one principal in the one pre-production scope."""

    def __init__(
        self,
        *,
        scope: PublicationScope,
        principal_id: str,
        readers: Iterable[str],
    ) -> None:
        """Create the policy.

        :param scope: The only scope it answers for; must be pre-production.
        :param principal_id: The server-derived caller.
        :param readers: Principal ids allowed to read the publication.
        :raises ValueError: Outside pre-production or with no readers.
        """
        if scope.environment is not SourceEnvironment.ppd:
            raise ValueError("pre-production read policy is refused outside ppd")
        allowed = frozenset(reader.strip() for reader in readers if reader.strip())
        if not allowed:
            raise ValueError("pre-production read policy requires at least one reader")
        self._scope = scope
        self._principal_id = principal_id.strip()
        self._readers = allowed
        listing = "\n".join(
            [scope.environment.value, scope.partition, *sorted(allowed)]
        ).encode("utf-8")
        self._revision = f"{POLICY_NAME}:{hashlib.sha256(listing).hexdigest()[:32]}"

    @property
    def revision(self) -> str:
        """:return: The policy name and a digest of the scope and the reader list."""
        return self._revision

    @property
    def admits_caller(self) -> bool:
        """:return: Whether the caller is a listed reader."""
        return self._principal_id in self._readers

    async def may_see_component(self, component_id: str, *, scope: PublicationScope) -> bool:
        """:param component_id: The component being considered.
        :param scope: The scope the component is being read in.

        :return: Whether the caller is a listed reader asking in the configured scope.
        """
        return scope == self._scope and self.admits_caller

    async def may_traverse(self, link_type: LinkType, *, scope: PublicationScope) -> bool:
        """:param link_type: The relation being considered.
        :param scope: The scope the relation is being read in.

        :return: Whether a listed reader may follow this relation in the configured scope.
        """
        return (
            scope == self._scope
            and self.admits_caller
            and link_type in TRAVERSABLE_LINK_TYPES
        )
