"""Helpers for the search tests: seeding the database with the synthetic rulebook."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime

from sqlalchemy import Connection, insert

from kp.clock import FixedClock
from kp.domain import ApprovalState, Passage, SourceKind
from kp.search import Embedder, PassageStore, SearchService, SearchSettings
from kp.store import Database
from kp.store.schema import clause, edition, run, source_item
from kp.testing.dataset import SyntheticDataset

DOMAIN = "payments"
RULEBOOK_ITEM = "payments-rulebook"
RUN_ID = "run-test"
FETCHED = datetime(2026, 1, 1, tzinfo=UTC)


def add_run(connection: Connection) -> None:
    """Insert the run that source items reference."""
    connection.execute(
        insert(run).values(
            run_id=RUN_ID,
            kind="sweep",
            sources=[],
            started_at=FETCHED,
            outcome="succeeded",
            items_touched=0,
        )
    )


def add_source_item(
    connection: Connection,
    source: SourceKind,
    item_id: str,
    version: str,
    *,
    state: ApprovalState = ApprovalState.ADMITTED,
    domain: str | None = DOMAIN,
    effective_date: date | None = None,
    superseded_at: date | None = None,
    withdrawn_at: date | None = None,
    authority: str | None = None,
    modified_at: datetime | None = None,
) -> None:
    """Insert one approved (or otherwise stated) source item version."""
    connection.execute(
        insert(source_item).values(
            source=source.value,
            item_id=item_id,
            version=version,
            native_id=item_id,
            content_sha256="0" * 64,
            media_type="text/markdown",
            title=item_id,
            raw_location="raw",
            fetched_at=FETCHED,
            run_id=RUN_ID,
            extraction_status="not_required",
            approval_state=state.value,
            effective_date=effective_date,
            superseded_at=superseded_at,
            withdrawn_at=withdrawn_at,
            domain=domain,
            authority=authority,
            modified_at=modified_at,
            machine_authored=False,
        )
    )


def add_edition(
    connection: Connection,
    dataset: SyntheticDataset,
    label: str,
    *,
    item_id: str = RULEBOOK_ITEM,
    state: ApprovalState = ApprovalState.ADMITTED,
    domain: str | None = DOMAIN,
    withdrawn_from: date | None = None,
) -> None:
    """Insert an edition of the synthetic rulebook with all its clauses."""
    truth = dataset.truth.edition(label)
    add_source_item(
        connection, SourceKind.REGULATORY_REPO, item_id, label, state=state, domain=domain
    )
    connection.execute(
        insert(edition).values(
            label=label,
            effective_date=truth.effective_date,
            superseded_from=truth.superseded_from,
            withdrawn_from=withdrawn_from,
            title="Payments Rulebook",
            source=SourceKind.REGULATORY_REPO.value,
            item_id=item_id,
            version=label,
        )
    )
    connection.execute(
        insert(clause),
        [
            {
                "edition": label,
                "number": c.number,
                "title": c.title,
                "page": c.page,
                "char_start": c.md_char_start,
                "char_end": c.md_char_end,
                "text": c.text,
                "structure_score": 1.0,
                "parent_number": c.number.rsplit(".", 1)[0] if "." in c.number else None,
            }
            for c in truth.clauses
        ],
    )


def save_passages(connection: Connection, passages: list[Passage]) -> None:
    """Store passages grouped by item version."""
    store = PassageStore(connection)
    groups: dict[tuple[SourceKind, str, str], list[Passage]] = {}
    for passage in passages:
        groups.setdefault((passage.source, passage.item_id, passage.version), []).append(passage)
    for (source, item_id, version), group in groups.items():
        store.replace_item(source, item_id, version, group)


@dataclass(frozen=True)
class SearchWorld:
    """A seeded database plus the objects tests need to query it."""

    database: Database
    dataset: SyntheticDataset
    clock: FixedClock

    def service(
        self, settings: SearchSettings | None = None, embedder: Embedder | None = None
    ) -> SearchService:
        """Build a search service on the seeded database."""
        return SearchService(self.database, self.clock, settings, embedder)

    def markdown(self, label: str) -> str:
        """The source Markdown of one edition."""
        return self.dataset.path(self.dataset.truth.edition(label).markdown_path).read_text(
            encoding="utf-8"
        )
