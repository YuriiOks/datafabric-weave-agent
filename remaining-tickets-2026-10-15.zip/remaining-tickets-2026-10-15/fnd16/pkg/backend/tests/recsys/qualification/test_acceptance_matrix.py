"""Acceptance matrix: complete, consistent, honest about blockers, and never passed."""

from __future__ import annotations

import unittest
from pathlib import Path

from app.recsys.qualification.acceptance import ACCEPTANCE_MATRIX, BLOCKERS
from app.recsys.qualification.matrix import (
    ARCHITECTURE_SCENARIOS,
    DELAYED_SOURCE_CASES,
    REFRESH_CASES,
    AcceptanceMatrix,
    AcceptanceMode,
    AcceptanceRow,
    EvidenceKind,
    OwnerRole,
    RequirementSource,
    RowStatus,
    completion_blockers,
    status_counts,
)
from app.recsys.qualification.render import NO_PASS_STATEMENT, render_matrix

BACKEND_ROOT = Path(__file__).resolve().parents[3]

#: Rows that need a validated candidate from a real refresh.
NEEDS_CANDIDATE = ("A05", "A06", "A07", "A08", "A14", "A17", "A18", "A18-age", "A19")


def _row(requirement_id: str = "A01", **values) -> AcceptanceRow:
    values.setdefault("source", RequirementSource.architecture_scenario)
    values.setdefault("title", "Synthetic requirement")
    values.setdefault("observable_result", "Something observable happens.")
    values.setdefault("owner_role", OwnerRole.contracts_owner)
    values.setdefault("evidence_kind", EvidenceKind.ci_job)
    values.setdefault("status", RowStatus.planned)
    return AcceptanceRow(requirement_id=requirement_id, **values)


def _required_rows() -> list[AcceptanceRow]:
    ids = ARCHITECTURE_SCENARIOS + REFRESH_CASES + DELAYED_SOURCE_CASES
    return [_row(key) for key in ids]


class CommittedMatrixTests(unittest.TestCase):
    def test_every_required_case_is_listed_once(self) -> None:
        ids = [row.requirement_id for row in ACCEPTANCE_MATRIX.rows]
        self.assertEqual(len(ids), len(set(ids)))
        for key in ARCHITECTURE_SCENARIOS + REFRESH_CASES + DELAYED_SOURCE_CASES:
            self.assertIn(key, ids)

    def test_no_row_can_read_as_passed(self) -> None:
        self.assertEqual(
            {status.value for status in RowStatus}, {"planned", "not_run", "blocked"}
        )
        with self.assertRaises(ValueError):
            _row(status="passed")

    def test_cited_tests_exist(self) -> None:
        cited = ACCEPTANCE_MATRIX.cited_tests()
        self.assertTrue(cited)
        for reference in cited:
            self.assertTrue((BACKEND_ROOT / reference).is_file(), reference)

    def test_rows_needing_a_validated_candidate_are_blocked_by_the_registrations(
        self,
    ) -> None:
        for key in NEEDS_CANDIDATE + ("R05", "R06"):
            row = ACCEPTANCE_MATRIX.row(key)
            self.assertIs(row.status, RowStatus.blocked, key)
            self.assertTrue({"B1", "B2", "B4"} <= set(row.blocked_by), key)

    def test_delayed_source_cases_name_their_own_blockers(self) -> None:
        self.assertIn("B3", ACCEPTANCE_MATRIX.row("A18").blocked_by)
        self.assertIn("B5", ACCEPTANCE_MATRIX.row("A18-age").blocked_by)
        self.assertEqual(ACCEPTANCE_MATRIX.row("A18-order").blocked_by, ("B2",))

    def test_blockers_stay_listed_even_when_no_row_cites_them(self) -> None:
        self.assertEqual(
            [blocker.blocker_id for blocker in BLOCKERS],
            ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "Q1", "Q2"],
        )
        self.assertEqual(ACCEPTANCE_MATRIX.blocked_rows("B8"), ())

    def test_parent_completion_is_blocked_for_every_row(self) -> None:
        graph = [row for row in ACCEPTANCE_MATRIX.rows if row.mode is AcceptanceMode.graph]
        reasons = completion_blockers(ACCEPTANCE_MATRIX)
        self.assertEqual(len(reasons), len(graph))
        self.assertIn("A16 has no recorded run", reasons)
        self.assertIn("A01 has no evidence yet", reasons)
        everything = completion_blockers(ACCEPTANCE_MATRIX, AcceptanceMode.recommendation)
        self.assertEqual(len(everything), len(ACCEPTANCE_MATRIX.rows))
        self.assertIn("G06 blocked by Q2", everything)

    def test_status_counts_cover_the_selected_delivery(self) -> None:
        graph = status_counts(ACCEPTANCE_MATRIX, AcceptanceMode.graph)
        every = status_counts(ACCEPTANCE_MATRIX)
        self.assertEqual(sum(every.values()), len(ACCEPTANCE_MATRIX.rows))
        self.assertEqual(sum(every.values()) - sum(graph.values()), 2)


class MatrixValidationTests(unittest.TestCase):
    def test_a_missing_required_case_is_refused(self) -> None:
        rows = [row for row in _required_rows() if row.requirement_id != "A18-order"]
        with self.assertRaisesRegex(ValueError, "required cases missing: A18-order"):
            AcceptanceMatrix(rows=tuple(rows))

    def test_a_repeated_requirement_is_refused(self) -> None:
        rows = _required_rows() + [_row("A07")]
        with self.assertRaisesRegex(ValueError, "requirements listed twice: A07"):
            AcceptanceMatrix(rows=tuple(rows))

    def test_an_unknown_blocker_is_refused(self) -> None:
        rows = _required_rows()
        rows[0] = _row("A01", status=RowStatus.blocked, blocked_by=("Z9",))
        with self.assertRaisesRegex(ValueError, "unknown blockers: Z9"):
            AcceptanceMatrix(rows=tuple(rows))

    def test_the_minimal_complete_matrix_is_accepted(self) -> None:
        matrix = AcceptanceMatrix(rows=tuple(_required_rows()))
        self.assertEqual(len(matrix.rows), 28)
        with self.assertRaises(KeyError):
            matrix.row("G09")


class RowValidationTests(unittest.TestCase):
    def test_blockers_appear_exactly_when_blocked(self) -> None:
        with self.assertRaises(ValueError):
            _row(status=RowStatus.blocked)
        with self.assertRaises(ValueError):
            _row(blocked_by=("B1",))
        with self.assertRaises(ValueError):
            _row(status=RowStatus.blocked, blocked_by=("B1", "B1"))

    def test_a_row_ready_to_run_names_its_evidence(self) -> None:
        with self.assertRaises(ValueError):
            _row(status=RowStatus.not_run)
        row = _row(status=RowStatus.not_run, evidence_reference="ci-job-1")
        self.assertIs(row.status, RowStatus.not_run)

    def test_a_test_reference_is_a_test_path(self) -> None:
        with self.assertRaises(ValueError):
            _row(evidence_kind=EvidenceKind.existing_test, evidence_reference="app/x.py")
        row = _row(
            evidence_kind=EvidenceKind.existing_test,
            evidence_reference="tests/recsys/x/test_y.py",
        )
        self.assertEqual(row.evidence_reference, "tests/recsys/x/test_y.py")

    def test_requirement_ids_follow_the_sources(self) -> None:
        for bad in ("A00", "A20", "R08", "G00", "a01", "A18_age"):
            with self.assertRaises(ValueError, msg=bad):
                _row(bad)


class RenderTests(unittest.TestCase):
    def test_render_lists_rows_blockers_and_ends_without_a_pass(self) -> None:
        text = render_matrix(ACCEPTANCE_MATRIX)
        self.assertIn("| A18-order |", text)
        self.assertIn("| B1 |", text)
        self.assertIn("`tests/recsys/refresh/test_runtime.py`", text)
        self.assertNotIn("| G06 |", text)
        self.assertTrue(text.rstrip().endswith(NO_PASS_STATEMENT))

    def test_recommendation_render_adds_its_gates(self) -> None:
        text = render_matrix(ACCEPTANCE_MATRIX, AcceptanceMode.recommendation)
        self.assertIn("| G06 |", text)
        self.assertIn("# Acceptance matrix: recommendation delivery", text)

    def test_cells_escape_pipes(self) -> None:
        row = _row("A01", title="left | right")
        rows = [row] + [item for item in _required_rows() if item.requirement_id != "A01"]
        text = render_matrix(AcceptanceMatrix(rows=tuple(rows)))
        self.assertIn("left \\| right", text)
