---
name: km-pr
description: "Checklist, then push and draft pull request, for a task branch in a work tree in /home/user/km. Use when the owner asks to push or to open or refresh a pull request. Running it is the owner's go for that task."
argument-hint: <task id, work tree path or clone folder name>
disable-model-invocation: true
---

# km-pr

Starting this skill is the owner's go (decision of 10 Nov) for this task: after the checks
it pushes the task branch with a plain push and opens or refreshes the draft pull request.
Nothing else is posted. $0 names where the work is: a task id (work tree
/home/user/km/work/wt/<task>), a work tree path, or a clone folder name under /home/user/km.
Call that folder <dir>, and the clone it belongs to <clone>
(`git rev-parse --git-common-dir` from a work tree). If $0 is missing, list the work trees
(`git -C <clone> worktree list`) and clones with commits ahead of upstream; one candidate: use
it; several: ask which. Run name: km-pr-<name>-<date>. Stop at the first failure, report it
in one line, and change nothing. Steps 1 to 7 are read-only; step 8 is the only write.
The branch must be feat/... and not main; anything else is a stop.

1. Branch. In a separate call, cd to <dir>; check with `pwd`. Run `git status -sb`. The tree
   is clean, the branch is not the default branch, and in a work tree the branch is the task's
   own `feat/...` branch. For a clone folder the branch must be named in a work/builds/*.md
   record or a plan header; otherwise ask the owner to name it before step 8. If the remote
   branch exists, `git log origin/<branch> --not <base> --format=%ae` shows only the owner's
   commits; others' commits are a stop. The base is origin/main for a work tree; for a
   clone, upstream, else
   the remote default branch. If unclear, ask the owner. Then `git fetch origin` (read-only)
   and `git log HEAD..origin/main --oneline`: if main has moved, it comes in by merge commit
   before the push (no rebase); report it as a stop and tell the owner.
2. Paths. `git diff --name-only <base>...HEAD`. No path under .claude or .github. No harness
   file: copies of AGENTS.md or CLAUDE.md, START.md, start.sh, anything from kb/, designs/ or
   work/, skills, agents, names or claims files.
3. Secrets. List files whose diff matches secret-shaped text, names only, never the match:
   `git diff --name-only -i -G'(password|secret|token|api[_-]?key|private key)' <base>...HEAD`
   and the same with an email pattern. Look at each file listed and decide. A credential,
   key, token, staff id or email address in the diff is a stop.
4. Commits. `git log --format='%h %s' <base>..HEAD`. Each commit is one logical step with a
   one-line message. History was not amended or rebased; the main line comes in by merge commit.
   No session link line and no typed attribution line: one found is a stop, tell the
   owner, no amend. A tool-credit line the environment forces despite the settings is
   left in place and named to the owner once; it does not stop the push.
5. Guard. The session folder is not a git repository, so every gh command and the guard
   run in a subshell: `(cd <dir> && /home/user/km/.claude/bin/pre-push-guard.sh --check)`,
   by its full path (if it is not
   executable, `bash` with the same path). Show its output to the owner. Anything other than
   a pass is a stop.
6. Pull request text. Read
   ${CLAUDE_SKILL_DIR}/references/pr-text.md and check the draft against it. If the owner
   has no draft, write one to work/builds/<task>-pr.md from
   ${CLAUDE_SKILL_DIR}/references/pr-body.md (title, body order, Self-review and Checks from
   real results only). If the diff changes what people see on screen, also read
   ${CLAUDE_SKILL_DIR}/references/screenshots.md, list the views the owner should capture,
   and check the draft's `## Screenshots` section. Keys in the title come from the owner, the
   plan's Keys line or kb/private/. Unknown keys: step 8 pushes but does not open the pull request.
   With a ticket key, read the ticket with the session's ticket read tool (read-only) and
   check the draft against its wording; ask the owner only if the tool is missing or the
   read fails, then mark acceptance Unverified. The draft stays a file until step 8.
7. Levels. For a work tree with a task id, read work/builds/<task>.md and
   work/reviews/<task>.md. List per level (1 builder checks, 2 tests, 3 and 4 review, 5 fix
   round, 6 advisor) the real result, and every finding still open. A failed check, an open
   blocker, or a missing level-6 answer for a change touching access control, migrations or
   data deletion is a stop. If work/reviews/grill-<task>.md exists, list its open Must fix
   count; an open must-fix item is a stop unless the owner accepts it in one line.
   No such files: say so; the owner decides whether to go on.
   The owner may also run `/km-review diff <clone>` or `/km-code-review <task>` first; read
   its table if he did.
8. Push and draft pull request. Only after steps 1 to 7 pass.
   Check `git -C <dir> rev-parse --abbrev-ref
   HEAD` equals the branch and `git -C <dir> config branch.<branch>.merge` is not
   refs/heads/main. Push with an explicit destination, every time, never a bare push:
   `git -C <dir> push -u origin <branch>`. Never --force, --force-with-lease or --no-verify;
   never main, a tag or a delete; no
   variant if a prompt is denied (log "push pending", stop). Then, with the draft file
   (title line 1, body after): no pull request for the branch yet (`(cd <dir> && gh pr list
   --head <branch> --json number,headRefName,isDraft)`) and both keys known:
   `(cd <dir> && gh pr create --draft --base main --head <branch> --title "<title>"
   --body-file <draft file>)`. One exists (edit only if its headRefName equals the branch and
   it is a draft): refresh from the live body (`(cd <dir> && gh pr view <n> --json body)`,
   keep images) and `(cd <dir> && gh pr edit <n> --body-file <file>)`. The body has no
   session link or attribution line. Then read the checks for that exact head, read-only
   (`(cd <dir> && gh pr checks <n>)`), and put the state into the body's Checks section.
   Ready, merge, close, approve, reviewers, labels
   and ticket status stay the owner's. The work tree stays; only the owner removes it.

Record the run in kb/log.d/<run>.txt: date, dir, branch, head id, result of each check, the
push result, pull request number and check state. No knowledge file is written, so there
is no index.d entry.

If a command is denied or an approval prompt times out, log it and stop; never pick a
variant or a permanent allow.
End with a summary of at most 10 lines: one line per check as pass or stop, then the next action.
