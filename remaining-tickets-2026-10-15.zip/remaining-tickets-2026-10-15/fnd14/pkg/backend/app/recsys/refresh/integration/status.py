"""Refresh status port over the publication pointer.

Status reports the publication that is actually active in the scope, read from the
same pointer row activation writes, never from the job that last ran.
"""

from __future__ import annotations

from app.recsys.contracts import PublicationScope
from app.recsys.publication.repository import PublicationRepository
from app.recsys.refresh.models import CurrentPublicationStatus


class ActivePublicationStatusPort:
    """``PublicationStatusPort`` reading the active descriptor of a scope."""

    def __init__(self, repository: PublicationRepository) -> None:
        """Create the port.

        :param repository: The publication repository holding the pointer.
        """
        self._repository = repository

    async def current_publication(
        self,
        scope: PublicationScope,
    ) -> CurrentPublicationStatus | None:
        """Return the active publication of a scope, if there is one.

        The descriptor carries no configuration digest, so ``snapshot_id`` is the
        manifest digest of the catalogue snapshot the publication projects.

        :param scope: The scope to report.
        :return: The active publication, or ``None`` when nothing is active.
        """
        descriptor = await self._repository.active_descriptor(scope)
        if descriptor is None or descriptor.activated_at is None:
            return None
        return CurrentPublicationStatus(
            publication_uuid=descriptor.publication_uuid,
            catalogue_id=descriptor.catalogue_id,
            scope=descriptor.scope,
            snapshot_id=descriptor.manifest_digest,
            activated_at=descriptor.activated_at,
        )
