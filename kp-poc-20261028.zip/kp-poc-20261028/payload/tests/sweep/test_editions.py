"""US-02: a merged edition is used from its effective date; the older one is superseded."""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

from sqlalchemy import insert, select, update

from kp.domain import ApprovalState, ChangeKind, Edition, ItemKey, SourceKind, select_edition_as_at
from kp.domain.clause_ref import ClauseRef
from kp.store import schema as tables

from .conftest import Harness
from .support import ScriptedReader, edition_entry, entry

REPO = SourceKind.REGULATORY_REPO
EFFECTIVE_2026 = date(2026, 11, 16)


def _store_edition(harness: Harness, label: str, effective: date) -> None:
    """Insert the edition row the ingest lane would write for a stored edition."""
    with harness.database.transaction() as connection:
        connection.execute(
            insert(tables.edition).values(
                label=label,
                effective_date=effective,
                title="Payments Rulebook",
                source=REPO.value,
                item_id="payments-rulebook",
                version=label,
            )
        )


def _editions(harness: Harness) -> list[Edition]:
    with harness.database.transaction() as connection:
        rows = connection.execute(select(tables.edition)).mappings().all()
    return [
        Edition(
            label=r["label"],
            effective_date=r["effective_date"],
            superseded_from=r["superseded_from"],
            withdrawn_from=r["withdrawn_from"],
            item_id=r["item_id"],
            version=r["version"],
        )
        for r in rows
    ]


def test_us02_merged_edition_is_loaded_on_the_next_sweep(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(edition_entry(committed_fixtures_dir, "2026.1"))

    summary = harness.sweep(reader)

    edition = harness.version(REPO, "payments-rulebook", "2026.1")
    assert edition.approval_state is ApprovalState.ADMITTED
    assert edition.effective_date == EFFECTIVE_2026
    assert [item.key.version for item in summary.work_items] == ["2026.1"]


def test_us02_older_edition_is_superseded_from_the_new_effective_date_and_stays_available(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(edition_entry(committed_fixtures_dir, "2025.2"))
    harness.sweep(reader)
    _store_edition(harness, "2025.2", date(2025, 6, 2))
    reader.add(edition_entry(committed_fixtures_dir, "2026.1"))

    harness.sweep(reader)
    _store_edition(harness, "2026.1", EFFECTIVE_2026)

    older = harness.version(REPO, "payments-rulebook", "2025.2")
    assert older.superseded_at == EFFECTIVE_2026
    # Still in force on 1 Nov: the state only changes once the date arrives.
    assert older.approval_state is ApprovalState.ADMITTED
    assert harness.raw_store.get(older.raw_location)
    editions = _editions(harness)
    assert {e.label: e.superseded_from for e in editions}["2025.2"] == EFFECTIVE_2026
    before = select_edition_as_at(editions, date(2026, 11, 15))
    after = select_edition_as_at(editions, EFFECTIVE_2026)
    assert before is not None
    assert before.label == "2025.2"
    assert after is not None
    assert after.label == "2026.1"
    assert ChangeKind.SUPERSEDED in {event.kind for event in harness.events()}


def test_us02_supersession_keeps_a_withdrawal_date_the_edition_already_carries(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(edition_entry(committed_fixtures_dir, "2025.2"))
    harness.sweep(reader)
    _store_edition(harness, "2025.2", date(2025, 6, 2))
    with harness.database.transaction() as connection:
        connection.execute(
            update(tables.edition)
            .where(tables.edition.c.label == "2025.2")
            .values(withdrawn_from=date(2027, 1, 1))
        )
    reader.add(edition_entry(committed_fixtures_dir, "2026.1"))

    harness.sweep(reader)

    older = {e.label: e for e in _editions(harness)}["2025.2"]
    assert older.superseded_from == EFFECTIVE_2026
    assert older.withdrawn_from == date(2027, 1, 1)


def test_us04_withdrawn_edition_is_not_in_force_from_its_withdrawal_date(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(edition_entry(committed_fixtures_dir, "2025.2"))
    harness.sweep(reader)
    _store_edition(harness, "2025.2", date(2025, 6, 2))
    reader.add_deleted(REPO, "payments-rulebook", "2025.2")

    harness.sweep(reader)

    editions = _editions(harness)
    today = harness.clock.today()
    assert {e.label: e.withdrawn_from for e in editions} == {"2025.2": today}
    assert select_edition_as_at(editions, today) is None
    before = select_edition_as_at(editions, today - timedelta(days=1))
    assert before is not None
    assert before.label == "2025.2"
    # A clause citation resolves its edition, and the edition row says since when it is gone.
    cited = ClauseRef.parse("2025.2:3.1")
    assert {e.label: e for e in editions}[cited.edition].withdrawn_from == today


def test_us02_superseded_state_settles_when_the_effective_date_arrives(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(
        edition_entry(committed_fixtures_dir, "2025.2"),
        edition_entry(committed_fixtures_dir, "2026.1"),
    )
    harness.sweep(reader)
    harness.advance(days=15)
    assert harness.version(REPO, "payments-rulebook", "2025.2").approval_state is (
        ApprovalState.ADMITTED
    )

    harness.advance(days=1)
    harness.sweep(reader)

    assert harness.version(REPO, "payments-rulebook", "2025.2").approval_state is (
        ApprovalState.SUPERSEDED
    )
    assert harness.version(REPO, "payments-rulebook", "2026.1").approval_state is (
        ApprovalState.ADMITTED
    )


def test_us02_edition_backfilled_after_a_newer_one_never_replaces_it(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(edition_entry(committed_fixtures_dir, "2026.1"))
    harness.sweep(reader)
    reader.add(edition_entry(committed_fixtures_dir, "2025.2"))

    summary = harness.sweep(reader)

    assert harness.version(REPO, "payments-rulebook", "2026.1").superseded_at is None
    assert harness.version(REPO, "payments-rulebook", "2025.2").superseded_at == EFFECTIVE_2026
    assert [item.key.version for item in summary.work_items] == ["2025.2"]


def test_us02_unmerged_pull_request_loads_nothing(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    reader = ScriptedReader(REPO)
    reader.add(edition_entry(committed_fixtures_dir, "2026.1", merged=False))

    summary = harness.sweep(reader)

    assert harness.version(REPO, "payments-rulebook", "2026.1").approval_state is (
        ApprovalState.EXCLUDED
    )
    assert summary.work_items == ()
    assert harness.processor.processed == []


def test_us02_edition_without_an_effective_date_is_reported_not_loaded(harness: Harness) -> None:
    reader = ScriptedReader(REPO)
    reader.add(entry(REPO, "payments-rulebook", "2027.1", title="Payments Rulebook"))

    harness.sweep(reader)

    version = harness.version(REPO, "payments-rulebook", "2027.1")
    assert version.approval_state is ApprovalState.NON_CONFORMING
    (review,) = harness.reviews()
    assert review.missing_details == ("effective_date",)
    assert ItemKey(source=REPO, item_id="payments-rulebook", version="2027.1") not in (
        harness.processor.processed
    )
