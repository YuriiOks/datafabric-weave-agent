"""Seam: the read tools' coverage port, backed by the link service's coverage query."""

from __future__ import annotations

import logging
from datetime import UTC, date, datetime, time

from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError

from kp.adapters.domains import ItemDomains
from kp.clock import Clock
from kp.config import Thresholds
from kp.domain import ClauseRef, ItemRef, ItemType
from kp.links import LinkService
from kp.links import NoEditionInForceError as LinkNoEditionInForceError
from kp.links import RuleCoverage as LinkRuleCoverage
from kp.store import Database, schema
from kp.tools import (
    CoverageSnapshot,
    LinkStoreUnavailableError,
    NoEditionInForceError,
    RuleCoverage,
    StoryGap,
)

logger = logging.getLogger(__name__)


class LinkServiceCoveragePort:
    """Coverage of the rules in force, labelled with the domain of each rule and story.

    :param database: The platform database
    :param clock: Time source
    :param thresholds: Platform thresholds, passed on to the link service
    """

    def __init__(self, database: Database, clock: Clock, thresholds: Thresholds) -> None:
        self._database = database
        self._clock = clock
        self._thresholds = thresholds

    def snapshot(self, *, domains: frozenset[str], as_at: date) -> CoverageSnapshot:
        """Compute coverage for the rules in force on ``as_at`` and place each item in a domain.

        Items outside ``domains`` are counted, not listed.

        :param domains: Domains the caller may read
        :param as_at: The date the rules are read at
        :return: Per-rule coverage, story gaps and the number of items hidden
        :raises kp.tools.NoEditionInForceError: If no edition was in force on that date
        :raises kp.tools.LinkStoreUnavailableError: If the link store cannot be read
        """
        instant = datetime.combine(as_at, time.max, tzinfo=UTC)
        try:
            with self._database.transaction() as connection:
                service = LinkService(connection, thresholds=self._thresholds, clock=self._clock)
                try:
                    report = service.coverage(as_at=instant)
                except LinkNoEditionInForceError as exc:
                    raise NoEditionInForceError(str(exc)) from exc
                placer = ItemDomains(connection)
                summaries = dict(
                    connection.execute(
                        select(schema.story.c.story_key, schema.story.c.summary)
                    ).all()
                )
        except SQLAlchemyError as exc:
            logger.error("Link store could not be read")
            raise LinkStoreUnavailableError("The link store is unavailable") from exc
        rules = [
            _rule(entry, placer.of(_clause(entry.reference)))
            for entry in (*report.with_tests, *report.without_tests)
        ]
        gaps = [
            StoryGap(
                story_key=key,
                summary=summaries.get(key, ""),
                domain=placer.of(ItemRef(item_type=ItemType.STORY, key=key)),
            )
            for key in report.stories_without_requirement_or_clause
        ]
        visible_rules = [rule for rule in rules if rule.domain in domains]
        visible_gaps = [gap for gap in gaps if gap.domain in domains]
        return CoverageSnapshot(
            rules=tuple(visible_rules),
            story_gaps=tuple(visible_gaps),
            filtered_out=(len(rules) - len(visible_rules)) + (len(gaps) - len(visible_gaps)),
        )


def _clause(reference: str) -> ItemRef:
    return ItemRef(item_type=ItemType.CLAUSE, key=ClauseRef.parse(reference).format())


def _rule(entry: LinkRuleCoverage, domain: str | None) -> RuleCoverage:
    return RuleCoverage(
        reference=entry.reference,
        domain=domain,
        has_test=entry.has_test,
        linked_stories=entry.story_count,
        stated_links=entry.stated_links,
        guessed_links=entry.guessed_links,
    )
