"""Turns scores into stored guessed links: proposed, review-only, or not kept."""

from __future__ import annotations

import logging
from collections.abc import Sequence
from typing import Annotated

from pydantic import Field

from kp.config import Thresholds
from kp.domain import DomainModel, ItemType, Link, LinkKind, LinkState, Relation
from kp.links.candidate import LinkCandidate, conformance_violation
from kp.links.guessed.scoring import GuessItem, LinkScorer
from kp.links.stated.model import RejectedLink
from kp.links.store import SqlLinkStore

logger = logging.getLogger(__name__)


class GuessReport(DomainModel):
    """What one guessing run did.

    ``proposed`` links are used by queries (marked guessed); ``review`` links are only on
    the review list. Pairs scoring below the review threshold are counted in ``dropped``
    and not kept. ``guessed_share`` is the guessed share of all links in use after the run.
    """

    proposed: tuple[Link, ...] = ()
    review: tuple[Link, ...] = ()
    dropped: int = 0
    already_stated: int = 0
    rejected: tuple[RejectedLink, ...] = ()
    guessed_share: Annotated[float, Field(ge=0, le=1)] = 0.0
    guessed_share_limit: Annotated[float, Field(ge=0, le=1)] = 0.5

    @property
    def share_within_limit(self) -> bool:
        """True when the guessed share does not exceed its limit."""
        return self.guessed_share <= self.guessed_share_limit


class GuessedLinkProposer:
    """Scores candidate pairs and stores the ones worth keeping.

    Score at or above ``link_proposed_min`` is stored as ``proposed`` with its score and
    evidence; from ``link_review_min`` up to that is stored as ``review`` (listed for a
    person, never used by queries); below it nothing is kept, and a guessed link that used
    to exist for the pair is closed. A pair that already has a stated link is left alone.

    :param store: Where links are kept
    :param scorer: How pairs are scored
    :param thresholds: The provisional score bands and the guessed-share limit
    """

    def __init__(self, store: SqlLinkStore, scorer: LinkScorer, thresholds: Thresholds) -> None:
        self._store = store
        self._scorer = scorer
        self._thresholds = thresholds

    def state_for(self, score: float) -> LinkState | None:
        """Place a score in its band.

        :param score: A 0-1 score
        :return: ``proposed``, ``review``, or ``None`` when the link is not kept
        """
        if score >= self._thresholds.link_proposed_min:
            return LinkState.PROPOSED
        if score >= self._thresholds.link_review_min:
            return LinkState.REVIEW
        return None

    def propose(
        self, relation: Relation, sources: Sequence[GuessItem], targets: Sequence[GuessItem]
    ) -> GuessReport:
        """Score every source against every target for one relation and store the outcome.

        :param relation: The relation the links would have
        :param sources: Items the links would start at
        :param targets: Items the links would end at
        :return: What was proposed, put up for review, dropped or refused
        """
        proposed: list[Link] = []
        review: list[Link] = []
        rejected: list[RejectedLink] = []
        dropped = already_stated = 0
        open_facts = self._store.open_facts(relation)
        violations: dict[tuple[ItemType, ItemType], str | None] = {}
        for source in sources:
            valid_targets = []
            for target in targets:
                pair = (source.ref.item_type, target.ref.item_type)
                if pair not in violations:
                    violations[pair] = conformance_violation(
                        LinkCandidate.guessed(
                            source.ref,
                            relation,
                            target.ref,
                            score=0.0,
                            state=LinkState.DROPPED,
                            evidence="",
                        )
                    )
                violation = violations[pair]
                if violation is None:
                    valid_targets.append(target)
                else:
                    rejected.append(
                        RejectedLink(
                            origin=f"{source.ref.key} {relation.value} {target.ref.key}",
                            reason=violation,
                        )
                    )
            for target, result in zip(
                valid_targets, self._scorer.score_all(source, valid_targets), strict=True
            ):
                existing = open_facts.get((source.ref, relation, target.ref))
                if existing is not None and existing.kind is LinkKind.STATED:
                    already_stated += 1
                    continue
                state = self.state_for(result.score)
                if state is None:
                    dropped += 1
                    if existing is not None:
                        self._store.close_fact(source.ref, relation, target.ref)
                    continue
                asserted = self._store.assert_link(
                    LinkCandidate.guessed(
                        source.ref,
                        relation,
                        target.ref,
                        score=result.score,
                        state=state,
                        evidence=result.evidence,
                    )
                )
                (proposed if state is LinkState.PROPOSED else review).append(asserted.link)
        share = self._store.statistics().guessed_share
        logger.info(
            "Guessed links stored",
            extra={
                "relation": relation.value,
                "proposed": len(proposed),
                "review": len(review),
                "dropped": dropped,
                "guessed_share": share,
            },
        )
        return GuessReport(
            proposed=tuple(proposed),
            review=tuple(review),
            dropped=dropped,
            already_stated=already_stated,
            rejected=tuple(rejected),
            guessed_share=share,
            guessed_share_limit=self._thresholds.guessed_share_max,
        )
