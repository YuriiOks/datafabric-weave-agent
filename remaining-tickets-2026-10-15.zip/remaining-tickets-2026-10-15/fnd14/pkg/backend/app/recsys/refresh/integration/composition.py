"""Pre-production composition of the refresh runtime over the registered sources.

Startup calls this only when refresh is enabled, no runtime was configured explicitly,
and the pre-production authority flag is set. It refuses production before touching
the database, then wires the registered workbook and skills sources, the catalogue
build, the graph publisher and the active-publication status into the existing job
framework. The worker is built only when the worker flag is set too.
"""

from __future__ import annotations

import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import Any
from uuid import uuid4

from app.recsys.acquisition import (
    AcquisitionService,
    GitAdapter,
    SourceRegistry,
    SubprocessGitRunner,
    WorkbookAdapter,
)
from app.recsys.acquisition.models import RegisteredSource
from app.recsys.config import RecsysSettings
from app.recsys.contracts import PublicationScope, SourceEnvironment
from app.recsys.contracts.sources import SourceAuthority
from app.recsys.publication.graph_store import CandidateGraphStore
from app.recsys.publication.publisher import GraphPublisher
from app.recsys.publication.repository import PublicationRepository
from app.recsys.reconcile_skills import (
    OperatorAskPassProvider,
    _git_executable,
    registered_git_source,
    registered_workbook_source,
)
from app.recsys.refresh.repository import RefreshRepository
from app.recsys.refresh.runtime import RefreshRuntime
from app.recsys.refresh.service import RefreshService
from app.recsys.refresh.worker import RefreshWorker

from .acquisition_source import AcquisitionSourceAdapter
from .authority import PreproductionAuthorityPort, parse_operators
from .catalogue_version import CapturedCatalogueVersion
from .configuration import RegisteredConfigurationPort
from .staging import ArtifactStaging
from .status import ActivePublicationStatusPort

CONFIGURATION_ID = "ppd-catalogue"
# Credential references name how a source is reached, never the credential itself:
# the skills remote through the operator's askpass helper, the workbook as a file
# inside the configured workspace.
_CREDENTIAL_REFERENCES = {
    SourceAuthority.skills_repo: "credential-ref:operator-askpass",
    SourceAuthority.agent_hub_export: "credential-ref:workspace-file",
}


def preproduction_settings(
    settings: RecsysSettings,
) -> tuple[PublicationScope, frozenset[str], Path]:
    """Validate the settings the pre-production composition needs.

    :param settings: The recsys settings.
    :return: The scope, the operator allow-list and the workspace root.
    :raises RuntimeError: If any requirement is unmet; nothing has been touched.
    """
    if not settings.recsys_refresh_preproduction_authority_enabled:
        raise RuntimeError("pre-production refresh authority is not enabled")
    if settings.recsys_refresh_environment != SourceEnvironment.ppd.value:
        raise RuntimeError("pre-production refresh authority is refused outside ppd")
    operators = parse_operators(settings.recsys_refresh_preproduction_operators)
    if not operators:
        raise RuntimeError(
            "pre-production refresh authority requires RECSYS_REFRESH_PREPRODUCTION_OPERATORS"
        )
    workspace = settings.recsys_refresh_workspace_root.strip()
    if not workspace:
        raise RuntimeError(
            "pre-production refresh authority requires RECSYS_REFRESH_WORKSPACE_ROOT"
        )
    scope = PublicationScope(
        environment=SourceEnvironment.ppd,
        partition=settings.recsys_refresh_partition,
    )
    return scope, operators, Path(workspace)


def compose_preproduction_runtime(
    settings: RecsysSettings,
    pool_factory: Callable[[], Any],
) -> RefreshRuntime:
    """Compose the refresh runtime for one pre-production scope.

    :param settings: The recsys settings.
    :param pool_factory: Returns the PostgreSQL pool; called only after the
        settings checks pass.
    :return: The runtime, with a worker when the worker flag is set.
    :raises RuntimeError: If the settings or the source registrations are unusable.
    """
    scope, operators, workspace = preproduction_settings(settings)

    def load_sources() -> tuple[RegisteredSource, ...]:
        return (registered_workbook_source(workspace), registered_git_source())

    try:
        sources = load_sources()
    except (OSError, ValueError) as error:
        raise RuntimeError(
            f"registered refresh sources are unavailable ({type(error).__name__})"
        ) from error
    if any(source.scope != scope for source in sources):
        raise RuntimeError("registered refresh sources do not belong to the configured scope")
    configurations = RegisteredConfigurationPort(
        configuration_id=CONFIGURATION_ID,
        load_sources=load_sources,
        credential_references={
            source.source_id: _CREDENTIAL_REFERENCES[source.authority] for source in sources
        },
    )
    snapshot = configurations.current_snapshot()
    authority = PreproductionAuthorityPort(
        scope=scope,
        operators=operators,
        configurations=configurations,
    )
    pool = pool_factory()
    service = RefreshService(
        RefreshRepository(pool),
        authority=authority,
        configurations=configurations,
        publication_status=ActivePublicationStatusPort(PublicationRepository(pool)),
    )
    if not settings.recsys_refresh_worker_enabled:
        return RefreshRuntime(service=service)

    staging = ArtifactStaging(Path(tempfile.mkdtemp(prefix="recsys-refresh-")))
    acquisition = AcquisitionService(
        registry=SourceRegistry(sources),
        workbook_adapter=WorkbookAdapter(),
        git_adapter=GitAdapter(
            runner=SubprocessGitRunner(git_executable=_git_executable()),
            credential_provider=OperatorAskPassProvider(),
        ),
    )
    adapters = {
        source.source_id: AcquisitionSourceAdapter(
            source_id=source.source_id,
            service=acquisition,
            staging=staging,
        )
        for source in sources
    }
    publisher = GraphPublisher(pool, _graph_store(), CapturedCatalogueVersion(pool, staging))
    worker = RefreshWorker(
        RefreshRepository(pool),
        worker_id=uuid4(),
        snapshot=snapshot,
        adapters=adapters,
        publisher=publisher,
        authority=authority,
        configurations=configurations,
        scan_interval_seconds=float(settings.recsys_refresh_scan_interval_seconds),
        heartbeat_seconds=float(settings.recsys_refresh_heartbeat_seconds),
    )
    return RefreshRuntime(service=service, worker=worker, on_close=staging.clear)


def _graph_store() -> CandidateGraphStore:
    # Imported here: the hub settings require the hub's environment, which the
    # settings checks above must not depend on.
    from app.config import settings as hub_settings

    return CandidateGraphStore(
        host=hub_settings.falkordb_host,
        port=hub_settings.falkordb_port,
        username=hub_settings.falkordb_username or None,
        password=hub_settings.falkordb_password or None,
    )
