# Task templates for /km-build

A subagent sees none of this conversation. Paste the content; name a path only as an input to
read. Never write "read <file> and do what it says". Each task ends with the line: "Work
carefully and check your own result before you reply." Replace <...>; keep the headings.

## Builder (km-build-<layer>), first try
```
goal: implement slice <Sn> of task <id>: <the Does text of the slice>
tree: /home/user/km/work/wt/<id> (the only place you change files)
inputs: the conventions file <full path: plan's Conventions folder + <layer>.md> (read it
  first); the baseline check results <pasted from the build file>; slice and contracts below
owned paths: <exact paths>. Change nothing else. If another file is needed, stop and say so.
slice: <the whole row of the plan>
contracts: <the entries of the plan this slice produces or consumes, exact shapes>
checks: <the Check column: lint, type and test commands, and the named tests>
reply: files changed; each check run with its command and real result; what is not done;
  questions; new dependencies (none unless stated); decisions (non-trivial choices, one line
  each, with the alternative)
skip: git writes, env and credential files, anything outside the owned paths
```
Partial work from an earlier run may exist in the tree: add "the tree may already hold partial
work for this slice: look at `git status` and the owned files first, then complete it".

## Builder, retry or fix
Same header, plus:
```
problem: <failed check output, or findings: id, severity, path:line, what breaks, fix>
attempt: <2 or 3>. Change only what the problem needs. Report each finding as fixed,
  not fixed (why) or not a bug (evidence path:line).
known failures: <matching entries of kb/errors.md, or "none">
never weaken, skip, delete or loosen a test or check to pass, and never suppress an error;
  if a test is wrong, say so with path:line evidence and stop.
```
After advice, add the advisor's recommendation as a quote and say it decides the approach.

## km-test (level 2)
```
goal: make sure slice <Sn> of task <id> has tests for every behaviour it changes, and that they pass
tree: /home/user/km/work/wt/<id>
inputs: <full path of the layer's conventions file>; the changed files (paths below); the slice
  and its Tests column pasted below
write: test files only, under <test paths from the slice>
run: the named tests and the layer test command for those files; no whole suite unless the
  conventions file says one command covers it
reply: tests added or changed; each command with its real result; failures with
  path:line and whether the fault is in the source or in a test; what could not be run
```

## km-advisor
```
goal: <go or no-go on task <id> | choose between option A and B for ... | decide why slice
  <Sn> keeps failing>. Trigger: <A, B, C or D>
inputs: the paths to read: plan /home/user/km/work/plans/<id>.md, build file, review report
  /home/user/km/work/reviews/<id>.md, tree /home/user/km/work/wt/<id> (git diff and git log
  against origin/main only), conventions files
question: <one question>
evidence: <path:line facts, check outputs, what each side claims>
reply: recommendation; reason; what would change your mind; risk of the other option
skip: editing anything; any command except read-only git diff and git log
```
Trigger B: run km-verifier first on the disputed claims (at most 15, one sentence each, the
clone path) and paste its table as evidence.

## km-code-review round
Read and follow /home/user/km/.claude/skills/km-code-review/SKILL.md and references/routing.md
(the Skill tool cannot call it); this skill only adds: name <id> and tag r1 or r2.
