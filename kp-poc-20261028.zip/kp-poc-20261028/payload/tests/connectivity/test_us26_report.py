"""US-26: the exit-criteria report. A hop without evidence is never a pass."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from connectivity.support import Stack
from kp.config import Mode
from kp.connectivity import (
    Evidence,
    ExitReport,
    GatewayForbiddenError,
    build_report,
    collect_evidence,
    render_markdown,
)
from kp.connectivity.evidence import ItemEvidence
from kp.connectivity.models import ItemStatus, RunActivity, RunResult
from kp.connectivity.report import LOCAL_VERDICT, Cell, HopRow, HopVerdict
from kp.connectivity.scoring import percentile, score_criteria
from kp.domain import ExitResult, McpCallRecord, RunOutcome, SourceKind
from kp.domain.base import DomainModel
from kp.errors import SourceAuthRefusedError

NAMESPACES = {
    SourceKind.CONFLUENCE: "confluence",
    SourceKind.JIRA: "jira",
    SourceKind.GITHUB: "github",
}
ALL = tuple(f"X-{n:02d}" for n in range(1, 12))


def _evidence(stack: Stack, mode: Mode = Mode.LOCAL) -> Evidence:
    return collect_evidence(
        database=stack.database,
        mode=mode,
        namespaces=NAMESPACES,
        sample_total=9,
        ledger_dir=stack.ledger_dir,
        signatures=stack.signatures,
        raw_store=stack.raw,
        markdown_store=stack.markdown,
    )


def _prove(stack: Stack) -> None:
    runner = stack.runner()
    runner.discover()
    runner.run()
    runner.run()
    runner.probe_errors()


def _by_id(report: ExitReport) -> dict[str, ExitResult]:
    return {criterion.id: criterion.result for criterion in report.criteria}


def _detail(report: ExitReport, criterion_id: str) -> str:
    return next(c.detail for c in report.criteria if c.id == criterion_id)


def _hop(report: ExitReport, name: str) -> HopRow:
    return next(hop for hop in report.hops if hop.hop == name)


def _empty(mode: Mode = Mode.REAL) -> Evidence:
    return Evidence(mode=mode, namespaces=NAMESPACES, sample_total=9)


def _call(namespace: str, operation: str = "tools/call", **overrides: object) -> McpCallRecord:
    values: dict[str, object] = {
        "call_id": f"c-{id(overrides)}-{namespace}-{operation}",
        "run_id": "r1",
        "tool": f"{namespace}/get_page",
        "operation": operation,
        "request_digest": "0" * 64,
        "http_status": 200,
        "latency_ms": 10.0,
        "surviving_fields": ("id",),
        "called_at": "2026-11-01T09:30:00+00:00",
    }
    values.update(overrides)
    return McpCallRecord.model_validate(values)


def test_us26_without_any_evidence_nothing_passes() -> None:
    report = build_report(_empty())

    assert set(_by_id(report).values()) == {ExitResult.INCONCLUSIVE}
    assert tuple(_by_id(report)) == ALL
    assert {hop.verdict for hop in report.hops} == {HopVerdict.NOT_PASSED}
    assert _hop(report, "jira").reachable is Cell.NO_EVIDENCE
    assert "A hop without evidence is not a pass" in report.verdict


def test_us26_local_verdict_says_the_harness_is_proven_and_the_platform_is_not(
    stack: Stack,
) -> None:
    _prove(stack)

    report = build_report(_evidence(stack))

    assert report.verdict.startswith(LOCAL_VERDICT)
    passed = {cid for cid, result in _by_id(report).items() if result is ExitResult.PASS}
    inconclusive = {
        cid for cid, result in _by_id(report).items() if result is ExitResult.INCONCLUSIVE
    }
    assert passed == {"X-03", "X-04", "X-05", "X-07", "X-08", "X-09"}
    assert inconclusive == {"X-01", "X-02", "X-06", "X-10", "X-11"}
    assert "Stand-in evidence only" in _detail(report, "X-01")
    assert {hop.verdict for hop in report.hops} == {HopVerdict.NOT_PASSED}


def test_us26_each_source_hop_records_the_four_facts_and_the_time(stack: Stack) -> None:
    _prove(stack)

    report = build_report(_evidence(stack))

    for name in ("confluence", "jira", "github"):
        hop = _hop(report, name)
        assert (hop.reachable, hop.authenticated, hop.entitled, hop.fields_survived) == (
            Cell.YES,
            Cell.YES,
            Cell.YES,
            Cell.YES,
        )
        assert hop.p50_ms is not None


def test_us26_on_the_real_route_the_same_evidence_can_pass_the_hops(stack: Stack) -> None:
    _prove(stack)

    report = build_report(_evidence(stack, Mode.REAL))

    results = _by_id(report)
    assert [cid for cid in ALL if results[cid] is ExitResult.PASS] == [
        "X-01", "X-02", "X-03", "X-04", "X-05", "X-07", "X-08", "X-09", "X-10", "X-11",
    ]  # fmt: skip
    assert results["X-06"] is ExitResult.INCONCLUSIVE
    assert {hop.hop: hop.verdict for hop in report.hops} == dict.fromkeys(
        ("gateway", "confluence", "jira", "github", "raw storage", "extraction"),
        HopVerdict.PASSED,
    )
    assert report.verdict.startswith("Incomplete: no evidence yet for X-06")
    assert "p50" in _detail(report, "X-11")
    assert report.count(ExitResult.PASS) == 10


def test_us26_without_discovery_signatures_are_not_proven(stack: Stack) -> None:
    stack.runner().run()

    assert _by_id(build_report(_evidence(stack)))["X-03"] is ExitResult.INCONCLUSIVE


def test_us26_tools_that_return_prose_are_named_and_the_source_moves_to_direct_reads(
    stack: Stack,
) -> None:
    stack.fake.prose_namespaces = {"jira"}
    runner = stack.runner()
    runner.discover()
    runner.run()

    report = build_report(_evidence(stack))

    results = _by_id(report)
    assert results["X-05"] is ExitResult.FAIL
    for item_id in ("jira-description", "jira-comments", "jira-word"):
        assert item_id in _detail(report, "X-05")
        assert any(item_id in line for line in report.attention)
    assert any("jira" in line and "direct reads" in line for line in report.attention)
    assert _hop(report, "jira").fields_survived is Cell.NO
    assert _hop(report, "jira").verdict is HopVerdict.FAILED
    assert _hop(report, "confluence").fields_survived is Cell.YES
    assert results["X-04"] is ExitResult.FAIL
    assert "partial pass" in _detail(report, "X-04")
    assert "failed X-04, X-05" in report.verdict


def test_us26_an_unreachable_attachment_is_named_with_its_type(stack: Stack) -> None:
    del stack.fake.data.page_attachments[("7003", "att-7003")]
    stack.runner().run()

    report = build_report(_evidence(stack))

    detail = _detail(report, "X-04")
    assert "conf-pdf" in detail
    assert "application/pdf" in detail
    assert "8 of 9" in detail
    assert any("conf-pdf" in line for line in report.attention)


def test_us26_weak_extraction_is_recorded_by_file_type(stack: Stack) -> None:
    stack.runner().run()
    evidence = _evidence(stack)
    weak = tuple(
        item.model_copy(update={"markdown_chars": 0}) if item.item_id == "gh-excel" else item
        for item in evidence.items
    )

    report = build_report(evidence.model_copy(update={"items": weak}))

    assert _by_id(report)["X-07"] is ExitResult.FAIL
    assert "spreadsheetml.sheet: gh-excel (no Markdown)" in _detail(report, "X-07")


def test_us26_a_manifest_missing_a_field_is_named(stack: Stack) -> None:
    stack.runner().run()
    evidence = _evidence(stack)
    cut = tuple(
        item.model_copy(update={"manifest_problems": ("extracted_at",)})
        if item.item_id == "jira-word"
        else item
        for item in evidence.items
    )

    detail = _detail(build_report(evidence.model_copy(update={"items": cut})), "X-07")

    assert "jira-word (manifest lacks extracted_at)" in detail


def test_us26_extraction_skipped_is_not_judged(stack: Stack) -> None:
    stack.runner().run(skip_extraction=True)

    assert _by_id(build_report(_evidence(stack)))["X-07"] is ExitResult.INCONCLUSIVE


def test_us26_a_stored_file_that_no_longer_matches_its_manifest_fails(
    stack: Stack, tmp_path: Path
) -> None:
    stack.runner().run()
    target = next((tmp_path / "raw" / "github").rglob("*"))
    while target.is_dir():
        target = next(target.iterdir())
    target.write_bytes(b"tampered")

    report = build_report(_evidence(stack))

    assert _by_id(report)["X-08"] is ExitResult.FAIL
    assert "gh-" in _detail(report, "X-08")
    assert _hop(report, "raw storage").verdict is HopVerdict.FAILED


def test_us26_a_rerun_that_stored_something_is_our_defect(stack: Stack) -> None:
    stack.runner().run()
    stack.runner().run()
    evidence = _evidence(stack)
    first, second = evidence.runs
    restored = second.model_copy(
        update={
            "items": tuple(
                item.model_copy(update={"status": ItemStatus.STORED}) for item in second.items[:1]
            )
            + second.items[1:]
        }
    )

    report = build_report(evidence.model_copy(update={"runs": (first, restored)}))

    assert _by_id(report)["X-09"] is ExitResult.FAIL
    assert "our defect" in _detail(report, "X-09")


def test_us26_a_version_that_moved_between_runs_fails_x05(stack: Stack) -> None:
    stack.runner().run()
    stack.fake.edit_page("7002", "<p>edited</p>")
    stack.runner().run()

    report = build_report(_evidence(stack))

    assert _by_id(report)["X-05"] is ExitResult.FAIL
    assert "conf-table" in _detail(report, "X-05")


def _long_run(stack: Stack, **updates: object) -> Evidence:
    stack.runner().run()
    evidence = _evidence(stack)
    [only] = evidence.runs
    longer = only.model_copy(
        update={"ended_at": only.started_at + timedelta(minutes=31), **updates}
    )
    return evidence.model_copy(update={"runs": (longer,)})


def _run_that_outlives_its_token(stack: Stack) -> Evidence:
    """A real run in which the clock moves past 80% of the token life, then past the whole life."""

    def move_clock(count: int) -> None:
        if count in {4, 7}:
            stack.clock.set(stack.clock.now() + timedelta(seconds=1500 if count == 4 else 400))

    stack.fake.before_request = move_clock
    stack.runner().run()
    return _evidence(stack)


def test_us26_x06_passes_only_when_a_long_run_renewed_its_token(stack: Stack) -> None:
    evidence = _run_that_outlives_its_token(stack)

    [only] = evidence.runs
    assert only.duration_seconds > evidence.token_lifetime_seconds
    assert sum(1 for call in evidence.calls if call.token_refreshed) == 1
    real = _by_id(build_report(evidence.model_copy(update={"mode": Mode.REAL})))
    local = build_report(evidence)

    assert real["X-06"] is ExitResult.PASS
    assert _by_id(local)["X-06"] is ExitResult.INCONCLUSIVE
    assert "Stand-in evidence only" in _detail(local, "X-06")


def test_us26_x06_a_long_run_with_only_the_first_sign_in_proves_nothing(stack: Stack) -> None:
    evidence = _long_run(stack)

    assert [call.token_refreshed for call in evidence.calls] == [False] * 9
    report = build_report(evidence.model_copy(update={"mode": Mode.REAL}))

    assert _by_id(report)["X-06"] is ExitResult.INCONCLUSIVE
    assert "expiry was not exercised" in _detail(report, "X-06")


def test_us26_x06_a_renewal_on_the_first_call_of_a_long_run_proves_nothing(stack: Stack) -> None:
    evidence = _long_run(stack)
    renewed_first = tuple(
        call.model_copy(update={"token_refreshed": index == 0})
        for index, call in enumerate(evidence.calls)
    )

    report = build_report(evidence.model_copy(update={"calls": renewed_first, "mode": Mode.REAL}))

    assert _by_id(report)["X-06"] is ExitResult.INCONCLUSIVE


def test_us26_x06_fails_when_a_long_run_died_on_a_refused_credential(stack: Stack) -> None:
    evidence = _long_run(stack, outcome=RunOutcome.FAILED, abort_reason="SourceAuthRefusedError")

    report = build_report(evidence.model_copy(update={"mode": Mode.REAL}))

    assert _by_id(report)["X-06"] is ExitResult.FAIL


def test_us26_a_short_run_says_nothing_about_token_expiry(stack: Stack) -> None:
    stack.runner().run()

    report = build_report(_evidence(stack, Mode.REAL))

    assert _by_id(report)["X-06"] is ExitResult.INCONCLUSIVE
    assert "No run lasted longer" in _detail(report, "X-06")


def test_us26_x10_needs_both_a_credential_error_and_a_parameter_error(stack: Stack) -> None:
    _prove(stack)
    evidence = _evidence(stack, Mode.REAL)
    without_parameter = tuple(c for c in evidence.calls if c.error_class != "GatewayProtocolError")

    report = build_report(evidence.model_copy(update={"calls": without_parameter}))

    assert _by_id(report)["X-10"] is ExitResult.INCONCLUSIVE
    assert "bad parameter" in _detail(report, "X-10")


def test_us26_a_refused_sign_in_fails_x02_and_names_the_server(stack: Stack) -> None:
    stack.fake.forbidden_namespaces = {"jira"}
    with pytest.raises(GatewayForbiddenError):
        stack.runner().discover()

    report = build_report(_evidence(stack))

    assert _by_id(report)["X-02"] is ExitResult.FAIL
    assert "jira" in _detail(report, "X-02")
    assert _hop(report, "jira").entitled is Cell.NO
    assert _by_id(report)["X-03"] is ExitResult.FAIL


def test_us26_no_answer_from_the_gateway_fails_x01() -> None:
    evidence = _empty().model_copy(
        update={"calls": (_call("jira", "tools/list", http_status=None, error_class="X"),)}
    )

    report = build_report(evidence)

    assert _by_id(report)["X-01"] is ExitResult.FAIL
    assert _hop(report, "gateway").reachable is Cell.NO


def test_us26_a_hop_with_partial_evidence_is_not_passed() -> None:
    evidence = _empty().model_copy(
        update={"calls": (_call("confluence", "tools/list"), _call("confluence"))}
    )

    report = build_report(evidence)

    assert _hop(report, "confluence").verdict is HopVerdict.PASSED
    assert _hop(report, "jira").verdict is HopVerdict.NOT_PASSED
    assert _hop(report, "jira").entitled is Cell.NO_EVIDENCE
    assert _by_id(report)["X-02"] is ExitResult.INCONCLUSIVE


def test_us26_percentiles_are_nearest_rank() -> None:
    values = [40.0, 10.0, 30.0, 20.0]

    assert percentile(values, 0.5) == 20.0
    assert percentile(values, 0.95) == 40.0
    assert percentile([7.0], 0.5) == 7.0


def test_us26_x11_reports_percentiles_by_operation() -> None:
    calls = tuple(
        _call(ns, op, latency_ms=latency, call_id=f"{ns}-{op}-{latency}")
        for ns in ("confluence", "jira", "github")
        for op in ("tools/list", "tools/call")
        for latency in (10.0, 20.0, 30.0, 40.0)
    )

    report = build_report(_empty().model_copy(update={"calls": calls}))

    assert _by_id(report)["X-11"] is ExitResult.PASS
    assert "jira tools/call: p50 20 ms, p95 40 ms (n=4)" in _detail(report, "X-11")


def test_us26_report_states_what_was_not_tested(stack: Stack) -> None:
    _prove(stack)

    local = build_report(_evidence(stack))
    real = build_report(_evidence(stack, Mode.REAL))

    for report in (local, real):
        text = " ".join(report.not_tested)
        assert "Volume" in text
        assert "Change tracking" in text
        assert "Extraction quality" in text
    assert any("platform route" in line for line in local.not_tested)
    assert not any("platform route" in line for line in real.not_tested)


def test_us26_markdown_report_has_every_section_and_every_criterion(stack: Stack) -> None:
    _prove(stack)

    text = render_markdown(build_report(_evidence(stack)))

    for heading in ("## Exit criteria", "## Hops", "## What was not tested"):
        assert heading in text
    for criterion_id in ALL:
        assert f"| {criterion_id} |" in text
    assert LOCAL_VERDICT in text
    assert "A hop without evidence is shown as not passed." in text


def test_us26_report_survives_a_json_round_trip(stack: Stack) -> None:
    _prove(stack)
    report = build_report(_evidence(stack))

    assert ExitReport.model_validate_json(report.model_dump_json()) == report
    assert isinstance(report, DomainModel)


def test_us26_scoring_is_a_pure_function_of_the_evidence(stack: Stack) -> None:
    _prove(stack)
    evidence = _evidence(stack)

    assert score_criteria(evidence) == score_criteria(evidence)
    assert {run.activity for run in evidence.runs} == {
        RunActivity.DISCOVER,
        RunActivity.FETCH,
        RunActivity.PROBE,
    }
    assert all(isinstance(item, ItemEvidence) for item in evidence.items)


def test_us26_x09_a_rerun_that_stopped_early_is_not_a_pass(stack: Stack) -> None:
    stack.runner().run()

    def refuse_from_the_third_call_of_the_rerun(count: int) -> None:
        if count == 12:
            stack.fake.reject_all = True

    stack.fake.before_request = refuse_from_the_third_call_of_the_rerun
    with pytest.raises(SourceAuthRefusedError):
        stack.runner().run()

    evidence = _evidence(stack, Mode.REAL)
    report = build_report(evidence)

    assert len(evidence.items) == 9
    assert _by_id(report)["X-09"] is ExitResult.INCONCLUSIVE
    assert "stopped early" in _detail(report, "X-09")
    assert "2 of 9" in _detail(report, "X-09")


def test_us26_x09_a_rerun_that_covered_only_part_of_the_items_is_not_a_pass(stack: Stack) -> None:
    stack.runner().run()
    stack.runner().run()
    evidence = _evidence(stack, Mode.REAL)
    first, second = evidence.runs
    short = second.model_copy(update={"items": second.items[:4]})

    report = build_report(evidence.model_copy(update={"runs": (first, short)}))

    assert _by_id(report)["X-09"] is ExitResult.INCONCLUSIVE
    assert "4 of 9" in _detail(report, "X-09")


def test_us26_x05_compares_only_what_both_runs_covered(stack: Stack) -> None:
    stack.runner().run()
    stack.runner().run()
    evidence = _evidence(stack, Mode.REAL)
    first, second = evidence.runs
    short = first.model_copy(update={"items": first.items[:3]})

    report = build_report(evidence.model_copy(update={"runs": (short, second)}))

    assert _by_id(report)["X-05"] is ExitResult.INCONCLUSIVE
    assert "3 of 9" in _detail(report, "X-05")


def test_us26_x05_recovers_once_the_adapter_reads_the_source_fields(stack: Stack) -> None:
    stack.fake.prose_namespaces = {"jira"}
    stack.runner().run()
    assert _by_id(build_report(_evidence(stack)))["X-05"] is ExitResult.FAIL

    stack.fake.prose_namespaces = set()
    stack.runner().run()
    report = build_report(_evidence(stack))

    assert _by_id(report)["X-05"] is not ExitResult.FAIL
    assert _hop(report, "jira").fields_survived is Cell.YES
    assert report.attention == ()


def test_us26_a_skipped_then_completed_extraction_passes_x07_and_a_third_run_x09(
    stack: Stack,
) -> None:
    runner = stack.runner()
    runner.run(skip_extraction=True)
    assert _by_id(build_report(_evidence(stack)))["X-07"] is ExitResult.INCONCLUSIVE
    runner.run()
    runner.run()

    results = _by_id(build_report(_evidence(stack)))

    assert results["X-07"] is ExitResult.PASS
    assert results["X-08"] is ExitResult.PASS
    assert results["X-09"] is ExitResult.PASS
    assert results["X-05"] is ExitResult.PASS


def _probe(call_id: str, namespace: str, status: int) -> McpCallRecord:
    return _call(namespace, "tools/list", call_id=call_id, run_id="probe-1", http_status=status)


def _probe_run() -> RunResult:
    started = datetime(2026, 11, 1, 9, 0, tzinfo=UTC)
    return RunResult(
        run_id="probe-1",
        activity=RunActivity.PROBE,
        started_at=started,
        ended_at=started,
        outcome=RunOutcome.SUCCEEDED,
    )


def test_us26_a_forbidden_answer_to_the_bad_credential_probe_does_not_fail_the_hop() -> None:
    evidence = _empty().model_copy(
        update={
            "runs": (_probe_run(),),
            "calls": (
                _call("confluence", "tools/list", call_id="ok-1"),
                _call("confluence", call_id="ok-2"),
                _probe("p-1", "confluence", 403),
            ),
        }
    )

    hop = _hop(build_report(evidence), "confluence")

    assert (hop.authenticated, hop.entitled) == (Cell.YES, Cell.YES)
    assert hop.verdict is HopVerdict.PASSED


def test_us26_probe_calls_alone_say_nothing_about_a_hop() -> None:
    evidence = _empty().model_copy(
        update={"runs": (_probe_run(),), "calls": (_probe("p-1", "jira", 403),)}
    )

    hop = _hop(build_report(evidence), "jira")

    assert (hop.reachable, hop.authenticated, hop.entitled) == (Cell.NO_EVIDENCE,) * 3
    assert hop.verdict is HopVerdict.NOT_PASSED


def test_us26_a_later_success_supersedes_an_earlier_refusal_on_a_hop() -> None:
    refused = _call(
        "jira", "tools/list", call_id="a-1", http_status=403, called_at="2026-11-01T09:00:00+00:00"
    )
    unauthorized = _call(
        "jira", "tools/list", call_id="a-2", http_status=401, called_at="2026-11-01T09:01:00+00:00"
    )
    fixed = _call("jira", call_id="a-3", called_at="2026-11-01T10:00:00+00:00")
    before = _empty().model_copy(update={"calls": (refused, unauthorized)})
    after = _empty().model_copy(update={"calls": (refused, unauthorized, fixed)})

    refused_hop = _hop(build_report(before), "jira")
    fixed_hop = _hop(build_report(after), "jira")

    assert (refused_hop.authenticated, refused_hop.entitled) == (Cell.NO, Cell.NO)
    assert (fixed_hop.authenticated, fixed_hop.entitled) == (Cell.YES, Cell.YES)
    assert fixed_hop.verdict is HopVerdict.PASSED


def test_us26_a_refusal_after_the_last_success_still_fails_the_hop() -> None:
    fine = _call("jira", call_id="a-1", called_at="2026-11-01T09:00:00+00:00")
    refused = _call(
        "jira", "tools/list", call_id="a-2", http_status=403, called_at="2026-11-01T10:00:00+00:00"
    )

    hop = _hop(build_report(_empty().model_copy(update={"calls": (fine, refused)})), "jira")

    assert hop.entitled is Cell.NO
    assert hop.verdict is HopVerdict.FAILED
