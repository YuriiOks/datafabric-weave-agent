"""Seam: the read tools' link port, backed by the link store.

Links in use (stated and proposed) are read into a graph and walked from the start item. The
walk never steps onto or through an item outside the caller's domains; those items are only
counted. Templates are reached but not walked through, because one template is shared by many
specs and would make unrelated work look connected.
"""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence

from sqlalchemy.exc import SQLAlchemyError

from kp.adapters.domains import ItemDomains
from kp.clock import Clock
from kp.domain import ItemRef, ItemType, LinkKind
from kp.links import LinkGraph, SqlLinkStore
from kp.store import Database
from kp.tools import LinkCounts, LinkedItem, LinkStoreUnavailableError, LinkTraversal

logger = logging.getLogger(__name__)


class StoreLinkPort:
    """Link traversal and counts for the agent tools.

    :param database: The platform database
    :param clock: Time source for the validity of links
    """

    def __init__(self, database: Database, clock: Clock) -> None:
        self._database = database
        self._clock = clock

    def traverse(self, root: ItemRef, *, steps: int, domains: frozenset[str]) -> LinkTraversal:
        """Follow links in either direction up to ``steps`` edges away.

        :param root: The start item
        :param steps: Maximum distance, 1 to 3
        :param domains: Domains the caller may read
        :return: Linked items the caller may see, and how many were hidden
        :raises kp.tools.LinkStoreUnavailableError: If the link store cannot be read
        """
        try:
            with self._database.transaction() as connection:
                graph = LinkGraph(SqlLinkStore(connection, self._clock).in_use_links())
                placer = ItemDomains(connection)
        except SQLAlchemyError as exc:
            logger.error("Link store could not be read")
            raise LinkStoreUnavailableError("The link store is unavailable") from exc
        root_domain = placer.of(root)
        items: list[LinkedItem] = []
        hidden = 0
        seen = {root}
        frontier: list[tuple[ItemRef, str | None]] = [(root, root_domain)]
        for distance in range(1, steps + 1):
            following: list[tuple[ItemRef, str | None]] = []
            for node, node_domain in frontier:
                for edge in graph.edges(node):
                    if edge.other in seen:
                        continue
                    seen.add(edge.other)
                    domain = placer.of(edge.other, reached_from=node_domain)
                    if domain is None or domain not in domains:
                        hidden += 1
                        continue
                    link = edge.link
                    items.append(
                        LinkedItem(
                            item=edge.other,
                            domain=domain,
                            steps=distance,
                            relation=link.relation,
                            outgoing=edge.forward,
                            via=node,
                            kind=link.kind,
                            state=link.state,
                            score=link.score,
                            evidence=link.evidence,
                        )
                    )
                    if edge.other.item_type is not ItemType.TEMPLATE:
                        following.append((edge.other, domain))
            frontier = following
        return LinkTraversal(root_domain=root_domain, items=tuple(items), filtered_out=hidden)

    def link_counts(
        self, items: Sequence[ItemRef], *, domains: frozenset[str]
    ) -> Mapping[ItemRef, LinkCounts]:
        """Count the links an agent could follow one step from each item.

        :param items: The items to count for
        :param domains: Domains the caller may read
        :return: Counts per item with at least one visible link
        :raises kp.tools.LinkStoreUnavailableError: If the link store cannot be read
        """
        counts: dict[ItemRef, LinkCounts] = {}
        for item in items:
            traversal = self.traverse(item, steps=1, domains=domains)
            stated = sum(1 for linked in traversal.items if linked.kind is LinkKind.STATED)
            guessed = len(traversal.items) - stated
            if traversal.items:
                counts[item] = LinkCounts(stated=stated, guessed=guessed)
        return counts
