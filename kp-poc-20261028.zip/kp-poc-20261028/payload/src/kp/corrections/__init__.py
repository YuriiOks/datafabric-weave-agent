"""The corrections log (US-24, build side): every correction a product owner makes to a drafted
spec is recorded with its reason and a wrong-clause flag, and a report gives each spec's citation
rate, wrong-clause count and correction count.

The reviews themselves are live work; this package only keeps their record.
``kp corrections add`` records one, ``kp corrections report`` reports.
"""

from kp.corrections.cli import add_parser
from kp.corrections.errors import CorrectionError, InvalidCorrectionError, UnknownSpecError
from kp.corrections.report import CorrectionReport, SpecReportRow, build_report, format_report
from kp.corrections.store import CorrectionLog

__all__ = [
    "CorrectionError",
    "CorrectionLog",
    "CorrectionReport",
    "InvalidCorrectionError",
    "SpecReportRow",
    "UnknownSpecError",
    "add_parser",
    "build_report",
    "format_report",
]
