"""Apply the SKL-04 change package to a clean worktree. Harness file: never committed.

Usage: python3 apply_skl04.py <worktree-root> [--check]

Copies every file under ./pkg into the worktree, refusing to overwrite anything. The
package only adds files; it edits nothing. Before writing, it checks that the names the
new code imports exist on this base. One problem writes nothing.

Branch: feat/skl-04-*, cut from main. The MCP-04 package stacks on this branch.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / "pkg"
BRANCH_PREFIXES = ("feat/skl-04",)

#: (file, text that must occur in it): the names the new code and tests import.
REQUIRED: tuple[tuple[str, str], ...] = (
    ("backend/app/recsys/eval/schema.py", "DRAFT_LABELLER"),
    ("backend/app/recsys/eval/schema.py", "SYNTHETIC_MARKER"),
    ("backend/app/recsys/eval/schema.py", "class GoldenInput("),
    ("backend/app/recsys/contracts/catalogue.py", 'raw_yaml_description = "raw_yaml_description"'),
    ("backend/app/recsys/contracts/catalogue.py", 'empty_description = "empty_description"'),
    ("backend/app/recsys/contracts/catalogue.py", 'missing_frontmatter = "missing_frontmatter"'),
    ("backend/app/recsys/contracts/states.py", 'graph_valid = "graph_valid"'),
    ("backend/app/recsys/contracts/states.py", "recommendation_eligible = "),
    ("backend/app/recsys/contracts/states.py", "recommendation_ineligible = "),
    ("backend/app/recsys/contracts/states.py", "execution_denied"),
    ("backend/app/recsys/contracts/scope.py", "class PublicationScope("),
    ("backend/app/recsys/contracts/resolution.py", "class CanonicalRecord("),
    ("backend/app/recsys/contracts/resolution.py", "class SourceEvidence("),
    ("backend/app/recsys/contracts/resolution.py", "class SourceLocator("),
    ("backend/app/recsys/contract_fixtures.py", "RESOLVED_IDENTITY = "),
    ("backend/app/recsys/contract_fixtures.py", "GRAPH_VISIBLE_INELIGIBLE_DENIED = "),
    ("backend/app/recsys/contract_fixtures.py", "PPD_SCOPE = "),
    ("backend/tests/recsys/eval/__init__.py", ""),
)


def _git(root: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 2
    root = Path(argv[0]).resolve()
    check_only = "--check" in argv[1:]
    problems: list[str] = []

    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if not branch.startswith(BRANCH_PREFIXES):
        problems.append(f"branch is {branch}, expected one of {BRANCH_PREFIXES}")
    if _git(root, "status", "--porcelain"):
        problems.append("worktree is not clean")

    for rel, needle in REQUIRED:
        path = root / rel
        if not path.is_file():
            problems.append(f"missing file: {rel}")
        elif needle and needle not in path.read_text(encoding="utf-8"):
            problems.append(f"{rel}: expected text not found: {needle!r}")

    new_files: list[tuple[Path, bytes]] = []
    for source in sorted(PKG.rglob("*")):
        if source.is_dir() or "__pycache__" in source.parts:
            continue
        target = root / source.relative_to(PKG)
        if target.exists():
            problems.append(f"new file already exists: {source.relative_to(PKG)}")
        new_files.append((target, source.read_bytes()))
        if target.suffix == ".py":
            try:
                compile(source.read_text(encoding="utf-8"), str(target), "exec")
            except SyntaxError as error:
                problems.append(f"{target.name}: does not compile: {error}")

    if problems:
        print("NOTHING WRITTEN. Problems:")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print(f"OK: {len(new_files)} new files, no edits")
    if check_only:
        return 0
    for target, data in new_files:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print("written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
