"""Tests for the release acceptance matrix."""
