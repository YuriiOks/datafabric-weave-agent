"""Tests for the stable relation key and the evidence digest."""

from __future__ import annotations

import unittest
from dataclasses import replace
from uuid import UUID

from app.recsys.contracts import LinkType
from app.recsys.registry.relations.evidence import (
    EVIDENCE_DIGEST_NAMESPACE,
    EvidenceEntry,
    evidence_digest,
    ordered_evidence,
)
from app.recsys.registry.relations.keys import (
    RELATION_KEY_NAMESPACE,
    SHA256_HEX_PATTERN,
    canonical_sha256,
    relation_key,
)

SOURCE = UUID("00000000-0000-4000-8000-000000000001")
TARGET = UUID("00000000-0000-4000-8000-000000000002")

ENTRY = EvidenceEntry(
    authority="agent_hub_export",
    collection="agent_records",
    structural_locator="sheet=Agent Usage;row=1",
    field_name="skill",
    token_ordinal=0,
    raw_token="alpha-helper",
    raw_token_digest=None,
    resolution_outcome="resolved_exact",
    matched_index="slugified_source_id",
    rule_id="exact_source_key",
    rule_version="policy-v1",
)


class RelationKeyTests(unittest.TestCase):
    def test_the_key_is_a_full_lower_case_sha256(self):
        self.assertRegex(
            relation_key(SOURCE, LinkType.uses_skill, TARGET), SHA256_HEX_PATTERN
        )

    def test_the_key_depends_only_on_its_three_parts(self):
        self.assertEqual(
            relation_key(SOURCE, LinkType.uses_skill, TARGET),
            relation_key(str(SOURCE), LinkType.uses_skill, str(TARGET)),
        )

    def test_direction_and_link_type_each_change_the_key(self):
        keys = {
            relation_key(SOURCE, LinkType.uses_skill, TARGET),
            relation_key(TARGET, LinkType.uses_skill, SOURCE),
            relation_key(SOURCE, LinkType.uses_mcp, TARGET),
        }
        self.assertEqual(len(keys), 3)

    def test_the_versioned_namespace_is_part_of_the_key(self):
        key = relation_key(SOURCE, LinkType.uses_skill, TARGET)
        self.assertEqual(
            key,
            canonical_sha256(
                [RELATION_KEY_NAMESPACE, str(SOURCE), "USES_SKILL", str(TARGET)]
            ),
        )
        self.assertNotEqual(
            key, canonical_sha256([str(SOURCE), "USES_SKILL", str(TARGET)])
        )


class EvidenceDigestTests(unittest.TestCase):
    def test_the_digest_ignores_input_order(self):
        second = replace(ENTRY, token_ordinal=1)
        self.assertEqual(evidence_digest([ENTRY, second]), evidence_digest([second, ENTRY]))
        self.assertEqual(ordered_evidence([second, ENTRY]), [ENTRY, second])

    def test_every_source_and_resolution_fact_moves_the_digest(self):
        baseline = evidence_digest([ENTRY])
        for change in (
            {"structural_locator": "sheet=Agent Usage;row=2"},
            {"token_ordinal": 1},
            {"raw_token": "alpha-helper-two"},
            {"field_name": "mcp"},
            {"matched_index": "component_id"},
            {"rule_version": "policy-v2"},
            {"authority": "skills_repo"},
        ):
            with self.subTest(change=change):
                self.assertNotEqual(evidence_digest([replace(ENTRY, **change)]), baseline)

    def test_a_repeated_declaration_moves_the_digest(self):
        self.assertNotEqual(
            evidence_digest([ENTRY]),
            evidence_digest([ENTRY, replace(ENTRY, token_ordinal=1)]),
        )

    def test_an_empty_set_digests_only_the_namespace(self):
        self.assertEqual(evidence_digest([]), canonical_sha256([EVIDENCE_DIGEST_NAMESPACE]))

    def test_rendering_redacts_a_sensitive_token_without_moving_the_digest(self):
        sensitive = replace(ENTRY, raw_token="/srv/private/alpha")
        rendered = sensitive.as_dict()
        self.assertTrue(rendered["raw_value_redacted"])
        self.assertTrue(rendered["raw_value"].startswith("sha256:"))
        self.assertNotIn("/srv/private/alpha", str(rendered))
        self.assertEqual(evidence_digest([sensitive]), evidence_digest([sensitive]))
        self.assertNotEqual(evidence_digest([sensitive]), evidence_digest([ENTRY]))


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
