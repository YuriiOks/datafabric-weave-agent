"""Behaviour of ``install.py``: verify first, inspect without writing, refuse a full target."""

from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

import pytest
from package_world import builder, installer, make_project, options_for, write_patterns


@pytest.fixture
def package_dir(tmp_path: Path) -> Path:
    project = make_project(tmp_path / "project")
    patterns = write_patterns(tmp_path / "patterns.json")
    return builder.build_package(options_for(project, tmp_path / "out", patterns)).package_dir


def _run(package: Path, *argv: str) -> int:
    return installer.run(package, installer.build_parser().parse_args(list(argv)))


def _payload_files(package: Path) -> dict[str, str]:
    root = package / "payload"
    return {
        p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in root.rglob("*")
        if p.is_file()
    }


def _tree(root: Path) -> dict[str, str]:
    return {
        p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in root.rglob("*")
        if p.is_file()
    }


def test_inspect_lists_the_plan_and_writes_nothing(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    target = tmp_path / "target"

    status = _run(package_dir, "--inspect", "--target", str(target))

    out = capsys.readouterr().out
    assert status == installer.EXIT_OK
    assert not target.exists()
    assert "PLAN new src/kp/__init__.py" in out
    assert "PLAN new .env.example" in out
    assert out.rstrip().endswith("INSPECT only: nothing was written")


def test_install_writes_the_payload_and_prints_the_next_steps(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    target = tmp_path / "target"

    status = _run(package_dir, "--target", str(target))

    out = capsys.readouterr().out
    assert status == installer.EXIT_OK
    assert _tree(target) == _payload_files(package_dir)
    assert "INSTALLED" in out
    assert "python3 -m venv .venv" in out
    assert "INSTALL-WORKSTATION.md" in out


def test_the_installed_launcher_script_stays_executable(package_dir: Path, tmp_path: Path) -> None:
    target = tmp_path / "target"
    source = package_dir / "payload" / "scripts" / "check.sh"
    source.chmod(0o755)

    _run(package_dir, "--target", str(target))

    assert (target / "scripts" / "check.sh").stat().st_mode & 0o111


def test_a_target_that_is_not_empty_is_refused_until_forced(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    target = tmp_path / "target"
    target.mkdir()
    (target / "keep.txt").write_bytes(b"mine")

    refused = _run(package_dir, "--target", str(target))

    assert refused == installer.EXIT_REFUSED
    assert "Refused" in capsys.readouterr().err
    assert [p.name for p in target.iterdir()] == ["keep.txt"]

    forced = _run(package_dir, "--target", str(target), "--force")

    assert forced == installer.EXIT_OK
    assert (target / "keep.txt").read_bytes() == b"mine"
    assert (target / "pyproject.toml").is_file()


def test_an_empty_existing_target_is_accepted(package_dir: Path, tmp_path: Path) -> None:
    target = tmp_path / "target"
    target.mkdir()

    assert _run(package_dir, "--target", str(target)) == installer.EXIT_OK


def test_inspect_notes_that_the_target_is_not_empty(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    target = tmp_path / "target"
    target.mkdir()
    (target / "keep.txt").write_bytes(b"mine")

    assert _run(package_dir, "--inspect", "--target", str(target)) == installer.EXIT_OK
    assert "NOTE the target is not empty" in capsys.readouterr().out


def test_a_changed_file_is_caught_before_anything_is_written(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    target = tmp_path / "target"
    (package_dir / "payload" / "README.md").write_bytes(b"# Tampered\n")

    status = _run(package_dir, "--target", str(target))

    assert status == installer.EXIT_BAD_PACKAGE
    assert "MISMATCH payload/README.md" in capsys.readouterr().err
    assert not target.exists()


def test_a_missing_and_an_unlisted_file_are_both_reported(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    (package_dir / "payload" / "docs" / "guide.md").unlink()
    (package_dir / "payload" / "extra.txt").write_bytes(b"added")

    status = _run(package_dir, "--inspect", "--target", str(tmp_path / "target"))

    err = capsys.readouterr().err
    assert status == installer.EXIT_BAD_PACKAGE
    assert "MISSING payload/docs/guide.md" in err
    assert "UNLISTED payload/extra.txt" in err


def test_a_package_without_a_checksum_file_is_not_installed(
    package_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    (package_dir / "SHA256SUMS").unlink()

    status = _run(package_dir, "--target", str(tmp_path / "target"))

    assert status == installer.EXIT_BAD_PACKAGE
    assert "SHA256SUMS is missing" in capsys.readouterr().err


@pytest.mark.parametrize(
    "line",
    [
        "not a checksum line",
        f"{'a' * 64} /absolute/path",
        f"{'a' * 64}  ../outside",
        f"{'A' * 64}  upper-case-digest",
    ],
)
def test_malformed_or_unsafe_checksum_lines_are_rejected(line: str) -> None:
    with pytest.raises(installer.PackageError):
        installer.parse_checksums(line + "\n")


def test_a_repeated_path_in_the_checksum_file_is_rejected() -> None:
    line = f"{'a' * 64}  same.txt\n"

    with pytest.raises(installer.PackageError):
        installer.parse_checksums(line + line)


def test_the_installer_runs_on_its_own_as_a_script(package_dir: Path, tmp_path: Path) -> None:
    done = subprocess.run(  # noqa: S603 - fixed argument list: our interpreter and our file
        [sys.executable, "-I", str(package_dir / "install.py"), "--inspect", "--target", "t"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
    )

    assert done.returncode == 0, done.stderr
    assert "CHECKSUMS OK" in done.stdout
    assert not (tmp_path / "t").exists()
