# km-read pdf

Goal: record what the code-health review of the older repositories found, with page numbers,
so S2, S5 and S6 start from evidence.
Input: /home/user/km/work/legacy-review.pdf, put there by the owner. Missing: log it, tell the
owner "put the review PDF at work/legacy-review.pdf", stop.
Output: /home/user/km/kb/legacy/. No network. The review is a document: its statements are
Reported, each with its page number. Page numbers are the PDF's own, counted from 1.

## Choose the route
Check `command -v pdftotext` and `command -v pdfinfo`.

Route A, pdftotext exists:
1. Convert once, only if work/legacy-review.txt is absent, with a marker line before each page
   (run in /home/user/km). A last empty marker beyond the real page count is ignored.

       pdftotext -layout work/legacy-review.pdf - |
         awk 'BEGIN{RS="\f"}{printf "=== PAGE %d ===\n%s\n",NR,$0}' > work/legacy-review.txt

2. Page count N from pdfinfo, else the highest marker with text. One reader per 40 pages
   (1-40, 41-80, ...), up to 3 at once; each gets the line range from the marker of its first
   page to the line before the marker of the page after its last (grep -n). Each reads the
   text file with line ranges of at most 1500 lines. Page of a fact = the nearest marker above.
3. Outputs kb/legacy/review-p<from>-<to>.md per reader (page numbers padded to 3 digits).

Route B, no pdftotext:
1. Readers use the Read tool on the PDF with page ranges of at most 20 pages per call.
2. One reader per 40 pages: 1-40, 41-80, and so on to the last page. Up to 3 at once. If the
   page count is unknown, the last reader reports the last page it could read.
3. Outputs kb/legacy/review-p<from>-<to>.md per reader.

## Headings of each review file
Repositories covered and the verdict for each (use LEGACY_REPO_n from kb/legacy/repo-list.md
when it exists, else the order of appearance); Issue counts by theme; Reusable blocks named;
API standards findings; The five findings most relevant to S2, S5 or S6, with pages; Facts by
page (table: page, fact, label); Open questions.
A reader that cannot fit its range in 150 lines sets Status partial and lists the page
ranges left; the main session runs follow-up readers on those ranges (at most 3).

## Main session after the readers
1. Write kb/legacy/review-summary.md (at most 150 lines) from the review files only: Lessons
   for S5, Lessons for S6, Risks for S2, Reuse blocks named. Each item cites file and page.
2. For each kb/legacy/repo-<n>.md that exists, replace "not checked" under What a reviewer
   flagged with that repository's findings and pages, taken from the review files.
3. A skipped range is not retried; it is listed in the summary and the log.

## Done when
- One review file per reader exists with page numbers on every fact.
- review-summary.md exists; repo files show reviewer flags where a repo file exists.
- Run record and kb-lint.sh PASS as in the method; summary printed.

## Stop
- The PDF cannot be read (blocked, scanned images only, no text): log it, stop, tell the owner.
- A credential or personal data appears in the review: record only its page, never the value.
- At most 9 reader calls in total.
