"""Argument checks shared by the readers' paged listings."""

from __future__ import annotations

from kp.sources.errors import InvalidReadRequestError


def require_limit(limit: int) -> None:
    """Check the page size a caller asked for.

    :param limit: Maximum items per page
    :raises kp.sources.errors.InvalidReadRequestError: If ``limit`` is below one
    """
    if limit < 1:
        raise InvalidReadRequestError("limit must be at least 1")
