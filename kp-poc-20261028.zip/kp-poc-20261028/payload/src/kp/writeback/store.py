"""Persistence of the write side: templates, specs, citations, reference lookup, audit rows.

Functions and small classes over a :class:`sqlalchemy.Connection` from
``Database.transaction()``, using the shared ``kp.store.schema`` tables.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from datetime import date

from sqlalchemy import ColumnElement, Connection, delete, insert, select, update

from kp.domain import (
    Citation,
    ClauseRef,
    ItemType,
    Relation,
    Spec,
    SpecState,
    Template,
    ToolCallRecord,
)
from kp.errors import InvalidClauseRefError, TemplateNotFoundError
from kp.store import Database
from kp.store.schema import citation as citation_table
from kp.store.schema import clause as clause_table
from kp.store.schema import edition as edition_table
from kp.store.schema import link as link_table
from kp.store.schema import requirement as requirement_table
from kp.store.schema import spec as spec_table
from kp.store.schema import template as template_table
from kp.store.schema import tool_call as tool_call_table

_VERSION_PARTS = re.compile(r"(\d+)")


def version_key(version: str) -> tuple[tuple[int, int, str], ...]:
    """Order version strings naturally: ``1.10.0`` after ``1.9.0``, ``v10`` after ``v9``.

    :param version: A version label
    :return: A sort key; digit runs compare as numbers, everything else as text
    """
    return tuple(
        (0, int(part), "") if part.isdigit() else (1, 0, part)
        for part in _VERSION_PARTS.split(version)
        if part
    )


class TemplateRepository:
    """Governed templates. Absence is an error, never a fallback.

    :param connection: A connection inside a transaction owned by the caller
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def save(self, template: Template) -> None:
        """Insert a template version unless that version already exists.

        :param template: The governed template
        """
        exists = self._connection.execute(
            select(template_table.c.template_id).where(
                template_table.c.template_id == template.template_id,
                template_table.c.version == template.version,
            )
        ).first()
        if exists is None:
            self._connection.execute(insert(template_table).values(**template.model_dump()))

    def get(self, template_id: str, version: str) -> Template:
        """Fetch one template version.

        :param template_id: The template identifier
        :param version: The template version
        :return: The template
        :raises kp.errors.TemplateNotFoundError: If there is no such version
        """
        row = self._connection.execute(
            select(template_table).where(
                template_table.c.template_id == template_id,
                template_table.c.version == version,
            )
        ).first()
        if row is None:
            raise TemplateNotFoundError("No governed template with that id and version")
        return Template.model_validate(dict(row._mapping))

    def latest(self, spec_type: str) -> Template:
        """Fetch the newest version of the template for a spec type.

        :param spec_type: The kind of spec
        :return: The template with the highest version
        :raises kp.errors.TemplateNotFoundError: If none is governed for the type
        """
        rows = self._connection.execute(
            select(template_table).where(template_table.c.spec_type == spec_type)
        ).all()
        if not rows:
            raise TemplateNotFoundError("No governed template for that spec type")
        newest = max(rows, key=lambda row: version_key(row.version))
        return Template.model_validate(dict(newest._mapping))


class SpecRepository:
    """Drafted specs and their citations.

    :param connection: A connection inside a transaction owned by the caller
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def get_by_branch(self, branch: str) -> Spec | None:
        """Find the spec on a branch (a branch is a pull request is a spec).

        :param branch: The branch name
        :return: The spec, or ``None``
        """
        return self._one(spec_table.c.branch == branch)

    def get_by_story(self, story_key: str) -> Spec | None:
        """Find the spec drafted for a story.

        :param story_key: The story key
        :return: The spec, or ``None``
        """
        return self._one(spec_table.c.story_key == story_key)

    def merged_spec_id(self, story_key: str) -> str | None:
        """Find the merged (or closed) spec of a story, if it has one.

        A spec the platform drafted is found by its row, whose state the sweep sets when the
        merged file is loaded back. A spec only a person wrote has no row; the link the
        load-back opens from the story to it is what shows it.

        :param story_key: The story key
        :return: The spec identity, or ``None`` when the story has no merged spec
        """
        spec = self.get_by_story(story_key)
        if spec is not None and spec.state is not SpecState.DRAFTED:
            return spec.spec_id
        return self._connection.execute(
            select(link_table.c.target_key)
            .where(
                link_table.c.source_item_type == ItemType.STORY.value,
                link_table.c.source_key == story_key,
                link_table.c.relation == Relation.SPECIFIED_BY.value,
                link_table.c.valid_to.is_(None),
            )
            .order_by(link_table.c.target_key)
        ).scalar()

    def _one(self, condition: ColumnElement[bool]) -> Spec | None:
        row = self._connection.execute(select(spec_table).where(condition)).first()
        return None if row is None else Spec.model_validate(dict(row._mapping))

    def save(self, spec: Spec, citations: Sequence[Citation]) -> None:
        """Update a spec in place, or insert it, and replace its citations.

        Two concurrent first saves of one spec can both reach the insert; the loser raises
        :class:`sqlalchemy.exc.IntegrityError`, and the caller retries in a new transaction.

        :param spec: The spec; ``spec_id`` identifies the row
        :param citations: The citation rows of the current draft
        :raises sqlalchemy.exc.IntegrityError: If another transaction inserted the row first
        """
        values = spec.model_dump()
        values["open_items"] = list(spec.open_items)
        updated = self._connection.execute(
            update(spec_table).where(spec_table.c.spec_id == spec.spec_id).values(**values)
        )
        if updated.rowcount == 0:
            self._connection.execute(insert(spec_table).values(**values))
        self._connection.execute(
            delete(citation_table).where(citation_table.c.spec_id == spec.spec_id)
        )
        for item in citations:
            self._connection.execute(insert(citation_table).values(**item.model_dump()))

    def citations(self, spec_id: str) -> tuple[Citation, ...]:
        """List the stored citations of a spec in statement order.

        :param spec_id: The spec identifier
        :return: The citations
        """
        rows = self._connection.execute(
            select(citation_table)
            .where(citation_table.c.spec_id == spec_id)
            .order_by(citation_table.c.statement_index)
        ).all()
        return tuple(Citation.model_validate(dict(row._mapping)) for row in rows)


class DatabaseReferenceResolver:
    """Tells whether a reference names an existing clause or register row.

    Withdrawn and superseded clauses still resolve: an older spec's citation stays valid.

    :param connection: A connection inside a transaction owned by the caller
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def resolves(self, reference: str) -> bool:
        """Check a canonical reference.

        :param reference: ``<edition>:<number>`` or a requirement id
        :return: True when a clause or a register row exists under it
        """
        try:
            ref = ClauseRef.parse(reference)
        except InvalidClauseRefError:
            pass
        else:
            clause_found = self._connection.execute(
                select(clause_table.c.number).where(
                    clause_table.c.edition == ref.edition, clause_table.c.number == ref.number
                )
            ).first()
            if clause_found is not None:
                return True
        row_found = self._connection.execute(
            select(requirement_table.c.requirement_id).where(
                requirement_table.c.requirement_id == reference
            )
        ).first()
        return row_found is not None

    def withdrawn_since(self, reference: str) -> date | None:
        """Tell since when the edition of a cited clause is withdrawn.

        A withdrawn clause still resolves, so an older spec's citation stays valid; this says
        since when it is no longer in use.

        :param reference: ``<edition>:<number>`` or a requirement id
        :return: The withdrawal date, or ``None`` for a clause in use and for anything else
        """
        try:
            ref = ClauseRef.parse(reference)
        except InvalidClauseRefError:
            return None
        return self._connection.execute(
            select(edition_table.c.withdrawn_from).where(edition_table.c.label == ref.edition)
        ).scalar()


class DatabaseAuditSink:
    """Writes tool call records to ``tool_call`` in a transaction of their own.

    A refusal is recorded even though the call that caused it then fails.

    :param database: The database to write to
    """

    def __init__(self, database: Database) -> None:
        self._database = database

    def record(self, record: ToolCallRecord) -> None:
        """Insert one record.

        :param record: The call to record
        """
        values = record.model_dump(mode="json")
        values["domains_applied"] = list(record.domains_applied)
        values["called_at"] = record.called_at
        with self._database.transaction() as connection:
            connection.execute(insert(tool_call_table).values(**values))
