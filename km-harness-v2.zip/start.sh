#!/usr/bin/env bash
# start.sh: start a design session in /home/user/km with the right model.
# Run by the owner in a plain terminal, never by an agent.
#
#   bash start.sh          the 1M model id, effort high (use this)
#   bash start.sh std      the same model without the 1M suffix (if the first form is refused)
#   bash start.sh plain    no flags at all: the project settings decide (if a flag is rejected)
#
# Extra words after the mode are passed to claude unchanged.
# The agents of the other project that live in the user folder are switched off for this
# session by name. Nothing is changed on disk.

KM_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$KM_DIR" || exit 1

mode="1m"
case "${1:-}" in
  1m|std|plain) mode="$1"; shift ;;
esac

if [ "$mode" = "plain" ]; then
  echo "km: mode=plain dir=$KM_DIR"
  exec claude "$@"
fi

args=(--effort high --permission-mode auto)
case "$mode" in
  1m)  args+=(--model 'claude-opus-5-5[1m]') ;;
  std) args+=(--model 'claude-opus-5-5') ;;
esac

# Build Agent(<name>) entries for user-level agents that are not ours.
deny=""
for f in "$HOME"/.claude/agents/*.md; do
  [ -f "$f" ] || continue
  name="$(awk '
    NR == 1 && $0 !~ /^---[ \t\r]*$/ { exit }
    /^---[ \t\r]*$/ { if (++n == 2) exit; next }
    n == 1 && /^name:/ { sub(/^name:[ \t]*/, ""); print; exit }
  ' "$f" | tr -d '\r"'"'")"
  [ -n "$name" ] || name="$(basename "$f" .md)"
  case "$name" in
    km-*) continue ;;
  esac
  case "$name" in
    *[!A-Za-z0-9_-]*) continue ;;
  esac
  deny="${deny:+$deny,}Agent($name)"
done
# The deny list goes first: the flag takes a list, and the next flag ends that list.
if [ -n "$deny" ]; then
  args=(--disallowedTools "$deny" "${args[@]}")
fi

echo "km: mode=$mode dir=$KM_DIR"
exec claude "${args[@]}" "$@"
