#!/bin/bash
# Apply the component-page details fix to a checkout and run the frontend checks for it.
# usage: bash apply.sh <checkout root>     (PY=<python> to pick the interpreter)
# edit_details.py checks every anchor first and writes nothing unless all of them hold.
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
cd "${1:?checkout root}" || exit 1
"${PY:-python3}" "$HERE/edit_details.py" || exit 1
git status --short | tail -12
cd frontend || exit 1
npx eslint src/features/recsys/component-page 2>&1 | tail -12
echo ESLINT_DONE
npx tsc -b --force > /tmp/tsc.log 2>&1
echo "TSC=$?"
tail -8 /tmp/tsc.log
npx vitest run src/features/recsys/component-page 2>&1 | grep -E "Test Files|Tests |FAIL|AssertionError|Error:" | head -14
