"""Corpus manifest and field availability: states, provenance, exclusions, no copied text."""

from __future__ import annotations

import hashlib
import unittest

from app.recsys.contract_fixtures import GRAPH_VISIBLE_INELIGIBLE_DENIED, RESOLVED_IDENTITY
from app.recsys.contracts import ComponentType
from app.recsys.contracts.catalogue import QualityFlag
from app.recsys.contracts.resolution import CanonicalRecord, SourceEvidence, SourceLocator
from app.recsys.contracts.sources import SourceAuthority, SourceCollection
from app.recsys.contracts.states import RecommendationEligibility
from app.recsys.eval.casepack.corpus import (
    NOT_PUBLISHED_FIELDS,
    FieldState,
    build_corpus_manifest,
    field_availability,
    render_field_availability,
)
from app.recsys.eval.casepack.lineage import CasePackError, lineage_for

from . import casepack_support as support


def _description(manifest, number: int):
    entry = manifest.entry(support.component_id(number))
    return next(item for item in entry.observations if item.name == "description")


class CorpusManifestTests(unittest.TestCase):
    def test_description_states(self) -> None:
        manifest = support.corpus(
            [
                support.record(1),
                support.record(2, description=""),
                support.record(3, description="   ", flags=(QualityFlag.empty_description,)),
                support.record(
                    4,
                    description="name: x\ndescription: y",
                    flags=(QualityFlag.raw_yaml_description,),
                ),
                support.record(5, description="Synthetic\x00text"),
            ]
        )
        expected = {
            1: (FieldState.present, ()),
            2: (FieldState.missing, ("empty",)),
            3: (FieldState.missing, (QualityFlag.empty_description.value,)),
            4: (FieldState.malformed, (QualityFlag.raw_yaml_description.value,)),
            5: (FieldState.malformed, ("control_characters",)),
        }
        for number, (state, reasons) in expected.items():
            observation = _description(manifest, number)
            self.assertEqual((observation.state, observation.reasons), (state, reasons))

    def test_text_is_digested_never_copied(self) -> None:
        text = "Synthetic description that must stay out of the manifest"
        manifest = support.corpus([support.record(1, description=text)])
        self.assertNotIn(text, manifest.model_dump_json())
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        self.assertEqual(_description(manifest, 1).text_digest, digest)
        empty = support.corpus([support.record(2, description="")])
        self.assertIsNone(_description(empty, 2).text_digest)

    def test_ineligible_record_is_excluded_with_its_reason(self) -> None:
        ineligible = support.record(
            2, eligibility=RecommendationEligibility.recommendation_ineligible
        )
        manifest = support.corpus([support.record(1), ineligible])
        entry = manifest.entry(support.component_id(2))
        self.assertFalse(entry.baseline_input)
        self.assertEqual(entry.exclusion_reason, "eligibility:recommendation_ineligible")
        self.assertTrue(manifest.entry(support.component_id(1)).baseline_input)

    def test_other_component_types_are_skipped(self) -> None:
        mcp = support.record(9, component_type=ComponentType.mcp)
        manifest = support.corpus([support.record(1), mcp])
        self.assertEqual(manifest.component_ids(), frozenset({support.component_id(1)}))

    def test_refuses_a_component_published_twice(self) -> None:
        with self.assertRaisesRegex(CasePackError, "published twice"):
            support.corpus([support.record(1), support.record(1)])

    def test_refuses_evidence_outside_the_lineage(self) -> None:
        lineage = lineage_for(support.snapshot(), [support.record(1)])
        stray = support.record(2, evidence_items=[support.evidence(2, revision="commit-0ther")])
        with self.assertRaisesRegex(CasePackError, "outside the lineage"):
            build_corpus_manifest([stray], component_type=ComponentType.skill, lineage=lineage)

    def test_records_field_precedence_without_guessing_the_source(self) -> None:
        records = [support.record(1)]
        lineage = lineage_for(support.snapshot(), records)
        order = [SourceAuthority.skills_repo, SourceAuthority.agent_hub_export]
        manifest = build_corpus_manifest(
            records,
            component_type=ComponentType.skill,
            lineage=lineage,
            field_precedence={"description": order},
        )
        self.assertEqual(
            _description(manifest, 1).precedence, tuple(item.value for item in order)
        )
        entry = manifest.entry(support.component_id(1))
        name = next(item for item in entry.observations if item.name == "name")
        self.assertEqual(name.precedence, ())
        self.assertEqual(entry.provenance[0].record_occurrence_id, support.occurrence(1))

    def test_reads_a_real_canonical_record(self) -> None:
        evidence = SourceEvidence(
            authority=SourceAuthority.skills_repo,
            source_key=RESOLVED_IDENTITY.source_key,
            locator=SourceLocator(
                capture_digest="a" * 64,
                collection=SourceCollection.skill_content,
                structural_locator="skills/ticket-triage-helper/SKILL.md",
            ),
            source_configuration_version=support.SKILLS_CONFIGURATION,
            resolved_revision=support.SKILLS_REVISION,
            record_occurrence_id="c" * 64,
        )
        record = CanonicalRecord(
            catalogue_id=support.CATALOGUE_ID,
            identity=RESOLVED_IDENTITY,
            name="Ticket triage helper",
            description="Sorts synthetic tickets by urgency.",
            states=GRAPH_VISIBLE_INELIGIBLE_DENIED,
            source_evidence=[evidence],
        )
        manifest = support.corpus([record])
        entry = manifest.entry(str(RESOLVED_IDENTITY.component_uuid))
        self.assertEqual(
            entry.exclusion_reason, "eligibility:recommendation_insufficient_evidence"
        )
        self.assertEqual(entry.field_state("description"), FieldState.present)


class FieldAvailabilityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.records = [
            support.record(1),
            support.record(2, description=""),
            support.record(
                3, description="key: value", flags=(QualityFlag.raw_yaml_description,)
            ),
            support.record(
                4,
                description="",
                eligibility=RecommendationEligibility.recommendation_ineligible,
            ),
        ]

    def test_counts_cover_baseline_input_only(self) -> None:
        report = field_availability(support.corpus(self.records))
        description = next(item for item in report.availability if item.name == "description")
        self.assertEqual(
            (description.present, description.missing, description.malformed), (1, 1, 1)
        )
        self.assertEqual(description.missing_ids, (support.component_id(2),))
        self.assertEqual(report.excluded, {"eligibility:recommendation_ineligible": 1})
        self.assertEqual((report.published, report.baseline_input), (4, 3))
        self.assertEqual(report.not_published_fields, NOT_PUBLISHED_FIELDS)

    def test_render_names_the_unpublished_fields(self) -> None:
        text = render_field_availability(field_availability(support.corpus(self.records)))
        self.assertIn("Not carried by the canonical publication: triggers, tools, tags.", text)
        self.assertIn("| description | 1 | 1 | 1 |", text)

    def test_access_filtering_is_reported_as_not_applied(self) -> None:
        report = field_availability(support.corpus(self.records, access_policy_revision=None))
        self.assertEqual(report.access_filtering, "not_applied")
