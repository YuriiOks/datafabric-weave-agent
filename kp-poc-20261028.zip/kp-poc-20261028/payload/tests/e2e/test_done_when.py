"""The three "done when" lines of the plan, asserted end to end.

Once through :mod:`kp.app` (the same objects the command line uses) and once through
``kp.cli.main("demo")``, which also writes the report and the summary.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path

import pytest

from kp.app import Application, build_application
from kp.cli import main
from kp.clock import FixedClock
from kp.demo.build import BuildRun, run_build
from kp.demo.model import DONE_WHEN, Check, LineResult
from kp.demo.runner import demo_settings
from kp.demo.staging import StagedData, find_dataset, stage
from kp.demo.week1 import evaluate_week1
from kp.demo.week2 import evaluate_week2
from kp.demo.week3 import evaluate_week3
from kp.writeback import resolve_git_binary

FAILED = "forced failure"


@pytest.fixture(scope="module")
def judged(
    committed_fixtures_dir: Path, tmp_path_factory: pytest.TempPathFactory
) -> Iterator[tuple[LineResult, LineResult, LineResult]]:
    """Build once through the application, then judge the three lines."""
    work = tmp_path_factory.mktemp("e2e")
    staged: StagedData = stage(find_dataset(committed_fixtures_dir), work)
    clock = FixedClock(staged.demo_instant())
    application: Application = build_application(
        demo_settings(staged, work, work / "e2e.db"), clock=clock, sleeper=lambda _seconds: None
    )
    try:
        build: BuildRun = run_build(application, staged)
        yield (
            evaluate_week1(application, staged, build),
            evaluate_week2(application, staged, build),
            evaluate_week3(application, build, clock),
        )
    finally:
        application.close()


def _failures(line: LineResult) -> list[str]:
    return [f"{check.name}: {check.evidence}" for check in line.checks if not check.passed]


def test_w1_sources_in_the_rulebook_register_and_stories_with_drafts_excluded(
    judged: tuple[LineResult, LineResult, LineResult],
) -> None:
    line = judged[0]

    assert _failures(line) == []
    assert line.passed
    assert line.done_when == DONE_WHEN["W1"]
    assert {check.name for check in line.checks} >= {
        "Every rule clause can be referenced on its own",
        "Drafts and unapproved versions excluded",
        "A status-only board move causes no rework",
    }


def test_w2_a_currency_question_returns_clause_4_2_1_and_both_questions_answer(
    judged: tuple[LineResult, LineResult, LineResult],
) -> None:
    line = judged[1]

    assert _failures(line) == []
    evidence = " ".join(check.evidence for check in line.checks)
    assert "2026.1 clause 4.2.1" in evidence
    assert "page 4, characters 4087-4321" in evidence
    assert "26 of 27 rules" in evidence  # clause 4.2.1 reaches a test through spec and code
    assert "6 stated, 0 guessed" in evidence
    for chain in ("story PAY-104", "spec spec-pay-104", "code src/payments/inbound.py::"):
        assert chain in evidence


def test_w3_one_story_goes_to_a_spec_pull_request_and_a_user_without_access_is_refused(
    judged: tuple[LineResult, LineResult, LineResult],
) -> None:
    line = judged[2]

    assert _failures(line) == []
    evidence = " ".join(check.evidence for check in line.checks)
    assert "pull request record" in evidence
    assert "code -32010" in evidence  # forbidden, not an empty answer


@pytest.fixture
def demo_args(tmp_path: Path, committed_fixtures_dir: Path) -> list[str]:
    return [
        "demo",
        "--data",
        str(committed_fixtures_dir),
        "--workdir",
        str(tmp_path / "work"),
        "--db",
        str(tmp_path / "out" / "demo.db"),
        "--report",
        str(tmp_path / "out" / "report.html"),
    ]


def test_kp_demo_exits_zero_when_all_three_lines_pass_and_writes_both_outputs(
    demo_args: list[str], tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(demo_args) == 0

    printed = capsys.readouterr().out
    for line_id in DONE_WHEN:
        assert f"{line_id} PASS" in printed
    assert "X-01" in printed
    assert "X-11" in printed
    assert (tmp_path / "out" / "demo.db").is_file()
    summary = json.loads((tmp_path / "out" / "summary.json").read_text(encoding="ascii"))
    assert summary["passed"] is True
    assert [line["id"] for line in summary["lines"]] == ["W1", "W2", "W3"]
    assert all(line["passed"] for line in summary["lines"])
    assert len(summary["connectivity"]["criteria"]) == 11


def test_the_report_is_self_contained_and_ascii_only(demo_args: list[str], tmp_path: Path) -> None:
    assert main(demo_args) == 0

    html = (tmp_path / "out" / "report.html").read_bytes()
    html.decode("ascii")
    text = html.decode("ascii")
    assert "<style>" in text
    for outside in ("http://", "https://", "<script", "<link", "src="):
        assert outside not in text
    assert all(words in text for words in (DONE_WHEN["W1"][:40], DONE_WHEN["W3"][:40]))


def test_running_the_demo_again_in_the_same_folder_gives_the_same_result(
    demo_args: list[str], tmp_path: Path
) -> None:
    assert main(demo_args) == 0
    (tmp_path / "out" / "demo.db").unlink()

    assert main(demo_args) == 0


def test_a_failing_line_makes_the_demo_exit_one_and_the_report_says_so(
    demo_args: list[str], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        "kp.demo.runner.evaluate_week2",
        lambda *_: LineResult("W2", (Check("forced", False, FAILED),)),
    )

    assert main(demo_args) == 1

    summary = json.loads((tmp_path / "out" / "summary.json").read_text(encoding="ascii"))
    assert summary["passed"] is False
    assert [line["passed"] for line in summary["lines"]] == [True, False, True]
    assert FAILED in (tmp_path / "out" / "report.html").read_text(encoding="ascii")


def test_without_a_dataset_the_demo_exits_two_with_a_message(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    empty = tmp_path / "empty"
    empty.mkdir()

    assert main(["demo", "--data", str(empty), "--workdir", str(tmp_path / "work")]) == 2
    assert "No synthetic dataset" in capsys.readouterr().err


def test_an_existing_database_is_never_overwritten(
    demo_args: list[str], tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    database = tmp_path / "out" / "demo.db"
    database.parent.mkdir()
    database.write_text("keep me", encoding="ascii")

    assert main(demo_args) == 2
    assert database.read_text(encoding="ascii") == "keep me"
    assert "already exists" in capsys.readouterr().err


@pytest.mark.parametrize("git_works", [False, True])
def test_the_demo_passes_with_either_spec_publisher(
    demo_args: list[str],
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    git_works: bool,
) -> None:
    real = resolve_git_binary()
    if git_works and real is None:
        pytest.skip("no working git binary (set KP_GIT_BINARY)")
    monkeypatch.setattr(
        "kp.adapters.publishers.resolve_git_binary", lambda **_: real if git_works else None
    )

    assert main(demo_args) == 0

    summary = json.loads((tmp_path / "out" / "summary.json").read_text(encoding="ascii"))
    assert summary["publisher"] == ("local_git" if git_works else "dry_run")
