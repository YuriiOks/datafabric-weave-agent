"""``kp demo``: the command line of the demo."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from kp.demo.model import DemoOutcome
from kp.demo.report import render_html, render_json
from kp.demo.runner import DemoOptions, run_demo
from kp.errors import KpError

DEFAULT_WORKDIR = Path("kp-demo")
REPORT_FILE = "report.html"
SUMMARY_FILE = "summary.json"


def add_parser(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Register ``demo``.

    :param subparsers: The subparsers action of the ``kp`` parser
    """
    parser = subparsers.add_parser(
        "demo", help="Run the platform end to end on the synthetic data and judge the plan"
    )
    parser.add_argument(
        "--data", type=Path, metavar="DIR", help="Synthetic dataset folder (default: the bundled)"
    )
    parser.add_argument("--db", type=Path, metavar="PATH", help="Database file to create")
    parser.add_argument("--report", type=Path, metavar="PATH", help="HTML report to write")
    parser.add_argument(
        "--summary",
        type=Path,
        metavar="PATH",
        help="JSON summary to write (default: beside report)",
    )
    parser.add_argument(
        "--workdir",
        type=Path,
        default=DEFAULT_WORKDIR,
        metavar="DIR",
        help=f"Folder for staged data and outputs (default: {DEFAULT_WORKDIR})",
    )
    parser.set_defaults(handler=handle)


def handle(args: argparse.Namespace) -> int:
    """Run the demo and print the three "done when" lines.

    :param args: Parsed arguments from :func:`add_parser`
    :return: 0 only if all three lines pass, 1 if one fails, 2 if the demo could not run
    """
    options = DemoOptions(data=args.data, database=args.db, workdir=args.workdir)
    root = logging.getLogger()
    level = root.level
    root.setLevel(logging.WARNING)  # the demo prints its own account; log lines would bury it
    try:
        outcome = run_demo(options)
    except KpError as exc:
        sys.stderr.write(f"kp demo: {exc}\n")
        return 2
    finally:
        root.setLevel(level)
    report = args.report or args.workdir / REPORT_FILE
    summary = args.summary or report.with_name(SUMMARY_FILE)
    report.parent.mkdir(parents=True, exist_ok=True)
    summary.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(render_html(outcome), encoding="ascii")
    summary.write_text(render_json(outcome), encoding="ascii")
    _print(outcome, report, summary)
    return 0 if outcome.passed else 1


def _print(outcome: DemoOutcome, report: Path, summary: Path) -> None:
    out = sys.stdout
    out.write(f"Demo as at {outcome.facts.demo_date}, spec publisher: {outcome.facts.publisher}\n")
    for name, text in outcome.facts.steps:
        out.write(f"  {name}: {text}\n")
    out.write("\n")
    for line in outcome.lines:
        out.write(line.summary + "\n")
        for check in line.checks:
            out.write(f"  {'PASS' if check.passed else 'FAIL'}  {check.name}\n")
            out.write(f"        {check.evidence}\n")
    out.write(f"\nConnectivity job (local stand-ins): {outcome.connectivity.verdict}\n")
    if outcome.connectivity.error:
        out.write(f"  not run: {outcome.connectivity.error}\n")
    for row in outcome.connectivity.rows:
        out.write(f"  {row.criterion_id:<5} {row.result:<13} {row.title}\n")
    out.write(f"\nReport:  {report}\nSummary: {summary}\n")
    out.write(f"Result: {'PASS' if outcome.passed else 'FAIL'}\n")
