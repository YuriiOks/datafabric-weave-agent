"""A minimal MCP server over JSON-RPC 2.0, standard library only, on stdio and HTTP.

It does not use the external MCP SDK, so it installs anywhere. The read and write servers are
separate entry points over :mod:`kp.tools`.
"""

from kp.mcp.cli import ServeWiring, add_parser, handle_serve_read, handle_serve_write
from kp.mcp.http import McpHttpGateway, create_http_server
from kp.mcp.identity import (
    IdentityHeaders,
    caller_from_environment,
    caller_from_headers,
)
from kp.mcp.jsonrpc import ErrorCode, JsonRpcError
from kp.mcp.server import McpServer
from kp.mcp.servers import (
    READ_SERVER_NAME,
    WRITE_SERVER_NAME,
    build_read_server,
    build_write_server,
)
from kp.mcp.stdio import serve_stdio

__all__ = [
    "READ_SERVER_NAME",
    "WRITE_SERVER_NAME",
    "ErrorCode",
    "IdentityHeaders",
    "JsonRpcError",
    "McpHttpGateway",
    "McpServer",
    "ServeWiring",
    "add_parser",
    "build_read_server",
    "build_write_server",
    "caller_from_environment",
    "caller_from_headers",
    "create_http_server",
    "handle_serve_read",
    "handle_serve_write",
    "serve_stdio",
]
