"""Scoring of the exit criteria X-01..X-11.

One rule runs through every scorer: a hop without evidence is not a pass. A criterion is
``PASS`` only when the evidence shows it, ``FAIL`` when the evidence shows it is not met, and
``INCONCLUSIVE`` when there is nothing to judge from. On the local route the criteria that are
about the platform itself can never be better than ``INCONCLUSIVE``, however clean the
stand-in run was.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Sequence
from math import ceil

from kp.config import Mode
from kp.connectivity.evidence import Evidence
from kp.connectivity.http_status import FORBIDDEN, OK_MAX, UNAUTHORIZED
from kp.connectivity.models import ItemOutcome, ItemStatus, RunActivity, RunResult
from kp.domain import ExitResult, ExtractionStatus, McpCallRecord, RunOutcome
from kp.domain.base import DomainModel
from kp.errors import SourceAuthRefusedError

_HTTP_OK_MIN = 200
_CREDENTIAL_REFUSALS = (UNAUTHORIZED, FORBIDDEN)
_PARAMETER_ERRORS = ("GatewayProtocolError", "ToolError")
_STAND_IN_ONLY = "Stand-in evidence only; it says nothing about the platform route."


class CriterionResult(DomainModel):
    """The verdict on one exit criterion."""

    id: str
    title: str
    result: ExitResult
    detail: str
    if_not_met: str


Scorer = Callable[[Evidence], tuple[ExitResult, str]]

_NO_EVIDENCE = (ExitResult.INCONCLUSIVE, "No evidence yet.")


def percentile(values: Sequence[float], fraction: float) -> float:
    """Return the nearest-rank percentile of ``values``.

    :param values: At least one measurement
    :param fraction: The percentile as a fraction, for example 0.95
    :return: The value at that rank
    """
    ordered = sorted(values)
    return ordered[max(0, ceil(fraction * len(ordered)) - 1)]


def is_success(call: McpCallRecord) -> bool:
    """Say whether a call got a 2xx answer without an error class.

    :param call: A call record
    :return: True for a successful exchange
    """
    return (
        call.http_status is not None
        and _HTTP_OK_MIN <= call.http_status <= OK_MAX
        and call.error_class is None
    )


def namespace_of(call: McpCallRecord) -> str:
    """Return the tool route a call record belongs to.

    :param call: A call record whose ``tool`` reads ``<namespace>/<tool>``
    :return: The namespace
    """
    return call.tool.split("/", maxsplit=1)[0]


def fetch_runs(evidence: Evidence) -> tuple[RunResult, ...]:
    """Pick the item-fetching runs of the evidence.

    :param evidence: Gathered evidence
    :return: Those runs, oldest first
    """
    return tuple(run for run in evidence.runs if run.activity is RunActivity.FETCH)


def non_probe_calls(evidence: Evidence) -> tuple[McpCallRecord, ...]:
    """Pick the calls that say something about the real credential, oldest first.

    The deliberate bad-credential probe is evidence for X-10 only: its refusals are provoked
    and must not count against a hop.

    :param evidence: Gathered evidence
    :return: The calls of every run except probe runs, in the order they were made
    """
    probes = {run.run_id for run in evidence.runs if run.activity is RunActivity.PROBE}
    kept = (call for call in evidence.calls if call.run_id not in probes)
    return tuple(sorted(kept, key=lambda call: (call.called_at, call.call_id)))


def latest_outcomes(evidence: Evidence) -> dict[str, ItemOutcome]:
    """Fold the fetch runs into the most recent outcome of each sample item.

    A fault fixed and re-run is not still a fault, and a fault in a run that stopped before
    reaching the item stays what it was.

    :param evidence: Gathered evidence
    :return: The latest outcome by item id
    """
    latest: dict[str, ItemOutcome] = {}
    for run in fetch_runs(evidence):
        for item in run.items:
            latest[item.item_id] = item
    return latest


def _x01(evidence: Evidence) -> tuple[ExitResult, str]:
    if not evidence.calls:
        return _NO_EVIDENCE
    answered = sum(1 for call in evidence.calls if call.http_status is not None)
    if answered:
        return ExitResult.PASS, f"The gateway answered {answered} of {len(evidence.calls)} calls."
    return ExitResult.FAIL, f"No answer from the gateway in {len(evidence.calls)} calls."


def _x02(evidence: Evidence) -> tuple[ExitResult, str]:
    calls = non_probe_calls(evidence)
    listed = {
        namespace_of(call) for call in calls if call.operation == "tools/list" and is_success(call)
    }
    wanted = set(evidence.namespaces.values())
    refused = sorted(
        {
            namespace_of(call)
            for call in calls
            if call.operation == "tools/list" and call.http_status in _CREDENTIAL_REFUSALS
        }
        - listed
    )
    if wanted <= listed:
        return ExitResult.PASS, f"Tool lists received from all {len(wanted)} servers."
    if refused:
        return ExitResult.FAIL, f"Sign-in or group check refused for: {', '.join(refused)}."
    if not listed:
        return _NO_EVIDENCE
    return ExitResult.INCONCLUSIVE, f"Tool lists from {len(listed)} of {len(wanted)} servers only."


def _x03(evidence: Evidence) -> tuple[ExitResult, str]:
    discovered = any(run.activity is RunActivity.DISCOVER for run in evidence.runs)
    wanted = sorted(set(evidence.namespaces.values()))
    missing = [name for name in wanted if evidence.signature_counts.get(name, 0) == 0]
    if not discovered and not evidence.signature_counts:
        return _NO_EVIDENCE
    if missing:
        return ExitResult.FAIL, f"No tool signatures kept for: {', '.join(missing)}."
    total = sum(evidence.signature_counts.get(name, 0) for name in wanted)
    return ExitResult.PASS, f"{total} tool signatures kept for {len(wanted)} servers."


def _x04(evidence: Evidence) -> tuple[ExitResult, str]:
    runs = fetch_runs(evidence)
    if not runs:
        return _NO_EVIDENCE
    latest = runs[-1]
    fetched = [item for item in latest.items if item.status is not ItemStatus.FAILED]
    failed = latest.failed_items
    if failed:
        types = sorted({item.media_type for item in failed})
        names = ", ".join(item.item_id for item in failed)
        return (
            ExitResult.FAIL,
            f"{len(fetched)} of {evidence.sample_total} retrieved (partial pass). "
            f"Unreachable: {names}. Types to record: {', '.join(types)}.",
        )
    if len(fetched) < evidence.sample_total:
        return (
            ExitResult.INCONCLUSIVE,
            f"The latest run reached {len(fetched)} of {evidence.sample_total} items.",
        )
    return (
        ExitResult.PASS,
        f"All {evidence.sample_total} items retrieved, attachments and binaries included.",
    )


def _x05(evidence: Evidence) -> tuple[ExitResult, str]:
    runs = fetch_runs(evidence)
    if not runs:
        return _NO_EVIDENCE
    lost = sorted(
        item.item_id
        for item in latest_outcomes(evidence).values()
        if item.error_class == "FidelityError"
    )
    if lost:
        return (
            ExitResult.FAIL,
            f"Tools returned summaries or prose instead of source fields for: {', '.join(lost)}. "
            "The affected sources move to direct reads.",
        )
    if len(runs) < 2:  # noqa: PLR2004 - "two runs equal" is the criterion
        return (
            ExitResult.INCONCLUSIVE,
            "One run only; two runs are needed to show the version is stable.",
        )
    return _stable_versions(evidence, runs[-2], runs[-1])


def _stable_versions(
    evidence: Evidence, earlier: RunResult, later: RunResult
) -> tuple[ExitResult, str]:
    before = _versions(earlier)
    after = _versions(later)
    compared = sorted(before.keys() & after.keys())
    differing = [item_id for item_id in compared if before[item_id] != after[item_id]]
    if differing:
        return (
            ExitResult.FAIL,
            f"Version changed between the last two runs for: {', '.join(differing)}.",
        )
    if len(after) < evidence.sample_total:
        return (
            ExitResult.INCONCLUSIVE,
            f"A version was derived for {len(after)} of {evidence.sample_total} items.",
        )
    if len(compared) < evidence.sample_total:
        return (
            ExitResult.INCONCLUSIVE,
            f"Only {len(compared)} of {evidence.sample_total} items have a version in both of "
            "the last two runs.",
        )
    return ExitResult.PASS, f"A version derived for all {len(after)} items, equal across two runs."


def _versions(run: RunResult) -> dict[str, str]:
    return {item.item_id: item.version for item in run.items if item.version is not None}


def _renewed_mid_run(evidence: Evidence, run: RunResult) -> bool:
    """Say whether a run replaced an existing token after its first call.

    The first call of a run is excluded: a renewal there says the token was already old when
    the run began, not that the run outlived it.
    """
    calls = sorted(
        (call for call in evidence.calls if call.run_id == run.run_id),
        key=lambda call: (call.called_at, call.call_id),
    )
    return any(call.token_refreshed for call in calls[1:])


def _x06(evidence: Evidence) -> tuple[ExitResult, str]:
    limit = evidence.token_lifetime_seconds
    long_runs = [run for run in evidence.runs if run.duration_seconds > limit]
    if not long_runs:
        return (
            ExitResult.INCONCLUSIVE,
            f"No run lasted longer than the {limit / 60:.0f}-minute token lifetime.",
        )
    refused = [run for run in long_runs if run.abort_reason == SourceAuthRefusedError.__name__]
    if refused:
        return (
            ExitResult.FAIL,
            "A run longer than the token lifetime stopped on a refused credential.",
        )
    if any(_renewed_mid_run(evidence, run) for run in long_runs):
        return (
            ExitResult.PASS,
            "A run longer than the token lifetime renewed its token and finished.",
        )
    return (
        ExitResult.INCONCLUSIVE,
        "A long run finished without replacing its token; expiry was not exercised.",
    )


def _x07(evidence: Evidence) -> tuple[ExitResult, str]:
    if not evidence.items:
        return _NO_EVIDENCE
    problems: dict[str, list[str]] = defaultdict(list)
    pending = 0
    for item in evidence.items:
        if item.extraction_status is ExtractionStatus.PENDING:
            pending += 1
            continue
        if item.extraction_status is ExtractionStatus.FAILED:
            problems[item.media_type].append(f"{item.item_id} (extraction failed)")
            continue
        if not item.markdown_chars:
            problems[item.media_type].append(f"{item.item_id} (no Markdown)")
        if item.manifest_problems is None:
            problems[item.media_type].append(f"{item.item_id} (no manifest)")
        elif item.manifest_problems:
            problems[item.media_type].append(
                f"{item.item_id} (manifest lacks {', '.join(item.manifest_problems)})"
            )
    if problems:
        by_type = "; ".join(
            f"{media}: {', '.join(names)}" for media, names in sorted(problems.items())
        )
        return ExitResult.FAIL, f"Weak by file type: {by_type}."
    if pending or len(evidence.items) < evidence.sample_total:
        return (
            ExitResult.INCONCLUSIVE,
            f"{len(evidence.items) - pending} of {evidence.sample_total} items have outputs "
            "to judge.",
        )
    return (
        ExitResult.PASS,
        f"Non-empty Markdown and a complete manifest for all {len(evidence.items)} items.",
    )


def _x08(evidence: Evidence) -> tuple[ExitResult, str]:
    comparable = [item for item in evidence.items if item.manifest_sha256 is not None]
    if not comparable:
        return _NO_EVIDENCE
    wrong = sorted(
        item.item_id
        for item in comparable
        if not (item.raw_sha256 == item.manifest_sha256 == item.row_sha256)
    )
    if wrong:
        return (
            ExitResult.FAIL,
            f"Stored file fingerprint differs from the manifest for: {', '.join(wrong)}.",
        )
    if len(comparable) < evidence.sample_total:
        return (
            ExitResult.INCONCLUSIVE,
            f"Fingerprints compared for {len(comparable)} of {evidence.sample_total} items.",
        )
    return (
        ExitResult.PASS,
        f"Stored fingerprint equals manifest fingerprint for all {len(comparable)} items.",
    )


def _x09(evidence: Evidence) -> tuple[ExitResult, str]:
    runs = fetch_runs(evidence)
    if len(runs) < 2:  # noqa: PLR2004 - a re-run needs a first run
        return (
            _NO_EVIDENCE
            if not runs
            else (ExitResult.INCONCLUSIVE, "Only one run; a re-run is needed.")
        )
    latest = runs[-1]
    altered = sorted(item.item_id for item in evidence.items if item.raw_sha256 != item.row_sha256)
    if latest.stored_count:
        return (
            ExitResult.FAIL,
            f"The re-run stored {latest.stored_count} new item versions (our defect).",
        )
    if altered:
        return ExitResult.FAIL, f"Stored files changed for: {', '.join(altered)} (our defect)."
    unchanged = sum(1 for item in latest.items if item.status is ItemStatus.UNCHANGED)
    if latest.abort_reason is not None:
        return (
            ExitResult.INCONCLUSIVE,
            f"The latest run stopped early ({latest.abort_reason}) after {len(latest.items)} of "
            f"{evidence.sample_total} items; the re-run is not shown.",
        )
    if latest.outcome is not RunOutcome.SUCCEEDED or unchanged < evidence.sample_total:
        return (
            ExitResult.INCONCLUSIVE,
            f"The latest run found {unchanged} of {evidence.sample_total} items unchanged; "
            "it is not a clean re-run.",
        )
    return (
        ExitResult.PASS,
        f"The re-run added nothing: {unchanged} items unchanged, no file changed.",
    )


def _x10(evidence: Evidence) -> tuple[ExitResult, str]:
    probe_runs = {run.run_id for run in evidence.runs if run.activity is RunActivity.PROBE}
    calls = [call for call in evidence.calls if call.run_id in probe_runs]
    credential = any(call.http_status in _CREDENTIAL_REFUSALS for call in calls)
    parameter = any(call.error_class in _PARAMETER_ERRORS for call in calls)
    if credential and parameter:
        return (
            ExitResult.PASS,
            "A bad credential and a bad parameter each produced a recorded, distinct error.",
        )
    if not calls:
        return _NO_EVIDENCE
    missing = [
        name
        for name, seen in (("bad credential", credential), ("bad parameter", parameter))
        if not seen
    ]
    return ExitResult.INCONCLUSIVE, f"Not yet characterised: {', '.join(missing)}."


def _x11(evidence: Evidence) -> tuple[ExitResult, str]:
    timings: dict[tuple[str, str], list[float]] = defaultdict(list)
    for call in evidence.calls:
        if is_success(call):
            timings[(namespace_of(call), call.operation)].append(call.latency_ms)
    if not timings:
        return _NO_EVIDENCE
    missing = [
        f"{namespace} {operation}"
        for namespace in sorted(set(evidence.namespaces.values()))
        for operation in ("tools/list", "tools/call")
        if (namespace, operation) not in timings
    ]
    summary = (
        "; ".join(
            f"{namespace} {operation}: p50 {percentile(values, 0.5):.0f} ms, "
            f"p95 {percentile(values, 0.95):.0f} ms (n={len(values)})"
            for (namespace, operation), values in sorted(timings.items())
        )
        + "."
    )
    if missing:
        return ExitResult.INCONCLUSIVE, f"No timing for: {', '.join(missing)}. {summary}"
    return ExitResult.PASS, summary


# id, title, if not met (SPEC 4.6), scorer, true when the criterion is about the platform route
_CRITERIA: tuple[tuple[str, str, str, Scorer, bool], ...] = (
    (
        "X-01",
        "Network route to the gateway works (any response, even a refusal)",
        "Blocking; escalate D-01",
        _x01,
        True,
    ),
    (
        "X-02",
        "Sign-in succeeds and the group allows the call; tool list from all 3 servers",
        "Blocking; D-03, D-04",
        _x02,
        True,
    ),
    ("X-03", "Tool signatures captured and kept for all 3 servers", "Blocking", _x03, False),
    (
        "X-04",
        "All 9 items retrieved, including attachments and binaries",
        "Partial pass; record unreachable types",
        _x04,
        False,
    ),
    (
        "X-05",
        "Stable version derivable for every item from returned fields; two runs equal",
        "Serious: summaries, not source fields; move to direct reads",
        _x05,
        False,
    ),
    (
        "X-06",
        "A run longer than 30 minutes survives token expiry",
        "Fatal for unattended running",
        _x06,
        True,
    ),
    (
        "X-07",
        "Non-empty Markdown and a complete manifest for every item",
        "Record by file type; Excel expected weak",
        _x07,
        False,
    ),
    ("X-08", "Stored file fingerprint equals the manifest fingerprint", "Fatal", _x08, False),
    ("X-09", "Re-run changes nothing (same count, files unchanged)", "Our defect", _x09, False),
    (
        "X-10",
        "Gateway errors characterised (bad credential, bad parameter)",
        "Not fatal",
        _x10,
        True,
    ),
    (
        "X-11",
        "Time per hop recorded (percentiles by operation)",
        "Not fatal; cross-region figure",
        _x11,
        True,
    ),
)


def score_criteria(evidence: Evidence) -> tuple[CriterionResult, ...]:
    """Score all eleven exit criteria from the evidence.

    On the local route, criteria about the platform itself are capped at ``INCONCLUSIVE``.

    :param evidence: Gathered evidence
    :return: One result per criterion, X-01 to X-11
    """
    results = []
    for criterion_id, title, if_not_met, scorer, route_only in _CRITERIA:
        result, detail = scorer(evidence)
        if evidence.mode is Mode.LOCAL and route_only and result is ExitResult.PASS:
            result, detail = ExitResult.INCONCLUSIVE, f"{detail} {_STAND_IN_ONLY}"
        results.append(
            CriterionResult(
                id=criterion_id, title=title, result=result, detail=detail, if_not_met=if_not_met
            )
        )
    return tuple(results)
