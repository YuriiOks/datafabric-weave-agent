"""Stated links from the rule-reference column of the requirements register."""

from __future__ import annotations

from collections.abc import Collection, Iterable

from kp.domain import ItemRef, ItemType, Relation, Requirement
from kp.links.candidate import LinkCandidate
from kp.links.refs import clause_item, split_clause_refs
from kp.links.stated.model import RejectedLink, StatedLinkSet, keep_conforming

DEFAULT_REFERENCE_FIELD = "Rule reference"


def _normalise(header: str) -> str:
    return " ".join(header.casefold().split())


def register_link_set(
    requirements: Iterable[Requirement],
    *,
    reference_field: str = DEFAULT_REFERENCE_FIELD,
    editions: Collection[str] | None = None,
) -> StatedLinkSet:
    """Turn the rule references of register rows into ``constrained_by`` links.

    A cell may name several clauses. A cell with text but no readable reference is reported
    as rejected, and so is a reference to an edition that is not loaded (when ``editions``
    is given); an empty cell simply states nothing.

    :param requirements: Loaded register rows
    :param reference_field: Header of the rule-reference column, compared ignoring case and spacing
    :param editions: Loaded edition labels; references to any other edition are rejected
    :return: The stated links, the unreadable cells and the scope enumerated
    """
    wanted = _normalise(reference_field)
    rows = list(requirements)
    candidates: list[tuple[str, LinkCandidate]] = []
    rejected: list[RejectedLink] = []
    for row in rows:
        source = ItemRef(item_type=ItemType.REQUIREMENT, key=row.requirement_id)
        cell = next(
            (value for header, value in row.fields.items() if _normalise(header) == wanted), ""
        ).strip()
        if not cell:
            continue
        origin = f"{row.requirement_id} row {row.row_number}"
        references, unknown = split_clause_refs(cell, editions)
        if not references and not unknown:
            rejected.append(RejectedLink(origin=origin, reason="no clause reference in the cell"))
        rejected.extend(
            RejectedLink(origin=origin, reason=f"edition {ref.edition} is not loaded")
            for ref in unknown
        )
        candidates.extend(
            (
                origin,
                LinkCandidate.stated(
                    source, Relation.CONSTRAINED_BY, clause_item(ref), evidence=origin
                ),
            )
            for ref in references
        )
    links, violations = keep_conforming(candidates)
    return StatedLinkSet(
        links=links,
        rejected=tuple(rejected) + violations,
        owned_sources=frozenset(
            ItemRef(item_type=ItemType.REQUIREMENT, key=row.requirement_id) for row in rows
        ),
        relations=frozenset({Relation.CONSTRAINED_BY}),
    )
