"""Regular-expression fragments shared by the rulebook parsers."""

from __future__ import annotations

# Same shape as ``kp.domain.clause_ref``: no leading zeros, so a number has one spelling.
CLAUSE_NUMBER = r"(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))*"
