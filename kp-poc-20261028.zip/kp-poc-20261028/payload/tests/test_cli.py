"""The ``kp`` command line: every command registered, wired to the application."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from kp.cli import build_parser, main
from kp.demo.runner import demo_settings
from kp.demo.staging import StagedData, find_dataset, stage

COMMANDS = {
    "sweep",
    "search",
    "impact",
    "coverage",
    "publish",
    "connectivity",
    "serve-read",
    "serve-write",
    "draft-spec",
    "merge-spec",
    "corrections",
    "init-db",
    "demo",
}


@pytest.fixture
def cli_world(
    committed_fixtures_dir: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> StagedData:
    """Stage the data and point the process environment at it, as an operator would."""
    for name in [name for name in os.environ if name.startswith("KP_")]:
        monkeypatch.delenv(name)
    staged = stage(find_dataset(committed_fixtures_dir), tmp_path)
    staged.reveal_second_jira_export()
    settings = demo_settings(staged, tmp_path, tmp_path / "cli.db")
    environment = {
        "KP_DATABASE_URL": settings.database_url.get_secret_value(),
        "KP_DATA_DIR": str(settings.data_dir),
        "KP_DOCUMENT_LIBRARY_ROOT": str(staged.library),
        "KP_REGULATORY_REPO_PATH": str(staged.regulatory),
        "KP_CONFLUENCE_EXPORT_PATH": str(staged.confluence),
        "KP_JIRA_EXPORT_PATH": str(staged.jira),
        "KP_CODE_REPO_PATH": str(staged.code_repo),
        "KP_IDENTITY_MAPPING_FILE": str(staged.identity_mapping),
        "KP_SPEC_REPO": "example-org/example-specs",
        "KP_SPEC_PATH": "specs",
        "KP_JIRA_FIELDS_ALLOWED": json.dumps(["status", "spec_link"]),
        "KP_LOG_LEVEL": "WARNING",
    }
    for name, value in environment.items():
        monkeypatch.setenv(name, value)
    return staged


def test_every_command_is_registered_and_none_is_a_stub(capsys: pytest.CaptureFixture[str]) -> None:
    parser = build_parser()

    help_text = parser.format_help()

    assert all(name in help_text for name in COMMANDS)
    with pytest.raises(SystemExit):
        main(["no-such-command"])
    assert "not implemented" not in capsys.readouterr().err


def test_init_db_creates_the_tables_and_loads_the_governed_templates(
    cli_world: StagedData, capsys: pytest.CaptureFixture[str]
) -> None:
    status = main(["init-db", "--templates", str(cli_world.templates)])

    assert status == 0
    assert "1 templates loaded" in capsys.readouterr().out


def test_init_db_reports_a_template_that_is_not_usable(
    cli_world: StagedData, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    broken = tmp_path / "broken"
    broken.mkdir()
    (broken / "bad.md").write_text("no front matter", encoding="utf-8")

    assert main(["init-db", "--templates", str(broken)]) == 1
    assert "kp init-db" in capsys.readouterr().err


def test_the_operator_flow_from_sweep_to_a_published_spec(
    cli_world: StagedData, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["init-db", "--templates", str(cli_world.templates)]) == 0
    assert main(["sweep"]) == 0
    swept = capsys.readouterr().out
    assert "succeeded" in swept
    assert "links: repository" in swept

    assert main(["sweep", "--freshness"]) == 0
    assert (
        main(
            [
                "search",
                "which currency may an inbound credit transfer use?",
                "--as-at",
                "2026-11-20",
                "--limit",
                "3",
            ]
        )
        == 0
    )
    found = capsys.readouterr().out
    assert "1. 2026.1 clause 4.2.1" in found
    assert "page 4" in found

    assert main(["impact", "2026.1:4.2.1"]) == 0
    assert "requirement" in capsys.readouterr().out

    assert main(["coverage", "--edition", "2026.1"]) == 0
    assert "Rules with no test" in capsys.readouterr().out

    assert main(["publish", "--dry-run"]) == 0
    capsys.readouterr()
    assert main(["publish"]) == 0
    assert "Published knowledge version" in capsys.readouterr().out

    assert main(["draft-spec", "PAY-101", "--as-at", "2026-11-20"]) == 0
    assert "## Rules" in capsys.readouterr().out
    assert main(["draft-spec", "PAY-101", "--as-at", "2026-11-20", "--publish"]) == 0
    assert "pr_url" in capsys.readouterr().out


def test_a_merged_spec_comes_back_through_the_operator_commands_and_gives_a_rule_a_test(
    cli_world: StagedData, capsys: pytest.CaptureFixture[str]
) -> None:
    """Sweep, draft and publish a spec, merge it, sweep again: the whole US-23 loop by command."""
    assert main(["init-db", "--templates", str(cli_world.templates)]) == 0
    assert main(["sweep"]) == 0
    capsys.readouterr()
    assert main(["coverage", "--edition", "2026.1", "--json"]) == 0
    before = json.loads(capsys.readouterr().out)
    assert "2026.1:4.2.1" in _untested(before)

    assert main(["draft-spec", "PAY-104", "--as-at", "2026-11-20", "--publish"]) == 0
    assert "pr_url" in capsys.readouterr().out
    assert main(["merge-spec", "PAY-104"]) == 0
    assert "kp sweep" in capsys.readouterr().out
    assert main(["sweep"]) == 0
    capsys.readouterr()

    assert main(["coverage", "--edition", "2026.1", "--json"]) == 0
    after = json.loads(capsys.readouterr().out)
    assert "2026.1:4.2.1" not in _untested(after)
    assert main(["impact", "2026.1:4.2.1", "--json"]) == 0
    impact = json.loads(capsys.readouterr().out)
    assert {"story", "spec", "code", "test"} <= {
        item["ref"]["item_type"] for item in impact["items"]
    }

    assert main(["draft-spec", "PAY-104", "--as-at", "2026-11-20", "--publish"]) == 0
    assert "already has a merged spec" in capsys.readouterr().out


def _untested(report: dict[str, object]) -> list[str]:
    rules = report["without_tests"]
    assert isinstance(rules, list)
    return [rule["reference"] for rule in rules]


def test_merging_a_spec_that_was_never_published_says_so(
    cli_world: StagedData, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["init-db", "--templates", str(cli_world.templates)]) == 0

    assert main(["merge-spec", "PAY-104"]) == 1
    assert "kp merge-spec" in capsys.readouterr().err


def test_a_command_with_unusable_settings_exits_with_a_message(
    cli_world: StagedData, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("KP_MODE", "real")

    assert main(["sweep"]) == 2
    assert "KP_MODE=real requires" in capsys.readouterr().err


def test_the_agent_servers_say_what_is_missing_when_there_is_no_identity_mapping(
    cli_world: StagedData, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.delenv("KP_IDENTITY_MAPPING_FILE")

    assert main(["serve-read"]) == 2
    assert "KP_IDENTITY_MAPPING_FILE" in capsys.readouterr().err
