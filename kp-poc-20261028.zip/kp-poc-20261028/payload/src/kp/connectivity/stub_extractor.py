"""Local stand-in for the document extraction service.

Reads the raw object from its storage reference, converts it, and writes the Markdown document
and the JSON manifest sidecar beside each other in the Markdown store, exactly where the
contract says the real service does. It can be called directly (it satisfies
:class:`~kp.connectivity.ports.ExtractionPort`) or reached through
:meth:`StubExtractionService.transport`, so the real HTTP client is exercised too.
"""

from __future__ import annotations

import json

import httpx
from pydantic import ValidationError

from kp.clock import Clock
from kp.connectivity.conversion import to_markdown
from kp.connectivity.digest import sha256_hex
from kp.connectivity.errors import ExtractionError
from kp.connectivity.models import ExtractionRequest, ExtractionResponse, Manifest
from kp.connectivity.ports import ObjectStore

STUB_EXTRACTOR_VERSION = "stub-extractor/1.0"
MARKDOWN_SUFFIX = ".md"
MANIFEST_SUFFIX = ".manifest.json"


class StubExtractionService:
    """The stand-in service.

    :param raw_store: Where it reads raw objects from
    :param markdown_store: Where it writes Markdown and manifests
    :param clock: Time source for ``extracted_at``
    :param extractor_version: The version it reports; empty to provoke the mandatory-version error
    """

    def __init__(
        self,
        raw_store: ObjectStore,
        markdown_store: ObjectStore,
        clock: Clock,
        *,
        extractor_version: str = STUB_EXTRACTOR_VERSION,
    ) -> None:
        self._raw = raw_store
        self._markdown = markdown_store
        self._clock = clock
        self._extractor_version = extractor_version
        self.requests: list[ExtractionRequest] = []

    def extract(self, request: ExtractionRequest) -> ExtractionResponse:
        """Convert one stored object and write its outputs.

        :param request: Identity, storage reference, declared media type and source type
        :return: The output references and the extractor version
        :raises kp.connectivity.errors.ExtractionError: If the object is missing or cannot be
            converted
        """
        self.requests.append(request)
        raw_key = self._raw.key_of(request.storage_reference)
        try:
            data = self._raw.get(raw_key)
        except KeyError:
            raise ExtractionError(
                f"No stored object at the reference for {request.item_id}"
            ) from None
        markdown_key = f"{raw_key}{MARKDOWN_SUFFIX}"
        manifest_key = f"{raw_key}{MANIFEST_SUFFIX}"
        warnings: tuple[str, ...] = ()
        page_count: int | None = None
        if not (self._markdown.exists(markdown_key) and self._markdown.exists(manifest_key)):
            text, page_count = to_markdown(request.media_type, data)
            if not text.strip():
                warnings = ("no text could be extracted",)
            self._markdown.put_if_absent(markdown_key, text.encode("utf-8"))
            self._markdown.put_if_absent(manifest_key, self._manifest(request, data))
        return ExtractionResponse(
            item_id=request.item_id,
            markdown_location=self._markdown.location(markdown_key),
            manifest_location=self._markdown.location(manifest_key),
            extractor_version=self._extractor_version,
            page_count=page_count,
            warnings=warnings,
        )

    def transport(self) -> httpx.MockTransport:
        """Serve this stand-in over HTTP for the real client to talk to.

        :return: A transport answering every POST as the extraction endpoint
        """
        return httpx.MockTransport(self._handle)

    def _handle(self, request: httpx.Request) -> httpx.Response:
        try:
            extraction_request = ExtractionRequest.model_validate_json(request.content)
        except ValidationError:
            return httpx.Response(422, json={"error": "invalid request"})
        try:
            response = self.extract(extraction_request)
        except ExtractionError as exc:
            return httpx.Response(422, json={"error": str(exc)})
        return httpx.Response(200, json=response.model_dump(mode="json"))

    def _manifest(self, request: ExtractionRequest, data: bytes) -> bytes:
        hints = request.hints
        modified = hints.get("modified_at")
        manifest = Manifest.model_validate(
            {
                "item_id": request.item_id,
                "source_type": request.source_type,
                "native_id": hints.get("native_id", request.item_id),
                "version": request.version,
                "content_sha256": sha256_hex(data),
                "title": hints.get("title", ""),
                "author": hints.get("author"),
                "modified_at": modified if modified else None,
                "extracted_at": self._clock.now(),
                "extractor_version": self._extractor_version or STUB_EXTRACTOR_VERSION,
            }
        )
        return (
            json.dumps(manifest.model_dump(mode="json"), sort_keys=True, indent=2) + "\n"
        ).encode("utf-8")
