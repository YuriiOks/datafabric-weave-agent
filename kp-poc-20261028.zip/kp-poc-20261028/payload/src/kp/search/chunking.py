"""Splitting text into character spans of a token budget.

Spans are half-open ``(start, end)`` offsets into the original text, so a passage built from
a span quotes the source exactly and its position is a plain offset.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from re import Pattern

from kp.search.tokens import count_tokens

Span = tuple[int, int]

PARAGRAPH = re.compile(r"\n[ \t]*\n")
SENTENCE = re.compile(r"(?<=[.!?])\s+")
LINE = re.compile(r"\n")
_WORD = re.compile(r"\S+")


def word_spans(text: str) -> list[Span]:
    """Locate every whitespace-separated word.

    :param text: Any text
    :return: One span per word
    """
    return [(match.start(), match.end()) for match in _WORD.finditer(text)]


def window_spans(text: str, size: int, overlap: int) -> list[Span]:
    """Cut text into overlapping windows of ``size`` words.

    :param text: Any text
    :param size: Words per window
    :param overlap: Words shared by consecutive windows; must be smaller than ``size``
    :return: Windows from the start to the end of the text; a text of at most ``size`` words
        yields one window, an empty text none
    :raises ValueError: If ``overlap`` is not smaller than ``size``
    """
    if overlap >= size:
        raise ValueError("overlap must be smaller than size")
    words = word_spans(text)
    windows: list[Span] = []
    start = 0
    while start < len(words):
        end = min(start + size, len(words))
        windows.append((words[start][0], words[end - 1][1]))
        if end == len(words):
            break
        start = end - overlap
    return windows


def split_span(text: str, span: Span, target: int, levels: Sequence[Pattern[str]]) -> list[Span]:
    """Split ``span`` at natural boundaries into parts of about ``target`` tokens.

    Text is first cut at the coarsest separator in ``levels`` (for example blank lines). A
    piece still over the budget is cut at the next separator, and one with no separator
    left falls back to word windows. Pieces are then packed greedily: a part grows until the
    next piece would push it over ``target``.

    :param text: The full source text
    :param span: The range of ``text`` to split
    :param target: Token budget per part
    :param levels: Separators from coarse to fine
    :return: Contiguous-order parts; each is an exact slice of ``text``
    """
    pieces = _pieces(text, span, target, levels)
    parts: list[Span] = []
    current: Span | None = None
    current_tokens = 0
    for piece in pieces:
        tokens = count_tokens(text[piece[0] : piece[1]])
        if current is not None and current_tokens + tokens > target:
            parts.append(current)
            current = None
        if current is None:
            current, current_tokens = piece, tokens
        else:
            current, current_tokens = (current[0], piece[1]), current_tokens + tokens
    if current is not None:
        parts.append(current)
    return parts


def _pieces(text: str, span: Span, target: int, levels: Sequence[Pattern[str]]) -> list[Span]:
    if not levels:
        return [
            (span[0] + start, span[0] + end)
            for start, end in window_spans(text[span[0] : span[1]], target, 0)
        ]
    pieces: list[Span] = []
    for piece in _cut(text, span, levels[0]):
        if count_tokens(text[piece[0] : piece[1]]) > target:
            pieces.extend(_pieces(text, piece, target, levels[1:]))
        else:
            pieces.append(piece)
    return pieces


def _cut(text: str, span: Span, separator: Pattern[str]) -> list[Span]:
    """Cut ``span`` at ``separator`` and trim each non-empty piece to its visible text."""
    start, end = span
    pieces: list[Span] = []
    cursor = start
    boundaries = [(m.start(), m.end()) for m in separator.finditer(text, start, end)]
    for boundary_start, boundary_end in [*boundaries, (end, end)]:
        piece = _trim(text, cursor, boundary_start)
        if piece is not None:
            pieces.append(piece)
        cursor = boundary_end
    return pieces


def _trim(text: str, start: int, end: int) -> Span | None:
    chunk = text[start:end]
    stripped = chunk.strip()
    if not stripped:
        return None
    lead = len(chunk) - len(chunk.lstrip())
    return (start + lead, start + lead + len(stripped))
