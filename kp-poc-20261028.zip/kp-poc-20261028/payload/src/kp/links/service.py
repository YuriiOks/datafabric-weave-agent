"""The facade of the links package: one object for writing, guessing and querying links."""

from __future__ import annotations

import logging
from collections.abc import Sequence
from datetime import datetime

from sqlalchemy import Connection

from kp.clock import Clock, SystemClock
from kp.config import Thresholds
from kp.domain import (
    MERGED_SPEC_EVIDENCE,
    ClauseRef,
    DomainModel,
    ItemRef,
    ItemType,
    Link,
    LinkState,
    Relation,
)
from kp.errors import InvalidClauseRefError
from kp.links.candidate import LinkCandidate
from kp.links.coverage import (
    CoverageReport,
    RulesWithoutTests,
    measure_coverage,
    rules_without_tests,
)
from kp.links.errors import UnknownClauseError
from kp.links.graph import LinkGraph
from kp.links.guessed import GuessedLinkProposer, GuessItem, GuessReport, LinkScorer
from kp.links.impact import IMPACT_MAX_STEPS, ImpactReport, impact_of_clause
from kp.links.ports import LinkReader, SimilarityPort
from kp.links.refs import clause_item, source_path_of
from kp.links.rules import RuleCatalog, loaded_story_keys
from kp.links.stated import RejectedLink, StatedLinkSet
from kp.links.store import AssertedLink, AssertOutcome, LinkStatistics, SqlLinkStore

logger = logging.getLogger(__name__)


_REPOSITORY_TYPES = frozenset({ItemType.CODE, ItemType.TEST, ItemType.SCHEMA_FIELD})


class SyncReport(DomainModel):
    """What applying a set of stated links changed.

    ``rejected`` counts every link that was not stored: those the loader could not express
    and those that point at a clause that is not loaded (``dangling``). ``rejections`` lists
    the dangling ones with their origin; the loader's own list stays on the stated set.
    """

    opened: int = 0
    changed: int = 0
    unchanged: int = 0
    closed: int = 0
    rejected: int = 0
    dangling: int = 0
    rejections: tuple[RejectedLink, ...] = ()


def _in_owned_path(ref: ItemRef, paths: frozenset[str]) -> bool:
    return ref.item_type in _REPOSITORY_TYPES and source_path_of(ref) in paths


class LinkService:
    """Writes links, guesses links, and answers the impact and coverage questions.

    Everything runs inside the caller's unit of work (``Database.transaction()``). Pass a
    :class:`~kp.links.ports.SimilarityPort` backed by search to replace the local term
    overlap used for guessed links.

    :param connection: A connection inside the caller's unit of work
    :param thresholds: Score bands and limits; the defaults of the platform when omitted
    :param clock: Time source; the system clock when omitted
    :param similarity: Search agreement for guessed links; local term overlap when omitted
    :param reader: Where the queries read links from; the SQL store when omitted
    """

    def __init__(
        self,
        connection: Connection,
        *,
        thresholds: Thresholds | None = None,
        clock: Clock | None = None,
        similarity: SimilarityPort | None = None,
        reader: LinkReader | None = None,
    ) -> None:
        self._connection = connection
        self._clock: Clock = clock if clock is not None else SystemClock()
        self._thresholds = thresholds if thresholds is not None else Thresholds()
        self._store = SqlLinkStore(connection, self._clock)
        self._reader: LinkReader = reader if reader is not None else self._store
        self._proposer = GuessedLinkProposer(self._store, LinkScorer(similarity), self._thresholds)
        self._rules = RuleCatalog(connection)

    @property
    def store(self) -> SqlLinkStore:
        """The underlying link store."""
        return self._store

    def apply_stated(self, stated: StatedLinkSet) -> SyncReport:
        """Make the links a source states true, and close those it no longer states.

        A link that ends at a clause that is not loaded is not stored: it is counted as
        dangling and listed in the report.

        :param stated: A loader's result
        :return: How many links were opened, changed, left alone, closed and rejected
        :raises LinkModelViolationError: If a link in the set violates the model
        """
        counts = {outcome: 0 for outcome in AssertOutcome}
        listed: set[tuple[ItemRef, Relation, ItemRef]] = set()
        dangling: list[RejectedLink] = []
        for candidate in stated.links:
            missing = next(
                (
                    ref
                    for ref in (candidate.source_ref, candidate.target_ref)
                    if ref.item_type is ItemType.CLAUSE and not self._clause_loaded(ref)
                ),
                None,
            )
            if missing is not None:
                dangling.append(
                    RejectedLink(
                        origin=candidate.evidence or candidate.source_ref.key,
                        reason=f"clause {missing.key} is not loaded",
                    )
                )
                continue
            listed.add(candidate.fact)
            counts[self._store.assert_link(candidate).outcome] += 1
        closed = 0
        for link in self._store.open_links({LinkState.STATED}):
            owned = (
                link.source_ref in stated.owned_sources
                or link.target_ref in stated.owned_targets
                or _in_owned_path(link.source_ref, stated.owned_paths)
                or _in_owned_path(link.target_ref, stated.owned_paths)
            )
            fact = (link.source_ref, link.relation, link.target_ref)
            if (
                link.relation in stated.relations
                and owned
                and fact not in listed
                and not link.evidence.startswith(MERGED_SPEC_EVIDENCE)
            ):
                self._store.close_fact(*fact)
                closed += 1
        logger.info(
            "Stated links applied",
            extra={
                "opened": counts[AssertOutcome.OPENED],
                "closed": closed,
                "dangling": len(dangling),
            },
        )
        return SyncReport(
            opened=counts[AssertOutcome.OPENED],
            changed=counts[AssertOutcome.CHANGED],
            unchanged=counts[AssertOutcome.UNCHANGED],
            closed=closed,
            rejected=len(stated.rejected) + len(dangling),
            dangling=len(dangling),
            rejections=tuple(dangling),
        )

    def _clause_loaded(self, ref: ItemRef) -> bool:
        try:
            return self._rules.exists(ClauseRef.parse(ref.key))
        except InvalidClauseRefError:
            return False

    def assert_link(self, candidate: LinkCandidate) -> AssertedLink:
        """Assert one link candidate. See :meth:`SqlLinkStore.assert_link`.

        :param candidate: The link content
        :return: The link now in force
        :raises LinkModelViolationError: If the candidate violates the model
        """
        return self._store.assert_link(candidate)

    def retire_item(self, ref: ItemRef) -> int:
        """Close every open link of an item that was withdrawn or replaced.

        :param ref: The item
        :return: How many links were closed
        """
        return self._store.close_links_of(ref)

    def guess(
        self, relation: Relation, sources: Sequence[GuessItem], targets: Sequence[GuessItem]
    ) -> GuessReport:
        """Guess links of one relation between two groups of items and store the outcome.

        :param relation: The relation the links would have
        :param sources: Items the links would start at
        :param targets: Items the links would end at
        :return: What was proposed, put up for review, dropped or refused, and the guessed share
        """
        return self._proposer.propose(relation, sources, targets)

    def review_list(self) -> list[Link]:
        """List guessed links that wait for a person, best score first.

        :return: Links in state ``review``
        """
        return self._store.review_list()

    def statistics(self) -> LinkStatistics:
        """Count the open links, including the guessed share.

        :return: The statistics
        """
        return self._reader.statistics()

    def impact(
        self,
        clause: ClauseRef | str,
        *,
        max_steps: int = IMPACT_MAX_STEPS,
        as_at: datetime | None = None,
    ) -> ImpactReport:
        """Say what a change to a rule affects.

        :param clause: The changed clause, as a reference or its text (``2026.1:4.2.1``
            or ``2026.1 clause 4.2.1``)
        :param max_steps: How many links away to look
        :param as_at: Read the links as they were at this instant; now when omitted
        :return: The affected items, or an explicit message when the clause has no links
        :raises InvalidClauseRefError: If the text is not a clause reference
        :raises UnknownClauseError: If the clause is neither loaded nor linked
        """
        ref = clause if isinstance(clause, ClauseRef) else ClauseRef.parse(clause)
        graph = LinkGraph(self._reader.in_use_links(as_at))
        if not graph.edges(clause_item(ref)) and not self._rules.exists(ref):
            raise UnknownClauseError(f"Clause {ref.format()} is not loaded and has no links")
        return impact_of_clause(graph, ref, max_steps)

    def coverage(
        self,
        *,
        as_at: datetime | None = None,
        edition: str | None = None,
        leaf_only: bool = True,
    ) -> CoverageReport:
        """Measure which rules have tests, and which stories tie to no requirement or clause.

        :param as_at: Read the links, and pick the edition in force, at this instant
        :param edition: Measure this edition instead of the one in force
        :param leaf_only: Count only clauses without sub-clauses as rules
        :return: The coverage report
        :raises NoEditionInForceError: If no edition is given and none was in force
        :raises UnknownEditionError: If the named edition is not loaded
        """
        label = edition or self._rules.edition_as_at(
            as_at.date() if as_at is not None else self._clock.today()
        )
        graph = LinkGraph(self._reader.in_use_links(as_at))
        return measure_coverage(
            graph,
            self._rules.rules(label, leaf_only=leaf_only),
            loaded_story_keys(self._connection),
            label,
        )

    def rules_without_tests(
        self,
        *,
        as_at: datetime | None = None,
        edition: str | None = None,
        leaf_only: bool = True,
    ) -> RulesWithoutTests:
        """List the rules that have no path to a test.

        Each rule shows its reference and how many stories are tied to it; the answer states
        how many of the links behind it are stated and how many guessed. It is recomputed
        from the links in use on every call, so linking a test removes the rule.

        :param as_at: Read the links, and pick the edition in force, at this instant
        :param edition: Measure this edition instead of the one in force
        :param leaf_only: Count only clauses without sub-clauses as rules
        :return: The untested rules
        :raises NoEditionInForceError: If no edition is given and none was in force
        :raises UnknownEditionError: If the named edition is not loaded
        """
        return rules_without_tests(self.coverage(as_at=as_at, edition=edition, leaf_only=leaf_only))
