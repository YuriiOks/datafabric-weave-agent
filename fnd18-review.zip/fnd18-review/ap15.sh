cd /home/user/bp-card-matured || exit 1
clear
[ "$(git branch --show-current)" = "feat/fnd-18" ] || { echo NOT ON BRANCH; exit 1; }
GIT_TERMINAL_PROMPT=0 git fetch -q origin
echo "HEAD $(git rev-parse --short HEAD) ORIGIN $(git rev-parse --short origin/feat/fnd-18) BEHIND MAIN $(git rev-list --count HEAD..origin/main)"
[ -z "$(git status --short | grep -v '^??')" ] || { echo TREE DIRTY; exit 1; }
PY=backend/.venv/bin/python
$PY /home/user/bpc-port/fnd18-review/apply_t.py . --check || exit 1
$PY /home/user/bpc-port/fnd18-review/apply_t.py . || exit 1
git status --short | grep -v '^??'
cd backend || exit 1
F="app/recsys/registry/agent_hub_api.py tests/recsys/registry/test_agent_hub_api.py"
.venv/bin/ruff check --fix --output-format=concise $F 2>&1 | tail -2
.venv/bin/ruff format $F 2>&1 | tail -1
.venv/bin/python -m pytest tests/recsys/registry/test_agent_hub_api.py -q -p no:cacheprovider 2>&1 | tail -1
cd ../frontend || exit 1
T=src/features/recsys
npx vitest run $T/components/RecommendationCard.test.tsx $T/component-page/fromRegistry.test.ts $T/component-page/SourceCard.test.tsx 2>&1 | grep -E 'Test Files|Tests |FAIL' | head -4
npx tsc --noEmit -p tsconfig.app.json 2>&1 | tail -3; echo TSC RC ${PIPESTATUS[0]}
npx eslint $T/components/RecommendationCard.tsx $T/component-page/fromRegistry.ts 2>&1 | tail -3; echo ESLINT RC ${PIPESTATUS[0]}
cd .. && $PY -m scripts.ci invariants 2>&1 | grep -E "unexplained|FAIL" | cut -c1-120
git diff --stat | tail -1
bash /home/user/bpc-port/fnd18/restart-backend.sh
(cd frontend && nohup npx vite --config vite.config.local.ts --host 0.0.0.0 > /home/user/bpc-port/poc/vite-fnd18.log 2>&1 &)
sleep 20; ss -ltn | grep -cE ':(8000|5173) '; echo DONE15
