# Build file: work/builds/<task>.md

Created at the start of /km-build, rewritten in place after every state change. Lines at most
100 characters. It is a log for restarts and the owner's summary. Git is the truth.

## Layout
```
# Build <task>
Date: <first run>   Updated: <now>
Status: running | blocked | done | stopped (reason)
Tree: /home/user/km/work/wt/<task>   Branch: <branch>   Base sha: <sha of origin/main>
Advisor calls used: <n> of 3

## Baseline
Per layer: command, exit code, on the untouched tree (step 2b). Skipped files per commit.

## Slices
| Slice | Agent | State | Attempts | Commit | Note |
Attempts: builder passes so far (limit 3); note "same failure" after a repeat.
State: todo, built, tested, committed, blocked, skipped.

## Waves
One line per event: time, slice, what happened (builder returned, test failed, commit).

## Review
Round 1: report path, counts of proven, refuted, unclear. Round 2: same.
Head sha before each round.

## Advisor calls
n, trigger (A to D), question, answer in one line.

## Plan changes
The decision journal, newest first. Entries (kind, context, decision, why, alternatives,
files) as in fix-loop.md section 2; a plain plan change is a deviation entry. Never deleted.

## Stuck
One block per blocked slice (fix-loop.md section 1). Empty if none.

## Open for owner
Proven findings still open, unclear findings, nits, questions, no-go reasons.

## Summary
Filled at the end: branch, commits (sha subject), table slice by level 1 to 6, not done,
next step.
```
States: todo (nothing yet), built (builder replied, not committed), tested (levels 1 and 2
passed, not committed), committed (sha recorded), blocked (3 attempts failed), skipped (needs
a blocked slice).

## Restart rules
1. Read the file, then compare with git in the tree: `git -C <tree> log --oneline
   <base sha>..HEAD`, `git -C <tree> status --short`.
2. A slice marked committed whose sha is not in the log: set it back to todo and note it.
3. A slice marked built or tested, or todo with changes in its owned paths: the tree holds
   partial work. Do not reset it. Send the builder the "partial work" line of the template,
   and run levels 1 and 2 again before committing.
4. Changes in the tree outside every owned path, or staged files: stop and ask the owner.
5. Review rounds recorded as done are not repeated. A round without a report file is redone.
6. Advisor calls used is read from the file; never reset it. If the file and the plan header
   disagree, take the larger number.
7. Status stopped with a reason: check whether the reason is gone (service running, plan
   fixed) and say so before going on. If it is not gone, stop again with the same reason.
