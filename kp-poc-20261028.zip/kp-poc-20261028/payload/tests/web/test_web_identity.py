"""Who is signed in decides what a page shows; a refusal is a state, never an empty list."""

from __future__ import annotations

import re

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import delete, insert

from kp.app import build_application
from kp.config import Mode
from kp.domain import Story, StoryLink
from kp.store import schema
from kp.web.app import create_app
from kp.web.settings import WebSettings
from web.conftest import CURRENCY_QUESTION, LOCAL_USERS, WebWorld
from web.web_support import BARE_PAGES, PAGES

IDENTITY_HEADER = "X-Test-Signed-In-User"


def _real_mode_client(web_world: WebWorld) -> TestClient:
    """The UI in real mode on the same platform: identity from one header only."""
    world = web_world.world
    # Only the mode is switched: the UI is under test here, not the completeness of the settings.
    settings = world.settings.model_copy(update={"mode": Mode.REAL})
    application = build_application(
        settings, clock=world.application.clock, database=world.application.database
    )
    web = WebSettings(identity_header=IDENTITY_HEADER)
    return TestClient(create_app(application, settings=web))


def test_local_mode_reachable_from_other_machines_signs_nobody_in_by_default(
    web_world: WebWorld,
) -> None:
    world = web_world.world
    application = build_application(
        world.settings, clock=world.application.clock, database=world.application.database
    )
    exposed = TestClient(create_app(application, loopback_only=False))

    anonymous = exposed.get("/search", params={"q": CURRENCY_QUESTION})
    chosen = exposed.get("/search", params={"q": CURRENCY_QUESTION, "user": "user-full-access"})

    assert anonymous.status_code == 403
    assert chosen.status_code == 200


def test_local_mode_offers_the_test_users_of_the_identity_mapping(client: TestClient) -> None:
    page = client.get("/").text

    assert "Signed in as" in page
    for user in LOCAL_USERS:
        assert f'<option value="{user}"' in page


def test_local_mode_starts_as_the_user_with_the_widest_access(client: TestClient) -> None:
    page = client.get("/").text

    assert '<option value="user-full-access" selected>' in page


def test_choosing_a_user_changes_who_is_signed_in_and_the_links_keep_the_choice(
    client: TestClient,
) -> None:
    page = client.get("/", params={"user": "user-one-domain"}).text

    assert '<option value="user-one-domain" selected>' in page
    assert "/search?user=user-one-domain" in page


@pytest.mark.parametrize("path", [*PAGES, *BARE_PAGES])
def test_a_user_without_access_gets_the_forbidden_state_on_every_page(
    client: TestClient, path: str
) -> None:
    response = client.get(path, params={"user": "user-no-access"})

    assert response.status_code == 403
    assert "Forbidden" in response.text
    assert 'role="alert"' in response.text
    assert "a refusal, not an empty result" in response.text


def test_a_refused_search_shows_no_results_and_no_zero_count(client: TestClient) -> None:
    response = client.get("/search", params={"q": CURRENCY_QUESTION, "user": "user-no-access"})

    assert response.status_code == 403
    assert '<ol class="results">' not in response.text
    assert "0 results" not in response.text
    assert "No passage matched" not in response.text


def test_a_user_without_payments_access_sees_the_filtered_out_count_and_no_payments_text(
    client: TestClient,
) -> None:
    response = client.get(
        "/search", params={"q": CURRENCY_QUESTION, "user": "user-no-payments-access"}
    )

    hidden = re.search(r"Filtered out by your access: <strong>(\d+)</strong>", response.text)
    assert response.status_code == 200
    assert hidden is not None
    assert int(hidden[1]) > 0
    assert "Domain: payments" not in response.text
    assert "Domain: cards" in response.text


def test_a_user_with_one_domain_sees_only_that_domain_and_the_hidden_count(
    client: TestClient,
) -> None:
    response = client.get("/search", params={"q": CURRENCY_QUESTION, "user": "user-one-domain"})

    domains = set(re.findall(r"Domain: (\w+)", response.text))
    hidden = re.search(r"Filtered out by your access: <strong>(\d+)</strong>", response.text)
    assert domains == {"payments"}
    assert hidden is not None
    assert int(hidden[1]) > 0


def test_a_user_who_may_not_read_a_story_is_refused_whether_or_not_it_exists(
    client: TestClient,
) -> None:
    hidden = client.get("/specs", params={"story": "PAY-101", "user": "user-no-payments-access"})
    unknown = client.get("/specs", params={"story": "NOPE-1", "user": "user-no-payments-access"})

    assert hidden.status_code == unknown.status_code == 403
    assert "The drafted spec" not in hidden.text


def test_a_user_who_may_not_read_a_spec_is_refused_its_audit_trail(client: TestClient) -> None:
    response = client.get(
        "/audit", params={"spec": "spec-pay-101", "user": "user-no-payments-access"}
    )

    assert response.status_code == 403
    assert "kp-draft-spec" not in response.text


def test_an_unknown_test_user_has_no_access(client: TestClient) -> None:
    response = client.get("/search", params={"q": "currency", "user": "somebody-else"})

    assert response.status_code == 403


def test_real_mode_takes_the_user_from_the_header(web_world: WebWorld) -> None:
    client = _real_mode_client(web_world)

    page = client.get("/", headers={IDENTITY_HEADER: "user-full-access"})

    assert page.status_code == 200
    assert "Signed in as <strong>user-full-access</strong>" in page.text
    assert "<select" not in page.text  # nobody can switch user in real mode


def test_real_mode_ignores_a_user_in_the_query_string(web_world: WebWorld) -> None:
    client = _real_mode_client(web_world)

    response = client.get(
        "/search",
        params={"q": CURRENCY_QUESTION, "user": "user-full-access"},
        headers={IDENTITY_HEADER: "user-no-access"},
    )

    assert response.status_code == 403
    assert "user-full-access" not in response.text


def test_real_mode_refuses_a_request_with_no_identity_header(web_world: WebWorld) -> None:
    client = _real_mode_client(web_world)

    response = client.get("/search", params={"q": CURRENCY_QUESTION, "user": "user-full-access"})

    assert response.status_code == 403
    assert "Not signed in" in response.text


def test_real_mode_links_do_not_carry_a_user(web_world: WebWorld) -> None:
    client = _real_mode_client(web_world)

    page = client.get("/", headers={IDENTITY_HEADER: "user-full-access"}).text

    assert "user=" not in page


def test_real_mode_reads_the_header_named_by_the_setting_only(web_world: WebWorld) -> None:
    client = _real_mode_client(web_world)

    response = client.get("/", headers={"X-KP-Caller": "user-full-access"})

    assert response.status_code == 403


def test_a_draft_never_shows_material_of_a_domain_the_viewer_may_not_read(
    web_world: WebWorld, client: TestClient
) -> None:
    """A payments story may link a cards register row; only a viewer of cards sees its text."""
    story = Story(
        story_key="PAY-901",
        version="v1",
        summary="Show the card transfer status next to payments",
        domain="payments",
        links=(StoryLink(link_type="implements", target_key="REQ-010"),),
    )
    values = story.model_dump()
    values["links"] = [link.model_dump() for link in story.links]
    values["fingerprint"] = story.fingerprint()
    database = web_world.world.application.database
    with database.transaction() as connection:
        connection.execute(insert(schema.story).values(**values))
    try:
        payments_only = client.get("/specs", params={"story": "PAY-901", "user": "user-one-domain"})
        everything = client.get("/specs", params={"story": "PAY-901", "user": "user-full-access"})
    finally:
        with database.transaction() as connection:
            connection.execute(delete(schema.story).where(schema.story.c.story_key == "PAY-901"))

    assert payments_only.status_code == 200
    assert "Show card transfer status" not in payments_only.text
    assert "REQ-010" not in payments_only.text
    assert "Show card transfer status" in everything.text


def _figure(page: str, caption: str) -> int:
    found = re.search(
        rf'<span class="figure">(\d+)</span><span class="caption">{caption}</span>', page
    )
    assert found is not None, caption
    return int(found[1])


def test_the_overview_counts_only_what_the_viewer_may_read(client: TestClient) -> None:
    everything = client.get("/", params={"user": "user-full-access"}).text
    payments = client.get("/", params={"user": "user-one-domain"}).text
    cards = client.get("/", params={"user": "user-no-payments-access"}).text

    assert _figure(everything, "Requirements") == 12
    assert _figure(payments, "Requirements") == 10
    assert _figure(cards, "Requirements") == 2
    assert (_figure(payments, "Stories"), _figure(cards, "Stories")) == (6, 1)
    assert _figure(cards, "Clauses") == _figure(cards, "Rulebook editions") == 0
    assert _figure(everything, "Clauses") == _figure(payments, "Clauses") == 93  # all payments


def test_link_figures_are_shown_only_to_someone_who_may_read_every_domain(
    client: TestClient,
) -> None:
    everything = client.get("/", params={"user": "user-full-access"}).text
    payments = client.get("/", params={"user": "user-one-domain"}).text

    assert "Stated by a source" in everything
    assert "Stated by a source" not in payments
    assert "shown only to someone who may read all of them" in payments
