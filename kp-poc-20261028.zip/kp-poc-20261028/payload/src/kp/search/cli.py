"""The ``kp search`` command.

The integrator wires :func:`add_parser` into :mod:`kp.cli`; this module never imports it.
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from typing import TYPE_CHECKING, TextIO

from pydantic import ValidationError
from sqlalchemy.exc import SQLAlchemyError

from kp.clock import SystemClock
from kp.config import load_settings
from kp.errors import KpError
from kp.search.models import SearchHit
from kp.search.service import SearchService
from kp.store import Database

if TYPE_CHECKING:
    from argparse import _SubParsersAction

COMMAND = "search"
_PREVIEW_CHARACTERS = 240


def add_parser(subparsers: _SubParsersAction[argparse.ArgumentParser]) -> argparse.ArgumentParser:
    """Register ``kp search`` and its arguments.

    :param subparsers: The subparsers action of the top-level parser
    :return: The new subparser, with ``handler`` set to :func:`handle`
    """
    parser = subparsers.add_parser(COMMAND, help="Search passages and look up clauses")
    parser.add_argument("question", help="A question, or a clause reference such as 4.2.1")
    parser.add_argument(
        "--as-at",
        type=date.fromisoformat,
        default=None,
        metavar="YYYY-MM-DD",
        help="Read the rules as they were on this date (default: today)",
    )
    parser.add_argument(
        "--domain",
        action="append",
        default=[],
        dest="domains",
        help="Only search this domain; repeat for several",
    )
    parser.add_argument(
        "--limit", type=_positive_int, default=None, help="Maximum number of hits (at least 1)"
    )
    parser.set_defaults(handler=handle)
    return parser


def _positive_int(text: str) -> int:
    try:
        value = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{text!r} is not a whole number") from None
    if value < 1:
        raise argparse.ArgumentTypeError("must be at least 1")
    return value


def handle(args: argparse.Namespace, *, out: TextIO | None = None) -> int:
    """Run a search and print the hits.

    :param args: Parsed arguments from :func:`add_parser`
    :param out: Where to print; standard output when ``None``
    :return: 0 on success, 1 when the question could not be answered (a failure of the
        database, the settings or the search itself, reported in one line on standard error)
    """
    stream = out or sys.stdout
    try:
        database = Database.from_settings(load_settings())
        try:
            response = SearchService(database, SystemClock()).search(
                args.question, as_at=args.as_at, domains=args.domains, limit=args.limit
            )
        finally:
            database.dispose()
    except KpError as error:
        sys.stderr.write(f"kp search: {error}\n")
        return 1
    except ValidationError:
        sys.stderr.write("kp search: a KP_* or KP_SEARCH_* setting has an invalid value\n")
        return 1
    except SQLAlchemyError:
        sys.stderr.write("kp search: the database is unavailable or not initialised\n")
        return 1
    stream.write(f"As at {response.as_at.isoformat()}")
    stream.write(f" (edition in force: {response.edition_in_force or 'none'})\n")
    if not response.hits:
        stream.write("No matching passages.\n")
    for rank, hit in enumerate(response.hits, start=1):
        stream.write(_format_hit(rank, hit))
    return 0


def _format_hit(rank: int, hit: SearchHit) -> str:
    where = f"page {hit.page}" if hit.page is not None else "page n/a"
    if hit.char_start is not None and hit.char_end is not None:
        where += f", characters {hit.char_start}-{hit.char_end}"
    title = f" {hit.title}" if hit.title else ""
    quote = " ".join(hit.text.split())
    if len(quote) > _PREVIEW_CHARACTERS:
        quote = quote[:_PREVIEW_CHARACTERS].rstrip() + "..."
    heading = f"{rank}. {hit.human_reference}{title}"
    return f"{heading} [{hit.passage_type.value}, version {hit.version}, {where}]\n   {quote}\n"
