"""Stated links read from the files of a code repository.

Three things are stated by files alone:

* a schema property that carries an ``x-clause`` entry: the clause resolves to that field;
* a test that imports and calls a function or class of the repository: the code is verified
  by that test. Only a call counts; a name used as an argument or an annotation does not;
* a function or class whose docstring or comment says ``Implements spec <spec id>``: the spec
  is implemented by that code. The spec must be a loaded one; any other id is rejected.

Code and tests that *cite* a clause in a docstring or comment are reported as citations.
The model has no relation from code or a test to a clause (only a spec is implemented by
code), so a citation cannot be stored as a link until a spec connects the two. That is what
the third statement is for: clause, spec, code and test then form one chain.
"""

from __future__ import annotations

import ast
import io
import json
import logging
import os
import re
import tokenize
from collections.abc import Collection, Iterable
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

from kp.domain import DomainModel, ItemRef, Relation
from kp.links.candidate import LinkCandidate
from kp.links.refs import (
    clause_item,
    code_item,
    find_clause_refs,
    schema_field_item,
    spec_item,
    split_clause_refs,
    unit_test_item,
)
from kp.links.stated.model import RejectedLink, StatedLinkSet, keep_conforming

logger = logging.getLogger(__name__)

SCHEMA_SUFFIX = ".schema.json"
_CLAUSE_KEY = "x-clause"
_IGNORED_DIRECTORIES = frozenset({"__pycache__", "node_modules", "venv"})
_TEST_DIRECTORIES = frozenset({"test", "tests"})
# "Implements spec spec-pay-104": the id ends on a letter or digit, so a closing full stop is
# not part of it.
_IMPLEMENTS_SPEC = re.compile(
    r"\bimplements\s+spec\s+([A-Za-z0-9](?:[A-Za-z0-9_.-]*[A-Za-z0-9])?)", re.IGNORECASE
)


class ClauseCitation(DomainModel):
    """A code symbol or test that names a clause in its documentation or comments."""

    item: ItemRef
    clause: ItemRef


class RepositoryScan(StatedLinkSet):
    """A stated-link set plus the clause citations that could not become links."""

    citations: tuple[ClauseCitation, ...] = ()


@dataclass(slots=True)
class _Module:
    path: str
    tree: ast.Module
    comments: dict[int, str]
    symbols: dict[str, ast.AST] = field(default_factory=dict)


def _is_test_path(path: str) -> bool:
    pure = PurePosixPath(path)
    return (
        bool(_TEST_DIRECTORIES & set(pure.parts[:-1]))
        or pure.name.startswith("test_")
        or pure.stem.endswith("_test")
    )


def _comments(source: str) -> dict[int, str]:
    comments: dict[int, str] = {}
    try:
        for token in tokenize.generate_tokens(io.StringIO(source).readline):
            if token.type == tokenize.COMMENT:
                comments[token.start[0]] = token.string
    except (tokenize.TokenError, IndentationError):
        return comments
    return comments


def _documentation(module: _Module, node: ast.AST) -> str:
    docstring = (
        ast.get_docstring(node)
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef)
        else None
    )
    first = getattr(node, "lineno", 0)
    last = getattr(node, "end_lineno", first)
    notes = [text for line, text in module.comments.items() if first <= line <= last]
    return "\n".join([docstring or "", *notes])


def _top_level_symbols(tree: ast.Module) -> dict[str, ast.AST]:
    return {
        node.name: node
        for node in tree.body
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef)
    }


def _dotted(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        head = _dotted(node.value)
        return None if head is None else f"{head}.{node.attr}"
    return None


class _Imports:
    """Names a module binds by importing from other modules."""

    def __init__(self, tree: ast.Module) -> None:
        self.symbols: dict[str, tuple[str, str]] = {}
        self.modules: dict[str, str] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    self.symbols[alias.asname or alias.name] = (node.module, alias.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    self.modules[alias.asname or alias.name] = alias.name

    def called_by(self, function: ast.AST) -> set[tuple[str, str]]:
        """List the (module, symbol) pairs a function body calls."""
        called: set[tuple[str, str]] = set()
        for node in ast.walk(function):
            if not isinstance(node, ast.Call):
                continue
            dotted = _dotted(node.func)
            if dotted is None:
                continue
            head = dotted.split(".", maxsplit=1)[0]
            prefix, _, attribute = dotted.rpartition(".")
            if head in self.symbols:
                called.add(self.symbols[head])
            elif prefix in self.modules:
                called.add((self.modules[prefix], attribute))
        return called


def _module_names(path: str) -> set[str]:
    parts = list(PurePosixPath(path).with_suffix("").parts)
    if parts[-1] == "__init__":
        parts.pop()
    return {".".join(parts[start:]) for start in range(len(parts))}


def _test_functions(tree: ast.Module) -> list[tuple[str, ast.AST]]:
    found: list[tuple[str, ast.AST]] = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef) and node.name.startswith(
            "test"
        ):
            found.append((node.name, node))
        elif isinstance(node, ast.ClassDef) and node.name.startswith("Test"):
            found.extend(
                (f"{node.name}.{member.name}", member)
                for member in node.body
                if isinstance(member, ast.FunctionDef | ast.AsyncFunctionDef)
                and member.name.startswith("test")
            )
    return found


class RepositoryScanner:
    """Reads a repository checkout and states what its files say.

    :param revision: Commit that qualifies every path in the item keys; ``None`` for none
    :param editions: Loaded edition labels; a clause reference to any other edition is
        rejected in a schema and ignored in documentation
    :param specs: Loaded spec identities; code that implements any other spec is rejected.
        ``None`` accepts every id.
    """

    def __init__(
        self,
        revision: str | None = None,
        editions: Collection[str] | None = None,
        specs: Collection[str] | None = None,
    ) -> None:
        self._revision = revision
        self._editions = editions
        self._specs = specs

    def scan(self, root: Path) -> RepositoryScan:
        """Scan a checkout.

        :param root: The repository root; paths in item keys are relative to it
        :return: The stated links, citations, rejected files and the scope enumerated
        """
        candidates: list[tuple[str, LinkCandidate]] = []
        rejected: list[RejectedLink] = []
        citations: dict[tuple[ItemRef, ItemRef], ClauseCitation] = {}
        owned_sources: set[ItemRef] = set()
        owned_targets: set[ItemRef] = set()
        owned_paths: set[str] = set()
        code_modules: dict[str, _Module] = {}
        test_modules: list[_Module] = []

        for path, file in self._files(root):
            if path.endswith(SCHEMA_SUFFIX):
                owned_paths.add(path)
                self._scan_schema(path, file, candidates, rejected, owned_targets)
            elif path.endswith(".py"):
                module = self._parse(path, file, rejected)
                if module is None:
                    continue
                owned_paths.add(path)
                if _is_test_path(path):
                    test_modules.append(module)
                else:
                    code_modules[path] = module

        for module in code_modules.values():
            for symbol, node in module.symbols.items():
                item = code_item(module.path, symbol, self._revision)
                owned_sources.add(item)
                documentation = _documentation(module, node)
                self._cite(item, documentation, citations)
                self._implement(item, module.path, documentation, candidates, rejected)
        names = self._module_index(code_modules)
        for module in test_modules:
            self._scan_tests(module, code_modules, names, candidates, citations)

        links, violations = keep_conforming(candidates)
        return RepositoryScan(
            links=links,
            rejected=tuple(rejected) + violations,
            owned_sources=frozenset(owned_sources),
            owned_targets=frozenset(owned_targets),
            owned_paths=frozenset(owned_paths),
            relations=frozenset(
                {Relation.RESOLVES_TO, Relation.VERIFIED_BY, Relation.IMPLEMENTED_BY}
            ),
            citations=tuple(citations.values()),
        )

    def _files(self, root: Path) -> Iterable[tuple[str, Path]]:
        """List the regular files below ``root``, as the code source reader does.

        Hidden files and folders, symbolic links and tooling caches are never read, so the scan
        sees what the sweep stored and cannot be steered outside the checkout.
        """
        for directory, subdirectories, names in os.walk(root, followlinks=False):
            subdirectories[:] = sorted(
                name
                for name in subdirectories
                if not name.startswith(".") and name not in _IGNORED_DIRECTORIES
            )
            for name in sorted(names):
                file = Path(directory) / name
                if not name.startswith(".") and not file.is_symlink():
                    yield file.relative_to(root).as_posix(), file

    def _parse(self, path: str, file: Path, rejected: list[RejectedLink]) -> _Module | None:
        try:
            source = file.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            logger.warning("Skipped a file that cannot be read", extra={"path": path})
            rejected.append(RejectedLink(origin=path, reason="cannot be read as UTF-8 text"))
            return None
        try:
            tree = ast.parse(source)
        except SyntaxError:
            logger.warning("Skipped a file that is not valid Python", extra={"path": path})
            rejected.append(RejectedLink(origin=path, reason="not valid Python"))
            return None
        return _Module(
            path=path, tree=tree, comments=_comments(source), symbols=_top_level_symbols(tree)
        )

    def _scan_schema(
        self,
        path: str,
        file: Path,
        candidates: list[tuple[str, LinkCandidate]],
        rejected: list[RejectedLink],
        owned_targets: set[ItemRef],
    ) -> None:
        try:
            document = json.loads(file.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, OSError):
            logger.warning("Skipped a file that cannot be read", extra={"path": path})
            rejected.append(RejectedLink(origin=path, reason="cannot be read as UTF-8 text"))
            return
        except json.JSONDecodeError:
            rejected.append(RejectedLink(origin=path, reason="not valid JSON"))
            return
        properties = document.get("properties") if isinstance(document, dict) else None
        if not isinstance(properties, dict):
            return
        for name, definition in sorted(properties.items()):
            target = schema_field_item(path, str(name), self._revision)
            owned_targets.add(target)
            declared = definition.get(_CLAUSE_KEY) if isinstance(definition, dict) else None
            texts = declared if isinstance(declared, list) else [declared]
            origin = f"{path} property {name}"
            for text in texts:
                if not isinstance(text, str):
                    continue
                known, unknown = split_clause_refs(text, self._editions)
                rejected.extend(
                    RejectedLink(origin=origin, reason=f"edition {ref.edition} is not loaded")
                    for ref in unknown
                )
                candidates.extend(
                    (
                        origin,
                        LinkCandidate.stated(
                            clause_item(ref), Relation.RESOLVES_TO, target, evidence=origin
                        ),
                    )
                    for ref in known
                )

    def _module_index(self, code_modules: dict[str, _Module]) -> dict[str, str | None]:
        """Map every dotted suffix of a code path to that path; ``None`` when ambiguous."""
        index: dict[str, str | None] = {}
        for path in sorted(code_modules):
            for name in _module_names(path):
                index[name] = None if name in index else path
        return index

    def _scan_tests(
        self,
        module: _Module,
        code_modules: dict[str, _Module],
        names: dict[str, str | None],
        candidates: list[tuple[str, LinkCandidate]],
        citations: dict[tuple[ItemRef, ItemRef], ClauseCitation],
    ) -> None:
        imports = _Imports(module.tree)
        for name, node in _test_functions(module.tree):
            test = unit_test_item(module.path, name, self._revision)
            self._cite(test, _documentation(module, node), citations)
            for imported_module, symbol in sorted(imports.called_by(node)):
                code_path = names.get(imported_module)
                if code_path is None or symbol not in code_modules[code_path].symbols:
                    continue
                origin = f"{module.path} calls {symbol}"
                candidates.append(
                    (
                        origin,
                        LinkCandidate.stated(
                            code_item(code_path, symbol, self._revision),
                            Relation.VERIFIED_BY,
                            test,
                            evidence=origin,
                        ),
                    )
                )

    def _implement(
        self,
        code: ItemRef,
        path: str,
        documentation: str,
        candidates: list[tuple[str, LinkCandidate]],
        rejected: list[RejectedLink],
    ) -> None:
        for spec_id in dict.fromkeys(_IMPLEMENTS_SPEC.findall(documentation)):
            origin = f"{path} {code.key.rpartition('::')[2]} implements spec {spec_id}"
            if self._specs is not None and spec_id not in self._specs:
                rejected.append(RejectedLink(origin=origin, reason=f"spec {spec_id} is not loaded"))
                continue
            candidates.append(
                (
                    origin,
                    LinkCandidate.stated(
                        spec_item(spec_id), Relation.IMPLEMENTED_BY, code, evidence=origin
                    ),
                )
            )

    def _cite(
        self,
        item: ItemRef,
        documentation: str,
        citations: dict[tuple[ItemRef, ItemRef], ClauseCitation],
    ) -> None:
        for ref in find_clause_refs(documentation, self._editions):
            clause = clause_item(ref)
            citations.setdefault((item, clause), ClauseCitation(item=item, clause=clause))
