import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { MarkdownViewer } from './MarkdownViewer'

const MD = [
  '---',
  'name: Alpha Ticket Helper',
  'allowed-tools: Read, Write',
  '---',
  '',
  '# Alpha Ticket Helper',
  '',
  '## When to use',
  '',
  'Use it for **new** tickets. <script>alert(1)</script>',
  '',
  '## Output',
  '',
  '```json',
  '{ "queue": "billing" }',
  '```',
  '',
  '[bad](javascript:alert(1)) and [good](https://example.test/docs)',
  '',
  '> [!WARNING]',
  '> Needs write scope.',
].join('\n')

function setClipboard(value: unknown) {
  Object.defineProperty(window.navigator, 'clipboard', { value, configurable: true })
}

afterEach(() => {
  cleanup()
  Reflect.deleteProperty(window.navigator, 'clipboard')
})

describe('MarkdownViewer', () => {
  it('renders the frontmatter as rows with chips for list keys', () => {
    render(<MarkdownViewer markdown={MD} path="skills/alpha/SKILL.md" />)
    expect(screen.getByText('allowed-tools')).toBeInTheDocument()
    expect(screen.getByText('Read')).toBeInTheDocument()
    expect(screen.getByText('Write')).toBeInTheDocument()
    expect(screen.getByText('skills/alpha/SKILL.md')).toBeInTheDocument()
  })

  it('renders headings with anchors and an On this page list', () => {
    const { container } = render(<MarkdownViewer markdown={MD} idPrefix="t" />)
    expect(screen.getByRole('heading', { name: 'When to use' })).toHaveAttribute('id', 't-when-to-use')
    const toc = screen.getByRole('navigation', { name: 'On this page' })
    expect(within(toc).getByRole('link', { name: 'Output' })).toHaveAttribute('href', '#t-output')
    expect(container.querySelector('script')).toBeNull()
  })

  it('shows HTML in the file as text, never as markup', () => {
    render(<MarkdownViewer markdown={MD} />)
    expect(screen.getByText(/<script>alert\(1\)<\/script>/)).toBeInTheDocument()
  })

  it('links only safe targets and keeps every link in the same tab', () => {
    render(<MarkdownViewer markdown={MD} />)
    expect(screen.queryByRole('link', { name: 'bad' })).toBeNull()
    expect(screen.getByText('bad')).toBeInTheDocument()
    const good = screen.getByRole('link', { name: 'good' })
    expect(good).toHaveAttribute('href', 'https://example.test/docs')
    expect(good).not.toHaveAttribute('target')
  })

  it('renders GitHub alerts as notes', () => {
    render(<MarkdownViewer markdown={MD} />)
    const note = screen.getByRole('note')
    expect(within(note).getByText('Warning')).toBeInTheDocument()
    expect(within(note).getByText('Needs write scope.')).toBeInTheDocument()
  })

  it('switches between the rendered view and the raw Markdown', () => {
    render(<MarkdownViewer markdown={MD} />)
    const rendered = screen.getByRole('button', { name: 'Rendered' })
    const raw = screen.getByRole('button', { name: 'Markdown' })
    expect(rendered).toHaveAttribute('aria-pressed', 'true')
    fireEvent.click(raw)
    expect(raw).toHaveAttribute('aria-pressed', 'true')
    expect(screen.getByLabelText('Markdown source').textContent).toBe(MD)
    expect(screen.queryByRole('heading', { name: 'When to use' })).toBeNull()
  })

  it('copies a code block', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    setClipboard({ writeText })
    render(<MarkdownViewer markdown={MD} />)
    fireEvent.click(screen.getByRole('button', { name: 'Copy' }))
    expect(await screen.findByRole('button', { name: 'Copied' })).toBeInTheDocument()
    expect(writeText).toHaveBeenCalledWith('{ "queue": "billing" }')
  })

  it('says so when the clipboard is not available', async () => {
    setClipboard(undefined)
    render(<MarkdownViewer markdown={MD} />)
    fireEvent.click(screen.getByRole('button', { name: 'Copy' }))
    expect(await screen.findByRole('button', { name: 'Select to copy' })).toBeInTheDocument()
  })

  it('shows the Open source link only for a safe URL', () => {
    const { rerender } = render(<MarkdownViewer markdown={MD} sourceUrl="https://example.test/SKILL.md" />)
    expect(screen.getByRole('link', { name: /Open source/ })).toHaveAttribute('href', 'https://example.test/SKILL.md')
    rerender(<MarkdownViewer markdown={MD} sourceUrl="javascript:alert(1)" />)
    expect(screen.queryByRole('link', { name: /Open source/ })).toBeNull()
  })
})
