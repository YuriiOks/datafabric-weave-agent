"""US-20: the story moves to "Spec drafted" and links the pull request; nothing else changes."""

from __future__ import annotations

import json

import httpx
import pytest
from pydantic import SecretStr

from kp.config import Settings
from kp.writeback import (
    DryRunJiraUpdater,
    JiraRestClient,
    JiraStoryUpdate,
    JiraTransientError,
    JiraUpdateError,
)

API = "https://jira.example.invalid"
ISSUE = "/rest/api/2/issue/PAY-101"
UPDATE = JiraStoryUpdate(
    story_key="PAY-101", status="Spec drafted", link_field="spec_link", link_value="local-pr:1"
)


class FakeJira:
    """A Jira stand-in with one issue, a status and a workflow."""

    def __init__(self, status: str = "To Do", transitions: list[dict[str, object]] | None = None):
        self.status = status
        self.transitions = (
            [{"id": "31", "name": "Draft", "to": {"name": "Spec drafted"}}]
            if transitions is None
            else transitions
        )
        self.requests: list[httpx.Request] = []
        self.written: list[dict[str, object]] = []
        self.responses: list[httpx.Response] = []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if self.responses:
            return self.responses.pop(0)
        if request.content:
            self.written.append(json.loads(request.content))
        if request.method == "PUT":
            return httpx.Response(204)
        if request.method == "GET" and request.url.path == ISSUE:
            return httpx.Response(200, json={"fields": {"status": {"name": self.status}}})
        if request.method == "GET" and request.url.path == f"{ISSUE}/transitions":
            return httpx.Response(200, json={"transitions": self.transitions})
        if request.method == "POST" and request.url.path == f"{ISSUE}/transitions":
            self.status = "Spec drafted"
            return httpx.Response(204)
        return httpx.Response(500)


def client_for(jira: FakeJira) -> JiraRestClient:
    return JiraRestClient(httpx.Client(base_url=API, transport=httpx.MockTransport(jira)))


def test_us20_pr_created_story_moves_to_spec_drafted_and_links_the_pr() -> None:
    jira = FakeJira()

    applied = client_for(jira).apply(UPDATE)

    assert (applied.status_changed, applied.link_set, applied.dry_run) == (True, True, False)
    assert jira.status == "Spec drafted"
    assert jira.written == [
        {"fields": {"spec_link": "local-pr:1"}},
        {"transition": {"id": "31"}},
    ]


def test_us20_no_other_jira_field_changes() -> None:
    jira = FakeJira()

    client_for(jira).apply(UPDATE)

    writes = [r for r in jira.requests if r.method in {"PUT", "POST"}]
    assert [(r.method, r.url.path) for r in writes] == [
        ("PUT", ISSUE),
        ("POST", f"{ISSUE}/transitions"),
    ]
    assert set(jira.written[0]["fields"]) == {"spec_link"}  # type: ignore[call-overload]  # JSON
    assert set(jira.written[1]) == {"transition"}
    assert {r.url.path for r in jira.requests} == {ISSUE, f"{ISSUE}/transitions"}


def test_us20_a_story_already_in_the_status_is_not_moved_again() -> None:
    jira = FakeJira(status="Spec drafted")

    applied = client_for(jira).apply(UPDATE)

    assert (applied.status_changed, applied.link_set) == (False, True)
    assert jira.written == [{"fields": {"spec_link": "local-pr:1"}}]


def test_us20_repeating_the_update_converges() -> None:
    jira = FakeJira()
    client = client_for(jira)

    client.apply(UPDATE)
    again = client.apply(UPDATE)

    assert again.status_changed is False
    assert [w for w in jira.written if "transition" in w] == [{"transition": {"id": "31"}}]


@pytest.mark.parametrize("status", [429, 500, 502, 503])
def test_us20_a_server_side_failure_is_transient(status: int) -> None:
    jira = FakeJira()
    jira.responses = [httpx.Response(status)]

    with pytest.raises(JiraTransientError):
        client_for(jira).apply(UPDATE)


def test_us20_an_unreachable_jira_is_transient() -> None:
    def refuse(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down", request=request)

    client = JiraRestClient(httpx.Client(base_url=API, transport=httpx.MockTransport(refuse)))

    with pytest.raises(JiraTransientError):
        client.apply(UPDATE)


@pytest.mark.parametrize("status", [400, 401, 403, 404])
def test_us20_a_client_error_is_final(status: int) -> None:
    jira = FakeJira()
    jira.responses = [httpx.Response(status)]

    with pytest.raises(JiraUpdateError) as caught:
        client_for(jira).apply(UPDATE)

    assert not isinstance(caught.value, JiraTransientError)


def test_us20_no_transition_to_the_status_is_a_final_error() -> None:
    jira = FakeJira(transitions=[{"id": "11", "name": "Close", "to": {"name": "Done"}}])

    with pytest.raises(JiraUpdateError):
        client_for(jira).apply(UPDATE)

    assert not any("transition" in written for written in jira.written)


def test_us20_a_transition_is_found_by_target_status_name_ignoring_case() -> None:
    jira = FakeJira(transitions=[{"id": "7", "name": "x", "to": {"name": "SPEC DRAFTED"}}])

    client_for(jira).apply(UPDATE)

    assert jira.written[-1] == {"transition": {"id": "7"}}


def test_us20_dry_run_records_the_update_and_changes_nothing() -> None:
    dry_run = DryRunJiraUpdater()

    applied = dry_run.apply(UPDATE)

    assert applied.dry_run is True
    assert dry_run.updates == [UPDATE]


def test_us20_from_settings_sends_the_jira_source_credential() -> None:
    jira = FakeJira()
    settings = Settings(_env_file=None, source_token_jira=SecretStr("synthetic-token"))
    client = JiraRestClient.from_settings(
        settings, base_url=API, transport=httpx.MockTransport(jira)
    )

    client.apply(UPDATE)

    assert jira.requests[0].headers["Authorization"] == "Bearer synthetic-token"
