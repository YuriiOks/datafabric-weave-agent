---
pack_id: "bpc-sep26-v1"
local_id: "AGT-05"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1345"
summary: "Conditional: evaluate Agent relevance against the approved shared baseline"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "recommendations"
create_by_default: false
planned_start: "2026-09-25"
planned_due: "2026-09-28"
dates_profile: "recommendations"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["AGT-02","AGT-03","CORE-07","CORE-08"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-agt-05"
architecture_sections: ["component evaluation","future component engine","validation gates"]
---

# Conditional: evaluate Agent relevance against the approved shared baseline

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1345**. Local reference **AGT-05** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **not scheduled; do not create by default**.
- Recommendation extension: **2026-09-25 → 2026-09-28 (D13–D14)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

If recommendation mode is approved, create the Agent-specific evidence needed to compare a proposed recommender with the shared authorised lexical baseline. The result is an adjudicated, leakage-controlled case pack and an interpretable report slice; it is not a claim that declared Agent usage proves relevance.

## Start condition

Start only after the owner approves recommendation scope, domain reviewer, labels, per-type acceptance targets, data/trace retention, cost/privacy limits and the shared baseline adapter. If that decision is absent, retain this item as blocked and attach the decision gap rather than fabricating labels or measurements.

## Scope

- Curate Agent cases from approved sources with domain-review provenance: positive candidates, hard negatives, legitimate empty needs, access-restricted candidates, duplicates/aliases, ambiguous references, noisy descriptions and required-prerequisite cases where applicable.
- Group related source cards/Agents before development, validation and frozen held-out partitions to prevent leakage.
- Use the shared runner to report Agent-type coverage, adjudicated precision/recall, empty-control false positives, forbidden hits, unjudged outcomes, access failures, latency and cost.
- Keep declared Agent-to-Skill/MCP links as candidate/evidence context only; labels come from the agreed adjudication policy.

## Boundaries

Do not alter production ranking, tune on the final held-out partition, count runner failures as correct empty answers, or claim an acceptance threshold before the owner approves it. No LLM, embedding or graph boost is introduced by this case-pack work.

## Technical steps

1. Confirm the shared baseline's typed outcomes and the case/trace retention boundary.
2. Build the Agent case manifest with source provenance, label status and group key.
3. Obtain domain adjudication and resolve disputed/unknown labels before acceptance scoring.
4. Freeze the final partition, run the common baseline/comparator harness and report denominators and unjudged cases.
5. Hand results to CORE-09 for cross-type rollout evidence; an unmet gate remains a decision input, not a hidden regression.

## Acceptance criteria

- Each Agent case has an authorised source reference, group key, label/adjudicator status and explicit inclusion in development, validation or frozen final test.
- Related Agents/cards cannot appear across training/tuning and final-test partitions.
- The report separates completed, failed, disabled, cancelled, missing-source, skipped and unjudged cases; no excluded case improves a quality denominator.
- Any inaccessible, revoked, wrong-environment or fabricated Agent ID is reported as a blocking forbidden hit.
- A quality claim is emitted only when the agreed per-type acceptance targets and all planned-case coverage requirements are met.

## Evidence to attach

Frozen case-manifest digest, adjudication record, baseline/comparator report with denominators, partition-leakage check and owner decision on acceptance.

## Dependencies / blockers

Conditional on recommendation-mode approval and requires AGT-02, AGT-03, CORE-07, CORE-08 plus an available domain reviewer.

## Out of scope

Production promotion, threshold selection without owner approval, use of source declarations as ground truth, and recommender implementation outside the shared baseline scope.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [AGT-02](AGT-02.md) must finish its stated contract boundary before this task starts.
- [AGT-03](AGT-03.md) must finish its stated contract boundary before this task starts.
- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.
- [CORE-08](CORE-08.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `component evaluation`, `future component engine`, `validation gates`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
