"""Evaluation cases: adjudication rules, scenario templates and gated prerequisite evidence."""

from __future__ import annotations

import unittest

from app.recsys.eval.casepack.cases import (
    SCENARIO_RULES,
    Adjudication,
    AdjudicationState,
    EvidenceKind,
    EvidenceRequirement,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.schema import DRAFT_LABELLER

from . import casepack_support as support

ONE = support.component_id(1)
TWO = support.component_id(2)
THREE = support.component_id(3)


class AdjudicationTests(unittest.TestCase):
    def test_a_new_case_is_unjudged(self) -> None:
        lineage = support.corpus().lineage
        case = support.case(1, lineage=lineage, scenario=Scenario.ambiguous)
        self.assertIs(case.adjudication.state, AdjudicationState.unjudged)
        self.assertEqual(case.relevant_ids(), frozenset())

    def test_unjudged_lists_candidates_without_labels(self) -> None:
        pending = Adjudication(labels={ONE: RelevanceLabel.unjudged})
        self.assertEqual(pending.ids_labelled(RelevanceLabel.unjudged), frozenset({ONE}))
        with self.assertRaises(ValueError):
            Adjudication(labels={ONE: RelevanceLabel.relevant})
        with self.assertRaises(ValueError):
            Adjudication(reviewer="reviewer-a")

    def test_judged_names_reviewer_and_decision(self) -> None:
        labels = {ONE: RelevanceLabel.relevant}
        with self.assertRaises(ValueError):
            Adjudication(state=AdjudicationState.judged, labels=labels)
        with self.assertRaises(ValueError):
            support.judged(labels, reviewer=DRAFT_LABELLER)
        with self.assertRaises(ValueError):
            Adjudication(state=AdjudicationState.judged, reviewer="reviewer-a", labels=labels)
        self.assertTrue(support.judged(labels).judged)

    def test_judged_labels_every_candidate(self) -> None:
        with self.assertRaises(ValueError):
            support.judged({ONE: RelevanceLabel.relevant, TWO: RelevanceLabel.unjudged})

    def test_component_ids_are_canonical_uuids(self) -> None:
        with self.assertRaises(ValueError):
            Adjudication(labels={"skill:synthetic": RelevanceLabel.unjudged})
        with self.assertRaises(ValueError):
            Adjudication(labels={ONE.upper(): RelevanceLabel.unjudged})


class ScenarioRuleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.lineage = support.corpus().lineage

    def test_every_scenario_has_a_rule(self) -> None:
        self.assertEqual(set(SCENARIO_RULES), set(Scenario))

    def test_outcome_fits_the_scenario(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                1,
                lineage=self.lineage,
                scenario=Scenario.source_unavailable,
                expected=ExpectedOutcome.ranked,
            )
        case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.source_unavailable,
            expected=ExpectedOutcome.source_unavailable,
        )
        self.assertIs(case.expected_outcome, ExpectedOutcome.source_unavailable)

    def test_access_case_names_the_hidden_component(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                1,
                lineage=self.lineage,
                scenario=Scenario.access_restricted,
                expected=ExpectedOutcome.access_filtered,
            )
        case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.access_restricted,
            expected=ExpectedOutcome.access_filtered,
            forbidden=[TWO],
        )
        self.assertEqual(case.forbidden, (TWO,))

    def test_valid_empty_has_no_relevant_component(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                1,
                lineage=self.lineage,
                scenario=Scenario.valid_empty,
                expected=ExpectedOutcome.valid_empty,
                adjudication=support.judged({ONE: RelevanceLabel.relevant}),
            )
        case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.valid_empty,
            expected=ExpectedOutcome.valid_empty,
            adjudication=support.judged({ONE: RelevanceLabel.not_relevant}),
        )
        self.assertEqual(case.relevant_ids(), frozenset())

    def test_ranked_expectation_needs_a_relevant_component(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                1,
                lineage=self.lineage,
                scenario=Scenario.hard_negative,
                forbidden=[TWO],
                adjudication=support.judged({ONE: RelevanceLabel.not_relevant}),
            )

    def test_forbidden_component_cannot_be_relevant(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                1,
                lineage=self.lineage,
                forbidden=[ONE],
                adjudication=support.judged({ONE: RelevanceLabel.relevant}),
            )

    def test_scenario_evidence_is_required(self) -> None:
        with self.assertRaises(ValueError):
            support.case(1, lineage=self.lineage, scenario=Scenario.unresolved_dependency)
        case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.unresolved_dependency,
            required_evidence=[
                EvidenceRequirement(kind=EvidenceKind.unresolved_reference, subject_id=ONE)
            ],
        )
        self.assertEqual(case.referenced_ids(), frozenset({ONE}))

    def test_free_text_need_is_marked_synthetic(self) -> None:
        with self.assertRaises(ValueError):
            support.case(1, lineage=self.lineage, scenario=Scenario.ambiguous, notes="")


class PrerequisiteEvidenceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.lineage = support.corpus().lineage
        self.prerequisite = EvidenceRequirement(
            kind=EvidenceKind.declared_prerequisite, subject_id=ONE, related_id=TWO
        )

    def test_declared_relation_never_supplies_the_label(self) -> None:
        case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.prerequisite,
            required_evidence=[self.prerequisite],
            adjudication=Adjudication(labels={ONE: RelevanceLabel.unjudged}),
        )
        self.assertEqual(case.relevant_ids(), frozenset())
        self.assertEqual(case.gated_evidence(), (self.prerequisite,))

    def test_evidence_applies_after_the_subject_is_judged_relevant(self) -> None:
        case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.prerequisite,
            required_evidence=[self.prerequisite],
            adjudication=support.judged({ONE: RelevanceLabel.relevant}),
        )
        self.assertEqual(case.gated_evidence(), ())

    def test_evidence_about_a_non_relevant_subject_is_refused(self) -> None:
        with self.assertRaises(ValueError):
            support.case(
                1,
                lineage=self.lineage,
                scenario=Scenario.prerequisite,
                required_evidence=[self.prerequisite],
                adjudication=support.judged(
                    {ONE: RelevanceLabel.not_relevant, THREE: RelevanceLabel.relevant}
                ),
            )

    def test_relation_evidence_names_two_components(self) -> None:
        with self.assertRaises(ValueError):
            EvidenceRequirement(kind=EvidenceKind.declared_prerequisite, subject_id=ONE)
        with self.assertRaises(ValueError):
            EvidenceRequirement(
                kind=EvidenceKind.duplicate_identity, subject_id=ONE, related_id=ONE
            )
