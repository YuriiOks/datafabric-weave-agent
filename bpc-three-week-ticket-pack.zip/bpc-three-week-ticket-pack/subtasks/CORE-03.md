---
pack_id: "bpc-sep26-v1"
local_id: "CORE-03"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Integrate the versioned catalogue and deterministic identity resolver"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-10"
planned_due: "2026-09-11"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-03"
architecture_sections: ["identity","ingestion","model"]
---

# Integrate the versioned catalogue and deterministic identity resolver

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-03** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-10 → 2026-09-11 (D2–D3)**.
- Recommendation extension: **2026-09-10 → 2026-09-11 (D2–D3)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Publish an auditable catalogue that accounts for every accepted, quarantined or unresolved source record before any graph generation is exposed.

## Scope and contract

Use existing Postgres authority. Reuse verified PoC tables or implement minimum reviewed/versioned schema additions. Identity remains stable under row reordering and reviewed renames. Record field-level provenance and source precedence; missing descriptions do not remove otherwise graph-valid components.

## Implementation sequence

1. Map source adapter outputs into the canonical record and snapshot schema, preserving immutable source locators and explicit flags.
2. Implement scoped exact-key and approved alias resolution; reject ambiguous identity instead of picking the first or using fuzzy similarity.
3. Persist row/reference accounting and deterministic manifests for a complete source set; validate cross-source precedence and complete-snapshot removal rules.
4. Expose a bounded resolver/reader contract for type-specific relation mappers and shared UI without bypassing current policy.
5. Use parameterized access through the verified repository pattern; retain rollback-safe schema compatibility.

## Acceptance criteria

- [ ] Reordered inputs produce the same durable IDs and resolved facts.
- [ ] Every input row and relation has exactly one recorded outcome, with no silent loss.
- [ ] Malformed/incomplete/failed sources cannot infer deletion by absence or silently mix old and new required inputs.
- [ ] Canonical records retain source/version evidence and independent eligibility states.

## Verification

- Known oracle fixtures include duplicate identifiers, renamed keys, incomplete export, malformed metadata and overlapping sources.
- Compare exact expected ID/node/edge sets rather than accepting historical total counts.

## Evidence to attach

- Ingest reconciliation report, expected-vs-actual oracle diff, schema change/reversal review and contract CI.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Current ingestion source adapters are delivered by SKL/MCP/AGT tasks. This task may use frozen contract fixtures while those adapters are implemented; integrated source parity remains a release gate.

## Monotonic source collections

The manifest includes a monotonic collection revision for each authority/partition/collection, separate from content hash, capture time and individual source record version. Validate the source-authoritative ordering rule; never sort hashes or substitute local ingestion order for source chronology. Preserve original age and revision when carrying an unchanged source. Unknown or ambiguous source ordering blocks automatic promotion until the authority supplies a verifiable ordering decision. Attach vector fixtures for an old complete source arriving after a newer active publication.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `identity`, `ingestion`, `model`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
