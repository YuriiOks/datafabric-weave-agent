---
name: km-page
description: "Use to turn finished findings into a readable report or one-pager as a single self-contained page plus a markdown twin. Argument: a short name, then the kb or design files to draw from."
argument-hint: <name> <source kb files or design files>
disable-model-invocation: true
effort: medium
---

# km-page

Goal: designs/pages/<name>.html (what the owner or a stakeholder reads) and
designs/pages/<name>.md (the same facts, same order), made from sources already in the kb or in
designs/. You fill a fixed template; you do not restyle it. Nothing is sent, posted or shared:
the owner decides who gets the page.

Argument: $0 is the name (lower case, ASCII, hyphens, no folder, no extension); the rest of
the line names the sources. No name: print "usage: /km-page <name> <sources>" and stop.
Run id: km-page-$0-<date>. Read ${CLAUDE_SKILL_DIR}/references/blocks.md once.

## 1 Decide what the page says
- One reader, one purpose. Name the reader as a role and write down, in one line, what they
  should know or decide after reading. If the owner gave neither, ask one question and stop.
- Use only facts that are in the named sources, with their labels (Observed, Reported,
  Proposed, Unverified, Historical). Do not read raw code: ask km-scout. Missing facts are
  listed as open questions, never filled by guessing.
- Writing for stakeholder readers follows /km-write: product language, numbers instead of
  adjectives, no test counts, no prototype talk, at most two questions to the reader.

## 2 Draft the twin first
Write designs/pages/$0.md: a `#` title, a lede, an "In short" part of at most three sentences,
then one `##` heading per section, last one "Sources and evidence". Each section heading
states a finding ("Two decisions block the next step"), not a topic word. Lines at most 100
characters. This is the content; the page only dresses it.

## 3 Build the page
1. `bash /home/user/km/.claude/skills/km-page/scripts/page.sh new $0` copies the template.
2. Replace every `[[...]]` placeholder with the twin's content, one `<section id="sN">` per
   `##` heading, blocks from the reference only. No inline styles, no new classes, no colour,
   no logo, no company or product name, no address of any kind.
3. Number tiles: only when two to four real numbers exist, each with its source. Otherwise
   delete the block. One accent per page is already in the template; add no more.
4. A diagram: build it first with /km-diagram, then keep the frame block from the template,
   set its path, and write a caption that says what to notice. A link alone also works.
5. `bash /home/user/km/.claude/skills/km-page/scripts/page.sh check $0` must print PASS:
   no placeholder left, ASCII only, no outside address, only palette colours, sections match
   the twin. Fix and run again.

## 4 Hand over
The owner opens the page in a browser, wide and narrow. Tell him what to look at: the summary
reads alone, every number has a source, the contents list matches the sections.
Record kb/log.d/<run>.txt: date, name, sources, open questions left in the page.
Print at most 6 lines: both paths, section count, tiles used or not, the one thing to check.
