"""Seam: a checkout of the code repository rebuilt from the items the sweep already stored.

The steps after a sweep read the code repository's files as a tree (which function a test calls,
which spec a function implements, which clause a schema field names). Locally that tree is the
checkout folder. In the real route there is no folder: the files arrive through the gateway, one
item version at a time, and their exact bytes sit in the raw store. This module lays the current
version of every admitted code-source item out in a scratch folder, so the same scan runs on
either.
"""

from __future__ import annotations

import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

from sqlalchemy import Connection, select

from kp.domain import ApprovalState, SourceKind
from kp.store import schema
from kp.sweep import RawStore


@contextmanager
def swept_code_checkout(connection: Connection, raw_store: RawStore) -> Iterator[Path | None]:
    """Lay out the admitted code files in a scratch folder for the length of the block.

    A file whose path is absolute or climbs out of the folder is left out.

    :param connection: An open connection
    :param raw_store: Where the raw bytes of the items are kept
    :return: The scratch folder, or ``None`` when no code file has been swept
    """
    table = schema.source_item
    rows = connection.execute(
        select(table.c.item_id, table.c.raw_location)
        .where(
            table.c.source == SourceKind.GITHUB.value,
            table.c.approval_state == ApprovalState.ADMITTED.value,
        )
        .order_by(table.c.item_id)
    ).all()
    with tempfile.TemporaryDirectory(prefix="kp-code-") as scratch:
        root = Path(scratch)
        written = 0
        for item_id, location in rows:
            relative = PurePosixPath(item_id)
            if relative.is_absolute() or ".." in relative.parts:
                continue
            target = root.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw_store.get(location))
            written += 1
        yield root if written else None
