"""Name the skills repository on the component page and link each repository skill to its SKILL.md.

The catalogue records each repository skill's folder but never the repository's
address. The address is deployment configuration (RECSYS_SKILLS_REPO_URL and
RECSYS_SKILLS_REPO_REF), and detail responses build the link from it.

Validates every anchor first and writes nothing unless all of them hold.
Run from the worktree root.
"""

import pathlib
import re
import sys

ROOT = pathlib.Path.cwd()
B = "backend/app/recsys/"
T = "backend/tests/recsys/"
F = "frontend/src/features/recsys/"
CP = F + "component-page/"
DOT = chr(92) + "u00b7"

texts, created, errors, done = {}, {}, [], []


def get(path):
    if path not in texts:
        texts[path] = (ROOT / path).read_text(encoding="utf-8")
    return texts[path]


def bounds(text, start, end, label):
    if start is None:
        return 0, len(text)
    n = text.count(start)
    if n != 1:
        errors.append(f"{label}: scope start x{n}")
        return None, None
    lo = text.index(start)
    hi = text.find(end, lo + len(start)) if end else -1
    return lo, (len(text) if hi < 0 else hi)


def edit(path, old, new, label, start=None, end=None):
    text = get(path)
    lo, hi = bounds(text, start, end, label)
    if lo is None:
        return
    seg = text[lo:hi]
    n = seg.count(old)
    if n != 1:
        errors.append(f"{label}: x{n}")
        return
    texts[path] = text[:lo] + seg.replace(old, new) + text[hi:]
    done.append(label)


def after_line(path, anchor, block, label, start=None, end=None):
    text = get(path)
    lo, hi = bounds(text, start, end, label)
    if lo is None:
        return
    seg = text[lo:hi]
    n = seg.count(anchor)
    if n != 1:
        errors.append(f"{label}: x{n}")
        return
    k = lo + seg.index(anchor)
    line_start = text.rfind("\n", 0, k) + 1
    line_end = text.index("\n", k) + 1
    line = text[line_start:line_end]
    indent = line[: len(line) - len(line.lstrip())]
    lines = block.strip("\n").split("\n")
    add = "".join((indent + ln if ln else "") + "\n" for ln in lines)
    texts[path] = text[:line_end] + add + text[line_end:]
    done.append(label)


def resub(path, pattern, repl, label, start=None, end=None):
    text = get(path)
    lo, hi = bounds(text, start, end, label)
    if lo is None:
        return
    new, n = re.subn(pattern, repl, text[lo:hi])
    if n != 1:
        errors.append(f"{label}: x{n}")
        return
    texts[path] = text[:lo] + new + text[hi:]
    done.append(label)


def append(path, block, label):
    texts[path] = get(path).rstrip("\n") + "\n" + block.rstrip("\n") + "\n"
    done.append(label)


def create(path, content, label):
    if (ROOT / path).exists():
        errors.append(f"{label}: already exists")
        return
    if not (ROOT / path).parent.is_dir():
        errors.append(f"{label}: no directory for it")
        return
    created[path] = content.lstrip("\n")
    done.append(label)


# --- backend: settings -------------------------------------------------------
SETTINGS_BLOCK = '''
#: Web address of the skills repository the ingest reads, such as
#: ``https://git.example/acme/skills``. The catalogue records only each skill's
#: folder, so detail responses build the link to its SKILL.md from this.
#: Empty leaves repository skills without a link.
recsys_skills_repo_url: str = Field(default="", alias="RECSYS_SKILLS_REPO_URL")
#: The branch, tag or commit those links point at.
recsys_skills_repo_ref: str = Field(
    default="main", alias="RECSYS_SKILLS_REPO_REF"
)
'''


def settings_fields(m):
    indent = m[2]
    lines = SETTINGS_BLOCK.strip("\n").split("\n")
    return m[1] + "".join(indent + ln + "\n" for ln in lines)


resub(
    B + "config.py",
    r'(\n([ \t]*)recsys_embed_cache_dir: str = Field\(\n'
    r'[ \t]*default="data/recsys-cache", alias="RECSYS_EMBED_CACHE_DIR"\n[ \t]*\)\n)',
    settings_fields,
    "settings fields",
)

# --- backend: the link -------------------------------------------------------
create(
    B + "api/source_links.py",
    r'''
"""Links from a component to its definition in the source repository.

The catalogue records which skills folder a repository skill came from, never
the repository's address, so the ingest report stays free of paths. The address
is deployment configuration, and the link is added when a detail is served.
"""

from __future__ import annotations

from urllib.parse import quote, urlsplit

from app.recsys.contracts.catalogue import ComponentDetail, ComponentType


def _repository(repo_url: str) -> tuple[str, str] | None:
    """Split a repository's web address into a clean base and its name.

    User info in the address is dropped, so a credential can never reach a link.

    :param repo_url: The repository's web address, such as
        ``https://git.example/acme/skills``.
    :return: The base address and the ``owner/name`` path, or None when the
        address is not an http(s) address with a path.
    """
    parts = urlsplit(repo_url.strip())
    try:
        port = parts.port
    except ValueError:
        return None
    if parts.scheme not in ("http", "https") or not parts.hostname:
        return None
    name = parts.path.strip("/").removesuffix(".git").strip("/")
    if not name:
        return None
    host = parts.hostname + (f":{port}" if port else "")
    return f"{parts.scheme}://{host}/{name}", name


def with_source_link(
    detail: ComponentDetail, *, repo_url: str, ref: str
) -> ComponentDetail:
    """Name the repository a skill comes from and link its SKILL.md there.

    :param detail: The component detail as the registry returns it.
    :param repo_url: The skills repository's web address; empty when not set.
    :param ref: The branch, tag or commit the link points at.
    :return: The detail with ``source_repository`` and ``source_url`` set, or
        the same detail when it is not a skill with a folder, or no repository
        is configured.
    """
    folder = detail.external_ids.get("folder")
    repository = _repository(repo_url)
    if (
        detail.component_type != ComponentType.skill
        or not isinstance(folder, str)
        or not folder.strip("/")
        or repository is None
        or not ref.strip()
    ):
        return detail
    base, name = repository
    path = quote(f"skills/{folder.strip('/')}/SKILL.md")
    url = f"{base}/blob/{quote(ref.strip())}/{path}"
    return detail.model_copy(update={"source_repository": name, "source_url": url})
''',
    "link module",
)
R = B + "api/router.py"
edit(
    R,
    "from app.recsys.contracts import Capability, Domain\n",
    "from app.recsys.api.source_links import with_source_link\n"
    "from app.recsys.config import recsys_settings\n"
    "from app.recsys.contracts import Capability, Domain\n",
    "router imports",
)
resub(
    R,
    r'([ \t]*)raise HTTPException\(status_code=404, detail="Component not found"\)\n([ \t]*)return detail\n',
    lambda m: (
        f'{m[1]}raise HTTPException(status_code=404, detail="Component not found")\n'
        f"{m[2]}return with_source_link(\n"
        f"{m[2]}    detail,\n"
        f"{m[2]}    repo_url=recsys_settings.recsys_skills_repo_url,\n"
        f"{m[2]}    ref=recsys_settings.recsys_skills_repo_ref,\n"
        f"{m[2]})\n"
    ),
    "router detail link",
    "async def get_registry_component(",
    "@router.get(",
)

# --- backend: contract -------------------------------------------------------
after_line(
    B + "contracts/catalogue.py",
    'definition: str = ""',
    r'''
#: Where the definition can be read: the repository's ``owner/name`` and a web
#: link to the file. Set for repository skills when the deployment configures
#: the repository's address; None otherwise. Detail responses only.
source_repository: str | None = None
source_url: str | None = None
''',
    "contract fields",
    "class ComponentDetail(ComponentSummary):",
    "@model_validator",
)
edit(B + "contracts/scope.py", 'CONTRACT_SCHEMA_VERSION = "1.4.0"', 'CONTRACT_SCHEMA_VERSION = "1.5.0"', "contract version")
FZ = B + "contracts/freeze.py"
edit(FZ, "def _amended_v1_4(note: str) -> FreezeRecord:", "def _amended_v1_5(note: str) -> FreezeRecord:", "amended helper name")
edit(FZ, "amended compatibly in contract version 1.4.0.", "amended compatibly in contract version 1.5.0.", "amended helper doc")
edit(
    FZ,
    'return FreezeRecord(status=FreezeStatus.amended, since_version="1.4.0", note=note)',
    'return FreezeRecord(status=FreezeStatus.amended, since_version="1.5.0", note=note)',
    "amended helper version",
)
edit(FZ, '"ComponentDetail": _amended_v1_4(', '"ComponentDetail": _amended_v1_5(', "detail amended 1.5")
resub(
    FZ,
    r'([ \t]*)"additive relationship disclosures \(1\.3\.0\) and definition text \(1\.4\.0\) "\n'
    r'[ \t]*"have safe defaults"',
    lambda m: (
        f'{m[1]}"additive relationship disclosures (1.3.0), definition text (1.4.0) "\n'
        f'{m[1]}"and source links (1.5.0) have safe defaults"'
    ),
    "detail note",
)

# --- backend: tests ------------------------------------------------------------
TF = T + "contracts/test_freeze.py"
edit(TF, 'self.assertEqual(CONTRACT_SCHEMA_VERSION, "1.4.0")', 'self.assertEqual(CONTRACT_SCHEMA_VERSION, "1.5.0")', "freeze version")
edit(
    TF,
    "def test_the_definition_amendment_is_recorded_at_1_4(self):",
    "def test_the_source_link_amendment_is_recorded_at_1_5(self):",
    "freeze test name",
)
edit(TF, 'self.assertEqual(record.since_version, "1.4.0")', 'self.assertEqual(record.since_version, "1.5.0")', "freeze test version")
create(
    T + "api/test_source_links.py",
    r'''
"""A repository skill's detail names its repository and links its SKILL.md.

Every address here is invented for the test suite.
"""

from __future__ import annotations

import unittest

from app.recsys.api.source_links import with_source_link
from app.recsys.contracts.catalogue import ComponentDetail, ComponentType
from app.recsys.db.repository import component_detail_from_row
from tests.recsys.api.fakes import component_row

_REPO = "https://git.example/acme/skills"


def _skill(**updates: object) -> ComponentDetail:
    """Build a repository skill's detail around the fields a test cares about.

    :param updates: Detail fields to replace.
    :return: The detail.
    """
    detail = component_detail_from_row(
        component_row(
            component_id="skill:alpha-helper",
            component_type=ComponentType.skill,
            name="Alpha helper",
            description="Use when alpha tickets arrive.",
        )
    )
    fields: dict[str, object] = {
        "source": "skills_repo",
        "external_ids": {"folder": "alpha-helper"},
    }
    return detail.model_copy(update={**fields, **updates})


class SourceLinkTests(unittest.TestCase):
    """The link is built from the configured repository and the skill's folder."""

    def test_a_repository_skill_links_to_its_skill_md(self):
        linked = with_source_link(_skill(), repo_url=_REPO, ref="main")
        self.assertEqual(linked.source_repository, "acme/skills")
        self.assertEqual(
            linked.source_url, _REPO + "/blob/main/skills/alpha-helper/SKILL.md"
        )

    def test_a_trailing_slash_and_git_suffix_are_dropped(self):
        linked = with_source_link(_skill(), repo_url=_REPO + ".git/", ref="main")
        self.assertEqual(linked.source_repository, "acme/skills")
        self.assertTrue(linked.source_url.startswith(_REPO + "/blob/main/"))

    def test_a_nested_folder_and_a_space_stay_a_valid_path(self):
        linked = with_source_link(
            _skill(external_ids={"folder": "team/alpha helper"}),
            repo_url=_REPO,
            ref="v1.2",
        )
        self.assertEqual(
            linked.source_url,
            _REPO + "/blob/v1.2/skills/team/alpha%20helper/SKILL.md",
        )

    def test_user_info_in_the_address_never_reaches_the_link(self):
        linked = with_source_link(
            _skill(),
            repo_url="https://someone:secret@git.example/acme/skills",
            ref="main",
        )
        self.assertNotIn("secret", linked.source_url)
        self.assertTrue(linked.source_url.startswith(_REPO + "/"))

    def test_no_repository_leaves_the_detail_as_it_was(self):
        detail = _skill()
        self.assertIs(with_source_link(detail, repo_url="", ref="main"), detail)
        ssh_only = "git@git.example:acme/skills.git"
        self.assertIs(with_source_link(detail, repo_url=ssh_only, ref="main"), detail)

    def test_a_skill_without_a_folder_gets_no_link(self):
        linked = with_source_link(_skill(external_ids={}), repo_url=_REPO, ref="main")
        self.assertIsNone(linked.source_repository)
        self.assertIsNone(linked.source_url)

    def test_only_skills_are_linked(self):
        linked = with_source_link(
            _skill(component_type=ComponentType.agent), repo_url=_REPO, ref="main"
        )
        self.assertIsNone(linked.source_url)

    def test_a_detail_carries_no_link_by_default(self):
        detail = _skill()
        self.assertIsNone(detail.source_repository)
        self.assertIsNone(detail.source_url)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
''',
    "link tests",
)

# --- frontend: contract mirror -------------------------------------------------
after_line(
    F + "types/catalogue.ts",
    "definition?: string",
    r'''
/** The repository the definition lives in (owner/name), when the deployment configures it. Detail responses only. */
source_repository?: string | null
/** A web link to the definition file in that repository. Detail responses only. */
source_url?: string | null
''',
    "ts fields",
    "export interface ComponentDetail extends ComponentSummary {",
    "\n}",
)
edit(F + "types/scope.ts", "CONTRACT_SCHEMA_VERSION = '1.4.0'", "CONTRACT_SCHEMA_VERSION = '1.5.0'", "ts contract version")

# --- frontend: page model ------------------------------------------------------
MD = CP + "model.ts"
edit(
    MD,
    "  /** A link to the file at its revision. */\n  url: string | null\n",
    "  /** A link to the file at its revision. */\n  url: string | null\n"
    "  /** The repository the file lives in, e.g. `acme/skills`. */\n  repository: string | null\n",
    "model field",
)
edit(MD, "  url: null,\n", "  url: null,\n  repository: null,\n", "model empty")
edit(
    CP + "fromRegistry.ts",
    "      catalogueVersion: detail.catalogue_version || null,\n",
    "      catalogueVersion: detail.catalogue_version || null,\n"
    "      url: detail.source_url || null,\n"
    "      repository: detail.source_repository || null,\n",
    "page link",
)

# --- frontend: source card and summary tile --------------------------------------
edit(
    CP + "SourceCard.tsx",
    "  add('Source', source.source)\n",
    r"""  add('Source', source.source)
  add(
    'Repository',
    source.repository === null ? null : href ? (
      <a href={href} style={linkStyle}>
        {source.repository}
      </a>
    ) : (
      source.repository
    ),
  )
""",
    "card repository",
)
ST = CP + "DetailStatTiles.tsx"
edit(
    ST,
    "      value: shortSource(source.originSystem ?? source.source, prod),\n"
    "      detail: [prod ? 'Prod' : null, source.lastSynced ? 'synced ' + source.lastSynced : null]\n"
    "        .filter((part): part is string => part !== null)\n"
    "        .join(' @D@ ') || 'Provenance not recorded',\n".replace("@D@", DOT),
    "      value: source.repository\n"
    "        ? repositoryName(source.repository)\n"
    "        : shortSource(source.originSystem ?? source.source, prod),\n"
    "      detail:\n"
    "        source.repository ??\n"
    "        ([prod ? 'Prod' : null, source.lastSynced ? 'synced ' + source.lastSynced : null]\n"
    "          .filter((part): part is string => part !== null)\n"
    "          .join(' @D@ ') || 'Provenance not recorded'),\n".replace("@D@", DOT),
    "tile repository",
)
append(
    ST,
    r"""
/** The name part of an `owner/name` repository. */
function repositoryName(repository: string): string {
  return repository.split('/').filter(Boolean).pop() ?? repository
}
""",
    "tile helper",
)

# --- frontend: tests -----------------------------------------------------------------
edit(
    CP + "SourceCard.test.tsx",
    "  it('says when no source is recorded', () => {\n",
    r"""  it('names the repository and links it to the file', () => {
    const url = 'https://git.example/acme/skills/blob/main/skills/alpha/SKILL.md'
    render(<SourceCard source={{ ...EMPTY_SOURCE, source: 'skills_repo', repository: 'acme/skills', url }} />)
    expect(screen.getByText('Repository')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'acme/skills' })).toHaveAttribute('href', url)
    expect(screen.getByRole('link', { name: 'Open source' })).toHaveAttribute('href', url)
  })

  it('shows the repository as text when the link is not safe', () => {
    render(<SourceCard source={{ ...EMPTY_SOURCE, repository: 'acme/skills', url: 'javascript:alert(1)' }} />)
    expect(screen.getByText('acme/skills')).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: 'acme/skills' })).toBeNull()
  })

  it('says when no source is recorded', () => {
""",
    "card tests",
)
append(
    CP + "fromRegistry.test.ts",
    r"""
describe('toPageModel source link', () => {
  it('carries the repository and the link to the file', () => {
    const url = 'https://git.example/acme/skills/blob/main/skills/alpha-ticket-helper/SKILL.md'
    const { source } = toPageModel(detail({ source_repository: 'acme/skills', source_url: url }), { demo: false })
    expect(source.repository).toBe('acme/skills')
    expect(source.url).toBe(url)
  })

  it('leaves both out when the registry has no link', () => {
    const { source } = toPageModel(detail({ source_repository: null, source_url: null }), { demo: false })
    expect(source.repository).toBeNull()
    expect(source.url).toBeNull()
  })
})
""",
    "fromRegistry tests",
)
edit(
    CP + "ComponentDetailLayout.test.tsx",
    "  it('says the full definition is not available and shows the description once, in the details', () => {\n",
    r"""  it('names the repository in the source tile', () => {
    setWide(true)
    renderPage(makeModel({ source: { ...EMPTY_SOURCE, source: 'skills_repo', repository: 'acme/skills' } }))
    const summary = screen.getByRole('region', { name: 'Summary' })
    expect(within(summary).getByText('skills')).toBeInTheDocument()
    expect(within(summary).getByText('acme/skills')).toBeInTheDocument()
  })

  it('says the full definition is not available and shows the description once, in the details', () => {
""",
    "tile test",
)

if errors:
    print("NOTHING WRITTEN")
    for line in errors:
        print("FAIL", line)
    sys.exit(1)
for path, text in texts.items():
    (ROOT / path).write_text(text, encoding="utf-8")
for path, text in created.items():
    (ROOT / path).write_text(text, encoding="utf-8")
print(f"OK {len(done)} edits, {len(texts)} files changed, {len(created)} created")
