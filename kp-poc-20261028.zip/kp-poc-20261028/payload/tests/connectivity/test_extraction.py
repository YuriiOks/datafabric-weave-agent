"""US-25: the extraction client and the local stub extractor."""

from __future__ import annotations

import json

import httpx
import pytest
from pydantic import ValidationError

from connectivity.support import Stack
from kp.connectivity import (
    ExtractionClient,
    ExtractionError,
    ExtractionUnavailableError,
    Manifest,
    MissingExtractorVersionError,
    StubExtractionService,
)
from kp.connectivity.conversion import DOCX, XLSX, to_markdown
from kp.connectivity.fake_gateway import FAKE_EXTRACTION_URL
from kp.connectivity.models import ExtractionRequest, ExtractionResponse
from kp.connectivity.stand_in_content import make_docx, make_pdf, make_xlsx
from kp.domain import SourceKind
from kp.errors import SourceAuthRefusedError


def _request(
    stack: Stack, media_type: str, data: bytes, item_id: str = "item-1"
) -> ExtractionRequest:
    key = f"github/{item_id}/v1"
    stack.raw.put_if_absent(key, data)
    return ExtractionRequest(
        item_id=item_id,
        source_type=SourceKind.GITHUB,
        version="v1",
        storage_reference=stack.raw.location(key),
        media_type=media_type,
        hints={"native_id": "docs/a.md", "title": "A", "modified_at": "2026-10-01T09:00:00+00:00"},
    )


def test_us25_client_posts_identity_reference_media_type_and_source_never_bytes(
    stack: Stack,
) -> None:
    sent: list[httpx.Request] = []

    def spy(request: httpx.Request) -> httpx.Response:
        sent.append(request)
        return stack.stub.transport().handle_request(request)

    payload = b"UNIQUE-FILE-CONTENT-" + b"x" * 5000
    request = _request(stack, "text/markdown", payload)
    client = ExtractionClient(
        http=httpx.Client(transport=httpx.MockTransport(spy)), endpoint=FAKE_EXTRACTION_URL
    )

    response = client.extract(request)

    [call] = sent
    body = json.loads(call.content)
    assert set(body) == {
        "item_id",
        "source_type",
        "version",
        "storage_reference",
        "media_type",
        "hints",
    }
    assert body["source_type"] == "github"
    assert body["media_type"] == "text/markdown"
    assert body["storage_reference"] == "local:github/item-1/v1"
    assert b"UNIQUE-FILE-CONTENT" not in call.content
    assert len(call.content) < 600
    assert response.extractor_version == "stub-extractor/1.0"


def test_us25_extractor_version_is_mandatory(stack: Stack) -> None:
    blank = StubExtractionService(stack.raw, stack.markdown, stack.clock, extractor_version="")
    client = ExtractionClient(
        http=httpx.Client(transport=blank.transport()), endpoint=FAKE_EXTRACTION_URL
    )

    with pytest.raises(MissingExtractorVersionError):
        client.extract(_request(stack, "text/markdown", b"# Title\n"))


def test_us25_service_answers_are_mapped_to_typed_errors(stack: Stack) -> None:
    request = _request(stack, "text/markdown", b"# Title\n")

    def client_for(status: int, text: str = "{}") -> ExtractionClient:
        return ExtractionClient(
            http=httpx.Client(
                transport=httpx.MockTransport(lambda _: httpx.Response(status, text=text))
            ),
            endpoint=FAKE_EXTRACTION_URL,
        )

    with pytest.raises(ExtractionError):
        client_for(422).extract(request)
    with pytest.raises(ExtractionUnavailableError):
        client_for(503).extract(request)
    with pytest.raises(SourceAuthRefusedError):
        client_for(401).extract(request)
    with pytest.raises(ExtractionUnavailableError):
        client_for(408).extract(request)
    with pytest.raises(ExtractionUnavailableError):
        client_for(429).extract(request)
    with pytest.raises(ExtractionError):
        client_for(200, "not json").extract(request)
    with pytest.raises(ExtractionError):
        client_for(200, "[]").extract(request)
    with pytest.raises(ExtractionError):
        client_for(200, '{"item_id": 5}').extract(request)


def test_us25_unreachable_service_is_a_typed_error(stack: Stack) -> None:
    def down(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down", request=request)

    client = ExtractionClient(
        http=httpx.Client(transport=httpx.MockTransport(down)), endpoint=FAKE_EXTRACTION_URL
    )

    with pytest.raises(ExtractionUnavailableError):
        client.extract(_request(stack, "text/markdown", b"x"))


def test_us25_hints_cannot_carry_a_document() -> None:
    with pytest.raises(ValidationError, match="longer than"):
        ExtractionRequest(
            item_id="i",
            source_type=SourceKind.JIRA,
            version="1",
            storage_reference="local:a/b/1",
            media_type="text/plain",
            hints={"title": "x" * 2000},
        )


def test_us25_stub_writes_markdown_and_manifest_beside_each_other(stack: Stack) -> None:
    response = stack.stub.extract(_request(stack, "text/markdown", b"# Title\n\nBody.\n"))

    assert response.markdown_location == "local:github/item-1/v1.md"
    assert response.manifest_location == "local:github/item-1/v1.manifest.json"
    assert stack.markdown.get("github/item-1/v1.md") == b"# Title\n\nBody.\n"
    manifest = Manifest.model_validate_json(stack.markdown.get("github/item-1/v1.manifest.json"))
    assert manifest.item_id == "item-1"
    assert manifest.source_type is SourceKind.GITHUB
    assert manifest.native_id == "docs/a.md"
    assert manifest.title == "A"
    assert manifest.author is None
    assert manifest.extracted_at == stack.clock.now()
    assert manifest.extractor_version == "stub-extractor/1.0"


def test_us25_manifest_without_a_field_is_not_complete() -> None:
    with pytest.raises(ValidationError):
        Manifest.model_validate({"item_id": "i"})


def test_us25_stub_is_idempotent_and_does_not_rewrite_outputs(stack: Stack) -> None:
    request = _request(stack, "text/markdown", b"# Title\n")
    first = stack.stub.extract(request)
    stack.clock.set(stack.clock.now().replace(year=2027))

    second = stack.stub.extract(request)

    assert first == second
    manifest = Manifest.model_validate_json(stack.markdown.get("github/item-1/v1.manifest.json"))
    assert manifest.extracted_at.year == 2026


def test_us25_stub_reports_a_missing_object_and_an_unknown_type(stack: Stack) -> None:
    missing = ExtractionRequest(
        item_id="gone",
        source_type=SourceKind.GITHUB,
        version="v1",
        storage_reference=stack.raw.location("github/gone/v1"),
        media_type="text/markdown",
    )
    with pytest.raises(ExtractionError, match="No stored object"):
        stack.stub.extract(missing)
    with pytest.raises(ExtractionError, match="No stub converter"):
        stack.stub.extract(_request(stack, "image/png", b"\x89PNG", item_id="img"))


def test_us25_empty_markdown_is_flagged_with_a_warning(stack: Stack) -> None:
    response = stack.stub.extract(_request(stack, "text/markdown", b"   \n", item_id="blank"))

    assert response.warnings == ("no text could be extracted",)


def test_us25_conversions_keep_headings_tables_and_sheets() -> None:
    html_md, _ = to_markdown(
        "text/html",
        b"<h1>Top</h1><p>Intro text.</p><ul><li>one</li></ul>"
        b"<table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>",
    )
    docx_md, _ = to_markdown(DOCX, make_docx("Heading", ["First.", "Second."]))
    xlsx_md, _ = to_markdown(XLSX, make_xlsx("Data", [["Name", "Qty"], ["a", 2]]))
    pdf_md, pages = to_markdown("application/pdf", make_pdf(["Line one", "Line two"]))

    assert "# Top" in html_md
    assert "- one" in html_md
    assert "| A | B |\n| --- | --- |\n| 1 | 2 |" in html_md
    assert docx_md.startswith("# Heading")
    assert "First." in docx_md
    assert "## Data" in xlsx_md
    assert "| a | 2 |" in xlsx_md
    assert "Line one" in pdf_md
    assert pages == 1


@pytest.mark.parametrize("media_type", [DOCX, XLSX, "application/pdf", "application/json"])
def test_us25_corrupt_bytes_are_an_extraction_error(media_type: str) -> None:
    with pytest.raises(ExtractionError):
        to_markdown(media_type, b"not a document")


def test_us25_response_model_keeps_only_known_fields_from_a_richer_service(stack: Stack) -> None:
    def richer(request: httpx.Request) -> httpx.Response:
        body = json.loads(stack.stub.transport().handle_request(request).content)
        return httpx.Response(200, json={**body, "billing_unit": 3})

    client = ExtractionClient(
        http=httpx.Client(transport=httpx.MockTransport(richer)), endpoint=FAKE_EXTRACTION_URL
    )

    response = client.extract(_request(stack, "text/markdown", b"# T\n"))

    assert isinstance(response, ExtractionResponse)
