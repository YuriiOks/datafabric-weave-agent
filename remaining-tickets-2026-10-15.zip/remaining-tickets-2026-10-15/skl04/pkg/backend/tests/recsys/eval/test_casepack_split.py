"""Grouped split: deterministic placement, no leakage, frozen final test, no final feedback."""

from __future__ import annotations

import unittest
from datetime import UTC, datetime

from app.recsys.eval.casepack.cases import (
    EvidenceKind,
    EvidenceRequirement,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.casepack.lineage import CasePackError
from app.recsys.eval.casepack.split import (
    FeedbackEntry,
    FeedbackPurpose,
    Partition,
    SplitManifest,
    assign_partitions,
    check_feedback,
    check_grouping,
    freeze_final,
    verify_final,
)

from . import casepack_support as support

WEIGHTS = {
    Partition.development: 50,
    Partition.validation: 20,
    Partition.calibration: 10,
    Partition.final_test: 20,
}
ONE = support.component_id(1)
TWO = support.component_id(2)


def _split() -> SplitManifest:
    return SplitManifest(
        seed="seed-1",
        weights=WEIGHTS,
        assignments={"g-dev": Partition.development, "g-final": Partition.final_test},
    )


class AssignmentTests(unittest.TestCase):
    def test_assignment_is_deterministic(self) -> None:
        groups = [f"need-{number}" for number in range(40)]
        first = assign_partitions(groups, seed="seed-1", weights=WEIGHTS)
        again = assign_partitions(list(reversed(groups)), seed="seed-1", weights=WEIGHTS)
        self.assertEqual(first.assignments, again.assignments)

    def test_adding_groups_moves_no_existing_group(self) -> None:
        first = assign_partitions([f"need-{n}" for n in range(40)], seed="s", weights=WEIGHTS)
        grown = assign_partitions([f"need-{n}" for n in range(80)], seed="s", weights=WEIGHTS)
        for group, partition in first.assignments.items():
            self.assertIs(grown.assignments[group], partition)

    def test_a_zero_weight_partition_receives_nothing(self) -> None:
        weights = {Partition.development: 1, Partition.final_test: 0}
        split = assign_partitions([f"need-{n}" for n in range(20)], seed="s", weights=weights)
        self.assertEqual(set(split.assignments.values()), {Partition.development})

    def test_unusable_weights_are_refused(self) -> None:
        with self.assertRaises(ValueError):
            assign_partitions(["need-1"], seed="s", weights={Partition.development: -1})
        with self.assertRaises(ValueError):
            assign_partitions(["need-1"], seed="s", weights={Partition.development: 0})

    def test_unassigned_group_has_no_partition(self) -> None:
        with self.assertRaisesRegex(CasePackError, "no partition"):
            _split().partition_of("g-missing")


class GroupingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.lineage = support.corpus().lineage

    def test_the_same_need_stays_in_one_group(self) -> None:
        first = support.case(1, lineage=self.lineage, scenario=Scenario.ambiguous, need="Same")
        second = support.case(
            2, lineage=self.lineage, scenario=Scenario.ambiguous, need="Same", group="other"
        )
        with self.assertRaisesRegex(CasePackError, "repeats a need"):
            check_grouping([first, second])

    def test_duplicate_components_share_a_group(self) -> None:
        duplicate = EvidenceRequirement(
            kind=EvidenceKind.duplicate_identity, subject_id=ONE, related_id=TWO
        )
        alias_case = support.case(
            1,
            lineage=self.lineage,
            scenario=Scenario.duplicate_alias,
            required_evidence=[duplicate],
            group="dup-a",
        )
        leaking = support.case(
            2,
            lineage=self.lineage,
            adjudication=support.judged({TWO: RelevanceLabel.relevant}),
            group="dup-b",
        )
        with self.assertRaisesRegex(CasePackError, "duplicate set"):
            check_grouping([alias_case, leaking])
        kept = support.case(
            2,
            lineage=self.lineage,
            adjudication=support.judged({TWO: RelevanceLabel.relevant}),
            group="dup-a",
        )
        check_grouping([alias_case, kept])

    def test_caller_supplied_related_sets_are_honoured(self) -> None:
        first = support.case(
            1, lineage=self.lineage, adjudication=support.judged({ONE: RelevanceLabel.relevant})
        )
        second = support.case(
            2, lineage=self.lineage, adjudication=support.judged({TWO: RelevanceLabel.relevant})
        )
        check_grouping([first, second])
        with self.assertRaisesRegex(CasePackError, "duplicate set"):
            check_grouping([first, second], related=[{ONE, TWO}])


class FreezeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.lineage = support.corpus().lineage
        self.final = support.case(
            1,
            lineage=self.lineage,
            group="g-final",
            adjudication=support.judged({ONE: RelevanceLabel.relevant}),
        )
        self.development = support.case(
            2, lineage=self.lineage, scenario=Scenario.ambiguous, group="g-dev"
        )
        self.cases = [self.final, self.development]

    def test_frozen_final_verifies(self) -> None:
        frozen = freeze_final(self.cases, _split())
        verify_final(self.cases, frozen)

    def test_development_changes_do_not_touch_the_freeze(self) -> None:
        frozen = freeze_final(self.cases, _split())
        changed = support.case(
            2,
            lineage=self.lineage,
            scenario=Scenario.ambiguous,
            expected=ExpectedOutcome.valid_empty,
            group="g-dev",
        )
        verify_final([self.final, changed], frozen)

    def test_a_changed_final_case_is_detected(self) -> None:
        frozen = freeze_final(self.cases, _split())
        relabelled = support.case(
            1,
            lineage=self.lineage,
            group="g-final",
            adjudication=support.judged({TWO: RelevanceLabel.relevant}),
        )
        with self.assertRaisesRegex(CasePackError, "changed after the freeze"):
            verify_final([relabelled, self.development], frozen)

    def test_refreezing_is_refused(self) -> None:
        frozen = freeze_final(self.cases, _split())
        with self.assertRaisesRegex(CasePackError, "already frozen"):
            freeze_final(self.cases, frozen)

    def test_an_unfrozen_or_empty_final_is_refused(self) -> None:
        with self.assertRaisesRegex(CasePackError, "not frozen"):
            verify_final(self.cases, _split())
        with self.assertRaisesRegex(CasePackError, "holds no case"):
            freeze_final([self.development], _split())


class FeedbackTests(unittest.TestCase):
    def setUp(self) -> None:
        lineage = support.corpus().lineage
        self.cases = [
            support.case(1, lineage=lineage, scenario=Scenario.ambiguous, group="g-final"),
            support.case(2, lineage=lineage, scenario=Scenario.ambiguous, group="g-dev"),
        ]

    def _entry(self, entry_id: str, *case_ids: str) -> FeedbackEntry:
        return FeedbackEntry(
            entry_id=entry_id,
            recorded_at=datetime(2026, 10, 1, tzinfo=UTC),
            actor="engineer-a",
            purpose=FeedbackPurpose.tuning,
            case_ids=case_ids,
        )

    def test_development_feedback_is_allowed(self) -> None:
        check_feedback([self._entry("fb-1", "skl-0002")], self.cases, _split())

    def test_final_test_feedback_is_refused(self) -> None:
        with self.assertRaisesRegex(CasePackError, "touches the final test"):
            check_feedback([self._entry("fb-1", "skl-0001")], self.cases, _split())

    def test_unknown_case_and_repeated_entry_are_refused(self) -> None:
        with self.assertRaisesRegex(CasePackError, "unknown case"):
            check_feedback([self._entry("fb-1", "skl-0099")], self.cases, _split())
        entry = self._entry("fb-1", "skl-0002")
        with self.assertRaisesRegex(CasePackError, "recorded twice"):
            check_feedback([entry, entry], self.cases, _split())
