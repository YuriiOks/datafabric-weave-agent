"""Term and schema-field extraction used by the guessed-link scorer."""

from __future__ import annotations

import re
from collections import Counter
from collections.abc import Iterable
from functools import lru_cache

_WORD = re.compile(r"[a-z0-9]+")
_MIN_TERM_LENGTH = 3
_TERM_CACHE_SIZE = 8192
_STOPWORDS = frozenset(
    {
        "the", "and", "for", "that", "with", "this", "are", "was", "any", "all", "not", "but",
        "its", "may", "must", "shall", "should", "can", "will", "has", "have", "had", "been",
        "from", "into", "than", "then", "when", "where", "which", "who", "whom", "what", "each",
        "per", "such", "only", "also", "one", "two", "does", "did", "their", "there", "these",
        "those", "they", "them", "would", "could", "being", "both", "other", "over", "under",
        "before", "after", "within", "without", "between", "given", "else", "own", "via",
    }
)  # fmt: skip


def _stem(word: str) -> str:
    """Strip a plural ending, so ``references`` and ``reference`` count as one term."""
    if len(word) > _MIN_TERM_LENGTH + 1 and word.endswith("ies"):
        return f"{word[:-3]}y"
    if len(word) > _MIN_TERM_LENGTH and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def term_counts(text: str) -> Counter[str]:
    """Count the significant terms of a text.

    Lower-cased words of at least three characters, without stop words, plural endings
    removed. Dotted numbers such as clause references are not terms.

    :param text: Any text
    :return: Occurrences per term
    """
    words = (_stem(word) for word in _WORD.findall(text.lower()))
    return Counter(
        word
        for word in words
        if len(word) >= _MIN_TERM_LENGTH and word not in _STOPWORDS and not word.isdigit()
    )


@lru_cache(maxsize=_TERM_CACHE_SIZE)
def significant_terms(text: str) -> frozenset[str]:
    """List the distinct significant terms of a text.

    The result is cached by text, because guessing scores every target text against many
    sources.

    :param text: Any text
    :return: The terms
    """
    return frozenset(term_counts(text))


def _field_pattern(name: str) -> re.Pattern[str]:
    parts = [part for part in re.split(r"[\s_-]+", name.strip()) if part]
    separator = r"[\s_-]+"
    return re.compile(
        rf"(?<!\w){separator.join(re.escape(part) for part in parts)}(?!\w)", re.IGNORECASE
    )


def schema_fields_in(text: str, known_fields: Iterable[str]) -> frozenset[str]:
    """Find which known schema fields a text mentions.

    A field ``creditor_account`` is mentioned by ``creditor_account``, ``creditor-account``
    or ``creditor account``, ignoring case, but ``currency`` is not mentioned by
    ``currency_code``, which is a different identifier.

    :param text: Any text
    :param known_fields: Field names, e.g. the properties of a schema
    :return: The names (as given) that occur in the text
    """
    return frozenset(
        name for name in known_fields if name.strip() and _field_pattern(name).search(text)
    )
