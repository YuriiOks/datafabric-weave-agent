import type { ReactNode } from 'react'
import type { ComponentPageModel } from './model'
import {
  chipStyle,
  flagChipStyle,
  monoStyle,
  mutedStyle,
  rowLabelStyle,
  rowStyle,
  rowValueStyle,
  sectionCardStyle,
  sectionHeaderStyle,
  sectionLabelStyle,
  stackedRowStyle,
} from './styles'

type Props = {
  model: ComponentPageModel
  /**
   * `grouped` is the phone's single table ("What it does" and "How it runs"); `details` is the
   * wide page's card under the definition, which leaves out what the definition already shows.
   */
  variant: 'grouped' | 'details'
}

type Row = [string, ReactNode]

export function DetailsCard({ model, variant }: Props) {
  const none = <span style={mutedStyle}>none</span>
  const dash = <span style={mutedStyle}>{'\u2014'}</span>
  const chips = (values: string[], style = chipStyle) =>
    values.length === 0
      ? none
      : values.map((value) => (
          <span key={value} style={style}>
            {value}
          </span>
        ))

  const triggers: ReactNode = model.triggers.length === 0 ? dash : model.triggers.join('; ')
  const howItRuns: Row[] = [
    ['Version', model.version ?? dash],
    ['Native binding', model.nativeBinding ? <span style={monoStyle}>{model.nativeBinding}</span> : dash],
    ['Tenants', model.tenants.length > 0 ? model.tenants.join(', ') : none],
    ['Quality flags', chips(model.qualityFlags, flagChipStyle)],
  ]

  if (variant === 'grouped') {
    const whatItDoes: Row[] = [
      ['Component id', <span key="id" style={monoStyle}>{model.id}</span>],
      ['Description', model.description ?? dash],
      ['Triggers', triggers],
      ['Tools', chips(model.tools)],
      ['Tags', chips(model.tags)],
    ]
    return (
      <section style={sectionCardStyle} aria-label="Details">
        <Group title="What it does" rows={whatItDoes} stacked />
        <Group title="How it runs" rows={howItRuns} stacked />
      </section>
    )
  }

  // Without a definition the wide page has nowhere else to show the description, tools and tags.
  const rows: Row[] = model.definition
    ? [['Triggers', triggers], ...howItRuns]
    : [
        ['Description', model.description ?? dash],
        ['Triggers', triggers],
        ['Tools', chips(model.tools)],
        ['Tags', chips(model.tags)],
        ...howItRuns,
      ]
  return (
    <section style={sectionCardStyle} aria-label="Details">
      <Group title="Details" rows={rows} stacked={false} />
    </section>
  )
}

function Group({ title, rows, stacked }: { title: string; rows: Row[]; stacked: boolean }) {
  return (
    <>
      <div style={sectionHeaderStyle}>
        <h2 style={sectionLabelStyle}>{title}</h2>
      </div>
      <dl style={{ margin: 0 }}>
        {rows.map(([label, value]) => (
          <div key={label} style={stacked ? stackedRowStyle : rowStyle}>
            <dt style={rowLabelStyle}>{label}</dt>
            <dd style={{ ...rowValueStyle, margin: 0 }}>{value}</dd>
          </div>
        ))}
      </dl>
    </>
  )
}
