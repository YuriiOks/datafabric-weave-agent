import { describe, expect, it } from 'vitest'
import { parseInline, parseMarkdown, plainText, safeHref } from './markdown'
import type { Block } from './markdown'

const SKILL = [
  '---',
  'name: Alpha Ticket Helper',
  'allowed-tools: Read, Write',
  'tags: [ticket_automation, it_operations]',
  'skills:',
  '  - alpha',
  '  - beta',
  '---',
  '',
  '# Alpha Ticket Helper',
  '',
  '## Steps',
  '',
  '1. Read the ticket.',
  '2. Pick a queue.',
  '',
  '## Steps',
  '',
  '- outer',
  '  - inner',
  '',
  '```json',
  '{ "queue": "billing" }',
  '```',
  '',
  '> [!WARNING]',
  '> Needs write scope.',
  '',
  '| Tool | Read-only |',
  '|:--|--:|',
  '| `search` | Yes |',
].join('\n')

function kinds(blocks: Block[]): string[] {
  return blocks.map((block) => block.kind)
}

describe('parseMarkdown', () => {
  const parsed = parseMarkdown(SKILL)

  it('reads frontmatter values and turns list keys into items', () => {
    const byKey = Object.fromEntries(parsed.frontmatter.map((entry) => [entry.key, entry]))
    expect(byKey['name']?.value).toBe('Alpha Ticket Helper')
    expect(byKey['name']?.items).toBeNull()
    expect(byKey['allowed-tools']?.items).toEqual(['Read', 'Write'])
    expect(byKey['tags']?.items).toEqual(['ticket_automation', 'it_operations'])
    expect(byKey['skills']?.items).toEqual(['alpha', 'beta'])
  })

  it('parses the body into blocks in order', () => {
    expect(kinds(parsed.blocks)).toEqual(['heading', 'heading', 'list', 'heading', 'list', 'code', 'alert', 'table'])
  })

  it('gives repeated headings unique slugs and lists level 2 and 3 headings', () => {
    expect(parsed.toc.map((entry) => entry.slug)).toEqual(['steps', 'steps-2'])
  })

  it('nests indented list items and keeps the start of ordered lists', () => {
    const ordered = parsed.blocks[2]
    const nested = parsed.blocks[4]
    expect(ordered?.kind === 'list' && ordered.ordered && ordered.start).toBe(1)
    expect(nested?.kind === 'list' && nested.items[0]?.children[0]?.kind).toBe('list')
  })

  it('reads fenced code, GitHub alerts and tables with short dividers', () => {
    const code = parsed.blocks[5]
    const alert = parsed.blocks[6]
    const table = parsed.blocks[7]
    expect(code).toEqual({ kind: 'code', lang: 'json', text: '{ "queue": "billing" }' })
    expect(alert?.kind === 'alert' && alert.variant).toBe('warning')
    expect(table?.kind === 'table' && table.align).toEqual(['left', 'right'])
    expect(table?.kind === 'table' && table.rows.length).toBe(1)
  })

  it('handles an empty file and an unterminated fence', () => {
    expect(parseMarkdown('').blocks).toEqual([])
    expect(parseMarkdown('```\nopen').blocks).toEqual([{ kind: 'code', lang: null, text: 'open' }])
  })
})

describe('parseInline', () => {
  it('reads strong, emphasis, code and links', () => {
    const nodes = parseInline('**bold** *em* `code` [docs](https://example.test)')
    expect(nodes.map((node) => node.kind)).toEqual(['strong', 'text', 'em', 'text', 'code', 'text', 'link'])
    expect(plainText(nodes)).toBe('bold em code docs')
  })

  it('keeps the text of a link with an unsafe target but drops the target', () => {
    const [link] = parseInline('[x](javascript:alert)')
    expect(link).toEqual({ kind: 'link', href: null, children: [{ kind: 'text', text: 'x' }] })
  })
})

describe('safeHref', () => {
  it.each(['https://a.test', 'http://a.test', 'mailto:a@b.test', '#section', 'docs/page.md', '/registry'])(
    'allows %s',
    (href: string) => {
      expect(safeHref(href)).toBe(href)
    },
  )

  it.each(['javascript:alert(1)', 'JAVASCRIPT:x', ' javascript:x', 'data:text/html,x', 'vbscript:x', '//evil.test'])(
    'rejects %s',
    (href: string) => {
      expect(safeHref(href)).toBeNull()
    },
  )
})
