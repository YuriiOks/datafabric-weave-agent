"""Tests of the publish package (lane L5)."""
