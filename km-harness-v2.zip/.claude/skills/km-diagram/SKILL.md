---
name: km-diagram
description: "Use to draw an architecture or flow diagram as one self-contained page: you write a small JSON spec, a fixed template lays it out. Argument: a short name, then the kb files or design file to draw from."
argument-hint: <name> <source kb files or design file>
disable-model-invocation: true
effort: medium
---

# km-diagram

Goal: designs/diagrams/<name>.html (the picture) and designs/diagrams/<name>.md (the same
facts as a list), made from sources, with no coordinates and no SVG written by you. A fixed
template reads a JSON spec and lays the diagram out itself. Nothing is pushed, posted or sent.

Argument: $0 is the name (lower case, ASCII, hyphens, no folder, no extension), the rest of
the line names the sources. No name: print "usage: /km-diagram <name> <sources>" and stop.
Run id: km-diagram-$0-<date>.

## 1 Facts first
- Draw only what a source says. Sources: kb files, or a design file the owner names. Look up
  through kb/INDEX.md; more than 5 files to read: ask km-scout, never read raw code yourself.
- Every node and every edge comes from a line you can name. Put those files in `sources`.
  A part or link the sources only suggest gets status `proposed`; one that is described but
  not found in code gets `missing`; one that works only in part gets `partial`.
- A diagram shows one mechanism or one boundary. If the owner's ask needs more than 14 parts
  or 4 groups, split it: one overview and linked drill-down files (`<name>-<part>`), and say
  so in a note. Do not squeeze.
- Labels in product words, at most about 28 characters; detail goes in `sub`. No hosts, URLs,
  ticket keys, people. Names come from kb/private/names.md only when the owner asks for them.

## 2 Spec
Write the spec to work/diagrams/$0.json (Write tool). Field list, kinds, statuses, line
styles and one worked example: ${CLAUDE_SKILL_DIR}/references/spec.md. Read it once.
- Flow `lr` for a sequence of stages, `tb` for layers or a hierarchy. Groups are lanes
  (who owns or where it runs); put each node in one group.
- `hot`: at most one path, as node ids in order. It is the single accent: use it for the
  path the reader must remember, not for decoration.
- Under 900 tokens for the whole spec. Short ids (lower case, 2 to 6 letters).

## 3 Build and check
`bash /home/user/km/.claude/skills/km-diagram/scripts/diagram.sh build $0 work/diagrams/$0.json`
It copies the template if needed, replaces only the spec block, validates the spec, writes the
markdown twin and refreshes the no-script list. FAIL lines name the problem: fix the JSON and
run it again. Never edit the template, and never edit the html by hand.
Revising later: change the JSON, run the same command.

## 4 Look, if a browser is at hand
Do not open any window. The owner opens designs/diagrams/$0.html in a browser, once at full
width and once narrow. Tell him what to look for: no text cut off, no label on a box, edges
that read left to right (or top to bottom), light and dark. A problem he reports is fixed in
the spec (shorter label, fewer parts, a different flow), not in the template.

## 5 Finish
- Record kb/log.d/<run>.txt: date, name, sources, anything dropped or marked proposed.
  No kb knowledge file is written, so there is no index.d entry.
- Print at most 6 lines: both paths, node and edge counts, which nodes are proposed, partial
  or missing, and the one thing the owner should check.
