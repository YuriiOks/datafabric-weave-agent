"""Fixtures of the publish tests: a connection, a clock and a small catalog that passes."""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from datetime import UTC, datetime

import pytest
from sqlalchemy import Connection

from kp.clock import FixedClock
from kp.domain import ItemRef, ItemType, Relation
from kp.links import LinkService
from kp.publish import CatalogItem
from kp.store import Database
from links.builders import clause, item, requirement, spec, state_link, story

NOW = datetime(2026, 11, 20, 9, 0, tzinfo=UTC)


class ListCatalog:
    """An item catalog that returns a fixed list."""

    def __init__(self, items: Sequence[CatalogItem]) -> None:
        self.listed = list(items)

    def items(self) -> list[CatalogItem]:
        return list(self.listed)


def catalog_item(kind: str, ref: ItemRef | None, *, has_source: bool = True) -> CatalogItem:
    """Build a catalog item."""
    return CatalogItem(
        kind=kind, key=ref.key if ref is not None else "passage-1", ref=ref, has_source=has_source
    )


def filler(count: int, *, has_source: bool = True) -> list[CatalogItem]:
    """Build items that no check minds: passages, which links never connect."""
    return [
        CatalogItem(kind="passage", key=f"passage-{number}", ref=None, has_source=has_source)
        for number in range(count)
    ]


@pytest.fixture
def connection(database: Database) -> Iterator[Connection]:
    """A connection inside one transaction."""
    with database.transaction() as conn:
        yield conn


@pytest.fixture
def clock() -> FixedClock:
    """A clock on 20 Nov 2026."""
    return FixedClock(NOW)


@pytest.fixture
def links(connection: Connection, clock: FixedClock) -> LinkService:
    """A link service on the same connection."""
    return LinkService(connection, clock=clock)


@pytest.fixture
def tied_items(links: LinkService) -> list[CatalogItem]:
    """A clause, a requirement and a story that are fully linked, so no warning fires."""
    state_link(links, requirement("REQ-1"), Relation.CONSTRAINED_BY, clause("4.2.1"))
    state_link(links, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    state_link(links, story("PAY-1"), Relation.SPECIFIED_BY, spec("S1"))
    state_link(links, clause("4.2.1"), Relation.RESOLVES_TO, item(ItemType.SCHEMA_FIELD, "s#f"))
    return [
        catalog_item("clause", clause("4.2.1")),
        catalog_item("requirement", requirement("REQ-1")),
        catalog_item("story", story("PAY-1")),
    ]
