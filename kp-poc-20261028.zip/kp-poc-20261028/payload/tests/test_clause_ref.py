"""ClauseRef parsing, formatting and ordering."""

from __future__ import annotations

import pytest

from kp.domain import ClauseRef, parse_clause_number
from kp.errors import InvalidClauseRefError


def test_parse_canonical_form_round_trips() -> None:
    ref = ClauseRef.parse("2026.1:4.2.1")

    assert (ref.edition, ref.number) == ("2026.1", "4.2.1")
    assert ref.format() == "2026.1:4.2.1"
    assert str(ref) == "2026.1:4.2.1"
    assert ClauseRef.parse(ref.format()) == ref


@pytest.mark.parametrize("text", ["2026.1 clause 4.2.1", "  2026.1 Clause 4.2.1  "])
def test_parse_accepts_spoken_form(text: str) -> None:
    ref = ClauseRef.parse(text)

    assert ref == ClauseRef("2026.1", "4.2.1")
    assert ref.human() == "2026.1 clause 4.2.1"


@pytest.mark.parametrize(
    "text",
    ["", "4.2.1", "2026.1:", "2026.1:4..2", "2026.1:4.x", "2026.1:04.2", "2026.1 4.2.1", ":4.2"],
)
def test_parse_rejects_malformed_text(text: str) -> None:
    with pytest.raises(InvalidClauseRefError):
        ClauseRef.parse(text)


def test_constructor_validates_parts() -> None:
    with pytest.raises(InvalidClauseRefError):
        ClauseRef("2026.1", "4.a")
    with pytest.raises(InvalidClauseRefError):
        ClauseRef("2026 1", "4")


def test_clause_numbers_compare_as_integers_not_text() -> None:
    refs = [ClauseRef("2026.1", n) for n in ("4.10", "4.2.1", "4.2", "4.9", "10", "4")]

    assert [r.number for r in sorted(refs)] == ["4", "4.2", "4.2.1", "4.9", "4.10", "10"]


def test_editions_compare_naturally_before_clause_numbers() -> None:
    refs = [
        ClauseRef("2026.10", "1"),
        ClauseRef("2026.9", "9"),
        ClauseRef("2025.2", "9.9"),
        ClauseRef("2026.1", "2"),
    ]

    assert [r.format() for r in sorted(refs)] == [
        "2025.2:9.9",
        "2026.1:2",
        "2026.9:9",
        "2026.10:1",
    ]


def test_comparison_with_other_types_is_unsupported() -> None:
    with pytest.raises(TypeError):
        _ = ClauseRef("2026.1", "1") < "2026.1:2"


def test_parent_and_depth() -> None:
    ref = ClauseRef("2026.1", "4.2.1")

    assert ref.depth == 3
    assert ref.parent() == ClauseRef("2026.1", "4.2")
    assert ClauseRef("2026.1", "4").parent() is None


def test_descendant_requires_same_edition_and_strict_prefix() -> None:
    clause = ClauseRef("2026.1", "4.2.1")

    assert clause.is_descendant_of(ClauseRef("2026.1", "4"))
    assert clause.is_descendant_of(ClauseRef("2026.1", "4.2"))
    assert not clause.is_descendant_of(clause)
    assert not clause.is_descendant_of(ClauseRef("2025.2", "4.2"))
    assert not clause.is_descendant_of(ClauseRef("2026.1", "4.21"))


def test_parse_clause_number() -> None:
    assert parse_clause_number("4.2.1") == (4, 2, 1)
    with pytest.raises(InvalidClauseRefError):
        parse_clause_number("4.2.")
