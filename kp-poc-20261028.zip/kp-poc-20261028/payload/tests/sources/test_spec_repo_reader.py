"""The spec repository reader: merged spec files become items that name their story (US-23)."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime

import pytest

from kp.domain import SourceKind
from kp.errors import SourceItemNotFoundError
from kp.sources.spec_repo import (
    MergedSpecFile,
    SpecRepoReader,
    read_front_matter,
)

MERGED_AT = datetime(2026, 11, 2, 10, 0, tzinfo=UTC)
LATER = datetime(2026, 11, 9, 8, 30, tzinfo=UTC)
MACHINE = (
    b"---\nstory: PAY-101\nspec: spec-pay-101\ntemplate: functional-spec@1.0.0\n"
    b"machine_authored: true\n---\n# Title\n\nSee 2026.1:4.2.1.\n"
)
PERSON = b"---\nstory: PAY-101\nspec: spec-pay-101\n---\n# Title\n\nSee 2026.1:4.2.2.\n"


class ListedSpecs:
    """A merged spec source that the test can change between sweeps."""

    def __init__(self, *files: MergedSpecFile) -> None:
        self.files = list(files)

    def merged_specs(self) -> Sequence[MergedSpecFile]:
        return list(self.files)


def _file(
    content: bytes, merged_at: datetime = MERGED_AT, path: str = "specs/PAY-101.md"
) -> MergedSpecFile:
    return MergedSpecFile(path=path, content=content, merged_at=merged_at)


def test_the_front_matter_names_story_spec_template_and_the_machine_mark() -> None:
    front = read_front_matter(MACHINE)

    assert (front.story_key, front.spec_id, front.template) == (
        "PAY-101",
        "spec-pay-101",
        "functional-spec@1.0.0",
    )
    assert front.machine_authored is True


def test_a_person_who_removes_the_mark_makes_the_file_theirs() -> None:
    assert read_front_matter(PERSON).machine_authored is False


def test_a_missing_spec_line_falls_back_to_the_id_the_write_side_derives() -> None:
    front = read_front_matter(b"---\nstory: PAY-7\n---\nBody\n")

    assert front.spec_id == "spec-pay-7"


@pytest.mark.parametrize(
    "content",
    [b"no front matter", b"---\nnot: [valid\n---\nx", b"---\n- a list\n---\nx", b""],
)
def test_a_file_without_usable_front_matter_names_no_story(content: bytes) -> None:
    front = read_front_matter(content)

    assert (front.story_key, front.spec_id, front.machine_authored) == (None, None, False)


def test_every_merged_file_is_listed_as_merged_with_what_the_gate_reads() -> None:
    reader = SpecRepoReader(ListedSpecs(_file(MACHINE)))

    batch = reader.list_changed(None)
    (changed,) = batch.items
    fetched = reader.fetch(changed.key)

    assert reader.kind is SourceKind.GITHUB
    assert changed.key.item_id == "specs/PAY-101.md"
    assert fetched.content == MACHINE
    attributes = fetched.metadata.attributes
    assert attributes["merged"] is True
    assert attributes["story_key"] == "PAY-101"
    assert attributes["spec_id"] == "spec-pay-101"
    assert attributes["machine_authored"] is True
    assert attributes["template"] == "functional-spec@1.0.0"
    assert attributes["merged_at"] == MERGED_AT.isoformat()


def test_a_file_that_names_no_story_carries_no_spec_markers() -> None:
    reader = SpecRepoReader(ListedSpecs(_file(b"# Notes\n", path="specs/notes.md")))

    (changed,) = reader.list_changed(None).items
    attributes = reader.fetch(changed.key).metadata.attributes

    assert "story_key" not in attributes
    assert attributes["merged"] is True


def test_an_unchanged_repository_reports_nothing_on_the_next_sweep() -> None:
    reader = SpecRepoReader(ListedSpecs(_file(MACHINE)))
    first = reader.list_changed(None)

    second = reader.list_changed(first.next_cursor)

    assert len(first.items) == 1
    assert second.items == ()


def test_an_edit_is_a_new_version_of_the_same_item_and_not_a_deletion() -> None:
    source = ListedSpecs(_file(MACHINE))
    reader = SpecRepoReader(source)
    first = reader.list_changed(None)
    source.files = [_file(PERSON, LATER)]

    second = reader.list_changed(first.next_cursor)

    (changed,) = second.items
    assert changed.deleted is False
    assert changed.key.item_id == first.items[0].key.item_id
    assert changed.key.version != first.items[0].key.version


def test_a_change_of_merge_date_alone_is_reported_so_the_dates_stay_right() -> None:
    source = ListedSpecs(_file(MACHINE))
    reader = SpecRepoReader(source)
    first = reader.list_changed(None)
    source.files = [_file(MACHINE, LATER)]

    second = reader.list_changed(first.next_cursor)

    assert len(second.items) == 1


def test_a_file_that_changed_since_the_listing_cannot_be_fetched() -> None:
    source = ListedSpecs(_file(MACHINE))
    reader = SpecRepoReader(source)
    (changed,) = reader.list_changed(None).items
    source.files = [_file(PERSON, LATER)]

    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(changed.key)
