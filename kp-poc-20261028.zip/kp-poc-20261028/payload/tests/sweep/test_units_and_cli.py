"""Unit tests of the pieces (gate, ordering, raw store) and of the ``kp sweep`` command."""

from __future__ import annotations

import io
from argparse import ArgumentParser
from collections.abc import Sequence
from datetime import UTC, date, datetime
from pathlib import Path

import pytest

from kp.clock import FixedClock
from kp.config import Settings
from kp.domain import (
    DETAIL_NAMES,
    ApprovalState,
    ItemKey,
    ReviewKind,
    SourceItemVersion,
    SourceKind,
)
from kp.sources.base import ItemMetadata
from kp.store import Database
from kp.sweep import (
    ApprovalGate,
    FactoryTargetProvider,
    LocalRawStore,
    RawStoreConflictError,
    SweepStore,
    SweepTarget,
)
from kp.sweep.cli import add_parser, build_runtime
from kp.sweep.series import order_key, plan_supersession

from .support import (
    MemoryRawStore,
    RecordingSleeper,
    ScriptedReader,
    entry,
    governed_attributes,
    unavailable,
)

LIBRARY = SourceKind.DOCUMENT_LIBRARY
GITHUB = SourceKind.GITHUB
NOW = datetime(2026, 11, 1, 9, 30, tzinfo=UTC)


def _metadata(**attributes: object) -> ItemMetadata:
    return ItemMetadata.model_validate(
        {
            "native_id": "doc",
            "media_type": "text/markdown",
            "title": "Doc",
            "attributes": attributes,
        }
    )


@pytest.mark.parametrize(
    ("source", "attributes", "expected"),
    [
        (LIBRARY, governed_attributes(), ApprovalState.ADMITTED),
        (LIBRARY, governed_attributes(approval_status="draft"), ApprovalState.EXCLUDED),
        (LIBRARY, governed_attributes(approval_status="withdrawn"), ApprovalState.WITHDRAWN),
        (LIBRARY, governed_attributes(approval_status="in review"), ApprovalState.PENDING),
        (LIBRARY, governed_attributes(domain=None), ApprovalState.NON_CONFORMING),
        (LIBRARY, governed_attributes(document_type="Procedure"), ApprovalState.ADMITTED),
        (LIBRARY, governed_attributes(document_type="memo"), ApprovalState.PENDING),
        (SourceKind.CONFLUENCE, {"labels": ["Approved"]}, ApprovalState.ADMITTED),
        (SourceKind.CONFLUENCE, {"labels": ["payments"]}, ApprovalState.PENDING),
        (SourceKind.CONFLUENCE, {"labels": ["approved"], "state": "draft"}, ApprovalState.EXCLUDED),
        (LIBRARY, governed_attributes(approval_status=None), ApprovalState.NON_CONFORMING),
        (LIBRARY, {"sidecar_present": False}, ApprovalState.NON_CONFORMING),
        (GITHUB, {}, ApprovalState.ADMITTED),
        (GITHUB, {"merged": False}, ApprovalState.EXCLUDED),
        (GITHUB, {"story_key": "PAY-1", "merged": True}, ApprovalState.ADMITTED),
        (GITHUB, {"story_key": "PAY-1", "merged": False}, ApprovalState.EXCLUDED),
        (GITHUB, {"story_key": "PAY-1"}, ApprovalState.PENDING),
        (SourceKind.JIRA, {}, ApprovalState.ADMITTED),
        (SourceKind.REGULATORY_REPO, {"effective_date": "2026-11-16"}, ApprovalState.ADMITTED),
        (
            SourceKind.REGULATORY_REPO,
            {"effective_date": "not a date"},
            ApprovalState.NON_CONFORMING,
        ),
        (SourceKind.REGULATORY_REPO, {"merged": False}, ApprovalState.EXCLUDED),
        (
            SourceKind.REGULATORY_REPO,
            {"effective_date": "2026-11-16", "withdrawn_from": "2026-01-01"},
            ApprovalState.ADMITTED,
        ),
    ],
)
def test_us01_gate_decides_by_the_source_own_signals(
    source: SourceKind, attributes: dict[str, object], expected: ApprovalState
) -> None:
    decision = ApprovalGate().decide(source, _metadata(**attributes))

    assert decision.state is expected


def test_us01_gate_label_and_known_types_are_configurable() -> None:
    gate = ApprovalGate(approved_label="signed-off", document_types=frozenset({"memo"}))

    label = gate.decide(SourceKind.CONFLUENCE, _metadata(labels=["signed-off"]))
    memo = gate.decide(LIBRARY, _metadata(**governed_attributes(document_type="memo")))
    guide = gate.decide(LIBRARY, _metadata(**governed_attributes()))

    assert label.state is ApprovalState.ADMITTED
    assert memo.state is ApprovalState.ADMITTED
    assert guide.review is not None
    assert guide.review.kind is ReviewKind.UNKNOWN_DOCUMENT_TYPE


def test_us03_gate_checks_conformance_only_for_documents_it_would_admit() -> None:
    draft = ApprovalGate().decide(
        LIBRARY, _metadata(**governed_attributes(approval_status="draft", domain=None))
    )

    assert draft.state is ApprovalState.EXCLUDED
    assert draft.review is None


def test_us03_document_without_status_and_sidecar_names_every_missing_detail() -> None:
    decision = ApprovalGate().decide(LIBRARY, _metadata(sidecar_present=False))

    assert decision.state is ApprovalState.NON_CONFORMING
    assert decision.review is not None
    assert decision.review.kind is ReviewKind.MISSING_DETAIL
    assert decision.review.missing_details == (*DETAIL_NAMES, "approval_status")
    assert "no metadata sidecar" in decision.review.detail


def test_us03_document_with_an_explicit_other_status_and_all_details_is_pending_quietly() -> None:
    decision = ApprovalGate().decide(
        LIBRARY, _metadata(**governed_attributes(approval_status="in review"))
    )

    assert decision.state is ApprovalState.PENDING
    assert decision.review is None


def test_us03_document_with_a_status_word_we_do_not_know_and_missing_details_is_flagged() -> None:
    decision = ApprovalGate().decide(
        LIBRARY, _metadata(**governed_attributes(approval_status="in review", authority=None))
    )

    assert decision.state is ApprovalState.NON_CONFORMING
    assert decision.review is not None
    assert decision.review.missing_details == ("authority",)


def _version(
    version: str,
    *,
    effective: date | None = None,
    modified: datetime | None = None,
    state: ApprovalState = ApprovalState.ADMITTED,
    superseded: date | None = None,
    fetched: datetime = NOW,
) -> SourceItemVersion:
    return SourceItemVersion(
        source=GITHUB,
        item_id="doc",
        version=version,
        native_id="doc",
        content_sha256="0" * 64,
        media_type="text/markdown",
        title="doc",
        modified_at=modified,
        raw_location=f"doc/{version}",
        fetched_at=fetched,
        run_id="run",
        approval_state=state,
        effective_date=effective,
        superseded_at=superseded,
    )


def test_us02_supersession_follows_effective_dates_not_load_order() -> None:
    newer_loaded_first = _version("2026.1", effective=date(2026, 11, 16))
    older_loaded_later = _version("2025.2", effective=date(2025, 6, 2))

    plan = plan_supersession([newer_loaded_first, older_loaded_later], date(2026, 11, 1))

    assert [(s.older.version, s.newer.version, s.when) for s in plan] == [
        ("2025.2", "2026.1", date(2026, 11, 16))
    ]


@pytest.mark.parametrize("reverse", [False, True])
def test_us02_numeric_versions_of_one_day_are_ordered_numerically_in_either_load_order(
    reverse: bool,
) -> None:
    day = datetime(2026, 10, 1, tzinfo=UTC)
    versions = [_version("9", modified=day), _version("10", modified=day)]
    if reverse:
        versions.reverse()

    plan = plan_supersession(versions, date(2026, 11, 1))

    assert [(s.older.version, s.newer.version) for s in plan] == [("9", "10")]
    assert order_key(_version("9", modified=day)) < order_key(_version("10", modified=day))


def test_us02_supersession_without_a_date_uses_today_and_is_not_repeated() -> None:
    first = _version("1", modified=datetime(2026, 9, 1, tzinfo=UTC))
    second = _version("2", modified=datetime(2026, 10, 1, tzinfo=UTC))

    plan = plan_supersession([first, second], date(2026, 11, 1))
    already = plan_supersession(
        [first.model_copy(update={"superseded_at": date(2026, 11, 1)}), second], date(2026, 12, 1)
    )

    assert [(s.older.version, s.when) for s in plan] == [("1", date(2026, 11, 1))]
    assert already == []


def test_us02_withdrawn_and_excluded_versions_take_no_part_in_supersession() -> None:
    live = _version("1", modified=datetime(2026, 9, 1, tzinfo=UTC))
    draft = _version("2", state=ApprovalState.EXCLUDED, modified=datetime(2026, 10, 1, tzinfo=UTC))

    assert plan_supersession([live, draft], date(2026, 11, 1)) == []
    assert order_key(live) < order_key(draft)


def test_us09_local_raw_store_is_write_once(tmp_path: Path) -> None:
    store = LocalRawStore(tmp_path)
    key = ItemKey(source=GITHUB, item_id="file", version="1")

    location = store.put(key, b"first")
    again = store.put(key, b"first")

    assert location == again == "github/file/1"
    assert store.get(location) == b"first"
    with pytest.raises(RawStoreConflictError):
        store.put(key, b"different")
    assert store.get(location) == b"first"


@pytest.mark.parametrize("item_id", ["../escape", "a/b", "..", "c:\\x"])
def test_us09_local_raw_store_keeps_every_key_inside_its_root(tmp_path: Path, item_id: str) -> None:
    root = tmp_path / "raw"
    store = LocalRawStore(root)

    location = store.put(ItemKey(source=GITHUB, item_id=item_id, version="1"), b"x")

    written = (root / location).resolve()
    assert root.resolve() in written.parents
    assert store.get(location) == b"x"


class _Provider:
    def __init__(self, readers: Sequence[ScriptedReader]) -> None:
        self.readers = readers
        self.asked: list[SourceKind] = []

    def targets(self, sources: Sequence[SourceKind]) -> Sequence[SweepTarget]:
        self.asked = list(sources)
        wanted = set(sources) or {reader.kind for reader in self.readers}
        return [SweepTarget(r) for r in self.readers if r.kind in wanted]


def _command(
    argv: list[str], provider: _Provider, database: Database, local_settings: Settings
) -> tuple[int, str]:
    parser = ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))
    args = parser.parse_args(argv)
    runtime = build_runtime(
        local_settings,
        provider,
        database=database,
        raw_store=MemoryRawStore(),
        clock=FixedClock(NOW),
        sleeper=RecordingSleeper(),
    )
    out = io.StringIO()
    return args.handler(args, runtime, out), out.getvalue()


def test_cli_sweep_runs_the_selected_sources_and_reports(
    database: Database, local_settings: Settings
) -> None:
    github = ScriptedReader(GITHUB)
    github.add(entry(GITHUB, "file", "1"))
    library = ScriptedReader(LIBRARY)
    library.add(entry(LIBRARY, "guide", "1", attributes=governed_attributes()))
    provider = _Provider([github, library])

    status, output = _command(["sweep", "--source", "github"], provider, database, local_settings)

    assert status == 0
    assert provider.asked == [GITHUB]
    assert "github scope=- completed pages=1" in output
    assert "work_items=1" in output
    assert library.list_calls == 0


def test_cli_sweep_with_no_source_sweeps_everything_configured(
    database: Database, local_settings: Settings
) -> None:
    provider = _Provider([ScriptedReader(GITHUB), ScriptedReader(LIBRARY)])

    status, output = _command(["sweep"], provider, database, local_settings)

    assert status == 0
    assert provider.asked == []
    assert "github" in output
    assert "document_library" in output


def test_cli_sweep_exits_nonzero_when_a_source_fails(
    database: Database, local_settings: Settings
) -> None:
    broken = ScriptedReader(GITHUB)
    broken.fail_next(unavailable())

    status, output = _command(["sweep"], _Provider([broken]), database, local_settings)

    assert status == 1
    assert "failed" in output


def test_us01_cli_honours_the_configured_confluence_label(
    database: Database, local_settings: Settings
) -> None:
    reader = ScriptedReader(SourceKind.CONFLUENCE)
    reader.add(entry(SourceKind.CONFLUENCE, "page", "1", attributes={"labels": ["signed-off"]}))
    settings = local_settings.model_copy(update={"confluence_approved_label": "signed-off"})

    status, _ = _command(["sweep"], _Provider([reader]), database, settings)

    assert status == 0
    with database.transaction() as connection:
        stored = SweepStore(connection).get_version(
            ItemKey(source=SourceKind.CONFLUENCE, item_id="page", version="1")
        )
    assert stored is not None
    assert stored.approval_state is ApprovalState.ADMITTED


def test_cli_factory_target_provider_builds_the_readers_of_the_named_sources(
    tmp_path: Path, local_settings: Settings
) -> None:
    (tmp_path / "code_repo").mkdir()
    settings = local_settings.model_copy(update={"data_dir": tmp_path})

    targets = FactoryTargetProvider(settings).targets([GITHUB])

    assert [(target.reader.kind, target.scope) for target in targets] == [(GITHUB, "")]


def test_us08_cli_freshness_without_a_source_flags_every_provided_source_never_swept(
    database: Database, local_settings: Settings
) -> None:
    provider = _Provider([ScriptedReader(GITHUB), ScriptedReader(LIBRARY)])

    status, output = _command(["sweep", "--freshness"], provider, database, local_settings)

    assert status == 1
    assert "stale github scope=- last_success=never" in output
    assert "stale document_library scope=- last_success=never" in output


def test_us08_cli_freshness_lists_sources_never_swept(
    database: Database, local_settings: Settings
) -> None:
    provider = _Provider([])

    status, output = _command(
        ["sweep", "--freshness", "--source", "jira"], provider, database, local_settings
    )

    assert status == 1
    assert "stale jira scope=- last_success=never" in output


def test_us08_cli_freshness_is_clean_after_a_sweep(
    database: Database, local_settings: Settings
) -> None:
    reader = ScriptedReader(GITHUB)
    provider = _Provider([reader])
    _command(["sweep"], provider, database, local_settings)

    status, output = _command(["sweep", "--freshness"], provider, database, local_settings)

    assert (status, output) == (0, "all sources fresh\n")
