"""US-18: every tool call is recorded, refusals included, listable from the spec."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable, Iterator
from datetime import UTC, datetime, timedelta

import pytest
from pydantic import JsonValue
from sqlalchemy.exc import OperationalError
from tools_fixtures import *  # noqa: F403 - pytest fixtures

from kp.clock import FixedClock
from kp.domain import ToolCallRecord
from kp.errors import AccessForbiddenError, WriteNotPermittedError
from kp.log import JsonFormatter
from kp.store import Database
from kp.tools import (
    AuditFailedError,
    AuditStore,
    DatabaseAuditSink,
    IdentityMapping,
    InvalidToolArgumentsError,
    ReadPorts,
    ToolArguments,
    ToolContext,
    ToolExecutionError,
    ToolOutcome,
    ToolRegistry,
    ToolResult,
    UnknownToolError,
    build_caller,
    build_read_registry,
    build_write_registry,
    define_tool,
    request_digest,
)
from kp.tools.testing import FakeWritePort, InMemoryAudit

NOW = datetime(2026, 11, 1, 9, 30, tzinfo=UTC)


class _Boom(ToolArguments):
    pass


def ticking(step: float) -> Callable[[], float]:
    """A monotonic counter that advances ``step`` seconds per reading."""
    values: Iterator[float] = iter(i * step for i in range(1, 1000))
    return lambda: next(values)


def test_us18_a_read_call_records_every_required_field(
    ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    registry = build_read_registry(ports, mapping, audit, clock=fixed_clock)
    caller = build_caller(user="user-one-domain", agent="spec-agent", session_id="session-9")
    arguments: dict[str, JsonValue] = {"query": "currency", "limit": 5}

    result = registry.call(caller, "search", arguments)

    (record,) = audit.records
    assert record.call_id == result.call_id
    assert record.caller == "user-one-domain"
    assert record.agent == "spec-agent"
    assert record.session_id == "session-9"
    assert record.tool == "search"
    assert record.request == arguments
    assert record.request_digest == request_digest(arguments)
    assert record.domains_applied == ("payments",)
    assert record.items_returned == 1
    assert record.filtered_count == 2
    assert record.latency_ms >= 0
    assert record.called_at == NOW
    assert record.refused is False
    assert record.error_class is None


def test_us18_latency_is_the_measured_time_in_milliseconds(
    mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    registry = ToolRegistry(mapping, audit, clock=fixed_clock, monotonic=ticking(0.25))
    registry.register(
        define_tool("noop", "Does nothing.", _Boom, lambda _c, _a: ToolOutcome(payload={}))
    )
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")

    registry.call(caller, "noop", {})

    assert audit.records[0].latency_ms == pytest.approx(250.0)


def test_us18_refusals_are_recorded(registry: ToolRegistry, audit: InMemoryAudit) -> None:
    caller = build_caller(user="user-no-access", agent="spec-agent", session_id="s")

    with pytest.raises(AccessForbiddenError):
        registry.call(caller, "template", {"spec_type": "functional"})

    (record,) = audit.records
    assert record.refused is True
    assert record.refusal_reason
    assert record.error_class == "AccessForbiddenError"
    assert record.items_returned == 0
    assert record.request == {"spec_type": "functional"}


def test_us18_a_refusal_on_a_single_item_is_recorded_with_the_callers_domains(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    caller = build_caller(user="user-no-payments-access", agent="spec-agent", session_id="s")

    with pytest.raises(AccessForbiddenError):
        registry.call(caller, "rule_as_at", {"number": "4.2.1"})

    assert audit.records[0].refused is True
    assert audit.records[0].domains_applied == ("cards",)


def test_us18_malformed_and_unknown_calls_are_recorded_as_failures_not_refusals(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")

    with pytest.raises(InvalidToolArgumentsError):
        registry.call(caller, "search", {"query": ""})
    with pytest.raises(UnknownToolError):
        registry.call(caller, "x" * 400, {})

    assert [r.error_class for r in audit.records] == [
        "InvalidToolArgumentsError",
        "UnknownToolError",
    ]
    assert not any(r.refused for r in audit.records)
    assert len(audit.records[1].tool) == 255


def test_us18_unexpected_failure_is_recorded_and_its_detail_is_not_leaked(
    mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    def explode(context: ToolContext, arguments: _Boom) -> ToolOutcome:
        raise RuntimeError("secret internal detail")

    registry = ToolRegistry(mapping, audit, clock=fixed_clock)
    registry.register(define_tool("boom", "Always fails.", _Boom, explode))
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")

    with pytest.raises(ToolExecutionError) as caught:
        registry.call(caller, "boom", {})

    assert "secret internal detail" not in str(caught.value)
    assert audit.records[0].error_class == "RuntimeError"


def test_us18_logs_of_an_unexpected_failure_carry_no_exception_text(
    mapping: IdentityMapping,
    audit: InMemoryAudit,
    fixed_clock: FixedClock,
    caplog: pytest.LogCaptureFixture,
) -> None:
    needle = "distinctive-needle-in-exception"

    def explode(context: ToolContext, arguments: _Boom) -> ToolOutcome:
        raise RuntimeError(needle)

    registry = ToolRegistry(mapping, audit, clock=fixed_clock)
    registry.register(define_tool("boom", "Always fails.", _Boom, explode))
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")
    caplog.set_level(logging.DEBUG)

    with pytest.raises(ToolExecutionError):
        registry.call(caller, "boom", {})

    failure = next(r for r in caplog.records if r.getMessage() == "Tool failed unexpectedly")
    assert failure.__dict__["error_class"] == "RuntimeError"
    assert all(r.exc_info is None and r.exc_text is None for r in caplog.records)
    assert needle not in JsonFormatter().format(failure)
    assert needle not in json.dumps([r.__dict__ for r in caplog.records], default=str)


def test_us18_a_refused_or_anonymous_call_is_stored_clipped_with_the_digest_of_the_whole(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    huge: dict[str, JsonValue] = {"query": "x" * 500_000}
    nobody = build_caller(user=None, agent="spec-agent", session_id="s-big")

    with pytest.raises(AccessForbiddenError):
        registry.call(nobody, "search", huge)

    (record,) = audit.records
    assert len(json.dumps(record.request)) < 3_000
    assert record.request["original_chars"] == len(json.dumps(huge, sort_keys=True, default=str))
    assert record.request_digest == request_digest(huge)


def test_us18_an_answered_call_keeps_its_arguments_as_sent(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    arguments: dict[str, JsonValue] = {"query": "currency " * 50}

    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s-whole")
    registry.call(caller, "search", arguments)

    assert audit.records[0].request == arguments


def test_us18_registering_a_name_twice_is_rejected(
    mapping: IdentityMapping, audit: InMemoryAudit
) -> None:
    registry = ToolRegistry(mapping, audit)
    tool = define_tool("boom", "x", _Boom, lambda _c, _a: ToolOutcome(payload={}))
    registry.register(tool)

    with pytest.raises(ValueError, match="already registered"):
        registry.register(tool)


def test_us18_request_digest_ignores_key_order_and_detects_changes() -> None:
    first: dict[str, JsonValue] = {"a": 1, "b": ["x", {"c": 2}]}
    second: dict[str, JsonValue] = {"b": ["x", {"c": 2}], "a": 1}

    assert request_digest(first) == request_digest(second)
    assert request_digest(first) != request_digest({"a": 2, "b": ["x", {"c": 2}]})
    assert len(request_digest(first)) == 64


def test_us18_a_failed_audit_write_withholds_the_result(
    ports: ReadPorts, mapping: IdentityMapping, fixed_clock: FixedClock
) -> None:
    class BrokenSink:
        def record(self, record: ToolCallRecord) -> None:
            raise OperationalError("insert", {}, Exception("database is down"))

    registry = build_read_registry(ports, mapping, BrokenSink(), clock=fixed_clock)
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")

    with pytest.raises(AuditFailedError):
        registry.call(caller, "search", {"query": "currency"})


def test_us18_records_round_trip_through_the_database(
    ports: ReadPorts, mapping: IdentityMapping, database: Database, fixed_clock: FixedClock
) -> None:
    registry = build_read_registry(ports, mapping, DatabaseAuditSink(database), clock=fixed_clock)
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="session-db")

    registry.call(caller, "search", {"query": "currency"})
    fixed_clock.set(NOW + timedelta(seconds=1))
    with pytest.raises(AccessForbiddenError):
        registry.call(
            build_caller(user="user-no-access", agent="spec-agent", session_id="session-db"),
            "search",
            {"query": "currency"},
        )

    with database.transaction() as connection:
        records = AuditStore(connection).list_for_session("session-db")
    assert [r.refused for r in records] == [False, True]
    assert records[0].domains_applied == ("cards", "payments")
    assert records[0].request == {"query": "currency"}
    assert [r.called_at for r in records] == [NOW, NOW + timedelta(seconds=1)]


def test_us18_merged_spec_records_are_listed_from_the_spec_alone(
    mapping: IdentityMapping, database: Database, fixed_clock: FixedClock, ports: ReadPorts
) -> None:
    sink = DatabaseAuditSink(database)
    read = build_read_registry(ports, mapping, sink, clock=fixed_clock)
    write = build_write_registry(FakeWritePort(), mapping, sink, clock=fixed_clock)
    drafting = build_caller(user="user-full-access", agent="spec-agent", session_id="sess-a")
    other = build_caller(user="user-full-access", agent="spec-agent", session_id="sess-b")
    tagged = build_caller(
        user="user-full-access", agent="spec-agent", session_id="sess-c", spec_id="spec-other"
    )

    steps: list[Callable[[], object]] = [
        lambda: read.call(drafting, "search", {"query": "currency"}),
        lambda: read.call(drafting, "rule_as_at", {"number": "4.2.1"}),
        lambda: write.call(drafting, "publish_spec", {"spec_id": "spec-7", "path": "specs/a.md"}),
        lambda: read.call(other, "search", {"query": "currency"}),
        lambda: read.call(tagged, "search", {"query": "currency"}),
    ]
    results = []
    for second, step in enumerate(steps):
        fixed_clock.set(NOW + timedelta(seconds=second))
        results.append(step())
    result = results[2]

    with database.transaction() as connection:
        listed = AuditStore(connection).list_for_spec("spec-7")
    assert [r.tool for r in listed] == ["search", "rule_as_at", "publish_spec"]
    assert isinstance(result, ToolResult)
    assert listed[-1].call_id == result.call_id
    assert listed[-1].spec_id == "spec-7"
    assert {r.session_id for r in listed} == {"sess-a"}


def test_us18_refused_write_is_recorded_under_the_callers_spec(
    mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    write = build_write_registry(FakeWritePort(), mapping, audit, clock=fixed_clock)
    caller = build_caller(
        user="user-full-access", agent="spec-agent", session_id="s", spec_id="spec-8"
    )

    with pytest.raises(WriteNotPermittedError):
        write.call(caller, "publish_spec", {"spec_id": "spec-8", "path": "elsewhere/x.md"})

    (record,) = audit.records
    assert record.refused is True
    assert record.spec_id == "spec-8"


def test_us18_logs_carry_no_request_content(
    registry: ToolRegistry, audit: InMemoryAudit, caplog: pytest.LogCaptureFixture
) -> None:
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s")
    caplog.set_level(logging.DEBUG)

    registry.call(caller, "search", {"query": "distinctive-needle-text"})

    logged = json.dumps([r.__dict__ for r in caplog.records], default=str)
    assert "distinctive-needle-text" not in logged
    assert any(r.getMessage() == "Tool call finished" for r in caplog.records)
