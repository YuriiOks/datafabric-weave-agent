"""Tests for agent relations, their evidence and their retirement."""
