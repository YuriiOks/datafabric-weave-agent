"""Exact-reference lookup and the rule-as-at-date read.

Both use :func:`kp.domain.select_edition_as_at`, the one "as at" semantic: an edition applies
on a day when it is effective by then and neither superseded nor withdrawn by then. Load time
is never used, and a day on which nothing applied is an error, never another edition.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from datetime import date
from typing import Final

from sqlalchemy import Connection, select

from kp.domain import ClauseRef, Edition, parse_clause_number, select_edition_as_at
from kp.errors import InvalidClauseRefError
from kp.search.errors import ClauseNotFoundError, NoEditionInForceError
from kp.search.models import RuleText
from kp.search.store import PassageStore
from kp.store.schema import clause as clause_table

_NUMBER: Final = r"(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))*"
_BARE = re.compile(rf"^(?:clause\s+)?(?P<number>{_NUMBER})$", re.IGNORECASE)
# References inside a question: "2026.1:4.2.1", "2026.1 clause 4.2.1" or "clause 4.2.1".
_MENTION = re.compile(
    rf"(?:(?P<edition>\d[A-Za-z0-9_-]*(?:\.[A-Za-z0-9_-]+)*)(?::|\s+clause\s+)"
    rf"|\bclause\s+)(?P<number>{_NUMBER})(?![\d.]*\d)",
    re.IGNORECASE,
)


def find_references(question: str) -> list[tuple[str | None, str]]:
    """Find clause references mentioned in free text.

    :param question: A question such as ``what does 2026.1 clause 4.2.1 say?``
    :return: ``(edition or None, clause number)`` pairs in order of appearance, without repeats
    """
    found: list[tuple[str | None, str]] = []
    for match in _MENTION.finditer(question):
        pair = (match["edition"], match["number"])
        if pair not in found:
            found.append(pair)
    return found


def question_references(question: str) -> list[tuple[str | None, str]]:
    """Find the clause references a question asks about.

    Mentions inside the text come first (:func:`find_references`). A question that is nothing
    but a reference (``4.2.1``, ``2026.1:4.2.1``) also counts, because a clause passage does
    not contain its own number and keyword search could never find it by number.

    :param question: Free text or a bare reference
    :return: ``(edition or None, clause number)`` pairs; empty when the question names none
    """
    found = find_references(question)
    if found:
        return found
    try:
        return [parse_reference(question)]
    except InvalidClauseRefError:
        return []


def parse_reference(text: str) -> tuple[str | None, str]:
    """Parse a reference typed by a person.

    :param text: ``2026.1:4.2.1``, ``2026.1 clause 4.2.1``, ``clause 4.2.1`` or ``4.2.1``
    :return: ``(edition, number)``; the edition is ``None`` for a bare clause number, which
        the caller resolves by date
    :raises InvalidClauseRefError: If the text is none of those forms
    """
    bare = _BARE.match(text.strip())
    if bare is not None:
        parse_clause_number(bare["number"])
        return None, bare["number"]
    ref = ClauseRef.parse(text)
    return ref.edition, ref.number


class RuleLookup:
    """Reads rules from the clause table.

    :param connection: An open connection
    :param domains: Only read rules of documents in these domains; empty means all
    """

    def __init__(self, connection: Connection, domains: Sequence[str] = ()) -> None:
        self._connection = connection
        pairs = PassageStore(connection).editions_with_domain(domains)
        self._editions = [edition for edition, _ in pairs]
        self._domains = {edition.label: domain for edition, domain in pairs}

    @property
    def editions(self) -> list[Edition]:
        """The searchable editions in this lookup's domains, read once at construction."""
        return list(self._editions)

    def edition_in_force(self, as_at: date) -> Edition | None:
        """Select the edition that applied on ``as_at``.

        :param as_at: The date to read at
        :return: The edition, or ``None`` when none applied
        """
        return select_edition_as_at(self._editions, as_at)

    def rule_as_at(self, number: str, as_at: date) -> RuleText:
        """Read a clause as it was on ``as_at``.

        :param number: Clause number, e.g. ``4.2.1``
        :param as_at: The date to read at
        :return: The clause text of the edition then in force
        :raises NoEditionInForceError: If no edition applied on ``as_at``
        :raises ClauseNotFoundError: If that edition has no such clause
        :raises InvalidClauseRefError: If ``number`` is malformed
        """
        parse_clause_number(number)
        edition = self.edition_in_force(as_at)
        if edition is None:
            raise NoEditionInForceError(as_at)
        return self._read(edition, number, as_at)

    def rule_in_edition(self, ref: ClauseRef, as_at: date) -> RuleText:
        """Read a clause of an explicitly named edition.

        The edition need not be in force on ``as_at``; ``state`` on the result says whether it
        was. A withdrawn or unapproved edition is not found.

        :param ref: Edition and clause number
        :param as_at: The date used to report the edition's state
        :return: The clause text
        :raises ClauseNotFoundError: If the edition is not searchable or has no such clause
        """
        edition = next((e for e in self._editions if e.label == ref.edition), None)
        if edition is None:
            raise ClauseNotFoundError(f"No edition {ref.edition}")
        return self._read(edition, ref.number, as_at)

    def resolve(self, text: str, as_at: date) -> RuleText:
        """Resolve a typed reference: qualified ones by edition, bare ones by date.

        :param text: See :func:`parse_reference`
        :param as_at: The date to read bare numbers at
        :return: The clause text
        :raises InvalidClauseRefError: If ``text`` is not a reference
        :raises NoEditionInForceError: For a bare number when no edition applied on ``as_at``
        :raises ClauseNotFoundError: If the clause does not exist
        """
        edition, number = parse_reference(text)
        if edition is None:
            return self.rule_as_at(number, as_at)
        return self.rule_in_edition(ClauseRef(edition, number), as_at)

    def _read(self, edition: Edition, number: str, as_at: date) -> RuleText:
        row = (
            self._connection.execute(
                select(clause_table).where(
                    clause_table.c.edition == edition.label, clause_table.c.number == number
                )
            )
            .mappings()
            .first()
        )
        if row is None:
            raise ClauseNotFoundError(f"No clause {number} in edition {edition.label}")
        return RuleText(
            ref=ClauseRef(row["edition"], row["number"]),
            title=row["title"],
            version=edition.version,
            source=edition.source,
            item_id=edition.item_id,
            domain=self._domains.get(edition.label),
            page=row["page"],
            char_start=row["char_start"],
            char_end=row["char_end"],
            text=row["text"],
            as_at=as_at,
            state=edition.state_on(as_at),
        )
