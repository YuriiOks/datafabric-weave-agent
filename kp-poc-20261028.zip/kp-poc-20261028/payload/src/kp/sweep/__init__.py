"""Sweep engine: cursors, immutable item versions, approval gate, change tracking.

Wiring for the integrator:

* ``Sweeper(database, clock=..., processor=..., raw_store=..., sleeper=time.sleep).run(targets)``
* ``kp.sweep.cli.add_parser`` / ``kp.sweep.cli.run_sweep_command`` for ``kp sweep``
* Provide a :class:`ContentProcessor` (parsers), a :class:`RawStore` (the local one is
  included) and a :class:`TargetProvider` (:class:`FactoryTargetProvider` builds the readers
  from the settings).
"""

from kp.sweep.engine import Sweeper
from kp.sweep.errors import RawStoreConflictError, SweepDeferredError, SweepError
from kp.sweep.freshness import check_freshness
from kp.sweep.gate import ApprovalGate, Decision
from kp.sweep.loadback import SpecLoader, extract_clause_refs
from kp.sweep.models import (
    Alert,
    AlertKind,
    CitationStatus,
    FreshnessReport,
    LoadedSpec,
    RateLimitPolicy,
    SourceFreshness,
    SweepSummary,
    SweepTarget,
    TargetStatus,
    TargetSummary,
    WorkItem,
    WorkReason,
)
from kp.sweep.ports import ContentProcessor, RawStore, Sleeper, TargetProvider
from kp.sweep.processing import NullContentProcessor
from kp.sweep.rawstore import LocalRawStore
from kp.sweep.store import SweepStore
from kp.sweep.targets import FactoryTargetProvider

__all__ = [
    "Alert",
    "AlertKind",
    "ApprovalGate",
    "CitationStatus",
    "ContentProcessor",
    "Decision",
    "FactoryTargetProvider",
    "FreshnessReport",
    "LoadedSpec",
    "LocalRawStore",
    "NullContentProcessor",
    "RateLimitPolicy",
    "RawStore",
    "RawStoreConflictError",
    "Sleeper",
    "SourceFreshness",
    "SpecLoader",
    "SweepDeferredError",
    "SweepError",
    "SweepStore",
    "SweepSummary",
    "SweepTarget",
    "Sweeper",
    "TargetProvider",
    "TargetStatus",
    "TargetSummary",
    "WorkItem",
    "WorkReason",
    "check_freshness",
    "extract_clause_refs",
]
