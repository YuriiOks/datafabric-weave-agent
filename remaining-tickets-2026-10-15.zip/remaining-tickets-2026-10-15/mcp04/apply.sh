#!/usr/bin/env bash
# Apply the MCP case-pack package on the committed Skill case-pack branch, uncommitted.
# Usage: bash apply.sh <worktree-root>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:?worktree root}"
python3 "$HERE/apply_mcp04.py" "$ROOT" --check
python3 "$HERE/apply_mcp04.py" "$ROOT"
git -C "$ROOT" diff --stat
git -C "$ROOT" status -s --untracked-files=all
