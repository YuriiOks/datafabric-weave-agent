"""The demo's two outputs: a self-contained HTML report and a JSON summary.

The HTML has inline CSS and no external assets. Both outputs are ASCII only: text is escaped
and any other character is written as a numeric reference or a JSON escape.
"""

from __future__ import annotations

import json
from html import escape

from kp.demo.model import ConnectivityTable, DemoOutcome, LineResult

_STYLE = """
:root { --bg:#ffffff; --fg:#1b1f24; --muted:#59636e; --line:#d0d7de; --ok:#1a7f37;
  --bad:#cf222e; --card:#f6f8fa; }
@media (prefers-color-scheme: dark) { :root { --bg:#0d1117; --fg:#e6edf3; --muted:#9198a1;
  --line:#30363d; --ok:#3fb950; --bad:#f85149; --card:#161b22; } }
body { background:var(--bg); color:var(--fg); font:15px/1.5 system-ui, sans-serif;
  margin:0 auto; max-width:60rem; padding:1.5rem 1rem 4rem; }
h1 { font-size:1.6rem; margin:0 0 .25rem; } h2 { font-size:1.2rem; margin:2rem 0 .5rem; }
p, li { margin:.25rem 0; } .muted { color:var(--muted); }
.verdict { border:1px solid var(--line); background:var(--card); border-radius:8px;
  padding:.75rem 1rem; margin:1rem 0; }
.pass { color:var(--ok); font-weight:700; } .fail { color:var(--bad); font-weight:700; }
table { border-collapse:collapse; width:100%; margin:.5rem 0; }
th, td { border-bottom:1px solid var(--line); padding:.4rem .5rem; text-align:left;
  vertical-align:top; } th { color:var(--muted); font-weight:600; }
td.evidence { overflow-wrap:anywhere; }
@media (max-width: 40rem) { table, tbody, tr, td, th { display:block; }
  thead { display:none; } td { border:0; padding:.1rem 0; }
  tr { border-bottom:1px solid var(--line); padding:.4rem 0; } }
"""


def _mark(passed: bool) -> str:
    return '<span class="pass">PASS</span>' if passed else '<span class="fail">FAIL</span>'


def _line_section(line: LineResult) -> str:
    rows = "".join(
        f"<tr><td>{_mark(check.passed)}</td><td>{escape(check.name)}</td>"
        f'<td class="evidence">{escape(check.evidence)}</td></tr>'
        for check in line.checks
    )
    return (
        f"<h2>{escape(line.line_id)} {_mark(line.passed)} - {escape(line.title)}</h2>"
        f'<p class="muted">Done when: {escape(line.done_when)}</p>'
        "<table><thead><tr><th>Result</th><th>Check</th><th>Evidence</th></tr></thead>"
        f"<tbody>{rows}</tbody></table>"
    )


def _connectivity_section(table: ConnectivityTable) -> str:
    if table.error is not None:
        return f"<h2>Connectivity job</h2><p class='fail'>{escape(table.error)}</p>"
    rows = "".join(
        f"<tr><td>{escape(row.criterion_id)}</td><td>{escape(row.title)}</td>"
        f"<td>{escape(row.result)}</td><td class='evidence'>{escape(row.detail)}</td></tr>"
        for row in table.rows
    )
    return (
        "<h2>Connectivity job against the local stand-ins (X-01..X-11)</h2>"
        f"<p>{escape(table.verdict)}</p>"
        "<table><thead><tr><th>ID</th><th>Criterion</th><th>Result</th><th>Evidence</th></tr>"
        f"</thead><tbody>{rows}</tbody></table>"
        '<p class="muted">Criteria that need the real route stay INCONCLUSIVE on stand-ins by '
        "design; they count only on the real route.</p>"
    )


def render_html(outcome: DemoOutcome) -> str:
    """Render the report page.

    :param outcome: What the demo produced
    :return: A complete HTML document, ASCII only
    """
    verdict = "all three lines pass" if outcome.passed else "at least one line fails"
    steps = "".join(
        f"<tr><td>{escape(name)}</td><td>{escape(text)}</td></tr>"
        for name, text in outcome.facts.steps
    )
    checks = "".join(
        f"<tr><td>{escape(severity)}</td><td>{escape(name)}</td><td>{escape(text)}</td></tr>"
        for severity, name, text in outcome.facts.publication
    )
    notes = "".join(f"<li>{escape(note)}</li>" for note in outcome.notes)
    page = (
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        f"<title>Knowledge platform demo</title><style>{_STYLE}</style></head><body>"
        "<h1>Knowledge platform demo</h1>"
        f'<p class="muted">Synthetic data only. Run as at {escape(outcome.facts.demo_date)}; '
        f"spec publisher: {escape(outcome.facts.publisher)}.</p>"
        f'<div class="verdict">Result: {_mark(outcome.passed)} - {verdict}.</div>'
        + "".join(_line_section(line) for line in outcome.lines)
        + "<h2>What the build did</h2><table><tbody>"
        + steps
        + "</tbody></table><h2>Publication checks</h2><table><thead><tr><th>Severity</th>"
        "<th>Check</th><th>Result</th></tr></thead><tbody>"
        + checks
        + "</tbody></table>"
        + _connectivity_section(outcome.connectivity)
        + (f"<h2>Notes</h2><ul>{notes}</ul>" if notes else "")
        + "</body></html>\n"
    )
    return page.encode("ascii", "xmlcharrefreplace").decode("ascii")


def render_json(outcome: DemoOutcome) -> str:
    """Render the summary.

    :param outcome: What the demo produced
    :return: A JSON document, ASCII only
    """
    summary = {
        "passed": outcome.passed,
        "demo_date": outcome.facts.demo_date,
        "publisher": outcome.facts.publisher,
        "lines": [
            {
                "id": line.line_id,
                "title": line.title,
                "done_when": line.done_when,
                "passed": line.passed,
                "checks": [
                    {"name": check.name, "passed": check.passed, "evidence": check.evidence}
                    for check in line.checks
                ],
            }
            for line in outcome.lines
        ],
        "build": [{"step": name, "result": text} for name, text in outcome.facts.steps],
        "publication_checks": [
            {"severity": severity, "name": name, "result": text}
            for severity, name, text in outcome.facts.publication
        ],
        "connectivity": {
            "verdict": outcome.connectivity.verdict,
            "error": outcome.connectivity.error,
            "criteria": [
                {
                    "id": row.criterion_id,
                    "title": row.title,
                    "result": row.result,
                    "detail": row.detail,
                }
                for row in outcome.connectivity.rows
            ],
        },
        "notes": list(outcome.notes),
    }
    return json.dumps(summary, indent=2, ensure_ascii=True) + "\n"
