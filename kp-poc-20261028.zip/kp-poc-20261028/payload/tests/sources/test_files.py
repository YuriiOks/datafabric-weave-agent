"""File helpers shared by the readers: missing, unreadable and malformed files."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from kp.errors import SourceItemNotFoundError, SourceUnavailableError
from kp.sources import MalformedSourceDataError
from kp.sources.files import parse_file, read_file


def test_a_file_that_vanished_is_reported_as_gone(tmp_path: Path) -> None:
    with pytest.raises(SourceItemNotFoundError):
        read_file(tmp_path / "gone.md")


def test_a_file_that_cannot_be_read_is_reported_as_the_source_being_unavailable(
    tmp_path: Path,
) -> None:
    # A directory where a file is expected fails with an OSError other than "not found".
    with pytest.raises(SourceUnavailableError):
        read_file(tmp_path)


def test_parse_failure_becomes_malformed_source_data_naming_only_the_file(
    tmp_path: Path,
) -> None:
    path = tmp_path / "broken.json"
    path.write_text("{not json", encoding="utf-8")

    with pytest.raises(MalformedSourceDataError, match=r"Thing is invalid: broken\.json"):
        parse_file(path, json.loads, "Thing")


def test_parse_errors_not_listed_by_the_caller_are_not_swallowed(tmp_path: Path) -> None:
    path = tmp_path / "x.json"
    path.write_text("[]", encoding="utf-8")

    def parse(data: bytes) -> object:
        raise KeyError("unexpected")

    with pytest.raises(KeyError):
        parse_file(path, parse, "Thing")
