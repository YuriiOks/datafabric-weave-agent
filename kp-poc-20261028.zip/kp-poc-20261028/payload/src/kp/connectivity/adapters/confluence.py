"""Confluence adapter. The version token is the page (or attachment) version number."""

from __future__ import annotations

from collections.abc import Sequence

from pydantic import JsonValue

from kp.connectivity.adapters.base import (
    GatewayToolAdapter,
    decode_base64,
    dig,
    dig_text,
    fetched_item,
    optional_text,
    optional_time,
)
from kp.connectivity.errors import FidelityError
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.models import JsonObject, Route, SampleItem
from kp.sources.base import FetchedItem, ItemMetadata

PAGE_TOOL = "get_page"
ATTACHMENT_TOOL = "get_attachment"


class ConfluenceAdapter(GatewayToolAdapter):
    """Reads pages and attachments through the Confluence tool server.

    Tool names are the design's guess until ``discover`` shows the real ones.

    :param client: The gateway client
    :param route: The Confluence route
    :param items: The Confluence sample items
    :param page_tool: Name of the page tool
    :param attachment_tool: Name of the attachment tool
    """

    def __init__(
        self,
        client: GatewayClient,
        route: Route,
        items: Sequence[SampleItem],
        *,
        page_tool: str = PAGE_TOOL,
        attachment_tool: str = ATTACHMENT_TOOL,
    ) -> None:
        super().__init__(client, route, items)
        self._page_tool = page_tool
        self._attachment_tool = attachment_tool

    def _fetch_primary(self, item: SampleItem) -> FetchedItem:
        payload = self._call(item, self._page_tool, {"page_id": item.native_id})
        body = dig_text(item, payload, "body.storage.value")
        version = _version_number(item, dig(item, payload, "version.number"))
        return fetched_item(item, version, body.encode("utf-8"), _metadata(item, payload))

    def _fetch_attachment(self, item: SampleItem) -> FetchedItem:
        payload = self._call(
            item,
            self._attachment_tool,
            {"page_id": item.parent_native_id or "", "attachment_id": item.native_id},
        )
        version = _version_number(item, dig(item, payload, "version.number"))
        return fetched_item(
            item,
            version,
            decode_base64(item, payload, "content_base64"),
            _metadata(item, payload, {"attachment_parent": item.parent_native_id}),
        )


def _metadata(
    item: SampleItem, payload: JsonObject, attributes: dict[str, JsonValue] | None = None
) -> ItemMetadata:
    return ItemMetadata(
        native_id=dig_text(item, payload, "id"),
        media_type=item.media_type,
        title=dig_text(item, payload, "title"),
        author=optional_text(payload, "version.by"),
        modified_at=optional_time(payload, "version.when"),
        attributes=attributes or {},
    )


def _version_number(item: SampleItem, value: object) -> str:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise FidelityError(item.source.value, item.item_id, "version.number is not a number")
    return str(value)
