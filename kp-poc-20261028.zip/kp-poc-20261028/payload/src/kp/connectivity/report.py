"""The exit-criteria report: criteria, per-hop evidence, verdict and what was not tested.

Local mode never claims the platform works. Its verdict says the harness is proven against
stand-ins and the platform is not. In every mode a hop without evidence is shown as not
passed, never as passed by omission.
"""

from __future__ import annotations

from collections import defaultdict
from enum import StrEnum

from kp.config import Mode
from kp.connectivity.evidence import Evidence
from kp.connectivity.http_status import FORBIDDEN, UNAUTHORIZED
from kp.connectivity.models import ItemStatus
from kp.connectivity.scoring import (
    CriterionResult,
    is_success,
    latest_outcomes,
    namespace_of,
    non_probe_calls,
    percentile,
    score_criteria,
)
from kp.domain import ExitResult, ExtractionStatus, McpCallRecord, SourceKind
from kp.domain.base import DomainModel

LOCAL_VERDICT = "Local run only: the harness is proven against stand-ins; the platform is not."

_NOT_TESTED = (
    "Volume: only the nine sample items were moved, so throughput, paging and storage growth "
    "are unknown.",
    "Change tracking: saved positions, the Jira overlap window, page-version detection over "
    "time and withdrawals were not exercised.",
    "Extraction quality: only non-empty Markdown and a complete manifest were checked, not "
    "whether tables, headings or spreadsheets came out right.",
    "Concurrency and scheduling: one run at a time, started by hand.",
)
_LOCAL_NOT_TESTED = (
    "The platform route itself: gateway reachability, sign-in, group entitlement, source "
    "tokens and cross-region latency, because every call went to a stand-in.",
)


class Cell(StrEnum):
    """What the evidence says about one fact of one hop."""

    YES = "yes"
    NO = "no"
    NO_EVIDENCE = "no evidence"
    NOT_APPLICABLE = "n/a"


class HopVerdict(StrEnum):
    """Whether a hop counts as passed."""

    PASSED = "passed"
    FAILED = "failed"
    NOT_PASSED = "not passed"


class HopRow(DomainModel):
    """One hop of the route and what is known about it."""

    hop: str
    reachable: Cell
    authenticated: Cell
    entitled: Cell
    fields_survived: Cell
    p50_ms: float | None
    verdict: HopVerdict
    note: str = ""


class ExitReport(DomainModel):
    """The whole report."""

    mode: Mode
    verdict: str
    criteria: tuple[CriterionResult, ...]
    hops: tuple[HopRow, ...]
    attention: tuple[str, ...]
    not_tested: tuple[str, ...]

    def count(self, result: ExitResult) -> int:
        """Count the criteria with a given result.

        :param result: PASS, FAIL or INCONCLUSIVE
        :return: How many criteria have it
        """
        return sum(1 for criterion in self.criteria if criterion.result is result)


def build_report(evidence: Evidence) -> ExitReport:
    """Score the evidence into a report.

    :param evidence: Gathered evidence
    :return: The report
    """
    criteria = score_criteria(evidence)
    return ExitReport(
        mode=evidence.mode,
        verdict=_verdict(evidence.mode, criteria),
        criteria=criteria,
        hops=_hops(evidence),
        attention=_attention(evidence),
        not_tested=_not_tested(evidence, criteria),
    )


def _verdict(mode: Mode, criteria: tuple[CriterionResult, ...]) -> str:
    failed = [c.id for c in criteria if c.result is ExitResult.FAIL]
    open_ids = [c.id for c in criteria if c.result is ExitResult.INCONCLUSIVE]
    if failed:
        prefix = "Local run found harness defects" if mode is Mode.LOCAL else "Route not ready"
        return f"{prefix}: failed {', '.join(failed)}."
    if mode is Mode.LOCAL:
        suffix = f" Still without evidence: {', '.join(open_ids)}." if open_ids else ""
        return LOCAL_VERDICT + suffix
    if open_ids:
        return (
            "Incomplete: no evidence yet for "
            f"{', '.join(open_ids)}. A hop without evidence is not a pass."
        )
    return "All eleven criteria are met on the real route."


def _hops(evidence: Evidence) -> tuple[HopRow, ...]:
    rows = [_gateway_hop(evidence)]
    rows += [_source_hop(evidence, source) for source in evidence.namespaces]
    rows += [_storage_hop(evidence), _extraction_hop(evidence)]
    return tuple(rows)


def _decide(evidence: Evidence, cells: list[Cell]) -> HopVerdict:
    applicable = [cell for cell in cells if cell is not Cell.NOT_APPLICABLE]
    if Cell.NO in applicable:
        return HopVerdict.FAILED
    if evidence.mode is Mode.REAL and applicable and all(cell is Cell.YES for cell in applicable):
        return HopVerdict.PASSED
    return HopVerdict.NOT_PASSED


def _p50(calls: list[float]) -> float | None:
    return percentile(calls, 0.5) if calls else None


def _gateway_hop(evidence: Evidence) -> HopRow:
    calls = list(non_probe_calls(evidence))
    reachable = _reachable(calls)
    authenticated = _authenticated(calls)
    cells = [reachable, authenticated, Cell.NOT_APPLICABLE, Cell.NOT_APPLICABLE]
    return HopRow(
        hop="gateway",
        reachable=reachable,
        authenticated=authenticated,
        entitled=Cell.NOT_APPLICABLE,
        fields_survived=Cell.NOT_APPLICABLE,
        p50_ms=_p50([c.latency_ms for c in calls if is_success(c)]),
        verdict=_decide(evidence, cells),
        note=_stand_in_note(evidence),
    )


def _source_hop(evidence: Evidence, source: SourceKind) -> HopRow:
    namespace = evidence.namespaces[source]
    calls = [c for c in non_probe_calls(evidence) if namespace_of(c) == namespace]
    reachable = _reachable(calls)
    authenticated = _authenticated(calls)
    entitled = _decided(calls, FORBIDDEN)
    fields = _fields_cell(evidence, source, calls)
    return HopRow(
        hop=source.value,
        reachable=reachable,
        authenticated=authenticated,
        entitled=entitled,
        fields_survived=fields,
        p50_ms=_p50([c.latency_ms for c in calls if is_success(c)]),
        verdict=_decide(evidence, [reachable, authenticated, entitled, fields]),
        note=_stand_in_note(evidence),
    )


def _reachable(calls: list[McpCallRecord]) -> Cell:
    if not calls:
        return Cell.NO_EVIDENCE
    return Cell.YES if any(c.http_status is not None for c in calls) else Cell.NO


def _authenticated(calls: list[McpCallRecord]) -> Cell:
    return _decided(calls, UNAUTHORIZED)


def _decided(calls: list[McpCallRecord], refusal: int) -> Cell:
    """Read a fact from the most recent call that settled it, so a fix supersedes old refusals.

    :param calls: Calls in the order they were made
    :param refusal: The status that refuses the fact (401 for sign-in, 403 for entitlement)
    """
    verdict = Cell.NO_EVIDENCE
    for call in calls:
        if is_success(call):
            verdict = Cell.YES
        elif call.http_status == refusal:
            verdict = Cell.NO
    return verdict


def _fields_cell(evidence: Evidence, source: SourceKind, calls: list[McpCallRecord]) -> Cell:
    outcomes = [item for item in latest_outcomes(evidence).values() if item.source is source]
    if any(item.error_class == "FidelityError" for item in outcomes):
        return Cell.NO
    fetch_calls = [c for c in calls if c.operation == "tools/call" and is_success(c)]
    latest_run = fetch_calls[-1].run_id if fetch_calls else None
    latest = [c for c in fetch_calls if c.run_id == latest_run]
    if latest and all(c.surviving_fields for c in latest):
        return Cell.YES
    return Cell.NO_EVIDENCE


def _storage_hop(evidence: Evidence) -> HopRow:
    if not evidence.items:
        written = Cell.NO_EVIDENCE
    elif all(item.raw_sha256 == item.row_sha256 for item in evidence.items):
        written = Cell.YES
    else:
        written = Cell.NO
    return HopRow(
        hop="raw storage",
        reachable=written,
        authenticated=Cell.NOT_APPLICABLE,
        entitled=Cell.NOT_APPLICABLE,
        fields_survived=Cell.NOT_APPLICABLE,
        p50_ms=None,
        verdict=_decide(evidence, [written]),
        note=_stand_in_note(evidence),
    )


def _extraction_hop(evidence: Evidence) -> HopRow:
    statuses = [item.extraction_status for item in evidence.items]
    if ExtractionStatus.FAILED in statuses:
        reached, survived = Cell.YES, Cell.NO
    elif ExtractionStatus.SUCCEEDED in statuses:
        reached = Cell.YES
        complete = all(
            item.markdown_chars and item.manifest_problems == ()
            for item in evidence.items
            if item.extraction_status is ExtractionStatus.SUCCEEDED
        )
        survived = Cell.YES if complete else Cell.NO
    else:
        reached, survived = Cell.NO_EVIDENCE, Cell.NO_EVIDENCE
    return HopRow(
        hop="extraction",
        reachable=reached,
        authenticated=Cell.NOT_APPLICABLE,
        entitled=Cell.NOT_APPLICABLE,
        fields_survived=survived,
        p50_ms=None,
        verdict=_decide(evidence, [reached, survived]),
        note=_stand_in_note(evidence),
    )


def _stand_in_note(evidence: Evidence) -> str:
    return "stand-in answered; not a pass on the platform" if evidence.mode is Mode.LOCAL else ""


def _attention(evidence: Evidence) -> tuple[str, ...]:
    failures = [
        item for item in latest_outcomes(evidence).values() if item.status is ItemStatus.FAILED
    ]
    lines = [
        f"{item.item_id} ({item.source.value}, {item.media_type}): {item.error_class}"
        for item in failures
    ]
    lost: dict[SourceKind, list[str]] = defaultdict(list)
    for item in failures:
        if item.error_class == "FidelityError":
            lost[item.source].append(item.item_id)
    for source, ids in lost.items():
        lines.append(
            f"Tools for {source.value} return summaries instead of source fields "
            f"({', '.join(ids)}); that source moves to direct reads."
        )
    return tuple(lines)


def _not_tested(evidence: Evidence, criteria: tuple[CriterionResult, ...]) -> tuple[str, ...]:
    lines = list(_NOT_TESTED)
    if evidence.mode is Mode.LOCAL:
        lines.append(_LOCAL_NOT_TESTED[0])
    lines += [
        f"{c.id} has no evidence yet: {c.title.lower()}."
        for c in criteria
        if c.result is ExitResult.INCONCLUSIVE and c.detail.startswith("No evidence")
    ]
    return tuple(lines)


def render_markdown(report: ExitReport) -> str:
    """Render the report as Markdown.

    :param report: The report
    :return: The document text
    """
    lines = [
        "# Connectivity exit-criteria report",
        "",
        f"Route: **{report.mode.value}**",
        "",
        f"**Verdict.** {report.verdict}",
        "",
        f"PASS {report.count(ExitResult.PASS)}, FAIL {report.count(ExitResult.FAIL)}, "
        f"INCONCLUSIVE {report.count(ExitResult.INCONCLUSIVE)}.",
        "",
        "## Exit criteria",
        "",
        "| ID | Criterion | Result | Evidence | If not met |",
        "|---|---|---|---|---|",
    ]
    lines += [
        f"| {c.id} | {c.title} | {c.result.value} | {c.detail} | {c.if_not_met} |"
        for c in report.criteria
    ]
    lines += [
        "",
        "## Hops",
        "",
        "A hop without evidence is shown as not passed.",
        "",
        "| Hop | Reachable | Authenticated | Entitled | Fields survived | p50 ms | Verdict |",
        "|---|---|---|---|---|---|---|",
    ]
    lines += [
        f"| {h.hop} | {h.reachable.value} | {h.authenticated.value} | {h.entitled.value} | "
        f"{h.fields_survived.value} | {'-' if h.p50_ms is None else f'{h.p50_ms:.0f}'} | "
        f"{h.verdict.value}{f' ({h.note})' if h.note else ''} |"
        for h in report.hops
    ]
    if report.attention:
        lines += ["", "## Items that need attention", ""]
        lines += [f"- {line}" for line in report.attention]
    lines += ["", "## What was not tested", ""]
    lines += [f"- {line}" for line in report.not_tested]
    return "\n".join(lines) + "\n"
