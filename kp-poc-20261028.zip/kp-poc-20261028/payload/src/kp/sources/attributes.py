"""Names of the route-specific approval signals in ``ItemMetadata.attributes``.

Each reader reports what its source says about an item and decides nothing: the approval
rules of the sweep read these keys. Values are always JSON-compatible. A key is present for
every item of its route, with ``None`` when the source does not state it.
"""

from __future__ import annotations

from typing import Final

# Document library (one sidecar per document). The five required document details use the
# names in ``kp.domain.DETAIL_NAMES``: document_type, domain, authority, classification,
# content_owner. A missing detail is ``None``.
APPROVAL_STATUS: Final = "approval_status"  # lower-case status word from the sidecar, or None
SIDECAR_PRESENT: Final = "sidecar_present"  # False when the document has no metadata sidecar
RELATIVE_PATH: Final = "relative_path"  # path below the source root, "/" separated

# Confluence-like export.
LABELS: Final = "labels"  # all labels of the page (sorted); also used by the Jira route
REQUIRED_LABEL: Final = "required_label"  # the agreed approval label from the settings
HAS_REQUIRED_LABEL: Final = "has_required_label"  # False means: record as pending, do not load
WORKFLOW_STATE: Final = "state"  # always "published": a draft never surfaces (the gate's key)
SPACE: Final = "space"
PAGE_VERSION: Final = "page_version"  # integer version number of the listed version

# Jira-like export.
STATUS: Final = "status"  # board status; deliberately outside the story fingerprint
PARENT_KEY: Final = "parent_key"
LINKS: Final = "links"  # list of {"link_type": ..., "target_key": ...}
DOMAIN: Final = "domain"  # from a ``domain:<name>`` label, or None
STORY_FINGERPRINT: Final = "story_fingerprint"  # ``Story.fingerprint()``; excludes status
PROJECT: Final = "project"

# Regulatory repository (one manifest per edition directory).
EDITION_LABEL: Final = "edition_label"
EFFECTIVE_DATE: Final = "effective_date"  # ISO date
MERGED: Final = "merged"  # only merged editions are ever listed, so always True when seen
SUPERSEDED_FROM: Final = "superseded_from"  # ISO date or None
WITHDRAWN_FROM: Final = "withdrawn_from"  # ISO date or None
DOCUMENT: Final = "document"  # document name inside the edition (file stem)
FORMATS: Final = "formats"  # file suffixes available for the document in this edition

# Code repository tree.
CONTENT_SHA256: Final = "content_sha256"  # full SHA-256 of the file, lower-case hex
FILE_KIND: Final = "file_kind"  # "code", "test", "schema", "doc" or "other"
LANGUAGE: Final = "language"  # from the file suffix, or None
SIZE_BYTES: Final = "size_bytes"
