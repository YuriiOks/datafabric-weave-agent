"""Shared fixtures: local settings, an in-memory database with the schema, a fixed clock."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from pydantic import SecretStr
from sqlalchemy import Engine

from kp.clock import FixedClock
from kp.config import Mode, Settings
from kp.store import IN_MEMORY_SQLITE, Database, create_all, create_engine_for_url
from kp.testing.dataset import SyntheticDataset
from kp.testing.synthetic import generate
from world_support import World, build_world

FIXED_NOW = datetime(2026, 11, 1, 9, 30, tzinfo=UTC)


@pytest.fixture
def local_settings() -> Settings:
    """Settings for local mode on in-memory SQLite, independent of the process environment."""
    return Settings(_env_file=None, mode=Mode.LOCAL, database_url=SecretStr(IN_MEMORY_SQLITE))


@pytest.fixture
def engine() -> Iterator[Engine]:
    """An in-memory SQLite engine with the full schema created."""
    engine = create_engine_for_url(IN_MEMORY_SQLITE)
    create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture
def database(engine: Engine) -> Database:
    """A :class:`Database` around the in-memory engine."""
    return Database(engine)


@pytest.fixture
def fixed_clock() -> FixedClock:
    """A clock fixed at 1 Nov 2026, 09:30 UTC."""
    return FixedClock(FIXED_NOW)


@pytest.fixture(scope="session")
def dataset(tmp_path_factory: pytest.TempPathFactory) -> SyntheticDataset:
    """A freshly generated synthetic dataset (session-scoped; treat as read-only)."""
    return generate(tmp_path_factory.mktemp("synthetic"))


@pytest.fixture(scope="session")
def committed_fixtures_dir() -> Path:
    """The committed ``fixtures/generated`` directory."""
    return Path(__file__).resolve().parent.parent / "fixtures" / "generated"


@pytest.fixture(scope="session")
def built_world(
    committed_fixtures_dir: Path, tmp_path_factory: pytest.TempPathFactory
) -> Iterator[World]:
    """The whole platform built once on the committed data (read-mostly; do not publish)."""
    world = build_world(committed_fixtures_dir, tmp_path_factory.mktemp("world"))
    yield world
    world.application.close()
