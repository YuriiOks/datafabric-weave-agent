# Fix loop brake, decision journal, error log (for /km-build)

These extend the attempt counting and the Plan changes part of the build file. They add no
second counter and no second log.

## 1 Fix loop brake
A fix iteration is one builder pass after a failed check, a failed km-test run or a proven
finding, followed by levels 1 and 2 again. The existing limit stays: at most 3 attempts per
slice, every builder pass counting. The brake adds:
- Ceiling. No slice gets more than 5 fix-and-recheck iterations, counting builder passes and
  km-test reruns together. The 3-attempt limit normally binds first; the ceiling covers a
  slice that keeps bouncing between builder and km-test.
- Same failure twice. Compare each failed pass with the one before it: the same failing
  command and the same first error line or path:line. Two in a row is "stuck the same way".
  Stop sending that slice to a builder. If advisor calls remain, make the trigger C call (it
  is the one allowed exception, and gives the single third attempt, after advice). If not, or
  if the attempt after advice fails again, mark the slice blocked and write the stuck report.
- Tests are not bent. A builder or km-test never weakens, skips, deletes or loosens a test,
  assertion or check to make it pass, and never suppresses an error. After every pass, look
  at the diff of test files in the slice: a removed assertion, a new skip or expected-failure
  marker, a widened tolerance or a deleted test that the plan did not name is a failed
  attempt; send it back with the original failure. If the test itself is wrong, the builder
  says so with path:line evidence and stops; the decision goes to the journal (section 2).
- Stuck report. Under "Stuck" in the build file, one block per blocked slice: slice and
  attempts; per attempt one line on what was tried and how it failed; the last 15 lines of
  the failing output (no secrets); a hypothesis for the cause; the concrete ask to the owner.
  Honest and short. Never mark a stuck slice as passed or as partly done.

## 2 Decision journal
The build file keeps one journal, in the existing "Plan changes" part, newest entry first. It
holds only non-trivial choices: a spec that is silent on a contract, plan and code in
conflict, a feature skipped because of a blocker, a changed data shape, a choice between
libraries, a workaround for a defect elsewhere, a test judged wrong. Not names, formatting or
following an existing pattern. Entry:
```
<time> <kind> <slice>: <one line>
  Context: <why it came up>   Decision: <what was done or what is asked>
  Why: <reason>   Alternatives: <what else was possible>   Files: <paths>
```
Kinds: question (unresolved), decision, deviation (from the plan), trade-off. Contract
changes recorded here keep their old text: Plan changes lines are never deleted. Builders
report such choices under "decisions" in their reply; the orchestrator writes the entry.
A question still open at the end is copied to "Open for owner".

## 3 Error log: kb/errors.md
- Read it before fixing a bug and before any retry: search it for the symptom words and the
  failing command. Paste matching entries into the builder task under "known failures".
- Append an entry only when a slice needed more than 2 attempts, or when the first
  instinct was wrong and cost an attempt. Not for typos or one-pass fixes. The orchestrator
  writes it when the slice is committed or blocked. If an entry for the same cause exists,
  update it instead. Do not log what a rule already says. No secrets, no customer data.
- Format: kb/errors.md follows the kb file rules (title line, Date:, Task:, Status: lines,
  at most 150 lines of at most 100 characters). Newest entry first, fields not bullets:
```
### <date> <short title>
Symptom: <what was seen, the failing command>
Cause: <label: Observed with path:line, or Unverified>
Fix: <what worked, or "none yet" for a blocked slice>
Recognise: <how to tell it early next time>
```
- When the file passes 120 lines, move the oldest entries to kb/errors-<n>.md (n counting
  up) and keep a pointer line at the end of kb/errors.md. Never delete entries.
- First time only: create the file with its header and add one line to kb/index.d/<run>.txt
  (path, summary, date); later appends need no index change. Run kb-lint.sh after writing.
