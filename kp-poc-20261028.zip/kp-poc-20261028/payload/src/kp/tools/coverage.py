"""The ``coverage`` tool: rules with and without tests, and stories with no basis."""

from __future__ import annotations

from datetime import date
from typing import Annotated

from pydantic import Field

from kp.domain import DomainModel
from kp.tools.access import ToolContext
from kp.tools.ports import CoveragePort, RuleCoverage, StoryGap
from kp.tools.registry import RegisteredTool, ToolArguments, ToolOutcome, define_tool

NAME = "coverage"
DEFAULT_LIMIT = 100
MAX_LIMIT = 500


class CoverageArguments(ToolArguments):
    """Arguments of ``coverage``. There is deliberately no domain argument."""

    as_at: Annotated[
        date | None, Field(description="Read the rules as at this date; default is today")
    ] = None
    limit: Annotated[
        int, Field(ge=1, le=MAX_LIMIT, description="Maximum entries per list (rules, gaps)")
    ] = DEFAULT_LIMIT
    offset: Annotated[int, Field(ge=0, description="Entries to skip at the start of each list")] = 0


class CoverageOutput(DomainModel):
    """The ``coverage`` result, in the port's order.

    Each list is cut to the requested page; the ``total_*`` fields count every visible entry
    and ``truncated`` says whether any list has more than it shows. ``stated_links`` and
    ``guessed_links`` count the links underlying all visible rules, not just the page.
    """

    as_at: date
    rules_with_tests: tuple[RuleCoverage, ...]
    rules_without_tests: tuple[RuleCoverage, ...]
    stories_without_basis: tuple[StoryGap, ...]
    total_rules_with_tests: int
    total_rules_without_tests: int
    total_stories_without_basis: int
    truncated: bool
    stated_links: int
    guessed_links: int
    filtered_out: int


def coverage_tool(coverage: CoveragePort) -> RegisteredTool:
    """Build the ``coverage`` tool.

    :param coverage: Coverage queries
    :return: The registrable tool
    """

    def handle(context: ToolContext, arguments: CoverageArguments) -> ToolOutcome:
        as_at = arguments.as_at or context.clock.today()
        snapshot = coverage.snapshot(domains=context.domains, as_at=as_at)
        rules, hidden_rules = context.split_visible(snapshot.rules, lambda rule: rule.domain)
        gaps, hidden_gaps = context.split_visible(snapshot.story_gaps, lambda gap: gap.domain)
        filtered_out = snapshot.filtered_out + hidden_rules + hidden_gaps
        tested = [rule for rule in rules if rule.has_test]
        untested = [rule for rule in rules if not rule.has_test]
        stop = arguments.offset + arguments.limit
        page = slice(arguments.offset, stop)
        output = CoverageOutput(
            as_at=as_at,
            rules_with_tests=tuple(tested[page]),
            rules_without_tests=tuple(untested[page]),
            stories_without_basis=tuple(gaps[page]),
            total_rules_with_tests=len(tested),
            total_rules_without_tests=len(untested),
            total_stories_without_basis=len(gaps),
            truncated=any(len(entries) > stop for entries in (tested, untested, gaps)),
            stated_links=sum(rule.stated_links for rule in rules),
            guessed_links=sum(rule.guessed_links for rule in rules),
            filtered_out=filtered_out,
        )
        return ToolOutcome(
            payload=output.model_dump(mode="json"),
            items_returned=(
                len(output.rules_with_tests)
                + len(output.rules_without_tests)
                + len(output.stories_without_basis)
            ),
            filtered_count=filtered_out,
        )

    return define_tool(
        NAME,
        "Coverage of the rules in force: rules with and without a linked test (with linked "
        "story counts and the stated versus guessed link split), and stories that have no "
        "requirement or clause behind them. Lists are paged with limit and offset; the totals "
        "and a truncated flag say when more exist.",
        CoverageArguments,
        handle,
    )
