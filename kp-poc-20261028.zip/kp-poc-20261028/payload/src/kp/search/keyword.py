"""Okapi BM25 over an in-memory set of documents, implemented in Python.

The index is built from the candidates that already passed every filter, so document
frequencies and the average length describe exactly what can be returned.
"""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from collections.abc import Sequence
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Bm25Parameters:
    """BM25 tuning constants.

    :ivar k1: Term-frequency saturation
    :ivar b: Strength of document-length normalisation
    """

    k1: float = 1.2
    b: float = 0.75


class Bm25Index:
    """A BM25 index.

    :param documents: ``(document id, analysed terms)`` pairs
    :param parameters: Tuning constants
    """

    def __init__(
        self,
        documents: Sequence[tuple[str, Sequence[str]]],
        parameters: Bm25Parameters | None = None,
    ) -> None:
        self._parameters = parameters or Bm25Parameters()
        self._lengths: dict[str, int] = {}
        self._postings: dict[str, dict[str, int]] = defaultdict(dict)
        for document_id, terms in documents:
            self._lengths[document_id] = len(terms)
            for term, frequency in Counter(terms).items():
                self._postings[term][document_id] = frequency
        total = sum(self._lengths.values())
        self._average_length = total / len(self._lengths) if self._lengths else 0.0

    def __len__(self) -> int:
        return len(self._lengths)

    def search(self, query_terms: Sequence[str], limit: int) -> list[tuple[str, float]]:
        """Rank documents against a query.

        :param query_terms: Analysed query terms; repeats count once
        :param limit: Maximum number of results
        :return: ``(document id, score)`` best first, ties broken by id; documents sharing no
            term with the query are not returned
        """
        scores: dict[str, float] = defaultdict(float)
        for term in set(query_terms):
            postings = self._postings.get(term)
            if not postings:
                continue
            idf = self._idf(len(postings))
            for document_id, frequency in postings.items():
                scores[document_id] += idf * self._saturation(frequency, self._lengths[document_id])
        ranked = sorted(scores.items(), key=lambda item: (-item[1], item[0]))
        return ranked[:limit]

    def _idf(self, document_frequency: int) -> float:
        count = len(self._lengths)
        return math.log(1 + (count - document_frequency + 0.5) / (document_frequency + 0.5))

    def _saturation(self, frequency: int, length: int) -> float:
        k1, b = self._parameters.k1, self._parameters.b
        norm = 1 - b + b * length / self._average_length if self._average_length else 1.0
        return frequency * (k1 + 1) / (frequency + k1 * norm)
