"""Persistence of the connectivity job: ``run``, ``source_item`` and ``mcp_call`` rows.

Follows the repository convention: a small class that takes a Connection from
``Database.transaction()``. ``source_item`` rows are written once. The one exception is the
extraction outcome of a row written as ``pending`` (a run that skipped extraction, or no
extractor wired): :meth:`ConnectivityStore.complete_extraction` fills in exactly the
extraction columns, once, and touches nothing else.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Iterable, Sequence
from datetime import datetime

from sqlalchemy import Connection, RowMapping, insert, select, update

from kp.connectivity.models import CallObservation
from kp.domain import (
    ApprovalState,
    DocumentDetails,
    ExtractionStatus,
    McpCallRecord,
    Run,
    RunKind,
    RunOutcome,
    SourceItemVersion,
    SourceKind,
)
from kp.store import Database
from kp.store.schema import mcp_call, run, source_item

logger = logging.getLogger(__name__)


class ConnectivityStore:
    """Reads and writes the connectivity rows on one connection.

    :param connection: An open connection, normally inside ``Database.transaction()``
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def begin_run(self, record: Run) -> None:
        """Insert the run row.

        :param record: The run, outcome ``running``
        """
        self._connection.execute(
            insert(run).values(
                run_id=record.run_id,
                kind=record.kind.value,
                sources=[source.value for source in record.sources],
                started_at=record.started_at,
                ended_at=None,
                outcome=record.outcome.value,
                items_touched=record.items_touched,
            )
        )

    def finish_run(
        self, run_id: str, *, ended_at: datetime, outcome: RunOutcome, items_touched: int
    ) -> None:
        """Close a run.

        :param run_id: The run to close
        :param ended_at: When it ended
        :param outcome: How it ended
        :param items_touched: How many item versions it stored or completed
        """
        self._connection.execute(
            update(run)
            .where(run.c.run_id == run_id)
            .values(ended_at=ended_at, outcome=outcome.value, items_touched=items_touched)
        )

    def extraction_status_of(
        self, source: SourceKind, item_id: str, version: str
    ) -> ExtractionStatus | None:
        """Look up the extraction state of one recorded item version.

        :param source: The source
        :param item_id: The item id
        :param version: The version token
        :return: The recorded extraction status, or ``None`` when the version is not recorded
        """
        statement = select(source_item.c.extraction_status).where(
            source_item.c.source == source.value,
            source_item.c.item_id == item_id,
            source_item.c.version == version,
        )
        value = self._connection.execute(statement).scalar_one_or_none()
        return None if value is None else ExtractionStatus(value)

    def complete_extraction(
        self,
        source: SourceKind,
        item_id: str,
        version: str,
        *,
        status: ExtractionStatus,
        failure: str | None,
        markdown_location: str | None,
        manifest_location: str | None,
        extractor_version: str | None,
    ) -> bool:
        """Record the extraction outcome of a version that was stored with extraction pending.

        Only the five extraction columns are written, and only while the row is still
        ``pending``; every other column stays as first written.

        :param source: The source
        :param item_id: The item id
        :param version: The version token
        :param status: The outcome, ``succeeded`` or ``failed``
        :param failure: Why extraction failed, if it did
        :param markdown_location: Where the Markdown is
        :param manifest_location: Where the manifest is
        :param extractor_version: The version the service reported
        :return: True when a pending row was completed, False when there was none
        """
        result = self._connection.execute(
            update(source_item)
            .where(
                source_item.c.source == source.value,
                source_item.c.item_id == item_id,
                source_item.c.version == version,
                source_item.c.extraction_status == ExtractionStatus.PENDING.value,
            )
            .values(
                extraction_status=status.value,
                extraction_failure=failure,
                markdown_location=markdown_location,
                manifest_location=manifest_location,
                extractor_version=extractor_version,
            )
        )
        return result.rowcount == 1

    def insert_item(self, item: SourceItemVersion) -> None:
        """Insert one complete item version.

        Its content columns are never updated afterwards; see :meth:`complete_extraction` for
        the one permitted change.

        :param item: The version to record
        """
        self._connection.execute(
            insert(source_item).values(
                source=item.source.value,
                item_id=item.item_id,
                version=item.version,
                native_id=item.native_id,
                content_sha256=item.content_sha256,
                media_type=item.media_type,
                title=item.title,
                author=item.author,
                modified_at=item.modified_at,
                raw_location=item.raw_location,
                markdown_location=item.markdown_location,
                fetched_at=item.fetched_at,
                run_id=item.run_id,
                attachment_parent=item.attachment_parent,
                extraction_status=item.extraction_status.value,
                extraction_failure=item.extraction_failure,
                manifest_location=item.manifest_location,
                extractor_version=item.extractor_version,
                approval_state=item.approval_state.value,
                document_type=item.details.document_type,
                domain=item.details.domain,
                authority=item.details.authority,
                classification=item.details.classification,
                content_owner=item.details.content_owner,
                machine_authored=item.machine_authored,
            )
        )

    def items(self, sources: Iterable[SourceKind]) -> tuple[SourceItemVersion, ...]:
        """Read the stored item versions of some sources, in key order.

        :param sources: Which sources
        :return: The versions
        """
        statement = (
            select(source_item)
            .where(source_item.c.source.in_([source.value for source in sources]))
            .order_by(source_item.c.source, source_item.c.item_id, source_item.c.version)
        )
        return tuple(_item_from_row(row._mapping) for row in self._connection.execute(statement))

    def insert_call(self, call: McpCallRecord) -> None:
        """Insert one call record. It holds a request digest, never the request.

        :param call: The call to record
        """
        self._connection.execute(
            insert(mcp_call).values(
                call_id=call.call_id,
                run_id=call.run_id,
                tool=call.tool,
                operation=call.operation,
                request_digest=call.request_digest,
                http_status=call.http_status,
                error_class=call.error_class,
                object_count=call.object_count,
                truncated=call.truncated,
                latency_ms=call.latency_ms,
                token_refreshed=call.token_refreshed,
                surviving_fields=list(call.surviving_fields),
                called_at=call.called_at,
            )
        )

    def calls(self, run_ids: Sequence[str]) -> tuple[McpCallRecord, ...]:
        """Read the call records of some runs, oldest first.

        :param run_ids: Which runs
        :return: The records
        """
        statement = (
            select(mcp_call)
            .where(mcp_call.c.run_id.in_(list(run_ids)))
            .order_by(mcp_call.c.called_at, mcp_call.c.call_id)
        )
        return tuple(_call_from_row(row._mapping) for row in self._connection.execute(statement))


class RunCallRecorder:
    """Call sink that writes each observation as an ``mcp_call`` row of the current run.

    Each record is its own short transaction, so evidence survives a run that stops early.

    :param database: Where to write
    """

    def __init__(self, database: Database) -> None:
        self._database = database
        self._lock = threading.Lock()
        self._run_id: str | None = None
        self._sequence = 0

    def start(self, run_id: str) -> None:
        """Attribute the following observations to ``run_id``.

        :param run_id: A run whose row already exists
        """
        with self._lock:
            self._run_id = run_id
            self._sequence = 0

    def stop(self) -> None:
        """Stop attributing observations to a run."""
        with self._lock:
            self._run_id = None

    def record(self, observation: CallObservation) -> None:
        """Write an observation as a call row.

        The observation is dropped, with a debug log, when no run is active: the same client
        also serves callers outside a connectivity run (for example a sweep over the adapters).

        :param observation: What was observed about one exchange
        """
        with self._lock:
            if self._run_id is None:
                logger.debug("Gateway call not recorded: no connectivity run is active")
                return
            self._sequence += 1
            call = McpCallRecord(
                call_id=f"{self._run_id}-{self._sequence:05d}",
                run_id=self._run_id,
                **observation.model_dump(),
            )
        with self._database.transaction() as connection:
            ConnectivityStore(connection).insert_call(call)


def _item_from_row(row: RowMapping) -> SourceItemVersion:
    return SourceItemVersion(
        source=SourceKind(row["source"]),
        item_id=row["item_id"],
        version=row["version"],
        native_id=row["native_id"],
        content_sha256=row["content_sha256"],
        media_type=row["media_type"],
        title=row["title"],
        author=row["author"],
        modified_at=row["modified_at"],
        raw_location=row["raw_location"],
        markdown_location=row["markdown_location"],
        fetched_at=row["fetched_at"],
        run_id=row["run_id"],
        attachment_parent=row["attachment_parent"],
        extraction_status=ExtractionStatus(row["extraction_status"]),
        extraction_failure=row["extraction_failure"],
        manifest_location=row["manifest_location"],
        extractor_version=row["extractor_version"],
        approval_state=ApprovalState(row["approval_state"]),
        effective_date=row["effective_date"],
        details=DocumentDetails(
            document_type=row["document_type"],
            domain=row["domain"],
            authority=row["authority"],
            classification=row["classification"],
            content_owner=row["content_owner"],
        ),
        machine_authored=bool(row["machine_authored"]),
    )


def _call_from_row(row: RowMapping) -> McpCallRecord:
    return McpCallRecord(
        call_id=row["call_id"],
        run_id=row["run_id"],
        tool=row["tool"],
        operation=row["operation"],
        request_digest=row["request_digest"],
        http_status=row["http_status"],
        error_class=row["error_class"],
        object_count=row["object_count"],
        truncated=bool(row["truncated"]),
        latency_ms=row["latency_ms"],
        token_refreshed=bool(row["token_refreshed"]),
        surviving_fields=tuple(row["surviving_fields"] or ()),
        called_at=row["called_at"],
    )


def new_run(run_id: str, started_at: datetime, sources: tuple[SourceKind, ...]) -> Run:
    """Build the :class:`~kp.domain.Run` of a connectivity run.

    :param run_id: The run id
    :param started_at: When it started
    :param sources: Which sources it touches
    :return: A running run
    """
    return Run(run_id=run_id, kind=RunKind.CONNECTIVITY, sources=sources, started_at=started_at)
