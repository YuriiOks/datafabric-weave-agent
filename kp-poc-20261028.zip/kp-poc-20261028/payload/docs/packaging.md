# Building the workstation package

`scripts/build_bank_package.py` turns the project into one zip that is installed on the
workstation with `install.py`. It never uploads anything.

```bash
.venv/bin/python scripts/build_bank_package.py --patterns <path-to-local-patterns-file>
```

Options: `--out-root DIR` (default: the folder `build` next to the project), `--date YYYYMMDD`
(default: today), `--project-root DIR`, `--allow-url-host DOMAIN` and `--allow-email-domain
DOMAIN` (both repeatable, see below).

### Scrub exceptions of the synthetic data

The scrub is strict by default. The synthetic stand-ins in `src` and `tests` use three kinds of
fictional address, so a build of the whole tree names them as explicit exceptions:

```bash
.venv/bin/python scripts/build_bank_package.py --patterns <path-to-local-patterns-file> \
    --allow-url-host invalid --allow-url-host stand-in \
    --allow-url-host schemas.openxmlformats.org --allow-email-domain machine.invalid
```

| Exception | What it covers |
|---|---|
| `invalid` | Hosts under the reserved `.invalid` top level used by the write-back tests |
| `stand-in` | Hosts of the fictional stand-in gateway and extraction service |
| `schemas.openxmlformats.org` | The public namespace string inside generated office documents |
| `machine.invalid` (email) | The author address of machine-written specs |

The build prints a `NOTE scrub exception` line for each. Replacing those addresses with
`example.com` ones in the code makes the exceptions unnecessary.

## What goes in

`src`, `tests`, `fixtures`, `scripts`, `docs`, `pyproject.toml`, `README.md`, `ARCHITECTURE.md`,
`INSTALL-WORKSTATION.md`, `.env.example` and `.gitignore` (a test reads it). Left out: virtual
environments, caches, `.git`, the requirements document, build output, databases and every `.env`
file except `.env.example`.

## What the zip holds

```
kp-poc-<YYYYMMDD>/
    install.py          standard library only
    README-PACKAGE.txt  apply order and the output to expect
    SHA256SUMS          over every other file
    payload/            the project tree
```

The zip is reproducible: the same tree and date give the same bytes.

## The scrub

Run before anything is written. A finding stops the build, no file or zip is written, and the
report names `path:line: rule` only, never the matched text.

| Rule | Meaning |
|---|---|
| `non-ascii` | A byte above 127 in a text file |
| `bank-host-pattern`, `staff-id-pattern` | A match of the `bank_hosts` or `staff_ids` expressions in the local patterns file |
| `url-not-allowed` | An `http` or `https` address other than localhost, 127.0.0.1, example.com and example.org |
| `email-not-allowed` | An email address other than `@example.com` |
| `secret-shaped:*` | A token, key or private-key shape |

The patterns file is read from the path given on the command line. It is never copied into the
package, and the build fails if it is missing, unreadable, or lacks either list.

## On the workstation

1. `unzip`, then `sha256sum -c SHA256SUMS`.
2. `python3 install.py --inspect --target DIR` and compare it with `README-PACKAGE.txt`.
3. `python3 install.py --target DIR`, then follow `INSTALL-WORKSTATION.md`.
