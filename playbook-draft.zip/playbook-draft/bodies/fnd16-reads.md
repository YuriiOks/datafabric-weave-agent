## What changed

The bounded publication read is mounted at `POST /api/recsys/publication/reads`, behind an implemented read policy. A caller names seed components, relations and budgets; the scope comes from configuration and the principal from the session, never from the request. Each page returns the authorised nodes and edges of the scope's active publication, and a budget that runs out returns its page flagged with that budget.

In pre-production the policy is an explicit reader allow-list (`RECSYS_PUBLICATION_READERS`) standing in for the entitlement service: a listed reader sees the scope's components and the traversable relations, anyone else sees nothing. It is off unless `RECSYS_PUBLICATION_READS_ENABLED` is set, and refused when the refresh environment is production.

Blocker B6 leaves the checklist.

## Why

The read path existed but nothing served it, so no reader could see an activated publication, and every checklist row about reads, revocation and graph outages was blocked.

## How to verify

1. Unit tests: `tests/recsys/publication/test_preproduction_read_policy.py` and the route tests in `tests/recsys/publication/`.
2. With reads on and the caller listed, read from a seed: the page lists the reachable components and relations of the active publication.
3. Remove the caller from the list and restart, then resume with the cursor: the read is refused as a policy change (403 `policy_changed`).
4. Negative case: reads off, the caller not listed, or the refresh environment set to production. Each is refused before the graph is touched (503 or 403).
5. Stop the graph: the read answers 503 `graph_unavailable`, distinct from a timeout (`budget_exhausted:duration`) and from an empty but complete answer (200).

## Not in this PR

- The registry pages and the recommendation panel still read through the registry read scope, which stays refused on `main`.
- The entitlement service; production stays refused.

## Review focus

- The route is added to the recsys router route by route, not with `include_router`, so the hub's startup file is untouched, the route inherits that router's authentication, and it shows in `router.routes` as a plain route on any FastAPI release. The registered-paths test now lists nine paths.
- The policy revision is a digest of the scope and the reader list, so a list change invalidates open cursors.
