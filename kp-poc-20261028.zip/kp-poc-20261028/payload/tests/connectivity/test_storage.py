"""US-25: raw storage is immutable by key; the bucket implementation loads its client lazily."""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from kp.connectivity import (
    BucketClientUnavailableError,
    BucketObjectStore,
    ImmutableObjectError,
    InvalidObjectKeyError,
    LocalObjectStore,
    PutOutcome,
    object_key,
)
from kp.connectivity.storage import BucketClient, GcsBucketClient, default_bucket_client


def test_us25_local_store_writes_once_and_reads_back(tmp_path: Path) -> None:
    store = LocalObjectStore(tmp_path)
    key = object_key("jira", "item-1", "abc123")

    assert store.put_if_absent(key, b"first") is PutOutcome.CREATED
    assert store.get(key) == b"first"
    assert store.exists(key)
    assert key == "jira/item-1/abc123"


def test_us25_writing_the_same_bytes_again_is_a_no_op(tmp_path: Path) -> None:
    store = LocalObjectStore(tmp_path)
    store.put_if_absent("a/b/1", b"same")
    modified = (tmp_path / "a" / "b" / "1").stat().st_mtime_ns

    assert store.put_if_absent("a/b/1", b"same") is PutOutcome.EXISTING
    assert (tmp_path / "a" / "b" / "1").stat().st_mtime_ns == modified


def test_us25_existing_object_is_never_overwritten(tmp_path: Path) -> None:
    store = LocalObjectStore(tmp_path)
    store.put_if_absent("a/b/1", b"original")

    with pytest.raises(ImmutableObjectError):
        store.put_if_absent("a/b/1", b"replacement")

    assert store.get("a/b/1") == b"original"


def test_us25_no_partial_files_are_left_behind(tmp_path: Path) -> None:
    store = LocalObjectStore(tmp_path)
    store.put_if_absent("a/b/1", b"x")
    with pytest.raises(ImmutableObjectError):
        store.put_if_absent("a/b/1", b"y")

    assert [p.name for p in (tmp_path / "a" / "b").iterdir()] == ["1"]


def test_us25_missing_object_raises_key_error(tmp_path: Path) -> None:
    store = LocalObjectStore(tmp_path)

    assert not store.exists("a/b/1")
    with pytest.raises(KeyError):
        store.get("a/b/1")


@pytest.mark.parametrize(
    "key", ["", "/abs", "a/../b", "a//b", "a/./b", "a\\b", "x" * 600, "a/\x00"]
)
def test_us25_unsafe_keys_are_rejected(tmp_path: Path, key: str) -> None:
    with pytest.raises(InvalidObjectKeyError):
        LocalObjectStore(tmp_path).put_if_absent(key, b"x")


def test_us25_location_and_key_round_trip(tmp_path: Path) -> None:
    store = LocalObjectStore(tmp_path)

    assert store.key_of(store.location("a/b/1")) == "a/b/1"
    with pytest.raises(InvalidObjectKeyError):
        store.key_of("bucket:other/a")


class _MissingKey(Exception):  # noqa: N818 - mirrors the client library's error shape
    def __init__(self) -> None:
        super().__init__("no such key")
        self.response = {"Error": {"Code": "NoSuchKey"}}


class _PreconditionFailed(Exception):  # noqa: N818 - mirrors the client library's error shape
    def __init__(self) -> None:
        super().__init__("key exists")
        self.response = {"Error": {"Code": "PreconditionFailed"}}


class _Body:
    def __init__(self, data: bytes) -> None:
        self._data = data

    def read(self) -> bytes:
        return self._data


class FakeBucketClient:
    def __init__(self) -> None:
        self.objects: dict[tuple[str, str], bytes] = {}
        self.writes = 0

    def put_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
        Body: bytes,  # noqa: N803 - same
        IfNoneMatch: str,  # noqa: N803 - same
    ) -> object:
        assert IfNoneMatch == "*"
        if (Bucket, Key) in self.objects:
            raise _PreconditionFailed
        self.objects[(Bucket, Key)] = Body
        self.writes += 1
        return {}

    def get_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
    ) -> dict[str, Any]:
        if (Bucket, Key) not in self.objects:
            raise _MissingKey
        return {"Body": _Body(self.objects[(Bucket, Key)])}


def test_us25_bucket_store_has_the_same_immutability_rule() -> None:
    client = FakeBucketClient()
    store = BucketObjectStore("example-bucket", lambda: client)

    assert store.put_if_absent("a/b/1", b"one") is PutOutcome.CREATED
    assert store.put_if_absent("a/b/1", b"one") is PutOutcome.EXISTING
    with pytest.raises(ImmutableObjectError):
        store.put_if_absent("a/b/1", b"two")
    assert client.writes == 1
    assert store.get("a/b/1") == b"one"
    assert store.exists("a/b/1")
    assert not store.exists("a/b/2")
    with pytest.raises(KeyError):
        store.get("a/b/2")


def test_us25_bucket_store_references_round_trip() -> None:
    store = BucketObjectStore("example-bucket", FakeBucketClient)

    assert store.key_of(store.location("a/b/1")) == "a/b/1"
    with pytest.raises(InvalidObjectKeyError):
        BucketObjectStore("other", FakeBucketClient).key_of(store.location("a/b/1"))


def test_us25_bucket_client_is_created_only_when_first_used() -> None:
    created: list[BucketClient] = []

    def factory() -> BucketClient:
        created.append(FakeBucketClient())
        return created[-1]

    store = BucketObjectStore("example-bucket", factory)
    assert created == []
    store.exists("a/b/1")
    store.exists("a/b/2")
    assert len(created) == 1


def test_us25_missing_client_library_is_a_clear_typed_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def refuse(name: str) -> object:
        raise ModuleNotFoundError(name=name)

    monkeypatch.setattr("kp.connectivity.storage.import_module", refuse)

    with pytest.raises(BucketClientUnavailableError, match="not installed"):
        default_bucket_client()
    with pytest.raises(BucketClientUnavailableError):
        BucketObjectStore("example-bucket").put_if_absent("a/b/1", b"x")


def test_us25_importing_the_package_does_not_import_the_bucket_library() -> None:
    assert "boto3" not in sys.modules
    assert "google.cloud.storage" not in sys.modules


class _GcsError(Exception):
    """The shape of the Cloud Storage library's errors: an HTTP status in ``code``."""

    def __init__(self, code: int) -> None:
        super().__init__(code)
        self.code = code


class _FakeGcsBlob:
    def __init__(self, objects: dict[tuple[str, str], bytes], bucket: str, name: str) -> None:
        self._objects = objects
        self._key = (bucket, name)

    def upload_from_string(self, data: bytes, *, if_generation_match: int | None) -> None:
        if if_generation_match == 0 and self._key in self._objects:
            raise _GcsError(412)
        self._objects[self._key] = data

    def download_as_bytes(self) -> bytes:
        if self._key not in self._objects:
            raise _GcsError(404)
        return self._objects[self._key]


class _FakeGcsBucket:
    def __init__(self, objects: dict[tuple[str, str], bytes], name: str) -> None:
        self._objects = objects
        self._name = name

    def blob(self, name: str) -> _FakeGcsBlob:
        return _FakeGcsBlob(self._objects, self._name, name)


class FakeGcsClient:
    """An in-memory stand-in for the Cloud Storage client."""

    def __init__(self) -> None:
        self.objects: dict[tuple[str, str], bytes] = {}

    def bucket(self, name: str) -> _FakeGcsBucket:
        return _FakeGcsBucket(self.objects, name)


def test_us25_cloud_storage_client_keeps_the_immutability_rule() -> None:
    gcs = FakeGcsClient()
    store = BucketObjectStore("example-bucket", lambda: GcsBucketClient(gcs))

    assert store.put_if_absent("a/b/1", b"one") is PutOutcome.CREATED
    assert store.put_if_absent("a/b/1", b"one") is PutOutcome.EXISTING
    with pytest.raises(ImmutableObjectError):
        store.put_if_absent("a/b/1", b"other")
    assert gcs.objects[("example-bucket", "a/b/1")] == b"one"
    assert store.get("a/b/1") == b"one"
    with pytest.raises(KeyError):
        store.get("a/b/2")


def test_us25_cloud_storage_write_is_conditional_so_a_racing_writer_is_never_overwritten() -> None:
    gcs = FakeGcsClient()
    client = GcsBucketClient(gcs)
    client.put_object(Bucket="example-bucket", Key="a/b/1", Body=b"winner", IfNoneMatch="*")

    with pytest.raises(Exception, match="PreconditionFailed"):
        client.put_object(Bucket="example-bucket", Key="a/b/1", Body=b"late", IfNoneMatch="*")
    assert gcs.objects[("example-bucket", "a/b/1")] == b"winner"


def test_us25_other_cloud_storage_failures_pass_through_unchanged() -> None:
    class _Broken(FakeGcsClient):
        def bucket(self, name: str) -> _FakeGcsBucket:
            raise _GcsError(503)

    store = BucketObjectStore("example-bucket", lambda: GcsBucketClient(_Broken()))
    with pytest.raises(_GcsError):
        store.get("a/b/1")


def test_us25_the_native_cloud_storage_library_is_preferred(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    gcs = FakeGcsClient()
    library = SimpleNamespace(Client=lambda: gcs)
    requested: list[str] = []

    def fake_import(name: str) -> object:
        requested.append(name)
        if name == "google.cloud.storage":
            return library
        raise ModuleNotFoundError(name=name)

    monkeypatch.setattr("kp.connectivity.storage.import_module", fake_import)

    client = default_bucket_client()
    assert isinstance(client, GcsBucketClient)
    assert requested == ["google.cloud.storage"]


class _RacingClient(FakeBucketClient):
    """Reports the key as missing once although another writer has just stored it."""

    def __init__(self, winner: bytes) -> None:
        super().__init__()
        self.objects[("example-bucket", "a/b/1")] = winner
        self._hide_once = True

    def get_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
    ) -> dict[str, Any]:
        if self._hide_once:
            self._hide_once = False
            raise _MissingKey
        return super().get_object(Bucket=Bucket, Key=Key)


def test_us25_bucket_store_never_overwrites_a_key_written_between_check_and_write() -> None:
    same = _RacingClient(b"one")
    different = _RacingClient(b"other")

    assert BucketObjectStore("example-bucket", lambda: same).put_if_absent("a/b/1", b"one") is (
        PutOutcome.EXISTING
    )
    with pytest.raises(ImmutableObjectError):
        BucketObjectStore("example-bucket", lambda: different).put_if_absent("a/b/1", b"one")
    assert different.objects[("example-bucket", "a/b/1")] == b"other"
