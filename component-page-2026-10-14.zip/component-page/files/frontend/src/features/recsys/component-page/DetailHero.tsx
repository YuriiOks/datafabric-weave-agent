import type { CSSProperties } from 'react'
import { Link } from 'react-router-dom'
import { COMPONENT_TYPE_SINGULAR } from '../labels'
import { FacetBand } from '../components/FacetBand'
import { TYPE_BADGE_BACKGROUND, idPillStyle, typePillStyle } from '../components/cardStyles'
import type { ComponentPageModel } from './model'
import { mutedStyle } from './styles'

type Props = {
  model: ComponentPageModel
  wide: boolean
  /** Where the back link goes; the registry view the reader came from, when known. */
  backTo: string
  backLabel: string
}

/**
 * The top of the page: the card's facet band with the id and type pills, the name with its last
 * word in brand red, and the version and tenants underneath.
 */
export function DetailHero({ model, wide, backTo, backLabel }: Props) {
  const height = wide ? 90 : 75
  const subline = [model.version ? 'v' + model.version : null, model.tenants.join(', ') || null]
    .filter((part): part is string => part !== null)
    .join(' \u00b7 ')

  return (
    <header style={{ minWidth: 0 }}>
      <Link to={backTo} style={backLinkStyle}>
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
          <path d="M10 3 5 8l5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        {backLabel}
      </Link>
      <div style={heroCardStyle}>
        <div style={{ height, position: 'relative', overflow: 'hidden' }}>
          <FacetBand seed={model.id} type={model.type} width={wide ? 1200 : 420} height={height} />
          <div style={pillRowStyle}>
            <span style={{ ...idPillStyle, maxWidth: wide ? '60%' : 'calc(100% - 96px)' }} title={model.id}>
              {model.id}
            </span>
            <span style={{ ...typePillStyle, background: TYPE_BADGE_BACKGROUND[model.type] }}>
              {COMPONENT_TYPE_SINGULAR[model.type]}
            </span>
          </div>
        </div>
        <div style={{ padding: wide ? 'var(--space-4) var(--space-5)' : 'var(--space-3) var(--space-4)' }}>
          <h1 style={{ ...titleStyle, fontSize: wide ? '1.75rem' : '1.375rem' }}>
            <SplitTitle name={model.name} />
          </h1>
          {subline && <div style={{ ...mutedStyle, fontSize: 'var(--text-sm)', marginTop: 4 }}>{subline}</div>}
        </div>
      </div>
    </header>
  )
}

/** The name with its last word in brand red, as on the Playbook Library pages. */
function SplitTitle({ name }: { name: string }) {
  const trimmed = name.trim()
  const cut = trimmed.lastIndexOf(' ')
  if (cut <= 0) return <>{trimmed}</>
  return (
    <>
      {trimmed.slice(0, cut + 1)}
      <span style={{ color: 'var(--color-primary)' }}>{trimmed.slice(cut + 1)}</span>
    </>
  )
}

const backLinkStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 6,
  fontSize: 'var(--text-sm)',
  color: 'var(--color-text-secondary)',
  textDecoration: 'none',
  marginBottom: 'var(--space-3)',
}

const heroCardStyle: CSSProperties = {
  background: 'var(--color-surface)',
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-lg)',
  overflow: 'hidden',
}

const pillRowStyle: CSSProperties = {
  position: 'absolute',
  top: 10,
  left: 12,
  right: 12,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 12,
}

const titleStyle: CSSProperties = {
  margin: 0,
  fontWeight: 600,
  lineHeight: 1.2,
  color: 'var(--color-text-primary)',
  overflowWrap: 'anywhere',
}
