"""Per-type case-pack profiles: case id prefix, allowed and required scenarios."""

from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.recsys.contracts import ComponentType
from app.recsys.eval.casepack.cases import Scenario
from app.recsys.eval.casepack.lineage import CasePackError, enum_value


class CasePackProfile(BaseModel):
    """What a case pack of one component type may and must contain."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    component_type: ComponentType
    case_prefix: str = Field(pattern=r"^[a-z]{3}$")
    scenarios: frozenset[Scenario]
    required_scenarios: frozenset[Scenario]

    @model_validator(mode="after")
    def _required_are_allowed(self) -> CasePackProfile:
        """Every required scenario is also allowed.

        :return: The profile.
        :raises ValueError: When a required scenario is not allowed.
        """
        if not self.required_scenarios <= self.scenarios:
            raise ValueError("a required scenario must be an allowed scenario")
        return self


#: Skill cases. The required set is the minimum a Skill pack must cover before it can
#: support any quality statement.
SKILL_PROFILE = CasePackProfile(
    component_type=ComponentType.skill,
    case_prefix="skl",
    scenarios=frozenset(
        {
            Scenario.positive,
            Scenario.hard_negative,
            Scenario.valid_empty,
            Scenario.ambiguous,
            Scenario.access_restricted,
            Scenario.incomplete_description,
            Scenario.source_unavailable,
            Scenario.duplicate_alias,
            Scenario.unresolved_dependency,
            Scenario.prerequisite,
        }
    ),
    required_scenarios=frozenset(
        {
            Scenario.positive,
            Scenario.hard_negative,
            Scenario.valid_empty,
            Scenario.access_restricted,
            Scenario.incomplete_description,
            Scenario.source_unavailable,
        }
    ),
)

_PROFILES: Mapping[ComponentType, CasePackProfile] = MappingProxyType(
    {
        ComponentType.skill: SKILL_PROFILE,
    }
)


def profile_for(component_type: ComponentType) -> CasePackProfile:
    """Return the case-pack profile of one component type.

    :param component_type: The type.
    :return: Its profile.
    :raises CasePackError: When the type has no case-pack profile yet.
    """
    try:
        return _PROFILES[component_type]
    except KeyError as error:
        name = enum_value(component_type)
        raise CasePackError(f"no case-pack profile for {name}") from error
