"""Seam: the read tools' search port, backed by the search service.

The domains of a call are applied before ranking (the service filters candidates, not results).
To report how many matches the caller may not see, the same question is also asked without the
domain filter, and the hits of that run outside the caller's domains are counted.
"""

from __future__ import annotations

from datetime import date
from typing import Final

from kp.search import SearchService
from kp.tools import SearchHit, SearchResponse

DEFAULT_DEPTH: Final = 50


class SearchServicePort:
    """Passage search for the agent tools.

    :param service: The search service
    :param depth: How many ranked matches the hidden-match count looks at
    """

    def __init__(self, service: SearchService, *, depth: int = DEFAULT_DEPTH) -> None:
        self._service = service
        self._depth = depth

    def search(
        self, query: str, *, domains: frozenset[str], as_at: date, limit: int
    ) -> SearchResponse:
        """Search passages inside the caller's domains.

        :param query: The question or keywords
        :param domains: Domains the caller may read; passages elsewhere are never ranked
        :param as_at: Only versions in force on this date
        :param limit: Maximum number of hits
        :return: Ranked hits and the number of top matches hidden by ``domains``
        """
        everything = self._service.search(query, as_at=as_at, limit=max(self._depth, limit))
        hidden = sum(1 for hit in everything.hits if hit.domain not in domains)
        if not domains:
            return SearchResponse(filtered_out=hidden)
        allowed = self._service.search(query, as_at=as_at, domains=sorted(domains), limit=limit)
        return SearchResponse(
            hits=tuple(
                SearchHit(
                    passage_id=hit.passage_id,
                    passage_type=hit.passage_type,
                    reference=hit.reference,
                    text=hit.text,
                    page=hit.page,
                    char_start=hit.char_start,
                    char_end=hit.char_end,
                    version=hit.version,
                    domain=hit.domain,
                    score=hit.score,
                )
                for hit in allowed.hits
            ),
            filtered_out=hidden,
        )
