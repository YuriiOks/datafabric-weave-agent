"""Seam: what each agent session was shown by the read tools, kept for the citation check.

The write side flags a rule statement whose citation was not retrieved in the same session. The
read and write servers can be separate processes, so retrievals are recorded in the database:
:class:`RetrievalRecorder` is the read registry's observer, :class:`DatabaseSessionRetrievals`
is the write side's :class:`~kp.writeback.ports.SessionRetrievals`.
"""

from __future__ import annotations

from collections.abc import Mapping
from collections.abc import Set as AbstractSet
from typing import Final

from pydantic import JsonValue
from sqlalchemy import insert, select

from kp.clock import Clock
from kp.store import Database, schema
from kp.tools import Caller, ToolResult
from kp.writeback import canonical_reference

_CITABLE_TYPES: Final = frozenset({"clause", "requirement"})
_MAX_KEY: Final = 255


def session_key(caller: str, session_id: str) -> str:
    """The key a session is remembered under: the caller and the session label together.

    A session label is whatever the client chose, so two callers can name the same one. Keeping
    the caller in the key means one cannot be credited with what the other retrieved.

    :param caller: The authenticated user
    :param session_id: The session label the client sent
    :return: The key, cut to the width of the column
    """
    return f"{caller}/{session_id}"[:_MAX_KEY]


def references_in(payload: Mapping[str, JsonValue]) -> frozenset[str]:
    """Find the clause references and register row ids a tool result shows.

    Search hits, rules and coverage entries carry a ``reference``; link results name the items
    they reach by ``item_type`` and ``key``.

    :param payload: The JSON result of a read tool
    :return: The references in it, as the tool printed them
    """
    found: set[str] = set()
    _collect(dict(payload), found)
    return frozenset(found)


def _collect(node: JsonValue, found: set[str]) -> None:
    if isinstance(node, list):
        for entry in node:
            _collect(entry, found)
        return
    if not isinstance(node, dict):
        return
    reference = node.get("reference")
    if isinstance(reference, str):
        found.add(reference)
    for type_name, key_name in (("item_type", "key"), ("root_type", "root_key")):
        key = node.get(key_name)
        if node.get(type_name) in _CITABLE_TYPES and isinstance(key, str):
            found.add(key)
    for value in node.values():
        _collect(value, found)


class RetrievalRecorder:
    """Records the references of every successful read call under the caller's session.

    :param database: The platform database
    :param clock: Time source for the record
    """

    def __init__(self, database: Database, clock: Clock) -> None:
        self._database = database
        self._clock = clock

    def __call__(self, caller: Caller, tool: str, result: ToolResult) -> None:
        """Remember what a call showed.

        :param caller: The caller, whose session groups the references
        :param tool: The tool that answered
        :param result: Its result
        """
        references = {canonical_reference(reference) for reference in references_in(result.payload)}
        if not references:
            return
        session = session_key(caller.user, caller.session_id)
        with self._database.transaction() as connection:
            known = set(
                connection.execute(
                    select(schema.session_retrieval.c.reference).where(
                        schema.session_retrieval.c.session_id == session
                    )
                ).scalars()
            )
            fresh = sorted(references - known)
            if fresh:
                connection.execute(
                    insert(schema.session_retrieval),
                    [
                        {
                            "session_id": session,
                            "reference": reference,
                            "tool": tool,
                            "retrieved_at": self._clock.now(),
                        }
                        for reference in fresh
                    ],
                )


class DatabaseSessionRetrievals:
    """The write side's view of what a session retrieved.

    :param database: The platform database
    """

    def __init__(self, database: Database) -> None:
        self._database = database

    def references(self, session_id: str, caller: str) -> AbstractSet[str]:
        """List what a session was shown.

        :param session_id: The agent session
        :param caller: The authenticated user the session belongs to
        :return: Canonical references; empty for a session that retrieved nothing
        """
        with self._database.transaction() as connection:
            rows = connection.execute(
                select(schema.session_retrieval.c.reference).where(
                    schema.session_retrieval.c.session_id == session_key(caller, session_id)
                )
            )
            return frozenset(rows.scalars())
