"""Apply the FND-16 change package to a clean worktree. Harness file: never committed.

Usage: python3 apply_fnd16.py <worktree-root> [--check]

Stacks on the FND-14 branch: the refresh integration and its tests must already be
committed there, because the matrix cites those tests as evidence. Copies every file under
./pkg, refusing to overwrite anything. Every check runs before anything is written; one
problem writes nothing.

Branch: feat/fnd-16-*, cut from the committed branch that carries FND-14 (its own
feat/fnd-14-* branch, or feat/agt-02-relations when the two share one pull request).
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / "pkg"
BRANCH_PREFIXES = ("feat/fnd-16",)

#: Files the FND-14 package adds; their absence means this is not the stacked branch.
STACK_FILES: tuple[str, ...] = (
    "backend/app/recsys/refresh/integration/composition.py",
    "backend/app/recsys/refresh/integration/status.py",
    "backend/tests/recsys/refresh/integration_support.py",
)

#: Every test file the matrix cites; the matrix test fails in CI if one is missing.
CITED_TESTS: tuple[str, ...] = (
    "backend/tests/recsys/refresh/test_integration_acquisition_source.py",
    "backend/tests/recsys/refresh/test_integration_authority.py",
    "backend/tests/recsys/refresh/test_integration_status.py",
    "backend/tests/recsys/refresh/test_runtime.py",
)

#: The package must not land on top of an existing qualification package.
FREE_DIRS: tuple[str, ...] = (
    "backend/app/recsys/qualification",
    "backend/tests/recsys/qualification",
)


def _git(root: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 2
    root = Path(argv[0]).resolve()
    check_only = "--check" in argv[1:]
    problems: list[str] = []

    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if not branch.startswith(BRANCH_PREFIXES):
        problems.append(f"branch is {branch}, expected one of {BRANCH_PREFIXES}")
    if _git(root, "status", "--porcelain"):
        problems.append("worktree is not clean")
    for rel in STACK_FILES:
        if not (root / rel).is_file():
            problems.append(f"missing {rel}: apply on the committed FND-14 branch")
    for rel in CITED_TESTS:
        if not (root / rel).is_file():
            problems.append(f"missing cited test {rel}")
    for rel in FREE_DIRS:
        if (root / rel).exists():
            problems.append(f"{rel} already exists")

    new_files: list[tuple[Path, bytes]] = []
    for source in sorted(PKG.rglob("*")):
        if source.is_dir() or "__pycache__" in source.parts:
            continue
        target = root / source.relative_to(PKG)
        if target.exists():
            problems.append(f"new file already exists: {source.relative_to(PKG)}")
        new_files.append((target, source.read_bytes()))
        if target.suffix == ".py":
            try:
                compile(source.read_text(encoding="utf-8"), str(target), "exec")
            except SyntaxError as error:
                problems.append(f"{target.name}: does not compile: {error}")

    if problems:
        print("NOTHING WRITTEN. Problems:")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print(f"OK: {len(new_files)} new files, no edits")
    if check_only:
        return 0
    for target, data in new_files:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    print("written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
