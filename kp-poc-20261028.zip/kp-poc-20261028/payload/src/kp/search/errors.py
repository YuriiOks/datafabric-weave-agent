"""Typed errors of the search package. Every one derives from :class:`kp.errors.KpError`."""

from __future__ import annotations

from datetime import date

from kp.errors import KpError


class SearchError(KpError):
    """Base class of search failures."""


class NoEditionInForceError(SearchError):
    """No edition of the regulatory document applied on the requested date.

    Raised instead of falling back to another edition: reading a rule at a date it was not in
    force would be a silently wrong answer.

    :param as_at: The date that was asked for.
    """

    def __init__(self, as_at: date) -> None:
        super().__init__(f"No edition was in force on {as_at.isoformat()}")
        self.as_at = as_at


class ClauseNotFoundError(SearchError):
    """The requested clause does not exist in a searchable edition."""


class EmbeddingError(SearchError):
    """An embedder returned vectors that do not match the request."""
