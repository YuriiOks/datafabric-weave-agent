"""Run evidence files: one immutable JSON file per run, kept beside the database rows."""

from __future__ import annotations

from pathlib import Path

from kp.connectivity.models import RunResult
from kp.connectivity.storage import LocalObjectStore


def write_run_result(directory: Path, result: RunResult) -> None:
    """Keep the evidence file of a finished run.

    :param directory: The ledger directory
    :param result: The run's evidence
    :raises kp.connectivity.errors.ImmutableObjectError: If the run id was already written
    """
    LocalObjectStore(directory).put_if_absent(
        f"{result.run_id}.json", (result.model_dump_json(indent=2) + "\n").encode("utf-8")
    )


def load_run_results(directory: Path) -> tuple[RunResult, ...]:
    """Read every kept run, oldest first.

    :param directory: The ledger directory; may not exist yet
    :return: The runs ordered by start time
    """
    if not directory.is_dir():
        return ()
    results = [
        RunResult.model_validate_json(path.read_text(encoding="utf-8"))
        for path in directory.glob("*.json")
    ]
    return tuple(sorted(results, key=lambda result: (result.started_at, result.run_id)))
