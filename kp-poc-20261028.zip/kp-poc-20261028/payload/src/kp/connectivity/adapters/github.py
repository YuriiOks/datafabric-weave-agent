"""GitHub adapter. The version token is the blob sha of the file at the pinned commit."""

from __future__ import annotations

from collections.abc import Sequence

from kp.connectivity.adapters.base import (
    GatewayToolAdapter,
    decode_base64,
    dig_text,
    fetched_item,
)
from kp.connectivity.errors import FidelityError
from kp.connectivity.gateway import GatewayClient
from kp.connectivity.models import Route, SampleItem
from kp.sources.base import FetchedItem, ItemMetadata

FILE_TOOL = "get_file"


class GitHubAdapter(GatewayToolAdapter):
    """Reads files, pinned to a commit, through the GitHub tool server.

    :param client: The gateway client
    :param route: The GitHub route
    :param items: The GitHub sample items
    :param file_tool: Name of the file tool
    """

    def __init__(
        self,
        client: GatewayClient,
        route: Route,
        items: Sequence[SampleItem],
        *,
        file_tool: str = FILE_TOOL,
    ) -> None:
        super().__init__(client, route, items)
        self._file_tool = file_tool

    def _fetch_primary(self, item: SampleItem) -> FetchedItem:
        payload = self._call(
            item,
            self._file_tool,
            {
                "repository": item.repository or "",
                "path": item.native_id,
                "ref": item.ref or "",
            },
        )
        if dig_text(item, payload, "encoding") != "base64":
            raise FidelityError(item.source.value, item.item_id, "file content is not base64")
        path = dig_text(item, payload, "path")
        return fetched_item(
            item,
            dig_text(item, payload, "sha"),
            decode_base64(item, payload, "content"),
            ItemMetadata(
                native_id=path,
                media_type=item.media_type,
                title=path.rsplit("/", maxsplit=1)[-1],
                attributes={"commit": item.ref},
            ),
        )

    def _fetch_attachment(self, item: SampleItem) -> FetchedItem:
        raise FidelityError(item.source.value, item.item_id, "GitHub files have no attachments")
