import type { CSSProperties } from 'react'
import { Alert } from 'antd'
import { Link, useLocation } from 'react-router-dom'
import { COMPONENT_TYPE_SINGULAR } from '../labels'
import { ComponentCard } from '../components/ComponentCard'
import { TYPE_BADGE_BACKGROUND, typePillStyle } from '../components/cardStyles'
import type { ComponentRelations, RelatedComponent, RelationGroup } from './model'
import { emptyBoxStyle, monoStyle, sectionLabelStyle } from './styles'

const RELATED_SECTION_ID = 'related-components'

/** The components this one is used by, uses and depends on, as stacked Registry cards. */
export function RelatedColumn({ relations }: { relations: ComponentRelations }) {
  return (
    <section id={RELATED_SECTION_ID} aria-labelledby={RELATED_SECTION_ID + '-title'} style={{ scrollMarginTop: 80 }}>
      <h2 id={RELATED_SECTION_ID + '-title'} style={titleStyle}>
        Related components
      </h2>
      <Group label="Used by" group={relations.usedBy} />
      <Group label="Uses" group={relations.uses} />
      <Group label="Depends on" group={relations.dependsOn} />
    </section>
  )
}

function Group({ label, group }: { label: string; group: RelationGroup }) {
  const withheld = group.withheld
  return (
    <div style={{ marginBottom: 'var(--space-4)' }}>
      <h3 style={{ ...sectionLabelStyle, marginBottom: 'var(--space-2)' }}>
        {label} <span style={{ fontWeight: 400 }}>({group.items.length})</span>
      </h3>
      {group.items.length === 0 ? (
        <div style={{ ...emptyBoxStyle, padding: 'var(--space-3)' }}>None recorded</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
          {group.items.map((item) => (
            <RelatedItem key={item.id} item={item} />
          ))}
        </div>
      )}
      {withheld > 0 && (
        <Alert
          type="warning"
          showIcon
          style={{ marginTop: 'var(--space-2)' }}
          message={String(withheld) + ' unresolved declaration' + (withheld === 1 ? '' : 's') + ' withheld'}
        />
      )}
    </div>
  )
}

function RelatedItem({ item }: { item: RelatedComponent }) {
  const location = useLocation()
  if (item.summary) return <ComponentCard component={item.summary} />
  return (
    <Link
      to={'/registry/' + encodeURIComponent(item.id)}
      state={{ from: location.pathname + location.search }}
      style={compactCardStyle}
    >
      <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <span style={{ fontWeight: 600, color: 'var(--color-text-primary)', minWidth: 0, overflowWrap: 'anywhere' }}>
          {item.name}
        </span>
        {item.type && (
          <span style={{ ...typePillStyle, background: TYPE_BADGE_BACKGROUND[item.type] }}>
            {COMPONENT_TYPE_SINGULAR[item.type]}
          </span>
        )}
      </span>
      <span style={{ ...monoStyle, fontSize: '0.75rem', color: 'var(--color-text-tertiary)', overflowWrap: 'anywhere' }}>
        {item.id}
      </span>
    </Link>
  )
}

const titleStyle: CSSProperties = {
  margin: '0 0 var(--space-3)',
  fontSize: '1rem',
  fontWeight: 600,
  color: 'var(--color-text-primary)',
}

const compactCardStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
  padding: 'var(--space-3) var(--space-4)',
  background: 'var(--color-surface)',
  border: '1px solid var(--color-border-light)',
  borderRadius: 'var(--radius-lg)',
  textDecoration: 'none',
}
