---
pack_id: "bpc-sep26-v1"
local_id: "MCP-03"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1347"
summary: "Resolve duplicate MCP identities and references without heuristic joins"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-11"
planned_due: "2026-09-14"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["MCP-01","MCP-02","CORE-02","CORE-03"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-mcp-03"
architecture_sections: ["model","identity","ingestion"]
---

# Resolve duplicate MCP identities and references without heuristic joins

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1347**. Local reference **MCP-03** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-11 → 2026-09-14 (D3–D4)**.
- Recommendation extension: **2026-09-11 → 2026-09-14 (D3–D4)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Duplicate MCP IDs, aliases, and human-readable names can create incorrect joins. Extend CORE-03 with MCP-specific resolution evidence so every occurrence is resolved by an approved exact rule or remains visible as unresolved.

## Scope and contract

Keep durable identity separate from snapshot occurrences. A versioned resolution decision includes source ID, scope, evidence locators, resolver/alias version, rationale, and state. Exact source-owned IDs and approved scoped aliases may resolve. Names, descriptions, lexical similarity, tool names, and source order cannot merge identities. Ambiguous records stay in the review ledger and cannot support a graph edge or recommendation candidate.

## Steps

1. Define MCP identity inputs and scopes from MCP-01/02 evidence.
2. Add deterministic duplicate, alias, rename, and unresolved-reference dispositions.
3. Preserve all occurrences/conflicts while releasing stable references only after decision.
4. Supply unresolved results to MCP-04/05 rather than guessed IDs.

## Acceptance and verification

- Exact duplicates resolve only under approved scope/authority rules and retain all occurrence evidence.
- Same name or similar description across scopes remains unresolved without exact mapping.
- Approved rename/alias decisions are versioned and evidenced; unsupported renames remain unresolved.
- Row ordering cannot alter an identity or downstream target.
- Unresolved references create neither graph edges nor eligible candidates.

## Evidence, blockers and exclusions

Attach decision records, duplicate/alias/rename fixtures, ledger output, and owner approval for non-exact aliases. Block on missing scope, authority, or owner decision. Do not alter cross-type CORE identity semantics, project edges, or score candidates.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [MCP-01](MCP-01.md) must finish its stated contract boundary before this task starts.
- [MCP-02](MCP-02.md) must finish its stated contract boundary before this task starts.
- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.
- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `model`, `identity`, `ingestion`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
