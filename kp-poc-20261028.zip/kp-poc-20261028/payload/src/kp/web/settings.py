"""Settings of the web UI.

A separate group with its own prefix, as the search tunables are: the core ``Settings`` stay the
contract of the platform, and the UI reads what only it needs.
"""

from __future__ import annotations

from typing import Annotated

from pydantic import Field, ValidationError
from pydantic_settings import BaseSettings, SettingsConfigDict

from kp.errors import ConfigurationError

DEFAULT_IDENTITY_HEADER = "X-KP-Caller"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8090


class WebSettings(BaseSettings):
    """Settings of the web UI (``KP_WEB_`` environment variables).

    :ivar identity_header: In real mode, the name of the request header that carries the signed-in
        user. The UI trusts it, so it must sit behind something that authenticates the user and
        sets it; it binds to the loopback address by default. Local mode ignores it.
    :ivar result_limit: How many search hits a page asks for.
    :ivar audit_limit: How many audit records a page lists.
    """

    model_config = SettingsConfigDict(env_prefix="KP_WEB_", extra="ignore", frozen=True)

    identity_header: Annotated[str, Field(min_length=1, pattern=r"^[A-Za-z0-9-]+$")] = (
        DEFAULT_IDENTITY_HEADER
    )
    result_limit: Annotated[int, Field(ge=1, le=50)] = 10
    audit_limit: Annotated[int, Field(ge=1, le=1000)] = 200


def load_web_settings() -> WebSettings:
    """Load the UI settings from the process environment.

    :return: The validated, immutable settings
    :raises kp.errors.ConfigurationError: If a value is invalid
    """
    try:
        return WebSettings()
    except ValidationError as exc:
        problems = "; ".join(
            f"{'.'.join(str(part) for part in err['loc']) or 'settings'}: {err['msg']}"
            for err in exc.errors(include_input=False, include_url=False)
        )
        raise ConfigurationError(f"Invalid web settings: {problems}") from exc
