"""A page and position index kept from the source PDF.

Extraction Markdown may drop page markers. This index is built from the source file itself,
so a clause can still be given its page.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from pypdf import PdfReader

from kp.domain import Passage

_PROBE_WORDS = 10


def _normalise(text: str) -> str:
    return " ".join(text.split())


class PageIndex:
    """Page texts of one document, searchable by a snippet.

    :param pages: The text of each page, page 1 first
    """

    def __init__(self, pages: Sequence[str]) -> None:
        self._pages = [_normalise(page) for page in pages]

    @classmethod
    def from_pdf(cls, path: Path) -> PageIndex:
        """Read the page texts of a PDF.

        :param path: The PDF file
        :return: An index over its pages
        """
        return cls([page.extract_text() or "" for page in PdfReader(path).pages])

    def __len__(self) -> int:
        return len(self._pages)

    def page_of(self, text: str, *, from_page: int = 1) -> int | None:
        """Find the page on which a passage starts.

        :param text: The passage; only its first words are matched, whitespace-insensitively
        :param from_page: First page to consider; pass the previous clause's page to skip
            earlier pages that happen to contain the same words (a table of contents, say)
        :return: The one-based page number, or ``None`` when no page contains it
        """
        probe = " ".join(_normalise(text).split()[:_PROBE_WORDS])
        if not probe:
            return None
        for number, page in enumerate(self._pages[from_page - 1 :], start=from_page):
            if probe in page:
                return number
        return None


def fill_missing_pages(passages: Sequence[Passage], index: PageIndex) -> list[Passage]:
    """Give passages that lack a page number the page found in the source file.

    This is the fallback for extraction output without page markers. Passages must be in
    document order; each search starts at the page of the previous match, so repeated words
    on earlier pages are skipped. A passage that already has a page, or whose words the index
    does not hold, is returned unchanged.

    :param passages: Passages of one document in document order
    :param index: The page texts of the source file
    :return: The passages, with ``page`` set where it was missing and found
    """
    filled: list[Passage] = []
    current = 1
    for passage in passages:
        page = passage.page
        if page is None:
            page = index.page_of(passage.text, from_page=current)
            filled.append(passage if page is None else passage.model_copy(update={"page": page}))
        else:
            filled.append(passage)
        current = max(current, page or current)
    return filled
