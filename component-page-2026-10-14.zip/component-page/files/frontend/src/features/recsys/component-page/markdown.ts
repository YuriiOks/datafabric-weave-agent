/**
 * A small Markdown reader for component definitions (SKILL.md, agent and MCP server files).
 *
 * It covers what those files use: a frontmatter block, headings, paragraphs, nested lists,
 * fenced code, GitHub alerts (`> [!WARNING]`), quotes, tables, rules, inline code, emphasis and
 * links. It returns a tree that the viewer renders as React elements, so no HTML from a file
 * ever reaches the page, and links outside http(s), mailto, anchors and relative paths are
 * dropped.
 */

export type Inline =
  | { kind: 'text'; text: string }
  | { kind: 'code'; text: string }
  | { kind: 'strong'; children: Inline[] }
  | { kind: 'em'; children: Inline[] }
  | { kind: 'link'; href: string | null; children: Inline[] }

export type AlertVariant = 'note' | 'tip' | 'important' | 'warning' | 'caution'

export type Align = 'left' | 'center' | 'right' | null

export type ListItem = { inline: Inline[]; children: Block[] }

export type Block =
  | { kind: 'heading'; level: number; slug: string; text: string; inline: Inline[] }
  | { kind: 'paragraph'; inline: Inline[] }
  | { kind: 'list'; ordered: boolean; start: number; items: ListItem[] }
  | { kind: 'code'; lang: string | null; text: string }
  | { kind: 'alert'; variant: AlertVariant; blocks: Block[] }
  | { kind: 'quote'; blocks: Block[] }
  | { kind: 'table'; align: Align[]; header: Inline[][]; rows: Inline[][][] }
  | { kind: 'rule' }

export type FrontmatterEntry = {
  key: string
  value: string
  /** Set when the value is a list: a YAML list, `[a, b]`, or a comma list under a list key. */
  items: string[] | null
}

export type TocEntry = { slug: string; text: string; level: number }

export type ParsedMarkdown = {
  frontmatter: FrontmatterEntry[]
  blocks: Block[]
  /** Level 2 and 3 headings, in order, for an "On this page" list. */
  toc: TocEntry[]
}

/** Frontmatter keys whose comma-separated values are shown as separate chips. */
const LIST_KEYS = new Set([
  'tools',
  'allowed-tools',
  'allowed_tools',
  'tags',
  'skills',
  'mcp_servers',
  'mcp-servers',
  'servers',
  'tenants',
])

const FENCE = /^ {0,3}(`{3,}|~{3,})\s*([\w+#.-]*)\s*$/
const HEADING = /^ {0,3}(#{1,6})\s+(.*?)\s*#*\s*$/
const RULE = /^ {0,3}([-*_])(?:\s*\1){2,}\s*$/
const LIST_ITEM = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/
const TABLE_DIVIDER = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/
const ALERT = /^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*$/i

export function parseMarkdown(source: string): ParsedMarkdown {
  const lines = source.replace(/\r\n?/g, '\n').split('\n')
  const { entries, bodyStart } = readFrontmatter(lines)
  const slugs = new Map<string, number>()
  const blocks = parseBlocks(lines.slice(bodyStart), slugs)
  const toc: TocEntry[] = []
  collectHeadings(blocks, toc)
  return { frontmatter: entries, blocks, toc }
}

function readFrontmatter(lines: string[]): { entries: FrontmatterEntry[]; bodyStart: number } {
  if (lines[0]?.trim() !== '---') return { entries: [], bodyStart: 0 }
  const end = lines.findIndex((line, index) => index > 0 && line.trim() === '---')
  if (end < 0) return { entries: [], bodyStart: 0 }
  const entries: FrontmatterEntry[] = []
  for (const line of lines.slice(1, end)) {
    const item = /^\s+-\s+(.*)$/.exec(line)
    const last = entries[entries.length - 1]
    if (item && last && last.value === '') {
      last.items = [...(last.items ?? []), unquote(item[1] ?? '')]
      continue
    }
    const pair = /^([\w.-]+)\s*:\s*(.*)$/.exec(line)
    if (!pair) continue
    const key = pair[1] ?? ''
    const value = unquote(pair[2] ?? '')
    let items: string[] | null = null
    if (value.startsWith('[') && value.endsWith(']')) {
      items = splitList(value.slice(1, -1))
    } else if (LIST_KEYS.has(key.toLowerCase()) && value !== '') {
      items = splitList(value)
    }
    entries.push({ key, value, items })
  }
  for (const entry of entries) {
    if (entry.items && entry.value === '') entry.value = entry.items.join(', ')
  }
  return { entries, bodyStart: end + 1 }
}

function splitList(value: string): string[] {
  return value
    .split(',')
    .map((part) => unquote(part))
    .filter((part) => part !== '')
}

function unquote(value: string): string {
  const trimmed = value.trim()
  const quoted = /^(['"])(.*)\1$/.exec(trimmed)
  return quoted ? (quoted[2] ?? '') : trimmed
}

function startsBlock(line: string): boolean {
  return (
    FENCE.test(line) ||
    HEADING.test(line) ||
    RULE.test(line) ||
    LIST_ITEM.test(line) ||
    /^ {0,3}>/.test(line)
  )
}

function parseBlocks(lines: string[], slugs: Map<string, number>): Block[] {
  const blocks: Block[] = []
  const at = (k: number): string => lines[k] ?? ''
  let i = 0
  while (i < lines.length) {
    const line = at(i)
    if (line.trim() === '') {
      i += 1
      continue
    }

    const fence = FENCE.exec(line)
    if (fence) {
      const marker = fence[1] ?? '```'
      const body: string[] = []
      i += 1
      while (i < lines.length && !at(i).trim().startsWith(marker)) {
        body.push(at(i))
        i += 1
      }
      i += 1
      blocks.push({ kind: 'code', lang: fence[2] || null, text: body.join('\n') })
      continue
    }

    const heading = HEADING.exec(line)
    if (heading) {
      const inline = parseInline(heading[2] ?? '')
      const text = plainText(inline)
      blocks.push({
        kind: 'heading',
        level: (heading[1] ?? '#').length,
        slug: uniqueSlug(text, slugs),
        text,
        inline,
      })
      i += 1
      continue
    }

    if (RULE.test(line)) {
      blocks.push({ kind: 'rule' })
      i += 1
      continue
    }

    if (/^ {0,3}>/.test(line)) {
      const quoted: string[] = []
      while (i < lines.length && /^ {0,3}>/.test(at(i))) {
        quoted.push(at(i).replace(/^ {0,3}> ?/, ''))
        i += 1
      }
      const alert = ALERT.exec(quoted[0]?.trim() ?? '')
      if (alert) {
        blocks.push({
          kind: 'alert',
          variant: (alert[1] ?? 'note').toLowerCase() as AlertVariant,
          blocks: parseBlocks(quoted.slice(1), slugs),
        })
      } else {
        blocks.push({ kind: 'quote', blocks: parseBlocks(quoted, slugs) })
      }
      continue
    }

    if (line.includes('|') && i + 1 < lines.length && at(i + 1).includes('|') && TABLE_DIVIDER.test(at(i + 1))) {
      const header = splitRow(line)
      const align = splitRow(at(i + 1)).map(alignOf)
      const rows: Inline[][][] = []
      i += 2
      while (i < lines.length && at(i).includes('|') && at(i).trim() !== '') {
        rows.push(splitRow(at(i)).map(parseInline))
        i += 1
      }
      blocks.push({ kind: 'table', align, header: header.map(parseInline), rows })
      continue
    }

    if (LIST_ITEM.test(line)) {
      const { block, next } = parseList(lines, i, slugs)
      blocks.push(block)
      i = next
      continue
    }

    const paragraph: string[] = []
    while (i < lines.length && at(i).trim() !== '' && (paragraph.length === 0 || !startsBlock(at(i)))) {
      paragraph.push(at(i).trim())
      i += 1
    }
    blocks.push({ kind: 'paragraph', inline: parseInline(paragraph.join(' ')) })
  }
  return blocks
}

function indentOf(line: string): number {
  return line.length - line.trimStart().length
}

function parseList(
  lines: string[],
  start: number,
  slugs: Map<string, number>,
): { block: Block; next: number } {
  const at = (k: number): string => lines[k] ?? ''
  const first = LIST_ITEM.exec(at(start))
  const baseIndent = first ? (first[1] ?? '').length : 0
  const ordered = first ? /\d/.test(first[2] ?? '') : false
  const startNumber = ordered && first ? Number.parseInt(first[2] ?? '1', 10) : 1
  const items: ListItem[] = []
  let i = start
  while (i < lines.length) {
    const line = at(i)
    if (line.trim() === '') {
      const next = lines[i + 1]
      if (next !== undefined && LIST_ITEM.test(next) && indentOf(next) >= baseIndent) {
        i += 1
        continue
      }
      break
    }
    const match = LIST_ITEM.exec(line)
    const indent = indentOf(line)
    if (match && indent === baseIndent) {
      if (/\d/.test(match[2] ?? '') !== ordered) break
      const text: string[] = [match[3] ?? '']
      i += 1
      const nested: string[] = []
      while (i < lines.length && at(i).trim() !== '' && indentOf(at(i)) > baseIndent) {
        if (LIST_ITEM.test(at(i)) || nested.length > 0) {
          nested.push(at(i))
        } else {
          text.push(at(i).trim())
        }
        i += 1
      }
      items.push({
        inline: parseInline(text.join(' ')),
        children: nested.length > 0 ? parseBlocks(dedent(nested), slugs) : [],
      })
      continue
    }
    const last = items[items.length - 1]
    if (indent > baseIndent && last) {
      last.children = [...last.children, ...parseBlocks(dedent([line]), slugs)]
      i += 1
      continue
    }
    break
  }
  return { block: { kind: 'list', ordered, start: startNumber, items }, next: i }
}

function dedent(lines: string[]): string[] {
  const indents = lines.filter((line) => line.trim() !== '').map(indentOf)
  const cut = indents.length > 0 ? Math.min(...indents) : 0
  return lines.map((line) => line.slice(Math.min(cut, indentOf(line))))
}

function splitRow(line: string): string[] {
  let row = line.trim()
  if (row.startsWith('|')) row = row.slice(1)
  if (row.endsWith('|') && !row.endsWith('\\|')) row = row.slice(0, -1)
  const cells: string[] = []
  let cell = ''
  let inCode = false
  for (let k = 0; k < row.length; k += 1) {
    const ch = row.charAt(k)
    if (ch === '\\' && row.charAt(k + 1) === '|') {
      cell += '|'
      k += 1
    } else if (ch === '`') {
      inCode = !inCode
      cell += ch
    } else if (ch === '|' && !inCode) {
      cells.push(cell.trim())
      cell = ''
    } else {
      cell += ch
    }
  }
  cells.push(cell.trim())
  return cells
}

function alignOf(cell: string): Align {
  const left = cell.startsWith(':')
  const right = cell.endsWith(':')
  if (left && right) return 'center'
  if (right) return 'right'
  if (left) return 'left'
  return null
}

/** Inline Markdown: code spans, links, strong and emphasis; everything else stays text. */
export function parseInline(source: string): Inline[] {
  const out: Inline[] = []
  let text = ''
  const flush = () => {
    if (text !== '') {
      out.push({ kind: 'text', text })
      text = ''
    }
  }
  let i = 0
  while (i < source.length) {
    const ch = source.charAt(i)
    const nextChar = source.charAt(i + 1)
    if (ch === '\\' && i + 1 < source.length && /[\\`*_[\]()#+\-.!|>{}]/.test(nextChar)) {
      text += nextChar
      i += 2
      continue
    }
    if (ch === '`') {
      const end = source.indexOf('`', i + 1)
      if (end > i) {
        flush()
        out.push({ kind: 'code', text: source.slice(i + 1, end) })
        i = end + 1
        continue
      }
    }
    if (ch === '[') {
      const link = /^\[([^\]]+)\]\(\s*([^)\s]+)(?:\s+"[^"]*")?\s*\)/.exec(source.slice(i))
      if (link) {
        flush()
        out.push({ kind: 'link', href: safeHref(link[2] ?? ''), children: parseInline(link[1] ?? '') })
        i += link[0].length
        continue
      }
    }
    if ((ch === '*' || ch === '_') && nextChar === ch) {
      const end = source.indexOf(ch + ch, i + 2)
      if (end > i + 2) {
        flush()
        out.push({ kind: 'strong', children: parseInline(source.slice(i + 2, end)) })
        i = end + 2
        continue
      }
    }
    if (ch === '*' || ch === '_') {
      const before = i > 0 ? source.charAt(i - 1) : ' '
      const after = nextChar || ' '
      const opens = after !== ' ' && (ch === '*' || !/\w/.test(before))
      if (opens) {
        let end = source.indexOf(ch, i + 1)
        while (end > -1 && ch === '_' && /\w/.test(source.charAt(end + 1))) {
          end = source.indexOf(ch, end + 1)
        }
        if (end > i + 1 && source.charAt(end - 1) !== ' ') {
          flush()
          out.push({ kind: 'em', children: parseInline(source.slice(i + 1, end)) })
          i = end + 1
          continue
        }
      }
    }
    text += ch
    i += 1
  }
  flush()
  return out
}

/** Keeps http(s), mailto, in-page anchors and relative paths; drops every other scheme. */
export function safeHref(raw: string): string | null {
  const href = raw.trim()
  if (href === '' || href.startsWith('//')) return null
  if (href.startsWith('#')) return href
  if (/^[a-z][a-z0-9+.-]*:/i.test(href)) return /^(https?|mailto):/i.test(href) ? href : null
  return href
}

export function plainText(inline: Inline[]): string {
  return inline
    .map((node) => (node.kind === 'text' || node.kind === 'code' ? node.text : plainText(node.children)))
    .join('')
}

function uniqueSlug(text: string, slugs: Map<string, number>): string {
  const base =
    text
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .trim()
      .replace(/[\s_]+/g, '-')
      .replace(/-+/g, '-')
      .slice(0, 60) || 'section'
  const seen = slugs.get(base) ?? 0
  slugs.set(base, seen + 1)
  return seen === 0 ? base : base + '-' + String(seen + 1)
}

function collectHeadings(blocks: Block[], toc: TocEntry[]): void {
  for (const block of blocks) {
    if (block.kind === 'heading' && (block.level === 2 || block.level === 3)) {
      toc.push({ slug: block.slug, text: block.text, level: block.level })
    }
  }
}
