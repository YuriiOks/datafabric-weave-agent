"""Evaluation cases: scenario, truthful expected outcome, adjudication and required evidence.

A case references components by the id the publication projection emits: the canonical
component uuid as lower-case text. Relevance comes only from an adjudication by a named
reviewer. Until then every label is ``unjudged`` and the case supports no quality claim.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from enum import Enum
from types import MappingProxyType
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.recsys.contracts import ComponentType
from app.recsys.eval.schema import DRAFT_LABELLER, SYNTHETIC_MARKER, GoldenInput

CASE_ID_RE = re.compile(r"^[a-z]{3}-\d{4}$")
GROUP_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
SHA256_RE = r"^[0-9a-f]{64}$"


def canonical_component_id(value: str) -> str:
    """Check that a component id is canonical uuid text.

    :param value: The id.
    :return: The id, unchanged.
    :raises ValueError: When it is not lower-case canonical uuid text.
    """
    try:
        parsed = UUID(value)
    except (AttributeError, TypeError, ValueError) as error:
        raise ValueError("component ids are canonical component uuids") from error
    if str(parsed) != value:
        raise ValueError("component ids are lower-case canonical uuid text")
    return value


class Scenario(str, Enum):
    """What a case exercises. Each scenario has a rule in :data:`SCENARIO_RULES`."""

    positive = "positive"
    partial = "partial"
    hard_negative = "hard_negative"
    valid_empty = "valid_empty"
    ambiguous = "ambiguous"
    access_restricted = "access_restricted"
    incomplete_description = "incomplete_description"
    source_unavailable = "source_unavailable"
    duplicate_alias = "duplicate_alias"
    unresolved_dependency = "unresolved_dependency"
    prerequisite = "prerequisite"
    unknown_prerequisite = "unknown_prerequisite"
    conflict = "conflict"


class ExpectedOutcome(str, Enum):
    """The truthful outcome class a correct system reports for the case."""

    ranked = "ranked"
    valid_empty = "valid_empty"
    access_filtered = "access_filtered"
    source_unavailable = "source_unavailable"


class RelevanceLabel(str, Enum):
    """A reviewer's relevance judgement for one component and one need."""

    relevant = "relevant"
    partially_relevant = "partially_relevant"
    not_relevant = "not_relevant"
    unjudged = "unjudged"


POSITIVE_LABELS = frozenset({RelevanceLabel.relevant, RelevanceLabel.partially_relevant})


class AdjudicationState(str, Enum):
    """Whether a named reviewer has decided the case."""

    unjudged = "unjudged"
    judged = "judged"


class EvidenceKind(str, Enum):
    """Source evidence a correct answer must show. Evidence never decides relevance."""

    declared_prerequisite = "declared_prerequisite"
    prerequisite_unknown = "prerequisite_unknown"
    source_conflict = "source_conflict"
    unresolved_reference = "unresolved_reference"
    duplicate_identity = "duplicate_identity"


_NEEDS_RELATED = frozenset({EvidenceKind.declared_prerequisite, EvidenceKind.duplicate_identity})


class EvidenceRequirement(BaseModel):
    """One piece of evidence a correct answer must show about a component.

    A ``declared_prerequisite`` is gated: it applies only once a reviewer has judged its
    subject relevant, so a declared relation can never stand in for that judgement.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    kind: EvidenceKind
    subject_id: str
    related_id: str | None = None

    @field_validator("subject_id", "related_id")
    @classmethod
    def _canonical(cls, value: str | None) -> str | None:
        """Refuse ids that are not canonical component uuids.

        :param value: An id or ``None``.
        :return: The id, checked.
        """
        return None if value is None else canonical_component_id(value)

    @model_validator(mode="after")
    def _related_when_needed(self) -> EvidenceRequirement:
        """Prerequisite and duplicate evidence name the other component.

        :return: The requirement.
        :raises ValueError: When the related id is missing or equals the subject.
        """
        if self.kind in _NEEDS_RELATED and self.related_id is None:
            raise ValueError(f"{self.kind.value} evidence names the related component")
        if self.related_id is not None and self.related_id == self.subject_id:
            raise ValueError("evidence relates two different components")
        return self

    def component_ids(self) -> frozenset[str]:
        """:return: The ids the requirement references."""
        ids = {self.subject_id}
        if self.related_id is not None:
            ids.add(self.related_id)
        return frozenset(ids)


class Adjudication(BaseModel):
    """The relevance decision for one case.

    ``unjudged`` lists the candidates still to review, every one labelled ``unjudged``.
    ``judged`` names the reviewer and the decision reference, and labels no candidate
    ``unjudged``. The draft labeller is never a reviewer.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    state: AdjudicationState = AdjudicationState.unjudged
    reviewer: str | None = Field(default=None, min_length=1, max_length=128)
    decision_reference: str | None = Field(default=None, min_length=1, max_length=256)
    labels: dict[str, RelevanceLabel] = Field(default_factory=dict)

    @field_validator("labels")
    @classmethod
    def _canonical_ids(cls, value: dict[str, RelevanceLabel]) -> dict[str, RelevanceLabel]:
        """Refuse non-canonical ids and sort the labels.

        :param value: The labels by component id.
        :return: The labels, sorted by id.
        """
        for component_id in value:
            canonical_component_id(component_id)
        return dict(sorted(value.items()))

    @model_validator(mode="after")
    def _decision_is_named(self) -> Adjudication:
        """Only a named reviewer's decision carries labels other than ``unjudged``.

        :return: The adjudication.
        :raises ValueError: When the state, reviewer, reference and labels disagree.
        """
        if self.state is AdjudicationState.unjudged:
            if self.reviewer is not None or self.decision_reference is not None:
                raise ValueError("an unjudged case names no reviewer and no decision")
            if any(label is not RelevanceLabel.unjudged for label in self.labels.values()):
                raise ValueError("an unjudged case carries only unjudged labels")
            return self
        if self.reviewer is None or not self.reviewer.strip():
            raise ValueError("a judged case names its reviewer")
        if self.reviewer.strip() == DRAFT_LABELLER:
            raise ValueError("the draft labeller is not a reviewer")
        if self.decision_reference is None:
            raise ValueError("a judged case cites its decision")
        if any(label is RelevanceLabel.unjudged for label in self.labels.values()):
            raise ValueError("a judged case labels every candidate it lists")
        return self

    @property
    def judged(self) -> bool:
        """:return: Whether a named reviewer decided the case."""
        return self.state is AdjudicationState.judged

    def ids_labelled(self, *labels: RelevanceLabel) -> frozenset[str]:
        """Select the component ids carrying given labels.

        :param labels: The labels to select.
        :return: The component ids carrying any of them.
        """
        return frozenset(key for key, value in self.labels.items() if value in labels)


class ScenarioRule(BaseModel):
    """The shape every case of one scenario must have; the case template."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    outcomes: frozenset[ExpectedOutcome]
    needs_forbidden: bool = False
    needs_evidence: EvidenceKind | None = None
    judged_needs: RelevanceLabel | None = None


_RANKED = frozenset({ExpectedOutcome.ranked})
_RANKED_OR_EMPTY = frozenset({ExpectedOutcome.ranked, ExpectedOutcome.valid_empty})

SCENARIO_RULES: Mapping[Scenario, ScenarioRule] = MappingProxyType(
    {
        Scenario.positive: ScenarioRule(outcomes=_RANKED, judged_needs=RelevanceLabel.relevant),
        Scenario.partial: ScenarioRule(
            outcomes=_RANKED, judged_needs=RelevanceLabel.partially_relevant
        ),
        Scenario.hard_negative: ScenarioRule(outcomes=_RANKED_OR_EMPTY, needs_forbidden=True),
        Scenario.valid_empty: ScenarioRule(outcomes=frozenset({ExpectedOutcome.valid_empty})),
        Scenario.ambiguous: ScenarioRule(outcomes=_RANKED_OR_EMPTY),
        Scenario.access_restricted: ScenarioRule(
            outcomes=frozenset({ExpectedOutcome.access_filtered, ExpectedOutcome.ranked}),
            needs_forbidden=True,
        ),
        Scenario.incomplete_description: ScenarioRule(outcomes=_RANKED_OR_EMPTY),
        Scenario.source_unavailable: ScenarioRule(
            outcomes=frozenset({ExpectedOutcome.source_unavailable})
        ),
        Scenario.duplicate_alias: ScenarioRule(
            outcomes=_RANKED, needs_evidence=EvidenceKind.duplicate_identity
        ),
        Scenario.unresolved_dependency: ScenarioRule(
            outcomes=_RANKED_OR_EMPTY, needs_evidence=EvidenceKind.unresolved_reference
        ),
        Scenario.prerequisite: ScenarioRule(
            outcomes=_RANKED,
            needs_evidence=EvidenceKind.declared_prerequisite,
            judged_needs=RelevanceLabel.relevant,
        ),
        Scenario.unknown_prerequisite: ScenarioRule(
            outcomes=_RANKED_OR_EMPTY, needs_evidence=EvidenceKind.prerequisite_unknown
        ),
        Scenario.conflict: ScenarioRule(
            outcomes=_RANKED_OR_EMPTY, needs_evidence=EvidenceKind.source_conflict
        ),
    }
)


class EvaluationCase(BaseModel):
    """One need, its scenario, its truthful expected outcome and its adjudication.

    ``lineage_digest`` pins the case to the pack's lineage. ``forbidden`` lists components
    that must never appear, such as one the caller cannot access or a confusable one.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    case_id: str
    component_type: ComponentType
    group_id: str
    scenario: Scenario
    input: GoldenInput
    expected_outcome: ExpectedOutcome
    forbidden: tuple[str, ...] = ()
    required_evidence: tuple[EvidenceRequirement, ...] = ()
    adjudication: Adjudication = Field(default_factory=Adjudication)
    lineage_digest: str = Field(pattern=SHA256_RE)
    notes: str = Field(default="", max_length=2000)

    @field_validator("case_id")
    @classmethod
    def _case_id_shape(cls, value: str) -> str:
        """Refuse malformed case ids.

        :param value: The case id.
        :return: The id, checked.
        """
        if not CASE_ID_RE.match(value):
            raise ValueError("case ids look like skl-0001")
        return value

    @field_validator("group_id")
    @classmethod
    def _group_id_shape(cls, value: str) -> str:
        """Refuse malformed group ids.

        :param value: The group id.
        :return: The id, checked.
        """
        if not GROUP_ID_RE.match(value):
            raise ValueError("group ids are lower-case words joined by hyphens")
        return value

    @field_validator("forbidden")
    @classmethod
    def _forbidden_ids(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        """Refuse repeated or non-canonical forbidden ids.

        :param value: The forbidden ids.
        :return: The ids, unique and sorted.
        """
        ids = [canonical_component_id(item) for item in value]
        if len(set(ids)) != len(ids):
            raise ValueError("forbidden ids are unique")
        return tuple(sorted(ids))

    @model_validator(mode="after")
    def _follows_its_scenario(self) -> EvaluationCase:
        """Apply the scenario rule and the adjudication rules.

        :return: The case.
        :raises ValueError: When the case breaks either.
        """
        if self.input.pair_card_id is not None:
            raise ValueError("an evaluation case takes one need, not a pair")
        if self.input.text is not None and not self.notes.startswith(SYNTHETIC_MARKER):
            raise ValueError(f"a free-text need is synthetic; its notes start {SYNTHETIC_MARKER}")
        rule = SCENARIO_RULES[self.scenario]
        if self.expected_outcome not in rule.outcomes:
            raise ValueError(f"{self.scenario.value} expects one of its own outcome classes")
        if rule.needs_forbidden and not self.forbidden:
            raise ValueError(f"{self.scenario.value} names the component that must not appear")
        kinds = {item.kind for item in self.required_evidence}
        if rule.needs_evidence is not None and rule.needs_evidence not in kinds:
            needed = rule.needs_evidence.value
            raise ValueError(f"{self.scenario.value} requires {needed} evidence")
        positive = self.adjudication.ids_labelled(*POSITIVE_LABELS)
        if positive & set(self.forbidden):
            raise ValueError("a forbidden component cannot also be judged relevant")
        if self.adjudication.judged:
            self._check_judged(rule, positive)
        return self

    def _check_judged(self, rule: ScenarioRule, positive: frozenset[str]) -> None:
        """Check a judged case against its expected outcome and gated evidence.

        :param rule: The scenario rule.
        :param positive: The ids judged relevant or partially relevant.
        :raises ValueError: When the decision contradicts the case.
        """
        needs = rule.judged_needs
        if needs is not None and not self.adjudication.ids_labelled(needs):
            raise ValueError(f"a judged {self.scenario.value} case has a {needs.value} id")
        if self.expected_outcome is ExpectedOutcome.valid_empty and positive:
            raise ValueError("a valid empty expectation has no relevant component")
        if self.expected_outcome is ExpectedOutcome.ranked and not positive:
            raise ValueError("a ranked expectation has at least one relevant component")
        for item in self.required_evidence:
            if item.kind is EvidenceKind.declared_prerequisite and item.subject_id not in positive:
                raise ValueError("prerequisite evidence follows a relevance judgement")

    def relevant_ids(self) -> frozenset[str]:
        """:return: The ids a reviewer judged relevant; empty while unjudged."""
        return self.adjudication.ids_labelled(RelevanceLabel.relevant)

    def partial_ids(self) -> frozenset[str]:
        """:return: The ids a reviewer judged partially relevant; empty while unjudged."""
        return self.adjudication.ids_labelled(RelevanceLabel.partially_relevant)

    def referenced_ids(self) -> frozenset[str]:
        """:return: Every component id the case names: labels, forbidden ids and evidence."""
        ids = set(self.adjudication.labels) | set(self.forbidden)
        for item in self.required_evidence:
            ids |= item.component_ids()
        return frozenset(ids)

    def gated_evidence(self) -> tuple[EvidenceRequirement, ...]:
        """:return: Prerequisite evidence still waiting for its subject's judgement."""
        positive = self.adjudication.ids_labelled(*POSITIVE_LABELS)
        return tuple(
            item
            for item in self.required_evidence
            if item.kind is EvidenceKind.declared_prerequisite and item.subject_id not in positive
        )
