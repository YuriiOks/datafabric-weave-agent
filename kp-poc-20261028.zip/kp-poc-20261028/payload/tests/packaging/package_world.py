"""Shared helpers of the packaging tests: the scripts on the path and a small fake project.

The scripts are not part of the installed package, so the tests put ``scripts/`` on the import
path (``check.sh`` sets ``MYPYPATH`` to the same folder for the type check).
"""

from __future__ import annotations

import json
import sys
from datetime import date
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = PROJECT_ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import bank_install_template as installer  # noqa: E402
import build_bank_package as builder  # noqa: E402

__all__ = [
    "BUILD_DATE",
    "FAKE_PATTERNS",
    "PROJECT_ROOT",
    "SCRIPTS",
    "builder",
    "installer",
    "make_project",
    "options_for",
    "write_patterns",
]

BUILD_DATE = date(2026, 10, 28)
FAKE_PATTERNS = {
    "bank_hosts": [r"acme-internal\.test", r"\bacmebank\b"],
    "staff_ids": [r"\bSTAFF[0-9]{5}\b"],
}
"""Harmless stand-ins. The real expressions are never read by the tests."""


def write_patterns(path: Path, document: object | None = None) -> Path:
    """Write a patterns file.

    :param path: Where to write it
    :param document: The JSON document; the fake patterns by default
    :return: The path
    """
    path.write_text(json.dumps(FAKE_PATTERNS if document is None else document), encoding="utf-8")
    return path


def make_project(root: Path) -> Path:
    """Create a small project with everything the package needs, and some junk it must skip.

    :param root: The project folder to create
    :return: The same folder
    """
    files: dict[str, bytes] = {
        "src/kp/__init__.py": b'"""Package."""\n',
        "src/kp/py.typed": b"",
        "tests/test_one.py": b"def test_one() -> None:\n    assert True\n",
        "fixtures/generated/sample.json": b'{"name": "Example Scheme"}\n',
        "scripts/check.sh": b"#!/usr/bin/env bash\necho ok\n",
        "scripts/bank_install_template.py": (SCRIPTS / "bank_install_template.py").read_bytes(),
        "docs/guide.md": b"# Guide\n",
        "pyproject.toml": b'[project]\nname = "kp"\n',
        "README.md": b"# Project\n",
        "ARCHITECTURE.md": b"# Architecture\n",
        "INSTALL-WORKSTATION.md": b"# Install\n",
        ".env.example": b"# KP_MODE=local\n",
        ".gitignore": b".env\n",
        # Junk that must stay out of the package.
        "SPEC.md": b"requirements\n",
        ".env": b"KP_X=1\n",
        ".env.local": b"KP_X=1\n",
        "src/kp/__pycache__/one.cpython-311.pyc": b"\x00\x01",
        "src/kp/stale.pyc": b"\x00\x01",
        "src/.mypy_cache/meta.json": b"{}\n",
        "tests/var/data.txt": b"scratch\n",
        "tests/.pytest_cache/state": b"x\n",
        "fixtures/local.db": b"\x00",
        "docs/SPEC.md": b"requirements\n",
        "src/kp.egg-info/PKG-INFO": b"x\n",
    }
    for name, data in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    return root


def options_for(
    project: Path,
    out_root: Path,
    patterns: Path,
    *,
    extra_url_domains: tuple[str, ...] = (),
    extra_email_domains: tuple[str, ...] = (),
) -> builder.BuildOptions:
    """Build options for the fake project.

    :param project: The project folder
    :param out_root: Where the package and zip go
    :param patterns: The patterns file
    :param extra_url_domains: URL exceptions to the strict default
    :param extra_email_domains: Email exceptions to the strict default
    :return: The options
    """
    return builder.BuildOptions(
        project_root=project,
        out_root=out_root,
        patterns_file=patterns,
        build_date=BUILD_DATE,
        extra_url_domains=extra_url_domains,
        extra_email_domains=extra_email_domains,
    )
