"""Fixtures for the tool tests: ports built from the committed synthetic dataset."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest

from kp.clock import FixedClock
from kp.domain import (
    Clause,
    ClauseRef,
    Edition,
    ItemRef,
    ItemType,
    Link,
    LinkKind,
    LinkState,
    PassageType,
    Relation,
    Template,
)
from kp.testing.dataset import SyntheticDataset, load_dataset
from kp.tools import (
    CoverageSnapshot,
    IdentityMapping,
    ReadPorts,
    RuleClause,
    RuleCoverage,
    SearchHit,
    StoryGap,
    ToolRegistry,
    build_read_registry,
)
from kp.tools.testing import (
    FakeCoverage,
    FakeLinks,
    FakeRules,
    FakeSearch,
    FakeTemplates,
    InMemoryAudit,
)

__all__ = [
    "audit",
    "coverage",
    "link_graph",
    "links",
    "mapping",
    "ports",
    "registry",
    "rules",
    "search",
    "templates",
    "truth",
]

CLAUSE = "2026.1:4.2.1"
VALID_FROM = datetime(2026, 1, 1, tzinfo=UTC)


@pytest.fixture
def truth(committed_fixtures_dir: Path) -> SyntheticDataset:
    """The committed synthetic dataset with its ground truth."""
    return load_dataset(committed_fixtures_dir)


@pytest.fixture
def mapping(committed_fixtures_dir: Path) -> IdentityMapping:
    """The committed test users and their domains."""
    return IdentityMapping.from_file(committed_fixtures_dir / "identity" / "identity-mapping.yaml")


@pytest.fixture
def audit() -> InMemoryAudit:
    """A list-backed audit sink."""
    return InMemoryAudit()


def _stated(link_id: str, source: ItemRef, relation: Relation, target: ItemRef) -> Link:
    return Link(
        link_id=link_id,
        source_ref=source,
        relation=relation,
        target_ref=target,
        kind=LinkKind.STATED,
        state=LinkState.STATED,
        valid_from=VALID_FROM,
    )


def _guessed(
    link_id: str, source: ItemRef, relation: Relation, target: ItemRef, state: LinkState
) -> Link:
    return Link(
        link_id=link_id,
        source_ref=source,
        relation=relation,
        target_ref=target,
        kind=LinkKind.GUESSED,
        state=state,
        score=0.8,
        evidence="shared schema field and terms",
        valid_from=VALID_FROM,
    )


@pytest.fixture
def link_graph() -> tuple[list[Link], dict[str, str]]:
    """Links around clause 4.2.1 reaching a test at 3 steps and one more item at 4 steps."""
    clause = ItemRef(item_type=ItemType.CLAUSE, key=CLAUSE)
    requirement = ItemRef(item_type=ItemType.REQUIREMENT, key="REQ-1")
    spec = ItemRef(item_type=ItemType.SPEC, key="SPEC-1")
    story = ItemRef(item_type=ItemType.STORY, key="PAY-101")
    code = ItemRef(item_type=ItemType.CODE, key="code:inbound")
    test = ItemRef(item_type=ItemType.TEST, key="test:inbound")
    other_code = ItemRef(item_type=ItemType.CODE, key="code:other")
    cards_spec = ItemRef(item_type=ItemType.SPEC, key="SPEC-CARDS")
    review_spec = ItemRef(item_type=ItemType.SPEC, key="SPEC-REVIEW")
    links = [
        _stated("l1", requirement, Relation.CONSTRAINED_BY, clause),
        _guessed("l2", spec, Relation.DERIVED_FROM, clause, LinkState.PROPOSED),
        _stated("l3", story, Relation.SPECIFIED_BY, spec),
        _stated("l4", spec, Relation.IMPLEMENTED_BY, code),
        _stated("l5", code, Relation.VERIFIED_BY, test),
        _stated("l6", other_code, Relation.VERIFIED_BY, test),
        _guessed("l7", cards_spec, Relation.DERIVED_FROM, clause, LinkState.PROPOSED),
        _guessed("l8", review_spec, Relation.DERIVED_FROM, clause, LinkState.REVIEW),
    ]
    domains = {
        CLAUSE: "payments",
        "2026.1:4.2.2": "payments",
        "REQ-1": "payments",
        "SPEC-1": "payments",
        "PAY-101": "payments",
        "code:inbound": "payments",
        "test:inbound": "payments",
        "code:other": "payments",
        "SPEC-CARDS": "cards",
        "SPEC-REVIEW": "payments",
    }
    return links, domains


@pytest.fixture
def links(link_graph: tuple[list[Link], dict[str, str]]) -> FakeLinks:
    """A link store over the graph above."""
    graph, domains = link_graph
    return FakeLinks(graph, domains)


@pytest.fixture
def search(truth: SyntheticDataset) -> FakeSearch:
    """Search over two payments clauses, one cards passage and one unlabelled passage."""
    edition = truth.truth.edition("2026.1")
    by_number = {clause.number: clause for clause in edition.clauses}
    hits = [
        SearchHit(
            passage_id=f"2026.1:{number}",
            passage_type=PassageType.CLAUSE,
            reference=f"2026.1:{number}",
            text=by_number[number].text,
            page=by_number[number].page,
            char_start=by_number[number].md_char_start,
            char_end=by_number[number].md_char_end,
            version="2026.1",
            domain="payments",
            score=1.0 - index / 10,
        )
        for index, number in enumerate(("4.2.1", "4.2.2"))
    ]
    hits.append(
        SearchHit(
            passage_id="cards:limit",
            passage_type=PassageType.PAGE,
            reference="cards-guide:1",
            text="The card limit currency is set per scheme.",
            page=1,
            version="1",
            domain="cards",
        )
    )
    hits.append(
        SearchHit(
            passage_id="unlabelled:1",
            passage_type=PassageType.PAGE,
            reference="memo:1",
            text="An unlabelled memo about currency.",
            version="1",
            domain=None,
        )
    )
    return FakeSearch(hits)


@pytest.fixture
def rules(truth: SyntheticDataset) -> FakeRules:
    """Both editions of the rulebook; every clause belongs to the payments domain."""
    editions: list[Edition] = []
    clauses: dict[tuple[str, str], RuleClause] = {}
    for edition in truth.truth.editions:
        editions.append(
            Edition(
                label=edition.label,
                effective_date=edition.effective_date,
                superseded_from=edition.superseded_from,
                item_id="payments-rulebook",
                version=edition.label,
            )
        )
        for clause in edition.clauses:
            ref = ClauseRef(edition.label, clause.number)
            clauses[(edition.label, clause.number)] = RuleClause(
                clause=Clause(
                    ref=ref,
                    title=clause.title,
                    page=clause.page,
                    char_start=clause.md_char_start,
                    char_end=clause.md_char_end,
                    text=clause.text,
                    structure_score=1.0,
                    parent_ref=ref.parent(),
                ),
                domain="payments",
            )
    return FakeRules(editions, clauses)


@pytest.fixture
def templates() -> FakeTemplates:
    """One governed functional template in two versions."""
    return FakeTemplates(
        [
            Template(
                template_id="functional-spec",
                version=version,
                spec_type="functional",
                body=f"# Template {version}",
                content_sha256=digest * 64,
            )
            for version, digest in (("1.0.0", "a"), ("1.1.0", "b"))
        ]
    )


@pytest.fixture
def coverage() -> FakeCoverage:
    """Four payments rules (two tested), a cards rule and two story gaps."""
    return FakeCoverage(
        CoverageSnapshot(
            rules=(
                RuleCoverage(
                    reference="2026.1:4.2.1",
                    domain="payments",
                    has_test=True,
                    linked_stories=2,
                    stated_links=3,
                    guessed_links=1,
                ),
                RuleCoverage(
                    reference="2026.1:4.2.2",
                    domain="payments",
                    has_test=False,
                    linked_stories=1,
                    stated_links=1,
                    guessed_links=2,
                ),
                RuleCoverage(
                    reference="2026.1:5.1",
                    domain="cards",
                    has_test=False,
                    linked_stories=0,
                    stated_links=0,
                    guessed_links=0,
                ),
            ),
            story_gaps=(
                StoryGap(story_key="PAY-109", summary="Orphan story", domain="payments"),
                StoryGap(story_key="CRD-1", summary="Cards orphan", domain="cards"),
            ),
        )
    )


@pytest.fixture
def ports(
    search: FakeSearch,
    links: FakeLinks,
    rules: FakeRules,
    templates: FakeTemplates,
    coverage: FakeCoverage,
) -> ReadPorts:
    """All five read ports."""
    return ReadPorts(
        search=search, links=links, rules=rules, templates=templates, coverage=coverage
    )


@pytest.fixture
def registry(
    ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> ToolRegistry:
    """The read registry over the fakes, recording to the in-memory audit."""
    return build_read_registry(ports, mapping, audit, clock=fixed_clock)
