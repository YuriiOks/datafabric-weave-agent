"""Rulebook parser: PDF or Markdown to numbered clauses with page and character position.

Position convention (the contract with search and citation)
-----------------------------------------------------------

* **PDF.** Text comes from ``pypdf`` ``extract_text()`` per page (the version is recorded in
  :attr:`ParsedRulebook.text_extractor`; positions are only stable for the same extractor).
  A clause's ``page`` is the one-based page where its *body* starts (the heading line is not
  part of the body; its title is in ``Clause.title``). ``char_start`` and ``char_end`` are
  offsets into that page's extracted text, ``char_end`` exclusive. A body that continues on
  the next pages is not cut: ``Clause.text`` holds all of it, ``char_end`` is clipped to the end
  of the starting page, and the full source text is read back with :func:`clause_source_text`
  (page texts joined by one newline, from ``char_start``, ``len(text)`` characters). For a
  clause that fits on its page, ``page_text[char_start:char_end] == text`` exactly.
* **Markdown.** There are no pages: ``char_start`` and ``char_end`` are offsets into the whole
  file text, and ``page`` is the page the table of contents lists for the clause (1 when it
  lists none).
* The body is trimmed of leading and trailing whitespace; nothing inside it is normalised,
  so line breaks the PDF wrapped stay in ``text``.
* A clause with no body (a pure heading) has ``text == ""`` and an empty span right after
  its heading.
"""

from __future__ import annotations

import io
import logging
import re
from bisect import bisect_right
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date, datetime

import pypdf

from kp.config import Thresholds
from kp.domain import Clause, ClauseRef
from kp.ingest.errors import RulebookParseError
from kp.ingest.headings import Heading, find_markdown_headings, find_pdf_headings
from kp.ingest.models import ParsedRulebook, StructureDecision, TocEntry
from kp.ingest.structure import (
    ClauseDraft,
    classify,
    document_score,
    score_clauses,
    toc_findings,
)
from kp.ingest.toc import find_markdown_toc, find_pdf_toc

logger = logging.getLogger(__name__)

_DECLARED_EDITION = re.compile(
    r"^\s*Edition:?\s+(?P<label>[A-Za-z0-9][A-Za-z0-9._-]*)\s*$", re.MULTILINE
)
_DECLARED_DATE = re.compile(r"^\s*Effective(?:\s+date)?:?\s+(?P<value>\S.*?)\s*$", re.MULTILINE)
_MARKDOWN_HEAD_CHARS = 2000


def extract_pdf_pages(content: bytes) -> tuple[str, ...]:
    """Extract the text of every page of a PDF.

    :param content: The PDF bytes
    :return: One text per page, in order
    :raises RulebookParseError: If the file is not a readable PDF or has no pages; whatever the
        PDF library raises on a damaged file (truncated, bit-flipped) is reported this way
    """
    try:
        reader = pypdf.PdfReader(io.BytesIO(content))
        pages = tuple(page.extract_text() for page in reader.pages)
    except Exception as exc:
        raise RulebookParseError("The rulebook PDF could not be read") from exc
    if not pages:
        raise RulebookParseError("The rulebook PDF has no pages")
    return pages


def clause_source_text(pages: Sequence[str], clause: Clause) -> str:
    """Read a clause's text back from the source pages at its recorded position.

    :param pages: Page texts as returned by :func:`extract_pdf_pages`
    :param clause: A clause parsed from the same PDF
    :return: The source text at ``clause.page`` and ``clause.char_start``, as long as the
        clause text; equals ``clause.text`` when the position is right
    :raises IndexError: If the clause's page does not exist in ``pages``
    """
    joined = "\n".join(pages[clause.page - 1 :])
    return joined[clause.char_start : clause.char_start + len(clause.text)]


def parse_rulebook_pdf(
    content: bytes, *, default_edition: str | None, thresholds: Thresholds
) -> ParsedRulebook:
    """Split a rulebook PDF into clauses.

    :param content: The PDF bytes
    :param default_edition: The edition the reviewed source item carries. When given it is
        authoritative: clauses are labelled with it, and a document that states another edition
        is capped at the review decision. When ``None`` the document's own label is used.
    :param thresholds: Structure thresholds from settings
    :return: The clauses with structure score, decision and findings
    :raises RulebookParseError: If the PDF is unreadable or no edition label can be found
    """
    pages = extract_pdf_pages(content)
    toc, toc_pages = find_pdf_toc(pages)
    source = _Source.of(pages, has_pages=True, extractor=f"pypdf {pypdf.__version__}")
    headings = find_pdf_headings(pages, source.offsets, toc_pages, {e.number for e in toc})
    return _build(source, headings, toc, default_edition, thresholds)


def parse_rulebook_markdown(
    content: bytes | str, *, default_edition: str | None, thresholds: Thresholds
) -> ParsedRulebook:
    """Split a Markdown rulebook into clauses.

    :param content: The Markdown source, UTF-8 if bytes
    :param default_edition: The edition the reviewed source item carries; authoritative when
        given (see :func:`parse_rulebook_pdf`)
    :param thresholds: Structure thresholds from settings
    :return: The clauses with structure score, decision and findings
    :raises RulebookParseError: If the bytes are not UTF-8 or no edition label can be found
    """
    try:
        text = content if isinstance(content, str) else content.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise RulebookParseError("The rulebook Markdown is not valid UTF-8") from exc
    source = _Source.of([text], has_pages=False, extractor="markdown source")
    headings = find_markdown_headings(text)
    return _build(source, headings, find_markdown_toc(text), default_edition, thresholds)


@dataclass(frozen=True)
class _Source:
    """Page texts, the string they join into, and where each page starts in it."""

    pages: tuple[str, ...]
    text: str
    offsets: tuple[int, ...]
    has_pages: bool
    extractor: str

    @classmethod
    def of(cls, pages: Sequence[str], *, has_pages: bool, extractor: str) -> _Source:
        starts = [0]
        for page in pages[:-1]:
            starts.append(starts[-1] + len(page) + 1)
        return cls(tuple(pages), "\n".join(pages), tuple(starts), has_pages, extractor)

    @property
    def head(self) -> str:
        return self.pages[0] if self.has_pages else self.text[:_MARKDOWN_HEAD_CHARS]


def _build(
    source: _Source,
    headings: Sequence[Heading],
    toc: Sequence[TocEntry],
    default_edition: str | None,
    thresholds: Thresholds,
) -> ParsedRulebook:
    declared_edition, declared_date = _declared(source.head)
    edition = default_edition or declared_edition
    if edition is None:
        raise RulebookParseError("The rulebook does not state its edition and none was given")
    anomalies: list[str] = []
    edition_mismatch = declared_edition is not None and declared_edition != edition
    if edition_mismatch:
        anomalies.append(f"document states edition {declared_edition}, expected {edition}")
    drafts = _drafts(source, _drop_duplicates(headings, anomalies))
    scores = score_clauses(drafts, toc, check_pages=source.has_pages)
    score = document_score(scores, drafts, toc)
    toc_matches, findings = toc_findings(drafts, toc)
    anomalies.extend(findings)
    if not drafts:
        anomalies.append("no numbered clause headings found")
    decision = classify(score, thresholds)
    if decision is StructureDecision.PROCEED and (not toc_matches or edition_mismatch):
        decision = StructureDecision.REVIEW
    listed_pages = {} if source.has_pages else {e.number: e.page for e in toc if e.page}
    clauses = tuple(
        _clause(edition, draft, clause_score, listed_pages.get(draft.number))
        for draft, clause_score in zip(drafts, scores, strict=True)
    )
    logger.info(
        "Rulebook parsed",
        extra={
            "edition": edition,
            "clauses": len(clauses),
            "toc_entries": len(toc),
            "structure_score": round(score, 4),
            "decision": decision.value,
        },
    )
    return ParsedRulebook(
        edition=edition,
        declared_edition=declared_edition,
        declared_effective_date=declared_date,
        toc=tuple(toc),
        clauses=clauses,
        structure_score=score,
        decision=decision,
        toc_matches=toc_matches,
        anomalies=tuple(anomalies),
        text_extractor=source.extractor,
    )


def _drop_duplicates(headings: Sequence[Heading], anomalies: list[str]) -> list[Heading]:
    seen: set[str] = set()
    unique = []
    for heading in headings:
        if heading.number in seen:
            anomalies.append(f"heading {heading.number} appears more than once; later one ignored")
            continue
        seen.add(heading.number)
        unique.append(heading)
    return unique


def _drafts(source: _Source, headings: Sequence[Heading]) -> list[ClauseDraft]:
    if not headings:
        return []
    ends = [heading.start for heading in headings[1:]]
    ends.append(len(source.text))
    return [
        _draft(source, heading, source.text[heading.end : end])
        for heading, end in zip(headings, ends, strict=True)
    ]


def _draft(source: _Source, heading: Heading, region: str) -> ClauseDraft:
    body = region.strip()
    if body:
        start = heading.end + len(region) - len(region.lstrip())
        end = start + len(body)
        page_index = bisect_right(source.offsets, start) - 1
    else:
        start = end = heading.end
        page_index = heading.page - 1
    base = source.offsets[page_index]
    page_end = base + len(source.pages[page_index])
    return ClauseDraft(
        number=heading.number,
        title=heading.title,
        heading_page=heading.page,
        page=page_index + 1,
        char_start=start - base,
        char_end=min(end, page_end) - base,
        text=source.text[start:end],
    )


def _clause(edition: str, draft: ClauseDraft, score: float, page: int | None) -> Clause:
    ref = ClauseRef(edition, draft.number)
    return Clause(
        ref=ref,
        title=draft.title,
        page=page or draft.page,
        char_start=draft.char_start,
        char_end=draft.char_end,
        text=draft.text,
        structure_score=score,
        parent_ref=ref.parent(),
    )


def _declared(head: str) -> tuple[str | None, date | None]:
    edition = _DECLARED_EDITION.search(head)
    effective = _DECLARED_DATE.search(head)
    return (
        edition["label"] if edition else None,
        _parse_date(effective["value"]) if effective else None,
    )


def _parse_date(value: str) -> date | None:
    try:
        return date.fromisoformat(value)
    except ValueError:
        pass
    try:
        return datetime.strptime(value, "%d %B %Y").date()
    except ValueError:
        return None
