"""The small pieces the pages are built from: form values, links, identities and states."""

from __future__ import annotations

from datetime import UTC, date, datetime
from pathlib import Path

import pytest

from kp.errors import AccessForbiddenError, ConfigurationError, InvalidClauseRefError, KpError
from kp.links import UnknownClauseError
from kp.tools import (
    IdentityMapping,
    InvalidToolArgumentsError,
    LinkStoreUnavailableError,
    build_caller,
)
from kp.web.errors import InvalidInputError, Problem, ProblemKind, problem_from
from kp.web.identity import LocalIdentity, Viewer, load_user_names, session_id_for
from kp.web.query import QueryForm
from kp.web.render import Links, format_moment, format_number, format_percent, format_words
from kp.web.settings import WebSettings, load_web_settings
from kp.writeback import StoryNotFoundError


def test_text_is_trimmed_and_an_absent_field_is_empty() -> None:
    form = QueryForm({"q": "  currency  "})

    assert form.text("q") == "currency"
    assert form.text("missing") == ""


def test_a_date_is_read_or_refused_with_the_field_named() -> None:
    form = QueryForm({"as_at": "2026-11-16", "bad": "16/11/2026", "blank": " "})

    assert form.day("as_at", "As at") == date(2026, 11, 16)
    assert form.day("blank", "As at") is None
    with pytest.raises(InvalidInputError, match="Starting date must be a date"):
        form.day("bad", "Starting date")


def test_a_number_stays_within_its_bounds() -> None:
    form = QueryForm({"n": "7", "big": "500", "neg": "-3", "word": "x"})

    assert form.number("n", "N", default=0, low=0, high=10) == 7
    assert form.number("absent", "N", default=4, low=0, high=10) == 4
    for name in ("big", "neg", "word"):
        with pytest.raises(InvalidInputError, match="whole number from 0 to 10"):
            form.number(name, "N", default=0, low=0, high=10)


def test_links_leave_out_empty_values_and_carry_the_chosen_user() -> None:
    assert Links(None).to("/rule", number="4.2.1", as_at=None, edition="") == "/rule?number=4.2.1"
    assert Links(None).to("/audit") == "/audit"
    assert Links("user-a").to("/rule", number="4.2.1") == "/rule?number=4.2.1&user=user-a"
    assert Links("user-a").to("/") == "/?user=user-a"


def test_values_are_written_for_people() -> None:
    assert format_moment(datetime(2026, 11, 20, 9, 5, tzinfo=UTC)) == "2026-11-20 09:05 UTC"
    assert format_moment(None) == "-"
    assert format_percent(0.953) == "95%"
    assert format_number(None) == "-"
    assert format_number(1.234, 2) == "1.23"
    assert format_words("items_have_source") == "Items have source"


def test_each_kind_of_failure_becomes_one_of_four_states_without_echoing_the_request() -> None:
    expected: list[tuple[KpError, ProblemKind, int]] = [
        (AccessForbiddenError("secret detail"), ProblemKind.FORBIDDEN, 403),
        (InvalidInputError("Enter a date."), ProblemKind.INVALID, 400),
        (InvalidToolArgumentsError("number: secret"), ProblemKind.INVALID, 400),
        (InvalidClauseRefError("secret"), ProblemKind.INVALID, 400),
        (UnknownClauseError("Clause 1:2 is not loaded"), ProblemKind.MISSING, 404),
        (StoryNotFoundError("The story is not in the store"), ProblemKind.MISSING, 404),
        (LinkStoreUnavailableError("down"), ProblemKind.UNAVAILABLE, 503),
        (KpError("secret detail"), ProblemKind.UNAVAILABLE, 503),
    ]

    for error, kind, status in expected:
        problem = problem_from(error)
        assert (problem.kind, problem.status_code) == (kind, status)
        assert "secret" not in problem.message
        assert problem.title


def test_an_unexpected_kind_of_error_is_named_by_class_only() -> None:
    assert "KpError" in problem_from(KpError("anything")).message


def test_a_heading_replaces_the_default_title_only_when_given() -> None:
    plain = Problem(ProblemKind.MISSING, "Nothing matched.")
    settled = Problem(ProblemKind.MISSING, "The story already has a spec.", "Already specified")

    assert plain.title == "Nothing found"
    assert settled.title == "Already specified"
    assert settled.status_code == plain.status_code


def test_a_viewer_without_domains_or_identity_has_no_access() -> None:
    signed_in = Viewer(build_caller(user="a"), frozenset({"payments"}))
    nobody = Viewer(build_caller(user="b"), frozenset())
    anonymous = Viewer(build_caller(user=None), frozenset({"payments"}))

    assert signed_in.has_access
    assert not nobody.has_access
    assert not anonymous.has_access
    assert signed_in.may_read("payments")
    assert not signed_in.may_read("cards")
    assert not signed_in.may_read(None)  # an unlabelled item is visible to nobody


def test_the_local_selector_starts_as_the_user_with_the_widest_access() -> None:
    directory = IdentityMapping({"a": ["x"], "b": ["x", "y"], "c": []})

    identity = LocalIdentity.for_directory(("a", "b", "c"), directory)

    assert identity.selectable_users == ("a", "b", "c")
    with pytest.raises(ConfigurationError):
        LocalIdentity.for_directory((), directory)


def test_the_users_of_an_identity_mapping_are_listed_and_bad_files_are_refused(
    tmp_path: Path,
) -> None:
    good = tmp_path / "good.yaml"
    good.write_text("version: 1\nusers:\n  zed: {domains: []}\n  amy: {domains: [a]}\n")
    empty = tmp_path / "empty.yaml"
    empty.write_text("version: 1\n")
    broken = tmp_path / "broken.yaml"
    broken.write_text("users: [unclosed")

    assert load_user_names(good) == ("amy", "zed")
    for path in (empty, broken, tmp_path / "absent.yaml"):
        with pytest.raises(ConfigurationError):
            load_user_names(path)


def test_the_audit_session_of_a_user_is_stable_and_fits_the_label_limit() -> None:
    assert session_id_for("user-a") == "web-user-a"
    assert len(session_id_for("u" * 300)) == 128


def test_web_settings_default_to_the_identity_header_of_the_agent_servers(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("KP_WEB_IDENTITY_HEADER", raising=False)
    assert load_web_settings().identity_header == "X-KP-Caller"

    monkeypatch.setenv("KP_WEB_IDENTITY_HEADER", "X-Other-Header")
    assert load_web_settings() == WebSettings(identity_header="X-Other-Header")

    monkeypatch.setenv("KP_WEB_IDENTITY_HEADER", "not a header name")
    with pytest.raises(ConfigurationError, match="identity_header"):
        load_web_settings()
