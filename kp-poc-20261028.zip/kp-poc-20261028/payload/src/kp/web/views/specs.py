"""Specs: pick a story, draft its spec, and check every rule statement's citations.

Drafting only reads: nothing is written to a repository or to the tracker from this page. The
pull request record shown is whatever an earlier publication left for the story.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

from kp.domain import ClauseRef, Spec, Story
from kp.errors import AccessForbiddenError, InvalidClauseRefError, KpError
from kp.links.rules import loaded_story_keys
from kp.web.errors import Problem, ProblemKind, problem_from
from kp.web.identity import Viewer
from kp.web.query import QueryForm
from kp.web.state import WebState
from kp.writeback import (
    CitationReport,
    SpecRepository,
    canonical_reference,
    draft_spec,
    extract_references,
    load_story,
)
from kp.writeback import Problem as CitationProblem
from kp.writeback.cli import DEFAULT_SPEC_TYPE
from kp.writeback.template import split_front_matter, split_sections

# The two ways a draft cites, as the citation check reads them: a marker, or the spoken form.
_CITATION = re.compile(
    r"\[ref:\s*(?P<marker>[^\]]+?)\s*\]"
    r"|(?<![\w.:-])(?P<edition>(?=[A-Za-z0-9])[A-Za-z0-9._-]*\d[A-Za-z0-9._-]*)\s+clause\s+"
    r"(?P<number>(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))*)\b",
    re.IGNORECASE,
)
_LIST_ITEM = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
_REASONS = {
    CitationProblem.UNCITED: "No citation.",
    CitationProblem.UNRESOLVED: "A citation does not resolve to a clause or a register row.",
    CitationProblem.NOT_RETRIEVED: "The cited material was not retrieved for this draft.",
}


@dataclass(frozen=True, slots=True)
class Segment:
    """A run of text in a drafted line; a citation carries the clause it points at, if any."""

    text: str
    reference: str | None = None
    edition: str | None = None
    number: str | None = None


@dataclass(frozen=True, slots=True)
class Line:
    """One paragraph or list item of a drafted section."""

    segments: tuple[Segment, ...]
    is_item: bool


@dataclass(frozen=True, slots=True)
class Section:
    """A heading of the drafted spec and what stands under it."""

    title: str
    level: int
    lines: tuple[Line, ...]


@dataclass(frozen=True, slots=True)
class CitationRow:
    """One reference the draft cites, and whether it holds up."""

    reference: str
    edition: str | None
    number: str | None
    resolves: bool
    retrieved: bool


@dataclass(frozen=True, slots=True)
class Flagged:
    """A rule statement the citation check does not accept, and why."""

    statement: str
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DraftView:
    """A drafted spec with its citation check."""

    as_at: date
    sections: tuple[Section, ...]
    citations: tuple[CitationRow, ...]
    flagged: tuple[Flagged, ...]
    rule_statements: int
    valid_statements: int
    rate: float
    target: float
    open_items: tuple[str, ...]

    @property
    def meets_target(self) -> bool:
        """True when the citation rate reaches the target."""
        return self.rate >= self.target


@dataclass(frozen=True, slots=True)
class PullRequestRecord:
    """What an earlier publication left for the story."""

    spec: Spec
    valid_citations: int
    total_citations: int


@dataclass(frozen=True, slots=True)
class StoryChoice:
    """A story the viewer may draft for."""

    key: str
    summary: str


@dataclass(frozen=True, slots=True)
class SpecsView:
    """The specs page.

    :ivar stories: The stories the viewer may read.
    :ivar story_key: The story chosen (empty before a choice).
    :ivar draft: The drafted spec; ``None`` before a draft and when drafting failed.
    :ivar draft_problem: Why drafting failed, while the pull request record can still be shown.
    :ivar record: The pull request record of the story; ``None`` when none was opened.
    """

    stories: tuple[StoryChoice, ...] = ()
    story_key: str = ""
    as_at: date | None = None
    draft: DraftView | None = None
    draft_problem: Problem | None = None
    record: PullRequestRecord | None = None
    problem: Problem | None = None


def read_specs(state: WebState, viewer: Viewer, form: QueryForm) -> SpecsView:
    """Draft the spec of the chosen story, if a story was chosen.

    :param state: The shared state
    :param viewer: Who is asking
    :param form: The query string of the request
    :return: The view
    """
    story_key = ""
    as_at: date | None = None
    stories: tuple[StoryChoice, ...] = ()
    try:
        state.require_access(viewer)
        story_key = form.text("story")
        as_at = form.day("as_at", "As at")
        stories = _choices(state, viewer)
        if not story_key:
            return SpecsView(stories=stories, as_at=as_at)
        # A story the viewer may not read is refused whether or not it exists.
        if story_key not in {choice.key for choice in stories}:
            raise AccessForbiddenError("The story is unknown or belongs to a domain not readable")
        record = _record(state, story_key)
        draft, draft_problem = _draft(
            state, viewer, story_key, as_at or state.application.clock.today()
        )
        return SpecsView(stories, story_key, as_at, draft, draft_problem, record)
    except KpError as exc:
        return SpecsView(stories, story_key, as_at, problem=problem_from(exc))


def _choices(state: WebState, viewer: Viewer) -> tuple[StoryChoice, ...]:
    with state.application.database.transaction() as connection:
        stories: list[Story] = [
            load_story(connection, key) for key in loaded_story_keys(connection)
        ]
    return tuple(
        StoryChoice(story.story_key, story.summary)
        for story in stories
        if viewer.may_read(story.domain)
    )


def _record(state: WebState, story_key: str) -> PullRequestRecord | None:
    with state.application.database.transaction() as connection:
        repository = SpecRepository(connection)
        spec = repository.get_by_story(story_key)
        if spec is None:
            return None
        stored = repository.citations(spec.spec_id)
    return PullRequestRecord(spec, sum(1 for item in stored if item.is_valid), len(stored))


def _draft(
    state: WebState, viewer: Viewer, story_key: str, day: date
) -> tuple[DraftView | None, Problem | None]:
    try:
        # The draft rests only on material of the viewer's domains, so neither its text nor its
        # citation rows can show a rule or register row the viewer may not read.
        report = draft_spec(
            story_key,
            runtime=state.application.draft_runtime(),
            publish=False,
            spec_type=DEFAULT_SPEC_TYPE,
            as_at=day,
            viewer_domains=viewer.domains,
        )
    except KpError as exc:
        return None, problem_from(exc)
    if report.skipped:
        return None, Problem(ProblemKind.MISSING, report.skipped, heading="Already specified")
    check = report.citations
    if check is None:
        return None, None
    references = extract_references(report.markdown)
    flagged = tuple(
        Flagged(item.statement, tuple(_REASONS[problem] for problem in item.problems))
        for item in check.flagged
    )
    return (
        DraftView(
            as_at=day,
            sections=_sections(report.markdown),
            citations=_citation_rows(references, check),
            flagged=flagged,
            rule_statements=check.rule_statements,
            valid_statements=check.valid_statements,
            rate=check.rate,
            target=check.target,
            open_items=report.open_items,
        ),
        None,
    )


def _citation_rows(references: tuple[str, ...], check: CitationReport) -> tuple[CitationRow, ...]:
    broken = {ref for item in check.checks for ref in item.unresolved}
    unretrieved = {ref for item in check.checks for ref in item.unretrieved}
    rows = []
    for reference in references:
        edition, number = _clause_parts(reference)
        rows.append(
            CitationRow(
                reference=reference,
                edition=edition,
                number=number,
                resolves=reference not in broken,
                retrieved=reference not in unretrieved,
            )
        )
    return tuple(rows)


def _clause_parts(reference: str) -> tuple[str | None, str | None]:
    try:
        ref = ClauseRef.parse(reference)
    except InvalidClauseRefError:
        return None, None
    return ref.edition, ref.number


def _sections(markdown: str) -> tuple[Section, ...]:
    body = split_front_matter(markdown)[1]
    return tuple(
        Section(section.title, section.level, _lines(section.lines))
        for section in split_sections(body)
        if section.title or any(line.strip() for line in section.lines)
    )


def _lines(raw: tuple[str, ...]) -> tuple[Line, ...]:
    lines: list[Line] = []
    paragraph: list[str] = []

    def flush() -> None:
        if paragraph:
            lines.append(Line(_segments(" ".join(paragraph)), is_item=False))
            paragraph.clear()

    for text in raw:
        stripped = text.strip().removeprefix(">").strip()
        if not stripped:
            flush()
        elif _LIST_ITEM.match(text):
            flush()
            lines.append(Line(_segments(_LIST_ITEM.sub("", text).strip()), is_item=True))
        else:
            paragraph.append(stripped)
    flush()
    return tuple(lines)


def _segments(text: str) -> tuple[Segment, ...]:
    """Split a line at its citations (``[ref: ...]`` or ``2026.1 clause 4.2.1``) to draw links."""
    segments: list[Segment] = []
    position = 0
    for match in _CITATION.finditer(text):
        if match.start() > position:
            segments.append(Segment(text[position : match.start()]))
        reference = canonical_reference(match["marker"] or match.group(0))
        edition, number = _clause_parts(reference)
        segments.append(
            Segment(match.group(0) if match["edition"] else reference, reference, edition, number)
        )
        position = match.end()
    if position < len(text):
        segments.append(Segment(text[position:]))
    return tuple(segments)
