"""Test coverage of rules, and the stories that tie to no requirement or clause."""

from __future__ import annotations

from collections.abc import Iterable
from enum import StrEnum

from kp.domain import ClauseRef, DomainModel, ItemRef, ItemType, Link, LinkKind
from kp.links.graph import LinkGraph, reaches_requirement_or_clause, walk_rule
from kp.links.refs import clause_item
from kp.links.rules import Rule


class CoverageEvidence(StrEnum):
    """How a rule is known to have a test."""

    STATED = "stated"
    GUESSED = "guessed"
    NONE = "none"


class RuleCoverage(DomainModel):
    """One rule with the stories and links behind its coverage answer.

    ``story_count`` is the number of distinct stories connected to the rule through a spec.
    ``stated_links`` and ``guessed_links`` count the distinct links crossed to reach every
    story, spec, code and test of the rule. ``test_evidence`` is ``stated`` when a path to a
    test uses only stated links, ``guessed`` when every path uses a guessed link, and
    ``none`` when no path reaches a test.
    """

    reference: str
    title: str
    story_count: int
    stated_links: int
    guessed_links: int
    test_evidence: CoverageEvidence

    @property
    def has_test(self) -> bool:
        """True when any path, stated or guessed, reaches a test."""
        return self.test_evidence is not CoverageEvidence.NONE


class RulesWithoutTests(DomainModel):
    """The answer to "which rules have no test".

    ``stated_links`` and ``guessed_links`` count the distinct links behind the whole list.
    """

    edition: str
    total_rules: int
    rules: tuple[RuleCoverage, ...]
    stated_links: int
    guessed_links: int

    @property
    def summary(self) -> str:
        """One sentence that states the count and the stated/guessed split."""
        return (
            f"{len(self.rules)} of {self.total_rules} rules in edition {self.edition} have no "
            f"test; the answer rests on {self.stated_links + self.guessed_links} links "
            f"({self.stated_links} stated, {self.guessed_links} guessed)."
        )


class CoverageReport(DomainModel):
    """Rules with and without tests, and the stories tied to no requirement or clause.

    The story list is report-only: it never blocks anything.
    """

    edition: str
    with_tests: tuple[RuleCoverage, ...]
    without_tests: tuple[RuleCoverage, ...]
    stories_without_requirement_or_clause: tuple[str, ...]
    stated_links: int
    guessed_links: int

    @property
    def total_rules(self) -> int:
        """Rules measured."""
        return len(self.with_tests) + len(self.without_tests)


def _count(links: Iterable[Link]) -> tuple[int, int]:
    stated = guessed = 0
    for link in links:
        if link.kind is LinkKind.STATED:
            stated += 1
        else:
            guessed += 1
    return stated, guessed


def rule_coverage(
    graph: LinkGraph, stated_graph: LinkGraph, rule: Rule
) -> tuple[RuleCoverage, dict[str, Link]]:
    """Measure one rule.

    :param graph: The links in use
    :param stated_graph: The same graph restricted to stated links
    :param rule: The rule
    :return: Its coverage and the links behind it, by identity
    """
    clause = clause_item(ClauseRef.parse(rule.reference))
    walk = walk_rule(graph, clause)
    if not walk.tests:
        evidence = CoverageEvidence.NONE
    elif walk_rule(stated_graph, clause).tests:
        evidence = CoverageEvidence.STATED
    else:
        evidence = CoverageEvidence.GUESSED
    stated, guessed = _count(walk.links.values())
    return (
        RuleCoverage(
            reference=rule.reference,
            title=rule.title,
            story_count=len(walk.stories),
            stated_links=stated,
            guessed_links=guessed,
            test_evidence=evidence,
        ),
        walk.links,
    )


def measure_coverage(
    graph: LinkGraph, rules: Iterable[Rule], story_keys: Iterable[str], edition: str
) -> CoverageReport:
    """Measure every rule and every story.

    :param graph: The links in use
    :param rules: The rules to measure
    :param story_keys: Keys of the loaded stories
    :param edition: The edition the rules belong to
    :return: The coverage report
    """
    stated_graph = graph.stated_only()
    covered: list[RuleCoverage] = []
    used: dict[str, Link] = {}
    for rule in rules:
        coverage, links = rule_coverage(graph, stated_graph, rule)
        covered.append(coverage)
        if not coverage.has_test:
            used.update(links)
    stated, guessed = _count(used.values())
    return CoverageReport(
        edition=edition,
        with_tests=tuple(item for item in covered if item.has_test),
        without_tests=tuple(item for item in covered if not item.has_test),
        stories_without_requirement_or_clause=tuple(
            key
            for key in sorted(story_keys)
            if not reaches_requirement_or_clause(graph, ItemRef(item_type=ItemType.STORY, key=key))
        ),
        stated_links=stated,
        guessed_links=guessed,
    )


def rules_without_tests(report: CoverageReport) -> RulesWithoutTests:
    """Narrow a coverage report to the rules that have no test.

    :param report: A coverage report
    :return: The untested rules with the stated/guessed split of the links behind them
    """
    return RulesWithoutTests(
        edition=report.edition,
        total_rules=report.total_rules,
        rules=report.without_tests,
        stated_links=report.stated_links,
        guessed_links=report.guessed_links,
    )
