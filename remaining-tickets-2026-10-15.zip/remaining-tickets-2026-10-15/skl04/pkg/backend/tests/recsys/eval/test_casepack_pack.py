"""Case pack: pinned to its corpus, checked against its profile, round-trips on disk."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app.recsys.eval.casepack.cases import (
    EvidenceKind,
    EvidenceRequirement,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.casepack.lineage import CasePackError
from app.recsys.eval.casepack.pack import (
    CasePack,
    coverage_gaps,
    dump_document,
    dump_pack,
    load_document,
    load_pack,
    validate_pack,
)
from app.recsys.eval.casepack.profiles import SKILL_PROFILE, profile_for
from app.recsys.eval.casepack.split import Partition, SplitManifest

from . import casepack_support as support

ONE = support.component_id(1)
THREE = support.component_id(3)


class CasePackTests(unittest.TestCase):
    def setUp(self) -> None:
        self.corpus = support.corpus()
        self.lineage = self.corpus.lineage
        self.positive = support.case(
            1, lineage=self.lineage, adjudication=support.judged({ONE: RelevanceLabel.relevant})
        )
        self.incomplete = support.case(
            2,
            lineage=self.lineage,
            scenario=Scenario.incomplete_description,
            adjudication=support.judged({THREE: RelevanceLabel.relevant}),
        )

    def test_a_consistent_pack_validates(self) -> None:
        validate_pack(
            support.pack([self.positive, self.incomplete], self.corpus), self.corpus, SKILL_PROFILE
        )
        self.assertIs(profile_for(self.corpus.component_type), SKILL_PROFILE)

    def test_an_unpublished_component_is_refused(self) -> None:
        invented = support.component_id(99)
        case = support.case(
            3,
            lineage=self.lineage,
            adjudication=support.judged({invented: RelevanceLabel.relevant}),
        )
        with self.assertRaisesRegex(CasePackError, "unpublished components"):
            validate_pack(support.pack([case], self.corpus), self.corpus, SKILL_PROFILE)

    def test_prefix_and_scenario_follow_the_profile(self) -> None:
        foreign = support.case(3, lineage=self.lineage, prefix="mcp", scenario=Scenario.ambiguous)
        with self.assertRaisesRegex(CasePackError, "prefix"):
            validate_pack(support.pack([foreign], self.corpus), self.corpus, SKILL_PROFILE)
        conflict = support.case(
            3,
            lineage=self.lineage,
            scenario=Scenario.conflict,
            required_evidence=[
                EvidenceRequirement(kind=EvidenceKind.source_conflict, subject_id=ONE)
            ],
        )
        with self.assertRaisesRegex(CasePackError, "does not allow"):
            validate_pack(support.pack([conflict], self.corpus), self.corpus, SKILL_PROFILE)

    def test_incomplete_description_names_a_weak_description(self) -> None:
        case = support.case(
            3,
            lineage=self.lineage,
            scenario=Scenario.incomplete_description,
            adjudication=support.judged({ONE: RelevanceLabel.relevant}),
        )
        with self.assertRaisesRegex(CasePackError, "weak description"):
            validate_pack(support.pack([case], self.corpus), self.corpus, SKILL_PROFILE)

    def test_the_corpus_pin_is_checked(self) -> None:
        pack = support.pack([self.positive], self.corpus)
        moved = pack.model_copy(update={"corpus_digest": "0" * 64})
        with self.assertRaisesRegex(CasePackError, "not the one the pack pins"):
            validate_pack(moved, self.corpus, SKILL_PROFILE)
        other = support.corpus(access_policy_revision=None)
        with self.assertRaisesRegex(CasePackError, "another lineage"):
            validate_pack(pack, other, SKILL_PROFILE)

    def test_a_case_pinned_elsewhere_is_refused(self) -> None:
        other = support.corpus(access_policy_revision=None).lineage
        stray = support.case(3, lineage=other, scenario=Scenario.ambiguous)
        with self.assertRaises(ValueError):
            support.pack([stray], self.corpus)

    def test_coverage_gaps_list_missing_required_scenarios(self) -> None:
        pack = support.pack([self.positive, self.incomplete], self.corpus)
        gaps = coverage_gaps(pack, SKILL_PROFILE)
        self.assertEqual(
            set(gaps),
            {
                Scenario.hard_negative,
                Scenario.valid_empty,
                Scenario.access_restricted,
                Scenario.source_unavailable,
            },
        )

    def test_round_trips_through_its_directory(self) -> None:
        pack = support.pack(
            [
                self.positive,
                self.incomplete,
                support.case(
                    3,
                    lineage=self.lineage,
                    scenario=Scenario.valid_empty,
                    expected=ExpectedOutcome.valid_empty,
                ),
            ],
            self.corpus,
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name, text in dump_pack(pack).items():
                (root / name).write_text(text, encoding="utf-8")
            self.assertEqual(load_pack(root), pack)
            (root / "skl-0001.yaml").rename(root / "skl-0009.yaml")
            with self.assertRaisesRegex(CasePackError, "holds case"):
                load_pack(root)

    def test_split_round_trips_as_a_document(self) -> None:
        split = SplitManifest(
            seed="seed-1",
            weights={Partition.development: 3, Partition.final_test: 1},
            assignments={"need-1": Partition.final_test},
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "split.yaml"
            path.write_text(dump_document(split), encoding="utf-8")
            self.assertEqual(load_document(path, SplitManifest), split)
            path.write_text("seed: [", encoding="utf-8")
            with self.assertRaises(CasePackError):
                load_document(path, CasePack)
