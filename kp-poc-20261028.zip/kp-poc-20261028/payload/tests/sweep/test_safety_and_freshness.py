"""US-08 and US-09: stale or failing sources are visible; re-runs and retries are safe."""

from __future__ import annotations

import logging
from collections.abc import Sequence

import pytest
from sqlalchemy import func, select

from kp.config import Thresholds
from kp.domain import ChangeKind, ItemKey, RunOutcome, SourceKind
from kp.store import schema as tables
from kp.sweep import (
    AlertKind,
    FreshnessReport,
    RateLimitPolicy,
    RawStoreConflictError,
    SweepStore,
    TargetStatus,
    check_freshness,
)

from .conftest import Harness
from .support import (
    MemoryRawStore,
    ProcessorCrashError,
    ScriptedReader,
    entry,
    governed_attributes,
    rate_limited,
    unavailable,
)

JIRA = SourceKind.JIRA
LIBRARY = SourceKind.DOCUMENT_LIBRARY
GITHUB = SourceKind.GITHUB


def _reader(count: int, kind: SourceKind = GITHUB) -> ScriptedReader:
    reader = ScriptedReader(kind)
    reader.add(*(entry(kind, f"file-{n}", "1") for n in range(count)))
    return reader


def _count(harness: Harness, table: str) -> int:
    with harness.database.transaction() as connection:
        return connection.execute(
            select(func.count()).select_from(tables.metadata.tables[table])
        ).scalar_one()


def _freshness(harness: Harness, expected: Sequence[SourceKind] = ()) -> FreshnessReport:
    with harness.database.transaction() as connection:
        return check_freshness(SweepStore(connection), now=harness.clock.now(), expected=expected)


# US-09 -------------------------------------------------------------------------------------


@pytest.mark.parametrize("honour_cursor", [True, False])
def test_us09_rerun_with_no_changes_creates_no_rows_and_no_work(
    harness: Harness, honour_cursor: bool
) -> None:
    reader = _reader(3)
    reader.honour_cursor = honour_cursor
    harness.sweep(reader)
    before = {
        name: _count(harness, name) for name in ("source_item", "change_event", "review_item")
    }

    summary = harness.sweep(reader)

    assert summary.work_items == ()
    assert summary.versions_recorded == 0
    assert summary.state_changes == 0
    after = {name: _count(harness, name) for name in before}
    assert after == before
    assert summary.outcome is RunOutcome.SUCCEEDED


def test_us09_stopped_run_restarts_from_the_last_saved_point_without_duplicates(
    harness: Harness,
) -> None:
    harness.page_size = 2
    reader = _reader(5)
    harness.processor.crash_on = {reader.entries[3][0].key}

    with pytest.raises(ProcessorCrashError):
        harness.sweep(reader)

    # Page one (two items) is committed with its cursor; page two rolled back whole.
    assert len(harness.versions(GITHUB)) == 2
    with harness.database.transaction() as connection:
        cursor = SweepStore(connection).load_cursor(GITHUB, "")
        runs = connection.execute(select(tables.run.c.outcome)).scalars().all()
    assert cursor is not None
    assert cursor.position == "2"
    assert cursor.last_success_at is None
    assert runs == [RunOutcome.FAILED.value]

    harness.processor.crash_on = set()
    summary = harness.sweep(reader)

    assert [item.key.item_id for item in summary.work_items] == ["file-2", "file-3", "file-4"]
    assert len(harness.versions(GITHUB)) == 5
    new_events = harness.events(ChangeKind.NEW)
    assert sorted(e.item_id for e in new_events) == [f"file-{n}" for n in range(5)]
    assert summary.outcome is RunOutcome.SUCCEEDED


def test_us09_rate_limited_source_is_waited_for_as_instructed_then_finishes(
    harness: Harness,
) -> None:
    reader = _reader(2)
    reader.fail_next(rate_limited(30), rate_limited(60))

    summary = harness.sweep(reader)

    assert harness.sleeper.waits == [30, 60]
    assert summary.outcome is RunOutcome.SUCCEEDED
    assert len(summary.work_items) == 2


def test_us09_source_that_keeps_limiting_is_finished_later_not_failed(harness: Harness) -> None:
    harness.page_size = 2
    reader = _reader(4)
    reader.fail_next(*[rate_limited(10)] * 10, after_calls=3)

    first = harness.sweep(reader)

    assert first.outcome is RunOutcome.PARTIAL
    (target,) = first.targets
    assert target.status is TargetStatus.DEFERRED
    assert target.pages == 1
    assert harness.sleeper.waits == [10, 10, 10]
    assert first.alerts == ()
    with harness.database.transaction() as connection:
        cursor = SweepStore(connection).load_cursor(GITHUB, "")
    assert cursor is not None
    assert cursor.consecutive_failures == 0
    assert cursor.position == "2"
    assert len(harness.versions(GITHUB)) == 2

    reader.faults.clear()
    second = harness.sweep(reader)

    assert second.outcome is RunOutcome.SUCCEEDED
    assert [item.key.item_id for item in second.work_items] == ["file-2", "file-3"]
    assert len(harness.versions(GITHUB)) == 4


def test_us09_a_wait_longer_than_the_budget_defers_without_sleeping(harness: Harness) -> None:
    harness.rate_limit = RateLimitPolicy(max_waits=3, max_wait_seconds=120)
    reader = _reader(2)
    reader.fail_next(rate_limited(3600))

    summary = harness.sweep(reader)

    assert harness.sleeper.waits == []
    assert summary.targets[0].status is TargetStatus.DEFERRED


def test_us09_one_source_failing_does_not_stop_the_others(harness: Harness) -> None:
    broken = _reader(2, JIRA)
    broken.fail_next(unavailable())
    healthy = _reader(2, GITHUB)

    summary = harness.sweep(broken, healthy)

    statuses = {t.source: t.status for t in summary.targets}
    assert statuses == {JIRA: TargetStatus.FAILED, GITHUB: TargetStatus.COMPLETED}
    assert summary.outcome is RunOutcome.PARTIAL
    assert len(harness.versions(GITHUB)) == 2


def test_us09_item_that_vanished_between_listing_and_fetch_is_skipped(harness: Harness) -> None:
    reader = _reader(2)
    reader.entries[0] = (reader.entries[0][0], None)

    summary = harness.sweep(reader)

    assert [item.key.item_id for item in summary.work_items] == ["file-1"]
    assert summary.outcome is RunOutcome.SUCCEEDED


class _ConflictingRawStore(MemoryRawStore):
    """A raw store that already holds other bytes under every key."""

    def put(self, key: ItemKey, content: bytes) -> str:
        raise RawStoreConflictError("Other bytes are already stored")


def test_us09_raw_store_conflict_for_a_new_version_is_counted_and_the_sweep_goes_on(
    harness: Harness,
) -> None:
    harness.raw_store = _ConflictingRawStore()

    summary = harness.sweep(_reader(2))

    assert summary.conflicts == 2
    assert summary.versions_recorded == 0
    assert summary.work_items == ()
    assert summary.outcome is RunOutcome.SUCCEEDED
    assert harness.versions(GITHUB) == []


def test_us08_an_item_that_always_fails_to_process_reaches_the_alert_after_three_runs(
    harness: Harness,
) -> None:
    reader = _reader(1)
    harness.processor.crash_on = {reader.entries[0][0].key}

    for _ in range(2):
        with pytest.raises(ProcessorCrashError):
            harness.sweep(reader)
    assert _freshness(harness).alerts == ()
    with pytest.raises(ProcessorCrashError):
        harness.sweep(reader)

    (alert,) = _freshness(harness).alerts
    assert alert.source is GITHUB
    assert alert.consecutive_failures == 3
    assert alert.kind is AlertKind.REPEATED_FETCH_FAILURES


def test_us09_different_bytes_for_a_stored_version_are_refused_and_counted(
    harness: Harness,
) -> None:
    reader = _reader(1)
    harness.sweep(reader)
    reader.add(entry(GITHUB, "file-0", "1", content=b"rewritten"))

    summary = harness.sweep(reader)

    assert summary.conflicts == 1
    assert summary.work_items == ()


# US-08 -------------------------------------------------------------------------------------


def test_us08_source_without_a_recent_success_is_listed_with_its_last_success(
    harness: Harness,
) -> None:
    harness.sweep(_reader(1, LIBRARY))
    swept_at = harness.clock.now()

    harness.advance(hours=5, minutes=59)
    assert _freshness(harness).stale == ()

    harness.advance(minutes=2)
    report = _freshness(harness)

    (stale,) = report.stale
    assert stale.source is LIBRARY
    assert stale.last_success_at == swept_at
    assert stale.age_hours == pytest.approx(6 + 1 / 60)
    assert not report.is_healthy


def test_us08_expected_source_that_was_never_swept_is_listed(harness: Harness) -> None:
    harness.sweep(_reader(1, LIBRARY))

    report = _freshness(harness, [LIBRARY, JIRA])

    (stale,) = report.stale
    assert stale.source is JIRA
    assert stale.last_success_at is None


def test_us08_a_successful_sweep_clears_staleness(harness: Harness) -> None:
    reader = _reader(1, LIBRARY)
    harness.sweep(reader)
    harness.advance(hours=8)
    assert _freshness(harness).stale

    harness.sweep(reader)

    assert _freshness(harness).is_healthy


def test_us08_three_failed_fetches_raise_an_alert(
    harness: Harness, caplog: pytest.LogCaptureFixture
) -> None:
    reader = _reader(1)
    summaries = []
    with caplog.at_level(logging.WARNING, logger="kp.sweep"):
        for _ in range(3):
            reader.fail_next(unavailable())
            summaries.append(harness.sweep(reader))
            harness.advance(minutes=10)

    assert [len(s.alerts) for s in summaries] == [0, 0, 1]
    alert = summaries[2].alerts[0]
    assert (alert.source, alert.consecutive_failures) == (GITHUB, 3)
    assert summaries[2].outcome is RunOutcome.FAILED
    assert any(
        r.levelno == logging.ERROR and "alert raised" in r.getMessage() for r in caplog.records
    )
    report = _freshness(harness)
    assert [(a.source, a.consecutive_failures) for a in report.alerts] == [(GITHUB, 3)]


def test_us08_failure_during_fetch_counts_and_two_failures_do_not_alert(harness: Harness) -> None:
    reader = _reader(1)

    for _ in range(2):
        reader.fail_next(unavailable(), after_calls=1)
        summary = harness.sweep(reader)
        assert summary.alerts == ()

    assert _freshness(harness).alerts == ()
    with harness.database.transaction() as connection:
        cursor = SweepStore(connection).load_cursor(GITHUB, "")
    assert cursor is not None
    assert cursor.consecutive_failures == 2
    assert harness.versions(GITHUB) == []


def test_us08_success_resets_the_failure_count(harness: Harness) -> None:
    reader = _reader(1)
    for _ in range(2):
        reader.fail_next(unavailable())
        harness.sweep(reader)

    harness.sweep(reader)
    reader.fail_next(unavailable())
    summary = harness.sweep(reader)

    assert summary.alerts == ()
    with harness.database.transaction() as connection:
        cursor = SweepStore(connection).load_cursor(GITHUB, "")
    assert cursor is not None
    assert cursor.consecutive_failures == 1


def test_us08_alert_threshold_comes_from_settings_thresholds(harness: Harness) -> None:
    reader = _reader(1)
    reader.fail_next(unavailable())
    harness.sweep(reader)

    with harness.database.transaction() as connection:
        report = check_freshness(
            SweepStore(connection),
            now=harness.clock.now(),
            thresholds=Thresholds(fetch_failures_before_alert=1),
        )

    assert len(report.alerts) == 1


def test_us08_a_later_sweep_finds_a_change_by_polling_the_cursor_alone(
    harness: Harness,
) -> None:
    # The sweep takes no notification input at all, so a source that stopped announcing
    # changes cannot hide them: the next scheduled sweep polls from the saved cursor.
    reader = ScriptedReader(LIBRARY)
    reader.add(entry(LIBRARY, "first-guide", "1", attributes=governed_attributes()))
    harness.sweep(reader)
    harness.advance(hours=7)
    reader.add(entry(LIBRARY, "late-guide", "1", attributes=governed_attributes()))

    summary = harness.sweep(reader)

    assert [item.key.item_id for item in summary.work_items] == ["late-guide"]
