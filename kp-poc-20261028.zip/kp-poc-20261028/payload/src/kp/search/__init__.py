"""Passages, keyword and optional vector search, exact-reference lookup, rule as at a date."""

from kp.search.embedding import (
    EMBEDDING_BATCH_SIZE,
    Embedder,
    HashingEmbedder,
    embed_pending,
    embed_texts,
)
from kp.search.errors import (
    ClauseNotFoundError,
    EmbeddingError,
    NoEditionInForceError,
    SearchError,
)
from kp.search.indexing import index_clauses, index_requirements, index_stories
from kp.search.models import RuleText, SearchHit, SearchResponse, quote_matches
from kp.search.pages import PageIndex, fill_missing_pages
from kp.search.passages import (
    CodeFile,
    DocumentText,
    SchemaDocument,
    clause_passages,
    code_passages,
    page_passages,
    requirement_passage,
    schema_field_passages,
    story_passages,
)
from kp.search.service import IndexReport, SearchService
from kp.search.settings import SearchSettings
from kp.search.store import PassageStore
from kp.search.tokens import count_tokens

__all__ = [
    "EMBEDDING_BATCH_SIZE",
    "ClauseNotFoundError",
    "CodeFile",
    "DocumentText",
    "Embedder",
    "EmbeddingError",
    "HashingEmbedder",
    "IndexReport",
    "NoEditionInForceError",
    "PageIndex",
    "PassageStore",
    "RuleText",
    "SchemaDocument",
    "SearchError",
    "SearchHit",
    "SearchResponse",
    "SearchService",
    "SearchSettings",
    "clause_passages",
    "code_passages",
    "count_tokens",
    "embed_pending",
    "embed_texts",
    "fill_missing_pages",
    "index_clauses",
    "index_requirements",
    "index_stories",
    "page_passages",
    "quote_matches",
    "requirement_passage",
    "schema_field_passages",
    "story_passages",
]
