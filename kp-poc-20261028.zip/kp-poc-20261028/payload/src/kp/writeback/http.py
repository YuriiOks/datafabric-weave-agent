"""Shared HTTP plumbing of the REST publisher and the REST Jira client."""

from __future__ import annotations

import httpx
from pydantic import SecretStr

from kp.config import Settings

DEFAULT_TIMEOUT_SECONDS = 30.0
HTTP_OK = 200
HTTP_CREATED = 201
HTTP_NO_CONTENT = 204
HTTP_NOT_FOUND = 404
HTTP_UNPROCESSABLE = 422
HTTP_REQUEST_TIMEOUT = 408
HTTP_TOO_MANY_REQUESTS = 429
HTTP_SERVER_ERROR = 500


def is_transient_status(status: int) -> bool:
    """Tell whether a response status means "try again later".

    :param status: HTTP status code
    :return: True for timeouts, rate limiting and server-side failures
    """
    return status in (HTTP_REQUEST_TIMEOUT, HTTP_TOO_MANY_REQUESTS) or status >= HTTP_SERVER_ERROR


def build_client(
    base_url: str,
    *,
    token: SecretStr | None,
    token_header: str | None = None,
    transport: httpx.BaseTransport | None = None,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> httpx.Client:
    """Build an HTTP client for one REST API.

    The credential travels in ``token_header`` when one is configured (the per-tool source
    credential header), otherwise as a bearer token.

    :param base_url: API root, from settings
    :param token: The credential, if the API needs one
    :param token_header: Header name for the credential; ``None`` for ``Authorization: Bearer``
    :param transport: A transport to use instead of the network (tests)
    :param timeout: Per-request timeout in seconds
    :return: A client; the caller closes it
    """
    headers = {"Accept": "application/json"}
    if token is not None:
        secret = token.get_secret_value()
        if token_header:
            headers[token_header] = secret
        else:
            headers["Authorization"] = f"Bearer {secret}"
    return httpx.Client(base_url=base_url, headers=headers, transport=transport, timeout=timeout)


def source_token_header(settings: Settings) -> str | None:
    """Return the configured per-tool credential header name, if any.

    :param settings: Platform settings
    :return: The header name or ``None``
    """
    header = (settings.source_token_header or "").strip()
    return header or None
