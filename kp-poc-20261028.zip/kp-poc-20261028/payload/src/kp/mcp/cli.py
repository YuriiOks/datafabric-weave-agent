"""``kp serve-read`` and ``kp serve-write``: stdio by default, ``--http PORT`` for HTTP.

The integrator calls :func:`add_parser` with a :class:`ServeWiring` that builds the real
port implementations; this module never imports another lane.
"""

from __future__ import annotations

import argparse
import ipaddress
import logging
import os
import sys
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import TextIO, TypeVar

from kp.config import Settings, load_settings
from kp.errors import ConfigurationError
from kp.log import configure_logging
from kp.mcp.http import MAX_BODY_BYTES, READ_MAX_BODY_BYTES, McpHttpGateway, create_http_server
from kp.mcp.identity import IdentityHeaders, caller_from_environment
from kp.mcp.server import McpServer
from kp.mcp.servers import build_read_server, build_write_server
from kp.mcp.stdio import serve_stdio
from kp.store import Database
from kp.tools import DatabaseAuditSink, IdentityMapping, ReadPorts, ToolObserver, WriteToolPort

logger = logging.getLogger(__name__)

_T = TypeVar("_T")

READ_COMMAND = "serve-read"
WRITE_COMMAND = "serve-write"
DEFAULT_HOST = "127.0.0.1"
EXIT_OK = 0
EXIT_CONFIGURATION = 2


@dataclass(frozen=True, slots=True)
class ServeWiring:
    """How the integrator supplies the real ports.

    :param read_ports: Builds the five read ports; required for ``serve-read``
    :param write_port: Builds the write tools; required for ``serve-write``
    :param read_observer: Builds the observer told about every successful read call
    """

    read_ports: Callable[[Settings, Database], ReadPorts] | None = None
    write_port: Callable[[Settings, Database], WriteToolPort] | None = None
    read_observer: Callable[[Settings, Database], ToolObserver] | None = None


def add_parser(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    *,
    wiring: ServeWiring | None = None,
) -> None:
    """Register ``serve-read`` and ``serve-write``.

    Each parsed namespace gets a ``handler`` attribute: call ``args.handler(args)`` to run the
    command and use its return value as the exit status.

    :param subparsers: The subparsers action of the ``kp`` parser
    :param wiring: Builders for the real ports; without them the commands exit with status 2
    """
    for command, help_text, handler in (
        (READ_COMMAND, "Serve the read tools for agents (MCP)", handle_serve_read),
        (WRITE_COMMAND, "Serve the write tools for agents (MCP)", handle_serve_write),
    ):
        parser = subparsers.add_parser(command, help=help_text)
        parser.add_argument(
            "--http",
            type=int,
            metavar="PORT",
            default=None,
            help="serve HTTP on this port instead of stdio",
        )
        parser.add_argument("--host", default=DEFAULT_HOST, help="HTTP bind address")
        parser.add_argument(
            "--trusted-proxy",
            action="store_true",
            help="allow a non-loopback --host: a proxy that authenticates users sets the "
            "identity header and is the only client that can reach this port",
        )
        parser.add_argument(
            "--identity-header",
            default=IdentityHeaders().user,
            help="HTTP header that carries the caller identity",
        )
        parser.set_defaults(handler=_bind(handler, wiring))


def _bind(
    handler: Callable[..., int], wiring: ServeWiring | None
) -> Callable[[argparse.Namespace], int]:
    def run(args: argparse.Namespace) -> int:
        return handler(args, wiring)

    return run


def handle_serve_read(
    args: argparse.Namespace,
    wiring: ServeWiring | None,
    *,
    settings: Settings | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    environ: Mapping[str, str] | None = None,
) -> int:
    """Run ``kp serve-read``.

    :param args: Parsed arguments (``http``, ``host``, ``trusted_proxy``, ``identity_header``)
    :param wiring: Builders for the real ports
    :param settings: Settings; loaded from the environment when omitted
    :param stdin: Input stream for stdio mode; defaults to standard input
    :param stdout: Output stream for stdio mode; defaults to standard output
    :param environ: Environment carrying the caller identity; defaults to ``os.environ``
    :return: The process exit status
    """
    return _run(
        args,
        settings=settings,
        stdin=stdin,
        stdout=stdout,
        environ=environ,
        build=lambda cfg, database, directory: build_read_server(
            _required(wiring.read_ports if wiring else None, "read ports")(cfg, database),
            directory,
            DatabaseAuditSink(database),
            observer=(
                wiring.read_observer(cfg, database) if wiring and wiring.read_observer else None
            ),
        ),
    )


def handle_serve_write(
    args: argparse.Namespace,
    wiring: ServeWiring | None,
    *,
    settings: Settings | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    environ: Mapping[str, str] | None = None,
) -> int:
    """Run ``kp serve-write``.

    :param args: Parsed arguments (``http``, ``host``, ``identity_header``)
    :param wiring: Builders for the real ports
    :param settings: Settings; loaded from the environment when omitted
    :param stdin: Input stream for stdio mode; defaults to standard input
    :param stdout: Output stream for stdio mode; defaults to standard output
    :param environ: Environment carrying the caller identity; defaults to ``os.environ``
    :return: The process exit status
    """
    return _run(
        args,
        settings=settings,
        stdin=stdin,
        stdout=stdout,
        environ=environ,
        build=lambda cfg, database, directory: build_write_server(
            _required(wiring.write_port if wiring else None, "write tools")(cfg, database),
            directory,
            DatabaseAuditSink(database),
        ),
    )


def _is_loopback(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _required(builder: _T | None, what: str) -> _T:
    if builder is None:
        raise ConfigurationError(f"No implementation of the {what} is wired into this build")
    return builder


def _run(
    args: argparse.Namespace,
    *,
    settings: Settings | None,
    stdin: TextIO | None,
    stdout: TextIO | None,
    environ: Mapping[str, str] | None,
    build: Callable[[Settings, Database, IdentityMapping], McpServer],
) -> int:
    try:
        if args.http is not None and not args.trusted_proxy and not _is_loopback(args.host):
            raise ConfigurationError(
                f"--host {args.host!r} is not a loopback address: the identity header is not "
                "authenticated here, so a reachable port lets any client impersonate any user; "
                "pass --trusted-proxy only behind a proxy that sets it"
            )
        cfg = settings if settings is not None else load_settings()
        if settings is None:
            configure_logging(cfg.log_level)
        if cfg.identity_mapping_file is None:
            raise ConfigurationError("KP_IDENTITY_MAPPING_FILE is required to serve agents")
        directory = IdentityMapping.from_file(cfg.identity_mapping_file)
        database = Database.from_settings(cfg)
        try:
            database.ensure_schema(cfg)
            server = build(cfg, database, directory)
            _serve(
                server,
                args,
                stdin=stdin if stdin is not None else sys.stdin,
                stdout=stdout if stdout is not None else sys.stdout,
                environ=environ if environ is not None else os.environ,
            )
        finally:
            database.dispose()
    except ConfigurationError as exc:
        sys.stderr.write(f"kp {args.command}: {exc}\n")
        return EXIT_CONFIGURATION
    return EXIT_OK


def _serve(
    server: McpServer,
    args: argparse.Namespace,
    *,
    stdin: TextIO,
    stdout: TextIO,
    environ: Mapping[str, str],
) -> None:
    if args.http is None:
        serve_stdio(server, caller_from_environment(environ), stdin, stdout)
        return
    gateway = McpHttpGateway(
        server,
        names=IdentityHeaders(user=args.identity_header),
        max_body_bytes=READ_MAX_BODY_BYTES if args.command == READ_COMMAND else MAX_BODY_BYTES,
    )
    http_server = create_http_server(gateway, args.host, args.http)
    logger.info("Serving MCP over HTTP", extra={"server": server.name, "port": args.http})
    try:
        http_server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Stopping HTTP server")
    finally:
        http_server.server_close()
