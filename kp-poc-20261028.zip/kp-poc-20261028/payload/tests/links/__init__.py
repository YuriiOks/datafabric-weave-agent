"""Tests of the links package (lane L5)."""
