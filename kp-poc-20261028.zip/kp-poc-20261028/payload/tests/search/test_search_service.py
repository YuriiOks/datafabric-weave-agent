"""US-10 (question to exact clause with page and position) and US-11 (rule as at a date)."""

from __future__ import annotations

from datetime import UTC, date, datetime

import pytest

from kp.domain import EditionState
from kp.errors import InvalidClauseRefError
from kp.search import (
    ClauseNotFoundError,
    NoEditionInForceError,
    SearchSettings,
    quote_matches,
)
from search.search_support import SearchWorld

CURRENCY_QUESTION = "which currency may an inbound credit transfer use?"
AFTER_SWITCH = date(2026, 11, 16)
BEFORE_SWITCH = date(2026, 11, 15)

# (question, expected clause number in 2026.1). Written from the leaf clauses of the synthetic
# rulebook: each paraphrases the rule without copying its title.
EVALUATION_SET: tuple[tuple[str, str], ...] = (
    (CURRENCY_QUESTION, "4.2.1"),
    ("how long must participants keep records of credit transfers?", "2.2.2"),
    ("which reason code is used when a transfer is in the wrong currency?", "4.2.1"),
    ("how quickly must a received credit transfer be acknowledged?", "4.1.2"),
    ("what monthly availability must a participant achieve?", "6.1.1"),
    ("within how many hours must a major incident be reported to the operator?", "6.2.1"),
    ("when may the scheme operator suspend a participant?", "2.1.2"),
    ("how soon must a returned transfer be sent back?", "5.2.2"),
    ("which characters are not allowed in the remittance reference?", "4.2.4"),
    ("in which currency does settlement happen?", "4.3.2"),
    ("how many characters can an account identifier have?", "3.2.1"),
    ("how long can the optional remittance reference be?", "3.1.2"),
    ("which elements must every credit transfer message carry?", "3.1.1"),
    ("are card payments or cheques covered by this rulebook?", "1.1.2"),
    ("when is a credit transfer treated as received?", "4.1.1"),
    ("when are accepted credit transfers settled?", "4.3.1"),
    ("can an outbound credit transfer be initiated in pounds sterling?", "5.1.1"),
    ("what must the receiving participant confirm about the creditor account?", "4.2.3"),
    ("how is an institution admitted to the scheme?", "2.1.1"),
    ("before what time must outbound transfers be submitted each day?", "5.1.2"),
)


def test_us10_currency_question_returns_clause_4_2_1_in_top_3_with_page_and_position(
    world: SearchWorld,
) -> None:
    response = world.service().search(CURRENCY_QUESTION, as_at=AFTER_SWITCH)

    top3 = response.hits[:3]
    hit = next(h for h in top3 if h.reference == "2026.1:4.2.1")
    truth = next(c for c in world.dataset.truth.edition("2026.1").clauses if c.number == "4.2.1")
    assert hit.edition == "2026.1"
    assert hit.version == "2026.1"
    assert hit.page == truth.page == 4
    assert (hit.char_start, hit.char_end) == (truth.md_char_start, truth.md_char_end)
    assert hit.human_reference == "2026.1 clause 4.2.1"


def test_us10_quoted_text_equals_the_source_at_the_returned_position(world: SearchWorld) -> None:
    markdown = world.markdown("2026.1")

    response = world.service().search(CURRENCY_QUESTION, as_at=AFTER_SWITCH)

    assert response.hits
    for hit in response.hits:
        if hit.char_start is not None:
            assert quote_matches(hit, markdown)
    assert response.hits[0].text.startswith("An inbound credit transfer may be denominated")


def test_us10_at_least_16_of_20_checked_questions_have_the_clause_in_the_top_5(
    world: SearchWorld,
) -> None:
    assert len(EVALUATION_SET) == 20
    truth = {c.number for c in world.dataset.truth.edition("2026.1").clauses}
    assert {number for _, number in EVALUATION_SET} <= truth
    service = world.service()

    found = 0
    for question, number in EVALUATION_SET:
        top5 = service.search(question, as_at=AFTER_SWITCH, limit=5).hits
        found += any(h.reference == f"2026.1:{number}" for h in top5)

    assert found >= 16


def test_us10_exact_reference_in_the_question_comes_first(world: SearchWorld) -> None:
    response = world.service().search("what does 2026.1 clause 4.2.2 say?", as_at=AFTER_SWITCH)

    first = response.hits[0]
    assert first.reference == "2026.1:4.2.2"
    assert first.match == "reference"
    assert [h.reference for h in response.hits].count("2026.1:4.2.2") == 1


def test_us10_bare_clause_number_is_resolved_by_the_as_at_date(world: SearchWorld) -> None:
    service = world.service()

    before = service.search("explain clause 4.2.1", as_at=BEFORE_SWITCH).hits[0]
    after = service.search("explain clause 4.2.1", as_at=AFTER_SWITCH).hits[0]

    assert (before.reference, after.reference) == ("2025.2:4.2.1", "2026.1:4.2.1")
    assert before.match == after.match == "reference"


def test_us10_a_question_that_is_only_a_clause_number_returns_that_clause_first(
    world: SearchWorld,
) -> None:
    service = world.service()

    before = service.search("4.2.1", as_at=BEFORE_SWITCH).hits[0]
    after = service.search(" 4.2.1 ", as_at=AFTER_SWITCH).hits[0]
    named = service.search("2025.2:4.2.1", as_at=AFTER_SWITCH).hits[0]

    assert (before.reference, after.reference) == ("2025.2:4.2.1", "2026.1:4.2.1")
    assert named.reference == "2025.2:4.2.1"
    assert before.match == after.match == named.match == "reference"


def test_us10_a_bare_number_that_names_no_clause_falls_back_to_ranking(
    world: SearchWorld,
) -> None:
    response = world.service().search("99.9.9", as_at=AFTER_SWITCH)

    assert all(h.match == "ranked" for h in response.hits)


def test_us11_named_edition_hit_reports_that_the_edition_was_not_in_force(
    world: SearchWorld,
) -> None:
    service = world.service()
    question = "what does 2026.1 clause 4.2.1 say?"

    in_force = service.search(question, as_at=AFTER_SWITCH).hits[0]
    superseded_era = service.search(question, as_at=BEFORE_SWITCH)
    before_any = service.search(question, as_at=date(2025, 1, 1))

    assert in_force.reference == "2026.1:4.2.1"
    assert in_force.state is EditionState.CURRENT
    assert superseded_era.edition_in_force == "2025.2"
    assert superseded_era.hits[0].reference == "2026.1:4.2.1"
    assert superseded_era.hits[0].state is EditionState.NOT_YET_EFFECTIVE
    assert before_any.edition_in_force is None
    assert before_any.hits[0].state is EditionState.NOT_YET_EFFECTIVE


def test_us11_a_superseded_named_edition_is_marked_superseded(world: SearchWorld) -> None:
    hit = world.service().search("2025.2:4.2.1", as_at=AFTER_SWITCH).hits[0]

    assert hit.reference == "2025.2:4.2.1"
    assert hit.state is EditionState.SUPERSEDED


def test_us10_ranked_hits_carry_no_edition_state(world: SearchWorld) -> None:
    hits = world.service().search(CURRENCY_QUESTION, as_at=AFTER_SWITCH).hits

    assert all(h.state is None for h in hits)


def test_us10_unknown_reference_in_the_question_adds_no_exact_hit(world: SearchWorld) -> None:
    response = world.service().search("see clause 99.9.9 on currency", as_at=AFTER_SWITCH)

    assert all(h.match == "ranked" for h in response.hits)
    assert response.hits


def test_us10_search_respects_the_result_limit(world: SearchWorld) -> None:
    assert len(world.service().search("credit transfer", as_at=AFTER_SWITCH, limit=3).hits) == 3


@pytest.mark.parametrize("limit", [0, -1])
def test_us10_a_limit_below_one_is_rejected(world: SearchWorld, limit: int) -> None:
    with pytest.raises(ValueError, match="at least 1"):
        world.service().search("credit transfer", as_at=AFTER_SWITCH, limit=limit)


def test_us10_without_a_limit_the_result_limit_setting_applies(world: SearchWorld) -> None:
    service = world.service(SearchSettings(result_limit=4))

    assert len(service.search("credit transfer", as_at=AFTER_SWITCH).hits) == 4


def test_us10_question_of_only_stop_words_returns_nothing(world: SearchWorld) -> None:
    assert world.service().search("what is the", as_at=AFTER_SWITCH).hits == ()


def test_us10_long_clause_part_is_found_and_quotes_its_own_slice(world: SearchWorld) -> None:
    markdown = world.markdown("2026.1")

    hits = world.service().search("MSG04 leading or trailing spaces", as_at=AFTER_SWITCH).hits

    part = next(h for h in hits if h.reference == "2026.1:6.3.2")
    assert part.part_index is not None
    assert quote_matches(part, markdown)


def test_us10_response_reports_the_date_and_the_edition_in_force(world: SearchWorld) -> None:
    response = world.service().search(CURRENCY_QUESTION, as_at=BEFORE_SWITCH)

    assert response.edition_in_force == "2025.2"
    assert response.as_at == BEFORE_SWITCH
    assert response.vector_used is False


def test_us11_clause_4_2_1_as_at_15_nov_returns_the_2025_2_text(world: SearchWorld) -> None:
    rule = world.service().rule_as_at("4.2.1", as_at=BEFORE_SWITCH)

    assert rule.ref.format() == "2025.2:4.2.1"
    assert rule.text.startswith("An inbound credit transfer shall be denominated in euro only")
    assert rule.state.value == "current"
    assert quote_matches(rule, world.markdown("2025.2"))


def test_us11_clause_4_2_1_as_at_16_nov_returns_the_2026_1_text(world: SearchWorld) -> None:
    rule = world.service().rule_as_at("4.2.1", as_at=AFTER_SWITCH)

    assert rule.ref.format() == "2026.1:4.2.1"
    assert "euro or in pounds sterling" in rule.text
    assert quote_matches(rule, world.markdown("2026.1"))


def test_us11_no_date_reads_the_edition_in_force_today(world: SearchWorld) -> None:
    service = world.service()
    world.clock.set(datetime(2026, 11, 1, tzinfo=UTC))
    today_before = service.rule_as_at("4.2.1")
    world.clock.set(datetime(2026, 12, 1, tzinfo=UTC))
    today_after = service.rule_as_at("4.2.1")

    assert today_before.ref.edition == "2025.2"
    assert today_after.ref.edition == "2026.1"


def test_us11_search_without_a_date_uses_todays_edition(world: SearchWorld) -> None:
    world.clock.set(datetime(2026, 12, 1, tzinfo=UTC))

    response = world.service().search(CURRENCY_QUESTION)

    assert response.as_at == date(2026, 12, 1)
    assert response.hits[0].edition == "2026.1"
    assert {h.edition for h in response.hits if h.edition} == {"2026.1"}


def test_us11_a_date_before_any_edition_is_a_typed_error_not_a_fallback(
    world: SearchWorld,
) -> None:
    with pytest.raises(NoEditionInForceError) as error:
        world.service().rule_as_at("4.2.1", as_at=date(2025, 1, 1))

    assert error.value.as_at == date(2025, 1, 1)


def test_us11_qualified_lookup_names_the_edition_and_reports_its_state(
    world: SearchWorld,
) -> None:
    service = world.service()

    old = service.lookup("2025.2 clause 4.2.1", as_at=AFTER_SWITCH)
    new = service.lookup("2026.1:4.2.1", as_at=AFTER_SWITCH)

    assert old.state.value == "superseded"
    assert new.state.value == "current"
    assert old.text != new.text


def test_us11_bare_lookup_resolves_by_date(world: SearchWorld) -> None:
    service = world.service()

    assert service.lookup("4.2.1", as_at=BEFORE_SWITCH).ref.edition == "2025.2"
    assert service.lookup("clause 4.2.1", as_at=AFTER_SWITCH).ref.edition == "2026.1"


def test_us11_clause_added_later_does_not_exist_in_the_earlier_edition(
    world: SearchWorld,
) -> None:
    service = world.service()

    assert service.rule_as_at("4.2.4", as_at=AFTER_SWITCH).ref.edition == "2026.1"
    with pytest.raises(ClauseNotFoundError):
        service.rule_as_at("4.2.4", as_at=BEFORE_SWITCH)


def test_us11_rule_reads_respect_the_domain_filter(world: SearchWorld) -> None:
    service = world.service()

    assert service.rule_as_at("4.2.1", as_at=AFTER_SWITCH, domains=["payments"]).domain == (
        "payments"
    )
    assert service.lookup("2026.1:4.2.1", domains=["payments"], as_at=AFTER_SWITCH).domain == (
        "payments"
    )
    with pytest.raises(NoEditionInForceError):
        service.rule_as_at("4.2.1", as_at=AFTER_SWITCH, domains=["cards"])
    with pytest.raises(ClauseNotFoundError):
        service.lookup("2026.1:4.2.1", as_at=AFTER_SWITCH, domains=["cards"])


def test_us11_malformed_references_are_rejected(world: SearchWorld) -> None:
    service = world.service()

    with pytest.raises(InvalidClauseRefError):
        service.lookup("not a reference")
    with pytest.raises(InvalidClauseRefError):
        service.rule_as_at("4..2")
