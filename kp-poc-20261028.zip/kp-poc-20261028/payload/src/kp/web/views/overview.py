"""Overview: the knowledge version, the freshness of each source and what the base holds."""

from __future__ import annotations

from collections.abc import Collection
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from sqlalchemy import func, select

from kp.domain import KnowledgeVersion, SourceKind
from kp.errors import KpError
from kp.links import LinkService
from kp.publish import KnowledgePublisher
from kp.store import schema
from kp.sweep import SweepStore, check_freshness
from kp.web.errors import Problem, problem_from
from kp.web.identity import Viewer
from kp.web.state import WebState


class SourceStatus(StrEnum):
    """How fresh a source is."""

    FRESH = "Fresh"
    STALE = "Stale"
    ALERT = "Needs attention"
    NEVER = "Never swept"


@dataclass(frozen=True, slots=True)
class SourceRow:
    """The last sweep of one source."""

    source: str
    scope: str
    last_attempt: datetime | None
    last_success: datetime | None
    age_hours: float | None
    failures: int
    status: SourceStatus


@dataclass(frozen=True, slots=True)
class Counts:
    """What the knowledge base holds."""

    editions: int
    clauses: int
    requirements: int
    stories: int
    passages: int


@dataclass(frozen=True, slots=True)
class LinkFigures:
    """Links in use, stated and guessed, against the limit on the guessed share."""

    stated: int
    guessed: int
    review: int
    guessed_share: float
    share_limit: float

    @property
    def within_limit(self) -> bool:
        """True when the guessed share does not exceed its limit."""
        return self.guessed_share <= self.share_limit


@dataclass(frozen=True, slots=True)
class OverviewView:
    """Everything the overview page draws.

    :ivar serving: The version readers see now; ``None`` before the first publication.
    :ivar latest: The newest attempt when it is not the one serving (a build that was blocked).
    :ivar last_sweep: The newest sweep attempt of any source.
    """

    serving: KnowledgeVersion | None = None
    latest: KnowledgeVersion | None = None
    sources: tuple[SourceRow, ...] = ()
    last_sweep: datetime | None = None
    counts: Counts | None = None
    links: LinkFigures | None = None
    problem: Problem | None = None


def read_overview(state: WebState, viewer: Viewer) -> OverviewView:
    """Collect the overview.

    :param state: The shared state
    :param viewer: Who is looking; a viewer with no access is refused
    :return: The view, or one carrying the reason it could not be built
    """
    try:
        state.require_access(viewer)
        return _collect(state, viewer)
    except KpError as exc:
        return OverviewView(problem=problem_from(exc))


def _scoped_counts(state: WebState, viewer: Viewer) -> Counts:
    """Count only what the viewer may read: the totals of other domains are not theirs to know."""
    domains = sorted(viewer.domains)
    rules = state.application.read_ports().rules
    labels = [
        edition.label
        for edition in rules.editions()
        if rules.edition_domain(edition.label) in viewer.domains
    ]
    with state.application.database.transaction() as connection:
        clauses = connection.execute(
            select(func.count())
            .select_from(schema.clause)
            .where(schema.clause.c.edition.in_(labels))
        ).scalar_one()
        requirements = connection.execute(
            select(func.count())
            .select_from(schema.requirement)
            .where(schema.requirement.c.domain.in_(domains))
        ).scalar_one()
        stories = connection.execute(
            select(func.count(func.distinct(schema.story.c.story_key))).where(
                schema.story.c.domain.in_(domains)
            )
        ).scalar_one()
        passages = connection.execute(
            select(func.count())
            .select_from(schema.passage)
            .where(schema.passage.c.domain.in_(domains))
        ).scalar_one()
    return Counts(
        editions=len(labels),
        clauses=clauses,
        requirements=requirements,
        stories=stories,
        passages=passages,
    )


def _collect(state: WebState, viewer: Viewer) -> OverviewView:
    application = state.application
    thresholds = application.settings.thresholds
    now = application.clock.now()
    with application.database.transaction() as connection:
        versions = KnowledgePublisher(connection, thresholds=thresholds, clock=application.clock)
        serving = versions.current()
        newest = versions.versions()[:1]
        statistics = LinkService(connection, thresholds=thresholds, clock=application.clock)
        figures = statistics.statistics()
        sweep = SweepStore(connection)
        cursors = sweep.list_cursors()
        report = check_freshness(sweep, now=now, thresholds=thresholds, expected=list(SourceKind))
    latest = next(
        (v for v in newest if serving is None or v.version_id != serving.version_id), None
    )
    stale = {(entry.source, entry.scope) for entry in report.stale}
    alerting = {(alert.source, alert.scope) for alert in report.alerts}
    rows = [
        SourceRow(
            source=cursor.source.value,
            scope=cursor.scope,
            last_attempt=cursor.last_attempt_at,
            last_success=cursor.last_success_at,
            age_hours=_age(now, cursor.last_success_at),
            failures=cursor.consecutive_failures,
            status=_status((cursor.source, cursor.scope), stale, alerting),
        )
        for cursor in cursors
    ]
    swept = {cursor.source for cursor in cursors}
    rows.extend(
        SourceRow(kind.value, "", None, None, None, 0, SourceStatus.NEVER)
        for kind in SourceKind
        if kind not in swept
    )
    attempts = [cursor.last_attempt_at for cursor in cursors if cursor.last_attempt_at]
    return OverviewView(
        serving=serving,
        latest=latest,
        sources=tuple(rows),
        last_sweep=max(attempts) if attempts else None,
        counts=_scoped_counts(state, viewer),
        # The link figures cover every domain at once and cannot be split here, so only a viewer
        # who may read every domain gets them.
        links=LinkFigures(
            stated=figures.stated,
            guessed=figures.guessed,
            review=figures.review,
            guessed_share=figures.guessed_share,
            share_limit=thresholds.guessed_share_max,
        )
        if viewer.domains >= state.directory.all_domains()
        else None,
    )


def _age(now: datetime, moment: datetime | None) -> float | None:
    """Hours since a moment; never negative, so a clock set earlier than the data reads as 0."""
    if moment is None:
        return None
    return max(0.0, (now - moment).total_seconds() / 3600)


def _status(
    key: tuple[SourceKind, str],
    stale: Collection[tuple[SourceKind, str]],
    alerting: Collection[tuple[SourceKind, str]],
) -> SourceStatus:
    if key in alerting:
        return SourceStatus.ALERT
    return SourceStatus.STALE if key in stale else SourceStatus.FRESH
