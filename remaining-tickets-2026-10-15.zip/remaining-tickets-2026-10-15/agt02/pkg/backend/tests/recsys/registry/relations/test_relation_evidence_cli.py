"""The relation evidence command reports a build and, optionally, its retirements.

It reads only the synthetic fixtures and writes one JSON file; it opens no database.
"""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from typing import Any

from app.recsys.relation_evidence import main
from tests.recsys.registry._fixtures import EXPORT_DIR, SKILLS_REPO, write_export_dir

NAMES = ("widget-helper", "alpha-helper", "widget-hub", "absent-mcp", "tenant-one")


class RelationEvidenceCommandTests(unittest.TestCase):
    def setUp(self) -> None:
        scratch = tempfile.TemporaryDirectory()
        self.addCleanup(scratch.cleanup)
        self.root = Path(scratch.name)
        self.out = self.root / "report.json"

    def _run(self, *extra: str, export: Path = EXPORT_DIR) -> dict[str, Any]:
        code = main(
            [
                "--export",
                str(export),
                "--skills-repo",
                str(SKILLS_REPO),
                "--environment",
                "ppd",
                "--partition",
                "default",
                "--out",
                str(self.out),
                *extra,
            ]
        )
        self.assertEqual(code, 0)
        return json.loads(self.out.read_text(encoding="utf-8"))

    def test_the_report_accounts_for_every_relation_and_entry(self):
        report = self._run()

        buckets = report["by_link_type"].values()
        self.assertEqual(report["relations"], sum(b["relations"] for b in buckets))
        self.assertEqual(
            report["evidence_entries"], sum(b["published_evidence"] for b in buckets)
        )
        self.assertLessEqual(
            set(report["link_types_present"]), set(report["closed_link_types"])
        )
        self.assertEqual(report["by_link_type"]["USES_MCP"]["unresolved_occurrences"], 3)
        self.assertNotIn("transition", report)

    def test_the_sample_carries_evidence_for_every_relation_shown(self):
        report = self._run("--sample", "3")

        self.assertLessEqual(len(report["evidence_sample"]), 3)
        self.assertTrue(report["evidence_sample"])
        for item in report["evidence_sample"]:
            with self.subTest(relation=item["relation_key"]):
                self.assertTrue(item["evidence"])

    def test_the_default_report_carries_no_component_names(self):
        self._run()

        text = self.out.read_text(encoding="utf-8")
        for name in NAMES:
            with self.subTest(name=name):
                self.assertNotIn(name, text)

    def test_include_ids_keeps_them(self):
        report = self._run("--include-ids")

        self.assertIn("agent:tenant-one/widget-helper", json.dumps(report))
        self.assertIn("entries", report["ledger"])

    def test_a_previous_build_yields_the_relation_diff_and_the_verdict(self):
        candidate = write_export_dir(self.root / "candidate")

        report = self._run(
            "--previous-export",
            str(EXPORT_DIR),
            "--previous-skills-repo",
            str(SKILLS_REPO),
            export=candidate,
        )

        transition = report["transition"]
        self.assertGreater(transition["relation_diff"]["retired"], 0)
        self.assertFalse(transition["allowed"])
        relation_breaches = [
            breach
            for breach in transition["breaches"]
            if breach["kind"] == "relation_retirement_not_declared"
        ]
        self.assertEqual(len(relation_breaches), 1)
        self.assertEqual(
            relation_breaches[0]["relation_keys"],
            transition["relation_diff"]["retired_keys"],
        )

    def test_half_a_previous_build_is_refused(self):
        code = main(
            [
                "--export",
                str(EXPORT_DIR),
                "--skills-repo",
                str(SKILLS_REPO),
                "--previous-export",
                str(EXPORT_DIR),
                "--environment",
                "ppd",
                "--partition",
                "default",
                "--out",
                str(self.out),
            ]
        )
        self.assertEqual(code, 2)
        self.assertFalse(self.out.exists())


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
