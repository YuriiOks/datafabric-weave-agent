import type { CSSProperties } from 'react'
import { isProd, relationCount, shortSource, withheldCount } from './model'
import type { ComponentPageModel } from './model'
import { STATE_COLOUR } from './styles'
import type { TileState } from './styles'

type Tile = {
  label: string
  value: string
  detail: string
  state: TileState
  href?: string
}

/** Four summary tiles under the hero on wide screens, each with a state colour on its top edge. */
export function DetailStatTiles({ model }: { model: ComponentPageModel }) {
  const { relations, source } = model
  const prod = isProd(source.environment)
  const related = relationCount(relations)
  const withheld = withheldCount(relations)
  const flags = model.qualityFlags

  const tiles: Tile[] = [
    {
      label: 'Version',
      value: model.version ?? '\u2014',
      detail: model.nativeBinding ? 'Native binding: ' + model.nativeBinding : 'Native binding not set',
      state: 'none',
    },
    {
      label: 'Source',
      value: shortSource(source.originSystem, prod),
      detail: [prod ? 'Prod' : null, source.lastSynced ? 'synced ' + source.lastSynced : null]
        .filter((part): part is string => part !== null)
        .join(' \u00b7 ') || 'Provenance not recorded',
      state: prod || source.revision ? 'clear' : 'none',
    },
    {
      label: 'Relations',
      value: String(related),
      detail:
        String(relations.usedBy.items.length) + ' used by \u00b7 ' +
        String(relations.uses.items.length) + ' uses \u00b7 ' +
        String(relations.dependsOn.items.length) + ' depends on',
      state: withheld > 0 ? 'look' : 'none',
      href: '#related-components',
    },
    {
      label: 'Quality flags',
      value: flags.length > 0 ? String(flags.length) : 'None',
      detail: flags.length > 0 ? flags.join(', ') : 'No flags raised',
      state: flags.length > 0 ? 'look' : 'clear',
    },
  ]

  return (
    <section aria-label="Summary">
      <div style={gridStyle}>
        {tiles.map((tile) => (
          <TileBox key={tile.label} tile={tile} />
        ))}
      </div>
      <div style={legendStyle} aria-hidden="true">
        <LegendDot state="none" label="No state" />
        <LegendDot state="look" label="Needs a look" />
        <LegendDot state="clear" label="Clear" />
      </div>
    </section>
  )
}

function TileBox({ tile }: { tile: Tile }) {
  const body = (
    <>
      <div style={tileLabelStyle}>{tile.label}</div>
      <div style={tileValueStyle} title={tile.value}>
        {tile.value}
      </div>
      <div style={tileDetailStyle} title={tile.detail}>
        {tile.detail}
      </div>
    </>
  )
  const style: CSSProperties = { ...tileStyle, borderTopColor: STATE_COLOUR[tile.state] }
  if (!tile.href) return <div style={style}>{body}</div>
  return (
    <a
      href={tile.href}
      style={{ ...style, textDecoration: 'none', color: 'inherit' }}
      onClick={(event) => {
        const target = document.getElementById(tile.href?.slice(1) ?? '')
        if (!target) return
        event.preventDefault()
        target.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }}
    >
      {body}
    </a>
  )
}

function LegendDot({ state, label }: { state: TileState; label: string }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span style={{ width: 8, height: 8, borderRadius: 2, background: STATE_COLOUR[state] }} />
      {label}
    </span>
  )
}

const gridStyle: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
  gap: 'var(--space-3)',
}

const tileStyle: CSSProperties = {
  display: 'block',
  minWidth: 0,
  background: 'var(--color-surface)',
  border: '1px solid var(--color-border-light)',
  borderTop: '3px solid',
  borderRadius: 'var(--radius-lg)',
  padding: 'var(--space-3) var(--space-4)',
}

const tileLabelStyle: CSSProperties = {
  fontSize: '0.6875rem',
  fontWeight: 600,
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--color-text-secondary)',
}

const tileValueStyle: CSSProperties = {
  fontSize: '1.375rem',
  fontWeight: 600,
  color: 'var(--color-text-primary)',
  margin: '4px 0 2px',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
}

const tileDetailStyle: CSSProperties = {
  fontSize: '0.75rem',
  color: 'var(--color-text-tertiary)',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
}

const legendStyle: CSSProperties = {
  display: 'flex',
  justifyContent: 'flex-end',
  gap: 'var(--space-4)',
  marginTop: 'var(--space-2)',
  fontSize: '0.75rem',
  color: 'var(--color-text-tertiary)',
}
