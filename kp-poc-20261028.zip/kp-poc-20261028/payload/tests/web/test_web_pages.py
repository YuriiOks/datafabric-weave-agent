"""Every page of the UI answers from the demo's platform, with the numbers the data implies."""

from __future__ import annotations

import re

from fastapi.testclient import TestClient

from kp.web.app import create_app
from kp.web.settings import WebSettings
from kp.writeback import SpecRepository
from web.conftest import CURRENCY_QUESTION, PUBLISHED_STORY, WebWorld

AS_AT_BEFORE_NEW_EDITION = "2026-11-15"
AS_AT_NEW_EDITION = "2026-11-16"
OLD_RULE_WORDING = "denominated in euro only"
NEW_RULE_WORDING = "euro or in pounds sterling"
CLAUSE_WITHOUT_LINKS = "2026.1:4"


def _page(client: TestClient, path: str, **params: str) -> str:
    response = client.get(path, params=params)
    assert response.status_code == 200, response.text[:400]
    return response.text


def test_the_overview_shows_the_version_in_use_each_source_and_what_is_held(
    client: TestClient, web_world: WebWorld
) -> None:
    truth = web_world.world.staged.dataset.truth

    page = _page(client, "/")

    assert "is serving" in page
    assert "Publication checks of version kv-" in page
    for source in ("document_library", "confluence", "jira", "github", "regulatory_repo"):
        assert f'<th scope="row">{source}</th>' in page
    assert "Needs attention" not in page
    expected = {
        "Rulebook editions": len(truth.editions),
        "Clauses": sum(len(edition.clauses) for edition in truth.editions),
        "Requirements": truth.requirements_register.data_row_count,
        "Stories": truth.stories.story_count,
    }
    for caption, count in expected.items():
        assert f'<span class="figure">{count}</span><span class="caption">{caption}</span>' in page
    assert "Stated by a source" in page
    assert "Guessed share of the links in use" in page


def test_a_question_returns_the_clause_with_page_position_version_and_quoted_text(
    client: TestClient, web_world: WebWorld
) -> None:
    truth = web_world.world.staged.dataset.truth
    newest = max(truth.editions, key=lambda edition: edition.effective_date)
    clause = next(item for item in newest.clauses if item.number == "4.2.1")

    page = _page(client, "/search", q=CURRENCY_QUESTION)

    first = page.split('<li class="result">')[1]
    assert f"Clause {newest.label}:4.2.1" in first
    assert f"<li>Page: {clause.page}</li>" in first
    assert re.search(r"<li>Characters: \d+ to \d+</li>", first)
    assert f"<li>Version: {newest.label}</li>" in first
    assert NEW_RULE_WORDING in first
    assert "Filtered out by your access: <strong>0</strong>" in page


def test_a_search_as_at_an_earlier_date_reads_the_edition_then_in_force(client: TestClient) -> None:
    page = _page(client, "/search", q="clause 4.2.1", as_at=AS_AT_BEFORE_NEW_EDITION)

    assert OLD_RULE_WORDING in page
    assert NEW_RULE_WORDING not in page


def test_a_search_with_no_match_says_so_explicitly(client: TestClient) -> None:
    page = _page(client, "/search", q="zzzzqqqq")

    assert "No passage matched your question." in page
    assert "0 results" in page


def test_the_rule_as_at_the_day_before_and_the_day_of_the_new_edition(client: TestClient) -> None:
    before = _page(client, "/rule", number="4.2.1", as_at=AS_AT_BEFORE_NEW_EDITION)
    on_the_day = _page(client, "/rule", number="4.2.1", as_at=AS_AT_NEW_EDITION)

    assert "Edition in force</dt><dd>2025.2" in before
    assert "Edition in force</dt><dd>2026.1, effective 2026-11-16" in on_the_day
    for page in (before, on_the_day):
        assert OLD_RULE_WORDING in page
        assert NEW_RULE_WORDING in page  # both editions are always shown side by side
        assert '<th scope="row">2025.2</th>' in page
        assert '<th scope="row">2026.1</th>' in page
        assert "2025-06-02" in page
        assert "2026-11-16" in page
    assert "not yet effective" in before


def test_the_rule_without_a_date_is_read_as_at_today(client: TestClient) -> None:
    page = _page(client, "/rule", number="4.2.1")

    assert "Clause 4.2.1 as at 2026-11-20" in page
    assert "Edition in force</dt><dd>2026.1" in page


def test_a_rule_that_the_edition_in_force_lacks_is_reported_in_place(client: TestClient) -> None:
    page = _page(client, "/rule", number="9.9.9")

    assert "has no clause 9.9.9" in page
    assert "Every edition" in page


def test_a_changed_clause_lists_what_it_affects_marked_stated_or_guessed(
    client: TestClient,
) -> None:
    page = _page(client, "/impact", clause="4.2.1")

    assert "Clause 2026.1:4.2.1" in page
    assert "7 items within 3 steps" in page
    assert '<span class="badge good">Stated</span>' in page
    for kind in ("requirement", "schema field", "story", "spec", "code", "test"):
        assert kind in page


def test_a_clause_with_no_links_says_so_instead_of_an_empty_list(client: TestClient) -> None:
    page = _page(client, "/impact", clause=CLAUSE_WITHOUT_LINKS)

    assert "Nothing is linked." in page
    assert "No links are recorded for this item within 3 steps." in page
    assert "<tbody>" not in page.split('aria-labelledby="impact-title"')[1]


def test_the_impact_page_offers_the_rules_to_choose_from(client: TestClient) -> None:
    page = _page(client, "/impact")

    assert '<option value="2026.1:4.2.1">' in page


def test_coverage_lists_untested_rules_with_linked_stories_and_the_link_split(
    client: TestClient,
) -> None:
    page = _page(client, "/coverage")

    assert re.search(r"\d+ of \d+ rules have no test; the answer rests on \d+ links", page)
    assert "Linked stories" in page
    assert "stated" in page
    assert "Stories with no requirement or clause behind them" in page
    assert "PAY-106" in page


def test_a_story_is_drafted_with_its_citations_resolved_and_rated(client: TestClient) -> None:
    page = _page(client, "/specs", story=PUBLISHED_STORY)

    assert "The drafted spec" in page
    assert "<strong>100%</strong> of rule statements are cited and valid" in page
    assert "against a target of 95%" in page
    assert "Meets the target" in page
    assert '<a class="cite" href="/rule?number=4.1.2' in page  # the citation links to the rule
    assert "<code>2026.1:4.1.2</code>" in page


def test_a_draft_with_an_uncited_statement_is_flagged_below_the_target(client: TestClient) -> None:
    page = _page(client, "/specs", story="PAY-106")

    assert "Below the target" in page
    assert "Flagged statements" in page
    assert "No citation." in page


def test_the_pull_request_record_of_a_published_spec_is_shown(client: TestClient) -> None:
    page = _page(client, "/specs", story=PUBLISHED_STORY)

    assert "Pull request record" in page
    assert "spec-pay-101" in page
    assert "<dt>Machine-authored</dt><dd>yes</dd>" in page
    assert "3 valid of 3" in page


def test_a_story_without_a_pull_request_says_so(client: TestClient) -> None:
    page = _page(client, "/specs", story="PAY-103")

    assert "No pull request has been opened for this story." in page


def test_drafting_a_spec_writes_no_spec_record(client: TestClient, web_world: WebWorld) -> None:
    _page(client, "/specs", story="PAY-103")

    with web_world.world.application.database.transaction() as connection:
        assert SpecRepository(connection).get_by_story("PAY-103") is None


def test_connectivity_shows_all_eleven_criteria_and_the_verdict(client: TestClient) -> None:
    page = _page(client, "/connectivity")

    for number in range(1, 12):
        assert f'<th scope="row">X-{number:02d}</th>' in page
    assert "Local run only: the harness is proven against stand-ins; the platform is not." in page
    assert "without evidence" in page
    assert "Each step of the route" in page


def test_connectivity_without_a_recorded_run_says_so(web_world: WebWorld) -> None:
    empty = web_world.world.settings.model_copy(
        update={"data_dir": web_world.world.workdir / "no-run-here"}
    )
    app = create_app(web_world.world.application, settings=WebSettings(), connectivity=empty)

    page = TestClient(app).get("/connectivity").text

    assert "No connectivity run has left evidence yet." in page
    assert "X-01" not in page


def test_the_audit_trail_lists_the_calls_behind_a_spec(client: TestClient) -> None:
    page = _page(client, "/audit", spec="spec-pay-101")

    assert "Recorded tool calls, newest first" in page
    assert "kp-draft-spec" in page
    assert "publish_spec" in page
    assert "Answered" in page


def test_the_audit_trail_lists_what_was_asked_in_the_ui_and_refusals(client: TestClient) -> None:
    client.get("/search", params={"q": "currency"})
    client.get("/search", params={"q": "currency", "user": "user-no-access"})

    page = _page(client, "/audit")

    assert "<td>user-full-access</td>" in page
    assert "<td>kp-web</td>" in page
    assert '<span class="badge bad">Refused</span>' in page
    assert "The caller has no access to any domain" in page


def test_the_audit_filter_offers_the_specs_that_exist(client: TestClient) -> None:
    page = _page(client, "/audit")

    assert '<option value="spec-pay-101">spec-pay-101</option>' in page


def test_the_audit_trail_hides_calls_made_with_wider_access_than_the_viewers(
    client: TestClient,
) -> None:
    client.get("/search", params={"q": "currency", "user": "user-full-access"})

    page = _page(client, "/audit", user="user-one-domain")

    assert "<td>user-full-access</td>" not in page


def test_text_typed_into_a_form_is_escaped(client: TestClient) -> None:
    page = _page(client, "/search", q="<script>alert(1)</script>")

    assert "<script>alert(1)</script>" not in page
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in page
