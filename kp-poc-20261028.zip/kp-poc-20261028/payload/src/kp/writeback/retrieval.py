"""Stand-ins the reference client uses where the read lanes would normally answer.

They read the shared tables directly: the story, the clause and register rows, and the link
store. They exist so ``kp draft-spec`` works on its own; the integrator can replace any of
them with an adapter over the real search and coverage tools through the same ports.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable
from collections.abc import Set as AbstractSet
from datetime import date

from sqlalchemy import Connection, select

from kp.domain import (
    ClauseRef,
    Edition,
    EditionState,
    ItemType,
    LinkState,
    Relation,
    Story,
    StoryLink,
    select_edition_as_at,
)
from kp.errors import InvalidClauseRefError
from kp.store.schema import clause, edition, link, requirement
from kp.store.schema import story as story_table
from kp.writeback.citations import canonical_reference, extract_references
from kp.writeback.errors import StoryNotFoundError
from kp.writeback.limits import spec_id_for_story
from kp.writeback.ports import EvidenceItem, Retrieval
from kp.writeback.store import version_key

_WORD = re.compile(r"[a-z]{4,}")
_STOPWORDS = frozenset(
    {
        "that",
        "this",
        "with",
        "from",
        "have",
        "must",
        "shall",
        "than",
        "into",
        "each",
        "every",
        "when",
        "which",
        "their",
    }
)
_MIN_SHARED_TERMS = 2
_MAX_PROPOSED = 3
_MAX_STEPS = 3


class InMemorySessionRetrievals:
    """Remembers what each session retrieved, for the reference client and tests."""

    def __init__(self) -> None:
        self._seen: dict[str, set[str]] = {}

    def record(self, session_id: str, references: Iterable[str]) -> None:
        """Note references retrieved in a session.

        :param session_id: The agent session
        :param references: References returned to the agent
        """
        self._seen.setdefault(session_id, set()).update(canonical_reference(r) for r in references)

    def references(self, session_id: str, caller: str = "") -> AbstractSet[str]:
        """List what a session retrieved.

        :param session_id: The agent session
        :param caller: Ignored: the reference client's sessions are its own, in memory
        :return: Canonical references; empty for an unknown session
        """
        del caller
        return frozenset(self._seen.get(session_id, set()))


def load_story(connection: Connection, story_key: str) -> Story:
    """Read the latest stored version of a story.

    :param connection: An open connection
    :param story_key: The story key
    :return: The latest version of the story (versions compare as numbers where they have
        digits, so ``v10`` is later than ``v9``)
    :raises kp.writeback.errors.StoryNotFoundError: If the story is not stored
    """
    rows = connection.execute(select(story_table).where(story_table.c.story_key == story_key)).all()
    if not rows:
        raise StoryNotFoundError("The story is not in the store")
    latest = max(rows, key=lambda row: version_key(row.version))
    values = dict(latest._mapping)
    values.pop("fingerprint", None)
    values["links"] = tuple(StoryLink.model_validate(item) for item in values["links"])
    return Story.model_validate(values)


def _is_clause(reference: str) -> bool:
    try:
        ClauseRef.parse(reference)
    except InvalidClauseRefError:
        return False
    return True


def _terms(text: str) -> set[str]:
    return set(_WORD.findall(text.casefold())) - _STOPWORDS


class DatabaseRetriever:
    """Finds a story's rules and register rows in the shared tables.

    Stated evidence: rules the story text cites, register rows its links name, the rules
    those rows cite, and what the story's spec is derived from through stated links in the link
    store. Evidence reached through a guessed link (proposed or under review) is marked
    proposed; dropped links are ignored. If the story cites no rule, up to three clauses of the
    edition in force that share at least two terms with the story are offered as proposed.

    Material the viewer may not read is left out wherever it would enter: cited rules, register
    rows, the rules those rows cite, spec links and proposals alike.

    :param connection: An open connection
    :param allowed: Tells whether a reference (a clause reference or a register row id) may be
        shown to whoever the draft is for; omitted means everything may
    """

    def __init__(
        self, connection: Connection, *, allowed: Callable[[str], bool] | None = None
    ) -> None:
        self._connection = connection
        self._allowed = allowed

    def _may_show(self, reference: str) -> bool:
        return self._allowed is None or self._allowed(reference)

    def retrieve(self, story: Story, *, as_at: date) -> Retrieval:
        """Retrieve evidence for a story.

        :param story: The story to draft for
        :param as_at: The date the rules are read at
        :return: Evidence and notes (an edition not in force, a link to a missing row)
        """
        items: dict[str, EvidenceItem] = {}
        notes: list[str] = []
        requirements = self._requirements()
        story_text = " ".join((story.summary, story.description, story.acceptance_criteria))
        for reference in extract_references(story_text):
            self._add_clause(items, reference)
        for story_link in story.links:
            row = self._register_row(requirements, story_link.target_key)
            if row is not None:
                self._add_register_row(items, row, proposed=False)
        for item_type, key, guessed in self._derived_from(story.story_key):
            if item_type is ItemType.CLAUSE:
                self._add_clause(items, key, proposed=guessed)
            elif item_type is ItemType.REQUIREMENT:
                linked_row = self._register_row(requirements, key)
                if linked_row is not None:
                    self._add_register_row(items, linked_row, proposed=guessed)
        notes.extend(self._edition_notes(items, as_at))
        if not any(self._is_clause(reference) for reference in items):
            for proposed in self._propose(story_text, as_at):
                items.setdefault(proposed.reference, proposed)
        return Retrieval(evidence=tuple(items.values()), notes=tuple(notes))

    @staticmethod
    def _is_clause(reference: str) -> bool:
        return _is_clause(reference)

    def _add_clause(
        self, items: dict[str, EvidenceItem], reference: str, *, proposed: bool = False
    ) -> None:
        if reference in items or not self._is_clause(reference) or not self._may_show(reference):
            return
        ref = ClauseRef.parse(reference)
        text = self._connection.execute(
            select(clause.c.text).where(
                clause.c.edition == ref.edition, clause.c.number == ref.number
            )
        ).scalar()
        if text is not None:
            items[reference] = EvidenceItem(reference=reference, text=text, proposed=proposed)

    def _add_register_row(
        self,
        items: dict[str, EvidenceItem],
        row: tuple[str, dict[str, str]],
        *,
        proposed: bool,
    ) -> None:
        requirement_id, fields = row
        if not self._may_show(requirement_id):
            return
        text = ". ".join(value for key, value in fields.items() if key in {"Title", "Description"})
        items.setdefault(
            requirement_id,
            EvidenceItem(reference=requirement_id, text=text or requirement_id, proposed=proposed),
        )
        for reference in extract_references(" ".join(fields.values())):
            self._add_clause(items, reference, proposed=proposed)

    def _requirements(self) -> list[tuple[str, dict[str, str]]]:
        rows = self._connection.execute(
            select(requirement.c.requirement_id, requirement.c.fields).order_by(
                requirement.c.requirement_id
            )
        ).all()
        return [(requirement_id, dict(fields)) for requirement_id, fields in rows]

    @staticmethod
    def _register_row(
        requirements: list[tuple[str, dict[str, str]]], key: str
    ) -> tuple[str, dict[str, str]] | None:
        """Pick the first row, in row id order, that is the key or carries it in a field."""
        for requirement_id, fields in requirements:
            if key == requirement_id or key in fields.values():
                return requirement_id, fields
        return None

    def _derived_from(self, story_key: str) -> list[tuple[ItemType, str, bool]]:
        """List what the story's spec is derived from: type, key and whether it is guessed."""
        rows = self._connection.execute(
            select(link.c.target_item_type, link.c.target_key, link.c.state)
            .where(
                link.c.source_item_type == ItemType.SPEC.value,
                link.c.source_key == spec_id_for_story(story_key),
                link.c.relation == Relation.DERIVED_FROM.value,
                link.c.valid_to.is_(None),
                link.c.state != LinkState.DROPPED.value,
            )
            .order_by(link.c.target_key)
        ).all()
        return [
            (ItemType(item_type), key, LinkState(state) is not LinkState.STATED)
            for item_type, key, state in rows
        ]

    def _editions(self) -> list[Edition]:
        rows = self._connection.execute(select(edition)).all()
        return [Edition.model_validate(dict(row._mapping)) for row in rows]

    def _edition_notes(self, items: dict[str, EvidenceItem], as_at: date) -> list[str]:
        labels = {ClauseRef.parse(ref).edition for ref in items if self._is_clause(ref)}
        known = {item.label: item for item in self._editions()}
        notes = []
        for label in sorted(labels & known.keys()):
            state = known[label].state_on(as_at)
            if state is not EditionState.CURRENT:
                notes.append(
                    f"Edition {label} is {state.value.replace('_', ' ')} as at {as_at.isoformat()}."
                )
        return notes

    def _propose(self, story_text: str, as_at: date) -> list[EvidenceItem]:
        in_force = select_edition_as_at(self._editions(), as_at)
        if in_force is None:
            return []
        story_terms = _terms(story_text)
        scored: list[tuple[int, str, str]] = []
        rows = self._connection.execute(
            select(clause.c.number, clause.c.text).where(clause.c.edition == in_force.label)
        ).all()
        for number, text in rows:
            shared = len(story_terms & _terms(text))
            if shared >= _MIN_SHARED_TERMS and self._may_show(
                ClauseRef(in_force.label, number).format()
            ):
                scored.append((shared, number, text))
        scored.sort(key=lambda entry: (-entry[0], ClauseRef(in_force.label, entry[1])))
        return [
            EvidenceItem(
                reference=ClauseRef(in_force.label, number).format(), text=text, proposed=True
            )
            for _, number, text in scored[:_MAX_PROPOSED]
        ]


class LinkGraphCoverage:
    """Finds the tests reachable from a rule or register row through the link store.

    Follows current links (no end date) that a source stated, in either direction, up to
    three steps. Guessed links (proposed, under review or dropped) never count as coverage.
    Items are identified by type and key, so equal keys of different types stay apart.

    :param connection: An open connection
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def tests_for(self, reference: str) -> tuple[str, ...]:
        """List the tests linked through stated links.

        :param reference: Canonical clause reference or requirement id
        :return: Test keys, sorted; empty when none is reachable
        """
        start = (ItemType.CLAUSE if _is_clause(reference) else ItemType.REQUIREMENT, reference)
        frontier = {start}
        visited = {start}
        tests: set[str] = set()
        for _ in range(_MAX_STEPS):
            rows = self._connection.execute(
                select(
                    link.c.source_item_type,
                    link.c.source_key,
                    link.c.target_item_type,
                    link.c.target_key,
                ).where(
                    link.c.valid_to.is_(None),
                    link.c.state == LinkState.STATED.value,
                    (link.c.source_key.in_({key for _, key in frontier}))
                    | (link.c.target_key.in_({key for _, key in frontier})),
                )
            ).all()
            reached: set[tuple[ItemType, str]] = set()
            for source_type, source_key, target_type, target_key in rows:
                source = (ItemType(source_type), source_key)
                target = (ItemType(target_type), target_key)
                for here, there in ((source, target), (target, source)):
                    if here in frontier and there not in visited:
                        reached.add(there)
            tests.update(key for item_type, key in reached if item_type is ItemType.TEST)
            visited |= reached
            frontier = reached
            if not frontier:
                break
        return tuple(sorted(tests))
