"""Constants and fakes shared by the write-back tests."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

from sqlalchemy import insert

from kp.domain import Story, Template, ToolCallRecord
from kp.store import Database
from kp.store.schema import story as story_table
from kp.writeback import (
    JiraApplied,
    JiraStoryUpdate,
    JiraSyncService,
    PublishRequest,
    PublishResult,
    SpecPublishingService,
    WriteTools,
)

NOW = datetime(2026, 11, 2, 10, 0, tzinfo=UTC)
REPOSITORY = "example-org/example-specs"
SPEC_PATH = "specs"
LINK_FIELD = "spec_link"
DOMAINS = frozenset({"payments"})
CLAUSE_TEXTS = {
    "4.1.2": "A participant shall acknowledge every received credit transfer within five seconds.",
    "4.2.1": "An inbound credit transfer may be denominated in euro or in pounds sterling.",
    "4.2.3": "The receiving participant shall confirm that the creditor account exists.",
}


@dataclass
class Seeded:
    """Handles to what :func:`seeded` inserted."""

    template: Template
    references: tuple[str, ...] = field(
        default=("2026.1:4.1.2", "2026.1:4.2.1", "2026.1:4.2.3", "2025.2:4.2.1")
    )
    requirement_id: str = "register-1:Requirements:8"


@dataclass
class RecordingPublisher:
    """A publisher fake that counts pull requests by branch, like the real ones."""

    requests: list[PublishRequest] = field(default_factory=list)
    pull_requests: dict[str, int] = field(default_factory=dict)
    contents: dict[str, str] = field(default_factory=dict)

    def publish(self, request: PublishRequest) -> PublishResult:
        """Record the request; the same branch is the same pull request."""
        self.requests.append(request)
        created = request.branch not in self.pull_requests
        number = self.pull_requests.setdefault(request.branch, len(self.pull_requests) + 1)
        committed = self.contents.get(request.branch) != request.content
        self.contents[request.branch] = request.content
        return PublishResult(
            branch=request.branch,
            pr_url=f"local-pr:{number}",
            pr_number=number,
            commit_sha="a" * 40,
            created=created,
            committed=committed,
        )


@dataclass
class ScriptedJira:
    """A Jira fake that fails with the queued errors before succeeding."""

    failures: list[Exception] = field(default_factory=list)
    updates: list[JiraStoryUpdate] = field(default_factory=list)

    def apply(self, update: JiraStoryUpdate) -> JiraApplied:
        """Raise the next queued failure, otherwise record the update."""
        self.updates.append(update)
        if self.failures:
            raise self.failures.pop(0)
        return JiraApplied(status_changed=True, link_set=True)


@dataclass
class MemoryAudit:
    """An audit sink that keeps records in memory."""

    records: list[ToolCallRecord] = field(default_factory=list)

    def record(self, record: ToolCallRecord) -> None:
        """Keep the record."""
        self.records.append(record)


GOOD_SPEC = """\
# Acknowledge received credit transfers

## Summary

Acknowledge each received transfer quickly.

## Rules

- A participant shall acknowledge every received credit transfer [ref: 2026.1:4.1.2].
- The receiving participant shall confirm the creditor account [ref: 2026.1:4.2.3].

## Acceptance

- A received transfer is acknowledged within five seconds.
"""
RETRIEVED = frozenset({"2026.1:4.1.2", "2026.1:4.2.3"})
SESSION = "session-1"


@dataclass
class Writers:
    """The write side wired to fakes."""

    publisher: RecordingPublisher
    jira: ScriptedJira
    audit: MemoryAudit
    tools: WriteTools
    publishing: SpecPublishingService
    sync: JiraSyncService
    sleeps: list[float]


def add_story(database: Database, story_key: str, *, domain: str | None) -> None:
    """Store a one-line story in the given domain (``None`` for an unlabelled one)."""
    story = Story(story_key=story_key, version="v1", summary="Another story", domain=domain)
    values = story.model_dump()
    values["links"] = []
    values["fingerprint"] = story.fingerprint()
    with database.transaction() as connection:
        connection.execute(insert(story_table).values(**values))
