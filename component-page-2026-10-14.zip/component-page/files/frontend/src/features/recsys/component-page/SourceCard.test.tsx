import { afterEach, describe, expect, it } from 'vitest'
import { cleanup, render, screen } from '@testing-library/react'
import { EMPTY_SOURCE } from './model'
import type { ComponentSource } from './model'
import { SourceCard } from './SourceCard'

afterEach(cleanup)

const PROD: ComponentSource = {
  ...EMPTY_SOURCE,
  originSystem: 'GroupAI platform',
  environment: 'Prod',
  path: 'agents/epsilon/AGENT.md',
  revision: 'prod-2026.10.08',
  lastSynced: '14 Oct 2026 06:00',
  syncTrigger: 'Scheduled pull',
  pulledBy: 'Service account',
  url: 'https://example.test/agents/epsilon/AGENT.md',
}

describe('SourceCard', () => {
  it('shows the provenance of a Prod component with the Prod pill and the ingest rule', () => {
    render(<SourceCard source={PROD} />)
    expect(screen.getByText('GroupAI platform')).toBeInTheDocument()
    expect(screen.getByTitle('Tested in Prod')).toBeInTheDocument()
    expect(screen.getByText('agents/epsilon/AGENT.md')).toBeInTheDocument()
    expect(screen.getByText('Scheduled pull \u00b7 14 Oct 2026 06:00')).toBeInTheDocument()
    expect(screen.getByText(/Only Prod is ingested/)).toBeInTheDocument()
    const link = screen.getByRole('link', { name: 'Open source' })
    expect(link).toHaveAttribute('href', PROD.url)
    expect(link).not.toHaveAttribute('target')
  })

  it('marks an environment that is not Prod', () => {
    render(<SourceCard source={{ ...PROD, environment: 'UAT' }} />)
    expect(screen.getByText('(not Prod)')).toBeInTheDocument()
    expect(screen.queryByTitle('Tested in Prod')).toBeNull()
    expect(screen.queryByText(/Only Prod is ingested/)).toBeNull()
  })

  it('leaves out rows without a value and an unsafe link', () => {
    render(<SourceCard source={{ ...EMPTY_SOURCE, source: 'catalogue.csv', url: 'javascript:alert(1)' }} />)
    expect(screen.getByText('catalogue.csv')).toBeInTheDocument()
    expect(screen.queryByText('Origin system')).toBeNull()
    expect(screen.queryByText('Revision')).toBeNull()
    expect(screen.queryByRole('link', { name: 'Open source' })).toBeNull()
  })

  it('says when no source is recorded', () => {
    render(<SourceCard source={EMPTY_SOURCE} />)
    expect(screen.getByText('No source recorded.')).toBeInTheDocument()
  })
})
