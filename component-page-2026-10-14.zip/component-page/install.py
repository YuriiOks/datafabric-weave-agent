#!/usr/bin/env python3
"""Install the component page bundle into a bp-card-matured checkout.

Run it from anywhere outside the repository, for example after unzipping into
/home/user/bpc-port/component-page:

    python3 install.py --inspect     # read-only: verify the bundle, check the target, find the page to wire
    python3 install.py               # copy the new files into the target worktree

What it does, and what it never does:
- verifies every file against MANIFEST.sha256 before touching anything;
- only adds files under frontend/src/features/recsys/component-page/;
- never overwrites a file that differs, unless --update is given, and then it first copies the
  old file to a backup folder outside the repository;
- never runs git add, commit or push, never runs tests, lint or type checks. It prints the
  commands for those so you can run them when you decide to.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

DEFAULT_TARGET = "/home/user/bp-card-matured/.worktrees/poc-suggested-components"
BUNDLE = Path(__file__).resolve().parent
PAYLOAD = BUNDLE / "files"
MANIFEST = BUNDLE / "MANIFEST.sha256"
PAGE_DIR = "frontend/src/features/recsys/component-page"
RECSYS = "frontend/src/features/recsys"

# What the new files import from the existing code, and the names they need from it.
DEPENDENCIES = [
    (RECSYS + "/components/FacetBand.tsx", ["export function FacetBand"]),
    (RECSYS + "/components/cardStyles.ts", ["TYPE_BADGE_BACKGROUND", "idPillStyle", "typePillStyle"]),
    (RECSYS + "/components/ComponentCard.tsx", ["export function ComponentCard"]),
    (RECSYS + "/labels.ts", ["COMPONENT_TYPE_SINGULAR"]),
]
TYPES_CANDIDATES = [RECSYS + "/types.ts", RECSYS + "/types/index.ts"]
TYPE_NAMES = ["ComponentType", "ComponentSummary"]
PACKAGES = ["react", "react-router-dom", "antd"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_manifest() -> dict[str, str]:
    entries: dict[str, str] = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        entries[rel.strip()] = digest.strip()
    return entries


def verify_bundle() -> dict[str, str]:
    if not MANIFEST.is_file() or not PAYLOAD.is_dir():
        sys.exit("bundle incomplete: MANIFEST.sha256 or files/ is missing next to install.py")
    manifest = read_manifest()
    on_disk = {str(p.relative_to(PAYLOAD)) for p in PAYLOAD.rglob("*") if p.is_file() and p.name != ".DS_Store"}
    problems = []
    for rel, digest in sorted(manifest.items()):
        path = PAYLOAD / rel
        if not path.is_file():
            problems.append("missing  " + rel)
        elif sha256(path) != digest:
            problems.append("changed  " + rel)
    for rel in sorted(on_disk - set(manifest)):
        problems.append("unlisted " + rel)
    for rel in manifest:
        if not rel.startswith(PAGE_DIR + "/"):
            problems.append("outside the page folder " + rel)
    if problems:
        print("Bundle check FAILED:")
        for problem in problems:
            print("  " + problem)
        sys.exit(1)
    print("Bundle check ok: %d files match MANIFEST.sha256" % len(manifest))
    return manifest


def git(target: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(target), *args], capture_output=True, text=True)
    return (result.stdout or result.stderr).rstrip()


def check_target(target: Path) -> bool:
    print("\nTarget: " + str(target))
    if not (target / RECSYS).is_dir():
        print("  NOT a bp-card-matured checkout with the recsys feature (" + RECSYS + " is missing)")
        return False
    print("  branch: " + (git(target, "branch", "--show-current") or "(detached)"))
    print("  head:   " + git(target, "log", "-1", "--format=%h %s"))
    ok = True
    for rel, needles in DEPENDENCIES:
        path = target / rel
        if not path.is_file():
            print("  MISSING " + rel)
            ok = False
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        absent = [n for n in needles if n not in text]
        print(("  ok      " if not absent else "  CHECK   ") + rel + ("" if not absent else "  (not found: " + ", ".join(absent) + ")"))
        ok = ok and not absent
    types = next((target / c for c in TYPES_CANDIDATES if (target / c).is_file()), None)
    if types is None:
        print("  MISSING " + " or ".join(TYPES_CANDIDATES))
        ok = False
    else:
        text = "\n".join(p.read_text(encoding="utf-8", errors="replace") for p in types.parent.glob("*.ts")) if types.name == "index.ts" else types.read_text(encoding="utf-8", errors="replace")
        absent = [n for n in TYPE_NAMES if not re.search(r"\b(type|interface)\s+" + n + r"\b", text) and n not in text]
        print(("  ok      " if not absent else "  CHECK   ") + str(types.relative_to(target)) + ("" if not absent else "  (not found: " + ", ".join(absent) + ")"))
        ok = ok and not absent
    package = target / "frontend/package.json"
    if package.is_file():
        text = package.read_text(encoding="utf-8")
        for name in PACKAGES:
            match = re.search(r'"' + re.escape(name) + r'"\s*:\s*"([^"]+)"', text)
            print("  " + ("ok      " if match else "MISSING ") + "package " + name + (" " + match.group(1) if match else ""))
            ok = ok and bool(match)
    return ok


def find_detail_page(target: Path) -> None:
    """Print where the current component page lives, to wire the new layout in (see WIRING.md)."""
    src = target / "frontend/src"
    hits = []
    for path in src.rglob("*.tsx"):
        if PAGE_DIR in str(path) or path.name.endswith(".test.tsx"):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if "Back to registry" in text or ("useParams" in text and "/registry" in text):
            hits.append((path, text))
    print("\nCurrent component page candidates (wire ComponentDetailLayout in here):")
    if not hits:
        print("  none found; search for the route of /registry/:id in the router")
    for path, text in hits[:4]:
        print("  " + str(path.relative_to(target)) + "  (%d lines)" % text.count("\n"))
        for line in text.splitlines():
            if line.startswith("import ") or re.search(r"recsysApi\.\w+|useQuery|Detail\b|<h1|Back to registry", line):
                print("      " + line.strip()[:150])
    types_dir = target / RECSYS / "types"
    files = list(types_dir.glob("*.ts")) if types_dir.is_dir() else [p for p in [target / RECSYS / "types.ts"] if p.is_file()]
    print("\nDetail and relation types in the recsys types:")
    for path in files:
        for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if re.search(r"(export )?(type|interface) \w*(Detail|Relation|Link|Provenance|Source)\w*", line):
                print("  %s:%d  %s" % (path.relative_to(target), number, line.strip()[:150]))


def install(target: Path, manifest: dict[str, str], update: bool) -> None:
    added, same, replaced, conflicts = [], [], [], []
    for rel, digest in sorted(manifest.items()):
        dest = target / rel
        if not dest.exists():
            added.append(rel)
        elif sha256(dest) == digest:
            same.append(rel)
        elif update:
            replaced.append(rel)
        else:
            conflicts.append(rel)
    if conflicts:
        print("\nNot installed: these files already exist with other content (nothing was changed):")
        for rel in conflicts:
            print("  " + rel)
        print("Run with --update to replace them; the old copies are backed up outside the repository first.")
        sys.exit(1)
    if replaced:
        backup = Path("/home/user/bpc-port/backup/component-page-" + time.strftime("%Y%m%d-%H%M%S"))
        if not Path("/home/user/bpc-port").is_dir():
            backup = BUNDLE.parent / ("component-page-backup-" + time.strftime("%Y%m%d-%H%M%S"))
        for rel in replaced:
            (backup / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target / rel, backup / rel)
        print("\nBacked up %d files to %s" % (len(replaced), backup))
    for rel in added + replaced:
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PAYLOAD / rel, dest)
    print("\nInstalled: %d added, %d replaced, %d already up to date" % (len(added), len(replaced), len(same)))
    for rel in added:
        print("  + " + rel)
    for rel in replaced:
        print("  ~ " + rel)
    for rel, digest in manifest.items():
        if sha256(target / rel) != digest:
            sys.exit("post-install check failed for " + rel)
    print("Post-install check ok: every installed file matches the manifest")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--target", default=DEFAULT_TARGET, help="the worktree to install into (default: %(default)s)")
    parser.add_argument("--inspect", action="store_true", help="read only: verify, check the target, find the page to wire")
    parser.add_argument("--update", action="store_true", help="replace bundle files that differ, after a backup")
    parser.add_argument("--force", action="store_true", help="install even when a dependency check fails")
    args = parser.parse_args()

    target = Path(args.target).expanduser().resolve()
    if BUNDLE == target or target in BUNDLE.parents:
        sys.exit("unzip the bundle outside the repository (for example /home/user/bpc-port/component-page)")
    manifest = verify_bundle()
    ok = check_target(target)
    if args.inspect:
        if (target / RECSYS).is_dir():
            find_detail_page(target)
        print("\nInspect only: nothing was written.")
        return
    if not ok and not args.force:
        sys.exit("\nTarget check failed; nothing was written. Fix the target, or rerun with --force.")
    install(target, manifest, args.update)

    print("\ngit status of the page folder (nothing is staged or committed):")
    print(git(target, "status", "--short", "--", PAGE_DIR) or "  (clean)")
    print("\ngit diff --stat (tracked files only; the new files show above as untracked):")
    print(git(target, "diff", "--stat") or "  (no tracked changes)")
    print("\nNext: wire the page as WIRING.md describes (" + str(BUNDLE / "WIRING.md") + ").")
    print("Checks to run when you decide to (this script does not run them):")
    print("  cd " + str(target / "frontend"))
    print("  npx eslint src/features/recsys/component-page")
    print("  npx tsc --noEmit -p .")
    print("  npx vitest run src/features/recsys/component-page")


if __name__ == "__main__":
    main()
