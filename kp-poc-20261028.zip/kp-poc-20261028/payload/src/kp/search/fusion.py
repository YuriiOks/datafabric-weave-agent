"""Reciprocal-rank fusion of ranked lists, followed by a source-authority weight."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Final

from kp.domain import SourceKind

RRF_DEPTH: Final = 50
RRF_CONSTANT: Final = 60
DEFAULT_AUTHORITY_WEIGHTS: Final[Mapping[SourceKind, float]] = {
    SourceKind.REGULATORY_REPO: 1.0,
    SourceKind.DOCUMENT_LIBRARY: 0.9,
    SourceKind.CONFLUENCE: 0.8,
    SourceKind.GITHUB: 0.7,
    SourceKind.JIRA: 0.7,
}


def reciprocal_rank_fusion(
    rankings: Sequence[Sequence[str]], depth: int = RRF_DEPTH, constant: int = RRF_CONSTANT
) -> dict[str, float]:
    """Combine ranked id lists: each id scores ``1 / (constant + rank)`` per list.

    :param rankings: Ranked lists of ids, best first
    :param depth: Only the top ``depth`` of each list takes part
    :param constant: The RRF smoothing constant
    :return: Fused score per id that appears in at least one list
    """
    fused: dict[str, float] = {}
    for ranking in rankings:
        for rank, item in enumerate(ranking[:depth], start=1):
            fused[item] = fused.get(item, 0.0) + 1.0 / (constant + rank)
    return fused
