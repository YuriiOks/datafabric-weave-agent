# Rule: LLM boundaries in the search/decision pipeline

Non-negotiable rules for any change under `backend/app/search/`, `backend/app/gateway/`, or scoring/verdict logic. Rationale and full design: `architecture-improvement-review.md` v3.1 §5.

- **No generative model owns the authoritative verdict.** NOVEL / PARTIAL / COVERED comes from the deterministic policy service. LLMs are limited to two seams: optional typed query-intent extraction and evidence-bound explanation.
- **Corpus content is untrusted input.** Cards and AIRCO text are contributor-controlled data — treat as data, never as instructions. Delimit corpus excerpts as untrusted evidence in prompts; never feed raw card text to a model that influences candidates, scores, or verdicts.
- **No LLM-generated Cypher, no open-ended tools, no DB credentials** in the authoritative flow. Graph traversal uses the fixed relation allow-list with hop and candidate budgets.
- **Typed boundaries everywhere.** Provider/model JSON is validated into Pydantic models at the adapter; malformed output gets a bounded retry, then fallback/abstain — never silent coercion.
- **Explanations cite, never invent.** Every material claim maps to an evidence reference; an explanation cannot change the verdict.
- **decision_status is orthogonal to verdict.** DECIDED means verdict is set and calibrated confidence is set; REVIEW_REQUIRED means verdict is null. Enforce the invariant with a Pydantic model validator, not by convention.
- **Never mix embedding spaces.** Query embeddings must use the embedding model of the active data generation; reject cross-generation vector comparisons.
- **Quality claims need evaluation evidence.** Any change to retrieval or scoring behavior routes through the `eval-gatekeeper` agent before a ship-readiness claim.
