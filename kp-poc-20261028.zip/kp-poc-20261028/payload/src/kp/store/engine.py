"""Engine construction and the unit-of-work helper."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from typing import Final

from sqlalchemy import Connection, Engine, create_engine, event
from sqlalchemy.engine import make_url
from sqlalchemy.pool import ConnectionPoolEntry, StaticPool

from kp.config import Mode, Settings
from kp.store.schema import metadata

IN_MEMORY_SQLITE: Final = "sqlite+pysqlite:///:memory:"


def create_engine_from_settings(settings: Settings) -> Engine:
    """Build an engine for ``settings.database_url``.

    SQLite gets foreign-key enforcement (off by default there) so tests catch the same
    integrity errors PostgreSQL would. In-memory SQLite shares one connection so the schema
    survives across checkouts.

    :param settings: Platform settings
    :return: A new engine; the caller owns disposal
    """
    return create_engine_for_url(settings.database_url.get_secret_value())


def create_engine_for_url(database_url: str) -> Engine:
    """Build an engine for an explicit URL. See :func:`create_engine_from_settings`.

    :param database_url: A SQLAlchemy URL
    :return: A new engine; the caller owns disposal
    """
    url = make_url(database_url)
    if url.get_backend_name() != "sqlite":
        return create_engine(url, pool_pre_ping=True)
    if url.database in (None, "", ":memory:"):
        engine = create_engine(url, poolclass=StaticPool, connect_args={"check_same_thread": False})
    else:
        engine = create_engine(url)
    event.listen(engine, "connect", _enable_sqlite_foreign_keys)
    return engine


def _enable_sqlite_foreign_keys(dbapi_connection: object, _record: ConnectionPoolEntry) -> None:
    # The DBAPI connection is untyped; PRAGMA is the only call made on it.
    cursor = dbapi_connection.cursor()  # type: ignore[attr-defined]  # untyped DBAPI object
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


def create_all(engine: Engine) -> None:
    """Create every table that does not exist yet.

    :param engine: The target engine
    """
    metadata.create_all(engine)


class Database:
    """Owns an engine and hands out transactional connections.

    Lanes write their own repositories as functions or small classes that take a
    :class:`sqlalchemy.Connection` obtained from :meth:`transaction`; there is no shared ORM.

    :param engine: The engine to use
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    @classmethod
    def from_settings(cls, settings: Settings) -> Database:
        """Build a database from settings.

        :param settings: Platform settings
        :return: A database around a new engine
        """
        return cls(create_engine_from_settings(settings))

    @property
    def engine(self) -> Engine:
        """The underlying engine."""
        return self._engine

    def create_all(self) -> None:
        """Create every table that does not exist yet."""
        create_all(self._engine)

    def ensure_schema(self, settings: Settings) -> None:
        """Create missing tables on a local stand-in database, and never on a real one.

        Real mode runs against a shared database whose tables are created once, by
        ``kp init-db``; a command that quietly ran DDL there would change it from whichever
        process started first.

        :param settings: Platform settings; only the mode matters
        """
        if settings.mode is Mode.LOCAL:
            self.create_all()

    @contextmanager
    def transaction(self) -> Iterator[Connection]:
        """Open a connection in a transaction: commit on success, roll back on any error.

        :return: A context manager yielding the connection
        """
        with self._engine.begin() as connection:
            yield connection

    def dispose(self) -> None:
        """Release pooled connections."""
        self._engine.dispose()
