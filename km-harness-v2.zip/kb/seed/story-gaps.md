# Story gaps

What each story description leaves out, from a review of the story texts against the programme
sources. Roles are used instead of names. Placeholders are explained in kb/seed/glossary.md.

Labels. A gap in a story text is Observed against that text. Every statement about the existing
application, the programme or the legacy work is Reported (people, decks, chat). Check against
kb/verified before use. Code wins over everything here. Severity is the review's view.
Each story also lacks acceptance criteria and a named output format. Ask for both.

## Cross-cutting
- Only 11 of the 13 stories in the sprint were recorded in the notes. Two are missing.
- Stories are one to three bullets taken from one long post by the technical lead.
- No story has acceptance criteria, estimates, subtasks or a definition of done.
- Dependencies exist only as clone links. The working chain (Proposed): namespaces feed storage
  paths (S6) and the product model (S3); the product model supplies the owner and role fields
  that roles (S4) need; gaps and risks (S2) feed the future backlog.
- All six stories are review or design work. The sprint goal implies building.
- Time is short and several owners are away part of the sprint. Name a reviewer per story.
- Asks in the original post dropped from the stories: custom quality metric rules, directory
  roles, group authentication, decision and terminology extraction, "not fully model-driven",
  enrichment, factual-accuracy checks. The first-release outline (a deck) was almost ignored.

## S1 Review existing components (severity: medium)
Left out:
- How admin rights for upload are granted today, and the plan for group-based authentication.
  [Reported] Detail in kb/private/seed-context.md when that file exists.
- Ontology versioning. [Reported] The lead says uploaded ontologies are version-controlled in
  object storage. The story only says "object storage". What versioning really exists is for
  kb/base to answer.
- AI search. [Reported] The lead says it runs over the relational store and the graph that
  holds the ontology. GRAPH_STORE is not named in the story.
- Status values shown by the running dev application are not in the story. [Reported] Record
  the status fields and what sets them. A displayed status may be runtime state, not code.
- BASE_REPO and CAPTURE_REPO are not named. The request to check a related team's codebase for
  reuse is not in any story.
- No output format. The status words (working, partial, missing) are not tied to the maturity
  legend used in the programme deck and the delivery lead's spreadsheet.
- Overlap with the story that documents current architecture. The split is not stated.
Raise as uncovered scope:
- A reuse check of the related team's code (S1 or the architecture story). The LEGACY_REVIEW
  report has unread pages.
- A finding list for the status values above.

## S2 Identify gaps and risks (severity: medium)
Left out:
- Authentication risk: see kb/private/seed-context.md section 6 when that file exists.
- Privacy and restricted-information checks before processing (a step in the first-release
  outline).
- Access control on publication to authorised consumers.
- Open choice of GRAPH_STORE. [Reported] The notes mention a possible later move from one graph
  product to another. The base application and the legacy work use different ones.
- Fit with the planned multi-tenant, multi-region design with a single control plane, and with
  the platform deployment constraints.
- [Reported] Status words in documents and screens (mock-up, live, planned) may not match
  what is live. They are Reported; code decides what is live.
- No format such as a risk register with severity and owner. No hand-off to the future backlog.
Raise as uncovered scope:
- Privacy and restricted-information checks: a design item in S6 and a risk here.
- Directory groups for admin rights: a spike, with the risk recorded here.

## S3 Define the knowledge-product model (severity: high)
Left out:
- Detail on each field. Scope means documents and ontologies uploaded by the owner. Structure
  means structured, unstructured, graph, or a mix. Quality metrics means custom metrics from a
  rules engine, with a standard rights-expression language and logic gates named as references.
  Owners and roles means link to owners or custom roles through the directory.
- The business owner's items under "define": identify consumers, define knowledge requirements,
  define knowledge outcomes, define quality criteria.
- First-release metadata: ownership, provenance, classification, access, retention, lifecycle.
  Approval needs approver, date and status.
- Lifecycle values: draft, in review, awaiting approval, approved, published, plus archive
  or retire.
- Namespace and version fields. No link to the nomination of a producer for a knowledge asset.
- No agreed schema or DDL as the output. Whether a product entity already exists is for
  kb/base to answer. Do not assume either way.
Raise as uncovered scope:
- A rules engine for custom quality metrics. A design spike, or a sub-task of S3.
- Enrichment workflow: custom metadata, business context, annotations, classifications.
- A workflow to capture factual accuracy and consistency, and an evaluation framework for
  producer review. Pair them.
- Discover stage: identify experts, assess source suitability, find knowledge gaps.

## S4 Define roles and permissions (severity: high)
Left out:
- Delegates have fine-grained access that the domain or sub-domain owner sets. The story fixes
  delegate rights in a fixed matrix.
- Custom roles through the directory, and group authentication for admin rights.
- The first-release roles are not mapped: steward (approves), producer (initiates, reviews),
  consumer (authorised access through CONSUMPTION_LAYER or the tool server). Reconcile them with
  admin, owner and delegate.
- Review routing roles: route to owner, ontologist, data owner. Separate approval of content,
  metadata, semantic model, graph and vector by role.
- Consumer-side authorisation for published products.
- The dependency on namespaces for scoping is not stated.
- No sign-off step for the matrix.
Raise as uncovered scope:
- Directory-linked owners and custom roles: add to S4.
- Steward approval workflow with request status tracking: S4 defines who may approve, not how.
- Publish through the tool server on AGENT_HUB: the headline outcome of the first release, and
  absent from the board.

## S5 Design the extraction-to-graph workflow (severity: high)
Left out:
- Decisions and terminology are dropped from the list of extracted things.
- Design constraints: not fully model-driven, users bring their own schema and ontology, use the
  foundational ontology and the ontologies already uploaded.
- A human review step for content, entities and relationships with evidence, provenance and
  confidence.
- The business owner's extract and transform items: identify missing information, standardise
  terms, normalise data, map to the knowledge taxonomy, resolve conflicting knowledge, create a
  canonical form.
- Namespace isolation of graphs.
- A scope conflict: the first release makes graph output optional and puts ontology linkage out
  of scope, but the workflow is ontology-driven.
- The boundary between the platform and PROCESSING_SERVICE is not addressed. The choice of
  GRAPH_STORE is not addressed.
- Existing extractors are not referenced. [Reported] The capability table lists one built in
  code and one prototype in the legacy work. Where they live and what they do is unchecked.
Raise as uncovered scope:
- PROCESSING_SERVICE integration: submit a request by API, then parse, chunk and embed.
  Stories for this and for the legacy comparison were promised and are not on the board.
- Evaluation framework for extraction quality.

## S6 Design ingestion (severity: high)
Left out:
- The pilot sources are not listed. They include the shared data layer, the wiki, the document
  share, the ticket system, the management-information store and the source host. PILOT_USE_CASE
  needs these onboarded and exposed to AGENT_HUB.
- CAPTURE_REPO is not referenced. [Reported] Its own README describes immutable capture of wiki,
  ticket and source-host content with an audit table. Its scope and scale limits are not in the
  story. Verify both before relying on it.
- "Tables created at run time" is reduced to "dynamic tables" with no domain or sub-domain scope.
- The business owner's ingest items: ingest repository content, capture expert knowledge, set
  ingestion schedules, capture source metadata, apply access and security controls.
- Privacy checks before processing, and the call to PROCESSING_SERVICE, are not in the design.
- Dependencies are not stated: namespaces, audit, and the product model.
- No output such as a path convention document or a connector list with availability.
Raise as uncovered scope:
- Onboarding the PILOT_USE_CASE sources: a new story. [Reported] The prototype covers a slice.
- Namespace isolation for graphs, data sources and file systems, with an audit of each
  namespace. The owner is another engineer. Coverage cannot be checked because those texts were
  not recorded.
- Maintain stage: monitor source changes, refresh, re-extract, revalidate, retire, impact.
- Consume stage: search, API and assisted access, usage analytics, consumer feedback.
- A capability check of a wiki-style knowledge approach, raised by the programme lead. Our lead
  offered to take it. The programme lead asked to check PROCESSING_SERVICE first.
- Mapping to the platform deployment model, owned by the architect.
