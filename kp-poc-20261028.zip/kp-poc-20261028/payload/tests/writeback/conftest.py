"""Shared fixtures of the write-back tests: settings, seeded tables, recording fakes."""

from __future__ import annotations

import os
from datetime import date
from pathlib import Path

import pytest
from sqlalchemy import insert

from kp.clock import FixedClock
from kp.config import Mode, Settings
from kp.domain import (
    ApprovalState,
    ExtractionStatus,
    ItemType,
    LinkKind,
    LinkState,
    RunKind,
    RunOutcome,
    SourceKind,
    Story,
    StoryLink,
    Template,
)
from kp.store import Database
from kp.store.schema import (
    clause,
    edition,
    link,
    requirement,
    run,
    source_item,
    story,
)
from kp.store.schema import template as template_table
from kp.writeback import (
    InMemorySessionRetrievals,
    JiraSyncService,
    SpecPublishingService,
    WriteTools,
    parse_template,
    resolve_git_binary,
)
from writeback.writeback_support import (
    CLAUSE_TEXTS,
    LINK_FIELD,
    NOW,
    REPOSITORY,
    RETRIEVED,
    SESSION,
    SPEC_PATH,
    MemoryAudit,
    RecordingPublisher,
    ScriptedJira,
    Seeded,
    Writers,
)


@pytest.fixture
def settings() -> Settings:
    """Local settings with the three write limits configured."""
    return Settings(
        _env_file=None,
        mode=Mode.LOCAL,
        spec_repo=REPOSITORY,
        spec_path=SPEC_PATH,
        jira_fields_allowed=("status", LINK_FIELD),
    )


@pytest.fixture
def clock() -> FixedClock:
    """A clock fixed at 2 Nov 2026."""
    return FixedClock(NOW)


@pytest.fixture
def git_binary() -> str:
    """A working git executable (``KP_GIT_BINARY`` or ``git``).

    Locally the test is skipped without one. Under CI (the ``CI`` variable is set) it fails
    instead, so the real-repository checks of US-19 can never be skipped silently.
    """
    found = resolve_git_binary()
    if found is None:
        message = "no working git binary (set KP_GIT_BINARY)"
        if os.environ.get("CI"):
            pytest.fail(message)
        pytest.skip(message)
    return found


@pytest.fixture
def template(committed_fixtures_dir: Path) -> Template:
    """The governed functional template from the committed fixtures."""
    text = (committed_fixtures_dir / "templates" / "functional-spec.v1.md").read_text(
        encoding="utf-8"
    )
    return parse_template(text)


@pytest.fixture
def seeded(database: Database, template: Template) -> Seeded:
    """Insert a rulebook (two editions), a register row, stories, links and the template."""
    with database.transaction() as connection:
        connection.execute(
            insert(run).values(
                run_id="run-1",
                kind=RunKind.SWEEP.value,
                sources=[],
                started_at=NOW,
                outcome=RunOutcome.SUCCEEDED.value,
                items_touched=0,
            )
        )
        for source, item_id, version in (
            (SourceKind.REGULATORY_REPO, "rulebook", "2026.1"),
            (SourceKind.REGULATORY_REPO, "rulebook", "2025.2"),
            (SourceKind.DOCUMENT_LIBRARY, "register-1", "v1"),
        ):
            connection.execute(
                insert(source_item).values(
                    source=source.value,
                    item_id=item_id,
                    version=version,
                    native_id=f"{item_id}-native",
                    content_sha256="0" * 64,
                    media_type="text/markdown",
                    title="Synthetic",
                    raw_location="raw",
                    fetched_at=NOW,
                    run_id="run-1",
                    extraction_status=ExtractionStatus.NOT_REQUIRED.value,
                    approval_state=ApprovalState.ADMITTED.value,
                )
            )
        for label, effective, superseded in (
            ("2025.2", date(2025, 6, 1), date(2026, 11, 16)),
            ("2026.1", date(2026, 11, 16), None),
        ):
            connection.execute(
                insert(edition).values(
                    label=label,
                    effective_date=effective,
                    superseded_from=superseded,
                    title="Payments Rulebook",
                    source=SourceKind.REGULATORY_REPO.value,
                    item_id="rulebook",
                    version=label,
                )
            )
        clauses = [("2026.1", number, text) for number, text in CLAUSE_TEXTS.items()]
        clauses.append(
            ("2025.2", "4.2.1", "An inbound credit transfer shall be denominated in euro.")
        )
        for label, number, text in clauses:
            connection.execute(
                insert(clause).values(
                    edition=label,
                    number=number,
                    title="",
                    page=3,
                    char_start=0,
                    char_end=len(text),
                    text=text,
                    structure_score=1.0,
                    parent_number=number.rsplit(".", 1)[0],
                )
            )
        connection.execute(
            insert(requirement).values(
                requirement_id="register-1:Requirements:8",
                source=SourceKind.DOCUMENT_LIBRARY.value,
                item_id="register-1",
                version="v1",
                sheet="Requirements",
                row_number=8,
                header_confidence=1.0,
                domain="payments",
                fields={
                    "Req ID": "REQ-004",
                    "Title": "Acknowledge received transfers",
                    "Description": "Every received transfer is acknowledged within five seconds.",
                    "Rule reference": "2026.1 clause 4.1.2",
                },
            )
        )
        for story_row in (
            Story(
                story_key="PAY-101",
                version="v1",
                summary="Acknowledge received credit transfers",
                description="Acknowledge each received transfer quickly.",
                acceptance_criteria="A received transfer is acknowledged within five seconds.",
                links=(StoryLink(link_type="implements", target_key="REQ-004"),),
                domain="payments",
            ),
            Story(
                story_key="PAY-102",
                version="v1",
                summary="Check the creditor account",
                description="Rule: 2026.1 clause 4.2.3.",
                acceptance_criteria="",
                domain="payments",
            ),
            Story(
                story_key="PAY-103",
                version="v1",
                summary="Accept pounds sterling",
                description="Allow inbound credit transfer in pounds sterling.",
                acceptance_criteria="A transfer in pounds sterling is accepted.",
                domain="payments",
            ),
        ):
            values = story_row.model_dump()
            values["links"] = [item.model_dump() for item in story_row.links]
            values["fingerprint"] = story_row.fingerprint()
            connection.execute(insert(story).values(**values))
        connection.execute(insert(template_table).values(**template.model_dump()))
        for source_type, source_key, relation, target_type, target_key in (
            (ItemType.SPEC, "spec-pay-101", "derived_from", ItemType.CLAUSE, "2026.1:4.1.2"),
            (ItemType.SPEC, "spec-pay-101", "implemented_by", ItemType.CODE, "code-a"),
            (ItemType.CODE, "code-a", "verified_by", ItemType.TEST, "test-a"),
        ):
            connection.execute(
                insert(link).values(
                    link_id=f"{source_key}->{target_key}",
                    source_item_type=source_type.value,
                    source_key=source_key,
                    relation=relation,
                    target_item_type=target_type.value,
                    target_key=target_key,
                    kind=LinkKind.STATED.value,
                    state=LinkState.STATED.value,
                    evidence="",
                    valid_from=NOW,
                )
            )
    return Seeded(template=template)


@pytest.fixture
def retrievals() -> InMemorySessionRetrievals:
    """A session ledger the tests fill by hand."""
    return InMemorySessionRetrievals()


@pytest.fixture
def writers(
    database: Database,
    settings: Settings,
    clock: FixedClock,
    retrievals: InMemorySessionRetrievals,
    seeded: Seeded,
) -> Writers:
    """Publishing, Jira sync and tools over recording fakes and the seeded database."""
    publisher, jira, audit = RecordingPublisher(), ScriptedJira(), MemoryAudit()
    sleeps: list[float] = []
    publishing = SpecPublishingService(
        database=database, settings=settings, publisher=publisher, clock=clock
    )
    sync = JiraSyncService(database=database, settings=settings, jira=jira, sleep=sleeps.append)
    retrievals.record(SESSION, RETRIEVED)
    tools = WriteTools(
        publishing=publishing, jira=sync, retrievals=retrievals, audit=audit, clock=clock
    )
    return Writers(publisher, jira, audit, tools, publishing, sync, sleeps)
