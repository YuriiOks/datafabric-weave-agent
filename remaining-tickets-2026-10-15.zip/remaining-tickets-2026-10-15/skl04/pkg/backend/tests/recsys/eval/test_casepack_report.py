"""Denominators: every case in one bucket, failure never counted as a valid empty."""

from __future__ import annotations

import unittest

from app.recsys.contracts.states import RecommendationEligibility
from app.recsys.eval.casepack.cases import (
    Adjudication,
    ExpectedOutcome,
    RelevanceLabel,
    Scenario,
)
from app.recsys.eval.casepack.lineage import CasePackError
from app.recsys.eval.casepack.profiles import SKILL_PROFILE
from app.recsys.eval.casepack.report import (
    CaseObservation,
    ObservedOutcome,
    RunStatus,
    build_report,
    render_report,
)
from app.recsys.eval.casepack.split import Partition, SplitManifest, freeze_final

from . import casepack_support as support

ONE = support.component_id(1)
TWO = support.component_id(2)
THREE = support.component_id(3)
FOUR = support.component_id(4)
FIVE = support.component_id(5)


def _cases(lineage):
    return [
        support.case(
            1,
            lineage=lineage,
            group="g-final",
            adjudication=support.judged({ONE: RelevanceLabel.relevant}),
        ),
        support.case(
            2,
            lineage=lineage,
            group="g-final",
            scenario=Scenario.valid_empty,
            expected=ExpectedOutcome.valid_empty,
            adjudication=support.judged({TWO: RelevanceLabel.not_relevant}),
        ),
        support.case(
            3, lineage=lineage, group="g-dev", scenario=Scenario.hard_negative, forbidden=[FOUR]
        ),
        support.case(
            4,
            lineage=lineage,
            group="g-dev",
            scenario=Scenario.source_unavailable,
            expected=ExpectedOutcome.source_unavailable,
        ),
        support.case(
            5,
            lineage=lineage,
            group="g-dev",
            scenario=Scenario.access_restricted,
            expected=ExpectedOutcome.access_filtered,
            forbidden=[FIVE],
        ),
        support.case(
            6,
            lineage=lineage,
            group="g-val",
            scenario=Scenario.incomplete_description,
            adjudication=Adjudication(labels={THREE: RelevanceLabel.unjudged}),
        ),
    ]


class DenominatorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.corpus = support.corpus()
        self.lineage = self.corpus.lineage.digest()
        self.pack = support.pack(_cases(self.corpus.lineage), self.corpus)
        split = SplitManifest(
            seed="seed-1",
            weights={Partition.development: 1},
            assignments={
                "g-final": Partition.final_test,
                "g-dev": Partition.development,
                "g-val": Partition.validation,
            },
        )
        self.split = freeze_final(self.pack.cases, split)
        self.unfrozen = split

    def _observe(self, case_id: str, **values) -> CaseObservation:
        values.setdefault("status", RunStatus.completed)
        values.setdefault("lineage_digest", self.lineage)
        return CaseObservation(case_id=case_id, **values)

    def _report(self, observations, split=None):
        chosen = self.split if split is None else split
        return build_report(self.pack, self.corpus, chosen, observations, SKILL_PROFILE)

    def test_every_planned_case_lands_in_one_bucket(self) -> None:
        report = self._report(
            [
                self._observe("skl-0001", outcome=ObservedOutcome.ranked, returned_ids=(ONE,)),
                self._observe("skl-0002", outcome=ObservedOutcome.empty),
                self._observe("skl-0003", status=RunStatus.failed, reason="timeout"),
                self._observe("skl-0004", outcome=ObservedOutcome.source_unavailable),
                self._observe("skl-0005", status=RunStatus.disabled, reason="flag_off"),
            ]
        )
        self.assertEqual(
            (report.planned, report.completed, report.failed, report.disabled, report.not_run),
            (6, 3, 1, 1, 1),
        )
        self.assertEqual((report.measured_ranked, report.measured_empty), (1, 1))
        self.assertEqual((report.valid_empty, report.source_unavailable), (1, 1))
        self.assertEqual((report.judged, report.unjudged), (2, 4))
        self.assertEqual(report.reduced_coverage, 1)
        self.assertEqual(report.outcome_mismatch, 0)
        self.assertEqual(report.by_partition[Partition.final_test].completed, 2)
        self.assertFalse(report.promotion_claim)

    def test_a_failed_run_is_not_a_valid_empty(self) -> None:
        report = self._report(
            [self._observe("skl-0002", status=RunStatus.failed, reason="dependency_unavailable")]
        )
        self.assertEqual((report.failed, report.measured_empty, report.valid_empty), (1, 0, 0))
        self.assertIn(
            "2 final-test cases are not both completed and judged", report.claim_blockers
        )

    def test_an_empty_result_where_a_relevant_component_was_judged(self) -> None:
        report = self._report([self._observe("skl-0001", outcome=ObservedOutcome.empty)])
        self.assertEqual((report.measured_empty, report.valid_empty), (1, 0))
        self.assertEqual((report.empty_where_relevant_judged, report.outcome_mismatch), (1, 1))

    def test_forbidden_and_unpublished_ids_block_a_quality_statement(self) -> None:
        report = self._report(
            [
                self._observe(
                    "skl-0003",
                    outcome=ObservedOutcome.ranked,
                    returned_ids=(FOUR, "skill:made-up"),
                )
            ]
        )
        self.assertEqual((report.forbidden_hit_cases, report.forbidden_hits), (1, 1))
        self.assertEqual(report.unpublished_id_cases, 1)
        self.assertIn("forbidden components were returned", report.claim_blockers)
        self.assertIn("components outside the pinned corpus were returned", report.claim_blockers)
        self.assertFalse(report.quality_claim_supported)

    def test_an_excluded_component_returned_blocks(self) -> None:
        records = support.default_records()
        records[3] = support.record(
            4, eligibility=RecommendationEligibility.recommendation_ineligible
        )
        corpus = support.corpus(records)
        pack = support.pack(_cases(corpus.lineage), corpus)
        observation = CaseObservation(
            case_id="skl-0001",
            lineage_digest=corpus.lineage.digest(),
            status=RunStatus.completed,
            outcome=ObservedOutcome.ranked,
            returned_ids=(ONE, FOUR),
        )
        report = build_report(pack, corpus, self.split, [observation], SKILL_PROFILE)
        self.assertEqual((report.excluded_id_cases, report.unpublished_id_cases), (1, 0))
        self.assertIn(
            "components excluded from baseline input were returned", report.claim_blockers
        )

    def test_another_lineage_is_not_measured(self) -> None:
        report = self._report(
            [
                self._observe(
                    "skl-0001",
                    lineage_digest="e" * 64,
                    outcome=ObservedOutcome.ranked,
                    returned_ids=(ONE,),
                )
            ]
        )
        self.assertEqual((report.lineage_mismatch, report.completed), (1, 0))

    def test_a_quality_statement_needs_a_frozen_judged_complete_final_test(self) -> None:
        observations = [
            self._observe("skl-0001", outcome=ObservedOutcome.ranked, returned_ids=(ONE,)),
            self._observe("skl-0002", outcome=ObservedOutcome.empty),
        ]
        report = self._report(observations)
        self.assertEqual(report.claim_blockers, ())
        self.assertTrue(report.quality_claim_supported)
        self.assertFalse(report.promotion_claim)
        unfrozen = self._report(observations, split=self.unfrozen)
        self.assertIn("the final-test partition is not frozen", unfrozen.claim_blockers)

    def test_access_cases_need_a_pinned_read_policy(self) -> None:
        corpus = support.corpus(access_policy_revision=None)
        pack = support.pack(_cases(corpus.lineage), corpus)
        report = build_report(pack, corpus, self.split, [], SKILL_PROFILE)
        self.assertIn("access cases need a pinned read policy", report.claim_blockers)

    def test_observations_name_known_cases_once(self) -> None:
        observation = self._observe("skl-0004", outcome=ObservedOutcome.source_unavailable)
        with self.assertRaisesRegex(CasePackError, "observed twice"):
            self._report([observation, observation])
        with self.assertRaisesRegex(CasePackError, "unknown case"):
            self._report([self._observe("skl-0099", status=RunStatus.blocked)])

    def test_observation_shape_follows_status(self) -> None:
        with self.assertRaises(ValueError):
            self._observe("skl-0001", status=RunStatus.failed, outcome=ObservedOutcome.empty)
        with self.assertRaises(ValueError):
            self._observe("skl-0001", outcome=ObservedOutcome.ranked)
        with self.assertRaises(ValueError):
            self._observe("skl-0001", outcome=ObservedOutcome.empty, returned_ids=(ONE,))

    def test_render_states_no_promotion_claim(self) -> None:
        text = render_report(self._report([]))
        self.assertIn("No promotion claim", text)
        self.assertIn("Quality statement not supported:", text)
        self.assertIn("| Not run | 6 |", text)
