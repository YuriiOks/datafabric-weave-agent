"""Refresh configuration port over the registered acquisition sources.

The configuration snapshot names the registered sources by id and carries a digest of
their full registrations, so a job can only run against the registrations it was
admitted with. Locations, remotes and credentials stay out of the snapshot: they are
covered by the digest and resolved from the registrations at capture time.
"""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Callable, Mapping
from datetime import date, datetime
from enum import Enum
from pathlib import PurePath
from typing import Any

from pydantic import BaseModel, ValidationError

from app.recsys.acquisition.models import RegisteredSource
from app.recsys.contracts.scope import PublicationScope
from app.recsys.refresh.models import CommandIdentity, SourceConfigurationSnapshot
from app.recsys.refresh.ports import ConfigurationChanged

logger = logging.getLogger(__name__)

SOURCE_SET_VERSION = "registered-sources-1"
DIGEST_DOMAIN = "bpc-refresh-source-set-v1"


def canonical(value: Any) -> Any:
    """Return a JSON-ready form whose serialization does not depend on set order.

    :param value: A registration dump or any value inside one.
    :return: Dicts with sorted keys, sets as sorted lists, scalars as JSON scalars.
    """
    if isinstance(value, BaseModel):
        return canonical(value.model_dump(mode="python"))
    if isinstance(value, Mapping):
        return {str(key): canonical(value[key]) for key in sorted(value, key=str)}
    if isinstance(value, (set, frozenset)):
        items = [canonical(item) for item in value]
        return sorted(items, key=lambda item: json.dumps(item, sort_keys=True))
    if isinstance(value, (list, tuple)):
        return [canonical(item) for item in value]
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, PurePath):
        return value.as_posix()
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    return str(value)


def source_set_digest(configuration_id: str, sources: tuple[RegisteredSource, ...]) -> str:
    """Digest the full registrations of a source set.

    :param configuration_id: The configuration the source set backs.
    :param sources: The registrations, in any order.
    :return: Lowercase SHA-256 hex of the canonical registrations.
    """
    payload = {
        "domain": DIGEST_DOMAIN,
        "configuration_id": configuration_id,
        "sources": [canonical(source) for source in sorted(sources, key=lambda s: s.source_id)],
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _collections(source: RegisteredSource) -> list[str]:
    revisions = getattr(source, "collection_revisions", None)
    if revisions is None:
        single = getattr(source, "collection_revision", None)
        revisions = [single] if single is not None else []
    return [revision.collection.value for revision in revisions]


class RegisteredConfigurationPort:
    """``ConfigurationPort`` that serves one configuration over registered sources."""

    def __init__(
        self,
        *,
        configuration_id: str,
        load_sources: Callable[[], tuple[RegisteredSource, ...]],
        credential_references: Mapping[str, str],
    ) -> None:
        """Create the port.

        :param configuration_id: The only configuration id this port resolves.
        :param load_sources: Returns the current registrations; called on every
            resolve and verify so a changed registration is noticed.
        :param credential_references: ``credential-ref:`` name per source id.
        """
        self.configuration_id = configuration_id
        self._load_sources = load_sources
        self._credential_references = dict(credential_references)

    def current_snapshot(self) -> SourceConfigurationSnapshot:
        """Build the snapshot from the registrations as they stand now.

        :return: The configuration snapshot.
        :raises ConfigurationChanged: If the registrations cannot form a snapshot.
        """
        try:
            sources = tuple(self._load_sources())
        except (OSError, ValueError) as error:
            # A missing or oversized workbook surfaces here; the path is not logged.
            logger.error(
                "Refresh source registrations are unavailable",
                extra={"error_type": type(error).__name__},
            )
            raise ConfigurationChanged("source_registration") from error
        scopes = {source.scope for source in sources}
        if len(scopes) != 1:
            raise ConfigurationChanged("scope")
        scope: PublicationScope = next(iter(scopes))
        try:
            return SourceConfigurationSnapshot(
                configuration_id=self.configuration_id,
                source_configuration_version=SOURCE_SET_VERSION,
                source_configuration_digest=source_set_digest(self.configuration_id, sources),
                scope=scope,
                adapter_ids=tuple(sorted(source.source_id for source in sources)),
                required_collections=tuple(
                    sorted({name for source in sources for name in _collections(source)})
                ),
                adapter_parameters={
                    source.source_id: {
                        "authority": source.authority.value,
                        "source_configuration_version": source.source_configuration_version,
                        "required": source.required,
                        "collections": sorted(_collections(source)),
                    }
                    for source in sources
                },
                credential_references={
                    source.source_id: self._credential_references.get(source.source_id, "")
                    for source in sources
                },
            )
        except ValidationError as error:
            logger.error(
                "Refresh source registrations do not form a configuration snapshot",
                extra={"error_count": error.error_count()},
            )
            raise ConfigurationChanged("source_registration") from error

    async def resolve(
        self,
        configuration_id: str,
        identity: CommandIdentity,
    ) -> SourceConfigurationSnapshot:
        """Return the snapshot for the requested configuration.

        :param configuration_id: The configuration the caller asked for.
        :param identity: The authenticated caller.
        :return: The current snapshot.
        :raises ConfigurationChanged: For an unknown id or a scope the caller lacks.
        """
        if configuration_id != self.configuration_id:
            raise ConfigurationChanged("source_configuration_id")
        snapshot = self.current_snapshot()
        if identity.principal.policy_scope != snapshot.scope:
            raise ConfigurationChanged("scope")
        return snapshot

    async def verify_revision(
        self,
        snapshot: SourceConfigurationSnapshot,
    ) -> SourceConfigurationSnapshot:
        """Confirm the registrations still match the snapshot a job was admitted with.

        :param snapshot: The job's snapshot.
        :return: The same snapshot.
        :raises ConfigurationChanged: If any registration changed since.
        """
        if snapshot.configuration_id != self.configuration_id:
            raise ConfigurationChanged("source_configuration_id")
        current = self.current_snapshot()
        if current.source_configuration_digest != snapshot.source_configuration_digest:
            raise ConfigurationChanged("source_configuration_digest")
        return snapshot
