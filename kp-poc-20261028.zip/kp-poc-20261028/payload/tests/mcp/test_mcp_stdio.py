"""MCP over stdio, tested in-process with streams."""

from __future__ import annotations

import io
import json
from collections.abc import Mapping

from mcp_fixtures import *  # noqa: F403 - pytest fixtures

from kp.mcp import McpServer, caller_from_environment, serve_stdio
from kp.tools.testing import InMemoryAudit


def run(server: McpServer, lines: list[str], environ: Mapping[str, str]) -> list[dict[str, object]]:
    stdout = io.StringIO()
    serve_stdio(
        server, caller_from_environment(environ), io.StringIO("\n".join(lines) + "\n"), stdout
    )
    return [json.loads(line) for line in stdout.getvalue().splitlines()]


ENV_FULL = {"KP_CALLER": "user-full-access", "KP_AGENT": "spec-agent", "KP_SESSION_ID": "sess-1"}
INIT = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
CALL = json.dumps(
    {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/call",
        "params": {"name": "search", "arguments": {"query": "currency"}},
    }
)


def test_us16_stdio_serves_a_session_one_json_object_per_line(read_server: McpServer) -> None:
    replies = run(
        read_server,
        [INIT, '{"jsonrpc":"2.0","method":"notifications/initialized"}', "", CALL],
        ENV_FULL,
    )

    assert [r["id"] for r in replies] == [1, 2]
    result = replies[1]["result"]
    assert isinstance(result, dict)
    assert result["isError"] is False


def test_us16_stdio_answers_garbage_with_a_parse_error_and_keeps_going(
    read_server: McpServer,
) -> None:
    replies = run(read_server, ["{broken", CALL], ENV_FULL)

    error = replies[0]["error"]
    assert isinstance(error, dict)
    assert error["code"] == -32700
    assert replies[1]["id"] == 2


def test_us16_stdio_survives_deeply_nested_json_and_serves_the_next_message(
    read_server: McpServer,
) -> None:
    nested = "[" * 100_000 + "]" * 100_000

    replies = run(read_server, [nested, CALL], ENV_FULL)

    error = replies[0]["error"]
    assert isinstance(error, dict)
    assert error["code"] == -32700
    assert replies[1]["id"] == 2


def test_us16_stdio_writes_protocol_messages_only(read_server: McpServer) -> None:
    stdout = io.StringIO()

    serve_stdio(read_server, caller_from_environment(ENV_FULL), io.StringIO(INIT + "\n"), stdout)

    assert stdout.getvalue().count("\n") == 1
    assert stdout.getvalue().endswith("\n")


def test_us17_stdio_identity_comes_from_the_environment_and_is_audited(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    run(read_server, [CALL], ENV_FULL)

    (record,) = audit.records
    assert (record.caller, record.agent, record.session_id) == (
        "user-full-access",
        "spec-agent",
        "sess-1",
    )


def test_us17_stdio_without_identity_is_refused_and_recorded(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    replies = run(read_server, [CALL], {})

    error = replies[0]["error"]
    assert isinstance(error, dict)
    assert error["code"] == -32010
    assert audit.records[0].caller == "anonymous"
    assert audit.records[0].refused is True


def test_us17_stdio_identity_cannot_be_overridden_by_the_message(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    sneaky = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "x"}, "user": "user-full-access"},
        }
    )

    replies = run(read_server, [sneaky], {"KP_CALLER": "user-no-access"})

    assert "error" in replies[0]
    assert audit.records[0].caller == "user-no-access"


def test_us16_stdio_stops_at_end_of_input(read_server: McpServer) -> None:
    assert run(read_server, [], ENV_FULL) == []
