---
name: km-read
description: Bulk-read one source into the kb with parallel km-reader subagents. Use when the owner types /km-read with base, capture, legacy, pdf or wiki, or asks to map a repository, mine the older projects, read the review PDF, or capture wiki pages and story tickets.
argument-hint: base | capture | legacy | pdf | wiki
---

Target: $0. If it is not one of base, capture, legacy, pdf, wiki, print
`usage: /km-read <base|capture|legacy|pdf|wiki>` and stop.

RUN = km-read-$0-<date>, date from `date +%F` (example km-read-base-2026-11-11).
The target file holds the inputs, slices, output files and done-when. Read it now:
- base: ${CLAUDE_SKILL_DIR}/references/base.md
- capture: ${CLAUDE_SKILL_DIR}/references/capture.md
- legacy: ${CLAUDE_SKILL_DIR}/references/legacy.md
- pdf: ${CLAUDE_SKILL_DIR}/references/pdf.md
- wiki: ${CLAUDE_SKILL_DIR}/references/wiki.md

## Method (common to all targets)
1. Inputs. BASE_REPO is the folder in /home/user/km with backend/ and frontend/; CAPTURE_REPO is
   the other clone. Pass readers real paths; kb files say BASE_REPO and CAPTURE_REPO.
   No kb/private/: work from code, wiki and kb/seed, mark what only private would confirm
   Unverified. A needed input missing: write why to kb/log.d/RUN.txt, tell the owner in two
   lines what is needed, stop.
2. Plan slices before reading. List the tree (names and sizes only). Skip .git, dependency and
   build folders, lock files, images, env, key and credential files. Group files by topic into
   slices of at most about 60 KB or 25 files. Name one kb output file per slice. Print the plan
   as a table: slice, inputs, output file.
3. Resume. Skip a slice whose output file exists and says Status complete. For a partial file,
   make a slice of its listed leftovers and write <name>-2.md.
4. Fan out km-reader, up to 3 at once, 1 at a time while a clone or a whole-tree search runs.
   Start the next batch when the current one has returned. Use this task form, filled:

       Goal: Describe how BASE_REPO stores and versions uploaded files, for the S1 table.
       Inputs: /home/user/km/<clone>/backend/<storage module>/ (9 files); <clone>/docs/<file>.
       Output: /home/user/km/kb/base/storage.md. Headings: Layout, Versioning, Access,
         Open questions.
       Size: at most 150 lines, 100 characters a line, one topic.
       Skip: tests, generated files, env and key files.
       Reply: the path, 3 findings, what you skipped. At most 10 lines.

5. The main session reads only the kb files that come back, never the sources. Check each
   against its headings. One repair slice per file at most; then leave the gap in Open questions.
6. Record the run. kb/index.d/RUN.txt: one line per file, `path | summary of 12 words | date`.
   kb/log.d/RUN.txt: date, task, files written, what was skipped and why, anything denied.
7. Run `bash /home/user/km/.claude/bin/kb-lint.sh`. On FAIL fix the files it names (kb files
   from this run only) and run it once more. Report a FAIL that remains.
8. Print a summary of at most 10 lines: files written, skipped, partial; open question count;
   lint result; the next command to type.

Budget: the target file sets the maximum number of reader calls. Stop at it and say what is left.
