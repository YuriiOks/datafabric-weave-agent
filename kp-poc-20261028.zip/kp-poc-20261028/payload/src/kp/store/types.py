"""Dialect-neutral column types."""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import DateTime
from sqlalchemy.engine import Dialect
from sqlalchemy.types import TypeDecorator


class UtcDateTime(TypeDecorator[datetime]):
    """A timezone-aware UTC datetime that round-trips on SQLite as well as PostgreSQL.

    SQLite drops timezone information; this type normalises to UTC on the way in and
    restores the UTC zone on the way out. Naive values are rejected on write.
    """

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(
        self,
        value: datetime | None,
        dialect: Dialect,  # noqa: ARG002 - fixed SQLAlchemy hook signature
    ) -> datetime | None:
        """Convert to UTC before storing.

        :param value: The value being written
        :param dialect: The active dialect
        :return: The UTC datetime, or ``None``
        :raises ValueError: If ``value`` is naive
        """
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("Naive datetime cannot be stored; use a timezone-aware value")
        return value.astimezone(UTC)

    def process_result_value(
        self,
        value: datetime | None,
        dialect: Dialect,  # noqa: ARG002 - fixed SQLAlchemy hook signature
    ) -> datetime | None:
        """Attach UTC to a value read back.

        :param value: The stored value
        :param dialect: The active dialect
        :return: A timezone-aware UTC datetime, or ``None``
        """
        if value is None:
            return None
        return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)
