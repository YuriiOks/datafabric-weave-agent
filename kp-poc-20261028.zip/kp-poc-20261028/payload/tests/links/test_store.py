"""The link store: facts with validity periods, nothing overwritten, every link in the model."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import Connection, insert, select

from kp.clock import FixedClock
from kp.domain import ItemRef, ItemType, LinkKind, LinkState, Relation
from kp.links import (
    AssertOutcome,
    LinkCandidate,
    LinkModelViolationError,
    LinkNotFoundError,
    SqlLinkStore,
    conformance_violation,
)
from kp.store.schema import link as link_table
from links.builders import clause, code, item, requirement, spec, story, verifying_test
from links.conftest import IN_FORCE_NOW


@pytest.fixture
def store(connection: Connection, clock: FixedClock) -> SqlLinkStore:
    return SqlLinkStore(connection, clock)


def test_us13_every_candidate_is_validated_against_the_seven_relations() -> None:
    allowed = LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    wrong_pair = LinkCandidate.stated(story("PAY-1"), Relation.DERIVED_FROM, clause("4.2.1"))
    reversed_edge = LinkCandidate.stated(clause("4.2.1"), Relation.DERIVED_FROM, spec("S1"))

    assert conformance_violation(allowed) is None
    assert "cannot connect story to clause" in str(conformance_violation(wrong_pair))
    assert "cannot connect clause to spec" in str(conformance_violation(reversed_edge))


def test_us13_a_link_outside_the_model_is_refused_and_not_stored(
    store: SqlLinkStore, connection: Connection
) -> None:
    bad = LinkCandidate.stated(story("PAY-1"), Relation.IMPLEMENTED_BY, code("a.py::f"))

    with pytest.raises(LinkModelViolationError, match="cannot connect story to code"):
        store.assert_link(bad)

    assert connection.execute(select(link_table)).first() is None


@pytest.mark.parametrize(
    ("relation", "source", "target"),
    [
        (Relation.SPECIFIED_BY, story("PAY-1"), spec("S1")),
        (Relation.DERIVED_FROM, spec("S1"), requirement("REQ-1")),
        (Relation.DERIVED_FROM, spec("S1"), clause("4.2.1")),
        (Relation.USES_TEMPLATE, spec("S1"), item(ItemType.TEMPLATE, "T-1")),
        (Relation.CONSTRAINED_BY, requirement("REQ-1"), clause("4.2.1")),
        (Relation.RESOLVES_TO, clause("4.2.1"), item(ItemType.SCHEMA_FIELD, "s.json#currency")),
        (Relation.IMPLEMENTED_BY, spec("S1"), code("a.py::f")),
        (Relation.VERIFIED_BY, code("a.py::f"), verifying_test("t.py::test_f")),
    ],
)
def test_us13_all_seven_relations_can_be_stored(
    store: SqlLinkStore, relation: Relation, source: ItemRef, target: ItemRef
) -> None:
    asserted = store.assert_link(LinkCandidate.stated(source, relation, target))

    assert asserted.outcome is AssertOutcome.OPENED
    assert store.get(asserted.link.link_id) == asserted.link


def test_us12_a_change_closes_the_old_fact_and_opens_a_new_one(
    store: SqlLinkStore, clock: FixedClock
) -> None:
    source, target = spec("S1"), code("a.py::f")
    first = store.assert_link(
        LinkCandidate.guessed(
            source, Relation.IMPLEMENTED_BY, target, score=0.6, state=LinkState.REVIEW, evidence="a"
        )
    )
    clock.set(IN_FORCE_NOW + timedelta(days=1))
    second = store.assert_link(
        LinkCandidate.guessed(
            source,
            Relation.IMPLEMENTED_BY,
            target,
            score=0.8,
            state=LinkState.PROPOSED,
            evidence="b",
        )
    )

    history = store.history(source, Relation.IMPLEMENTED_BY, target)

    assert second.outcome is AssertOutcome.CHANGED
    assert [link.link_id for link in history] == [first.link.link_id, second.link.link_id]
    assert history[0].valid_to == history[1].valid_from == IN_FORCE_NOW + timedelta(days=1)
    assert history[0].score == 0.6
    assert history[1].score == 0.8
    assert history[1].is_open
    assert not history[0].is_open


def test_us12_asserting_the_same_fact_again_changes_nothing(
    store: SqlLinkStore, clock: FixedClock
) -> None:
    candidate = LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"), "note")
    first = store.assert_link(candidate)
    clock.set(IN_FORCE_NOW + timedelta(hours=1))

    again = store.assert_link(candidate)

    assert again.outcome is AssertOutcome.UNCHANGED
    assert again.link == first.link
    assert len(store.history(*candidate.fact)) == 1


def test_us12_a_fact_closed_and_asserted_again_in_the_same_instant_does_not_overlap(
    store: SqlLinkStore,
) -> None:
    candidate = LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    store.assert_link(candidate)
    store.close_fact(*candidate.fact)

    again = store.assert_link(candidate)

    first, second = store.history(*candidate.fact)
    assert again.outcome is AssertOutcome.OPENED
    assert first.valid_to == second.valid_from
    assert second.is_open
    assert store.in_use_links(as_at=first.valid_from) == [first]
    assert store.in_use_links() == [second]


def test_us12_a_fact_asserted_again_after_a_later_close_opens_after_the_close(
    store: SqlLinkStore, clock: FixedClock
) -> None:
    candidate = LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
    store.assert_link(candidate)
    clock.set(IN_FORCE_NOW + timedelta(hours=2))
    closed = store.close_fact(*candidate.fact)
    clock.set(IN_FORCE_NOW + timedelta(hours=1))

    store.assert_link(candidate)

    assert closed is not None
    history = store.history(*candidate.fact)
    assert [link.valid_to for link in history[:-1]] == [h.valid_from for h in history[1:]]
    assert history[-1].valid_from == closed.valid_to


def test_us12_a_changed_fact_in_the_same_instant_still_keeps_both_rows(
    store: SqlLinkStore,
) -> None:
    source, target = spec("S1"), code("a.py::f")
    for score in (0.6, 0.7):
        store.assert_link(
            LinkCandidate.guessed(
                source,
                Relation.IMPLEMENTED_BY,
                target,
                score=score,
                state=LinkState.REVIEW,
                evidence="x",
            )
        )

    history = store.history(source, Relation.IMPLEMENTED_BY, target)

    assert [link.score for link in history] == [0.6, 0.7]
    assert history[0].valid_to == history[1].valid_from


def test_us12_links_can_be_read_as_they_were_at_an_earlier_instant(
    store: SqlLinkStore, clock: FixedClock
) -> None:
    source, target = spec("S1"), code("a.py::f")
    store.assert_link(LinkCandidate.stated(source, Relation.IMPLEMENTED_BY, target))
    later = IN_FORCE_NOW + timedelta(days=2)
    clock.set(later)
    store.close_fact(source, Relation.IMPLEMENTED_BY, target)

    assert len(store.in_use_links(IN_FORCE_NOW + timedelta(days=1))) == 1
    assert store.in_use_links(later + timedelta(seconds=1)) == []
    assert store.in_use_links() == []
    assert store.close_fact(source, Relation.IMPLEMENTED_BY, target) is None


def test_us14_review_links_are_listed_for_people_and_never_in_use(store: SqlLinkStore) -> None:
    source = spec("S1")
    store.assert_link(
        LinkCandidate.guessed(
            source,
            Relation.IMPLEMENTED_BY,
            code("a.py::f"),
            score=0.6,
            state=LinkState.REVIEW,
            evidence="x",
        )
    )
    store.assert_link(
        LinkCandidate.guessed(
            source,
            Relation.IMPLEMENTED_BY,
            code("a.py::g"),
            score=0.9,
            state=LinkState.REVIEW,
            evidence="x",
        )
    )

    assert [link.score for link in store.review_list()] == [0.9, 0.6]
    assert store.in_use_links() == []


def test_us14_a_stated_link_replaces_a_guess_for_the_same_fact(store: SqlLinkStore) -> None:
    source, target = spec("S1"), clause("4.2.1")
    store.assert_link(
        LinkCandidate.guessed(
            source, Relation.DERIVED_FROM, target, score=0.8, state=LinkState.PROPOSED, evidence="x"
        )
    )

    store.assert_link(LinkCandidate.stated(source, Relation.DERIVED_FROM, target))

    (current,) = store.in_use_links()
    assert current.kind is LinkKind.STATED
    assert len(store.history(source, Relation.DERIVED_FROM, target)) == 2


def test_us13_closing_the_links_of_a_withdrawn_item_closes_them_all(
    store: SqlLinkStore, clock: FixedClock
) -> None:
    store.assert_link(LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1")))
    store.assert_link(LinkCandidate.stated(spec("S1"), Relation.IMPLEMENTED_BY, code("a.py::f")))
    store.assert_link(LinkCandidate.stated(spec("S2"), Relation.IMPLEMENTED_BY, code("b.py::f")))
    clock.set(IN_FORCE_NOW + timedelta(minutes=1))

    closed = store.close_links_of(spec("S1"))

    assert closed == 2
    assert [link.source_ref.key for link in store.in_use_links()] == ["S2"]


def test_us13_an_unknown_link_identity_is_a_typed_error(store: SqlLinkStore) -> None:
    with pytest.raises(LinkNotFoundError):
        store.get("lnk-missing")


def test_us14_statistics_report_guessed_share_and_average_score(
    store: SqlLinkStore, connection: Connection
) -> None:
    store.assert_link(LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1")))
    store.assert_link(LinkCandidate.stated(spec("S1"), Relation.IMPLEMENTED_BY, code("a.py::f")))
    store.assert_link(
        LinkCandidate.guessed(
            spec("S1"),
            Relation.DERIVED_FROM,
            clause("4.2.2"),
            score=0.8,
            state=LinkState.PROPOSED,
            evidence="x",
        )
    )
    store.assert_link(
        LinkCandidate.guessed(
            spec("S1"),
            Relation.DERIVED_FROM,
            clause("4.2.3"),
            score=1.0,
            state=LinkState.PROPOSED,
            evidence="x",
        )
    )
    store.assert_link(
        LinkCandidate.guessed(
            spec("S1"),
            Relation.DERIVED_FROM,
            clause("4.2.4"),
            score=0.6,
            state=LinkState.REVIEW,
            evidence="x",
        )
    )

    statistics = store.statistics()

    assert (statistics.in_use, statistics.stated, statistics.guessed, statistics.review) == (
        4,
        2,
        2,
        1,
    )
    assert statistics.guessed_share == 0.5
    assert statistics.average_guessed_score == pytest.approx(0.9)
    assert statistics.model_conformance == 1.0


def test_us15_statistics_see_stored_links_that_break_the_model(
    store: SqlLinkStore, connection: Connection
) -> None:
    store.assert_link(LinkCandidate.stated(spec("S1"), Relation.DERIVED_FROM, clause("4.2.1")))
    # A row written around the store, as another tool might: a story cannot implement a clause.
    connection.execute(
        insert(link_table).values(
            link_id="lnk-bad",
            source_item_type="story",
            source_key="PAY-1",
            relation="constrained_by",
            target_item_type="clause",
            target_key="2026.1:4.2.1",
            kind="stated",
            state="stated",
            score=None,
            evidence="",
            valid_from=datetime(2026, 11, 1, tzinfo=UTC),
            valid_to=None,
        )
    )

    statistics = store.statistics()

    assert (statistics.checked, statistics.nonconforming) == (2, 1)
    assert statistics.model_conformance == 0.5
    assert [link.link_id for link in store.in_use_links()] != ["lnk-bad"]
    assert len(store.in_use_links()) == 1
