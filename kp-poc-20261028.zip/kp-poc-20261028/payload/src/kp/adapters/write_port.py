"""Seam: the write MCP server's tool port, backed by the write-back tools.

The write-back package declares its own descriptor, call and result types, field for field the
same as the agent tools' (neither package imports the other). This adapter converts at the
boundary and nothing else.
"""

from __future__ import annotations

from collections.abc import Sequence

from kp.tools import WriteToolCall, WriteToolDescriptor, WriteToolResult
from kp.writeback import WriteToolCall as WritebackCall
from kp.writeback import WriteTools


class WriteToolsPort:
    """The write-back tools as the write server's port.

    :param tools: The write-back tools; build them without an audit sink, because the server's
        registry already records every call and a second record would double it
    """

    def __init__(self, tools: WriteTools) -> None:
        self._tools = tools

    def describe(self) -> Sequence[WriteToolDescriptor]:
        """List the write tools with their input schemas.

        :return: One descriptor per tool
        """
        return [
            WriteToolDescriptor(
                name=item.name, description=item.description, input_schema=item.input_schema
            )
            for item in self._tools.describe()
        ]

    def invoke(self, call: WriteToolCall) -> WriteToolResult:
        """Run one write tool.

        :param call: The call, with identity taken from the transport
        :return: What the tool reports
        :raises ValueError: If the tool is unknown or its arguments are malformed
        :raises kp.errors.WriteNotPermittedError: If the target is outside the allow-list
        """
        result = self._tools.invoke(
            WritebackCall(
                tool=call.tool,
                arguments=call.arguments,
                caller=call.caller,
                agent=call.agent,
                session_id=call.session_id,
                domains=call.domains,
            )
        )
        return WriteToolResult(
            payload=result.payload, items_returned=result.items_returned, spec_id=result.spec_id
        )
