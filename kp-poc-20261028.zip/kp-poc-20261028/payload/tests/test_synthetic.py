"""Key properties of the synthetic dataset and its reproducibility."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from openpyxl import load_workbook
from pypdf import PdfReader

from kp.testing.dataset import SyntheticDataset, load_dataset
from kp.testing.synthetic import DEFAULT_SEED, generate

TEXT_SUFFIXES = {".md", ".json", ".yaml", ".py"}


def _clause_text(dataset: SyntheticDataset, edition: str, number: str) -> str:
    truth = dataset.truth.edition(edition)
    return next(c.text for c in truth.clauses if c.number == number)


def test_currency_clause_exists_in_both_editions_with_different_text(
    dataset: SyntheticDataset,
) -> None:
    earlier = _clause_text(dataset, "2025.2", "4.2.1")
    later = _clause_text(dataset, "2026.1", "4.2.1")

    assert "euro only" in earlier
    assert "pounds sterling" in later
    assert earlier != later


def test_editions_and_effective_dates(dataset: SyntheticDataset) -> None:
    assert [e.label for e in dataset.truth.editions] == ["2025.2", "2026.1"]
    assert dataset.truth.edition("2026.1").effective_date.isoformat() == "2026-11-16"
    assert (
        dataset.truth.edition("2025.2").superseded_from
        == dataset.truth.edition("2026.1").effective_date
    )
    for edition in dataset.truth.editions:
        marker = yaml.safe_load(
            dataset.path(f"regulatory_repo/{edition.label}/edition.yaml").read_text()
        )
        assert marker["edition"] == edition.label


@pytest.mark.parametrize("label", ["2025.2", "2026.1"])
def test_markdown_clause_positions_match_the_text(dataset: SyntheticDataset, label: str) -> None:
    edition = dataset.truth.edition(label)
    markdown = dataset.path(edition.markdown_path).read_text(encoding="utf-8")

    for clause in edition.clauses:
        assert markdown[clause.md_char_start : clause.md_char_end] == clause.text


@pytest.mark.parametrize("label", ["2025.2", "2026.1"])
def test_table_of_contents_lists_every_clause_with_its_page(
    dataset: SyntheticDataset, label: str
) -> None:
    edition = dataset.truth.edition(label)
    markdown = dataset.path(edition.markdown_path).read_text(encoding="utf-8")
    toc_lines = [ln for ln in markdown.splitlines() if ln.lstrip().startswith("- ")]

    assert len(toc_lines) == edition.toc_clause_count == len(edition.clauses)
    for clause, line in zip(edition.clauses, toc_lines, strict=True):
        assert line.strip() == f"- {clause.number} {clause.title} ... {clause.page}"


@pytest.mark.parametrize("label", ["2025.2", "2026.1"])
def test_clause_headings_are_on_the_recorded_pdf_page(
    dataset: SyntheticDataset, label: str
) -> None:
    edition = dataset.truth.edition(label)
    reader = PdfReader(dataset.path(edition.pdf_path))
    page_text = [" ".join((page.extract_text() or "").split()) for page in reader.pages]

    for clause in edition.clauses:
        assert f"{clause.number} {clause.title}" in page_text[clause.page - 1]


def test_clauses_span_three_levels(dataset: SyntheticDataset) -> None:
    depths = {c.depth for c in dataset.truth.edition("2026.1").clauses}

    assert depths == {1, 2, 3}


def test_later_edition_adds_a_clause(dataset: SyntheticDataset) -> None:
    earlier = {c.number for c in dataset.truth.edition("2025.2").clauses}
    later = {c.number for c in dataset.truth.edition("2026.1").clauses}

    assert later - earlier == {"4.2.4"}
    assert earlier <= later


@pytest.mark.parametrize("label", ["2025.2", "2026.1"])
def test_one_clause_is_long_enough_to_need_splitting(dataset: SyntheticDataset, label: str) -> None:
    longest = max(dataset.truth.edition(label).clauses, key=lambda c: len(c.text))

    # Whitespace words are the size proxy; a real tokenizer yields at least as many tokens.
    assert longest.number == "6.3.2"
    assert len(longest.text.split()) > 1_800


def test_register_header_is_not_the_first_row(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.requirements_register
    workbook = load_workbook(dataset.path(truth.path))
    sheet = workbook[truth.main_sheet]

    assert truth.header_row == 4
    assert tuple(cell.value for cell in sheet[truth.header_row]) == truth.header
    assert sheet.max_row - truth.header_row == truth.data_row_count
    assert sheet["A1"].value != truth.header[0]


def test_register_has_a_second_sheet_without_a_header(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.requirements_register
    workbook = load_workbook(dataset.path(truth.path))
    notes = workbook[truth.headerless_sheet]

    assert workbook.sheetnames == [truth.main_sheet, truth.headerless_sheet]
    assert all(row[0].value and len(row) == 1 for row in notes.iter_rows())


def _issues(dataset: SyntheticDataset, path: str) -> dict[str, dict[str, object]]:
    payload = json.loads(dataset.path(path).read_text(encoding="utf-8"))
    return {issue["key"]: issue["fields"] for issue in payload["issues"]}


def test_story_exports_contain_a_status_only_and_a_criteria_change(
    dataset: SyntheticDataset,
) -> None:
    truth = dataset.truth.stories
    first = _issues(dataset, truth.first_export)
    second = _issues(dataset, truth.second_export)

    assert len(first) == len(second) == truth.story_count
    changed = {key for key in first if first[key] != second[key]}
    assert changed == {truth.status_only_key, truth.criteria_changed_key}

    status_only = {
        k: v for k, v in first[truth.status_only_key].items() if k not in ("status", "updated")
    }
    assert status_only == {
        k: v for k, v in second[truth.status_only_key].items() if k not in ("status", "updated")
    }
    assert first[truth.status_only_key]["status"] != second[truth.status_only_key]["status"]
    assert (
        first[truth.criteria_changed_key]["acceptance_criteria"]
        != second[truth.criteria_changed_key]["acceptance_criteria"]
    )
    assert first["PAY-101"]["parent"] == {"key": "PAY-100"}
    assert first["PAY-103"]["issuelinks"]


def test_confluence_pages_cover_label_and_draft_cases(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.confluence

    def page(name: str) -> dict[str, object]:
        loaded = json.loads(dataset.path(f"confluence/{name}.json").read_text(encoding="utf-8"))
        assert isinstance(loaded, dict)
        return loaded

    assert "approved" in page(truth.approved_page)["labels"]  # type: ignore[operator]
    assert "approved" not in page(truth.unlabelled_page)["labels"]  # type: ignore[operator]
    versions = page(truth.page_with_newer_draft)["versions"]
    assert isinstance(versions, list)
    assert versions[-1]["state"] == "draft"
    assert versions[-1]["number"] > max(v["number"] for v in versions if v["state"] == "published")


def test_identity_mapping_has_users_without_and_with_limited_access(
    dataset: SyntheticDataset,
) -> None:
    users = yaml.safe_load(dataset.path("identity/identity-mapping.yaml").read_text())["users"]

    assert users["user-no-access"]["domains"] == []
    assert "payments" not in users["user-no-payments-access"]["domains"]
    assert users["user-one-domain"]["domains"] == ["payments"]
    assert set(users["user-full-access"]["domains"]) == {"cards", "payments"}


def test_code_repo_and_template_exist(dataset: SyntheticDataset) -> None:
    code = dataset.path("code_repo/src/payments/inbound.py").read_text()
    tests = dataset.path("code_repo/tests/test_inbound.py").read_text()
    template = dataset.path("templates/functional-spec.v1.md").read_text()

    assert "2026.1:4.2.1" in code
    assert "2026.1:4.2.1" in tests
    assert "2026.1:4.2.3" not in tests  # a rule with no test, for the coverage question
    assert "## Rules" in template


def test_library_covers_draft_missing_detail_and_unknown_type(dataset: SyntheticDataset) -> None:
    def meta(stem: str) -> dict[str, str | None]:
        return json.loads(dataset.path(f"library/{stem}.meta.json").read_text())  # type: ignore[no-any-return]

    assert meta("operating-guide.v3-draft")["approval_status"] == "draft"
    assert meta("escalation-note")["content_owner"] is None
    assert meta("unclassified-memo")["document_type"] == "unrecognised-type"


def test_same_seed_gives_identical_files(dataset: SyntheticDataset, tmp_path: Path) -> None:
    again = generate(tmp_path / "again", DEFAULT_SEED)

    files = sorted(p.relative_to(dataset.root) for p in dataset.root.rglob("*") if p.is_file())
    assert files == sorted(p.relative_to(again.root) for p in again.root.rglob("*") if p.is_file())
    for relative in files:
        assert (dataset.root / relative).read_bytes() == (again.root / relative).read_bytes(), (
            relative
        )


def test_different_seed_changes_only_seeded_content(
    dataset: SyntheticDataset, tmp_path: Path
) -> None:
    other = generate(tmp_path / "other", DEFAULT_SEED + 1)

    assert _clause_text(other, "2026.1", "6.3.2") != _clause_text(dataset, "2026.1", "6.3.2")
    assert _clause_text(other, "2026.1", "4.2.1") == _clause_text(dataset, "2026.1", "4.2.1")


def test_committed_fixtures_match_the_generator(
    dataset: SyntheticDataset, committed_fixtures_dir: Path
) -> None:
    committed = load_dataset(committed_fixtures_dir)

    assert committed.truth == dataset.truth
    for path in sorted(p for p in dataset.root.rglob("*") if p.suffix in TEXT_SUFFIXES):
        relative = path.relative_to(dataset.root)
        assert (committed_fixtures_dir / relative).read_bytes() == path.read_bytes(), relative
