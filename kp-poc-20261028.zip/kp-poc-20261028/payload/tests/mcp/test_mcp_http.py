"""MCP over HTTP: the request handling is tested without a socket, plus one loopback round trip."""

from __future__ import annotations

import contextlib
import http.client
import json
import socket
import threading
from collections.abc import Iterator

import pytest
from mcp_fixtures import *  # noqa: F403 - pytest fixtures

from kp.mcp import IdentityHeaders, McpHttpGateway, McpServer, create_http_server
from kp.tools.testing import InMemoryAudit

JSON_HEADERS = {"Content-Type": "application/json", "X-KP-Caller": "user-full-access"}
SEARCH = json.dumps(
    {
        "jsonrpc": "2.0",
        "id": 7,
        "method": "tools/call",
        "params": {"name": "search", "arguments": {"query": "currency"}},
    }
).encode()


@pytest.fixture
def gateway(read_server: McpServer) -> McpHttpGateway:
    return McpHttpGateway(read_server)


def test_us16_http_post_answers_with_one_json_body(gateway: McpHttpGateway) -> None:
    response = gateway.handle("POST", "/mcp", JSON_HEADERS, SEARCH)

    assert response.status == 200
    assert response.headers["Content-Type"] == "application/json"
    body = json.loads(response.body)
    assert body["id"] == 7
    assert body["result"]["isError"] is False


def test_us16_http_notification_is_accepted_without_a_body(gateway: McpHttpGateway) -> None:
    body = b'{"jsonrpc":"2.0","method":"notifications/initialized"}'

    response = gateway.handle("POST", "/mcp", JSON_HEADERS, body)

    assert (response.status, response.body) == (202, b"")


def test_us17_http_identity_comes_from_the_header_and_is_audited(
    gateway: McpHttpGateway, audit: InMemoryAudit
) -> None:
    headers = {**JSON_HEADERS, "x-kp-agent": "spec-agent", "X-KP-Session": "sess-http"}

    gateway.handle("POST", "/mcp", headers, SEARCH)

    (record,) = audit.records
    assert (record.caller, record.agent, record.session_id) == (
        "user-full-access",
        "spec-agent",
        "sess-http",
    )


def test_us17_http_requests_without_a_session_header_share_a_stable_session_per_user_and_agent(
    gateway: McpHttpGateway, audit: InMemoryAudit
) -> None:
    headers = {**JSON_HEADERS, "x-kp-agent": "spec-agent"}

    gateway.handle("POST", "/mcp", headers, SEARCH)
    gateway.handle("POST", "/mcp", headers, SEARCH)
    gateway.handle("POST", "/mcp", {**headers, "x-kp-agent": "other-agent"}, SEARCH)

    first, second, third = audit.records
    assert first.session_id == second.session_id == "http-spec-agent"
    assert third.session_id == "http-other-agent"


def test_us17_http_without_an_identity_header_is_forbidden_and_recorded(
    gateway: McpHttpGateway, audit: InMemoryAudit
) -> None:
    response = gateway.handle("POST", "/mcp", {"Content-Type": "application/json"}, SEARCH)

    assert json.loads(response.body)["error"]["code"] == -32010
    assert audit.records[0].refused is True
    assert audit.records[0].caller == "anonymous"


def test_us17_http_identity_in_the_body_does_not_count(
    gateway: McpHttpGateway, audit: InMemoryAudit
) -> None:
    message = json.loads(SEARCH)
    message["params"]["caller"] = "user-full-access"
    message["caller"] = "user-full-access"
    headers = {"Content-Type": "application/json", "X-KP-Caller": "user-no-access"}

    response = gateway.handle("POST", "/mcp", headers, json.dumps(message).encode())

    assert json.loads(response.body)["error"]["code"] == -32010
    assert audit.records[0].caller == "user-no-access"


def test_us17_http_identity_header_name_is_configurable(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    gateway = McpHttpGateway(read_server, names=IdentityHeaders(user="X-Authenticated-User"))

    gateway.handle(
        "POST",
        "/mcp",
        {"content-type": "application/json", "x-authenticated-user": "user-one-domain"},
        SEARCH,
    )

    assert audit.records[0].caller == "user-one-domain"


def test_us16_http_unknown_path_is_404(gateway: McpHttpGateway) -> None:
    assert gateway.handle("POST", "/other", JSON_HEADERS, SEARCH).status == 404


@pytest.mark.parametrize("method", ["GET", "PUT", "DELETE", "PATCH"])
def test_us16_http_other_methods_are_405_with_allow(gateway: McpHttpGateway, method: str) -> None:
    response = gateway.handle(method, "/mcp", JSON_HEADERS, b"")

    assert response.status == 405
    assert response.headers["Allow"] == "POST"


def test_us16_http_requires_a_json_content_type(gateway: McpHttpGateway) -> None:
    headers = {"Content-Type": "text/plain", "X-KP-Caller": "user-full-access"}

    assert gateway.handle("POST", "/mcp", headers, SEARCH).status == 415
    assert gateway.handle("POST", "/mcp", {}, SEARCH).status == 415


def test_us16_http_accepts_a_charset_suffix(gateway: McpHttpGateway) -> None:
    headers = {**JSON_HEADERS, "Content-Type": "application/json; charset=utf-8"}

    assert gateway.handle("POST", "/mcp", headers, SEARCH).status == 200


def test_us16_http_oversized_bodies_are_413(read_server: McpServer) -> None:
    small = McpHttpGateway(read_server, max_body_bytes=10)

    assert small.handle("POST", "/mcp", JSON_HEADERS, SEARCH).status == 413


def test_us16_http_browser_origins_are_refused_unless_allowed(read_server: McpServer) -> None:
    headers = {**JSON_HEADERS, "Origin": "origin-not-allowed"}

    assert McpHttpGateway(read_server).handle("POST", "/mcp", headers, SEARCH).status == 403
    allowed = McpHttpGateway(read_server, allowed_origins=frozenset({"origin-not-allowed"}))
    assert allowed.handle("POST", "/mcp", headers, SEARCH).status == 200


def test_us16_http_deeply_nested_body_is_a_400_parse_error_and_the_next_request_is_served(
    gateway: McpHttpGateway,
) -> None:
    nested = b"[" * 100_000 + b"]" * 100_000

    response = gateway.handle("POST", "/mcp", JSON_HEADERS, nested)

    assert response.status == 400
    assert json.loads(response.body)["error"]["code"] == -32700
    assert gateway.handle("POST", "/mcp", JSON_HEADERS, SEARCH).status == 200


@pytest.mark.parametrize("body", [b"{broken", b"\xff\xfe", b""])
def test_us16_http_unparseable_bodies_are_a_400_parse_error(
    gateway: McpHttpGateway, body: bytes
) -> None:
    response = gateway.handle("POST", "/mcp", JSON_HEADERS, body)

    assert response.status == 400
    assert json.loads(response.body)["error"]["code"] == -32700


def test_us16_http_invalid_request_is_a_400(gateway: McpHttpGateway) -> None:
    response = gateway.handle("POST", "/mcp", JSON_HEADERS, b"[]")

    assert response.status == 400
    assert json.loads(response.body)["error"]["code"] == -32600


def test_us16_http_tool_errors_stay_http_200_json_rpc_errors(gateway: McpHttpGateway) -> None:
    body = SEARCH.replace(b'"currency"', b'""')

    response = gateway.handle("POST", "/mcp", JSON_HEADERS, body)

    assert response.status == 200
    assert json.loads(response.body)["error"]["code"] == -32602


def test_us16_http_loopback_round_trip(read_server: McpServer, audit: InMemoryAudit) -> None:
    try:
        server = create_http_server(McpHttpGateway(read_server), "127.0.0.1", 0)
    except OSError:
        pytest.skip("cannot bind a loopback socket in this environment")
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        port = server.server_address[1]
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            connection.request("POST", "/mcp", body=SEARCH, headers=JSON_HEADERS)
            reply = connection.getresponse()
            status, body = reply.status, json.loads(reply.read())
            connection.request("GET", "/mcp")
            refused = connection.getresponse()
            refused.read()
        finally:
            connection.close()
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)

    assert status == 200
    assert body["result"]["isError"] is False
    assert refused.status == 405
    assert audit.records[0].caller == "user-full-access"


@contextlib.contextmanager
def _serving(server: McpServer, *, max_body_bytes: int, request_timeout: float) -> Iterator[int]:
    gateway = McpHttpGateway(server, max_body_bytes=max_body_bytes)
    try:
        http_server = create_http_server(gateway, "127.0.0.1", 0, request_timeout=request_timeout)
    except OSError:
        pytest.skip("cannot bind a loopback socket in this environment")
    thread = threading.Thread(target=http_server.serve_forever, daemon=True)
    thread.start()
    try:
        yield int(http_server.server_address[1])
    finally:
        http_server.shutdown()
        http_server.server_close()
        thread.join(timeout=5)


def _raw_exchange(port: int, head: str, body: bytes = b"") -> bytes:
    with socket.create_connection(("127.0.0.1", port), timeout=5) as connection:
        connection.sendall(head.encode("ascii") + body)
        chunks: list[bytes] = []
        while chunk := connection.recv(4096):
            chunks.append(chunk)
    return b"".join(chunks)


def _post_head(length: str) -> str:
    return (
        "POST /mcp HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\n"
        f"X-KP-Caller: user-full-access\r\nContent-Length: {length}\r\n\r\n"
    )


@pytest.mark.parametrize(
    ("length", "status"),
    [("abc", 400), ("-1", 400), ("100000", 413)],
    ids=["text", "negative", "big"],
)
def test_us16_http_bad_content_length_is_refused_before_reading_a_body(
    read_server: McpServer, length: str, status: int
) -> None:
    with _serving(read_server, max_body_bytes=1000, request_timeout=5) as port:
        reply = _raw_exchange(port, _post_head(length))

    assert reply.startswith(f"HTTP/1.0 {status} ".encode("ascii"))


def test_us16_http_a_client_that_never_sends_its_body_times_out_and_frees_the_thread(
    read_server: McpServer, audit: InMemoryAudit
) -> None:
    with _serving(read_server, max_body_bytes=1000, request_timeout=0.3) as port:
        reply = _raw_exchange(port, _post_head("500"), b"{")
        # The server is still serving after the stalled client was dropped.
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            connection.request("POST", "/mcp", body=SEARCH, headers=JSON_HEADERS)
            served = connection.getresponse().status
        finally:
            connection.close()

    assert reply.startswith(b"HTTP/1.0 408 ")
    assert served == 200
    assert len(audit.records) == 1
