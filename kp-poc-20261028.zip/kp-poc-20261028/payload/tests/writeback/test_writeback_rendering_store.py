"""US-19: what a pull request carries; persistence of templates, specs and citations."""

from __future__ import annotations

import pytest
from sqlalchemy import func, select

from kp.domain import Spec, SpecState, Template
from kp.errors import TemplateNotFoundError
from kp.store import Database
from kp.store.schema import citation
from kp.writeback import (
    CitationReport,
    SpecRepository,
    TemplateRepository,
    check_citations,
    parse_template,
)
from kp.writeback.rendering import (
    MACHINE_TRAILER,
    MAX_BODY_CHARS,
    commit_message,
    render_pr_body,
    render_spec_file,
    spec_title,
)
from writeback.writeback_support import NOW, Seeded

MARKDOWN = """\
# Acknowledge received credit transfers

## Rules

- A participant shall acknowledge every transfer [ref: 2026.1:4.1.2].
- A bare claim | with a pipe.
"""


def _all_resolve(reference: str) -> bool:
    return True


def _report() -> CitationReport:
    return check_citations(
        MARKDOWN,
        resolves=lambda reference: reference == "2026.1:4.1.2",
        retrieved={"2026.1:4.1.2"},
        target=0.95,
    )


def test_us19_pr_body_carries_template_version_citations_coverage_and_open_items() -> None:
    body = render_pr_body(
        story_key="PAY-101",
        path="specs/PAY-101.md",
        template_id="functional-spec",
        template_version="1.0.0",
        report=_report(),
        coverage={"rules_without_test": ["2026.1:4.1.2"]},
        open_items=("Add acceptance criteria.",),
    )

    assert "`functional-spec` version `1.0.0`" in body
    assert "`specs/PAY-101.md`" in body
    assert "Rule statements: 2" in body
    assert "Citation rate: 50% (is below the 95% target)" in body
    assert "| 1 | A bare claim \\| with a pipe. | no citation |" in body
    assert 'rules_without_test: `["2026.1:4.1.2"]`' in body
    assert "- Add acceptance criteria." in body
    assert "proposed" in body


def _body(**overrides: object) -> str:
    values: dict[str, object] = {
        "story_key": "PAY-101",
        "path": "specs/PAY-101.md",
        "template_id": "t",
        "template_version": "1",
        "report": _report(),
        "coverage": {},
        "open_items": (),
    }
    values.update(overrides)
    return render_pr_body(**values)  # type: ignore[arg-type]  # keyword values built generically


def test_us19_agent_text_cannot_mention_people_or_inject_markup_into_the_pr_body() -> None:
    body = _body(
        open_items=("Ask @someone to look at [this](https://example.invalid) `now` <b>.",),
        coverage={"@team": "`tick` @other"},
    )

    assert "@someone" not in body
    assert "@team" not in body
    assert "&#64;someone" in body
    assert "\\[this\\]" in body
    assert "\\`now\\`" in body
    assert "&lt;b&gt;" in body
    assert "`tick`" not in body


def test_us19_a_large_coverage_value_and_many_open_items_are_cut_with_a_visible_note() -> None:
    body = _body(
        coverage={"big": ["x" * 100] * 100},
        open_items=tuple(f"Item {number}" for number in range(40)),
    )

    coverage_line = next(line for line in body.splitlines() if line.startswith("- big:"))
    assert len(coverage_line) < 600
    assert coverage_line.endswith("...`")
    assert "- Item 29" in body
    assert "Item 30" not in body
    assert "- 10 more open items not shown." in body


def test_us19_a_body_over_the_size_limit_is_truncated_with_a_note() -> None:
    body = _body(coverage={f"key-{number}": "x" * 1000 for number in range(200)})

    assert len(body) <= MAX_BODY_CHARS
    assert body.endswith("(The description was shortened to fit the size limit.)\n")


def test_us21_a_long_list_of_flagged_statements_is_cut_with_a_count() -> None:
    markdown = "# T\n\n## Rules\n\n" + "".join(f"- Rule number {n} is open.\n" for n in range(150))
    report = check_citations(markdown, resolves=_all_resolve, retrieved=set(), target=0.95)

    body = _body(report=report)

    assert body.count("| no citation |") == 100
    assert "50 more flagged statements." in body


def test_us19_pr_body_without_coverage_or_open_items_says_so() -> None:
    report = check_citations("# T\n", resolves=_all_resolve, retrieved=set(), target=0.95)

    body = render_pr_body(
        story_key="PAY-101",
        path="specs/PAY-101.md",
        template_id="t",
        template_version="1",
        report=report,
        coverage={},
        open_items=(),
    )

    assert "No coverage information was supplied." in body
    assert "None." in body
    assert "No rule statements were found" in body
    assert "meets the 95% target" in body


def test_us19_spec_file_is_marked_machine_authored_and_replaces_agent_front_matter() -> None:
    content = render_spec_file(
        "---\nmachine_authored: false\n---\n# Title\n\nBody.\n",
        story_key="PAY-101",
        template_id="functional-spec",
        template_version="1.0.0",
    )

    assert content == (
        "---\nstory: PAY-101\nspec: spec-pay-101\ntemplate: functional-spec@1.0.0\n"
        "machine_authored: true\n---\n"
        "# Title\n\nBody.\n"
    )


def test_us19_commit_message_has_the_machine_authored_trailer() -> None:
    message = commit_message(story_key="PAY-101", template_id="t", template_version="1.0.0")

    assert message.splitlines()[0] == "Draft spec for PAY-101"
    assert MACHINE_TRAILER in message.splitlines()


def test_us19_title_comes_from_the_first_heading() -> None:
    assert spec_title(MARKDOWN, "PAY-101") == "[PAY-101] Acknowledge received credit transfers"
    assert spec_title("No heading\n", "PAY-101") == "[PAY-101] Draft spec"


def test_us19_template_file_is_parsed_with_its_digest(template: Template) -> None:
    assert (template.template_id, template.version, template.spec_type) == (
        "functional-spec",
        "1.0.0",
        "functional",
    )
    assert "## Rules" in template.body
    assert len(template.content_sha256) == 64


@pytest.mark.parametrize("text", ["# No front matter\n", "---\nspec_type: x\n---\nbody\n"])
def test_us19_template_without_identity_is_an_error(text: str) -> None:
    with pytest.raises(TemplateNotFoundError):
        parse_template(text)


@pytest.mark.parametrize("version", ["1.10", "2026.10", "007", "1e3", "yes"])
def test_us19_template_versions_stay_the_text_that_was_written(version: str) -> None:
    text = f"---\ntemplate_id: t\nversion: {version}\nspec_type: x\n---\nbody\n"

    assert parse_template(text).version == version


def test_us19_quoted_template_front_matter_values_are_read_without_quotes() -> None:
    text = '---\ntemplate_id: "t"\nversion: "1.10"\nspec_type: \'x\'\n---\nbody\n'

    parsed = parse_template(text)

    assert (parsed.template_id, parsed.version, parsed.spec_type) == ("t", "1.10", "x")


def test_us19_front_matter_that_is_not_yaml_is_an_error() -> None:
    with pytest.raises(TemplateNotFoundError):
        parse_template("---\ntemplate_id: [unclosed\n---\nbody\n")


def test_us19_template_repository_finds_exact_and_latest_versions(
    database: Database, seeded: Seeded
) -> None:
    newer = seeded.template.model_copy(update={"version": "1.10.0"})
    older = seeded.template.model_copy(update={"version": "1.9.0"})
    with database.transaction() as connection:
        repository = TemplateRepository(connection)
        repository.save(newer)
        repository.save(older)
        repository.save(older)

        assert repository.get("functional-spec", "1.9.0") == older
        assert repository.latest("functional").version == "1.10.0"
        with pytest.raises(TemplateNotFoundError):
            repository.get("functional-spec", "9.9.9")
        with pytest.raises(TemplateNotFoundError):
            repository.latest("unknown-type")


def _spec(**overrides: object) -> Spec:
    values: dict[str, object] = {
        "spec_id": "spec-pay-101",
        "story_key": "PAY-101",
        "path": "specs/PAY-101.md",
        "template_id": "functional-spec",
        "template_version": "1.0.0",
        "branch": "spec/pay-101",
        "pr_identity": "local-pr:1",
        "coverage": {"rules": {"a": ["t"]}},
        "open_items": ("One.",),
        "content_sha256": "1" * 64,
        "created_at": NOW,
    }
    values.update(overrides)
    return Spec.model_validate(values)


def test_us19_spec_repository_round_trips_and_updates_in_place(
    database: Database, seeded: Seeded
) -> None:
    report = check_citations(
        MARKDOWN, resolves=_all_resolve, retrieved={"2026.1:4.1.2"}, target=0.95
    )
    with database.transaction() as connection:
        repository = SpecRepository(connection)
        repository.save(_spec(), report.to_citations("spec-pay-101"))
        repository.save(_spec(open_items=("Two.",)), report.to_citations("spec-pay-101")[:1])

        stored = repository.get_by_branch("spec/pay-101")
        assert stored == _spec(open_items=("Two.",))
        assert repository.get_by_story("PAY-101") == stored
        assert repository.get_by_branch("spec/other") is None
        assert [c.statement_index for c in repository.citations("spec-pay-101")] == [0]
        assert connection.execute(select(func.count()).select_from(citation)).scalar() == 1


def test_us19_spec_state_survives_a_round_trip(database: Database, seeded: Seeded) -> None:
    with database.transaction() as connection:
        repository = SpecRepository(connection)
        repository.save(_spec(state=SpecState.MERGED, merged_at=NOW), ())

        stored = repository.get_by_story("PAY-101")

    assert stored is not None
    assert (stored.state, stored.merged_at, stored.machine_authored) == (
        SpecState.MERGED,
        NOW,
        True,
    )
