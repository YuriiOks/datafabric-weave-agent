# Reference patterns from prior work, part 2 (patterns 9 to 15)

Continues kb/seed/reference-patterns-1.md (patterns 1 to 8). Same format, labels and rules.
The description of the prior work is Reported. Every "Add" line is Proposed.
Stories: S1 review, S2 gaps, S3 product, S4 roles, S5 graph, S6 ingestion.

## 9. File type detection and conversion policy
Problem: decide what to do with each incoming file, the same way for every route.
How it works:
- Detect the type from the name and the leading bytes. Check the declared type against them.
- A policy table gives a disposition per type: convert, keep, pass through, or skip.
- Size ceilings apply per type. Accepted types can be set per tenant.
- Large scanned files are split into segments, processed one by one and stitched back with
  corrected page numbers. The planned work is checked against a time budget first.
Invariants:
- The same policy applies to uploads and to files delivered by connectors.
- A refused file gets a recorded reason.
- The prior work converted scans to plain text only. Markdown conversion was not built.
Add for our stories:
- A conversion step to a structured text form that keeps headings and tables.
- A skip decision for files that need privacy checks first.
Serves: S6, S5.

## 10. Per-stage processing status
Problem: see where each document stands in a long pipeline.
How it works:
- One row per stage per document: land, scan, extract, enrich, index.
- A transition locks the document row. A failed stage is recorded as failed, with a reason.
- A switch turns the whole pipeline on for a full local run.
Invariants:
- A document is complete only when every required stage is done.
- Stage rows are never deleted. A retry adds an attempt.
Add for our stories:
- Show stage status to producers and stewards, and use it as a gate input.
- Add a privacy-check stage before processing.
Serves: S6, S5, S3.

## 11. Evidence-linked extraction with verbatim quote checking
Problem: every extracted claim must point to text that really exists.
How it works:
- The model returns a claim, a page and a short quote.
- A pure function finds the quote in the source, ignoring whitespace changes and line-break
  hyphens, and returns offsets into the original text.
- A claim whose quote is not found is kept, the quote is dropped and the claim is flagged.
- An assertion fingerprint hashes field, canonical value, pages and normalised quote. It leaves
  out reprocessing details.
- Writes are idempotent. The same assertion refreshes provenance. A different one adds a row.
  Nothing is deleted. A later verified quote repairs an earlier bad one.
Invariants:
- Offsets always refer to the document's own characters. Fingerprint rules are versioned.
- The prior work stored page and verified quote, not offsets. Entity mentions had no quote.
Add for our stories:
- Store character offsets for every mention, and a quote for every relationship.
- Use an assertion table before the graph load. Load only verified assertions.
- Tune the hyphen rules to the language of the documents.
Serves: S5, S3.

## 12. Schema-driven extraction with a dynamic response model
Problem: the user brings a schema, and the extractor must follow it without code changes.
How it works:
- A registry of definitions. Each is versioned and frozen.
- A definition pairs a candidate model (filled by the model, with evidence) with a canonical
  value model and a declared policy: instruction, exclusions, inference rules.
- The response schema is built at run time: one list field per chosen definition.
- After the model answers, a fixed seam runs a pre-hook, strict validation and a post-hook.
  Production and evaluation share the seam.
Invariants:
- The registry checks its own structure when built.
- Strict validation follows the model step, so the flow is not fully model-driven.
- Definitions were written in code, not loaded from a user ontology.
Add for our stories:
- Generate definitions from the uploaded ontology: entity, attribute, relationship, decision, term.
- Reuse the foundational ontology as the default set.
Serves: S5, S3.

## 13. Entity deduplication tiers
Problem: merge duplicates without trusting the model for everything.
How it works:
- Tier 1: rules group records by normalised name keys per entity type. The richer record wins
  and fills only empty fields of the loser.
- Tier 2: an embedding step keeps the nearest few candidates.
- Tier 3: the model judges only those candidates.
- A merge unions the source ids and carries per-field provenance.
Invariants:
- Order is deterministic. Cheap steps run first. The model is the last resort.
- Weaknesses: greedy and sequential, no clustering, conflicts dropped without a review.
Add for our stories:
- Cluster transitively. Show field conflicts to a person.
- Keep merge decisions as proposals in the review queue.
Serves: S5.

## 14. Evaluation with optimal alignment
Problem: prove that extraction and merging work, and avoid false green.
How it works:
- Pair gold items with predicted ones by optimal assignment. Mark pairs that could pair another
  way as ambiguous, and do not guess.
- Score coverage, over-extraction, per-field agreement, and merge quality (split and fused).
- A model judge is used only for free text that fails an exact match, and only when allowed.
- Gold data is built by a person who marks exact spans in the source text.
Invariants:
- Not measured is not passed. A check with no gold data never raises a pass rate.
- Datasets are fingerprinted, so a score names the data it used.
Add for our stories:
- Use the same rule for product quality scorecards. Missing data shows as not measured.
- Start a small gold set from the pilot use case.
Serves: S5, S3, S2.

## 15. Tool server with capability checks and fail-closed audit
Problem: publish products to agents with control over who may call what.
How it works:
- A static catalogue of tools. Each has an input model and a required capability.
- Calls run in a fixed order: authenticate, check capability, audit received, run, redact,
  audit terminal event, release.
- Capabilities are explicit grant rows that can be revoked. They ignore the superuser shortcut.
  An unknown capability gives false.
- Output passes a path-based redaction policy before release. Service callers use workload identity.
Invariants:
- Audit unavailable means the call fails. Grants are history and are never deleted.
- The prior server was read-only. It had no publish or write tools.
Add for our stories:
- One tool per published product query, with a capability per domain or sub-domain.
- Add a scope to the capability grant.
Serves: S4, S6, S2.

## What the prior work does not have
Design these fresh. Do not look for a pattern to copy.
- Hierarchical scopes where a grant on a parent flows to its children.
- Per-action grants (create, view, update, delete, upload, approve, publish).
- Delegation limits: a delegate cannot grant more than the granter holds. No expiry on grants.
- Group principals and directory group mapping. Maker-checker (author differs from approver).
- A multi-stage publish lifecycle with immutable published versions.
- Graph construction, graph storage, and graph isolation per namespace.
- Relationship, decision and term extraction with evidence. Ontology supplied by the user.
- Database source connectors (JDBC, ODBC) and a generic REST connector.
- Tables created at run time for a domain or product.
- A storage path hierarchy by domain, sub-domain, namespace and product.
- Data-quality metrics (completeness, freshness, accuracy) and rules held as data.
- Isolation of storage, graph and vector data per namespace.
