"""Governed templates and drafted specs."""

from __future__ import annotations

from typing import Annotated

from pydantic import AwareDatetime, Field, JsonValue

from kp.domain.base import DomainModel
from kp.domain.enums import SpecState


class Template(DomainModel):
    """A governed, versioned template for one spec type. Absence is an error, never a fallback."""

    template_id: str
    version: str
    spec_type: str
    body: str
    content_sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]


class SpecCorrection(DomainModel):
    """One change a product owner made to a drafted spec, and why (US-24).

    ``wrong_clause`` marks a correction that replaced or removed a clause the draft cited
    wrongly; the per-spec report counts those apart from the other corrections.
    """

    correction_id: str
    spec_id: str
    correction: str
    reason: str
    wrong_clause: bool = False
    recorded_at: AwareDatetime


class Spec(DomainModel):
    """A drafted spec delivered as a pull request.

    The same ``branch`` always means the same pull request. ``machine_authored`` stops a
    merged spec from triggering a new draft when it is loaded back as knowledge.
    """

    spec_id: str
    story_key: str
    path: str
    template_id: str
    template_version: str
    branch: str
    pr_identity: str | None = None
    state: SpecState = SpecState.DRAFTED
    machine_authored: bool = True
    coverage: dict[str, JsonValue] = Field(default_factory=dict)
    open_items: tuple[str, ...] = ()
    content_sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    created_at: AwareDatetime
    merged_at: AwareDatetime | None = None
