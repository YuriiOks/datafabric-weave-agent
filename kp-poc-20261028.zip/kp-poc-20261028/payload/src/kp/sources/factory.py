"""Build source readers from :class:`kp.config.Settings`.

Local mode (the default) reads the stand-in data on disk: the library and regulatory folders
named in the settings, and export folders for the other three routes. Switching to the real
route is configuration: with ``KP_MODE=real`` the factory asks the builder registered for that
source (for example a gateway-backed reader supplied by the connectivity lane) and does not
read any local export. The library and the regulatory repository have no gateway route, so
they keep reading their configured folders in both modes unless a builder is registered.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path

from kp.config import Mode, Settings
from kp.domain.enums import SourceKind
from kp.errors import ConfigurationError
from kp.sources.base import SourceReader
from kp.sources.code_repo import CodeRepoReader
from kp.sources.confluence import ConfluenceExportReader
from kp.sources.document_library import DocumentLibraryReader
from kp.sources.jira import JiraExportReader
from kp.sources.regulatory import RegulatoryRepoReader

RealReaderBuilder = Callable[[Settings], SourceReader]
"""Builds the reader of the real route for one source from the settings."""

_GATEWAY_ONLY = frozenset({SourceKind.CONFLUENCE, SourceKind.JIRA, SourceKind.GITHUB})


@dataclass(frozen=True)
class StandInLocations:
    """Where the stand-in exports of the three tracker routes live, when not under the data folder.

    Each missing value falls back to ``KP_CONFLUENCE_EXPORT_PATH``, ``KP_JIRA_EXPORT_PATH`` or
    ``KP_CODE_REPO_PATH``, then to a subfolder of ``Settings.data_dir``: ``confluence``, ``jira``
    and ``code_repo``.
    """

    confluence: Path | None = None
    jira: Path | None = None
    code_repo: Path | None = None


def create_reader(
    kind: SourceKind,
    settings: Settings,
    *,
    locations: StandInLocations | None = None,
    real_builders: Mapping[SourceKind, RealReaderBuilder] | None = None,
) -> SourceReader:
    """Create the reader for one source.

    :param kind: Which source
    :param settings: The platform settings
    :param locations: Overrides for the stand-in export folders (local mode)
    :param real_builders: Builders for the real route, consulted in real mode
    :return: The reader
    :raises kp.errors.ConfigurationError: If the settings do not say where to read from, the
        folder does not exist, or real mode has no reader for a gateway-only source
    """
    if settings.mode is Mode.REAL:
        builder = (real_builders or {}).get(kind)
        if builder is not None:
            return builder(settings)
        if kind in _GATEWAY_ONLY:
            raise ConfigurationError(f"No real-route reader is registered for {kind.value}")
    return _stand_in(kind, settings, locations or StandInLocations())


def create_readers(
    settings: Settings,
    kinds: Iterable[SourceKind] = tuple(SourceKind),
    *,
    locations: StandInLocations | None = None,
    real_builders: Mapping[SourceKind, RealReaderBuilder] | None = None,
) -> dict[SourceKind, SourceReader]:
    """Create the readers for several sources.

    :param settings: The platform settings
    :param kinds: Which sources; all five by default
    :param locations: Overrides for the stand-in export folders (local mode)
    :param real_builders: Builders for the real route, consulted in real mode
    :return: One reader per requested source
    :raises kp.errors.ConfigurationError: As :func:`create_reader`, for the first source that fails
    """
    return {
        kind: create_reader(kind, settings, locations=locations, real_builders=real_builders)
        for kind in kinds
    }


def _stand_in(kind: SourceKind, settings: Settings, locations: StandInLocations) -> SourceReader:
    match kind:
        case SourceKind.DOCUMENT_LIBRARY:
            return DocumentLibraryReader(
                _existing(settings.document_library_root, "KP_DOCUMENT_LIBRARY_ROOT")
            )
        case SourceKind.REGULATORY_REPO:
            return RegulatoryRepoReader(
                _existing(settings.regulatory_repo_path, "KP_REGULATORY_REPO_PATH")
            )
        case SourceKind.CONFLUENCE:
            return ConfluenceExportReader(
                _existing(
                    locations.confluence
                    or settings.confluence_export_path
                    or settings.data_dir / "confluence",
                    "KP_CONFLUENCE_EXPORT_PATH",
                ),
                approved_label=settings.confluence_approved_label,
            )
        case SourceKind.JIRA:
            return JiraExportReader(
                _existing(
                    locations.jira or settings.jira_export_path or settings.data_dir / "jira",
                    "KP_JIRA_EXPORT_PATH",
                ),
                project_key=settings.jira_project_key,
                overlap_seconds=settings.jira_overlap_seconds,
                page_size=settings.jira_page_size,
            )
        case SourceKind.GITHUB:
            return CodeRepoReader(
                _existing(
                    locations.code_repo
                    or settings.code_repo_path
                    or settings.data_dir / "code_repo",
                    "KP_CODE_REPO_PATH",
                )
            )


def _existing(path: Path | None, setting: str) -> Path:
    if path is None:
        raise ConfigurationError(f"{setting} must be set to read this source")
    if not path.is_dir() and not path.is_file():
        raise ConfigurationError(f"The folder configured through {setting} does not exist")
    return path


__all__ = ["RealReaderBuilder", "StandInLocations", "create_reader", "create_readers"]
