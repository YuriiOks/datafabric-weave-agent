"""Reviewer decision log: the latest named decision sets the label, nothing else does."""

from __future__ import annotations

import unittest
from datetime import UTC, datetime

from app.recsys.eval.casepack.cases import ExpectedOutcome, RelevanceLabel, Scenario
from app.recsys.eval.casepack.decisions import (
    ReviewDecision,
    apply_decisions,
    check_decision_log,
    latest_decisions,
)
from app.recsys.eval.casepack.lineage import CasePackError
from app.recsys.eval.schema import DRAFT_LABELLER

from . import casepack_support as support

ONE = support.component_id(1)
TWO = support.component_id(2)


def _decision(
    decision_id: str,
    case_id: str,
    labels: dict[str, RelevanceLabel],
    *,
    day: int = 1,
    reviewer: str = "reviewer-a",
) -> ReviewDecision:
    return ReviewDecision(
        decision_id=decision_id,
        case_id=case_id,
        reviewer=reviewer,
        decided_at=datetime(2026, 10, day, tzinfo=UTC),
        decision_reference=f"review-log-{decision_id}",
        labels=labels,
    )


class DecisionLogTests(unittest.TestCase):
    def setUp(self) -> None:
        lineage = support.corpus().lineage
        self.positive = support.case(1, lineage=lineage)
        self.empty = support.case(
            2,
            lineage=lineage,
            scenario=Scenario.valid_empty,
            expected=ExpectedOutcome.valid_empty,
        )
        self.cases = [self.positive, self.empty]

    def test_the_latest_decision_sets_the_adjudication(self) -> None:
        earlier = _decision("d-1", "skl-0001", {ONE: RelevanceLabel.relevant}, day=1)
        later = _decision(
            "d-2",
            "skl-0001",
            {ONE: RelevanceLabel.partially_relevant, TWO: RelevanceLabel.relevant},
            day=2,
        )
        updated = apply_decisions(self.cases, [later, earlier])
        self.assertEqual(updated[0].adjudication, later.adjudication())
        self.assertEqual(updated[0].relevant_ids(), frozenset({TWO}))
        self.assertFalse(updated[1].adjudication.judged)
        self.assertEqual(latest_decisions([earlier, later])["skl-0001"], later)

    def test_a_contradicting_decision_is_refused(self) -> None:
        decision = _decision("d-1", "skl-0002", {ONE: RelevanceLabel.relevant})
        with self.assertRaisesRegex(CasePackError, "contradicts"):
            apply_decisions(self.cases, [decision])

    def test_unknown_case_and_repeated_decision_id_are_refused(self) -> None:
        with self.assertRaisesRegex(CasePackError, "unknown cases"):
            apply_decisions(self.cases, [_decision("d-1", "skl-0099", {})])
        decision = _decision("d-1", "skl-0001", {ONE: RelevanceLabel.relevant})
        with self.assertRaisesRegex(CasePackError, "appears twice"):
            apply_decisions(self.cases, [decision, decision])

    def test_the_draft_labeller_cannot_decide(self) -> None:
        with self.assertRaises(ValueError):
            _decision("d-1", "skl-0001", {ONE: RelevanceLabel.relevant}, reviewer=DRAFT_LABELLER)
        with self.assertRaises(ValueError):
            _decision("d-1", "skl-0001", {ONE: RelevanceLabel.unjudged})

    def test_cases_must_agree_with_the_log(self) -> None:
        decision = _decision("d-1", "skl-0001", {ONE: RelevanceLabel.relevant})
        check_decision_log(apply_decisions(self.cases, [decision]), [decision])
        with self.assertRaisesRegex(CasePackError, "differs from its latest"):
            check_decision_log(self.cases, [decision])
        judged_alone = [support.case(1, lineage=support.corpus().lineage)]
        judged_alone = apply_decisions(judged_alone, [decision])
        with self.assertRaisesRegex(CasePackError, "without a logged decision"):
            check_decision_log(judged_alone, [])
