"""Impact: choose a clause and see what a change to it reaches, up to three steps away."""

from __future__ import annotations

from dataclasses import dataclass

from pydantic import JsonValue

from kp.domain import ClauseRef, ItemType, select_edition_as_at
from kp.domain.clause_ref import parse_clause_number
from kp.errors import AccessForbiddenError, InvalidClauseRefError, KpError
from kp.tools import NoEditionInForceError
from kp.tools.coverage import CoverageOutput
from kp.tools.links import LinksOutput
from kp.web.errors import Problem, problem_from
from kp.web.identity import Viewer
from kp.web.query import QueryForm
from kp.web.state import WebState

MAX_STEPS = 3
_SUGGESTION_LIMIT = 500


@dataclass(frozen=True, slots=True)
class ImpactView:
    """The impact page.

    :ivar clause: What was typed (empty before the first lookup).
    :ivar reference: The clause reference it was read as, such as ``2026.1:4.2.1``.
    :ivar output: The tool's answer, including the explicit message when nothing is linked.
    :ivar suggestions: Clause references the viewer may read, to choose from.
    """

    clause: str = ""
    reference: str = ""
    output: LinksOutput | None = None
    suggestions: tuple[str, ...] = ()
    problem: Problem | None = None

    @property
    def looked_up(self) -> bool:
        """True once a clause has been chosen."""
        return bool(self.clause)


def read_impact(state: WebState, viewer: Viewer, form: QueryForm) -> ImpactView:
    """Follow the links of a clause as the viewer.

    :param state: The shared state
    :param viewer: Who is asking
    :param form: The query string of the request
    :return: The view
    """
    clause = ""
    suggestions: tuple[str, ...] = ()
    try:
        clause = form.text("clause")
        suggestions = _suggestions(state, viewer)
        if not clause:
            return ImpactView(suggestions=suggestions)
        reference = _reference(state, clause)
        arguments: dict[str, JsonValue] = {
            "item_type": ItemType.CLAUSE.value,
            "key": reference,
            "steps": MAX_STEPS,
        }
        output = LinksOutput.model_validate(state.call(viewer, "links", arguments))
        return ImpactView(clause, reference, output, suggestions)
    except KpError as exc:
        return ImpactView(clause, suggestions=suggestions, problem=problem_from(exc))


def _suggestions(state: WebState, viewer: Viewer) -> tuple[str, ...]:
    """The rules of the edition in force that the viewer may read; a refusal stops the page."""
    try:
        payload = state.call(viewer, "coverage", {"limit": _SUGGESTION_LIMIT})
    except AccessForbiddenError:
        raise
    except KpError:
        return ()
    output = CoverageOutput.model_validate(payload)
    rules = (*output.rules_without_tests, *output.rules_with_tests)
    return tuple(sorted({rule.reference for rule in rules}))


def _reference(state: WebState, text: str) -> str:
    """Read ``2026.1:4.2.1`` or ``2026.1 clause 4.2.1`` as is, and a bare number in the edition
    in force today."""
    try:
        return ClauseRef.parse(text).format()
    except InvalidClauseRefError:
        parse_clause_number(text)
    today = state.application.clock.today()
    edition = select_edition_as_at(state.application.read_ports().rules.editions(), today)
    if edition is None:
        raise NoEditionInForceError(f"No edition was in force on {today.isoformat()}")
    return ClauseRef(edition.label, text).format()
