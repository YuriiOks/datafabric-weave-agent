"""Hygiene of the delivered files and the wiring from settings."""

from __future__ import annotations

import re
from pathlib import Path

import pytest
from pydantic import SecretStr

from kp.clock import FixedClock
from kp.config import Mode, Settings
from kp.connectivity import Harness, build_harness, load_evidence
from kp.connectivity.fake_gateway import FAKE_BASE_URL, FAKE_EXTRACTION_URL, FAKE_TOKEN_URL
from kp.connectivity.models import RunActivity
from kp.connectivity.tokens import FixedTokenProvider
from kp.connectivity.wiring import extraction_auth
from kp.domain import RunOutcome
from kp.errors import ConfigurationError
from kp.store import IN_MEMORY_SQLITE

PACKAGE = Path(__file__).resolve().parents[2] / "src" / "kp" / "connectivity"
TESTS = Path(__file__).resolve().parent
# The only address-like literals allowed: three fictional stand-in hosts and the file-format
# namespace the Word document needs.
ALLOWED_URL_PREFIXES = (
    "http://gateway.stand-in",
    "http://extraction.stand-in",
    "http://schemas.openxmlformats.org",
)


def _files() -> list[Path]:
    return [
        path
        for root in (PACKAGE, TESTS)
        for path in root.rglob("*")
        if path.suffix in {".py", ".yaml"}
        and "__pycache__" not in path.parts
        and path != Path(__file__).resolve()  # this file spells the patterns it looks for
    ]


def test_hygiene_no_absolute_paths_emails_or_unlisted_addresses() -> None:
    offences = []
    for path in _files():
        text = path.read_text(encoding="utf-8")
        if "/Users/" in text or re.search(r"[\w.]+@[\w-]+\.\w+", text):
            offences.append(f"{path.name}: path or email")
        for match in re.finditer(r"https?://[^\s\"')]+", text):
            if not match.group(0).startswith(ALLOWED_URL_PREFIXES):
                offences.append(f"{path.name}: {match.group(0)}")
    assert offences == []


def test_hygiene_the_package_has_no_todo_stubs() -> None:
    markers = ("TODO", "FIXME", "XXX", "NotImplementedError")
    found = [
        f"{path.name}: {marker}"
        for path in PACKAGE.rglob("*.py")
        for marker in markers
        if marker in path.read_text(encoding="utf-8")
    ]
    assert found == []


def _settings(tmp_path: Path, **overrides: object) -> Settings:
    return Settings(
        _env_file=None,
        mode=Mode.LOCAL,
        database_url=SecretStr(IN_MEMORY_SQLITE),
        data_dir=tmp_path / "var",
        **overrides,  # type: ignore[arg-type]  # keyword overrides of typed settings
    )


def test_wiring_local_harness_runs_end_to_end(tmp_path: Path, fixed_clock: FixedClock) -> None:
    harness = build_harness(_settings(tmp_path), clock=fixed_clock)
    try:
        assert harness.fake is not None
        assert harness.stub is not None
        assert harness.job.discover().outcome is RunOutcome.SUCCEEDED
        assert harness.job.run().stored_count == 9
        assert harness.job.run().stored_count == 0
        evidence = harness.evidence()
        assert {run.activity for run in evidence.runs} == {RunActivity.DISCOVER, RunActivity.FETCH}
        assert len(evidence.items) == 9
        assert (tmp_path / "var" / "connectivity" / "raw").is_dir()
    finally:
        harness.close()


def test_wiring_header_names_come_from_settings(tmp_path: Path, fixed_clock: FixedClock) -> None:
    settings = _settings(
        tmp_path,
        gateway_token_header="x-custom-caller",  # noqa: S106 - a header name, not a secret
        source_token_header="x-custom-source",  # noqa: S106 - a header name, not a secret
    )
    harness = build_harness(settings, clock=fixed_clock)
    try:
        assert harness.job.run().stored_count == 9
        assert harness.fake is not None
        assert harness.fake.requests
    finally:
        harness.close()


def test_wiring_placeholder_namespaces_fall_back_to_defaults_locally(
    tmp_path: Path, fixed_clock: FixedClock
) -> None:
    settings = _settings(tmp_path, tool_namespace_jira="<namespace>", tool_namespace_github="gh")
    harness = build_harness(settings, clock=fixed_clock)
    try:
        assert {kind.value: name for kind, name in harness.namespaces.items()} == {
            "confluence": "confluence",
            "jira": "jira",
            "github": "gh",
        }
    finally:
        harness.close()


def _real_settings(tmp_path: Path, **overrides: object) -> Settings:
    values: dict[str, object] = {
        "gateway_base_url": FAKE_BASE_URL,
        "gateway_token_url": FAKE_TOKEN_URL,
        "gateway_client_id": "client",
        "gateway_client_secret": "client-secret-value",
        "gateway_token_header": "x-caller",
        "source_token_header": "x-source",
        "source_token_confluence": "t1",
        "source_token_jira": "t2",
        "source_token_github": "t3",
        "use_case_id": "case",
        "tool_namespace_confluence": "ns-c",
        "tool_namespace_jira": "ns-j",
        "tool_namespace_github": "ns-g",
        "extraction_base_url": FAKE_EXTRACTION_URL,
        "raw_bucket": "raw-bucket",
        "markdown_bucket": "markdown-bucket",
        "spec_repo": "org/repo",
        "spec_path": "specs",
        "jira_fields_allowed": ("status",),
    }
    values.update(overrides)
    # Real mode needs PostgreSQL, whose driver the tests do not carry: build as local, then
    # switch the mode on the copy (no validation) to keep the in-memory database.
    local = Settings(
        _env_file=None,
        mode=Mode.LOCAL,
        database_url=SecretStr(IN_MEMORY_SQLITE),
        data_dir=tmp_path / "var",
        **values,  # type: ignore[arg-type]  # keyword overrides of typed settings
    )
    return local.model_copy(update={"mode": Mode.REAL})


def test_wiring_real_route_is_built_from_settings_without_the_bucket_library(
    tmp_path: Path,
) -> None:
    harness: Harness = build_harness(_real_settings(tmp_path))
    try:
        assert harness.fake is None
        assert harness.stub is None
        assert set(harness.namespaces.values()) == {"ns-c", "ns-j", "ns-g"}
    finally:
        harness.close()


@pytest.mark.parametrize(
    ("missing", "message"),
    [
        ({"tool_namespace_jira": None}, "KP_TOOL_NAMESPACE_JIRA"),
        ({"source_token_github": None}, "KP_SOURCE_TOKEN_GITHUB"),
    ],
)
def test_wiring_real_route_names_the_missing_setting(
    tmp_path: Path, missing: dict[str, object], message: str
) -> None:
    with pytest.raises(ConfigurationError, match=message):
        build_harness(_real_settings(tmp_path, **missing))


def test_the_extraction_service_gets_its_own_credential_never_the_gateway_token(
    tmp_path: Path, fixed_clock: FixedClock
) -> None:
    plain = _settings(tmp_path)
    paired = _settings(
        tmp_path,
        extraction_auth_header="X-Extraction",
        extraction_token=SecretStr("extraction-credential"),
    )

    assert extraction_auth(plain, fixed_clock) == (None, None)
    provider, header = extraction_auth(paired, fixed_clock)
    assert isinstance(provider, FixedTokenProvider)
    assert header == "X-Extraction"
    assert provider.acquire().token.value.get_secret_value() == "extraction-credential"


def test_the_evidence_can_be_read_without_the_means_to_run_the_job(
    tmp_path: Path, fixed_clock: FixedClock
) -> None:
    """A page that shows the report holds no gateway address, no credential and no token."""
    settings = _settings(tmp_path).model_copy(
        update={"database_url": SecretStr(f"sqlite+pysqlite:///{tmp_path / 'evidence.db'}")}
    )
    harness = build_harness(settings, clock=fixed_clock)
    try:
        harness.job.discover()
        harness.job.run()
        expected = harness.evidence()
    finally:
        harness.close()
    bare = settings.model_copy(
        update={
            "gateway_base_url": None,
            "gateway_client_secret": None,
            "source_token_confluence": None,
            "source_token_jira": None,
            "source_token_github": None,
        }
    )

    read = load_evidence(bare)

    assert read.runs == expected.runs
    assert read.sample_total == expected.sample_total
