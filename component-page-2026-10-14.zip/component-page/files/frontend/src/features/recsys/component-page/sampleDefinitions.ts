import { EMPTY_SOURCE } from './model'
import type { ComponentDefinition, ComponentPageModel, ComponentSource } from './model'

/**
 * Sample definitions and provenance for three of the demo fixtures, so demo mode shows the whole
 * page before the catalogue carries the full .md and its source. Live data never reads this file.
 */

type Sample = { definition: ComponentDefinition; source: ComponentSource }

const SKILL_MD = [
  '---',
  'name: Alpha Ticket Helper',
  'description: Use when a team needs to triage inbound support tickets. Alpha Ticket Helper classifies a ticket into a queue, drafts a first reply and proposes a priority. Requires a ticketing system account with write scope.',
  'allowed-tools: Read, Write',
  'tags: ticket_automation, it_operations',
  '---',
  '',
  '# Alpha Ticket Helper',
  '',
  'Triage one inbound support ticket at a time.',
  '',
  '## When to use',
  '',
  'Use when a team needs to triage inbound support tickets.',
  '',
  '- The ticket is new and has no queue yet.',
  '- The team wants a first reply drafted for a person to review.',
  '- Do not use it for tickets that are already assigned.',
  '',
  '## Inputs',
  '',
  '- `ticket_id`: the id of the ticket in the ticketing system.',
  '- `queues`: the list of queues the team routes to.',
  '- `tone`: optional, `formal` or `friendly`. The default is `formal`.',
  '',
  '## Steps',
  '',
  '1. Read the ticket subject, body and attachment names with the Read tool.',
  '2. Pick the best queue from `queues`. If two fit equally, pick the one with the shorter backlog.',
  '3. Draft a first reply of at most 120 words in the requested tone.',
  '4. Propose a priority from `low`, `normal`, `high` or `urgent`, with one sentence of reasoning.',
  '5. Write the queue, the reply draft and the priority back to the ticket with the Write tool.',
  '',
  '## Output',
  '',
  '```json',
  '{',
  '  "ticket_id": "T-1042",',
  '  "queue": "billing",',
  '  "priority": "high",',
  '  "reply_draft": "Thanks for getting in touch. We have routed your request to billing."',
  '}',
  '```',
  '',
  '## Limits',
  '',
  '- It never closes a ticket and never sends the reply. A person sends it.',
  '- It lists attachment names but does not open attachments.',
  '- It handles one ticket per run.',
  '',
  '> [!WARNING]',
  '> This skill needs a ticketing system account with write scope. Without it, step 5 fails and nothing is saved.',
].join('\n')

const AGENT_MD = [
  '---',
  'name: Epsilon Triage Agent',
  'description: An agent that watches an inbound queue, triages each item and escalates anything it cannot classify.',
  'tools: Read, Write',
  'skills: alpha-ticket-helper',
  'mcp_servers: gamma-tracker',
  'tags: triage, it_operations',
  '---',
  '',
  '# Epsilon Triage Agent',
  '',
  '## Role',
  '',
  'You watch one inbound queue. For each new item you decide where it goes and whether a person needs to look at it.',
  '',
  '## When to use',
  '',
  'Use when an inbound queue needs triage and escalation.',
  '',
  '- Items arrive faster than a team can read them.',
  '- Some items cannot be classified and need a person.',
  '',
  '## Workflow',
  '',
  '1. Poll the queue for new items every five minutes.',
  '2. Run the `alpha-ticket-helper` skill on each item to get a queue and a priority.',
  '3. Look for related open issues with the `gamma-tracker` MCP server (`search_issues`).',
  '4. If a related issue exists, add a note with `comment_on_issue` and link the item.',
  '5. If none exists and the priority is `high` or `urgent`, open one with `create_issue`.',
  '6. Write the result back to the item with the Write tool.',
  '',
  '## Escalation rules',
  '',
  '- Escalate to a person when the skill returns no queue.',
  '- Escalate when two items from the same sender arrive within ten minutes.',
  '- Escalate every `urgent` item, even when a related issue exists.',
  '',
  '## Output',
  '',
  '```json',
  '{',
  '  "item_id": "Q-2210",',
  '  "queue": "it_operations",',
  '  "priority": "urgent",',
  '  "escalated": true,',
  '  "issue": "GT-318"',
  '}',
  '```',
  '',
  '## Limits',
  '',
  '- It never deletes an item.',
  '- It handles at most 50 items per run.',
  '- It does not reply to the sender. The skill drafts the reply and a person sends it.',
  '',
  '> [!IMPORTANT]',
  '> Escalated items must be picked up by a person within one working day. The agent does not retry an escalation.',
].join('\n')

const MCP_MD = [
  '---',
  'name: Delta Wiki MCP',
  'description: Read-only MCP server over the Delta internal wiki. Provides page search and page fetch. Requires a wiki space to be allow-listed\u2026',
  'transport: stdio',
  'tools: search_pages, fetch_page',
  'tags: knowledge, wiki',
  '---',
  '',
  '# Delta Wiki MCP',
  '',
  '## What it serves',
  '',
  'Read-only access to pages of the Delta internal wiki, limited to wiki spaces that an admin has allow-listed.',
  '',
  '## Tools',
  '',
  '| Tool | What it does | Read-only |',
  '| --- | --- | --- |',
  '| `search_pages` | Find pages by text in an allow-listed space. | Yes |',
  '| `fetch_page` | Return the content of one page by id. | Yes |',
  '',
  '## Setup',
  '',
  '1. Ask the wiki admin to allow-list the wiki space.',
  '2. Add the server to the tenant\'s tool list.',
  '3. Restart the agent session so it picks up the new server.',
  '',
  '## Auth',
  '',
  'The server reads the wiki with a service account. Callers do not pass credentials.',
  '',
  '## Limits',
  '',
  '- Read only. It cannot create or edit pages.',
  '- Pages outside an allow-listed space are not visible.',
  '- `search_pages` returns at most 20 results.',
  '',
  '> [!WARNING]',
  '> A wiki space that is not allow-listed returns no results and no error. Check the allow-list first when a search comes back empty.',
].join('\n')

const SAMPLES: Record<string, Sample> = {
  'alpha-ticket-helper': {
    definition: { markdown: SKILL_MD, path: 'skills/alpha-ticket-helper/SKILL.md' },
    source: {
      ...EMPTY_SOURCE,
      originSystem: 'GitHub skills repository',
      path: 'skills/alpha-ticket-helper/SKILL.md',
      revision: '3f9a1c2',
      lastSynced: '14 Oct 2026 09:12',
      syncTrigger: 'GitHub Actions on push',
      pulledBy: 'Service account',
    },
  },
  'epsilon-triage-agent': {
    definition: { markdown: AGENT_MD, path: 'agents/epsilon-triage-agent/AGENT.md' },
    source: {
      ...EMPTY_SOURCE,
      originSystem: 'GroupAI platform',
      environment: 'Prod',
      path: 'agents/epsilon-triage-agent/AGENT.md',
      revision: 'prod-2026.10.08',
      lastSynced: '14 Oct 2026 06:00',
      syncTrigger: 'Scheduled pull',
      pulledBy: 'Service account',
    },
  },
  'delta-wiki': {
    definition: { markdown: MCP_MD, path: 'mcp/delta-wiki/MCP.md' },
    source: {
      ...EMPTY_SOURCE,
      originSystem: 'GroupAI platform',
      environment: 'Prod',
      path: 'mcp/delta-wiki/MCP.md',
      revision: 'prod-2026.10.08',
      lastSynced: '14 Oct 2026 06:00',
      syncTrigger: 'Scheduled pull',
      pulledBy: 'Service account',
    },
  },
}

/** The demo sample for a fixture id, matched on the id's last segment (`skill:alpha-ticket-helper`). */
export function sampleFor(componentId: string): Sample | null {
  const slug = componentId.split(/[:/]/).pop() ?? ''
  return SAMPLES[slug] ?? null
}

/** Fills what the demo fixtures lack from the sample; values the model already has always win. */
export function withDemoSample(model: ComponentPageModel): ComponentPageModel {
  const sample = sampleFor(model.id)
  if (!sample) return model
  const source: ComponentSource = { ...model.source }
  for (const key of Object.keys(sample.source) as Array<keyof ComponentSource>) {
    if (key === 'externalIds') continue
    const current = source[key]
    const fallback = sample.source[key]
    if ((current === null || current === '') && typeof fallback === 'string') {
      Object.assign(source, { [key]: fallback })
    }
  }
  return { ...model, definition: model.definition ?? sample.definition, source }
}
