"""Clock, logging redaction, command line and the source contract."""

from __future__ import annotations

import io
import json
import logging
from datetime import UTC, date, datetime, timedelta, timezone

import pytest

from kp.clock import Clock, FixedClock, SystemClock
from kp.domain import ItemKey, SourceKind
from kp.log import REDACTED, configure_logging, redact
from kp.sources import ChangeBatch, ChangedItem, FetchedItem, ItemMetadata, SourceReader

NOW = datetime(2026, 11, 1, 9, 30, tzinfo=UTC)


def test_fixed_clock_reports_utc_instant_and_date() -> None:
    clock: Clock = FixedClock(datetime(2026, 11, 16, 1, 0, tzinfo=timezone(timedelta(hours=2))))

    assert clock.now() == datetime(2026, 11, 15, 23, 0, tzinfo=UTC)
    assert clock.today() == date(2026, 11, 15)


def test_fixed_clock_rejects_naive_datetimes() -> None:
    with pytest.raises(ValueError, match="timezone-aware"):
        FixedClock(datetime(2026, 11, 1))
    clock = FixedClock(NOW)
    with pytest.raises(ValueError, match="timezone-aware"):
        clock.set(datetime(2026, 11, 2))


def test_system_clock_is_aware_utc() -> None:
    assert SystemClock().now().utcoffset() == timedelta(0)


def test_redact_masks_secret_and_body_keys_recursively() -> None:
    result = redact(
        {
            "source": "jira",
            "gateway_client_secret": "abc",
            "Authorization": "Bearer abc",
            "request_body": {"q": "x"},
            "nested": {"api_key": "k", "items": 3},
        }
    )

    assert result == {
        "source": "jira",
        "gateway_client_secret": REDACTED,
        "Authorization": REDACTED,
        "request_body": REDACTED,
        "nested": {"api_key": REDACTED, "items": 3},
    }


def test_logging_writes_json_lines_with_redacted_extras() -> None:
    stream = io.StringIO()
    configure_logging("INFO", stream)

    logging.getLogger("kp.test").info("Sweep finished", extra={"items": 2, "token": "abc"})

    record = json.loads(stream.getvalue())
    assert record["message"] == "Sweep finished"
    assert record["items"] == 2
    assert record["token"] == REDACTED
    assert "abc" not in stream.getvalue()


def test_logging_includes_exception_traceback_text() -> None:
    stream = io.StringIO()
    configure_logging("INFO", stream)

    try:
        raise ValueError("bad")
    except ValueError:
        logging.getLogger("kp.test").exception("Step failed")

    assert "ValueError" in json.loads(stream.getvalue())["exception"]


def test_logging_leaves_the_exception_message_out_because_it_can_echo_input() -> None:
    stream = io.StringIO()
    configure_logging("INFO", stream)

    needle = "pa55word-" + "needle"
    try:
        raise ValueError(f"parameter value {needle}")
    except ValueError:
        logging.getLogger("kp.test").exception("Step failed")

    written = json.loads(stream.getvalue())["exception"]
    assert written.startswith("ValueError")
    assert needle not in stream.getvalue()
    assert "test_infrastructure" in written  # the frames are still there


class _ListingReader:
    """A minimal reader; proves the Protocol is implementable without inheritance."""

    kind = SourceKind.JIRA

    def list_changed(self, cursor: str | None, *, limit: int = 100) -> ChangeBatch:
        key = ItemKey(source=SourceKind.JIRA, item_id="PAY-1", version="1")
        return ChangeBatch(items=(ChangedItem(key=key, title="t"),)[:limit], next_cursor="c1")

    def fetch(self, key: ItemKey) -> FetchedItem:
        metadata = ItemMetadata(native_id=key.item_id, media_type="application/json", title="t")
        return FetchedItem(key=key, content=b"{}", metadata=metadata)


def test_a_plain_class_satisfies_the_source_reader_contract() -> None:
    reader = _ListingReader()

    assert isinstance(reader, SourceReader)
    batch = reader.list_changed(None)
    assert batch.exhausted
    assert reader.fetch(batch.items[0].key).content == b"{}"
