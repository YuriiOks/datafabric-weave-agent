# START: design harness (for the owner)

## 1 Unzip
```
cd /home/user/km
unzip -o km-harness.zip
```
- Appears: CLAUDE.md, AGENTS.md, START.md, start.sh, .claude/, kb/, designs/, work/.
- Nothing is written into the clones. A second unzip -o keeps run files but resets
  kb/INDEX.md and the agent tier: then run kb-lint.sh (section 7) and km-tier.sh fast if set.

## 2 Start
```
bash /home/user/km/start.sh
```
| Mode | Use when |
|---|---|
| (none) | normal: strong model, 1M window, effort high |
| std | the first form is refused: same model, no 1M suffix |
| plain | a flag is rejected: no flags, the project settings choose the model |

Mode goes first: bash /home/user/km/start.sh std. Always start here, never inside a clone.
A session inside a clone does not see these commands and loads that clone's own rules.

## 3 First run
Type /km-start. It prints a table of checks. Then check yourself:
- Banner: the strong model and the 1M window. Footer: auto mode (from the user settings).
- /context: note the size. The managed tool list is the largest part and is not ours.
- /memory: lists /home/user/km/CLAUDE.md. The user-level file should not be listed.
- /skills: eight km- skills. /agents: four km- agents.
Good: every row of the /km-start table says OK or gives a one-line reason you can act on.
If the cheaper model answered, run in a plain terminal (undo with strong):
bash /home/user/km/.claude/bin/km-tier.sh fast

## 4 Commands
| Command | One line |
|---|---|
| /km-start | check the setup and the models |
| /km-kb | rules for looking up and writing back to the kb |
| /km-read base, capture, legacy, pdf, wiki | bulk reading into kb/ by parallel readers |
| /km-verify s1..s6 or all | check recorded claims against code |
| /km-risks | risk register and open questions from the kb |
| /km-story s1..s6 | pack, the deliverable in designs/, one skeptical review |
| /km-review path | one skeptical review of a file |
| /km-pr | checklist before any push or pull request |

Order for three days:
- Wave 1: /km-start. Then /km-verify all and /km-read wiki, in two sessions. Without
  kb/private: /km-read base, /km-read capture and /km-read wiki first, then /km-verify all.
- Wave 2: /km-read base and /km-read capture (gap mode: only what is not yet read); /km-risks
  after both have finished.
- Wave 3: /km-story s3 and s4 first, then s1, s2, s5. Run s6 only if that story is yours.
- Any time, optional: /km-read legacy, /km-read pdf.

## 5 Effort
Sessions start at high. Type /effort xhigh before /km-story and /km-risks, and again after /clear.

## 6 Parallel sessions
At most 3, each in its own terminal started with start.sh. Each run writes its own files in
kb/index.d and kb/log.d, so they do not collide. Not the same command twice at once.

## 7 Checks
```
bash /home/user/km/.claude/bin/kb-lint.sh
```
It rebuilds kb/INDEX.md, prints FAIL and WARN lines, then PASS or FAIL. Fix every FAIL (size,
date line, secret-shaped text); WARN lines are advice. Run it after each wave.
Logs: kb/log.d, one file per run. Results: designs/.
Setup sizes before unzip: bash <(unzip -p km-harness.zip .claude/bin/inventory.sh)
and after unzip: bash /home/user/km/.claude/bin/inventory.sh

## 8 Optional private add-on
kb/private holds real names, claims from an earlier read, and chat context. It comes in
km-harness-full.zip (public files plus kb/private), unzipped the same way, never through the
public channel. Without it the skills use code, wiki and kb/seed and mark results Unverified;
/km-read wiki asks for the ticket keys, /km-read legacy for the org login.

## 9 Before any push
Run /km-pr. Optional, in a plain terminal, once per clone:
bash /home/user/km/.claude/bin/install-git-guard.sh /home/user/km/<clone>
It adds one git hook file that stops a push carrying harness files, paths under .claude/ or
.github/, or a session link line. By hand: cd into the clone, then
bash /home/user/km/.claude/bin/pre-push-guard.sh --check

## 10 Remove
Delete from /home/user/km: km-harness.zip, CLAUDE.md, AGENTS.md, START.md, start.sh, .claude,
kb, designs, work (copy kb and designs first). Also <clone>/.git/hooks/pre-push if installed.
The clones are untouched.

## 11 Known unknowns to watch
- Effort may be ignored by the gateway. The skills also state depth in words.
- The user-level rules of the other project may still load. /memory shows it.
- The wiki and ticket tools may be missing. /km-start lists the tools it sees.
- A denied command or a blocked file is logged and skipped. Nothing retries it.
