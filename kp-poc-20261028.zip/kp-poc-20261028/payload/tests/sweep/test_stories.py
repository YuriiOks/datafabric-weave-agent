"""US-05: stories are loaded; a status move causes no rework; a criteria change reprocesses one."""

from __future__ import annotations

import json
from pathlib import Path

from kp.domain import ChangeKind, SourceKind
from kp.testing.dataset import load_dataset

from .conftest import Harness
from .support import ScriptedReader, jira_entries, story_from_issue

JIRA = SourceKind.JIRA


def _reader(root: Path, export: str) -> ScriptedReader:
    reader = ScriptedReader(JIRA, honour_cursor=False)
    reader.add(*jira_entries(root, export))
    return reader


def test_us05_first_sweep_loads_every_story(harness: Harness, committed_fixtures_dir: Path) -> None:
    truth = load_dataset(committed_fixtures_dir).truth.stories

    summary = harness.sweep(_reader(committed_fixtures_dir, "export-1.json"))

    assert len(summary.work_items) == truth.story_count
    assert sorted(harness.processor.processed_ids(JIRA)) == [
        f"PAY-{number}" for number in range(100, 107)
    ]
    stored = json.loads(harness.raw_store.get("jira/PAY-101/2026-10-01T09:00:00+00:00"))
    assert stored["fields"]["acceptance_criteria"]
    exported = json.loads((committed_fixtures_dir / "jira" / "export-1.json").read_text())
    loaded = {
        version.item_id: story_from_issue(harness.raw_store.get(version.raw_location))
        for version in harness.versions(JIRA)
    }
    for issue in exported["issues"]:
        story = loaded[issue["key"]]
        assert story.summary == issue["fields"]["summary"]
        assert story.parent_key == (issue["fields"].get("parent") or {}).get("key")
        assert [(link.link_type, link.target_key) for link in story.links] == [
            (link["type"], link["key"]) for link in issue["fields"].get("issuelinks", [])
        ]
    assert any(story.parent_key for story in loaded.values())
    assert any(story.links for story in loaded.values())


def test_us05_status_only_change_causes_no_reprocessing(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    truth = load_dataset(committed_fixtures_dir).truth.stories
    harness.sweep(_reader(committed_fixtures_dir, "export-1.json"))
    processed_before = len(harness.processor.processed)

    summary = harness.sweep(_reader(committed_fixtures_dir, "export-2.json"))

    assert truth.status_only_key not in {item.key.item_id for item in summary.work_items}
    moved = [e for e in harness.events() if e.item_id == truth.status_only_key]
    assert [e.kind for e in moved] == [ChangeKind.NEW]
    # The board move is kept as a new immutable version, quietly: no change event, no rework.
    assert len(harness.processor.processed) - processed_before == len(summary.work_items)


def test_us05_acceptance_criteria_change_reprocesses_only_that_story(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    truth = load_dataset(committed_fixtures_dir).truth.stories
    harness.sweep(_reader(committed_fixtures_dir, "export-1.json"))

    summary = harness.sweep(_reader(committed_fixtures_dir, "export-2.json"))

    assert [item.key.item_id for item in summary.work_items] == [truth.criteria_changed_key]
    changed = [
        e for e in harness.events(ChangeKind.CHANGED) if e.item_id == truth.criteria_changed_key
    ]
    assert len(changed) == 1
    assert changed[0].old_version != changed[0].new_version


def test_us05_unchanged_stories_add_no_versions_on_the_second_export(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    truth = load_dataset(committed_fixtures_dir).truth.stories
    harness.sweep(_reader(committed_fixtures_dir, "export-1.json"))

    summary = harness.sweep(_reader(committed_fixtures_dir, "export-2.json"))

    # Two stories carry a new version (the board move and the criteria change); five are as before.
    assert summary.versions_recorded == 2
    assert len(harness.versions(JIRA)) == truth.story_count + 2


def test_us05_status_only_version_still_supersedes_the_old_one_without_an_event(
    harness: Harness, committed_fixtures_dir: Path
) -> None:
    truth = load_dataset(committed_fixtures_dir).truth.stories
    harness.sweep(_reader(committed_fixtures_dir, "export-1.json"))
    harness.sweep(_reader(committed_fixtures_dir, "export-2.json"))

    versions = [v for v in harness.versions(JIRA) if v.item_id == truth.status_only_key]

    assert sorted(v.approval_state.value for v in versions) == ["admitted", "superseded"]
    assert not [
        e for e in harness.events(ChangeKind.SUPERSEDED) if e.item_id == truth.status_only_key
    ]
