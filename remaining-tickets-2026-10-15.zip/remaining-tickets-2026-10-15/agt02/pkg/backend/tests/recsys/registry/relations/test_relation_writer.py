"""The writer persists each relation's key, digest and evidence with its link row.

Driven through the recording fake the versioned-write tests already use, so the exact
statements and parameters are visible without a database.
"""

from __future__ import annotations

import unittest
from dataclasses import replace

from app.recsys.contracts import LinkType
from app.recsys.registry.models import ComponentLink
from app.recsys.registry.relation_writer import relation_evidence_params
from app.recsys.registry.relations.evidence import EvidenceEntry, evidence_digest
from app.recsys.registry.writer import write_version
from tests.recsys.registry.test_writer import FakeConnection, _fixture_rows, _summary

KEY = "a" * 64

ENTRY = EvidenceEntry(
    authority="agent_hub_export",
    collection="agent_records",
    structural_locator="sheet=Agent Usage;row=1",
    field_name="skill",
    token_ordinal=0,
    raw_token="alpha-helper",
    raw_token_digest=None,
    resolution_outcome="resolved_exact",
    matched_index="slugified_source_id",
    rule_id="exact_source_key",
    rule_version="policy-v1",
)


def _link(evidence: list[EvidenceEntry] | None = None, key: str | None = KEY) -> ComponentLink:
    """:return: One resolved link carrying the given evidence."""
    entries = [ENTRY, replace(ENTRY, token_ordinal=1)] if evidence is None else evidence
    return ComponentLink(
        src_id="agent:tenant-one/widget-helper",
        dst_id="skill:alpha-helper",
        link_type=LinkType.uses_skill,
        source="agent_usage_sheet",
        resolved=True,
        matched_indexes=["slugified_source_id"],
        relation_key=key,
        evidence_digest=evidence_digest(entries) if entries else None,
        evidence=entries,
    )


def _batched(conn: FakeConnection, table: str) -> tuple[int, list]:
    """:return: The position and parameters of the batched insert into one table."""
    for index, (query, params) in enumerate(conn.many):
        if f"INSERT INTO {table}" in query:
            return index, params
    raise AssertionError(f"no batched insert into {table}")


class RelationWriterTests(unittest.IsolatedAsyncioTestCase):
    async def test_the_link_row_carries_its_key_and_digest(self):
        conn = FakeConnection()
        link = _link()
        await write_version(conn, summary=_summary(), rows=_fixture_rows(), links=[link])

        _, params = _batched(conn, "recsys_component_link")
        self.assertEqual(len(params[0]), 10)
        self.assertEqual(params[0][8], KEY)
        self.assertEqual(params[0][9], link.evidence_digest)

    async def test_every_entry_is_one_row_numbered_within_its_relation(self):
        conn = FakeConnection()
        await write_version(conn, summary=_summary(), rows=_fixture_rows(), links=[_link()])

        link_index, _ = _batched(conn, "recsys_component_link")
        evidence_index, params = _batched(conn, "recsys_relation_evidence")
        self.assertLess(link_index, evidence_index)
        self.assertEqual(len(params), 2)
        self.assertTrue(all(len(row) == 18 for row in params))
        self.assertEqual([row[4] for row in params], [0, 1])
        self.assertEqual([row[10] for row in params], [0, 1])
        self.assertTrue(all(row[5] == KEY for row in params))

    async def test_only_this_versions_evidence_is_replaced(self):
        conn = FakeConnection()
        summary = _summary()
        await write_version(conn, summary=summary, rows=_fixture_rows(), links=[_link()])

        deletes = [(query, args) for query, args in conn.executed if "DELETE" in query.upper()]
        evidence = [item for item in deletes if "recsys_relation_evidence" in item[0]]
        self.assertEqual(len(evidence), 1)
        self.assertIn("catalogue_version = $1", evidence[0][0])
        self.assertEqual(evidence[0][1], (summary.version,))
        statements = " ".join(query for query, _ in deletes).upper()
        self.assertNotIn("DELETE FROM RECSYS_COMPONENT_LINK", statements)

    async def test_a_link_without_evidence_writes_no_evidence_rows(self):
        conn = FakeConnection()
        await write_version(
            conn, summary=_summary(), rows=_fixture_rows(), links=[_link([], key=None)]
        )

        self.assertFalse(
            any("recsys_relation_evidence" in query for query, _ in conn.many)
        )

    async def test_a_sensitive_token_is_written_as_a_digest(self):
        conn = FakeConnection()
        sensitive = replace(ENTRY, raw_token="/srv/private/alpha")
        await write_version(
            conn, summary=_summary(), rows=_fixture_rows(), links=[_link([sensitive])]
        )

        _, params = _batched(conn, "recsys_relation_evidence")
        self.assertTrue(params[0][11].startswith("sha256:"))
        self.assertIs(params[0][12], True)

    async def test_a_reference_ledger_row_carries_outcome_owner_and_link_type(self):
        conn = FakeConnection()
        entry = {
            "kind": "reference",
            "environment": "ppd",
            "component_type": "skill",
            "reason": "reference_not_found",
            "source_locator": "sheet=Agent Usage;row=1",
            "raw_value": "no-such-skill",
            "field_name": "skill",
            "resolution_outcome": "missing",
            "owner_component_id": "agent:tenant-one/widget-helper",
            "link_type": "USES_SKILL",
        }
        await write_version(
            conn,
            summary=_summary(),
            rows=_fixture_rows(),
            links=[],
            ledger_entries=[entry],
        )

        _, params = _batched(conn, "recsys_review_ledger_entry")
        self.assertEqual(len(params[0]), 14)
        self.assertEqual(
            params[0][11:], ("missing", "agent:tenant-one/widget-helper", "USES_SKILL")
        )


class RelationEvidenceParamTests(unittest.TestCase):
    def test_evidence_without_a_relation_key_is_refused(self):
        with self.assertRaises(ValueError):
            relation_evidence_params("v1", [_link(key=None)])


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
