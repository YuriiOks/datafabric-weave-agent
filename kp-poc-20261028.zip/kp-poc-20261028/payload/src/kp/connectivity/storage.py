"""Immutable object storage: a local directory and a cloud bucket.

Both stores share one rule: a key is written once. Writing the same bytes again is a no-op,
writing different bytes under an existing key is an error. Nothing is ever overwritten.
"""

from __future__ import annotations

import io
import os
import tempfile
from collections.abc import Callable
from importlib import import_module
from pathlib import Path, PurePosixPath
from typing import Any, Protocol

from kp.connectivity.errors import (
    BucketClientUnavailableError,
    ImmutableObjectError,
    InvalidObjectKeyError,
)
from kp.connectivity.ports import PutOutcome

_LOCAL_PREFIX = "local:"
_BUCKET_PREFIX = "bucket:"
_MAX_KEY_CHARS = 512


def validate_key(key: str) -> str:
    """Check that ``key`` is a relative, normalised, slash-separated path.

    :param key: The candidate key
    :return: The key, unchanged
    :raises kp.connectivity.errors.InvalidObjectKeyError: If it is empty, too long, absolute or
        contains ``.``/``..`` segments or backslashes
    """
    parts = key.split("/")
    invalid = (
        not key
        or len(key) > _MAX_KEY_CHARS
        or key.startswith("/")
        or "\\" in key
        or "\x00" in key
        or any(part in {"", ".", ".."} for part in parts)
    )
    if invalid:
        raise InvalidObjectKeyError(f"Not an acceptable object key: {key!r}")
    return key


def object_key(source: str, item_id: str, version: str) -> str:
    """Build the immutable raw key ``source/item/version``.

    :param source: The source kind value
    :param item_id: The item id
    :param version: The version token
    :return: The key
    :raises kp.connectivity.errors.InvalidObjectKeyError: If a part is not a safe segment
    """
    return validate_key(f"{source}/{item_id}/{version}")


class LocalObjectStore:
    """Objects as files under a root directory. Writes are exclusive and atomic.

    :param root: The directory that holds the store; created on first write
    """

    def __init__(self, root: Path) -> None:
        self._root = root

    def put_if_absent(self, key: str, data: bytes) -> PutOutcome:
        """Write ``data`` unless the key exists.

        :param key: The object key
        :param data: The bytes to store
        :return: ``CREATED``, or ``EXISTING`` when identical bytes were already there
        :raises kp.connectivity.errors.ImmutableObjectError: If the key exists with other bytes
        :raises kp.connectivity.errors.InvalidObjectKeyError: If the key is not acceptable
        """
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False, suffix=".part") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
            staged = Path(handle.name)
        try:
            os.link(staged, path)
        except FileExistsError:
            if path.read_bytes() != data:
                raise ImmutableObjectError(
                    f"Object already stored with other bytes: {key}"
                ) from None
            return PutOutcome.EXISTING
        finally:
            staged.unlink()
        return PutOutcome.CREATED

    def get(self, key: str) -> bytes:
        """Read an object.

        :param key: The object key
        :return: Its bytes
        :raises KeyError: If there is no such object
        """
        try:
            return self._path(key).read_bytes()
        except FileNotFoundError:
            raise KeyError(key) from None

    def exists(self, key: str) -> bool:
        """Say whether an object exists.

        :param key: The object key
        :return: True when it exists
        """
        return self._path(key).is_file()

    def location(self, key: str) -> str:
        """Return the storage reference of ``key``.

        :param key: The object key
        :return: ``local:<key>``
        """
        return f"{_LOCAL_PREFIX}{validate_key(key)}"

    def key_of(self, location: str) -> str:
        """Return the key of a storage reference.

        :param location: A reference from :meth:`location`
        :return: The object key
        :raises kp.connectivity.errors.InvalidObjectKeyError: If it is not a local reference
        """
        if not location.startswith(_LOCAL_PREFIX):
            raise InvalidObjectKeyError("Not a local storage reference")
        return validate_key(location.removeprefix(_LOCAL_PREFIX))

    def _path(self, key: str) -> Path:
        return self._root.joinpath(*PurePosixPath(validate_key(key)).parts)


class BucketClient(Protocol):
    """The few bucket operations the store needs. Matches the common S3-style client."""

    def put_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
        Body: bytes,  # noqa: N803 - same
        IfNoneMatch: str,  # noqa: N803 - same
    ) -> object:
        """Write an object only if the key does not exist (``IfNoneMatch="*"``)."""
        ...

    def get_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
    ) -> dict[str, Any]:
        """Read an object; the result holds a readable ``Body``."""
        ...


class _Readable(Protocol):
    def read(self) -> bytes: ...


class _GcsBlob(Protocol):
    def upload_from_string(self, data: bytes, *, if_generation_match: int | None) -> None: ...

    def download_as_bytes(self) -> bytes: ...


class _GcsBucket(Protocol):
    def blob(self, name: str) -> _GcsBlob: ...


class _GcsClient(Protocol):
    def bucket(self, name: str) -> _GcsBucket: ...


class _CodedClientError(Exception):
    """A client failure carrying an S3-style error code, so one recogniser serves both clients."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.response = {"Error": {"Code": code}}


_HTTP_NOT_FOUND = 404
_HTTP_PRECONDITION_FAILED = 412


class GcsBucketClient:
    """The bucket operations of :class:`BucketClient` over the native Cloud Storage client.

    Credentials are whatever the client library resolves from the workload's environment (its
    service account), so no key is configured here. "Write only if absent" is the generation
    precondition 0, which the service enforces atomically.

    :param client: A Cloud Storage client, or a stand-in with the same ``bucket(name)`` shape
    """

    def __init__(self, client: _GcsClient) -> None:
        self._client = client

    def put_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
        Body: bytes,  # noqa: N803 - same
        IfNoneMatch: str,  # noqa: N803 - same
    ) -> object:
        """Write an object; with ``IfNoneMatch="*"`` only if the key does not exist.

        :param Bucket: The bucket name
        :param Key: The object key
        :param Body: The bytes to store
        :param IfNoneMatch: ``"*"`` to refuse writing over an existing object
        :return: Nothing useful; present for the protocol
        :raises Exception: A coded "PreconditionFailed" error when the key already exists
        """
        generation = 0 if IfNoneMatch == "*" else None
        blob = self._client.bucket(Bucket).blob(Key)
        try:
            blob.upload_from_string(Body, if_generation_match=generation)
        except Exception as exc:
            if getattr(exc, "code", None) == _HTTP_PRECONDITION_FAILED:
                raise _CodedClientError("PreconditionFailed") from exc
            raise
        return None

    def get_object(
        self,
        *,
        Bucket: str,  # noqa: N803 - keyword names of the S3-style client API
        Key: str,  # noqa: N803 - same
    ) -> dict[str, Any]:
        """Read an object.

        :param Bucket: The bucket name
        :param Key: The object key
        :return: A mapping whose ``Body`` is readable, as the S3-style client returns
        :raises Exception: A coded "NoSuchKey" error when there is no such object
        """
        blob = self._client.bucket(Bucket).blob(Key)
        try:
            data = blob.download_as_bytes()
        except Exception as exc:
            if getattr(exc, "code", None) == _HTTP_NOT_FOUND:
                raise _CodedClientError("NoSuchKey") from exc
            raise
        return {"Body": io.BytesIO(data)}


def default_bucket_client() -> BucketClient:
    """Create a bucket client, importing the client library only now.

    The native Cloud Storage library is preferred; an S3-style library is the fallback for an
    S3-compatible store.

    :return: A client configured from the process environment
    :raises kp.connectivity.errors.BucketClientUnavailableError: If neither library is installed
    """
    try:
        storage = import_module("google.cloud.storage")
    except ImportError:
        pass
    else:
        return GcsBucketClient(storage.Client())
    try:
        module = import_module("boto3")
    except ImportError as exc:
        raise BucketClientUnavailableError(
            "The cloud-bucket client library is not installed; install it to use bucket storage"
        ) from exc
    client: BucketClient = module.client("s3")
    return client


class BucketObjectStore:
    """Objects in a cloud bucket. The client library is imported only when first needed.

    :param bucket: The bucket name
    :param client_factory: Builds the client; defaults to the lazily imported library
    """

    def __init__(
        self, bucket: str, client_factory: Callable[[], BucketClient] = default_bucket_client
    ) -> None:
        self._bucket = bucket
        self._client_factory = client_factory
        self._client: BucketClient | None = None

    def put_if_absent(self, key: str, data: bytes) -> PutOutcome:
        """Write ``data`` unless the key exists.

        :param key: The object key
        :param data: The bytes to store
        :return: ``CREATED``, or ``EXISTING`` when identical bytes were already there
        :raises kp.connectivity.errors.ImmutableObjectError: If the key exists with other bytes
        :raises kp.connectivity.errors.InvalidObjectKeyError: If the key is not acceptable
        :raises kp.connectivity.errors.BucketClientUnavailableError: If the library is absent
        """
        validate_key(key)
        try:
            existing = self.get(key)
        except KeyError:
            try:
                # The conditional write closes the gap between the check above and the write:
                # a writer that got there first makes this one fail instead of overwriting.
                self._connection().put_object(
                    Bucket=self._bucket, Key=key, Body=data, IfNoneMatch="*"
                )
            except Exception as exc:
                if not _is_precondition_failed(exc):
                    raise
                existing = self.get(key)
            else:
                return PutOutcome.CREATED
        if existing != data:
            raise ImmutableObjectError(f"Object already stored with other bytes: {key}")
        return PutOutcome.EXISTING

    def get(self, key: str) -> bytes:
        """Read an object.

        :param key: The object key
        :return: Its bytes
        :raises KeyError: If there is no such object
        :raises kp.connectivity.errors.BucketClientUnavailableError: If the library is absent
        """
        client = self._connection()
        try:
            response = client.get_object(Bucket=self._bucket, Key=validate_key(key))
        except Exception as exc:
            if _is_missing(exc):
                raise KeyError(key) from None
            raise
        body: _Readable = response["Body"]
        return body.read()

    def exists(self, key: str) -> bool:
        """Say whether an object exists.

        :param key: The object key
        :return: True when it exists
        :raises kp.connectivity.errors.BucketClientUnavailableError: If the library is absent
        """
        try:
            self.get(key)
        except KeyError:
            return False
        return True

    def location(self, key: str) -> str:
        """Return the storage reference of ``key``.

        :param key: The object key
        :return: ``bucket:<bucket>/<key>``
        """
        return f"{_BUCKET_PREFIX}{self._bucket}/{validate_key(key)}"

    def key_of(self, location: str) -> str:
        """Return the key of a storage reference.

        :param location: A reference from :meth:`location`
        :return: The object key
        :raises kp.connectivity.errors.InvalidObjectKeyError: If it belongs to another bucket
        """
        prefix = f"{_BUCKET_PREFIX}{self._bucket}/"
        if not location.startswith(prefix):
            raise InvalidObjectKeyError("Not a reference into this bucket")
        return validate_key(location.removeprefix(prefix))

    def _connection(self) -> BucketClient:
        if self._client is None:
            self._client = self._client_factory()
        return self._client


def _is_missing(exc: Exception) -> bool:
    """Recognise a "no such key" answer from an S3-style client without importing its types."""
    return _error_code(exc) in {"NoSuchKey", "404", "NotFound"}


def _is_precondition_failed(exc: Exception) -> bool:
    """Recognise "the key already exists" from a conditional write."""
    return _error_code(exc) in {"PreconditionFailed", "412", "ConditionalRequestConflict"}


def _error_code(exc: Exception) -> object:
    response = getattr(exc, "response", None)
    if isinstance(response, dict):
        error = response.get("Error")
        if isinstance(error, dict):
            return error.get("Code")
    return None
