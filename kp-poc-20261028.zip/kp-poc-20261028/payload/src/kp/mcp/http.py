"""MCP over a small HTTP endpoint, standard library only.

``POST <path>`` carries one JSON-RPC message and is answered with one JSON body (or ``202``
for a notification). The request handling is a pure function of method, path, headers and
body, so it is testable without a socket; :func:`create_http_server` adapts it to
:mod:`http.server`.
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import ClassVar, Final

from kp.mcp.identity import IdentityHeaders, caller_from_headers
from kp.mcp.jsonrpc import ErrorCode, JsonRpcError, Message, decode, encode, error_response
from kp.mcp.server import McpServer

logger = logging.getLogger(__name__)

DEFAULT_PATH: Final = "/mcp"
MAX_BODY_BYTES: Final = 1_048_576
READ_MAX_BODY_BYTES: Final = 65_536
"""A read request is a question; only a published spec needs the larger body."""
REQUEST_TIMEOUT_SECONDS: Final = 30.0
_JSON: Final = "application/json"


@dataclass(frozen=True, slots=True)
class HttpResponse:
    """A response to send."""

    status: int
    body: bytes = b""
    headers: Mapping[str, str] = field(default_factory=dict)


class McpHttpGateway:
    """Answers HTTP requests for one MCP server.

    :param server: The MCP server
    :param names: Which headers carry the caller's identity
    :param path: The only path that serves MCP
    :param allowed_origins: Browser origins allowed to call (DNS-rebinding defence); a request
        with any other ``Origin`` header is refused, and agents normally send none
    :param max_body_bytes: Largest accepted request body
    """

    def __init__(
        self,
        server: McpServer,
        *,
        names: IdentityHeaders | None = None,
        path: str = DEFAULT_PATH,
        allowed_origins: frozenset[str] = frozenset(),
        max_body_bytes: int = MAX_BODY_BYTES,
    ) -> None:
        self._server = server
        self._names = names if names is not None else IdentityHeaders()
        self._path = path
        self._allowed_origins = allowed_origins
        self._max_body_bytes = max_body_bytes

    @property
    def max_body_bytes(self) -> int:
        """The largest request body accepted."""
        return self._max_body_bytes

    def handle(
        self, method: str, path: str, headers: Mapping[str, str], body: bytes
    ) -> HttpResponse:
        """Answer one request.

        :param method: The HTTP method
        :param path: The request path without query string
        :param headers: Request headers (names are matched case-insensitively)
        :param body: The request body
        :return: The response
        """
        lowered = {name.lower(): value for name, value in headers.items()}
        rejection = self._reject(method, path, lowered, body)
        if rejection is not None:
            return rejection
        try:
            message = decode(body.decode("utf-8"))
        except (UnicodeDecodeError, JsonRpcError):
            parse_error = JsonRpcError(ErrorCode.PARSE_ERROR, "Parse error")
            return _json(400, error_response(None, parse_error))
        caller = caller_from_headers(lowered, self._names)
        response = self._server.handle(message, caller)
        if response is None:
            return HttpResponse(202)
        status = 400 if _is_protocol_error(response.get("error")) else 200
        return _json(status, response)

    def _reject(
        self, method: str, path: str, headers: Mapping[str, str], body: bytes
    ) -> HttpResponse | None:
        """Return the refusal for a request that must not reach the server, if any."""
        origin = headers.get("origin")
        if path != self._path:
            return _plain(404, "Not found")
        if method != "POST":
            return _plain(405, "Method not allowed", {"Allow": "POST"})
        if origin is not None and origin not in self._allowed_origins:
            return _plain(403, "Origin not allowed")
        if not headers.get("content-type", "").lower().startswith(_JSON):
            return _plain(415, "Content-Type must be application/json")
        if len(body) > self._max_body_bytes:
            return _plain(413, "Request body too large")
        return None


def _is_protocol_error(error: object) -> bool:
    return isinstance(error, dict) and error.get("code") in (
        int(ErrorCode.INVALID_REQUEST),
        int(ErrorCode.PARSE_ERROR),
    )


def _plain(status: int, text: str, headers: Mapping[str, str] | None = None) -> HttpResponse:
    return HttpResponse(
        status, text.encode("ascii"), {"Content-Type": "text/plain", **(headers or {})}
    )


def _json(status: int, message: Message) -> HttpResponse:
    return HttpResponse(status, encode(message).encode("ascii"), {"Content-Type": _JSON})


class _Handler(BaseHTTPRequestHandler):
    """Adapts :mod:`http.server` to :class:`McpHttpGateway`."""

    _gateway: ClassVar[McpHttpGateway]

    def _dispatch(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = -1
        if length < 0 or length > self._gateway.max_body_bytes:
            self.close_connection = True
            self._send(_plain(413 if length > 0 else 400, "Unusable Content-Length"))
            return
        try:
            body = self.rfile.read(length) if length else b""
        except TimeoutError:
            # A client that announced a body and never sent it must not hold a thread.
            self.close_connection = True
            self._send(_plain(408, "Request timed out"))
            return
        path = self.path.split("?", 1)[0]
        self._send(self._gateway.handle(self.command, path, dict(self.headers.items()), body))

    def _send(self, response: HttpResponse) -> None:
        self.send_response(response.status)
        for name, value in response.headers.items():
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(response.body)))
        self.end_headers()
        self.wfile.write(response.body)

    do_GET = do_POST = do_PUT = do_DELETE = do_PATCH = _dispatch  # noqa: N815 - http.server hook names

    def log_message(self, format: str, *args: object) -> None:  # noqa: ARG002 - base signature
        """Route access logging to the structured logger without request details."""
        logger.debug("HTTP request handled")


def create_http_server(
    gateway: McpHttpGateway,
    host: str,
    port: int,
    *,
    request_timeout: float = REQUEST_TIMEOUT_SECONDS,
) -> ThreadingHTTPServer:
    """Create (but do not start) a threaded HTTP server for the gateway.

    :param gateway: The request handler
    :param host: The address to bind; keep it on loopback unless a trusted proxy fronts it
    :param port: The port; ``0`` picks a free one
    :param request_timeout: Seconds a connection may stall while sending its request
    :return: The server; call ``serve_forever`` and ``server_close``
    """

    class BoundHandler(_Handler):
        _gateway = gateway
        timeout = request_timeout

    return ThreadingHTTPServer((host, port), BoundHandler)
