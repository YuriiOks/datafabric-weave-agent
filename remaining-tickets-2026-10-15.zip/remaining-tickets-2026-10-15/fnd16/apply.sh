#!/usr/bin/env bash
# Apply the acceptance-matrix package on the committed refresh-integration branch, uncommitted.
# Usage: bash apply.sh <worktree-root>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:?worktree root}"
python3 "$HERE/apply_fnd16.py" "$ROOT" --check
python3 "$HERE/apply_fnd16.py" "$ROOT"
git -C "$ROOT" status -s --untracked-files=all
