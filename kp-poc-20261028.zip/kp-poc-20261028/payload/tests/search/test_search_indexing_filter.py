"""Indexing only the stories that changed."""

from __future__ import annotations

from sqlalchemy import func, select

from kp.search import index_stories
from kp.store import schema
from world_support import World


def test_only_the_named_stories_are_indexed(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        some = index_stories(connection, ["PAY-101"])
        everything = index_stories(connection)
        stored = connection.execute(
            select(func.count())
            .select_from(schema.passage)
            .where(schema.passage.c.item_id == "PAY-101")
        ).scalar_one()

    assert 0 < some < everything
    assert stored == some  # re-indexing replaces, never duplicates


def test_naming_no_story_indexes_nothing(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        assert index_stories(connection, []) == 0
