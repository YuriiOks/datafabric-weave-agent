"""Runtime wiring: pre-production gate, fail-closed default and worker lifecycle."""

from __future__ import annotations

import asyncio
import unittest
from unittest.mock import AsyncMock, Mock, patch

from app.recsys.config import RecsysSettings
from app.recsys.refresh import runtime
from app.recsys.refresh.runtime import (
    RefreshRuntime,
    close_refresh_runtime,
    configure_refresh_runtime,
    initialize_refresh_runtime,
    reset_refresh_runtime,
)


def _settings(**overrides) -> RecsysSettings:
    values = {"recsys_enabled": True, "recsys_refresh_enabled": True}
    values.update(overrides)
    return RecsysSettings(**values)


class _Worker:
    def __init__(self, error: Exception | None = None) -> None:
        self.error = error
        self.started = asyncio.Event()
        self._stop = asyncio.Event()
        self.stopped = False

    async def run_forever(self) -> None:
        self.started.set()
        if self.error is not None:
            raise self.error
        await self._stop.wait()

    async def stop(self) -> None:
        self.stopped = True
        self._stop.set()


class PreproductionGateTests(unittest.IsolatedAsyncioTestCase):
    async def asyncTearDown(self) -> None:
        reset_refresh_runtime()

    async def test_production_is_refused_before_the_database_is_touched(self) -> None:
        settings = _settings(
            recsys_refresh_preproduction_authority_enabled=True,
            recsys_refresh_environment="prod",
            recsys_refresh_preproduction_operators="operator-1",
            recsys_refresh_workspace_root="/srv/workspace",
        )
        pool = Mock(side_effect=AssertionError("database touched"))

        with patch.object(runtime, "resolve_pool", pool):
            with self.assertRaisesRegex(RuntimeError, "refused outside ppd"):
                await initialize_refresh_runtime(settings)
        pool.assert_not_called()

    async def test_missing_operator_list_is_refused(self) -> None:
        settings = _settings(
            recsys_refresh_preproduction_authority_enabled=True,
            recsys_refresh_environment="ppd",
            recsys_refresh_workspace_root="/srv/workspace",
        )

        with patch.object(runtime, "resolve_pool", Mock(side_effect=AssertionError)):
            with self.assertRaisesRegex(RuntimeError, "PREPRODUCTION_OPERATORS"):
                await initialize_refresh_runtime(settings)

    async def test_without_the_flag_refresh_still_fails_closed(self) -> None:
        settings = _settings(recsys_refresh_environment="ppd")

        with self.assertRaisesRegex(RuntimeError, "configured authority and ports"):
            await initialize_refresh_runtime(settings)


class WorkerLifecycleTests(unittest.IsolatedAsyncioTestCase):
    async def asyncTearDown(self) -> None:
        reset_refresh_runtime()

    async def _initialize(self, worker: _Worker, *, worker_enabled: bool, on_close=None):
        configure_refresh_runtime(
            RefreshRuntime(service=object(), worker=worker, on_close=on_close)
        )
        with (
            patch.object(runtime, "resolve_pool", Mock(return_value=object())),
            patch.object(runtime, "ensure_schema", AsyncMock()),
        ):
            settings = _settings(recsys_refresh_worker_enabled=worker_enabled)
            await initialize_refresh_runtime(settings)

    async def test_worker_runs_until_shutdown_and_cleanup_follows(self) -> None:
        worker = _Worker()
        on_close = Mock()

        await self._initialize(worker, worker_enabled=True, on_close=on_close)
        await asyncio.wait_for(worker.started.wait(), timeout=1)
        await close_refresh_runtime()

        self.assertTrue(worker.stopped)
        on_close.assert_called_once_with()

    async def test_worker_is_not_started_without_the_worker_flag(self) -> None:
        worker = _Worker()

        await self._initialize(worker, worker_enabled=False)
        await asyncio.sleep(0)

        self.assertFalse(worker.started.is_set())

    async def test_crashed_worker_is_logged_and_surfaces_at_shutdown(self) -> None:
        worker = _Worker(error=RuntimeError("loop died"))

        with self.assertLogs("app.recsys.refresh.runtime", level="ERROR"):
            await self._initialize(worker, worker_enabled=True)
            await asyncio.wait_for(worker.started.wait(), timeout=1)
            for _ in range(3):
                await asyncio.sleep(0)
        with self.assertRaisesRegex(RuntimeError, "loop died"):
            await close_refresh_runtime()
