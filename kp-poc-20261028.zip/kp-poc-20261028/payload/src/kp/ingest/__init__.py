"""Ingest: parsers and their repositories.

* Rulebook (PDF, Markdown) to clauses with page and character position (US-07).
* Register workbook to one requirement per data row (US-06).
* Tracker issues to stories with acceptance criteria kept apart (US-05).
* :class:`IngestProcessor`, the entry point for admitted item versions, and
  :class:`SweepContentProcessor`, its adapter to the sweep's processor port. Document details
  (US-03) are checked by the approval gate in ``kp.sweep``, before an item gets here.
"""

from kp.ingest.errors import (
    EditionConflictError,
    IngestError,
    MissingEffectiveDateError,
    RegisterParseError,
    RulebookParseError,
    StoryParseError,
)
from kp.ingest.models import (
    ParsedRegister,
    ParsedRulebook,
    SheetReport,
    StructureDecision,
    TocEntry,
)
from kp.ingest.processor import (
    ContentProcessor,
    IngestProcessor,
    ProcessingOutcome,
    ProcessingResult,
)
from kp.ingest.register import parse_register
from kp.ingest.repository import (
    ClauseStore,
    EditionStore,
    RequirementStore,
    ReviewStore,
    StoryChange,
    StoryStore,
)
from kp.ingest.reviews import ReviewContext, structure_review_id
from kp.ingest.rulebook import (
    clause_source_text,
    extract_pdf_pages,
    parse_rulebook_markdown,
    parse_rulebook_pdf,
)
from kp.ingest.stories import normalise_story, parse_story_export
from kp.ingest.sweep_adapter import SweepContentProcessor

__all__ = [
    "ClauseStore",
    "ContentProcessor",
    "EditionConflictError",
    "EditionStore",
    "IngestError",
    "IngestProcessor",
    "MissingEffectiveDateError",
    "ParsedRegister",
    "ParsedRulebook",
    "ProcessingOutcome",
    "ProcessingResult",
    "RegisterParseError",
    "RequirementStore",
    "ReviewContext",
    "ReviewStore",
    "RulebookParseError",
    "SheetReport",
    "StoryChange",
    "StoryParseError",
    "StoryStore",
    "StructureDecision",
    "SweepContentProcessor",
    "TocEntry",
    "clause_source_text",
    "extract_pdf_pages",
    "normalise_story",
    "parse_register",
    "parse_rulebook_markdown",
    "parse_rulebook_pdf",
    "parse_story_export",
    "structure_review_id",
]
