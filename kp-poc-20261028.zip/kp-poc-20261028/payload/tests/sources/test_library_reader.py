"""Document library reader: US-01 (approved only), US-03 (details reported), US-04 (withdrawn)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from kp.domain.enums import SourceKind
from kp.domain.source_items import DETAIL_NAMES
from kp.errors import SourceItemNotFoundError
from kp.sources import DocumentLibraryReader, MalformedSourceDataError
from kp.sources import attributes as attr

from .support import drain, ids, key, write_json

LIBRARY = SourceKind.DOCUMENT_LIBRARY


def _edit_sidecar(path: Path, **changes: object) -> None:
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload.update(changes)
    write_json(path, payload)


def test_us01_only_approved_version_is_listed_and_the_newer_draft_is_not(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    items, _ = drain(reader)

    assert ids(items) == {
        ("operating-guide", "2"),
        ("escalation-note", "1"),
        ("unclassified-memo", "1"),
    }


def test_us01_a_draft_cannot_be_fetched_either(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(key(LIBRARY, "operating-guide", "3"))


def test_us01_draft_bytes_are_not_reachable_through_any_listed_item(data_root: Path) -> None:
    library = data_root / "library"
    reader = DocumentLibraryReader(library)
    draft_bytes = (library / "operating-guide.v3-draft.md").read_bytes()

    items, _ = drain(reader)
    contents = [reader.fetch(item.key).content for item in items]

    assert contents
    assert draft_bytes not in contents
    assert {item.key.item_id for item in items} <= {
        "operating-guide",
        "escalation-note",
        "unclassified-memo",
    }


def test_us01_fetch_returns_the_approved_bytes_unaltered_with_approval_signals(
    data_root: Path,
) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    fetched = reader.fetch(key(LIBRARY, "operating-guide", "2"))

    assert fetched.content == (data_root / "library" / "operating-guide.v2.md").read_bytes()
    assert fetched.metadata.media_type == "text/markdown"
    assert fetched.metadata.title == "Operating guide"
    assert fetched.metadata.attributes[attr.APPROVAL_STATUS] == "approved"
    assert fetched.metadata.attributes[attr.SIDECAR_PRESENT] is True
    assert fetched.metadata.attributes["document_type"] == "guide"
    assert fetched.metadata.modified_at is not None


def test_us01_draft_later_approved_is_listed_as_a_new_version_on_the_next_sweep(
    data_root: Path,
) -> None:
    library = data_root / "library"
    reader = DocumentLibraryReader(library)
    _, cursor = drain(reader)

    _edit_sidecar(library / "operating-guide.v3-draft.meta.json", approval_status="approved")
    items, _ = drain(reader, cursor)

    assert ids(items) == {("operating-guide", "3")}
    assert not any(item.deleted for item in items)
    # The old version is still fetchable: it is superseded by the gate, not deleted.
    assert reader.fetch(key(LIBRARY, "operating-guide", "2")).content


def test_us01_unchanged_library_reports_nothing_on_the_next_sweep(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")
    _, cursor = drain(reader)

    items, again = drain(reader, cursor)

    assert items == []
    assert again == cursor


def test_us03_missing_detail_is_reported_as_none_not_dropped(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    attributes = reader.fetch(key(LIBRARY, "escalation-note", "1")).metadata.attributes

    assert attributes["content_owner"] is None
    assert {name: attributes[name] for name in DETAIL_NAMES if name != "content_owner"} == {
        "document_type": "procedure",
        "domain": "payments",
        "authority": "Example Scheme",
        "classification": "internal",
    }


def test_us03_unknown_document_type_is_passed_through_for_the_gate(data_root: Path) -> None:
    reader = DocumentLibraryReader(data_root / "library")

    attributes = reader.fetch(key(LIBRARY, "unclassified-memo", "1")).metadata.attributes

    assert attributes["document_type"] == "unrecognised-type"


def test_us03_blank_detail_counts_as_missing(data_root: Path) -> None:
    library = data_root / "library"
    _edit_sidecar(library / "operating-guide.v2.meta.json", authority="   ")

    attributes = (
        DocumentLibraryReader(library)
        .fetch(key(LIBRARY, "operating-guide", "2"))
        .metadata.attributes
    )

    assert attributes["authority"] is None


def test_us03_document_without_a_sidecar_is_listed_with_no_signals(tmp_path: Path) -> None:
    (tmp_path / "loose.md").write_text("# Loose\n\nNo sidecar.\n", encoding="utf-8")
    reader = DocumentLibraryReader(tmp_path)

    items, _ = drain(reader)
    attributes = reader.fetch(items[0].key).metadata.attributes

    assert items[0].key.item_id == "loose.md"
    assert attributes[attr.SIDECAR_PRESENT] is False
    assert attributes[attr.APPROVAL_STATUS] is None
    assert all(attributes[name] is None for name in DETAIL_NAMES)


def test_us04_removed_document_is_reported_deleted_on_the_next_sweep(data_root: Path) -> None:
    library = data_root / "library"
    reader = DocumentLibraryReader(library)
    _, cursor = drain(reader)

    (library / "operating-guide.v2.md").unlink()
    (library / "operating-guide.v2.meta.json").unlink()
    items, _ = drain(reader, cursor)

    assert [(item.key.item_id, item.key.version, item.deleted) for item in items] == [
        ("operating-guide", "2", True)
    ]


def test_us04_withdrawn_approval_is_listed_with_its_status_and_content_is_kept(
    data_root: Path,
) -> None:
    library = data_root / "library"
    reader = DocumentLibraryReader(library)
    _, cursor = drain(reader)

    _edit_sidecar(library / "operating-guide.v2.meta.json", approval_status="Withdrawn")
    items, _ = drain(reader, cursor)
    fetched = reader.fetch(items[0].key)

    assert ids(items) == {("operating-guide", "2")}
    assert items[0].deleted is False
    assert fetched.metadata.attributes[attr.APPROVAL_STATUS] == "withdrawn"
    assert fetched.content == (library / "operating-guide.v2.md").read_bytes()


def test_us04_approval_pulled_back_to_draft_is_reported_deleted(data_root: Path) -> None:
    library = data_root / "library"
    reader = DocumentLibraryReader(library)
    _, cursor = drain(reader)

    _edit_sidecar(library / "operating-guide.v2.meta.json", approval_status="draft")
    items, _ = drain(reader, cursor)

    assert [(item.key.version, item.deleted) for item in items] == [("2", True)]
    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(key(LIBRARY, "operating-guide", "2"))


def test_us01_malformed_sidecar_raises_instead_of_hiding_the_document(tmp_path: Path) -> None:
    (tmp_path / "broken.md").write_text("# Broken\n", encoding="utf-8")
    (tmp_path / "broken.meta.json").write_text("{not json", encoding="utf-8")

    with pytest.raises(MalformedSourceDataError):
        drain(DocumentLibraryReader(tmp_path))


def test_us01_two_documents_claiming_one_version_raise(data_root: Path) -> None:
    library = data_root / "library"
    (library / "copy.md").write_text("# Copy\n", encoding="utf-8")
    write_json(
        library / "copy.meta.json",
        json.loads((library / "operating-guide.v2.meta.json").read_text(encoding="utf-8")),
    )

    with pytest.raises(MalformedSourceDataError):
        drain(DocumentLibraryReader(library))


def test_us01_editing_a_document_without_a_sidecar_version_deletes_the_old_version(
    tmp_path: Path,
) -> None:
    document = tmp_path / "loose.md"
    document.write_text("# Loose\n\nFirst.\n", encoding="utf-8")
    reader = DocumentLibraryReader(tmp_path)
    first, cursor = drain(reader)

    document.write_text("# Loose\n\nSecond.\n", encoding="utf-8")
    second, _ = drain(reader, cursor)

    # No explicit version: the edit is a different version, and the old one is "deleted",
    # not superseded. Only a sidecar version gives supersession.
    old_version = first[0].key.version
    assert {(i.key.version == old_version, i.deleted) for i in second} == {
        (True, True),
        (False, False),
    }


def test_us01_editing_a_document_with_a_sidecar_version_is_the_same_version_changed(
    data_root: Path,
) -> None:
    library = data_root / "library"
    reader = DocumentLibraryReader(library)
    _, cursor = drain(reader)

    (library / "operating-guide.v2.md").write_text("# Operating guide\n\nEdited.\n", "utf-8")
    items, _ = drain(reader, cursor)

    assert [(i.key.item_id, i.key.version, i.deleted) for i in items] == [
        ("operating-guide", "2", False)
    ]


def test_us01_two_formats_sharing_a_stem_sidecar_claim_one_version_and_raise(
    tmp_path: Path,
) -> None:
    (tmp_path / "policy.md").write_text("# Policy\n", encoding="utf-8")
    (tmp_path / "policy.pdf").write_bytes(b"%PDF-1.4\n")
    write_json(
        tmp_path / "policy.meta.json",
        {"item_id": "policy", "version": "1", "approval_status": "approved"},
    )

    with pytest.raises(MalformedSourceDataError):
        drain(DocumentLibraryReader(tmp_path))


def test_us01_a_sidecar_named_after_the_whole_file_lets_two_formats_coexist(
    tmp_path: Path,
) -> None:
    (tmp_path / "policy.md").write_text("# Policy\n", encoding="utf-8")
    (tmp_path / "policy.pdf").write_bytes(b"%PDF-1.4\n")
    write_json(
        tmp_path / "policy.md.meta.json",
        {"item_id": "policy", "version": "1", "approval_status": "approved"},
    )
    write_json(
        tmp_path / "policy.pdf.meta.json",
        {"item_id": "policy-pdf", "version": "1", "approval_status": "approved"},
    )

    items, _ = drain(DocumentLibraryReader(tmp_path))

    assert ids(items) == {("policy", "1"), ("policy-pdf", "1")}


def test_us01_the_whole_file_sidecar_wins_over_the_stem_sidecar(tmp_path: Path) -> None:
    (tmp_path / "policy.md").write_text("# Policy\n", encoding="utf-8")
    write_json(tmp_path / "policy.meta.json", {"item_id": "stem", "version": "1"})
    write_json(tmp_path / "policy.md.meta.json", {"item_id": "whole", "version": "1"})

    items, _ = drain(DocumentLibraryReader(tmp_path))

    assert ids(items) == {("whole", "1")}


def test_us01_a_document_removed_after_the_listing_cannot_be_fetched(tmp_path: Path) -> None:
    (tmp_path / "doc.md").write_text("# Doc\n", encoding="utf-8")
    reader = DocumentLibraryReader(tmp_path)
    items, _ = drain(reader)

    (tmp_path / "doc.md").unlink()

    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(items[0].key)
