> [!IMPORTANT]
> **Stacked on the Skill case-pack PR (DTAA-1489).** This branch is cut from that one and its base is that branch; review and merge that first, then retarget this PR to `main`. Every case here is synthetic and unjudged, and every approval ships open.

## Problem

MCP suggestion quality cannot be inferred from parsing, a demo or declared relationships, and there is no MCP case set at all. Nothing records what a run depended on either: its lineage, the split, the reviewer decisions and the approvals that have to be in place before anyone relies on the result.

## Solution

- **MCP profile.** MCP cases use the shared case-pack format with their own prefix and scenarios. They add partial matches, unknown prerequisites and source conflicts. A non-match is a hard negative, and an empty control is a valid empty. A pack must cover positive, partial, hard negative, valid empty, access restricted, duplicate alias, unresolved dependency, unknown prerequisite and conflict cases.
- **Release evidence.** One record per run carries the run reference, the lineage, the corpus, split and decision-log digests, and the denominator report. It also lists the approvals the pack depends on: domain reviewers, the shared input contract and authorised evidence are required; access and privacy is recorded when given.
  - An approval nobody recorded counts as open. Open and refused approvals are blockers, and so is tuning feedback recorded against the final test.
  - A pack that does not validate against its corpus, or disagrees with its decision log, is refused outright.
  - The rendered record ends by saying it is evidence for a decision taken elsewhere, with no promotion claim.

Unchanged: everything from the Skill case-pack PR, except that the profile table gains the MCP entry. No route, catalogue, publication or model call is touched.

## How to verify

1. Unit tests: `tests/recsys/eval/test_casepack_mcp.py` and `tests/recsys/eval/test_casepack_release.py`. CI runs them.
2. Render the release evidence of the synthetic MCP pack with no approvals. The approvals table shows all three required approvals as open, and "Blocked:" lists them.
3. Negative case: record a refused authorised-evidence approval. It is listed as "approval refused: authorised_evidence".

## Not in this PR

- **Adjudicated labels.** Every case is unjudged; the domain reviewers judge them through the decision log.
- **Approvals.** All approvals ship open, so no result here can be relied on.
- **Live corpus.** Publication reads are not mounted, so the corpus is built from records the caller supplies.
- **Component ids.** Cases use canonical component id text, as the publication emits them. Joining that to the runner's type-and-slug keys is the shared baseline's integration point.
- **Out of scope.** Thresholds, rollout, model calls and the release decision itself.

## Review focus

- Access and privacy is recorded but not required. Should an access-restricted case make it required?
- The split between refusing (an invalid pack, a decision-log disagreement, an approval recorded twice) and listing a blocker (open approvals, final-test feedback, report blockers).

## CI

- The checks posted on this head are the result.
