---
pack_id: "bpc-sep26-v1"
local_id: "MCP-06"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1347"
summary: "Build MCP evaluation cases and release evidence for the shared baseline"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 5
scope: "recommendations"
create_by_default: false
planned_start: "2026-09-24"
planned_due: "2026-09-25"
dates_profile: "recommendations"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["MCP-05","CORE-07"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-mcp-06"
architecture_sections: ["validation-gates","engine","evaluation"]
---

# Build MCP evaluation cases and release evidence for the shared baseline

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1347**. Local reference **MCP-06** is not a Jira key.
- Estimate: **5 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **not scheduled; do not create by default**.
- Recommendation extension: **2026-09-24 → 2026-09-25 (D12–D13)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

MCP recommendation quality cannot be inferred from parsing, a demo, or source relationships. Supply the versioned adjudicated MCP cohort and release-evidence package required by CORE-07/09.

## Scope and contract

Cases are pinned to catalogue/publication, policy, and source evidence; grouped by related/duplicate components; and record expected candidate IDs, forbidden IDs, required evidence, and truthful outcome state. Domain adjudication owns relevance/suitability. Relationships, graph co-occurrence, and overrides are never automatic ground truth.

## Steps

1. Define MCP case templates from approved source fields and shared baseline input.
2. Record domain adjudication for relevant, partial, non-match, empty-control, duplicate, unresolved, access-limited, unknown-prerequisite, and conflict cases.
3. Pin lineage and grouped development/validation/final-test membership using the shared evaluation contract; hand the completed case pack to CORE-09.
4. Produce coverage, unjudged, forbidden-hit, failure, lineage, and approval-decision evidence.

## Acceptance and verification

- Every released case has stable ID, pinned lineage, adjudication or explicit unjudged state, and required/forbidden evidence.
- Duplicates/related MCPs share an evaluation group and cannot leak into held-out partitions.
- Empty, inaccessible, unresolved, unknown-prerequisite, and conflict cases state truthful outcomes; failure is not a correct empty result.
- Source-declared relationships require domain adjudication before they support suitability.
- The report distinguishes planned, completed, unjudged, failed, disabled, and blocked cases and makes no promotion claim.

## Evidence, blockers and exclusions

Attach case/adjudication/group manifests, forbidden-hit/completion report, and open approvals. Block on absent domain reviewers, shared input contract, or authorised evidence. Threshold setting, rollout, external model calls, and release approval are excluded.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [MCP-05](MCP-05.md) must finish its stated contract boundary before this task starts.
- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `validation-gates`, `engine`, `evaluation`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
