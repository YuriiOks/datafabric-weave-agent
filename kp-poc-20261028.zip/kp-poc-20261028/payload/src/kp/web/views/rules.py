"""Rule: one clause as it stood on a date, beside every edition that carries it."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from pydantic import JsonValue

from kp.domain import Edition, EditionState
from kp.errors import AccessForbiddenError, KpError
from kp.tools import InvalidToolArgumentsError
from kp.tools.rules import RuleOutput
from kp.web.errors import Problem, problem_from
from kp.web.identity import Viewer
from kp.web.query import QueryForm
from kp.web.state import WebState

TOOL = "rule_as_at"


@dataclass(frozen=True, slots=True)
class EditionRow:
    """One edition and what it says about the clause.

    :ivar state: The state of the edition on the date asked about.
    :ivar clause: The clause as that edition has it; ``None`` when it cannot be shown.
    :ivar note: Why no clause is shown.
    :ivar cited: True for the edition a citation named.
    """

    label: str
    effective_date: date
    superseded_from: date | None
    withdrawn_from: date | None
    state: EditionState
    clause: RuleOutput | None
    note: str = ""
    cited: bool = False


@dataclass(frozen=True, slots=True)
class RuleView:
    """The rule page.

    :ivar number: The clause number asked for (empty before the first lookup).
    :ivar as_at: The date the rule is read at.
    :ivar in_force: The clause in the edition in force on that date.
    :ivar in_force_problem: Why the clause in force cannot be shown, while the editions still can.
    :ivar problem: Why the whole page cannot be shown.
    """

    number: str = ""
    as_at: date | None = None
    in_force: RuleOutput | None = None
    in_force_problem: Problem | None = None
    editions: tuple[EditionRow, ...] = ()
    problem: Problem | None = None

    @property
    def looked_up(self) -> bool:
        """True once a clause number has been put."""
        return bool(self.number)


def read_rule(state: WebState, viewer: Viewer, form: QueryForm) -> RuleView:
    """Read a clause as at a date, and in every edition.

    Each reading goes through the ``rule_as_at`` tool as the viewer, so an edition the viewer may
    not read is refused in the same way as for an agent.

    :param state: The shared state
    :param viewer: Who is asking
    :param form: The query string of the request
    :return: The view
    """
    number = ""
    as_at: date | None = None
    try:
        number = form.text("number")
        as_at = form.day("as_at", "As at")
        if not number:
            # Nothing is asked, so nothing is recorded; but the form is not for everyone.
            state.require_access(viewer)
            return RuleView(as_at=as_at)
        day = as_at or state.application.clock.today()
        in_force, in_force_problem = _read_in_force(state, viewer, number, day)
        editions = _read_editions(state, viewer, number, day, in_force, form.text("edition"))
        return RuleView(number, day, in_force, in_force_problem, editions)
    except KpError as exc:
        return RuleView(number, as_at, problem=problem_from(exc))


def _read_in_force(
    state: WebState, viewer: Viewer, number: str, day: date
) -> tuple[RuleOutput | None, Problem | None]:
    """Read the clause on the date; a refusal or a bad number stops the page, the rest is shown."""
    try:
        return _read(state, viewer, number, day), None
    except (AccessForbiddenError, InvalidToolArgumentsError):
        raise
    except KpError as exc:
        return None, problem_from(exc)


def _read(state: WebState, viewer: Viewer, number: str, day: date) -> RuleOutput:
    arguments: dict[str, JsonValue] = {"number": number, "as_at": day.isoformat()}
    return RuleOutput.model_validate(state.call(viewer, TOOL, arguments))


def _read_editions(
    state: WebState,
    viewer: Viewer,
    number: str,
    day: date,
    in_force: RuleOutput | None,
    cited: str,
) -> tuple[EditionRow, ...]:
    rows = []
    editions = sorted(
        state.application.read_ports().rules.editions(), key=lambda e: (e.effective_date, e.label)
    )
    for edition in editions:
        if in_force is not None and in_force.edition == edition.label:
            clause: RuleOutput | None = in_force
            note = ""
        else:
            clause, note = _read_edition(state, viewer, number, edition)
        rows.append(
            EditionRow(
                label=edition.label,
                effective_date=edition.effective_date,
                superseded_from=edition.superseded_from,
                withdrawn_from=edition.withdrawn_from,
                state=edition.state_on(day),
                clause=clause,
                note=note,
                cited=edition.label == cited,
            )
        )
    return tuple(rows)


def _read_edition(
    state: WebState, viewer: Viewer, number: str, edition: Edition
) -> tuple[RuleOutput | None, str]:
    """Read the clause as the edition has it: on the day that edition took effect."""
    try:
        clause = _read(state, viewer, number, edition.effective_date)
    except AccessForbiddenError:
        return None, "You may not read this edition."
    except KpError as exc:
        return None, problem_from(exc).message
    if clause.edition != edition.label:
        return None, "This edition was not the one in force on its own effective date."
    return clause, ""
