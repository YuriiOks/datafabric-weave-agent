"""Install the knowledge platform from an unpacked bank package.

This file ships as ``install.py`` at the top of the package. It uses the standard library only,
so it runs on a bare Python 3 with no package mirror.

Run it from anywhere, with the package folder as the location of this file::

    python3 install.py --inspect --target DIR   # verify checksums, list what would be written
    python3 install.py --target DIR             # verify checksums, then write

Every mode verifies ``SHA256SUMS`` first. The new tree is written into ``--target``, which must be
absent or empty unless ``--force`` is given. Nothing is deleted and nothing outside the target is
touched.

Exit status: 0 done, 1 the target was refused, 2 the package failed verification or the
arguments were wrong.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

CHECKSUM_FILE = "SHA256SUMS"
PAYLOAD_DIR = "payload"
DEFAULT_TARGET = "kp-poc"
EXIT_OK = 0
EXIT_REFUSED = 1
EXIT_BAD_PACKAGE = 2

_CHECKSUM_LINE = re.compile(r"^([0-9a-f]{64})  (\S.*)$")
_IGNORED_PARTS = frozenset({"__pycache__"})
_READ_CHUNK = 1 << 20


class PackageError(Exception):
    """The package folder is damaged or incomplete."""


@dataclass(frozen=True, slots=True)
class PlannedFile:
    """One file the install would write.

    :ivar relative: Path inside the target, with forward slashes
    :ivar source: The file inside the package
    :ivar size: Size in bytes
    :ivar exists: Whether the target already holds a file there
    """

    relative: str
    source: Path
    size: int
    exists: bool


def sha256_of(path: Path) -> str:
    """Return the SHA-256 of a file as lower-case hex.

    :param path: The file to read
    :return: The digest
    """
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(_READ_CHUNK), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_checksums(text: str) -> dict[str, str]:
    """Parse ``sha256sum`` output.

    :param text: Contents of ``SHA256SUMS``
    :return: Digest per relative path
    :raises PackageError: On a malformed line, a duplicate, or an unsafe path
    """
    entries: dict[str, str] = {}
    for number, line in enumerate(text.splitlines(), start=1):
        match = _CHECKSUM_LINE.match(line)
        if match is None:
            raise PackageError(f"{CHECKSUM_FILE} line {number} is not a checksum line")
        digest, name = match.groups()
        parts = PurePosixPath(name).parts
        if PurePosixPath(name).is_absolute() or ".." in parts or not parts:
            raise PackageError(f"{CHECKSUM_FILE} line {number} names an unsafe path")
        if name in entries:
            raise PackageError(f"{CHECKSUM_FILE} line {number} repeats a path")
        entries[name] = digest
    return entries


def _package_files(package_dir: Path) -> set[str]:
    """Every file under the package folder except the checksum file."""
    found: set[str] = set()
    for path in package_dir.rglob("*"):
        relative = path.relative_to(package_dir)
        if not path.is_file() or _IGNORED_PARTS & set(relative.parts):
            continue
        name = relative.as_posix()
        if name != CHECKSUM_FILE:
            found.add(name)
    return found


def verify_package(package_dir: Path) -> dict[str, str]:
    """Check every file of the package against ``SHA256SUMS``.

    :param package_dir: The unpacked package folder
    :return: The verified digest per relative path
    :raises PackageError: If the checksum file is absent, a file is missing, changed or unlisted
    """
    checksum_path = package_dir / CHECKSUM_FILE
    if not checksum_path.is_file():
        raise PackageError(f"{CHECKSUM_FILE} is missing: this is not a complete package")
    entries = parse_checksums(checksum_path.read_text(encoding="ascii"))
    problems: list[str] = []
    for name, expected in sorted(entries.items()):
        path = package_dir / name
        if not path.is_file():
            problems.append(f"MISSING {name}")
        elif sha256_of(path) != expected:
            problems.append(f"MISMATCH {name}")
    problems.extend(
        f"UNLISTED {name}" for name in sorted(_package_files(package_dir) - set(entries))
    )
    if problems:
        raise PackageError("\n".join(problems))
    return entries


def plan_install(package_dir: Path, entries: dict[str, str], target: Path) -> list[PlannedFile]:
    """List what an install would write.

    :param package_dir: The unpacked package folder
    :param entries: The verified checksum entries
    :param target: The directory to install into
    :return: One item per payload file, in path order
    """
    prefix = f"{PAYLOAD_DIR}/"
    plan: list[PlannedFile] = []
    for name in sorted(entries):
        if not name.startswith(prefix):
            continue
        relative = name[len(prefix) :]
        source = package_dir / name
        plan.append(
            PlannedFile(
                relative=relative,
                source=source,
                size=source.stat().st_size,
                exists=(target / relative).exists(),
            )
        )
    return plan


def target_is_occupied(target: Path) -> bool:
    """Return True when the target exists and holds anything.

    :param target: The install directory
    :return: Whether an install without ``--force`` must be refused
    """
    if target.is_file():
        return True
    return target.is_dir() and any(target.iterdir())


def write_plan(plan: Sequence[PlannedFile], target: Path) -> None:
    """Copy the planned files into the target, then check what was written.

    :param plan: The files to write
    :param target: The install directory
    :raises PackageError: If a written file does not match the package
    """
    for item in plan:
        destination = target / item.relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item.source, destination)
    for item in plan:
        if sha256_of(target / item.relative) != sha256_of(item.source):
            raise PackageError(f"MISMATCH after writing {item.relative}")


def _print_plan(plan: Sequence[PlannedFile], target: Path) -> None:
    for item in plan:
        state = "overwrite" if item.exists else "new"
        sys.stdout.write(f"PLAN {state} {item.relative} ({item.size} bytes)\n")
    total = sum(item.size for item in plan)
    sys.stdout.write(f"PLAN {len(plan)} files, {total} bytes, into {target}\n")


def _print_next_steps(target: Path) -> None:
    sys.stdout.write(
        "\nNext steps:\n"
        f"  cd {target}\n"
        "  python3 -m venv .venv\n"
        "  .venv/bin/pip install -e '.[web,dev]'\n"
        "  .venv/bin/kp demo\n"
        "  scripts/check.sh\n"
        "Then read INSTALL-WORKSTATION.md.\n"
    )


def build_parser() -> argparse.ArgumentParser:
    """Build the command line parser.

    :return: The parser
    """
    parser = argparse.ArgumentParser(
        prog="install.py", description="Install the knowledge platform from this package."
    )
    parser.add_argument(
        "--inspect",
        action="store_true",
        help="verify checksums and list what would be written; write nothing",
    )
    parser.add_argument(
        "--target",
        type=Path,
        default=Path(DEFAULT_TARGET),
        metavar="DIR",
        help=f"directory to install into (default: {DEFAULT_TARGET})",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="install into a target that is not empty (files with the same name are replaced)",
    )
    return parser


def run(package_dir: Path, args: argparse.Namespace) -> int:
    """Verify the package, then inspect or install.

    :param package_dir: The unpacked package folder
    :param args: Parsed arguments from :func:`build_parser`
    :return: The exit status
    """
    try:
        entries = verify_package(package_dir)
    except PackageError as exc:
        sys.stderr.write(f"Package check FAILED:\n{exc}\n")
        return EXIT_BAD_PACKAGE
    sys.stdout.write(f"CHECKSUMS OK ({len(entries)} files verified)\n")
    target: Path = args.target
    plan = plan_install(package_dir, entries, target)
    occupied = target_is_occupied(target)
    if args.inspect:
        _print_plan(plan, target)
        if occupied and not args.force:
            sys.stdout.write("NOTE the target is not empty: an install needs --force\n")
        sys.stdout.write("INSPECT only: nothing was written\n")
        return EXIT_OK
    if occupied and not args.force:
        sys.stderr.write(f"Refused: {target} is not empty. Use another --target, or --force.\n")
        return EXIT_REFUSED
    try:
        write_plan(plan, target)
    except (PackageError, OSError) as exc:
        sys.stderr.write(f"Install FAILED: {exc}\n")
        return EXIT_BAD_PACKAGE
    sys.stdout.write(f"INSTALLED {len(plan)} files into {target}\n")
    _print_next_steps(target)
    return EXIT_OK


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point of ``install.py``.

    :param argv: Arguments without the program name; the process arguments by default
    :return: The exit status
    """
    args = build_parser().parse_args(argv)
    return run(Path(__file__).resolve().parent, args)


if __name__ == "__main__":
    sys.exit(main())
