"""Drawing a page: the shared frame, links that keep the chosen test user, and the filters.

Everything is server-rendered from Jinja2 templates with auto-escaping on. Text from the base
(clauses, stories, questions) is never marked safe.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlencode

from fastapi.templating import Jinja2Templates
from jinja2 import Environment, FileSystemLoader, select_autoescape
from starlette.requests import Request
from starlette.responses import HTMLResponse

from kp.web.errors import Problem
from kp.web.identity import USER_PARAMETER, Viewer

PACKAGE = Path(__file__).resolve().parent
TEMPLATES = PACKAGE / "templates"
STATIC = PACKAGE / "static"

NAVIGATION: tuple[tuple[str, str], ...] = (
    ("Overview", "/"),
    ("Search", "/search"),
    ("Rule", "/rule"),
    ("Impact", "/impact"),
    ("Coverage", "/coverage"),
    ("Specs", "/specs"),
    ("Connectivity", "/connectivity"),
    ("Audit", "/audit"),
)
_PERCENT = 100


class Links:
    """Builds the links of a page so that the chosen test user travels with them.

    :param user: The test user to carry; ``None`` when the identity is not chosen in the UI
    """

    def __init__(self, user: str | None) -> None:
        self._user = user

    def to(self, path: str, **parameters: object) -> str:
        """Build a link.

        :param path: The page path
        :param parameters: Query parameters; empty and ``None`` values are left out
        :return: The path with its query string
        """
        values = {name: str(value) for name, value in parameters.items() if value not in (None, "")}
        if self._user is not None:
            values[USER_PARAMETER] = self._user
        return f"{path}?{urlencode(values)}" if values else path


@dataclass(frozen=True, slots=True)
class Frame:
    """What every page shows around its content.

    :ivar path: The path of the page, for the identity form to return to.
    :ivar carried: The other query parameters of the page, kept when switching user.
    :ivar users: The test users to choose from; empty when the identity is not chosen here.
    """

    title: str
    active: str
    path: str
    viewer: Viewer
    links: Links
    users: tuple[str, ...]
    carried: tuple[tuple[str, str], ...]
    today: date
    navigation: tuple[tuple[str, str], ...] = NAVIGATION

    @property
    def user_parameter(self) -> str:
        """The name of the query parameter that carries the chosen test user."""
        return USER_PARAMETER


def format_moment(value: datetime | None) -> str:
    """Write an instant for a person.

    :param value: A timezone-aware instant
    :return: ``2026-11-20 09:00 UTC``, or a dash for none
    """
    return "-" if value is None else value.strftime("%Y-%m-%d %H:%M UTC")


def format_day(value: date | None) -> str:
    """Write a date for a person.

    :param value: A date
    :return: ``2026-11-20``, or a dash for none
    """
    return "-" if value is None else value.isoformat()


def format_percent(value: float) -> str:
    """Write a share as a whole percentage.

    :param value: A fraction from 0 to 1
    :return: For example ``95%``
    """
    return f"{value * _PERCENT:.0f}%"


def format_number(value: float | None, digits: int = 1) -> str:
    """Write a measurement.

    :param value: The number, or ``None``
    :param digits: Decimal places
    :return: The rounded number, or a dash for none
    """
    return "-" if value is None else f"{value:.{digits}f}"


def format_words(value: str) -> str:
    """Write an identifier such as ``items_have_source`` as a phrase.

    :param value: A snake_case name
    :return: ``Items have source``
    """
    return value.replace("_", " ").capitalize()


def build_templates() -> Jinja2Templates:
    """Load the templates with auto-escaping and the formatting filters.

    :return: The template set
    """
    environment = Environment(
        loader=FileSystemLoader(TEMPLATES),
        autoescape=select_autoescape(["html"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    environment.filters["moment"] = format_moment
    environment.filters["day"] = format_day
    environment.filters["percent"] = format_percent
    environment.filters["number"] = format_number
    environment.filters["words"] = format_words
    return Jinja2Templates(env=environment)


def make_frame(
    request: Request, viewer: Viewer, users: tuple[str, ...], *, title: str, today: date
) -> Frame:
    """Build the frame of one request.

    :param request: The incoming request
    :param viewer: Who is looking
    :param users: The test users to choose from (empty when not chosen in the UI)
    :param title: The page title
    :param today: The date the platform treats as today
    :return: The frame
    """
    carried = tuple(
        (name, value) for name, value in request.query_params.items() if name != USER_PARAMETER
    )
    return Frame(
        title=title,
        active=request.url.path,
        path=request.url.path,
        viewer=viewer,
        links=Links(viewer.user if users else None),
        users=users,
        carried=carried,
        today=today,
    )


def render_page(
    templates: Jinja2Templates,
    request: Request,
    name: str,
    frame: Frame,
    problem: Problem | None,
    context: Mapping[str, object],
) -> HTMLResponse:
    """Draw a page; a problem is served with the status that says what went wrong.

    :param templates: The template set
    :param request: The incoming request
    :param name: The template file
    :param frame: The shared frame
    :param problem: Why the page could not answer, if it could not
    :param context: What the template draws
    :return: The response
    """
    status = problem.status_code if problem is not None else 200
    page = {**context, "frame": frame, "problem": problem}
    return templates.TemplateResponse(request, name, page, status_code=status)
