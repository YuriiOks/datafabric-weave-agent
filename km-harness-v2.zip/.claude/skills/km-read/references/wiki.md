# km-read wiki

Goal: capture the programme design pages of WIKI_SPACE and the six story tickets S1 to S6 in the
kb, so that every story is worked from the written source.
Output: /home/user/km/kb/wiki/ and /home/user/km/kb/stories/. Read actions only: search, get
page, get ticket, get comments. Create, edit, comment, move and transition nothing.

## Step 0: tools and inputs
- Check the tools available in this session for one that reads wiki pages and one that reads
  tickets. Wiki tool missing: do Tickets only and log "no wiki tool". Ticket tool missing: do
  Pages only and log "no ticket tool". Both missing: tell the owner, stop.
  (km-reader has no such tools, so the main session reads, no subagents.)
- kb/private/names.md, when present, gives: the pages of WIKI_SPACE (numbered tree), the ticket
  keys of S1 to S6, the top item key. Without it: ask the owner in one message for the wiki
  space key and the six ticket keys, log them in kb/log.d/RUN.txt, take the page tree from the
  wiki tool, mark every fact Unverified and go on; the top item and the named extra pages are
  skipped and logged. Still no keys: log it and stop.

## Pages
Read one page at a time. Write its kb file before opening the next page. Skip a page whose file
exists. The page list, in this order:
1. The numbered pages of WIKI_SPACE (01 to NN) as named in names.md: kb/wiki/NN-<slug>.md.
2. The page that proposes the architecture of BASE_REPO: kb/wiki/arch-proposal.md.
3. Example solution designs named there: example-design-1.md, example-design-2.md.
4. The knowledge capability lifecycle page: lifecycle.md. The quarterly plan page: plan.md.
5. Platform pages (processing service, agent platform, graph store, data platform) if names.md
   names them or one search finds them: at most 8, kb/wiki/platform-<n>.md.
<slug> is a generic word for the topic (for example overview, roles, storage); no page titles.
Linked pages: at most 5 in total, only for a table that a page refers to.

Each page file has: Title line (the page number or key), Date: <date read>, Status; then
- Source: page number as in names.md, last-edit date if the tool shows it;
- Purpose: 2 to 4 lines;
- Key tables: transcribed in full, cell text as written (Observed);
- Decisions: what the page states as decided; a quote is at most 3 lines (Reported);
- Open questions: items marked draft, to be agreed, or blank;
- Informs: stories among S1 to S6 and one line why.
Notes over 150 lines split into -a and -b. After the last page write kb/wiki/map.md: a table,
one row per page file, one column per story, a dot where it informs; then the three most useful
pages for each story.

## Tickets
For S1 to S6 read the ticket, then its epic. Write kb/stories/s1.md to s6.md, each starting
with a title line and Date:, then:
- Source: ticket key, title, status, assignee role, epic title, sprint, created and updated;
- Description: the ticket text word for word in a quote block, not summarised or shortened;
- Links: cloned-from, cloned-by, blocks, blocked-by, related, parent, each with key and title;
- Added since: comments, sub-tasks, attachments, field changes after creation, with date and
  author role, or "none";
- Epic text: the epic description word for word;
- Gaps: a reference line to the story's part of kb/seed/story-gaps.md, not a copy.
If names.md names a top item: read the other stories under it and write kb/stories/others.md,
one block per story (key, title, owner role, epic, description in a quote block, which of S1 to
S6 it feeds). At most 15 stories.

## Done when
- Every planned page file and map.md exist, each section filled or marked "none".
- s1.md to s6.md exist and each description matches its ticket word for word.
- Every Observed line names a page number or ticket key.
- Run record (index.d, log.d, with the pages and tickets not opened and why) and kb-lint.sh
  PASS as in the method; summary printed.

## Stop
- A page or ticket cannot be opened: log it, go on with the next, list it in the summary.
- Budget per run: at most 12 pages, then the tickets. Stop there, log what is left, and print
  "type /clear, /effort xhigh, then /km-read wiki again" (files that exist are skipped). Over
  all runs: at most 40 pages and 25 tickets.
