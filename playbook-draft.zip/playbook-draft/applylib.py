"""Apply one change package to a clean worktree. Harness file: never committed.

usage: python3 applylib.py <package folder> <worktree root> [--check]

The package folder holds package.json (branch), edits.json (anchored edits to existing
files) and pkg/ (new files). Every anchor must occur exactly once and every new file
must be absent. All of it is checked before anything is written; one problem writes
nothing. A package that is already fully applied is reported as such and left alone.
The script never stages, commits, pushes or runs tests.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def _git(root: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def _diagnose(text: str, old: str) -> list[str]:
    """Show where an anchor nearly matched, so one screen fixes it."""
    report: list[str] = []
    anchor_lines = old.splitlines()
    first = next((line for line in anchor_lines if line.strip()), "")
    report.append(f"    expected first line: {first!r}")
    lines = text.splitlines()
    hits = [number for number, line in enumerate(lines) if first.strip() in line]
    if not hits:
        report.append("    first line not found anywhere")
    for number in hits[:4]:
        report.append(f"    L{number + 1}: {lines[number]!r}")
        offset = anchor_lines.index(first)
        for step, expected in enumerate(anchor_lines[offset:]):
            actual = lines[number + step] if number + step < len(lines) else "<eof>"
            if actual != expected:
                column = next(
                    (i for i, (a, b) in enumerate(zip(actual, expected)) if a != b),
                    min(len(actual), len(expected)),
                )
                report.append(
                    f"      first difference at L{number + step + 1} col {column + 1}: "
                    f"file {actual[column:column + 24]!r} vs anchor "
                    f"{expected[column:column + 24]!r}"
                )
                break
        else:
            report.append("      every anchor line matches here (count problem only)")
    return report


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(__doc__)
        return 2
    folder = Path(argv[0]).resolve()
    root = Path(argv[1]).resolve()
    check_only = "--check" in argv[2:]
    meta = json.loads((folder / "package.json").read_text(encoding="ascii"))
    edits = json.loads((folder / "edits.json").read_text(encoding="ascii"))
    problems: list[str] = []

    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if branch != meta["branch"]:
        problems.append(f"branch is {branch}, expected {meta['branch']}")
    for required in meta.get("requires_files", []):
        if not (root / required).is_file():
            problems.append(f"prerequisite file missing: {required}")

    new_files: list[tuple[Path, bytes]] = []
    present = 0
    for source in sorted((folder / "pkg").rglob("*")):
        if source.is_dir():
            continue
        rel = source.relative_to(folder / "pkg")
        target = root / rel
        data = source.read_bytes()
        if target.exists():
            if target.read_bytes() == data:
                present += 1
                continue
            problems.append(f"new file already exists with other content: {rel}")
        new_files.append((target, data))

    texts: dict[str, str] = {}
    applied = 0
    pending = 0
    for edit in edits:
        rel = edit["path"]
        if rel not in texts:
            path = root / rel
            if not path.is_file():
                problems.append(f"missing file: {rel}")
                texts[rel] = ""
                continue
            texts[rel] = path.read_text(encoding="utf-8")
        text = texts[rel]
        old_count = text.count(edit["old"])
        # An insertion keeps its anchor inside the new text, so "applied" is decided
        # first: the new text is there once, and the anchor survives only inside it.
        if text.count(edit["new"]) == 1 and (
            old_count == 0 or (old_count == 1 and edit["old"] in edit["new"])
        ):
            applied += 1
        elif old_count == 1:
            texts[rel] = text.replace(edit["old"], edit["new"], 1)
            pending += 1
        else:
            problems.append(f"{rel}: anchor found {old_count}x")
            problems.extend(_diagnose(text, edit["old"]))

    if pending == 0 and not new_files and not problems:
        print(f"ALREADY APPLIED: {meta['name']} ({applied} edits, {present} files present)")
        return 0
    if applied or present:
        problems.append(
            f"partly applied before ({applied} edits, {present} files); start from a clean branch"
        )
    if _git(root, "status", "--porcelain"):
        problems.append("worktree is not clean")
    for rel, text in texts.items():
        if rel.endswith(".py") and text:
            try:
                compile(text, rel, "exec")
            except SyntaxError as error:
                problems.append(f"{rel}: edited text does not compile: {error}")

    if problems:
        print(f"NOTHING WRITTEN ({meta['name']}). Problems:")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print(f"OK {meta['name']}: {len(new_files)} new files, {pending} edits in {len(texts)} files")
    if check_only:
        return 0
    for target, data in new_files:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    for rel, text in texts.items():
        (root / rel).write_text(text, encoding="utf-8")
    print("written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
