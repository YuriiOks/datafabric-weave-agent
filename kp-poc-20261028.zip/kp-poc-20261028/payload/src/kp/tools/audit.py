"""Audit trail of tool calls: one ``tool_call`` row per call, refusals included.

The row keeps the agent's arguments (the audited fact) plus a digest. It is never written to
logs. A merged spec's trail is found from the spec alone: calls tagged with the spec, plus the
untagged calls of every session in which a call was tagged with it.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Protocol

from pydantic import JsonValue
from sqlalchemy import Connection, insert, or_, select
from sqlalchemy.engine import Row

from kp.domain import ToolCallRecord
from kp.store import Database
from kp.store.schema import tool_call

_MAX_KEY_LENGTH = 255
MAX_REFUSED_REQUEST_CHARS = 2_048


def request_digest(arguments: Mapping[str, JsonValue]) -> str:
    """Hash the arguments of a call in a canonical form.

    :param arguments: The arguments exactly as the agent sent them
    :return: Lowercase hex SHA-256 of the key-sorted, ASCII-only JSON
    """
    canonical = json.dumps(arguments, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("ascii")).hexdigest()


def clip_request(arguments: Mapping[str, JsonValue]) -> dict[str, JsonValue]:
    """Keep the arguments of an unauthenticated or refused call short enough to store.

    :param arguments: The raw arguments
    :return: The arguments when they fit in 2 KiB as JSON; otherwise a note and their start
    """
    text = json.dumps(arguments, sort_keys=True, default=str)
    if len(text) <= MAX_REFUSED_REQUEST_CHARS:
        return dict(arguments)
    return {"clipped": text[:MAX_REFUSED_REQUEST_CHARS], "original_chars": len(text)}


def clip_key(value: str) -> str:
    """Cut a caller-supplied label to the width of the audit key columns.

    :param value: A tool name or other label chosen by the caller
    :return: ``value`` limited to 255 characters
    """
    return value[:_MAX_KEY_LENGTH]


class AuditSink(Protocol):
    """Where tool call records go."""

    def record(self, record: ToolCallRecord) -> None:
        """Persist one record.

        :param record: The call to record
        """
        ...


class AuditStore:
    """Reads and writes ``tool_call`` rows on one connection.

    :param connection: A connection inside a transaction owned by the caller
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def record(self, record: ToolCallRecord) -> None:
        """Insert one record. Rows are append-only; an existing ``call_id`` is an error.

        :param record: The call to record
        """
        values = record.model_dump(mode="json")
        values["domains_applied"] = list(record.domains_applied)
        values["called_at"] = record.called_at
        self._connection.execute(insert(tool_call).values(**values))

    def list_for_session(self, session_id: str) -> list[ToolCallRecord]:
        """List the calls of one session, oldest first.

        :param session_id: The session identifier
        :return: The records in call order
        """
        statement = (
            select(tool_call)
            .where(tool_call.c.session_id == session_id)
            .order_by(tool_call.c.called_at, tool_call.c.call_id)
        )
        return [_to_record(row) for row in self._connection.execute(statement)]

    def list_for_spec(self, spec_id: str) -> list[ToolCallRecord]:
        """List every call behind a spec, oldest first.

        Includes calls tagged with ``spec_id`` and the untagged calls of each session that has
        at least one call tagged with it. Calls tagged with another spec are excluded.

        :param spec_id: The spec identifier
        :return: The records in call order
        """
        sessions = select(tool_call.c.session_id).where(tool_call.c.spec_id == spec_id)
        statement = (
            select(tool_call)
            .where(
                or_(
                    tool_call.c.spec_id == spec_id,
                    (tool_call.c.spec_id.is_(None)) & tool_call.c.session_id.in_(sessions),
                )
            )
            .order_by(tool_call.c.called_at, tool_call.c.call_id)
        )
        return [_to_record(row) for row in self._connection.execute(statement)]


def _to_record(row: Row[tuple[object, ...]]) -> ToolCallRecord:
    values = dict(row._mapping)
    values["domains_applied"] = tuple(values["domains_applied"])
    return ToolCallRecord.model_validate(values)


class DatabaseAuditSink:
    """An :class:`AuditSink` that writes each record in its own transaction.

    :param database: The database holding the ``tool_call`` table
    """

    def __init__(self, database: Database) -> None:
        self._database = database

    def record(self, record: ToolCallRecord) -> None:
        """Persist one record and commit.

        :param record: The call to record
        """
        with self._database.transaction() as connection:
            AuditStore(connection).record(record)
