"""JSON-RPC 2.0 messages and the error codes of this server."""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import IntEnum

from pydantic import JsonValue

JSONRPC_VERSION = "2.0"
RequestId = str | int
Message = dict[str, JsonValue]


class ErrorCode(IntEnum):
    """JSON-RPC standard codes, and application codes in the implementation-defined range."""

    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    TOOL_FAILED = -32000
    FORBIDDEN = -32010
    NOT_FOUND = -32011
    UNAVAILABLE = -32012
    WRITE_NOT_PERMITTED = -32013
    AUDIT_FAILED = -32014


class JsonRpcError(Exception):
    """A failure that becomes a JSON-RPC error response.

    :param code: The error code
    :param message: A short message safe to show to the agent
    :param kind: A stable machine-readable label placed in ``error.data.kind``
    """

    def __init__(self, code: ErrorCode, message: str, kind: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.kind = kind


@dataclass(frozen=True, slots=True)
class Request:
    """A validated request or notification.

    :ivar request_id: The id to answer with; ``None`` for a notification.
    :ivar method: The method name.
    :ivar params: The parameters; empty when absent.
    """

    request_id: RequestId | None
    method: str
    params: dict[str, JsonValue]

    @property
    def is_notification(self) -> bool:
        """True when no response is expected."""
        return self.request_id is None


def decode(text: str) -> JsonValue:
    """Parse one JSON text.

    :param text: The raw message
    :return: The parsed value
    :raises JsonRpcError: With ``PARSE_ERROR`` if ``text`` is not valid JSON or nests too deeply
    """
    try:
        decoded: JsonValue = json.loads(text)
    except (ValueError, RecursionError) as exc:
        raise JsonRpcError(ErrorCode.PARSE_ERROR, "The message is not valid JSON") from exc
    return decoded


def parse_request(message: JsonValue) -> Request | None:
    """Validate an incoming message.

    :param message: A decoded JSON value
    :return: The request, or ``None`` for a response object sent by the peer (ignored)
    :raises JsonRpcError: With ``INVALID_REQUEST`` if it is not a valid request
    """
    if not isinstance(message, dict):
        raise JsonRpcError(ErrorCode.INVALID_REQUEST, "A message must be a JSON object")
    if message.get("jsonrpc") != JSONRPC_VERSION:
        raise JsonRpcError(ErrorCode.INVALID_REQUEST, 'The "jsonrpc" member must be "2.0"')
    if "method" not in message:
        if "result" in message or "error" in message:
            return None
        raise JsonRpcError(ErrorCode.INVALID_REQUEST, 'The "method" member is required')
    method = message["method"]
    if not isinstance(method, str) or not method:
        raise JsonRpcError(ErrorCode.INVALID_REQUEST, "The method must be a non-empty string")
    params = message.get("params", {})
    if not isinstance(params, dict):
        raise JsonRpcError(ErrorCode.INVALID_PARAMS, "The params must be an object")
    if "id" not in message:
        return Request(None, method, params)
    request_id = message["id"]
    if isinstance(request_id, bool) or not isinstance(request_id, str | int):
        raise JsonRpcError(ErrorCode.INVALID_REQUEST, "The id must be a string or an integer")
    return Request(request_id, method, params)


def result_response(request_id: RequestId, result: JsonValue) -> Message:
    """Build a success response.

    :param request_id: The id of the request
    :param result: The result value
    :return: The response object
    """
    return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "result": result}


def error_response(request_id: RequestId | None, error: JsonRpcError) -> Message:
    """Build an error response.

    :param request_id: The id of the request, or ``None`` when it could not be read
    :param error: The failure
    :return: The response object
    """
    body: dict[str, JsonValue] = {"code": int(error.code), "message": error.message}
    if error.kind is not None:
        body["data"] = {"kind": error.kind}
    return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "error": body}


def encode(message: Message) -> str:
    """Serialise a message to a single line.

    :param message: The message
    :return: Compact JSON without a newline
    """
    return json.dumps(message, separators=(",", ":"), ensure_ascii=True)
