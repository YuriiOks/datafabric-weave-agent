"""IngestProcessor: admitted item versions become stored clauses, requirements and stories."""

from __future__ import annotations

import io
from datetime import date

import pytest
from openpyxl import load_workbook
from sqlalchemy import Connection, Engine, Table, func, select, update

from ingest.ingest_support import XLSX, FetchFactory, ItemFactory, store_item
from kp.clock import FixedClock
from kp.config import Thresholds
from kp.domain import ApprovalState, ReviewKind, ReviewState, SourceKind
from kp.ingest import (
    ClauseStore,
    EditionConflictError,
    IngestProcessor,
    MissingEffectiveDateError,
    ProcessingOutcome,
    RequirementStore,
    ReviewStore,
)
from kp.store import Database
from kp.store.schema import clause, edition, requirement, review_item, story
from kp.testing.dataset import SyntheticDataset


def _count(connection: Connection, table: Table) -> int:
    return connection.execute(select(func.count()).select_from(table)).scalar_one()


@pytest.fixture
def processor(thresholds: Thresholds, fixed_clock: FixedClock) -> IngestProcessor:
    return IngestProcessor(thresholds, fixed_clock)


def _rulebook_markdown(dataset: SyntheticDataset, label: str = "2026.1") -> str:
    return dataset.path(dataset.truth.edition(label).markdown_path).read_text(encoding="utf-8")


@pytest.mark.parametrize("label", ["2025.2", "2026.1"])
def test_us07_pdf_edition_is_stored_as_referenced_clauses(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
    label: str,
) -> None:
    truth = dataset.truth.edition(label)
    item = make_item(version=label)
    content = dataset.path(truth.pdf_path).read_bytes()
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, content), connection)
        assert result.outcome is ProcessingOutcome.PROCESSED
        assert result.clauses_stored == truth.toc_clause_count
        stored = ClauseStore(connection).list_for_edition(label)
        assert [c.ref.number for c in stored] == [c.number for c in truth.clauses]
        assert _count(connection, edition) == 1


def test_us07_second_run_over_the_same_version_adds_nothing(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    item = make_item(version="2026.1", media_type="text/markdown")
    content = _rulebook_markdown(dataset).encode()
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        first = processor.process(item, fetched(item, content), connection)
        again = processor.process(item, fetched(item, content), connection)
        assert first.clauses_stored > 0
        assert again.outcome is ProcessingOutcome.PROCESSED
        assert again.clauses_stored == 0
        assert _count(connection, clause) == first.clauses_stored


def test_us07_two_editions_coexist_with_distinct_references(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    with Database(engine).transaction() as connection:
        for label, effective in (("2025.2", date(2025, 6, 2)), ("2026.1", date(2026, 11, 16))):
            item = make_item(version=label, effective_date=effective)
            store_item(connection, item)
            content = dataset.path(dataset.truth.edition(label).pdf_path).read_bytes()
            processor.process(item, fetched(item, content), connection)
        store = ClauseStore(connection)
        old = {c.ref.number: c for c in store.list_for_edition("2025.2")}
        new = {c.ref.number: c for c in store.list_for_edition("2026.1")}
        assert "euro only" in old["4.2.1"].text
        assert "pounds sterling" in new["4.2.1"].text
        assert "4.2.4" not in old
        assert "4.2.4" in new


def test_us07_effective_date_falls_back_to_the_date_in_the_document(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    item = make_item(version="2026.1", media_type="text/markdown", effective_date=None)
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        processor.process(item, fetched(item, _rulebook_markdown(dataset).encode()), connection)
        found = connection.execute(select(edition.c.effective_date)).scalar_one()
        assert found == date(2026, 11, 16)


def test_us07_edition_without_any_effective_date_is_an_error(
    engine: Engine,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    source = "## Contents\n\n- 1 Scope ... 1\n\n### 1 Scope\n\nText.\n"
    item = make_item(version="9.9", media_type="text/markdown", effective_date=None)
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        with pytest.raises(MissingEffectiveDateError):
            processor.process(item, fetched(item, source.encode()), connection)


def test_us07_toc_mismatch_holds_the_edition_for_review(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    source = _rulebook_markdown(dataset).replace("- 4.2.4 Reference format ... 4\n", "")
    item = make_item(version="2026.1", media_type="text/markdown")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, source.encode()), connection)
        assert result.outcome is ProcessingOutcome.HELD_FOR_REVIEW
        assert result.clauses_stored == 0
        assert _count(connection, clause) == 0
        assert _count(connection, edition) == 0
        (review,) = ReviewStore(connection).list_open()
        assert review.kind is ReviewKind.LOW_STRUCTURE_SCORE
        assert review.review_id in result.review_ids
        assert (review.item_id, review.version) == ("item-1", "2026.1")
        assert "4.2.4" in review.detail
        again = processor.process(item, fetched(item, source.encode()), connection)
        assert again.review_ids == ()
        assert len(ReviewStore(connection).list_open()) == 1


def test_us07_document_stating_another_edition_than_its_item_is_held_and_stores_nothing(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    # The item was reviewed as edition 2026.1; the text still says 2025.2.
    source = _rulebook_markdown(dataset).replace("Edition: 2026.1", "Edition: 2025.2")
    assert "Edition: 2025.2" in source
    item = make_item(version="2026.1", media_type="text/markdown")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, source.encode()), connection)
        assert result.outcome is ProcessingOutcome.HELD_FOR_REVIEW
        assert result.clauses_stored == 0
        assert _count(connection, clause) == _count(connection, edition) == 0
        (review,) = ReviewStore(connection).list_open()
        assert review.kind is ReviewKind.LOW_STRUCTURE_SCORE
        assert "2025.2" in review.detail
        assert "2026.1" in review.detail


def test_us07_edition_label_already_held_by_another_item_is_an_error_not_a_silent_skip(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    content = _rulebook_markdown(dataset).encode()
    first = make_item(item_id="item-1", version="2026.1", media_type="text/markdown")
    copy = make_item(item_id="item-2", version="2026.1", media_type="text/markdown")
    with Database(engine).transaction() as connection:
        store_item(connection, first)
        store_item(connection, copy)
        assert processor.process(first, fetched(first, content), connection).clauses_stored > 0
        with pytest.raises(EditionConflictError):
            processor.process(copy, fetched(copy, content), connection)


def test_us07_review_band_is_loaded_once_that_review_item_is_resolved(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    source = _rulebook_markdown(dataset).replace("- 4.2.4 Reference format ... 4\n", "")
    item = make_item(version="2026.1", media_type="text/markdown")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        held = processor.process(item, fetched(item, source.encode()), connection)
        assert held.outcome is ProcessingOutcome.HELD_FOR_REVIEW
        (review_id,) = held.review_ids
        again = processor.process(item, fetched(item, source.encode()), connection)
        assert again.outcome is ProcessingOutcome.HELD_FOR_REVIEW
        assert _count(connection, clause) == 0
        connection.execute(
            update(review_item)
            .where(review_item.c.review_id == review_id)
            .values(state=ReviewState.RESOLVED.value)
        )
        released = processor.process(item, fetched(item, source.encode()), connection)
        assert released.outcome is ProcessingOutcome.PROCESSED
        assert released.clauses_stored == dataset.truth.edition("2026.1").toc_clause_count


def test_us07_review_band_is_stored_once_a_person_accepts_it(
    engine: Engine,
    dataset: SyntheticDataset,
    thresholds: Thresholds,
    fixed_clock: FixedClock,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    source = _rulebook_markdown(dataset).replace("- 4.2.4 Reference format ... 4\n", "")
    item = make_item(version="2026.1", media_type="text/markdown")
    accepting = IngestProcessor(thresholds, fixed_clock, accept_review_band=True)
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = accepting.process(item, fetched(item, source.encode()), connection)
        assert result.outcome is ProcessingOutcome.PROCESSED
        assert result.clauses_stored == dataset.truth.edition("2026.1").toc_clause_count


def test_us07_scrambled_structure_is_blocked_even_when_review_is_accepted(
    engine: Engine,
    thresholds: Thresholds,
    fixed_clock: FixedClock,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    source = (
        "Edition: 1.0\n\n## Contents\n\n- 1 A ... 1\n- 2 B ... 1\n- 3 C ... 1\n\n"
        "### 1 A\n\nText.\n\n### 7 B\n\nText.\n\n### 3 C\n\nText.\n"
    )
    item = make_item(version="1.0", media_type="text/markdown")
    accepting = IngestProcessor(thresholds, fixed_clock, accept_review_band=True)
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = accepting.process(item, fetched(item, source.encode()), connection)
        assert result.outcome is ProcessingOutcome.BLOCKED
        assert _count(connection, clause) == 0
        assert len(result.review_ids) == 1


def test_us06_register_rows_become_requirements_and_the_headerless_sheet_is_raised(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    truth = dataset.truth.requirements_register
    item = make_item(
        item_id="register-1",
        source=SourceKind.DOCUMENT_LIBRARY,
        media_type=XLSX,
        effective_date=None,
    )
    content = dataset.path(truth.path).read_bytes()
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, content), connection)
        assert result.outcome is ProcessingOutcome.PROCESSED
        assert result.requirements_stored == truth.data_row_count
        assert _count(connection, requirement) == truth.data_row_count
        (review,) = ReviewStore(connection).list_open()
        assert review.kind is ReviewKind.REGISTER_HEADER
        assert truth.headerless_sheet in review.detail
        assert review.candidates
        assert all(candidate.isdigit() for candidate in review.candidates)
        again = processor.process(item, fetched(item, content), connection)
        assert again.requirements_stored == 0
        assert again.review_ids == ()
        stored = RequirementStore(connection).list_for_item(item.key)
        assert len(stored) == truth.data_row_count


def test_us06_newer_register_version_that_is_refused_keeps_the_serving_rows(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    truth = dataset.truth.requirements_register
    workbook = load_workbook(dataset.path(truth.path))
    del workbook[truth.main_sheet]
    workbook[truth.headerless_sheet].title = truth.main_sheet  # the header is lost in v2
    out = io.BytesIO()
    workbook.save(out)
    kwargs = {"item_id": "register-1", "source": SourceKind.DOCUMENT_LIBRARY, "media_type": XLSX}
    old = make_item(version="1", **kwargs)
    new = make_item(version="2", **kwargs)
    with Database(engine).transaction() as connection:
        store_item(connection, old)
        store_item(connection, new)
        processor.process(old, fetched(old, dataset.path(truth.path).read_bytes()), connection)
        before = RequirementStore(connection).list_for_item(old.key)
        held = processor.process(new, fetched(new, out.getvalue()), connection)
        assert held.outcome is ProcessingOutcome.HELD_FOR_REVIEW
        assert held.requirements_stored == 0
        assert RequirementStore(connection).list_for_item(new.key) == before
        assert {row.version for row in before} == {"1"}


def test_us06_workbook_with_only_refused_sheets_is_held(
    engine: Engine,
    dataset: SyntheticDataset,
    thresholds: Thresholds,
    fixed_clock: FixedClock,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    path = dataset.path(dataset.truth.requirements_register.path)
    workbook = load_workbook(path)
    del workbook[dataset.truth.requirements_register.main_sheet]
    out = io.BytesIO()
    workbook.save(out)
    item = make_item(item_id="notes-only", source=SourceKind.GITHUB, media_type=XLSX)
    processor = IngestProcessor(thresholds, fixed_clock)
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, out.getvalue()), connection)
        assert result.outcome is ProcessingOutcome.HELD_FOR_REVIEW
        assert result.requirements_stored == 0
        assert len(result.review_ids) == 1


def test_us05_first_export_stores_every_story_as_new(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    truth = dataset.truth.stories
    item = make_item(
        item_id="export-1",
        source=SourceKind.JIRA,
        media_type="application/json",
        effective_date=None,
    )
    content = dataset.path(truth.first_export).read_bytes()
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, content), connection)
        assert result.outcome is ProcessingOutcome.PROCESSED
        assert len(result.stories_new) == len(result.stories_to_reprocess) == truth.story_count
        assert _count(connection, story) == truth.story_count


def test_us05_status_move_causes_no_rework_and_a_criteria_change_only_that_story(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    truth = dataset.truth.stories
    first = make_item(item_id="export-1", source=SourceKind.JIRA, media_type="application/json")
    second = make_item(item_id="export-2", source=SourceKind.JIRA, media_type="application/json")
    with Database(engine).transaction() as connection:
        store_item(connection, first)
        store_item(connection, second)
        processor.process(
            first, fetched(first, dataset.path(truth.first_export).read_bytes()), connection
        )
        result = processor.process(
            second, fetched(second, dataset.path(truth.second_export).read_bytes()), connection
        )
        assert result.stories_changed == (truth.criteria_changed_key,)
        assert result.stories_new == ()
        assert result.stories_to_reprocess == (truth.criteria_changed_key,)
        assert truth.status_only_key in result.stories_unchanged
        assert len(result.stories_unchanged) == truth.story_count - 1
        again = processor.process(
            second, fetched(second, dataset.path(truth.second_export).read_bytes()), connection
        )
        assert again.stories_to_reprocess == ()


def test_us05_story_without_a_domain_label_takes_the_items_domain(
    engine: Engine,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    item = make_item(item_id="issue-1", source=SourceKind.JIRA, media_type="application/json")
    content = b'{"key": "PAY-9", "fields": {"summary": "A story", "updated": "v1"}}'
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        processor.process(item, fetched(item, content), connection)
        assert connection.execute(select(story.c.domain)).scalar_one() == "payments"


def test_us07_items_that_are_not_admitted_are_left_alone(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    item = make_item(
        version="2026.1", media_type="text/markdown", approval_state=ApprovalState.PENDING
    )
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(
            item, fetched(item, _rulebook_markdown(dataset).encode()), connection
        )
        assert result.outcome is ProcessingOutcome.NOT_ADMITTED
        assert _count(connection, clause) == 0


@pytest.mark.parametrize(
    ("source", "media_type"),
    [
        (SourceKind.DOCUMENT_LIBRARY, "text/markdown"),
        (SourceKind.CONFLUENCE, "application/json"),
        (SourceKind.GITHUB, "text/x-python"),
    ],
)
def test_us03_content_without_a_parser_is_not_applicable_and_not_guessed(
    engine: Engine,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
    source: SourceKind,
    media_type: str,
) -> None:
    item = make_item(item_id="other", source=source, media_type=media_type)
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(item, fetched(item, b"anything"), connection)
        assert result.outcome is ProcessingOutcome.NOT_APPLICABLE
        assert _count(connection, clause) == _count(connection, requirement) == 0


def test_us07_media_type_parameters_are_ignored_when_choosing_a_parser(
    engine: Engine,
    dataset: SyntheticDataset,
    processor: IngestProcessor,
    make_item: ItemFactory,
    fetched: FetchFactory,
) -> None:
    item = make_item(version="2026.1", media_type="Text/Markdown; charset=utf-8")
    with Database(engine).transaction() as connection:
        store_item(connection, item)
        result = processor.process(
            item, fetched(item, _rulebook_markdown(dataset).encode()), connection
        )
        assert result.outcome is ProcessingOutcome.PROCESSED
