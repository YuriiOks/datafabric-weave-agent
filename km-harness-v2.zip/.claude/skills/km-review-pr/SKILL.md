---
name: km-review-pr
description: Use to review someone else's pull request, read-only, and draft the comments for the owner. Argument is the number, an optional clone folder, and the word again for a later look.
argument-hint: <number> [clone] [again]
disable-model-invocation: true
effort: high
---

# km-review-pr

Arguments: $ARGUMENTS. $0 is the pull request number (digits), else print
"usage: /km-review-pr <number> [clone] [again]" and stop. Later words: `again`, and a clone
folder name in /home/user/km. No clone given: try BASE_REPO and CAPTURE_REPO, each with
`(cd /home/user/km/<clone> && gh pr view $0 --json number,title)` (a subshell, so the session
stays where it is). One answers: that is the clone. Both answer: print both titles, ask which,
stop. None: stop. Use absolute paths everywhere. First command: `mkdir -p
/home/user/km/work/reviews`. Conventions folder follows the clone: kb/conventions/ for
BASE_REPO, kb/conventions/capture/ for CAPTURE_REPO. Name: pr-$0.
Depth: read the code, not only the diff. The result is a draft file for the owner. Nothing
is ever posted: no gh pr review, gh pr comment, gh api write, gh pr checkout, merge, label
or ticket change; the owner posts, after his word. If the pull request is the
owner's own, say so and still review.

## 1 Fetch (read-only)
- Metadata: `(cd /home/user/km/<clone> && gh pr view $0 --json
  title,body,baseRefName,headRefName,headRefOid,files,commits)`. Closed or merged: say so,
  go on.
- Whole tree for the reviewers: `git -C <clone> fetch origin pull/$0/head`, then
  `git -C <clone> rev-parse FETCH_HEAD` and record that sha (the head sha). Different from
  headRefOid: the fetch is stale, say so and fetch once more. Then
  `git -C <clone> worktree add --detach /home/user/km/work/wt/pr-$0 <sha>`. If the work tree
  exists: `git -C /home/user/km/work/wt/pr-$0 checkout --detach <sha>`. Never use FETCH_HEAD
  inside the work tree. Never touch the main checkout of the clone.
- Diff, built locally (gh pr diff fails on very large diffs; gh is for metadata only):
  `git -C <clone> fetch origin <baseRefName>` then
  `git -C <clone> diff origin/<baseRefName>...<sha> > /home/user/km/work/reviews/pr-$0.diff`.
- Read the title and body: what the change claims to do. Check the claim against the diff.

## 1b Evidence pass (before any judgment)
Collect with read-only commands and record in the draft under "Evidence":
- Final head sha (the one fetched above) and whether the author pushed since you started.
- Checks for that exact head: `gh pr checks $0` or `gh pr view $0 --json
  statusCheckRollup`. Say "head <short sha>: N of M reported, K success". Tell apart never
  triggered, failed and reported nothing. A clean merge state is not test evidence. A red
  check is a finding only with a quoted log line.
- Open review threads and earlier comments (`gh pr view $0 --json reviews,comments`; a
  read-only `gh api graphql` query for threads if needed). Count the unresolved ones.
- Ticket wording: from the body. The ticket text itself is not readable here; ask the owner
  to paste it if the verdict depends on it, else mark acceptance as Unverified.
- File account: every changed file listed N of N with how it was read (in full, hunks,
  generated or lock file skipped). A file not accounted for is named in "Could not verify".
- Split every claim: "the author reports ..." (from the body or commits) apart from
  "re-checked here ..." (seen in code or command output at this head). Never merge them.

## 2 First review (no again)
- Draft exists: print "draft exists, use again or delete it", stop.
- Run levels 3 and 4 as in /home/user/km/.claude/skills/km-code-review/references/routing.md
  with name pr-$0 and tag p1: layer map, 2 to 4 reviewers, at most 3 subagents at once,
  skeptic, spot-check. There is no plan: tell reviewers the intent is the title and body.
  One round only.

## 3 Again
- Needs work/reviews/pr-$0.md, else print "no earlier draft, run without again", stop.
- Parse every section of the draft, not only the latest: comments by global number (C1, C2,
  ...), place, text, and the earlier table rows. The open set is every comment not marked
  fixed. Fetch the new head as in section 1. Same head sha as the draft records: print
  "no new commits", stop.
- Skeptic in again mode, with the earlier comments: fixed, partly or not addressed, from the
  current code only. A resolved mark, a reply or a commit message is not evidence.
- Fresh look at the new changes: `git -C <wt> diff <old sha>..HEAD`, files changed since,
  route and review them with tag p2. Old sha unknown to git (history was rewritten): use the
  whole diff and say so.

## 4 Draft: work/reviews/pr-$0.md
First review creates it. Again puts a new section at the top and keeps older ones below.
Per section: heading with date and head sha, base branch, clone, files reviewed.
- Verdict, one line: ready to merge, ready with changes, or changes needed (a blocker is
  proven). The owner chooses the real review state.
- Summary: two or three plain sentences, what the change does and the main point.
Section order in the draft: Verdict, Summary, Evidence, (again only: earlier-comments
table), Comments, Questions for the author, Could not verify last.
- Comments, at most 10, blockers first, then should-fix, question, nit. Merge or drop the
  rest and say how many were held back. Each one a short entry:
  `C<n>. path:line (severity)` (numbered globally across sections, continuing from the highest
  earlier number) then the problem in one or two plain sentences, then
  `Suggestion:` a concrete change. Line numbers are of the new version. Written to be
  pasted as an inline comment. Voice, anatomy (quote, why, fix), strip list and the four
  checks: read /home/user/km/.claude/skills/km-code-review/references/comment-voice.md
  before writing, and apply the four checks to every comment.
- Evidence: the section from 1b, placed after the Summary.
- Again only: a table of earlier comments: number, place, fixed, partly or not addressed,
  one line why. Fixed ones are not repeated as comments. Not addressed and partly addressed
  ones are listed again as comments under their original numbers.
- Could not verify: what no reviewer could verify. Layer map or conventions missing: say so.
- Questions for the author: at most 2, only if the answer changes the verdict.

## 5 Finish
- Write kb/log.d/<run>.txt, run id km-review-pr-$0-<date>: date, pull request, head sha,
  mode, verdict, comment count, what was skipped and why. No index.d entry.
- Print at most 8 lines: draft path, verdict, comment counts by severity, the blockers in
  one line each, and "nothing was posted". The owner decides what to post.
