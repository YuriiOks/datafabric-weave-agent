"""The web application: build it from an assembled platform with :func:`create_app`."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable

from fastapi import FastAPI
from starlette.requests import Request
from starlette.responses import PlainTextResponse, Response
from starlette.staticfiles import StaticFiles

from kp.app import Application
from kp.config import Settings
from kp.web.pages import Pages
from kp.web.render import STATIC, build_templates
from kp.web.settings import WebSettings, load_web_settings
from kp.web.state import WebState, build_identity

logger = logging.getLogger(__name__)

# Everything is served from this origin: no scripts, no fonts, no images from elsewhere.
_STATIC_PREFIX = "/static/"
_SECURITY_HEADERS = {
    "Content-Security-Policy": "default-src 'none'; style-src 'self'; form-action 'self'; "
    "base-uri 'none'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
}


def create_app(
    application: Application,
    *,
    settings: WebSettings | None = None,
    connectivity: Settings | None = None,
    loopback_only: bool = True,
) -> FastAPI:
    """Build the web application.

    The pages read only through the application's services and the read tools. In local mode
    the application needs an identity mapping file (``KP_IDENTITY_MAPPING_FILE``) for the
    test-user selector; in real mode the identity comes from one request header.

    :param application: The assembled platform; the caller owns it and closes it
    :param settings: Web settings; read from the ``KP_WEB_`` environment when omitted
    :param connectivity: Settings of the database and data folder the connectivity job used,
        when that is not the platform's own
    :param loopback_only: False when the server listens beyond this machine; the local-mode
        selector then signs nobody in until a user is chosen, instead of the widest user
    :return: The ASGI application
    :raises kp.errors.ConfigurationError: If the identity mapping or a web setting is unusable
    """
    web_settings = settings or load_web_settings()
    directory = application.identity_mapping()
    state = WebState(
        application=application,
        settings=web_settings,
        identity=build_identity(application, web_settings, directory, loopback_only=loopback_only),
        directory=directory,
        connectivity=connectivity,
    )
    # The interactive documentation pages load scripts from elsewhere, so they stay off.
    app = FastAPI(title="Knowledge platform", docs_url=None, redoc_url=None, openapi_url=None)
    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    Pages(state, build_templates()).register(app)

    @app.middleware("http")
    async def protect(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        try:
            response = await call_next(request)
        except Exception as exc:
            # Never the message or the arguments: they may echo what was asked.
            logger.error("Request failed", extra={"error_class": type(exc).__name__})
            response = PlainTextResponse("The request could not be completed.", status_code=500)
        for name, value in _SECURITY_HEADERS.items():
            response.headers[name] = value
        if not request.url.path.startswith(_STATIC_PREFIX):
            # A page differs per user; a shared cache must never serve one user's page to another.
            response.headers["Cache-Control"] = "no-store"
            response.headers["Vary"] = web_settings.identity_header
        return response

    return app
