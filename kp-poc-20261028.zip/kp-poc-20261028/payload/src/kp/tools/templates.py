"""The ``template`` tool: the governed template for a spec type, or an error."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from kp.domain import DomainModel
from kp.errors import TemplateNotFoundError
from kp.tools.access import ToolContext
from kp.tools.ports import TemplatePort
from kp.tools.registry import RegisteredTool, ToolArguments, ToolOutcome, define_tool

NAME = "template"


class TemplateArguments(ToolArguments):
    """Arguments of ``template``."""

    spec_type: Annotated[
        str, Field(min_length=1, max_length=64, description="Kind of spec, e.g. functional")
    ]
    version: Annotated[
        str | None, Field(max_length=64, description="A specific version; default is the latest")
    ] = None


class TemplateOutput(DomainModel):
    """The ``template`` result."""

    template_id: str
    version: str
    spec_type: str
    body: str
    content_sha256: str


def template_tool(templates: TemplatePort) -> RegisteredTool:
    """Build the ``template`` tool.

    :param templates: Governed templates
    :return: The registrable tool
    """

    def handle(context: ToolContext, arguments: TemplateArguments) -> ToolOutcome:  # noqa: ARG001
        template = templates.get(arguments.spec_type, arguments.version)
        if template is None:
            raise TemplateNotFoundError(
                f"No governed template exists for spec type {arguments.spec_type!r}"
                + (f" version {arguments.version!r}" if arguments.version else "")
            )
        output = TemplateOutput(
            template_id=template.template_id,
            version=template.version,
            spec_type=template.spec_type,
            body=template.body,
            content_sha256=template.content_sha256,
        )
        return ToolOutcome(payload=output.model_dump(mode="json"), items_returned=1)

    return define_tool(
        NAME,
        "Fetch the governed template for a spec type, with its version. There is no fallback: "
        "when no template is governed for the type the call fails.",
        TemplateArguments,
        handle,
    )
