# Glossary

These are target-model terms, not a description of what exists. Whether the existing
application has any of them is a question for kb/base. Until a run answers it, any claim that it
does is Reported. Roles, not people, are named. One line per term.

## Model terms
- Domain: the top level of the knowledge hierarchy. It has an owner.
- Sub-domain: a child of a domain. It has its own owner and inherits from its domain.
- Namespace: an isolated space for graphs, sources and files. Each namespace is to be audited.
- Knowledge product: a published bundle of knowledge with purpose, scope, owners and quality.
- Knowledge asset: a source item a product is built from, such as a document or a table.
- Platform admin: the role with rights across every domain.
- Domain owner: the role that owns a domain and sets delegate access.
- Delegate: a person who holds rights that an owner granted. A delegate cannot grant more.
- Steward: the role that approves a product before it is published.
- Producer: the role that starts a product and reviews extraction results.
- Consumer: a person or agent that reads published products.
- Scope: the part of the hierarchy a grant applies to.
- Grant: one record that gives a person or group a set of actions on a scope.
- Role-action-scope matrix: the table of who may do what where. The output of S4.
- Maker-checker: the rule that the approver must differ from the author.
- Lifecycle status: draft, in review, awaiting approval, approved, published, retired.
- Immutable version: a published version that is never edited. An edit creates a new version.
- Ontology: a model of entity types, attributes and relationships.
- Foundational ontology: the shared base ontology that other ontologies extend.
- Entity: a thing the text talks about, such as a system, a team or a term.
- Relationship: a typed link between two entities, with evidence.
- Evidence: the exact source text that supports a claim, with its location.
- Mention: one occurrence of an entity in the text, with a span.
- Provenance: the record of where a value or object came from.
- Lineage: the chain from source to ingested object to graph node.
- Assertion: one claim with a value, a source and a fingerprint, stored before the graph load.
- Fingerprint: a hash used to detect the same item or claim again.
- Deduplication: merging records that describe the same entity.
- Review queue: the list of machine proposals waiting for a person.
- Quality gate: a check that can block a move to the next status.
- Not measured: the result of a check that had no data. It is never counted as passed.
- Connector: an adapter that reads from one kind of source.
- Staging area: a holding place for uploads until checks pass.
- Row-level policy: a database rule that hides rows outside the caller's scope.
- Tool server: a service that offers published knowledge to agents as callable tools.
- Fail closed: when a check cannot run, the action is refused.
- Append-only: records can be added but never changed or removed.

## Evidence labels
Every fact in the kb or a design has one. Code wins over documents.
- Observed: read in a named file or page during this run, with path:line or page.
- Reported: said by a person or a document, not confirmed in code. A document's statement
  about behaviour stays Reported until code confirms it.
- Proposed: a design, plan or criterion that is not in effect. Design documents are Proposed.
- Unverified: plausible, not checked.
- Historical: true at a dated moment, may have changed.

## Placeholders
Real names are in kb/private/names.md when that file exists.
- BASE_REPO: the existing application clone that has backend/ and frontend/.
- CAPTURE_REPO: the other clone, a source-capture toolkit.
- LEGACY_ORG: an older knowledge project. A source of lessons, not of code to copy.
- LEGACY_REVIEW: a review report on the code health of the legacy work.
- WIKI_SPACE: the wiki space that holds the programme pages.
- PILOT_USE_CASE: the first use case that the first release is built for.
- PROCESSING_SERVICE: a shared service that parses, chunks and embeds content.
- AGENT_HUB: the marketplace where tool servers are published to agents.
- CONSUMPTION_LAYER: the single place where end users discover products.
- GRAPH_STORE: the graph database product. Which one is an open choice.
- S1..S6: the six stories. S1 review, S2 gaps and risks, S3 product model, S4 roles,
  S5 extraction-to-graph workflow, S6 ingestion.
