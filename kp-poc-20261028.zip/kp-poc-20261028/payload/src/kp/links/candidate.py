"""A link that has been proposed for storage, before it has an identity or a validity period."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Self

from pydantic import AwareDatetime, Field, ValidationError

from kp.domain import DomainModel, ItemRef, Link, LinkKind, LinkState, Relation

_PROBE_TIME = datetime(2000, 1, 1, tzinfo=UTC)
_VALUE_ERROR_PREFIX = "Value error, "


class LinkCandidate(DomainModel):
    """The content of a link fact: endpoints, relation, kind, state, score and evidence."""

    source_ref: ItemRef
    relation: Relation
    target_ref: ItemRef
    kind: LinkKind
    state: LinkState
    score: Annotated[float, Field(ge=0, le=1)] | None = None
    evidence: str = ""

    @classmethod
    def stated(
        cls, source_ref: ItemRef, relation: Relation, target_ref: ItemRef, evidence: str = ""
    ) -> Self:
        """Build a stated link: no score, state ``stated``.

        :param source_ref: Where the edge starts
        :param relation: The relation, which fixes the allowed endpoint types
        :param target_ref: Where the edge ends
        :param evidence: Where the source says so, e.g. a file path or issue key
        :return: The candidate
        """
        return cls(
            source_ref=source_ref,
            relation=relation,
            target_ref=target_ref,
            kind=LinkKind.STATED,
            state=LinkState.STATED,
            evidence=evidence,
        )

    @classmethod
    def guessed(
        cls,
        source_ref: ItemRef,
        relation: Relation,
        target_ref: ItemRef,
        *,
        score: float,
        state: LinkState,
        evidence: str,
    ) -> Self:
        """Build a guessed link.

        :param source_ref: Where the edge starts
        :param relation: The relation, which fixes the allowed endpoint types
        :param target_ref: Where the edge ends
        :param score: The 0-1 score
        :param state: ``proposed``, ``review`` or ``dropped``
        :param evidence: The evidence behind the score
        :return: The candidate
        """
        return cls(
            source_ref=source_ref,
            relation=relation,
            target_ref=target_ref,
            kind=LinkKind.GUESSED,
            state=state,
            score=score,
            evidence=evidence,
        )

    @property
    def fact(self) -> tuple[ItemRef, Relation, ItemRef]:
        """The (source, relation, target) triple that identifies the fact."""
        return (self.source_ref, self.relation, self.target_ref)

    def to_link(self, link_id: str, valid_from: AwareDatetime) -> Link:
        """Turn the candidate into a link that opens at ``valid_from``.

        :param link_id: Identity of the new link
        :param valid_from: Start of the validity period
        :return: The validated link
        :raises pydantic.ValidationError: If the candidate violates the link rules
        """
        return Link(
            link_id=link_id,
            source_ref=self.source_ref,
            relation=self.relation,
            target_ref=self.target_ref,
            kind=self.kind,
            state=self.state,
            score=self.score,
            evidence=self.evidence,
            valid_from=valid_from,
        )


def conformance_violation(candidate: LinkCandidate) -> str | None:
    """Validate a candidate against the relation model and the link rules.

    :param candidate: The candidate to check
    :return: The first violation as a sentence, or ``None`` when the candidate conforms
    """
    try:
        candidate.to_link(link_id="probe", valid_from=_PROBE_TIME)
    except ValidationError as exc:
        message = str(exc.errors(include_input=False, include_url=False)[0]["msg"])
        return message.removeprefix(_VALUE_ERROR_PREFIX)
    return None
