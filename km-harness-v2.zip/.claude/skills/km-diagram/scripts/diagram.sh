#!/bin/bash
# Helper for km-diagram. Run with bash. Needs jq and awk.
#   diagram.sh build <name> <spec.json>
#                             copy the template if needed, put the spec in, check, write twin
#   diagram.sh new <name>     copy the template to designs/diagrams/<name>.html
#   diagram.sh check <name>   validate the spec block, print PASS or FAIL
#   diagram.sh twin <name>    check, then write designs/diagrams/<name>.md and refresh the
#                             noscript list inside the html from the same spec
# <name> is a bare name (no folder, no extension).
set -u
KM="$(cd "$(dirname "$0")/../../../.." && pwd)"
TPL="$KM/.claude/skills/km-diagram/assets/diagram-template.html"
DIR="$KM/designs/diagrams"
cmd="${1:-}"; name="${2:-}"; specfile="${3:-}"
case "$name" in
  ""|*/*|*.*) echo "usage: diagram.sh build|new|check|twin <name> [spec.json]"; exit 2 ;;
esac
HTML="$DIR/$name.html"; MD="$DIR/$name.md"

spec() {
  awk '/<script type="application\/json" id="spec">/{f=1;next} f&&/<\/script>/{exit} f' "$HTML"
}

# Prints one problem per line, nothing when the spec is sound.
problems() {
  jq -r '
    (.nodes // []) as $n | (.edges // []) as $e | ($n | map(.id)) as $ids |
    (.groups // [] | map(.id)) as $g |
    (if ($n | length) == 0 then "no nodes" else empty end),
    (if ($n | length) > 14 then "more than 14 nodes: split into linked files" else empty end),
    (if ((.groups // []) | length) > 4 then "more than 4 groups" else empty end),
    (if ((.flow // "lr") | IN("lr", "tb") | not) then "flow must be lr or tb" else empty end),
    (if ($ids | length) != ($ids | unique | length) then "duplicate node ids" else empty end),
    ($n[] | select((.label // "") == "") | "node without label: \(.id)"),
    ($n[] | select(.kind != null
        and (.kind | IN("service", "store", "queue", "user", "external", "ai", "note") | not))
      | "bad kind on \(.id)"),
    ($n[] | select(.status != null
        and (.status | IN("exists", "partial", "missing", "proposed") | not))
      | "bad status on \(.id)"),
    ($n[] | . as $x | select($x.group != null and ($g | index($x.group) | not))
      | "node \($x.id) names unknown group \($x.group)"),
    ($e[] | . as $x | select($ids | index($x.from) | not) | "edge from unknown node: \($x.from)"),
    ($e[] | . as $x | select($ids | index($x.to) | not) | "edge to unknown node: \($x.to)"),
    ($e[] | select(.style != null and (.style | IN("solid", "dash", "dot") | not))
      | "bad edge style"),
    ((.hot // [])[] | . as $h | select($ids | index($h) | not)
      | "hot path names unknown node: \($h)")'
}

check() {
  [ -f "$HTML" ] || { echo "FAIL: $HTML not found"; return 1; }
  local s errs; s="$(spec)"
  echo "$s" | jq -e . >/dev/null 2>&1 || { echo "FAIL: spec is not valid JSON"; return 1; }
  errs="$(echo "$s" | problems 2>&1)"
  if echo "$s" | LC_ALL=C grep -q '[^[:print:][:space:]]'; then
    errs="$errs"$'\n'"non-ASCII text in spec"
  fi
  if echo "$s" | grep -qiE 'https?://|www\.'; then errs="$errs"$'\n'"address found in spec"; fi
  errs="$(echo "$errs" | sed '/^$/d')"
  if [ -n "$errs" ]; then echo "$errs" | sed 's/^/FAIL: /'; return 1; fi
  echo "PASS: $name ($(echo "$s" | jq '.nodes | length') nodes," \
    "$(echo "$s" | jq '(.edges // []) | length') edges)"
}

twin() {
  local s ns out; s="$(spec)"
  echo "$s" | jq -r '"# " + .title, "", (.subtitle // ""), "",
    "Flow: " + (.flow // "lr") + ". Diagram file: '"$name"'.html", "", "## Parts", "",
    ((.groups // []) as $g | .nodes[] | . as $n |
      "- " + $n.id + ": " + $n.label + (if $n.sub then " - " + $n.sub else "" end)
      + " (" + ($n.kind // "service") + (if $n.status then ", " + $n.status else "" end) + ")"
      + (if $n.group then " [" + ([$g[] | select(.id == $n.group)][0].label // $n.group) + "]"
         else "" end)),
    "", "## Connections", "",
    ((.edges // [])[] | "- " + .from + " -> " + .to + (if .label then ": " + .label else "" end)
      + (if (.style // "solid") != "solid" then " (" + .style + ")" else "" end)),
    (if (.hot // []) | length > 0 then "", "Path in focus: " + (.hot | join(" > ")) else empty end),
    (if (.notes // []) | length > 0 then "", "## Notes", "", (.notes[] | "- " + .) else empty end),
    (if (.sources // []) | length > 0 then "", "## Sources", "", (.sources[] | "- " + .)
     else empty end)' > "$MD"
  ns="$(echo "$s" | jq -r '"  <noscript>", "    <h2 class=\"small\">Nodes and edges</h2>",
    "    <ul>",
    (.nodes[] | "      <li>" + (.label | @html) + (if .sub then " - " + (.sub | @html) else "" end)
      + "</li>"),
    ((.edges // [])[] | "      <li>" + (.from | @html) + " -> " + (.to | @html)
      + (if .label then ": " + (.label | @html) else "" end) + "</li>"),
    "    </ul>", "  </noscript>"')"
  out="$(NS="$ns" awk '/<!--ns-->/{print; print ENVIRON["NS"]; skip=1; next}
    /<!--\/ns-->/{skip=0} !skip{print}' "$HTML")"
  printf '%s\n' "$out" > "$HTML"
  echo "wrote $MD and refreshed the noscript list"
}

build() {
  [ -f "$specfile" ] || { echo "FAIL: spec file not found: $specfile"; return 1; }
  jq -e . "$specfile" >/dev/null 2>&1 || { echo "FAIL: $specfile is not valid JSON"; return 1; }
  mkdir -p "$DIR"
  [ -f "$HTML" ] || cp "$TPL" "$HTML"
  local out
  out="$(awk -v f="$specfile" '/<script type="application\/json" id="spec">/{print;
    while ((getline l < f) > 0) print l; skip=1; next}
    skip&&/<\/script>/{skip=0} !skip{print}' "$HTML")"
  printf '%s\n' "$out" > "$HTML"
  check && twin
}

case "$cmd" in
  build) build ;;
  new)
    mkdir -p "$DIR"
    [ -e "$HTML" ] && { echo "FAIL: $HTML exists"; exit 1; }
    cp "$TPL" "$HTML" && echo "created $HTML" ;;
  check) check ;;
  twin) check && twin ;;
  *) echo "usage: diagram.sh build|new|check|twin <name> [spec.json]"; exit 2 ;;
esac
