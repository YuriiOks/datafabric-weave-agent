"""Errors of the agent tool layer. All derive from the shared hierarchy in :mod:`kp.errors`.

Access refusals reuse :class:`kp.errors.AccessForbiddenError`, a missing governed template
reuses :class:`kp.errors.TemplateNotFoundError` and a write outside the allow-list reuses
:class:`kp.errors.WriteNotPermittedError`; the classes here cover the rest.
"""

from __future__ import annotations

from kp.errors import ConfigurationError, KpError


class ToolError(KpError):
    """Base class of failures raised while running an agent tool."""


class UnknownToolError(ToolError):
    """The requested tool is not registered on this server."""


class InvalidToolArgumentsError(ToolError, ValueError):
    """The tool arguments do not match the tool's input schema."""


class LinkStoreUnavailableError(ToolError):
    """The link store could not be reached. Search degrades; other link tools fail."""


class NoEditionInForceError(ToolError):
    """No edition of the rulebook was in force on the requested date."""


class RuleNotFoundError(ToolError):
    """The edition in force has no clause with the requested number."""


class ToolExecutionError(ToolError):
    """A tool failed for a reason the caller cannot act on; details are only in the logs."""


class AuditFailedError(ToolError):
    """The audit record could not be written, so the result is withheld."""


class IdentityMappingError(ConfigurationError):
    """The identity to domain mapping file is missing or malformed."""
