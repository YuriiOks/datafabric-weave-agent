"""Refresh source adapter over one registered acquisition source.

The adapter id is the registered source id, which is also the source id operators see
in refresh status. Acquisition runs in a worker thread because the acquisition service
is synchronous and bounded by its own limits. Every failure leaves as
``SourceCaptureFailed`` with a safe reason: the worker maps only refresh port errors,
so anything else would escape the job instead of failing it.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
from pathlib import Path

from pydantic import ValidationError

from app.recsys.acquisition import AcquisitionService
from app.recsys.acquisition.models import (
    AcquiredGitSource,
    AcquiredWorkbook,
    AcquisitionBatch,
    AcquisitionRefusal,
    ActivationState,
    RefusalCode,
)
from app.recsys.refresh.models import (
    CapturedSource,
    LeaseToken,
    SafeReason,
    SourceConfigurationSnapshot,
)
from app.recsys.refresh.ports import SourceCaptureFailed

from .staging import ArtifactStaging

logger = logging.getLogger(__name__)

# Refusals that mean "the source answered, but not with a complete, current capture".
# Everything else is a failed fetch. There is no stale reason in the refresh contract,
# so a too-old source reports as incomplete: either way it cannot be published.
_INCOMPLETE_REFUSALS = frozenset({RefusalCode.source_incomplete, RefusalCode.source_stale})


def _safe_reason_for(code: RefusalCode | None) -> str:
    if code in _INCOMPLETE_REFUSALS:
        return SafeReason.source_incomplete.value
    return SafeReason.source_failed.value


def _refusal_code(batch: AcquisitionBatch, source_id: str) -> RefusalCode | None:
    for record in batch.records:
        if record.source_id == source_id and record.evidence is not None:
            return record.evidence.code
    return None


class AcquisitionSourceAdapter:
    """Capture one registered source for a refresh attempt."""

    def __init__(
        self,
        *,
        source_id: str,
        service: AcquisitionService,
        staging: ArtifactStaging,
    ) -> None:
        """Bind the adapter to one registered source.

        :param source_id: The registered source id; used as the refresh adapter id.
        :param service: The acquisition service holding the source registration.
        :param staging: Where acquired artifacts wait for the catalogue build.
        """
        self.adapter_id = source_id
        self._service = service
        self._staging = staging

    async def capture(
        self,
        snapshot: SourceConfigurationSnapshot,
        lease: LeaseToken,
    ) -> CapturedSource:
        """Acquire the source and return its capture for this attempt.

        :param snapshot: The configuration snapshot the job was admitted with.
        :param lease: The lease of the attempt doing the capture.
        :return: The capture, naming the staged artifact by reference and digest.
        :raises SourceCaptureFailed: If the source cannot back a publishable capture.
        """
        if self.adapter_id not in snapshot.adapter_ids or snapshot.scope != lease.scope:
            raise SourceCaptureFailed(SafeReason.source_configuration_changed.value)
        self._staging.prune(job_id=lease.job_id, attempt_id=lease.attempt_id)
        root = self._staging.root_for(lease.attempt_id, self.adapter_id)
        batch = await self._acquire(root)
        acquired = batch.acquired.get(self.adapter_id)
        if acquired is None:
            code = _refusal_code(batch, self.adapter_id)
            logger.warning(
                "Refresh source acquisition refused",
                extra={"source_id": self.adapter_id, "refusal": code.value if code else None},
            )
            raise SourceCaptureFailed(_safe_reason_for(code))
        if batch.activation is not ActivationState.eligible:
            shutil.rmtree(root, ignore_errors=True)
            logger.warning(
                "Refresh source acquired but not eligible for activation",
                extra={
                    "source_id": self.adapter_id,
                    "freshness": acquired.manifest.freshness.value,
                },
            )
            raise SourceCaptureFailed(SafeReason.source_incomplete.value)
        if acquired.manifest.scope != snapshot.scope:
            shutil.rmtree(root, ignore_errors=True)
            raise SourceCaptureFailed(SafeReason.source_configuration_changed.value)
        return self._register(acquired, lease)

    async def _acquire(self, root: Path) -> AcquisitionBatch:
        try:
            return await asyncio.to_thread(self._service.acquire, (self.adapter_id,), root)
        except AcquisitionRefusal as refusal:
            logger.warning(
                "Refresh source acquisition refused",
                extra={"source_id": self.adapter_id, "refusal": refusal.code.value},
            )
            raise SourceCaptureFailed(_safe_reason_for(refusal.code)) from refusal
        except Exception as error:
            # Credential provider, filesystem and registration errors all mean the
            # fetch failed; the type is logged, the message is not (it may hold paths).
            logger.error(
                "Refresh source acquisition failed",
                extra={"source_id": self.adapter_id, "error_type": type(error).__name__},
            )
            raise SourceCaptureFailed(SafeReason.source_failed.value) from error

    def _register(
        self,
        acquired: AcquiredWorkbook | AcquiredGitSource,
        lease: LeaseToken,
    ) -> CapturedSource:
        if isinstance(acquired, AcquiredWorkbook):
            digest = acquired.workbook_hash
        else:
            digest = acquired.content_hash
        reference = self._staging.register(
            job_id=lease.job_id,
            attempt_id=lease.attempt_id,
            source_id=self.adapter_id,
            acquired=acquired,
            digest=digest,
        )
        try:
            return CapturedSource(
                manifest=acquired.manifest,
                adapter_id=self.adapter_id,
                artifact_reference=reference,
                artifact_digest=digest,
            )
        except ValidationError as error:
            self._staging.discard([reference])
            logger.error(
                "Refresh source capture is not a valid capture record",
                extra={"source_id": self.adapter_id, "error_count": error.error_count()},
            )
            raise SourceCaptureFailed(SafeReason.source_failed.value) from error
