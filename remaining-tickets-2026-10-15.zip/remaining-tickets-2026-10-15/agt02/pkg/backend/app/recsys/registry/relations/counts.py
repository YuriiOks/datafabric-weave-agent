"""Per-link-type accounting: what the sources declared against what was published.

The counts are computed, not persisted. They exist so a reviewer can check that every
declared reference occurrence went somewhere: into a published relation's evidence, or
into the review ledger under a named resolution outcome. Occurrences and relations are
different units and are never added together; the difference between the two is how
many repeated declarations were folded into an existing relation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.recsys.contracts import AccountingOutcome, CatalogueBuildResult, LinkType
from app.recsys.registry.models import ComponentLink


@dataclass(slots=True)
class LinkTypeCounts:
    """The accounting for one link type."""

    #: Every reference occurrence the sources declared for this link type.
    declared_occurrences: int = 0
    #: Occurrences the catalogue accepted.
    accepted_occurrences: int = 0
    #: Accepted occurrences that ended up as evidence on a published relation.
    published_evidence: int = 0
    #: Distinct published relations.
    relations: int = 0
    #: Non-accepted occurrences, by resolution outcome.
    unresolved_by_outcome: dict[str, int] = field(default_factory=dict)
    #: Non-accepted occurrences whose declaring record has no accepted identity.
    unattributed_unresolved: int = 0

    @property
    def folded_duplicates(self) -> int:
        """:return: How many published occurrences repeated an existing relation."""
        return self.published_evidence - self.relations

    @property
    def unresolved_occurrences(self) -> int:
        """:return: Every non-accepted occurrence for this link type."""
        return sum(self.unresolved_by_outcome.values())

    def as_dict(self) -> dict[str, Any]:
        """:return: The counts as a JSON-serialisable mapping, units in the names."""
        return {
            "declared_occurrences": self.declared_occurrences,
            "accepted_occurrences": self.accepted_occurrences,
            "published_evidence": self.published_evidence,
            "relations": self.relations,
            "folded_duplicates": self.folded_duplicates,
            "unresolved_occurrences": self.unresolved_occurrences,
            "unresolved_by_outcome": dict(sorted(self.unresolved_by_outcome.items())),
            "unattributed_unresolved": self.unattributed_unresolved,
        }


def count_relations(
    catalogue: CatalogueBuildResult, links: list[ComponentLink]
) -> dict[str, LinkTypeCounts]:
    """Count declarations, outcomes and relations for every link type.

    :param catalogue: The built catalogue candidate.
    :param links: The links projected from it.
    :return: Link type value to its counts; every link type is present.
    """
    counts = {link_type.value: LinkTypeCounts() for link_type in LinkType}
    outcomes = {
        evidence.reference_occurrence_id: evidence
        for evidence in catalogue.reference_outcomes
    }
    accepted_records = {
        outcome.occurrence_id
        for outcome in catalogue.record_outcomes
        if outcome.accounting_outcome is AccountingOutcome.accepted
    }
    for batch in catalogue.source_batches:
        for record in batch.records:
            for reference in record.references:
                if reference.link_type is None:
                    continue
                bucket = counts[reference.link_type.value]
                bucket.declared_occurrences += 1
                evidence = outcomes.get(reference.occurrence_id)
                if (
                    evidence is not None
                    and evidence.accounting_outcome is AccountingOutcome.accepted
                ):
                    bucket.accepted_occurrences += 1
                    continue
                outcome = evidence.outcome.value if evidence is not None else "unknown"
                bucket.unresolved_by_outcome[outcome] = (
                    bucket.unresolved_by_outcome.get(outcome, 0) + 1
                )
                if reference.parent_occurrence_id not in accepted_records:
                    bucket.unattributed_unresolved += 1
    for link in links:
        bucket = counts[link.link_type.value]
        bucket.relations += 1
        bucket.published_evidence += len(link.evidence)
    return counts
