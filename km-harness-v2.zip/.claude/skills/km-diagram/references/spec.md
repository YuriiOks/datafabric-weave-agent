# Diagram spec

One JSON object. Unknown keys are ignored. Everything is plain ASCII text.

| Key | Type | Meaning |
|---|---|---|
| title | text | Page title. A statement of what the picture shows. |
| subtitle | text | One line: scope and date or source. Optional. |
| flow | `lr` or `tb` | Left to right (default) or top to bottom. |
| groups | list of {id, label} | Lanes, at most 4. Drawn in the order given. |
| nodes | list | At most 14. See below. |
| edges | list | See below. |
| hot | list of node ids | One path in focus, in order. Gets the accent. Optional. |
| legend | true or false | Key to the shapes and lines used. Default true. |
| notes | list of text | Numbered notes under the picture. Optional. |
| sources | list of text | kb or design files the facts come from. Always fill it. |

## Nodes
`{"id": "api", "label": "Search service", "sub": "answers queries", "group": "g1",
"kind": "service", "status": "partial"}`
- id: short, lower case, unique. label: at most about 28 characters. sub: optional, short.
- group: an id from groups. A node without a group goes to an unnamed lane, except an
  unconnected `note` when groups exist: it moves to the Notes list instead of taking a lane.
- kind picks the shape: `service` (box), `store` (cylinder), `queue` (pill), `user` (box with
  a person mark), `external` (plain box, outside our control), `ai` (box with a spark mark),
  `note` (a loose remark with a rule on the left; connect it to nothing).
- status: `exists` (default, solid border), `partial` (dashed, tagged), `missing` (dotted,
  tagged), `proposed` (dash and dot, tagged). The border and the tag say it; no colour is used.

## Edges
`{"from": "web", "to": "api", "label": "question", "style": "dash"}`
- from and to are node ids. label: one or two words, a verb or the thing that moves.
- style: `solid` a call or flow (default), `dash` a read, async or indirect link, `dot`
  planned. Pick the style by meaning; the legend names it.
- A link that goes backwards (a reply, a loop) is fine: the layout draws it with the arrow at
  the right end. Do not draw a self-link; the page lists it as not drawn.
- Two edges between the same pair are allowed (one per direction, or two styles).

## Hot path
`"hot": ["user", "web", "api"]` colours the edges between consecutive ids and marks the last
node. Use it for the one thing the reader should trace. Leave it out when no path matters
more than the others.

## Example (small, left to right)
```
{
  "title": "Question to answer",
  "subtitle": "Current path, from kb/base/search.md",
  "flow": "lr",
  "groups": [{"id": "fe", "label": "Front end"}, {"id": "be", "label": "Back end"}],
  "nodes": [
    {"id": "usr", "label": "Reader", "group": "fe", "kind": "user"},
    {"id": "web", "label": "Search page", "group": "fe"},
    {"id": "api", "label": "Query service", "group": "be"},
    {"id": "idx", "label": "Page index", "sub": "text and vectors", "group": "be", "kind": "store"}
  ],
  "edges": [
    {"from": "usr", "to": "web", "label": "types"},
    {"from": "web", "to": "api", "label": "question"},
    {"from": "api", "to": "idx", "label": "lookup", "style": "dash"}
  ],
  "hot": ["usr", "web", "api"],
  "sources": ["kb/base/search.md"]
}
```

## Choosing what to draw
- Lanes answer one question: who owns it, where does it run, or which layer is it.
- If most edges cross lanes the lanes are wrong; regroup or drop the lanes (no groups).
- Fewer, better parts: merge parts that are always used together; leave out a part that no
  edge touches.
- A diagram with every status in it needs the legend; keep `legend` on then.
