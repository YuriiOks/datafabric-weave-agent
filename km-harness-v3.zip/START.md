# START: design harness (for the owner)

## 1 Unzip
```
cd /home/user/km
unzip -o km-harness.zip
```
- Appears: CLAUDE.md, AGENTS.md, START.md, start.sh, .claude/, kb/, designs/, work/.
- Nothing is written into the clones. A second unzip -o keeps run files but resets
  kb/INDEX.md and the agent tier: then run kb-lint.sh (section 7) and km-tier.sh strong if set.

## 2 Start
```
bash /home/user/km/start.sh
```
| Mode | Use when |
|---|---|
| (none) | normal: strong model, 1M window, effort high |
| std | the first form is refused: same model, no 1M suffix |
| plain | a flag is rejected: no flags, the project settings choose the model |

Mode goes first: bash /home/user/km/start.sh std. Always start here, never inside a clone.
A session inside a clone does not see these commands and loads that clone's own rules.

## 3 First run
Type /km-start. It prints a table of checks. Then check yourself:
- Banner: the strong model and the 1M window. Footer: auto mode (from the user settings).
- /context: note the size. The managed tool list is the largest part and is not ours.
- /memory: lists /home/user/km/CLAUDE.md. The user-level file should not be listed.
- /skills: seventeen km- skills. /agents: sixteen km- agents.
Good: every row of the /km-start table says OK or gives a one-line reason you can act on.
The agents ship on the mixed tier (strongest model for the advisor, mid-size for builders,
tests, readers and level-3 reviewers, small for the kb scout). /km-start calls each model once
and says which answered. If one is refused, run in a plain terminal:
bash /home/user/km/.claude/bin/km-tier.sh strong
(every agent then uses the session model). Back: km-tier.sh mixed. Look: km-tier.sh show.

## 4 Commands
| Command | One line |
|---|---|
| /km-start | check the setup and the models |
| /km-kb | rules for looking up and writing back to the kb |
| /km-read base, capture, legacy, pdf, wiki | bulk reading into kb/ by parallel readers |
| /km-verify s1..s6 or all | check recorded claims against code |
| /km-risks | risk register and open questions from the kb |
| /km-story s1..s6 | pack, the deliverable in designs/, one skeptical review |
| /km-review path | one skeptical review of a file |
| /km-pr | checks, then push and draft pull request for a task |
| /km-conventions layer\|all [capture] | write kb/conventions/ from the code (layer rules) |
| /km-plan task design-file\|goal | slices, contracts, tests, order, risks in work/plans/ |
| /km-build task | work tree, builders, tests, reviews, pushed commits, draft PR; summary |
| /km-code-review task | review of a task's diff by dimension, then a refutation pass |
| /km-review-pr number | read-only review of someone else's pull request; a draft only |
| /km-grill task\|path | eight hard probes on your own change or design; a must-fix list |
| /km-write sprint\|status\|card\|ticket subject | plain-language draft for non-engineers |
| /km-diagram name | architecture diagram page plus a list twin in designs/diagrams/ |
| /km-page name | report or one-pager page plus a twin in designs/pages/ |

Order for three days:
- Wave 1: /km-start. Then /km-verify all and /km-read wiki, in two sessions. Without
  kb/private: /km-read base, /km-read capture and /km-read wiki first, then /km-verify all.
- Wave 2: /km-read base and /km-read capture (gap mode: only what is not yet read); /km-risks
  after both have finished.
- Wave 3: /km-story s3 and s4 first, then s1, s2, s5. Run s6 only if that story is yours.
- Any time, optional: /km-read legacy, /km-read pdf.

## 5 Effort
Sessions start at high. Type /effort xhigh before /km-story and /km-risks, and again after /clear.

## 6 Parallel sessions
At most 3, each in its own terminal started with start.sh. Each run writes its own files in
kb/index.d and kb/log.d, so they do not collide. Not the same command twice at once.

## 7 Checks
```
bash /home/user/km/.claude/bin/kb-lint.sh
```
It rebuilds kb/INDEX.md, prints FAIL and WARN lines, then PASS or FAIL. Fix every FAIL (size,
date line, secret-shaped text); WARN lines are advice. Run it after each wave.
Logs: kb/log.d, one file per run. Results: designs/.
Setup sizes before unzip: bash <(unzip -p km-harness.zip .claude/bin/inventory.sh)
and after unzip: bash /home/user/km/.claude/bin/inventory.sh

## 8 Optional private add-on
kb/private holds real names, claims from an earlier read, and chat context. It comes in
km-harness-full.zip (public files plus kb/private), unzipped the same way, never through the
public channel. Without it the skills use code, wiki and kb/seed and mark results Unverified;
/km-read wiki asks for the ticket keys, /km-read legacy for the org login.

## 9 Writing code
- Once per clone: /km-conventions all. Builders and reviewers read what it writes.
- Per task: /km-plan <task> "one-line goal" (or a design file), read work/plans/<task>.md,
  then /km-build <task>. Work happens in its own work tree under work/wt/<task> on a branch
  feat/<task>-<slug>; the main checkout of a clone is never edited.
- Your /km-build <task> is your go: the session pushes the branch after every commit and opens
  a draft pull request after the first push (it needs the epic and ticket key; without them it
  pushes only and says which is missing). The approval prompt of the environment may appear:
  answer it, never choose a permanent allow.
- The build ends with pushed commits and work/builds/<task>.md: files changed, checks with their
  real results, review findings, what is open. Two review rounds at most.
- Read the summary and the draft pull request. /km-pr <task> re-checks and refreshes it. Ready,
  merge, close, reviewers, labels, ticket status and every comment are yours; no skill does them.
- Remove a finished work tree yourself: git -C <clone> worktree remove /home/user/km/work/wt/<task>

## 10 Reviewing a pull request
- /km-review-pr <number> [clone] reads the change with gh and writes work/reviews/pr-<n>.md:
  verdict and at most 10 comments, each with path:line, the problem, a suggestion and a
  severity. Read it, edit it, post it yourself. Nothing is posted by the skill.
- After the author pushes fixes: /km-review-pr <number> again. It checks each earlier comment
  against the current code (fixed, partly, not addressed) before looking for new problems.
- Up to 3 subagents run at once. The machine is small: one review or build per session.

## 11 Before any push
/km-build and /km-pr push for you after their own checks. Optional, in a plain terminal,
once per clone, so every push from the clone is also checked by git itself:
bash /home/user/km/.claude/bin/install-git-guard.sh /home/user/km/<clone>
It adds one git hook file that stops a push carrying harness files, paths under .claude/ or
.github/, or a session link line. By hand: cd into the clone, then
bash /home/user/km/.claude/bin/pre-push-guard.sh --check

## 12 Remove
Delete from /home/user/km: km-harness.zip, CLAUDE.md, AGENTS.md, START.md, start.sh, .claude,
kb, designs, work (copy kb and designs first). Also <clone>/.git/hooks/pre-push if installed.
The clones are untouched.

## 13 Known unknowns to watch
- Effort may be ignored by the gateway. The skills also state depth in words.
- The user-level rules of the other project may still load. /memory shows it.
- The wiki and ticket tools may be missing. /km-start lists the tools it sees.
- A denied command or a blocked file is logged and skipped. Nothing retries it.
