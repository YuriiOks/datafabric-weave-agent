"""Change detection by snapshot, shared by the directory-backed readers.

A snapshot maps every item version a reader has already reported to a fingerprint of what the
source said about it (content plus approval signals). The cursor *is* the snapshot, compressed
and encoded, so it is opaque to callers and self-contained: no reader state is kept anywhere
else.

``list_changed`` compares the source as it is now with the snapshot in the cursor. Anything
new or with a different fingerprint is reported; anything that vanished is reported as deleted.
The cursor returned with a page is the snapshot *after that page was applied*, so a run that
stops halfway restarts from the last saved page without duplicates and without gaps.

Cursor size. The cursor holds one 64-character fingerprint per item version, so it grows
linearly with the source: 60 to 100 bytes per version once compressed and encoded, which is
about 20 KB for three hundred files and a few hundred KB for a repository of thousands. It is
rewritten to ``sweep_cursor.position`` after every page and held in memory while a listing is
built. That is acceptable for the proof of concept; a source beyond tens of thousands of items
needs a different position (for instance a per-directory digest map), which is why decoding
refuses a cursor that inflates past a fixed bound instead of trusting it.

Fetching. A scan is the expensive step (it reads and hashes every item), so a reader keeps the
result of its last scan and looks a key up there. Before returning content, ``fetch`` reads
that one item again and checks it still carries the key and fingerprint it was listed with, so
the bytes returned always match the version, and an item changed or withheld since the listing
(a draft, an unmerged edition) cannot be fetched. A key that is not in the last scan triggers
one new scan.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import logging
import zlib
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import ClassVar

from pydantic import JsonValue, TypeAdapter, ValidationError

from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.errors import SourceItemNotFoundError
from kp.sources.base import ChangeBatch, ChangedItem, FetchedItem, ItemMetadata
from kp.sources.errors import InvalidCursorError, MalformedSourceDataError
from kp.sources.paging import require_limit

logger = logging.getLogger(__name__)

Snapshot = dict[str, dict[str, str]]
"""``item_id -> version -> fingerprint``."""

_PREFIX = "snap1:"
_MAX_CURSOR_BYTES = 64 * 1024 * 1024
_SNAPSHOT_ADAPTER: TypeAdapter[Snapshot] = TypeAdapter(Snapshot)


def fingerprint(content_sha256: str, signals: Mapping[str, JsonValue]) -> str:
    """Combine a content hash with the approval signals reported beside it.

    A change to either makes the item show up as changed, so an approval withdrawn in a
    sidecar is noticed even though the document bytes did not move.

    :param content_sha256: Hash of the item's bytes
    :param signals: Everything else the source said about the item
    :return: Lower-case hexadecimal SHA-256
    """
    canonical = json.dumps(signals, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(f"{content_sha256}\n{canonical}".encode("ascii")).hexdigest()


def encode_snapshot(snapshot: Snapshot) -> str:
    """Turn a snapshot into an opaque cursor.

    :param snapshot: What has been reported so far
    :return: A text cursor for the sweep to persist
    """
    raw = json.dumps(snapshot, sort_keys=True, separators=(",", ":")).encode("ascii")
    return _PREFIX + base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode("ascii")


def decode_snapshot(cursor: str | None) -> Snapshot:
    """Read a cursor produced by :func:`encode_snapshot`.

    :param cursor: A persisted cursor, or ``None`` for a first sweep
    :return: The snapshot (empty for ``None``)
    :raises kp.sources.errors.InvalidCursorError: If the cursor is foreign, corrupt or too large
    """
    if cursor is None:
        return {}
    if not cursor.startswith(_PREFIX):
        raise InvalidCursorError("Cursor was not issued by a snapshot reader")
    try:
        compressed = base64.urlsafe_b64decode(cursor[len(_PREFIX) :].encode("ascii"))
        inflater = zlib.decompressobj()
        raw = inflater.decompress(compressed, _MAX_CURSOR_BYTES)
        if len(raw) >= _MAX_CURSOR_BYTES and not inflater.eof:
            # Cut at the bound: what was read is truncated JSON, so say why before parsing it.
            raise InvalidCursorError("Cursor is too large")
        return _SNAPSHOT_ADAPTER.validate_json(raw)
    except (binascii.Error, UnicodeEncodeError, zlib.error, ValidationError) as exc:
        raise InvalidCursorError("Cursor is corrupt") from exc


@dataclass(frozen=True)
class ReadItem:
    """One item version read in full: its identity, what the source said, and its bytes.

    :ivar fingerprint: Changes whenever the content or any approval signal changes
    """

    key: ItemKey
    fingerprint: str
    title: str
    modified_at: datetime | None
    content: bytes
    metadata: ItemMetadata


@dataclass(frozen=True)
class ScannedItem:
    """One item version as the source looked at scan time, without its bytes.

    :ivar fingerprint: Changes whenever the content or any approval signal changes
    :ivar reread: Reads this one item again; ``None`` when it is no longer visible. Called only
        when the item is fetched
    """

    key: ItemKey
    fingerprint: str
    title: str
    modified_at: datetime | None
    reread: Callable[[], ReadItem | None]

    @classmethod
    def of(cls, item: ReadItem, reread: Callable[[], ReadItem | None]) -> ScannedItem:
        """Keep what a listing needs from ``item`` and let go of its bytes.

        :param item: The item as just read
        :param reread: How to read this same item again
        :return: The scanned entry
        """
        return cls(
            key=item.key,
            fingerprint=item.fingerprint,
            title=item.title,
            modified_at=item.modified_at,
            reread=reread,
        )


@dataclass(frozen=True)
class _Change:
    item: ChangedItem
    fingerprint: str | None  # None for a deletion


class SnapshotReader(ABC):
    """Base of the readers over a local tree: implement :meth:`_scan` and :attr:`kind`.

    A reader instance keeps the result of its last scan, so it is meant to be used by one
    sweep at a time.

    :cvar supersedes_older_versions: True when a new version of an item replaces the old one
        in the source (a page edit, a changed file). The old version is then not "deleted".
        False when versions are explicit and coexist (document library, editions): a version
        that disappears has been removed or un-approved, and is reported as deleted.
    """

    supersedes_older_versions: ClassVar[bool] = False

    def __init__(self) -> None:
        self._index: dict[ItemKey, list[ScannedItem]] | None = None

    @property
    @abstractmethod
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves."""

    @abstractmethod
    def _scan(self) -> list[ScannedItem]:
        """Describe every item version visible in the source right now.

        :return: One entry per version; entries of withheld items (drafts, unmerged editions)
            are simply absent
        :raises kp.errors.SourceUnavailableError: If the source cannot be read
        :raises kp.sources.errors.MalformedSourceDataError: If a record has the wrong shape
        """

    def list_changed(self, cursor: str | None, *, limit: int = 100) -> ChangeBatch:
        """List item versions changed since ``cursor``.

        :param cursor: The saved position, or ``None`` for a first sweep
        :param limit: Maximum items per page
        :return: A page of changes; its cursor is valid once the page has been processed
        :raises kp.sources.errors.InvalidReadRequestError: If ``limit`` is below one
        :raises kp.sources.errors.InvalidCursorError: If the cursor is foreign or corrupt
        :raises kp.errors.SourceUnavailableError: If the source cannot be reached
        :raises kp.sources.errors.MalformedSourceDataError: If two records claim one version
        """
        require_limit(limit)
        known = decode_snapshot(cursor)
        current = self._rescan()
        for claimed, claims in (self._index or {}).items():
            if len(claims) > 1:
                raise MalformedSourceDataError(f"Two source records claim {claimed}")
        changes = self._diff(known, current)
        page = changes[:limit]
        logger.info(
            "Change listing built",
            extra={
                "source": self.kind.value,
                "known": sum(len(versions) for versions in known.values()),
                "current": len(current),
                "changes": len(changes),
                "returned": len(page),
            },
        )
        return ChangeBatch(
            items=tuple(change.item for change in page),
            next_cursor=encode_snapshot(self._advance(known, page)),
            exhausted=len(changes) <= limit,
        )

    def fetch(self, key: ItemKey) -> FetchedItem:
        """Fetch the bytes and metadata of one item version.

        :param key: The version to fetch
        :return: Its content and metadata, read after the listing and checked against it
        :raises kp.errors.SourceItemNotFoundError: If the version is not visible or changed
            since it was listed, which includes drafts and unmerged editions
        :raises kp.errors.SourceUnavailableError: If the source cannot be read
        :raises kp.sources.errors.MalformedSourceDataError: If two records claim this version
        """
        entries = self._index.get(key) if self._index is not None else None
        if entries is None:
            self._rescan()
            entries = (self._index or {}).get(key)
        if not entries:
            raise SourceItemNotFoundError(f"No such item version: {key}")
        if len(entries) > 1:
            raise MalformedSourceDataError(f"Two source records claim {key}")
        listed = entries[0]
        current = listed.reread()
        if current is None or (current.key, current.fingerprint) != (
            listed.key,
            listed.fingerprint,
        ):
            raise SourceItemNotFoundError(f"Item version changed or withheld since listing: {key}")
        return FetchedItem(key=current.key, content=current.content, metadata=current.metadata)

    def _rescan(self) -> list[ScannedItem]:
        entries = self._scan()
        index: dict[ItemKey, list[ScannedItem]] = {}
        for entry in entries:
            index.setdefault(entry.key, []).append(entry)
        self._index = index
        return entries

    def _diff(self, known: Snapshot, current: list[ScannedItem]) -> list[_Change]:
        changes = [
            _Change(
                ChangedItem(key=entry.key, title=entry.title, modified_at=entry.modified_at),
                entry.fingerprint,
            )
            for entry in current
            if known.get(entry.key.item_id, {}).get(entry.key.version) != entry.fingerprint
        ]
        present = {entry.key for entry in current}
        present_items = {entry.key.item_id for entry in current}
        for item_id, versions in known.items():
            if self.supersedes_older_versions and item_id in present_items:
                continue
            for version in versions:
                key = ItemKey(source=self.kind, item_id=item_id, version=version)
                if key not in present:
                    changes.append(_Change(ChangedItem(key=key, deleted=True), None))
        return sorted(
            changes, key=lambda change: (change.item.key.item_id, change.item.key.version)
        )

    def _advance(self, known: Snapshot, page: list[_Change]) -> Snapshot:
        snapshot = {item_id: dict(versions) for item_id, versions in known.items()}
        for change in page:
            key = change.item.key
            versions = snapshot.setdefault(key.item_id, {})
            if change.fingerprint is None:
                versions.pop(key.version, None)
            else:
                if self.supersedes_older_versions:
                    versions.clear()
                versions[key.version] = change.fingerprint
            if not versions:
                del snapshot[key.item_id]
        return snapshot
