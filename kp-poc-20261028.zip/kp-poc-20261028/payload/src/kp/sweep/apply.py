"""Applies one page of fetched changes inside the page's transaction.

For every item version the sweep sees, this module records the approval decision, hands
admitted versions to the content processor, supersedes older editions, withdraws removed
items and writes change events and review items. A version seen again with the same decision
changes nothing, which is what makes re-runs and restarts safe.
"""

from __future__ import annotations

import hashlib
import logging
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime

from sqlalchemy import Connection

from kp.domain import (
    ApprovalState,
    ChangeEvent,
    ChangeKind,
    ItemKey,
    ReviewItem,
    SourceItemVersion,
)
from kp.sources.base import ChangedItem, FetchedItem
from kp.sweep.errors import RawStoreConflictError
from kp.sweep.gate import ApprovalGate, Decision
from kp.sweep.loadback import SpecLoader
from kp.sweep.models import LoadedSpec, WorkItem, WorkReason
from kp.sweep.ports import ContentProcessor, RawStore
from kp.sweep.series import LIVE_STATES, order_key, plan_supersession
from kp.sweep.store import SweepStore

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ApplyServices:
    """The collaborators page application needs."""

    gate: ApprovalGate
    processor: ContentProcessor
    raw_store: RawStore


@dataclass
class PageResult:
    """What applying one page did.

    Internal and mutable: the page applier fills it in and the engine merges it into the
    run's tally. The public report is :class:`~kp.sweep.models.SweepSummary`.
    """

    work_items: list[WorkItem] = field(default_factory=list)
    loaded_specs: list[LoadedSpec] = field(default_factory=list)
    versions_recorded: int = 0
    state_changes: int = 0
    conflicts: int = 0


class PageApplier:
    """Applies the fetched items of one page on one open connection.

    :param connection: The page transaction's connection
    :param services: Gate, content processor and raw store
    :param run_id: The run the page belongs to
    :param now: The time to stamp on everything written
    """

    def __init__(
        self, connection: Connection, services: ApplyServices, *, run_id: str, now: datetime
    ) -> None:
        self._connection = connection
        self._store = SweepStore(connection)
        self._services = services
        self._run_id = run_id
        self._now = now
        self._today = now.date()
        self._result = PageResult()

    def apply(
        self, items: Sequence[ChangedItem], fetched: Mapping[ItemKey, FetchedItem]
    ) -> PageResult:
        """Apply every change of the page.

        :param items: The changes the source reported
        :param fetched: Fetched content for the non-deleted ones; an absent key means the
            source no longer has that version and it is skipped
        :return: Counts and the work handed on
        """
        for changed in items:
            if changed.deleted:
                self._apply_deleted(changed.key)
            elif (item := fetched.get(changed.key)) is not None:
                self._apply_fetched(item)
        return self._result

    # Items ------------------------------------------------------------------------------

    def _apply_deleted(self, key: ItemKey) -> None:
        stored = self._store.get_version(key)
        if stored is None:
            versions = self._store.list_versions(key.source, key.item_id)
            admitted = [v for v in versions if v.approval_state is ApprovalState.ADMITTED]
            stored = max(admitted, key=order_key) if admitted else None
        if stored is not None and stored.approval_state in LIVE_STATES:
            self._withdraw(stored)

    def _apply_fetched(self, item: FetchedItem) -> None:
        decision = self._services.gate.decide(item.key.source, item.metadata)
        stored = self._store.get_version(item.key)
        if stored is None:
            self._record_new(item, decision)
        else:
            self._reconsider(stored, item, decision)

    def _record_new(self, item: FetchedItem, decision: Decision) -> None:
        try:
            location = self._services.raw_store.put(item.key, item.content)
        except RawStoreConflictError:
            self._result.conflicts += 1
            logger.warning(
                "Raw store holds different bytes for a version not yet recorded",
                extra={"source": item.key.source.value, "item_id": item.key.item_id},
            )
            return
        meta = item.metadata
        version = SourceItemVersion(
            source=item.key.source,
            item_id=item.key.item_id,
            version=item.key.version,
            native_id=meta.native_id,
            content_sha256=hashlib.sha256(item.content).hexdigest(),
            media_type=meta.media_type,
            title=meta.title,
            author=meta.author,
            modified_at=meta.modified_at,
            raw_location=location,
            fetched_at=self._now,
            run_id=self._run_id,
            approval_state=decision.state,
            effective_date=decision.effective_date,
            withdrawn_at=self._today if decision.state is ApprovalState.WITHDRAWN else None,
            details=decision.details,
            machine_authored=decision.machine_authored,
        )
        self._store.insert_version(version)
        self._result.versions_recorded += 1
        self._note_review(version, decision)
        if decision.state is ApprovalState.ADMITTED:
            self._admit(version, item.content, decision)

    def _reconsider(self, stored: SourceItemVersion, item: FetchedItem, decision: Decision) -> None:
        if hashlib.sha256(item.content).hexdigest() != stored.content_sha256:
            self._result.conflicts += 1
            logger.warning(
                "Source offered different bytes for a stored version",
                extra={"source": stored.source.value, "item_id": stored.item_id},
            )
            return
        if stored.approval_state is ApprovalState.WITHDRAWN:
            # Withdrawal is final for a version; a re-approval arrives as a new version.
            return
        if stored.approval_state is ApprovalState.SUPERSEDED and (
            decision.state is not ApprovalState.WITHDRAWN
        ):
            return
        if stored.approval_state is decision.state:
            return
        # A live version that loses its approval (label removed, merge undone) is withdrawn
        # from today, so a citation shows since when it is no longer in use. Its predecessor
        # stays superseded: nothing is in force until a new approved version arrives.
        revoked = stored.approval_state in LIVE_STATES and decision.state not in LIVE_STATES
        state = ApprovalState.WITHDRAWN if revoked else decision.state
        updated = stored.model_copy(
            update={
                "approval_state": state,
                "effective_date": decision.effective_date or stored.effective_date,
                "withdrawn_at": self._today if state is ApprovalState.WITHDRAWN else None,
                "details": decision.details,
                "machine_authored": decision.machine_authored,
            }
        )
        self._store.save_approval(updated)
        self._store.sync_edition_dates(updated)
        self._result.state_changes += 1
        self._note_review(updated, decision)
        if revoked:
            self._emit(ChangeKind.WITHDRAWN, stored.key, old=stored.version, new=None)
        if decision.state is ApprovalState.ADMITTED:
            self._admit(updated, item.content, decision)

    # Admission, supersession, withdrawal --------------------------------------------------

    def _admit(self, version: SourceItemVersion, content: bytes, decision: Decision) -> None:
        others = [
            other
            for other in self._store.list_versions(version.source, version.item_id)
            if other.key != version.key and other.approval_state in LIVE_STATES
        ]
        position = order_key(version)
        earlier = [other for other in others if order_key(other) < position]
        predecessor = max(earlier, key=order_key) if earlier else None
        quiet = self._same_meaning(version, content, predecessor)
        if not quiet:
            self._services.processor.process(self._connection, version, content)
            reason = WorkReason.NEW if predecessor is None else WorkReason.CHANGED
            self._result.work_items.append(WorkItem(key=version.key, reason=reason))
            self._emit(
                ChangeKind.NEW if predecessor is None else ChangeKind.CHANGED,
                version.key,
                old=predecessor.version if predecessor else None,
                new=version.version,
            )
            if decision.spec is not None:
                loaded = SpecLoader(self._connection).load(
                    version, decision.spec, content, replaces_earlier=bool(others)
                )
                self._result.loaded_specs.append(loaded)
        self._supersede(version, quiet=quiet)

    def _same_meaning(
        self, version: SourceItemVersion, content: bytes, predecessor: SourceItemVersion | None
    ) -> bool:
        """True when the processor says the version differs from its predecessor in form only."""
        if predecessor is None:
            return False
        processor = self._services.processor
        fingerprint = processor.fingerprint(version, content)
        if fingerprint is None:
            return False
        before = self._services.raw_store.get(predecessor.raw_location)
        return processor.fingerprint(predecessor, before) == fingerprint

    def _supersede(self, newest: SourceItemVersion, *, quiet: bool) -> None:
        versions = self._store.list_versions(newest.source, newest.item_id)
        for step in plan_supersession(versions, self._today):
            due = step.when <= self._today
            older = step.older.model_copy(
                update={
                    "superseded_at": step.when,
                    "approval_state": ApprovalState.SUPERSEDED
                    if due
                    else step.older.approval_state,
                }
            )
            self._store.save_approval(older)
            self._store.sync_edition_dates(older)
            if not (quiet and step.newer.key == newest.key):
                self._emit(
                    ChangeKind.SUPERSEDED, older.key, old=older.version, new=step.newer.version
                )

    def _withdraw(self, version: SourceItemVersion) -> None:
        updated = version.model_copy(
            update={"approval_state": ApprovalState.WITHDRAWN, "withdrawn_at": self._today}
        )
        self._store.save_approval(updated)
        self._store.sync_edition_dates(updated)
        self._result.state_changes += 1
        self._emit(ChangeKind.WITHDRAWN, version.key, old=version.version, new=None)

    # Records ------------------------------------------------------------------------------

    def _note_review(self, version: SourceItemVersion, decision: Decision) -> None:
        review = decision.review
        if review is None:
            self._store.resolve_reviews(version.key, self._now)
        elif not self._store.has_open_review(version.key, review.kind):
            self._store.add_review(
                ReviewItem(
                    review_id=uuid.uuid4().hex,
                    kind=review.kind,
                    source=version.source,
                    item_id=version.item_id,
                    version=version.version,
                    detail=review.detail,
                    missing_details=review.missing_details,
                    content_owner=review.content_owner,
                    run_id=self._run_id,
                    created_at=self._now,
                )
            )

    def _emit(self, kind: ChangeKind, key: ItemKey, *, old: str | None, new: str | None) -> None:
        self._store.add_event(
            ChangeEvent(
                event_id=uuid.uuid4().hex,
                source=key.source,
                item_id=key.item_id,
                old_version=old,
                new_version=new,
                kind=kind,
                detected_at=self._now,
                run_id=self._run_id,
            )
        )
