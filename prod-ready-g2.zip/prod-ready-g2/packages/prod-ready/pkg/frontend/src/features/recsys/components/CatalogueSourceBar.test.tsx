import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { CatalogueSourceBar } from './CatalogueSourceBar'

vi.mock('../client', () => ({
  RECSYS_MOCK_ENABLED: false,
  recsysLive: async () => false,
  resetRecsysLive: () => undefined,
}))

afterEach(() => {
  cleanup()
})

describe('CatalogueSourceBar without demo mode', () => {
  it('says the recommender is unavailable instead of labelling sample data', async () => {
    render(
      <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
        <MemoryRouter>
          <CatalogueSourceBar sampleNote="The registry shows sample components." />
        </MemoryRouter>
      </QueryClientProvider>,
    )

    expect(await screen.findByText('Unavailable')).toBeInTheDocument()
    expect(screen.queryByText('Demo data')).not.toBeInTheDocument()
  })
})
