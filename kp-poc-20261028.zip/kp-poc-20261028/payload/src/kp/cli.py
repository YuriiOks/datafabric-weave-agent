"""Command-line entry point ``kp``.

Every command is owned by the package that implements it; this module registers them on one
parser and gives the ones that need the whole application (``sweep``, ``draft-spec``,
``merge-spec``, ``serve-read``, ``serve-write``) the application built from the settings.
``init-db`` and ``demo`` belong to the application itself, and ``web`` builds its own from the
arguments.
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Callable, Sequence
from pathlib import Path

from kp import mcp
from kp.app import Application, build_application, serve_wiring
from kp.config import load_settings
from kp.connectivity import cli as connectivity_cli
from kp.corrections import cli as corrections_cli
from kp.demo import cli as demo_cli
from kp.errors import KpError
from kp.links import cli as links_cli
from kp.log import configure_logging
from kp.publish import cli as publish_cli
from kp.search import cli as search_cli
from kp.sweep import cli as sweep_cli
from kp.web import cli as web_cli
from kp.writeback import cli as writeback_cli

DEFAULT_LOG_LEVEL = "INFO"


def build_parser() -> argparse.ArgumentParser:
    """Build the parser with every command registered.

    :return: The configured parser; each subparser sets ``handler``
    """
    parser = argparse.ArgumentParser(prog="kp", description="Knowledge platform")
    subparsers = parser.add_subparsers(dest="command", required=True)
    sweep_cli.add_parser(subparsers).set_defaults(handler=_sweep)
    search_cli.add_parser(subparsers)
    links_cli.add_parser(subparsers)
    publish_cli.add_parser(subparsers)
    corrections_cli.add_parser(subparsers)
    connectivity_cli.add_parser(subparsers)
    mcp.add_parser(subparsers, wiring=serve_wiring())
    writeback_cli.add_parser(subparsers).set_defaults(handler=_draft_spec)
    _add_merge_spec(subparsers)
    _add_init_db(subparsers)
    demo_cli.add_parser(subparsers)
    web_cli.add_parser(subparsers)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command line.

    Logging is configured (JSON on standard error) only when ``argv`` is not given, that is
    when the program itself is started rather than called from code.

    :param argv: Arguments without the program name; defaults to ``sys.argv[1:]``
    :return: The process exit status of the command
    """
    args = build_parser().parse_args(argv)
    if argv is None:
        configure_logging(_log_level())
    handler: Callable[[argparse.Namespace], int] = args.handler
    return handler(args)


def _log_level() -> str:
    try:
        return load_settings().log_level
    except KpError:
        return DEFAULT_LOG_LEVEL


def _with_application(run: Callable[[Application, argparse.Namespace], int]) -> Callable[..., int]:
    """Build the handler that runs a command with the application built from the environment."""

    def handler(args: argparse.Namespace) -> int:
        try:
            application = build_application(load_settings())
        except KpError as exc:
            sys.stderr.write(f"kp {args.command}: {exc}\n")
            return 2
        try:
            return run(application, args)
        finally:
            application.close()

    return handler


def _run_sweep(application: Application, args: argparse.Namespace) -> int:
    status = sweep_cli.run_sweep_command(args, application.sweep_runtime())
    if status != 0 or args.freshness:
        return status
    report = application.after_sweep()
    sys.stdout.write(
        f"links: repository {report.repository.opened if report.repository else 0} opened, "
        f"{report.citations} citations noted, guessed {report.proposed} proposed / "
        f"{report.review} for review / {report.dropped} not kept\n"
    )
    return 0


def _run_draft_spec(application: Application, args: argparse.Namespace) -> int:
    return writeback_cli.run(args, runtime=application.draft_runtime())


_sweep = _with_application(_run_sweep)
_draft_spec = _with_application(_run_draft_spec)


def _add_merge_spec(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    parser = subparsers.add_parser(
        "merge-spec",
        help="Merge a story's spec pull request in the local spec repository (stands in for a "
        "reviewer; the next sweep loads the merged spec back)",
    )
    parser.add_argument("story_key", help="Tracker key of the story, e.g. ABC-123")
    parser.set_defaults(handler=_with_application(_run_merge_spec))


def _run_merge_spec(application: Application, args: argparse.Namespace) -> int:
    try:
        merged = application.merge_spec(args.story_key)
    except KpError as exc:
        sys.stderr.write(f"kp merge-spec: {exc}\n")
        return 1
    state = "merged" if merged.merged else "was already merged"
    sys.stdout.write(
        f"{merged.branch} {state} at {merged.merged_at.isoformat()}; run 'kp sweep' to load the "
        "merged spec back as knowledge\n"
    )
    return 0


def _add_init_db(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    parser = subparsers.add_parser(
        "init-db", help="Create the tables, and optionally load the governed templates"
    )
    parser.add_argument(
        "--templates",
        type=Path,
        default=None,
        metavar="DIR",
        help="Folder of governed template files (*.md with front matter) to load",
    )
    parser.set_defaults(handler=_with_application(_run_init_db))


def _run_init_db(application: Application, args: argparse.Namespace) -> int:
    try:
        application.database.create_all()
        loaded = application.load_templates(args.templates) if args.templates else 0
    except KpError as exc:
        sys.stderr.write(f"kp init-db: {exc}\n")
        return 1
    sys.stdout.write(f"database ready; {loaded} templates loaded\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
