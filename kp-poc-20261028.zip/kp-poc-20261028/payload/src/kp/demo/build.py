"""The build phases of the demo: sweep, ingest, index, link, publish.

Everything goes through :class:`kp.app.Application`, the same object the command line uses, so
the demo shows what the platform does and not a script that imitates it.
"""

from __future__ import annotations

from dataclasses import dataclass

from kp.adapters.publishers import PublisherKind
from kp.app import AfterSweepReport, Application
from kp.demo.model import PipelineFacts
from kp.demo.reviewed_specs import seed_merged_specs
from kp.demo.staging import StagedData
from kp.domain import SourceKind
from kp.publish import PublicationResult
from kp.sweep import SweepSummary


@dataclass(frozen=True)
class BuildRun:
    """What the build phases returned, for the week checks to look at."""

    first_sweep: SweepSummary
    second_sweep: SweepSummary
    after_sweep: AfterSweepReport
    publication: PublicationResult
    templates_loaded: int
    publisher: PublisherKind
    specs_merged_before: int = 0

    def facts(self, demo_date: str) -> PipelineFacts:
        """Condense the run into the lines the report opens with.

        :param demo_date: The date the demo ran at
        :return: The facts
        """
        after = self.after_sweep
        steps = (
            (
                "Sweep of all five sources",
                f"{self.first_sweep.outcome.value}; {self.first_sweep.versions_recorded} item "
                f"versions recorded, {len(self.first_sweep.work_items)} handed to the parsers",
            ),
            (
                "Spec repository (specs a person merged before the first sweep)",
                f"{self.specs_merged_before} merged, "
                f"{len(self.first_sweep.loaded_specs)} loaded back as knowledge: "
                + (
                    ", ".join(
                        f"{loaded.spec_key} for {loaded.story_key} cites "
                        f"{len(loaded.clause_refs)} clause(s) and {len(loaded.requirement_ids)} "
                        "register row(s)"
                        for loaded in self.first_sweep.loaded_specs
                    )
                    or "none"
                ),
            ),
            (
                "Second Jira export (a board move and a criteria change)",
                f"{self.second_sweep.versions_recorded} versions recorded, "
                f"{len(self.second_sweep.work_items)} reprocessed",
            ),
            (
                "Code repository links",
                f"{self.after_sweep.repository.opened if self.after_sweep.repository else 0} "
                f"stated links opened, {self.after_sweep.citations} clause citations noted",
            ),
            (
                "Guessed links",
                (
                    f"{after.proposed} proposed, {after.review} for review, "
                    f"{after.dropped} not kept; guessed share {after.guessed_share:.0%}"
                )
                if after.guessed
                else "no edition in force",
            ),
            (
                "Knowledge version",
                f"{self.publication.version.version_id} "
                f"{'published' if self.publication.published else 'NOT published'} "
                f"({self.publication.version.item_count} items)",
            ),
        )
        publication = tuple(
            (
                check.severity.value,
                check.name,
                f"{'PASS' if check.passed else 'FAIL'} {check.detail}",
            )
            for check in self.publication.version.checks
        )
        return PipelineFacts(
            demo_date=demo_date,
            publisher=self.publisher.value,
            steps=steps,
            publication=publication,
        )


def run_build(application: Application, staged: StagedData) -> BuildRun:
    """Run the build phases in order.

    :param application: The application, with its database empty
    :param staged: The staged dataset
    :return: What each phase returned
    """
    application.database.create_all()
    templates = application.load_templates(staged.templates)
    merged_before = seed_merged_specs(application, staged)
    first = application.sweep()
    staged.reveal_second_jira_export()
    second = application.sweep([SourceKind.JIRA])
    after = application.after_sweep()
    publication = application.publish_knowledge()
    return BuildRun(
        first_sweep=first,
        second_sweep=second,
        after_sweep=after,
        publication=publication,
        templates_loaded=templates,
        publisher=application.writers().kind,
        specs_merged_before=merged_before,
    )
