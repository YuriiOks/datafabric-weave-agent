"""Stage the synthetic dataset in a working folder, shaped the way the readers expect it.

The register is a spreadsheet that sits beside the library in the dataset, not inside it. The
document library reader governs what it reads: a document needs a sidecar with the five
details and an approval status. Staging copies the dataset and gives the register its sidecar,
so the register enters through the same approval gate as every other document.

Jira is staged in two steps so the demo can show that a board move causes no rework: the first
export first, the second export on request.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Final

import yaml

import kp
from kp.errors import ConfigurationError
from kp.testing.dataset import GROUND_TRUTH_FILE, SyntheticDataset, load_dataset

REGISTER_SIDECAR: Final = {
    "approval_status": "approved",
    "authority": "Example Scheme",
    "classification": "internal",
    "content_owner": "owner-role-payments",
    "document_type": "register",
    "domain": "payments",
    "item_id": "requirements-register",
    "modified_at": "2026-09-05T09:00:00+00:00",
    "version": "1",
}
_DAYS_AFTER_LAST_EDITION: Final = 4
_DEMO_HOUR: Final = 9
_DATASET_FOLDERS: Final = ("fixtures", "generated")


@dataclass(frozen=True)
class StagedData:
    """Where the staged folders are.

    :ivar root: The staged copy of the dataset.
    :ivar dataset: The dataset's ground truth, with paths under :attr:`root`.
    :ivar library: The staged document library (documents plus the register).
    :ivar jira: The staged Jira export folder (the first export only until revealed).
    :ivar second_jira_export: The second export, still outside :attr:`jira`.
    """

    root: Path
    dataset: SyntheticDataset
    library: Path
    jira: Path
    second_jira_export: Path

    @property
    def regulatory(self) -> Path:
        """The regulatory repository folder."""
        return self.root / "regulatory_repo"

    @property
    def code_repo(self) -> Path:
        """The code repository folder."""
        return self.root / "code_repo"

    @property
    def spec_repo(self) -> Path:
        """The specs a person already merged (put into the spec repository before the sweep)."""
        return self.root / "spec_repo"

    @property
    def confluence(self) -> Path:
        """The Confluence export folder."""
        return self.root / "confluence"

    @property
    def templates(self) -> Path:
        """The governed templates folder."""
        return self.root / "templates"

    @property
    def identity_mapping(self) -> Path:
        """The written identity mapping."""
        return self.root / "identity" / "identity-mapping.yaml"

    def reveal_second_jira_export(self) -> Path:
        """Put the second Jira export beside the first, as a tracker would after a day.

        :return: The export's path in the staged Jira folder
        """
        return Path(shutil.copy2(self.second_jira_export, self.jira))

    def demo_instant(self) -> datetime:
        """The moment the demo runs at: a few days after the newest edition takes effect.

        The editions' effective dates are in the future of the dataset's own calendar, and the
        edition in force decides which clauses a question reads. Running the demo after the
        newest edition took effect makes the date explicit instead of depending on the day it
        is run.

        :return: 09:00 UTC, four days after the latest effective date
        """
        latest = max(_effective_dates(self.regulatory))
        day = latest + timedelta(days=_DAYS_AFTER_LAST_EDITION)
        return datetime(day.year, day.month, day.day, _DEMO_HOUR, tzinfo=UTC)


def find_dataset(explicit: Path | None) -> Path:
    """Locate the synthetic dataset to demonstrate on.

    :param explicit: A folder given on the command line, if any
    :return: A folder holding ``ground_truth.json``
    :raises kp.errors.ConfigurationError: If none is found
    """
    candidates = [explicit] if explicit is not None else _bundled_candidates()
    for candidate in candidates:
        if candidate is not None and (candidate / GROUND_TRUTH_FILE).is_file():
            return candidate
    raise ConfigurationError(
        "No synthetic dataset found: pass --data DIR (a folder with ground_truth.json); "
        "regenerate one with 'python -m kp.testing.regenerate DIR'"
    )


def _bundled_candidates() -> list[Path]:
    package = Path(kp.__file__).resolve().parent
    return [parent.joinpath(*_DATASET_FOLDERS) for parent in package.parents[:3]]


def stage(source: Path, work: Path) -> StagedData:
    """Copy a dataset into ``work`` and prepare it for the readers.

    :param source: The dataset folder (with ``ground_truth.json``)
    :param work: The working folder; ``data`` below it is replaced
    :return: The staged folders
    """
    root = work / "data"
    if root.exists():
        shutil.rmtree(root)
    shutil.copytree(source, root)
    library = root / "library"
    register = root / "register" / "requirements-register.xlsx"
    shutil.copy2(register, library / register.name)
    sidecar = library / "requirements-register.meta.json"
    sidecar.write_text(json.dumps(REGISTER_SIDECAR, sort_keys=True, indent=2) + "\n", "utf-8")
    dataset = load_dataset(root)
    second = root / dataset.truth.stories.second_export
    held_back = work / "held-back" / second.name
    held_back.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(second, held_back)
    return StagedData(
        root=root,
        dataset=dataset,
        library=library,
        jira=root / "jira",
        second_jira_export=held_back,
    )


def _effective_dates(regulatory: Path) -> list[date]:
    dates = []
    for manifest in sorted(regulatory.glob("*/edition.yaml")):
        data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
        dates.append(date.fromisoformat(str(data["effective_date"])))
    if not dates:
        raise ConfigurationError("The dataset has no regulatory editions")
    return dates
