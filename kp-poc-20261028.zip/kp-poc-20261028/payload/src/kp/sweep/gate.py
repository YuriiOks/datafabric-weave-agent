"""The approval gate: decides what a fetched item version may become.

The gate is a pure function of the source and the metadata a reader reports. It reads the
source's own approval signals from ``ItemMetadata.attributes``; the keys are the ones named in
``kp.sources.attributes`` plus the spec markers below (the five document details use the
names in ``kp.domain.DETAIL_NAMES``). Source readers must report these keys:

=================  ====================================================================
Source             Attributes the gate reads
=================  ====================================================================
document library   ``approval_status`` (``approved`` / ``draft`` / ``withdrawn``), the five
                   document details, optional ``effective_date``
Confluence         ``labels`` (list of strings), ``state`` (``draft`` marks a draft
                   version), optional ``domain``
regulatory repo    ``merged`` (False when the change is not merged), ``effective_date``
                   (required), optional ``domain``
GitHub             ``merged`` (False when not merged); spec files also carry ``story_key``
                   (then ``merged`` must be True, an unstated flag keeps the file pending),
                   optional ``spec_id``, ``merged_at``, ``machine_authored``, ``template``
                   (``<template id>@<version>``). The spec repository reader
                   (``kp.sources.spec_repo``) reports these for every merged spec file.
Jira               none (every story version is admitted; board status is not approval)
=================  ====================================================================

For every source ``machine_authored`` (bool) sets the machine-authored mark. Versions of one
item share ``item_id``; supersession is decided within ``(source, item_id)``.

A document library item whose approval status is absent or not one of the known words is
pending, not silently parked: when it also lacks required details (or its sidecar) it is
non-conforming and a review item names the missing details and the owner. The
``superseded_from`` and ``withdrawn_from`` dates a regulatory manifest reports are not read
here: supersession follows the newer edition's effective date (``kp.sweep.series``) and
withdrawal follows the item disappearing or losing approval.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, date, datetime
from enum import Enum, auto

from pydantic import JsonValue

from kp.domain import ApprovalState, DocumentDetails, ReviewKind, SourceKind
from kp.domain.base import DomainModel
from kp.sources import attributes as attr
from kp.sources.base import ItemMetadata

ATTR_MERGED_AT = "merged_at"
ATTR_MACHINE_AUTHORED = "machine_authored"
ATTR_STORY_KEY = "story_key"
ATTR_SPEC_ID = "spec_id"
ATTR_TEMPLATE = "template"

EFFECTIVE_DATE_DETAIL = attr.EFFECTIVE_DATE
STATUS_DETAIL = attr.APPROVAL_STATUS

DEFAULT_DOCUMENT_TYPES: frozenset[str] = frozenset(
    {"guide", "procedure", "policy", "standard", "specification", "register", "rulebook"}
)
_GOVERNED_SOURCES: frozenset[SourceKind] = frozenset({SourceKind.DOCUMENT_LIBRARY})
_DATED_SOURCES: frozenset[SourceKind] = frozenset({SourceKind.REGULATORY_REPO})
_MERGE_GATED_SOURCES: frozenset[SourceKind] = frozenset(
    {SourceKind.GITHUB, SourceKind.REGULATORY_REPO}
)
_DRAFT_STATE = "draft"


class _Signal(Enum):
    """What the source itself says about approval, before conformance checks."""

    APPROVED = auto()
    PENDING = auto()
    EXCLUDED = auto()
    WITHDRAWN = auto()


class ReviewRequest(DomainModel):
    """The review item a decision calls for: which document, what is missing, who owns it."""

    kind: ReviewKind
    detail: str
    missing_details: tuple[str, ...] = ()
    content_owner: str | None = None


class SpecMarker(DomainModel):
    """Marks a GitHub item as a spec file merged for a story."""

    story_key: str
    spec_id: str | None = None
    merged_at: datetime | None = None
    template: str | None = None


class Decision(DomainModel):
    """The gate's verdict on one item version."""

    state: ApprovalState
    details: DocumentDetails = DocumentDetails()
    effective_date: date | None = None
    machine_authored: bool = False
    review: ReviewRequest | None = None
    spec: SpecMarker | None = None


Attributes = Mapping[str, JsonValue]


def _text(attributes: Attributes, key: str) -> str | None:
    value = attributes.get(key)
    return value.strip() or None if isinstance(value, str) else None


def _flag(attributes: Attributes, key: str) -> bool | None:
    value = attributes.get(key)
    return value if isinstance(value, bool) else None


def _strings(attributes: Attributes, key: str) -> tuple[str, ...]:
    value = attributes.get(key)
    if not isinstance(value, list):
        return ()
    return tuple(item for item in value if isinstance(item, str))


def _moment(attributes: Attributes, key: str) -> datetime | None:
    text = _text(attributes, key)
    if text is None:
        return None
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)


def _day(attributes: Attributes, key: str) -> date | None:
    moment = _moment(attributes, key)
    return moment.date() if moment is not None else None


def _details(attributes: Attributes) -> DocumentDetails:
    return DocumentDetails(
        document_type=_text(attributes, "document_type"),
        domain=_text(attributes, "domain"),
        authority=_text(attributes, "authority"),
        classification=_text(attributes, "classification"),
        content_owner=_text(attributes, "content_owner"),
    )


class ApprovalGate:
    """Decides admitted / pending / non-conforming / excluded / withdrawn for a version.

    :param approved_label: The Confluence label that marks a page version as approved
    :param document_types: Document types the processors know; anything else is held
    """

    def __init__(
        self,
        *,
        approved_label: str = "approved",
        document_types: frozenset[str] = DEFAULT_DOCUMENT_TYPES,
    ) -> None:
        self._approved_label = approved_label.lower()
        self._document_types = frozenset(name.lower() for name in document_types)

    def decide(self, source: SourceKind, metadata: ItemMetadata) -> Decision:
        """Decide what a fetched version may become.

        :param source: Where the version came from
        :param metadata: What the reader reported about it
        :return: The approval state plus the details, dates and review the decision implies
        """
        attributes = metadata.attributes
        details = _details(attributes)
        effective = _day(attributes, attr.EFFECTIVE_DATE) or _day(attributes, ATTR_MERGED_AT)
        base = Decision(
            state=ApprovalState.PENDING,
            details=details,
            effective_date=effective,
            machine_authored=_flag(attributes, ATTR_MACHINE_AUTHORED) is True,
            spec=self._spec_marker(source, attributes),
        )
        signal = self._signal(source, attributes)
        if signal is _Signal.PENDING and source in _GOVERNED_SOURCES:
            held = self._unstated_status_review(metadata, details)
            if held is not None:
                return base.model_copy(
                    update={"state": ApprovalState.NON_CONFORMING, "review": held}
                )
        if signal is not _Signal.APPROVED:
            return base.model_copy(update={"state": _UNAPPROVED[signal]})
        review = self._conformance_review(source, metadata, details, effective)
        if review is None:
            return base.model_copy(update={"state": ApprovalState.ADMITTED})
        state = (
            ApprovalState.PENDING
            if review.kind is ReviewKind.UNKNOWN_DOCUMENT_TYPE
            else ApprovalState.NON_CONFORMING
        )
        return base.model_copy(update={"state": state, "review": review})

    def _signal(self, source: SourceKind, attributes: Attributes) -> _Signal:
        if source is SourceKind.DOCUMENT_LIBRARY:
            status = (_text(attributes, attr.APPROVAL_STATUS) or "").lower()
            return _LIBRARY_STATUS.get(status, _Signal.PENDING)
        if source is SourceKind.CONFLUENCE:
            if (_text(attributes, attr.WORKFLOW_STATE) or "").lower() == _DRAFT_STATE:
                return _Signal.EXCLUDED
            labels = {label.lower() for label in _strings(attributes, attr.LABELS)}
            return _Signal.APPROVED if self._approved_label in labels else _Signal.PENDING
        if source in _MERGE_GATED_SOURCES:
            merged = _flag(attributes, attr.MERGED)
            if merged is False:
                return _Signal.EXCLUDED
            if merged is None and self._spec_marker(source, attributes) is not None:
                return _Signal.PENDING
        return _Signal.APPROVED

    def _unstated_status_review(
        self, metadata: ItemMetadata, details: DocumentDetails
    ) -> ReviewRequest | None:
        """Review for a governed document that is not approved and is also incomplete."""
        missing = details.missing()
        if _text(metadata.attributes, attr.APPROVAL_STATUS) is None:
            missing = (*missing, STATUS_DETAIL)
        return self._missing_review(metadata, details, missing)

    @staticmethod
    def _missing_review(
        metadata: ItemMetadata, details: DocumentDetails, missing: tuple[str, ...]
    ) -> ReviewRequest | None:
        if not missing:
            return None
        detail = f"Document '{metadata.title}' is missing: {', '.join(missing)}"
        if metadata.attributes.get(attr.SIDECAR_PRESENT) is False:
            detail += " (no metadata sidecar found)"
        return ReviewRequest(
            kind=ReviewKind.MISSING_DETAIL,
            detail=detail,
            missing_details=missing,
            content_owner=details.content_owner,
        )

    def _conformance_review(
        self,
        source: SourceKind,
        metadata: ItemMetadata,
        details: DocumentDetails,
        effective: date | None,
    ) -> ReviewRequest | None:
        missing = details.missing() if source in _GOVERNED_SOURCES else ()
        if source in _DATED_SOURCES and effective is None:
            missing = (*missing, EFFECTIVE_DATE_DETAIL)
        review = self._missing_review(metadata, details, missing)
        if review is not None:
            return review
        document_type = (details.document_type or "").lower()
        if source in _GOVERNED_SOURCES and document_type not in self._document_types:
            return ReviewRequest(
                kind=ReviewKind.UNKNOWN_DOCUMENT_TYPE,
                detail=(
                    f"Document '{metadata.title}' has unknown document type "
                    f"'{details.document_type}' and is held, not processed"
                ),
                content_owner=details.content_owner,
            )
        return None

    @staticmethod
    def _spec_marker(source: SourceKind, attributes: Attributes) -> SpecMarker | None:
        story_key = _text(attributes, ATTR_STORY_KEY)
        if source is not SourceKind.GITHUB or story_key is None:
            return None
        return SpecMarker(
            story_key=story_key,
            spec_id=_text(attributes, ATTR_SPEC_ID),
            merged_at=_moment(attributes, ATTR_MERGED_AT),
            template=_text(attributes, ATTR_TEMPLATE),
        )


_LIBRARY_STATUS: dict[str, _Signal] = {
    "approved": _Signal.APPROVED,
    "draft": _Signal.EXCLUDED,
    "withdrawn": _Signal.WITHDRAWN,
}
_UNAPPROVED: dict[_Signal, ApprovalState] = {
    _Signal.PENDING: ApprovalState.PENDING,
    _Signal.EXCLUDED: ApprovalState.EXCLUDED,
    _Signal.WITHDRAWN: ApprovalState.WITHDRAWN,
}
