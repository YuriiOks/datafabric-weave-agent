"""Errors of the web UI, and how any platform error is shown to a person.

A page never shows an exception's arguments (they may echo what was asked). It shows one of four
states, each with a plain sentence: forbidden, invalid input, not found, or unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from kp.errors import AccessForbiddenError, InvalidClauseRefError, KpError, TemplateNotFoundError
from kp.links import NoEditionInForceError as LinksNoEditionInForceError
from kp.links import UnknownClauseError
from kp.search import ClauseNotFoundError
from kp.search import NoEditionInForceError as SearchNoEditionInForceError
from kp.tools import InvalidToolArgumentsError, LinkStoreUnavailableError, NoEditionInForceError
from kp.tools import RuleNotFoundError as ToolRuleNotFoundError
from kp.writeback import StoryNotFoundError


class WebError(KpError):
    """Base class of failures raised by the web UI itself."""


class InvalidInputError(WebError):
    """A value typed into a form is not usable. The message says what to enter instead."""


class ProblemKind(StrEnum):
    """The four states a page can be in when it cannot answer."""

    FORBIDDEN = "forbidden"
    INVALID = "invalid"
    MISSING = "missing"
    UNAVAILABLE = "unavailable"


_STATUS = {
    ProblemKind.FORBIDDEN: 403,
    ProblemKind.INVALID: 400,
    ProblemKind.MISSING: 404,
    ProblemKind.UNAVAILABLE: 503,
}
_TITLES = {
    ProblemKind.FORBIDDEN: "Forbidden",
    ProblemKind.INVALID: "Check what you entered",
    ProblemKind.MISSING: "Nothing found",
    ProblemKind.UNAVAILABLE: "Not available right now",
}
_MISSING_TYPES = (
    NoEditionInForceError,
    LinksNoEditionInForceError,
    SearchNoEditionInForceError,
    ToolRuleNotFoundError,
    ClauseNotFoundError,
    UnknownClauseError,
    StoryNotFoundError,
    TemplateNotFoundError,
)


@dataclass(frozen=True, slots=True)
class Problem:
    """Why a page could not answer, in words a person can act on.

    :ivar kind: Which of the four states this is.
    :ivar message: One plain sentence.
    :ivar heading: A heading that replaces the state's default one, when the default would mislead.
    """

    kind: ProblemKind
    message: str
    heading: str | None = None

    @property
    def title(self) -> str:
        """The heading of the state."""
        return self.heading or _TITLES[self.kind]

    @property
    def status_code(self) -> int:
        """The HTTP status the state is served with."""
        return _STATUS[self.kind]


def problem_from(error: KpError) -> Problem:
    """Describe a platform error without echoing what was asked.

    :param error: Any deliberate platform error
    :return: The state to show
    """
    if isinstance(error, AccessForbiddenError):
        return Problem(
            ProblemKind.FORBIDDEN,
            "You do not have access to this material. This is a refusal, not an empty result, "
            "and it has been recorded.",
        )
    if isinstance(error, InvalidInputError):
        return Problem(ProblemKind.INVALID, str(error))
    if isinstance(error, InvalidToolArgumentsError | InvalidClauseRefError):
        return Problem(
            ProblemKind.INVALID,
            "The value entered is not valid. Use a clause number such as 4.2.1 and dates as "
            "YYYY-MM-DD.",
        )
    if isinstance(error, _MISSING_TYPES):
        return Problem(ProblemKind.MISSING, str(error))
    if isinstance(error, LinkStoreUnavailableError):
        return Problem(ProblemKind.UNAVAILABLE, "The link store cannot be reached.")
    return Problem(
        ProblemKind.UNAVAILABLE,
        f"The request could not be completed ({type(error).__name__}); see the server log.",
    )
