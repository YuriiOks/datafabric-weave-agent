"""The dry-run spec publisher: one pull request record per branch, kept in a small file."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest

from kp.adapters.dry_run_publisher import DryRunSpecPublisher, DryRunStateError
from kp.clock import FixedClock
from kp.writeback import (
    BranchNotPermittedError,
    PublishError,
    PublishRequest,
    RepositoryNotPermittedError,
)

REPOSITORY = "example-org/example-specs"


def _request(branch: str = "spec/pay-1", content: str = "# Spec\n") -> PublishRequest:
    return PublishRequest(
        repository=REPOSITORY,
        branch=branch,
        path="specs/PAY-1.md",
        content=content,
        commit_message="Draft spec",
        pr_title="Spec for PAY-1",
        pr_body="body",
    )


def test_the_first_publication_opens_a_record_with_a_commit(tmp_path: Path) -> None:
    result = DryRunSpecPublisher(tmp_path / "records.json", repository=REPOSITORY).publish(
        _request()
    )

    assert (result.created, result.committed) == (True, True)
    assert result.pr_url == "dry-run-pr:1"
    assert len(result.commit_sha) == 40


def test_the_same_content_again_is_the_same_record_and_no_new_commit(tmp_path: Path) -> None:
    publisher = DryRunSpecPublisher(tmp_path / "records.json")
    first = publisher.publish(_request())

    again = publisher.publish(_request())

    assert (again.created, again.committed) == (False, False)
    assert again.pr_url == first.pr_url


def test_changed_content_updates_the_same_record_with_a_new_commit(tmp_path: Path) -> None:
    publisher = DryRunSpecPublisher(tmp_path / "records.json")
    first = publisher.publish(_request())

    changed = publisher.publish(_request(content="# Spec v2\n"))

    assert (changed.created, changed.committed) == (False, True)
    assert changed.pr_url == first.pr_url
    assert changed.commit_sha != first.commit_sha


def test_records_survive_a_new_publisher_and_numbers_continue(tmp_path: Path) -> None:
    path = tmp_path / "records.json"
    DryRunSpecPublisher(path).publish(_request())

    second = DryRunSpecPublisher(path).publish(_request(branch="spec/pay-2"))
    repeat = DryRunSpecPublisher(path).publish(_request())

    assert second.pr_url == "dry-run-pr:2"
    assert repeat.created is False


def test_another_repository_and_the_base_branch_are_refused(tmp_path: Path) -> None:
    publisher = DryRunSpecPublisher(tmp_path / "records.json", repository="other/repo")

    with pytest.raises(RepositoryNotPermittedError):
        publisher.publish(_request())
    with pytest.raises(BranchNotPermittedError):
        DryRunSpecPublisher(tmp_path / "r2.json").publish(_request(branch="main"))


def test_an_unreadable_record_file_is_a_typed_error(tmp_path: Path) -> None:
    path = tmp_path / "records.json"
    path.write_text("not json", encoding="utf-8")

    with pytest.raises(DryRunStateError):
        DryRunSpecPublisher(path).publish(_request())


def _clock(day: int = 2) -> FixedClock:
    return FixedClock(datetime(2026, 11, day, 10, 0, tzinfo=UTC))


def test_merging_marks_the_record_merged_and_lists_the_file_with_the_merge_date(
    tmp_path: Path,
) -> None:
    publisher = DryRunSpecPublisher(tmp_path / "records.json", clock=_clock())
    publisher.publish(_request(content="# Spec\n"))
    assert publisher.merged_specs() == []

    merged = publisher.merge("spec/pay-1")

    assert (merged.merged, merged.path) == (True, "specs/PAY-1.md")
    (listed,) = publisher.merged_specs()
    assert (listed.path, listed.content) == ("specs/PAY-1.md", b"# Spec\n")
    assert listed.merged_at == merged.merged_at == datetime(2026, 11, 2, 10, 0, tzinfo=UTC)


def test_merging_again_changes_nothing_and_a_merged_record_takes_no_more_content(
    tmp_path: Path,
) -> None:
    publisher = DryRunSpecPublisher(tmp_path / "records.json", clock=_clock())
    publisher.publish(_request())
    first = publisher.merge("spec/pay-1")

    again = publisher.merge("spec/pay-1")

    assert (again.merged, again.merged_at) == (False, first.merged_at)
    with pytest.raises(PublishError, match="no longer open"):
        publisher.publish(_request(content="# Changed\n"))


def test_the_newest_merge_of_a_file_is_the_one_listed(tmp_path: Path) -> None:
    path = tmp_path / "records.json"
    DryRunSpecPublisher(path, clock=_clock(2)).publish(_request(content="# First\n"))
    DryRunSpecPublisher(path, clock=_clock(2)).merge("spec/pay-1")
    later = DryRunSpecPublisher(path, clock=_clock(5))
    later.publish(_request(branch="people/edit", content="# Edited\n"))
    later.merge("people/edit")

    (listed,) = later.merged_specs()

    assert listed.content == b"# Edited\n"
    assert listed.merged_at.day == 5


def test_merging_an_unknown_branch_is_refused(tmp_path: Path) -> None:
    with pytest.raises(PublishError, match="no open pull request"):
        DryRunSpecPublisher(tmp_path / "records.json").merge("spec/none")


def test_records_written_before_merging_existed_stay_readable(tmp_path: Path) -> None:
    path = tmp_path / "records.json"
    path.write_text('{"spec/pay-1": {"number": 1, "commit_sha": "a"}}\n', encoding="utf-8")
    publisher = DryRunSpecPublisher(path)

    assert publisher.merged_specs() == []
    assert publisher.publish(_request()).created is False
