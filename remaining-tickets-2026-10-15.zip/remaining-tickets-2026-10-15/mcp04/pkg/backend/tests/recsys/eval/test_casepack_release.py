"""Release evidence: digests, approvals and blockers, and never a promotion claim."""

from __future__ import annotations

import unittest
from datetime import UTC, datetime

from app.recsys.eval.casepack.cases import RelevanceLabel
from app.recsys.eval.casepack.decisions import ReviewDecision
from app.recsys.eval.casepack.lineage import CasePackError
from app.recsys.eval.casepack.profiles import MCP_PROFILE
from app.recsys.eval.casepack.release import (
    Approval,
    ApprovalState,
    ApprovalSubject,
    build_release_evidence,
    render_release_evidence,
)
from app.recsys.eval.casepack.report import CaseObservation, ObservedOutcome, RunStatus
from app.recsys.eval.casepack.split import (
    FeedbackEntry,
    FeedbackPurpose,
    Partition,
    SplitManifest,
    freeze_final,
)

from . import casepack_support as support
from . import mcp_casepack_support as mcp


def _decision(decision_id: str, case_id: str, labels: dict[str, RelevanceLabel]):
    return ReviewDecision(
        decision_id=decision_id,
        case_id=case_id,
        reviewer="reviewer-a",
        decided_at=datetime(2026, 10, 1, tzinfo=UTC),
        decision_reference="review-log-1",
        labels=labels,
    )


def _granted(subject: ApprovalSubject) -> Approval:
    return Approval(
        subject=subject,
        state=ApprovalState.granted,
        decided_by="owner-a",
        decision_reference=f"approval-{subject.value}",
    )


class ReleaseEvidenceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.corpus = mcp.mcp_corpus()
        self.pack = support.pack(mcp.mcp_cases(self.corpus.lineage), self.corpus)
        assignments = {case.group_id: Partition.development for case in self.pack.cases}
        assignments["g-final"] = Partition.final_test
        split = SplitManifest(
            seed="seed-1", weights={Partition.development: 1}, assignments=assignments
        )
        self.split = freeze_final(self.pack.cases, split)
        self.decisions = [
            _decision("d-1", "mcp-0001", {mcp.mcp_id(1): RelevanceLabel.relevant}),
            _decision("d-2", "mcp-0002", {mcp.mcp_id(2): RelevanceLabel.partially_relevant}),
        ]
        lineage = self.corpus.lineage.digest()
        self.observations = [
            CaseObservation(
                case_id="mcp-0001",
                lineage_digest=lineage,
                status=RunStatus.completed,
                outcome=ObservedOutcome.ranked,
                returned_ids=(mcp.mcp_id(1),),
            ),
            CaseObservation(
                case_id="mcp-0002",
                lineage_digest=lineage,
                status=RunStatus.completed,
                outcome=ObservedOutcome.ranked,
                returned_ids=(mcp.mcp_id(2),),
            ),
        ]

    def _evidence(self, approvals, feedback=()):
        return build_release_evidence(
            self.pack,
            self.corpus,
            self.split,
            self.observations,
            self.decisions,
            approvals,
            MCP_PROFILE,
            run_reference="replay-run-1",
            feedback=feedback,
        )

    def test_unrecorded_required_approvals_are_open_blockers(self) -> None:
        evidence = self._evidence([])
        self.assertEqual(
            set(evidence.open_approvals),
            {
                ApprovalSubject.domain_reviewers,
                ApprovalSubject.shared_input_contract,
                ApprovalSubject.authorised_evidence,
            },
        )
        self.assertIn("approval open: domain_reviewers", evidence.blockers)
        self.assertFalse(evidence.promotion_claim)

    def test_granted_approvals_leave_only_run_blockers(self) -> None:
        approvals = [
            _granted(ApprovalSubject.domain_reviewers),
            _granted(ApprovalSubject.shared_input_contract),
            _granted(ApprovalSubject.authorised_evidence),
        ]
        evidence = self._evidence(approvals)
        self.assertEqual(evidence.open_approvals, ())
        self.assertEqual(evidence.blockers, ())
        self.assertTrue(evidence.denominators.quality_claim_supported)
        self.assertFalse(evidence.promotion_claim)

    def test_a_refused_approval_blocks(self) -> None:
        refused = Approval(
            subject=ApprovalSubject.authorised_evidence,
            state=ApprovalState.refused,
            decided_by="owner-a",
            decision_reference="approval-refused-1",
        )
        evidence = self._evidence([refused])
        self.assertEqual(evidence.refused_approvals, (ApprovalSubject.authorised_evidence,))
        self.assertIn("approval refused: authorised_evidence", evidence.blockers)

    def test_approvals_name_their_decider(self) -> None:
        with self.assertRaises(ValueError):
            Approval(subject=ApprovalSubject.domain_reviewers, state=ApprovalState.granted)
        with self.assertRaises(ValueError):
            Approval(subject=ApprovalSubject.domain_reviewers, decided_by="owner-a")
        with self.assertRaisesRegex(CasePackError, "recorded twice"):
            self._evidence(
                [
                    _granted(ApprovalSubject.domain_reviewers),
                    _granted(ApprovalSubject.domain_reviewers),
                ]
            )

    def test_final_test_feedback_is_a_blocker(self) -> None:
        feedback = FeedbackEntry(
            entry_id="fb-1",
            recorded_at=datetime(2026, 10, 2, tzinfo=UTC),
            actor="engineer-a",
            purpose=FeedbackPurpose.threshold_selection,
            case_ids=("mcp-0001",),
        )
        evidence = self._evidence([], feedback=[feedback])
        self.assertIn("feedback entry fb-1 touches the final test", evidence.blockers)

    def test_a_pack_that_disagrees_with_its_decision_log_is_refused(self) -> None:
        with self.assertRaisesRegex(CasePackError, "differs from its latest"):
            build_release_evidence(
                self.pack,
                self.corpus,
                self.split,
                self.observations,
                [_decision("d-1", "mcp-0001", {mcp.mcp_id(2): RelevanceLabel.relevant})],
                [],
                MCP_PROFILE,
                run_reference="replay-run-1",
            )

    def test_render_ends_without_a_promotion_claim(self) -> None:
        text = render_release_evidence(self._evidence([]))
        self.assertIn("- Run: `replay-run-1`", text)
        self.assertIn("| domain_reviewers | open | - | - |", text)
        self.assertIn("Blocked:", text)
        self.assertTrue(text.rstrip().endswith("decision taken elsewhere."))
