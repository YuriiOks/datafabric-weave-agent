"""Assembly of the write tool set from the tools another lane provides through a port."""

from __future__ import annotations

from collections.abc import Mapping

from pydantic import JsonValue

from kp.clock import Clock
from kp.tools.access import DomainDirectory, ToolContext
from kp.tools.audit import AuditSink
from kp.tools.errors import InvalidToolArgumentsError
from kp.tools.ports import WriteToolCall, WriteToolDescriptor, WriteToolPort
from kp.tools.registry import RegisteredTool, ToolDefinition, ToolOutcome, ToolRegistry


def build_write_registry(
    port: WriteToolPort,
    directory: DomainDirectory,
    audit: AuditSink,
    *,
    clock: Clock | None = None,
) -> ToolRegistry:
    """Build a registry holding exactly the tools the write port describes.

    The write lane owns argument validation and the server-side allow-list (one repository,
    one spec path, two tracker fields). This layer adds identity, access and audit, and records
    a refusal when the port raises :class:`kp.errors.WriteNotPermittedError`.

    :param port: The write tools
    :param directory: Identity to allowed domains
    :param audit: Where call records go
    :param clock: Time source; defaults to the system clock
    :return: The registry; it contains no read tools
    """
    registry = ToolRegistry(directory, audit, clock=clock)
    for descriptor in port.describe():
        registry.register(_wrap(port, descriptor))
    return registry


def _wrap(port: WriteToolPort, descriptor: WriteToolDescriptor) -> RegisteredTool:
    def run(context: ToolContext, arguments: Mapping[str, JsonValue]) -> ToolOutcome:
        call = WriteToolCall(
            tool=descriptor.name,
            arguments=dict(arguments),
            caller=context.caller.user,
            agent=context.caller.agent,
            session_id=context.caller.session_id,
            domains=tuple(sorted(context.domains)),
        )
        try:
            result = port.invoke(call)
        except ValueError as exc:
            raise InvalidToolArgumentsError(
                f"Invalid arguments for {descriptor.name}: {exc}"
            ) from exc
        return ToolOutcome(
            payload=result.payload, items_returned=result.items_returned, spec_id=result.spec_id
        )

    return RegisteredTool(
        definition=ToolDefinition(
            name=descriptor.name,
            description=descriptor.description,
            input_schema=descriptor.input_schema,
        ),
        run=run,
    )
