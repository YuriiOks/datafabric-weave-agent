"""Denominators of one run against one case pack.

Every planned case lands in exactly one run bucket: not run, lineage mismatch, failed,
disabled, blocked, or completed with an observed outcome. A failed or disabled run is never
counted as an empty result, and an empty result is a valid empty only when a named reviewer
judged that no published component fits the need. The report counts cases; it states no
quality figure and makes no promotion claim.
"""

from __future__ import annotations

from collections.abc import Sequence
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.recsys.contracts import ComponentType
from app.recsys.eval.casepack.cases import EvaluationCase, ExpectedOutcome, Scenario
from app.recsys.eval.casepack.corpus import CorpusManifest, FieldState
from app.recsys.eval.casepack.lineage import CasePackError, enum_value
from app.recsys.eval.casepack.pack import CasePack, coverage_gaps
from app.recsys.eval.casepack.profiles import CasePackProfile
from app.recsys.eval.casepack.split import Partition, SplitManifest, verify_final


class RunStatus(str, Enum):
    """How the run of one case ended."""

    completed = "completed"
    failed = "failed"
    disabled = "disabled"
    blocked = "blocked"


class ObservedOutcome(str, Enum):
    """The outcome class a completed run reported."""

    ranked = "ranked"
    empty = "empty"
    access_filtered = "access_filtered"
    source_unavailable = "source_unavailable"


_EXPECTED_FOR: dict[ObservedOutcome, ExpectedOutcome] = {
    ObservedOutcome.ranked: ExpectedOutcome.ranked,
    ObservedOutcome.empty: ExpectedOutcome.valid_empty,
    ObservedOutcome.access_filtered: ExpectedOutcome.access_filtered,
    ObservedOutcome.source_unavailable: ExpectedOutcome.source_unavailable,
}

#: Expected outcomes that do not depend on a relevance judgement.
_JUDGEMENT_FREE = frozenset({ExpectedOutcome.access_filtered, ExpectedOutcome.source_unavailable})

_COUNTERS = (
    "not_run",
    "lineage_mismatch",
    "failed",
    "disabled",
    "blocked",
    "completed",
    "measured_ranked",
    "measured_empty",
    "valid_empty",
    "empty_where_relevant_judged",
    "access_filtered",
    "source_unavailable",
    "outcome_mismatch",
    "judged",
    "unjudged",
    "reduced_coverage",
    "gated_evidence",
    "forbidden_hit_cases",
    "forbidden_hits",
    "unpublished_id_cases",
    "excluded_id_cases",
)


class CaseObservation(BaseModel):
    """What one run reported for one case, pinned to the lineage it ran against."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    case_id: str = Field(min_length=1, max_length=16)
    lineage_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    status: RunStatus
    outcome: ObservedOutcome | None = None
    returned_ids: tuple[str, ...] = ()
    reason: str | None = Field(default=None, min_length=1, max_length=256)

    @model_validator(mode="after")
    def _outcome_follows_status(self) -> CaseObservation:
        """Only a completed run has an outcome; only a ranked outcome returns ids.

        :return: The observation.
        :raises ValueError: When status, outcome and ids disagree.
        """
        if (self.status is RunStatus.completed) != (self.outcome is not None):
            raise ValueError("a completed run reports an outcome and no other run does")
        if (self.outcome is ObservedOutcome.ranked) != bool(self.returned_ids):
            raise ValueError("a ranked outcome returns ids and no other outcome does")
        return self


class PartitionCounts(BaseModel):
    """Planned, completed and judged cases of one partition."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    planned: int = 0
    completed: int = 0
    judged: int = 0
    unjudged: int = 0


class DenominatorReport(BaseModel):
    """The denominators of one run against one case pack."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    component_type: ComponentType
    lineage_digest: str
    corpus_digest: str
    planned: int
    not_run: int
    lineage_mismatch: int
    failed: int
    disabled: int
    blocked: int
    completed: int
    measured_ranked: int
    measured_empty: int
    valid_empty: int
    empty_where_relevant_judged: int
    access_filtered: int
    source_unavailable: int
    outcome_mismatch: int
    judged: int
    unjudged: int
    reduced_coverage: int
    gated_evidence: int
    forbidden_hit_cases: int
    forbidden_hits: int
    unpublished_id_cases: int
    excluded_id_cases: int
    by_partition: dict[Partition, PartitionCounts]
    by_scenario: dict[Scenario, int]
    coverage_gaps: tuple[Scenario, ...]
    claim_blockers: tuple[str, ...]
    quality_claim_supported: bool
    promotion_claim: Literal[False] = False


def _reduced_coverage(case: EvaluationCase, corpus: CorpusManifest) -> bool:
    """Return whether a labelled component of the case lacks a usable lexical field.

    Such a case measures the baseline on reduced input; a miss there is not evidence of
    lexical non-relevance.

    :param case: The case.
    :param corpus: The corpus manifest.
    :return: ``True`` when coverage is reduced.
    """
    for component_id in case.adjudication.labels:
        entry = corpus.entry(component_id)
        if entry is None:
            continue
        if any(item.state is not FieldState.present for item in entry.observations):
            return True
    return False


def _index(
    observations: Sequence[CaseObservation], pack: CasePack
) -> dict[str, CaseObservation]:
    """Index observations by case id.

    :param observations: The run's observations.
    :param pack: The case pack.
    :return: The observations by case id.
    :raises CasePackError: When a case is observed twice or an observation names no case.
    """
    known = {case.case_id for case in pack.cases}
    indexed: dict[str, CaseObservation] = {}
    for observation in observations:
        if observation.case_id not in known:
            raise CasePackError(f"observation names unknown case {observation.case_id}")
        if observation.case_id in indexed:
            raise CasePackError(f"case {observation.case_id} is observed twice")
        indexed[observation.case_id] = observation
    return indexed


def build_report(
    pack: CasePack,
    corpus: CorpusManifest,
    split: SplitManifest,
    observations: Sequence[CaseObservation],
    profile: CasePackProfile,
) -> DenominatorReport:
    """Count one run against one case pack.

    :param pack: The case pack, already validated against the corpus.
    :param corpus: The corpus manifest the pack pins.
    :param split: The grouped split of the pack.
    :param observations: The run's observations; a case without one was not run.
    :param profile: The profile of the pack's type.
    :return: The denominator report.
    :raises CasePackError: When an observation names an unknown case or repeats one.
    """
    observed = _index(observations, pack)
    lineage = pack.lineage.digest()
    published = corpus.component_ids()
    excluded = frozenset(
        entry.component_id for entry in corpus.entries if not entry.baseline_input
    )
    counts: dict[str, int] = dict.fromkeys(_COUNTERS, 0)
    by_partition = {
        partition: dict.fromkeys(("planned", "completed", "judged", "unjudged"), 0)
        for partition in Partition
    }
    by_scenario: dict[Scenario, int] = {}
    final_open = 0
    for case in pack.cases:
        partition = split.partition_of(case.group_id)
        judged = case.adjudication.judged
        by_scenario[case.scenario] = by_scenario.get(case.scenario, 0) + 1
        by_partition[partition]["planned"] += 1
        by_partition[partition]["judged" if judged else "unjudged"] += 1
        counts["judged" if judged else "unjudged"] += 1
        counts["reduced_coverage"] += int(_reduced_coverage(case, corpus))
        counts["gated_evidence"] += len(case.gated_evidence())
        bucket = _run_bucket(observed.get(case.case_id), lineage)
        counts[bucket] += 1
        if bucket != "completed":
            final_open += int(partition is Partition.final_test)
            continue
        by_partition[partition]["completed"] += 1
        _count_outcome(case, observed[case.case_id], published, excluded, counts)
        final_open += int(partition is Partition.final_test and not judged)
    gaps = coverage_gaps(pack, profile)
    blockers = _claim_blockers(pack, split, counts, gaps, final_open)
    return DenominatorReport(
        component_type=pack.component_type,
        lineage_digest=lineage,
        corpus_digest=pack.corpus_digest,
        planned=len(pack.cases),
        by_partition={key: PartitionCounts(**value) for key, value in by_partition.items()},
        by_scenario=dict(sorted(by_scenario.items(), key=lambda item: item[0].value)),
        coverage_gaps=gaps,
        claim_blockers=blockers,
        quality_claim_supported=not blockers,
        **counts,
    )


def _run_bucket(observation: CaseObservation | None, lineage: str) -> str:
    """Place one case in its run bucket.

    :param observation: The case's observation, or ``None`` when it was not run.
    :param lineage: The pack's lineage digest.
    :return: The bucket name.
    """
    if observation is None:
        return "not_run"
    if observation.lineage_digest != lineage:
        return "lineage_mismatch"
    return observation.status.value


def _count_outcome(
    case: EvaluationCase,
    observation: CaseObservation,
    published: frozenset[str],
    excluded: frozenset[str],
    counts: dict[str, int],
) -> None:
    """Count the observed outcome of one completed case.

    :param case: The case.
    :param observation: Its completed observation.
    :param published: The component ids the pinned corpus publishes.
    :param excluded: Published ids that are not baseline input.
    :param counts: The counters to update.
    """
    outcome = observation.outcome
    judged = case.adjudication.judged
    if outcome is ObservedOutcome.ranked:
        counts["measured_ranked"] += 1
        returned = set(observation.returned_ids)
        hits = len(returned & set(case.forbidden))
        counts["forbidden_hits"] += hits
        counts["forbidden_hit_cases"] += int(hits > 0)
        counts["unpublished_id_cases"] += int(bool(returned - published))
        counts["excluded_id_cases"] += int(bool(returned & excluded))
    elif outcome is ObservedOutcome.empty:
        counts["measured_empty"] += 1
        if judged and case.expected_outcome is ExpectedOutcome.valid_empty:
            counts["valid_empty"] += 1
        elif judged and case.expected_outcome is ExpectedOutcome.ranked:
            counts["empty_where_relevant_judged"] += 1
    elif outcome is ObservedOutcome.access_filtered:
        counts["access_filtered"] += 1
    else:
        counts["source_unavailable"] += 1
    decidable = judged or case.expected_outcome in _JUDGEMENT_FREE
    if outcome is not None and decidable and _EXPECTED_FOR[outcome] is not case.expected_outcome:
        counts["outcome_mismatch"] += 1


def _claim_blockers(
    pack: CasePack,
    split: SplitManifest,
    counts: dict[str, int],
    gaps: tuple[Scenario, ...],
    final_open: int,
) -> tuple[str, ...]:
    """List why the run cannot support a quality statement.

    :param pack: The case pack.
    :param split: The split.
    :param counts: The run counters.
    :param gaps: Required scenarios the pack does not cover.
    :param final_open: Final-test cases that are not both completed and judged.
    :return: The blockers; empty only when a quality statement is supportable.
    """
    blockers = []
    finals = [
        case for case in pack.cases if split.partition_of(case.group_id) is Partition.final_test
    ]
    if not finals:
        blockers.append("the final-test partition holds no case")
    try:
        verify_final(pack.cases, split)
    except CasePackError as error:
        blockers.append(str(error))
    if final_open:
        blockers.append(f"{final_open} final-test cases are not both completed and judged")
    if gaps:
        blockers.append("required scenarios missing: " + ", ".join(item.value for item in gaps))
    if counts["lineage_mismatch"]:
        blockers.append("observations ran against another lineage")
    if counts["forbidden_hits"]:
        blockers.append("forbidden components were returned")
    if counts["unpublished_id_cases"]:
        blockers.append("components outside the pinned corpus were returned")
    if counts["excluded_id_cases"]:
        blockers.append("components excluded from baseline input were returned")
    restricted = any(case.scenario is Scenario.access_restricted for case in pack.cases)
    if restricted and pack.lineage.access_policy_revision is None:
        blockers.append("access cases need a pinned read policy")
    return tuple(blockers)


def render_report(report: DenominatorReport) -> str:
    """Render the denominator report as Markdown.

    :param report: The report.
    :return: The Markdown, ending with the explicit no-promotion statement.
    """
    rows = [
        ("Planned", report.planned),
        ("Not run", report.not_run),
        ("Lineage mismatch (not measured)", report.lineage_mismatch),
        ("Failed", report.failed),
        ("Disabled", report.disabled),
        ("Blocked", report.blocked),
        ("Completed", report.completed),
        ("Measured with results", report.measured_ranked),
        ("Measured empty", report.measured_empty),
        ("Valid empty (judged)", report.valid_empty),
        ("Empty where a relevant component was judged", report.empty_where_relevant_judged),
        ("Access filtered", report.access_filtered),
        ("Source unavailable", report.source_unavailable),
        ("Outcome class differs from expected", report.outcome_mismatch),
        ("Judged", report.judged),
        ("Unjudged", report.unjudged),
        ("Reduced input coverage", report.reduced_coverage),
        ("Evidence waiting for adjudication", report.gated_evidence),
        ("Cases with forbidden hits", report.forbidden_hit_cases),
        ("Forbidden hits", report.forbidden_hits),
        ("Cases returning unpublished ids", report.unpublished_id_cases),
        ("Cases returning excluded ids", report.excluded_id_cases),
    ]
    lines = [
        f"# Case-pack denominators: {enum_value(report.component_type)}",
        "",
        f"- Lineage: `{report.lineage_digest}`",
        f"- Corpus: `{report.corpus_digest}`",
        "",
        "| Count | Cases |",
        "|---|---|",
    ]
    lines.extend(f"| {label} | {value} |" for label, value in rows)
    lines.extend(
        [
            "",
            "| Partition | Planned | Completed | Judged | Unjudged |",
            "|---|---|---|---|---|",
        ]
    )
    for partition, item in report.by_partition.items():
        lines.append(
            f"| {partition.value} | {item.planned} | {item.completed} | {item.judged} "
            f"| {item.unjudged} |"
        )
    lines.append("")
    if report.claim_blockers:
        lines.append("Quality statement not supported:")
        lines.extend(f"- {blocker}" for blocker in report.claim_blockers)
    else:
        lines.append("Quality statement supportable on the frozen final test.")
    lines.extend(["", "No promotion claim: this report counts cases and approves nothing."])
    return "\n".join(lines) + "\n"
