"""US-23: merged specs become knowledge without triggering a new draft."""

from __future__ import annotations

from datetime import UTC, date, datetime

import pytest
from pydantic import JsonValue
from sqlalchemy import select

from kp.domain import ApprovalState, SourceKind
from kp.sources.base import ChangedItem, FetchedItem
from kp.store import schema as tables
from kp.sweep import SpecLoader, extract_clause_refs

from .conftest import Harness
from .support import ScriptedReader, entry

GITHUB = SourceKind.GITHUB
SPEC_PATH = "specs/pay-101.md"
MERGE_ONE = "2026-11-02T10:00:00+00:00"
MERGE_TWO = "2026-11-10T08:30:00+00:00"


def _spec(
    version: str,
    body: str,
    *,
    merged_at: str,
    machine_authored: bool,
    path: str = SPEC_PATH,
    story: str = "PAY-101",
) -> tuple[ChangedItem, FetchedItem]:
    attributes: dict[str, JsonValue] = {
        "merged": True,
        "story_key": story,
        "spec_id": f"SPEC-{story}",
        "merged_at": merged_at,
        "machine_authored": machine_authored,
    }
    return entry(GITHUB, path, version, content=body.encode(), attributes=attributes)


def _links(harness: Harness) -> list[dict[str, object]]:
    with harness.database.transaction() as connection:
        rows = connection.execute(select(tables.link).order_by(tables.link.c.target_key))
        return [dict(row) for row in rows.mappings()]


def test_us23_merged_spec_is_loaded_linked_to_its_story_and_clauses(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    reader.add(
        _spec(
            "a1",
            "Per 2026.1:4.2.1 and 2026.1 clause 4.2.3 the amount is limited.",
            merged_at=MERGE_ONE,
            machine_authored=True,
        )
    )

    summary = harness.sweep(reader)

    (loaded,) = summary.loaded_specs
    assert loaded.story_key == "PAY-101"
    assert loaded.clause_refs == ("2026.1:4.2.1", "2026.1:4.2.3")
    version = harness.version(GITHUB, SPEC_PATH, "a1")
    assert version.approval_state is ApprovalState.ADMITTED
    links = _links(harness)
    facts = {
        (r["source_key"], r["relation"], r["target_key"], r["kind"], r["state"]) for r in links
    }
    assert facts == {
        ("PAY-101", "specified_by", "SPEC-PAY-101", "stated", "stated"),
        ("SPEC-PAY-101", "derived_from", "2026.1:4.2.1", "stated", "stated"),
        ("SPEC-PAY-101", "derived_from", "2026.1:4.2.3", "stated", "stated"),
    }
    assert {r["valid_from"] for r in links} == {datetime(2026, 11, 2, 10, tzinfo=UTC)}
    assert all(r["valid_to"] is None for r in links)
    with harness.database.transaction() as connection:
        assert SpecLoader(connection).spec_keys_for_story("PAY-101") == ("SPEC-PAY-101",)


def test_us23_machine_authored_mark_stops_a_new_draft(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    reader.add(
        _spec("a1", "See 2026.1:4.2.1.", merged_at=MERGE_ONE, machine_authored=True),
        _spec(
            "b1",
            "See 2026.1:4.2.2.",
            merged_at=MERGE_ONE,
            machine_authored=False,
            path="specs/pay-102.md",
            story="PAY-102",
        ),
    )

    summary = harness.sweep(reader)

    by_story = {loaded.story_key: loaded for loaded in summary.loaded_specs}
    assert harness.version(GITHUB, SPEC_PATH, "a1").machine_authored is True
    assert by_story["PAY-101"].machine_authored is True
    assert by_story["PAY-101"].triggers_draft is False
    assert by_story["PAY-102"].triggers_draft is True


def test_us23_later_human_edit_replaces_the_spec_from_the_merge_date(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    reader.add(
        _spec(
            "a1",
            "Cites 2026.1:4.2.1 and 2026.1:4.2.3.",
            merged_at=MERGE_ONE,
            machine_authored=True,
        )
    )
    harness.sweep(reader)
    reader.add(
        _spec(
            "a2",
            "Cites 2026.1:4.2.1 and 2026.1:4.2.2.",
            merged_at=MERGE_TWO,
            machine_authored=False,
        )
    )

    summary = harness.sweep(reader)

    (loaded,) = summary.loaded_specs
    assert loaded.machine_authored is False
    assert loaded.triggers_draft is False
    old = harness.version(GITHUB, SPEC_PATH, "a1")
    assert old.superseded_at == date(2026, 11, 10)
    assert harness.version(GITHUB, SPEC_PATH, "a2").approval_state is ApprovalState.ADMITTED
    by_clause = {r["target_key"]: r for r in _links(harness) if r["relation"] == "derived_from"}
    assert by_clause["2026.1:4.2.1"]["valid_to"] is None
    assert by_clause["2026.1:4.2.1"]["valid_from"] == datetime(2026, 11, 2, 10, tzinfo=UTC)
    assert by_clause["2026.1:4.2.3"]["valid_to"] == datetime(2026, 11, 10, 8, 30, tzinfo=UTC)
    assert by_clause["2026.1:4.2.2"]["valid_from"] == datetime(2026, 11, 10, 8, 30, tzinfo=UTC)
    assert by_clause["2026.1:4.2.2"]["valid_to"] is None


def test_us23_loading_the_same_merged_spec_twice_adds_no_links(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB, honour_cursor=False)
    reader.add(_spec("a1", "Cites 2026.1:4.2.1.", merged_at=MERGE_ONE, machine_authored=True))
    harness.sweep(reader)
    before = _links(harness)

    summary = harness.sweep(reader)

    assert summary.loaded_specs == ()
    assert _links(harness) == before


def test_us23_spec_citing_no_clause_still_links_to_its_story(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    reader.add(_spec("a1", "No rule is cited.", merged_at=MERGE_ONE, machine_authored=True))

    summary = harness.sweep(reader)

    assert summary.loaded_specs[0].clause_refs == ()
    assert [r["relation"] for r in _links(harness)] == ["specified_by"]


def test_us23_unmerged_spec_is_not_loaded(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    unmerged = entry(
        GITHUB,
        SPEC_PATH,
        "a1",
        attributes={"merged": False, "story_key": "PAY-101", "machine_authored": True},
    )
    reader.add(unmerged)

    summary = harness.sweep(reader)

    assert summary.loaded_specs == ()
    assert _links(harness) == []


def test_us23_clause_references_are_found_in_canonical_and_spoken_form() -> None:
    text = b"Rule 2026.1 clause 4.2.1; also 2025.2:3.1. Version 1.2 is not a reference."

    assert extract_clause_refs(text) == ("2025.2:3.1", "2026.1:4.2.1")


@pytest.mark.parametrize(
    "text",
    [
        "Meeting at 09:30 on Friday.",
        "The ratio 1:2 applies.",
        "Listen on port 8080:443 only.",
        "host:8080 is the endpoint.",
        "On version 2.0 clause 3 the setting is off.",
        "Build 12026.1:4 is not an edition.",
    ],
)
def test_us23_times_ratios_ports_and_versions_are_not_clause_references(text: str) -> None:
    assert extract_clause_refs(text.encode()) == ()


def test_us23_only_real_edition_labels_are_kept_among_noise() -> None:
    text = b"At 09:30, ratio 1:2, port 8080:443, version 2.0 clause 3, but 2026.1 clause 4.2."

    assert extract_clause_refs(text) == ("2026.1:4.2",)


def test_us23_merged_spec_with_noise_links_only_to_real_clauses(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    reader.add(
        _spec(
            "a1",
            "Run at 09:30 with ratio 1:2 per 2026.1:4.2.1.",
            merged_at=MERGE_ONE,
            machine_authored=False,
        )
    )

    harness.sweep(reader)

    clause_links = [row for row in _links(harness) if row["relation"] == "derived_from"]
    assert [row["target_key"] for row in clause_links] == ["2026.1:4.2.1"]


def test_us23_spec_without_a_merge_flag_is_not_loaded(harness: Harness) -> None:
    reader = ScriptedReader(GITHUB)
    reader.add(
        entry(
            GITHUB,
            SPEC_PATH,
            "a1",
            content=b"See 2026.1:4.2.1.",
            attributes={"story_key": "PAY-101", "spec_id": "SPEC-PAY-101"},
        )
    )

    summary = harness.sweep(reader)

    assert summary.loaded_specs == ()
    assert _links(harness) == []
    assert harness.version(GITHUB, SPEC_PATH, "a1").approval_state is ApprovalState.PENDING
