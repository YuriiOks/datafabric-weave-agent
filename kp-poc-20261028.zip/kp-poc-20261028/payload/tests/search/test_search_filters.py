"""US-10 / US-11 filters: domain, version in force, as-at date and withdrawn documents.

Every filter is applied before ranking, so each test would fail if it were applied to the
ranked list instead.
"""

from __future__ import annotations

from datetime import UTC, date, datetime

import pytest
from sqlalchemy import insert, update

from kp.domain import ApprovalState, PassageType, SourceKind, Story
from kp.search import (
    ClauseNotFoundError,
    DocumentText,
    NoEditionInForceError,
    PassageStore,
    SearchSettings,
    page_passages,
    story_passages,
)
from kp.store.schema import edition, requirement, source_item, story
from search.search_support import (
    SearchWorld,
    add_source_item,
    save_passages,
)

AFTER_SWITCH = date(2026, 11, 16)
QUESTION = "inbound credit transfer currency"


def _page_document(
    item_id: str,
    text: str,
    *,
    domain: str | None = "cards",
    source: SourceKind = SourceKind.DOCUMENT_LIBRARY,
    version: str = "1",
) -> DocumentText:
    return DocumentText(source, item_id, version, text, domain=domain)


def test_us10_domain_filter_is_applied_before_ranking(world: SearchWorld) -> None:
    loud = _page_document("cards-guide", "currency currency inbound credit transfer " * 20)
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "cards-guide", "1", domain="cards")
        save_passages(connection, page_passages(loud))

    equal = SearchSettings(authority_weights={kind: 1.0 for kind in SourceKind})
    unfiltered = world.service(equal).search(QUESTION, as_at=AFTER_SWITCH, limit=1).hits
    filtered = world.service(equal).search(
        QUESTION, as_at=AFTER_SWITCH, domains=["payments"], limit=1
    )

    assert unfiltered[0].item_id == "cards-guide"
    assert len(filtered.hits) == 1
    assert filtered.hits[0].domain == "payments"
    assert filtered.hits[0].reference == "2026.1:4.2.1"


def test_us10_domain_filter_returns_only_that_domain(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "cards-guide", "1", domain="cards")
        save_passages(connection, page_passages(_page_document("cards-guide", "currency fees")))

    cards = world.service().search("currency", as_at=AFTER_SWITCH, domains=["cards"]).hits
    both = (
        world.service().search("currency", as_at=AFTER_SWITCH, domains=["cards", "payments"]).hits
    )

    assert {h.domain for h in cards} == {"cards"}
    assert {h.domain for h in both} == {"cards", "payments"}


def test_us10_passage_without_a_domain_never_matches_a_domain_filter(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "loose", "1", domain=None)
        save_passages(
            connection, page_passages(_page_document("loose", "zebracorn notes", domain=None))
        )

    assert world.service().search("zebracorn", as_at=AFTER_SWITCH).hits
    assert not world.service().search("zebracorn", as_at=AFTER_SWITCH, domains=["payments"]).hits


@pytest.mark.parametrize(
    "state",
    [
        ApprovalState.WITHDRAWN,
        ApprovalState.EXCLUDED,
        ApprovalState.PENDING,
        ApprovalState.NON_CONFORMING,
    ],
)
def test_us10_only_approved_documents_appear(world: SearchWorld, state: ApprovalState) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "draft", "1", state=state)
        save_passages(connection, page_passages(_page_document("draft", "zebracorn draft")))

    assert not world.service().search("zebracorn", as_at=AFTER_SWITCH).hits


def test_us10_an_approved_document_with_the_same_words_does_appear(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "guide", "1")
        save_passages(connection, page_passages(_page_document("guide", "zebracorn guide")))

    hits = world.service().search("zebracorn", as_at=AFTER_SWITCH).hits

    assert [h.item_id for h in hits] == ["guide"]


def test_us10_document_withdrawn_later_vanishes_from_every_date(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "guide", "1")
        save_passages(connection, page_passages(_page_document("guide", "zebracorn guide")))
    assert world.service().search("zebracorn", as_at=AFTER_SWITCH).hits

    with world.database.transaction() as connection:
        connection.execute(
            update(source_item)
            .where(source_item.c.item_id == "guide")
            .values(approval_state="withdrawn", withdrawn_at=date(2026, 11, 20))
        )

    assert not world.service().search("zebracorn", as_at=date(2026, 11, 10)).hits
    assert not world.service().search("zebracorn", as_at=date(2026, 12, 1)).hits


def test_us10_withdrawn_edition_document_never_appears_and_is_not_selected(
    world: SearchWorld,
) -> None:
    with world.database.transaction() as connection:
        connection.execute(
            update(source_item)
            .where(source_item.c.version == "2026.1")
            .values(approval_state="withdrawn")
        )
    service = world.service()

    response = service.search(QUESTION, as_at=AFTER_SWITCH)

    assert response.hits == ()
    assert response.edition_in_force is None
    with pytest.raises(NoEditionInForceError):
        service.rule_as_at("4.2.1", as_at=AFTER_SWITCH)
    with pytest.raises(ClauseNotFoundError):
        service.lookup("2026.1:4.2.1", as_at=AFTER_SWITCH)
    assert service.rule_as_at("4.2.1", as_at=date(2026, 11, 15)).ref.edition == "2025.2"


def test_us11_edition_withdrawn_from_a_date_is_not_in_force_from_then(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        connection.execute(
            update(edition)
            .where(edition.c.label == "2026.1")
            .values(withdrawn_from=date(2026, 12, 1))
        )
    service = world.service()

    assert service.rule_as_at("4.2.1", as_at=date(2026, 11, 30)).ref.edition == "2026.1"
    with pytest.raises(NoEditionInForceError):
        service.rule_as_at("4.2.1", as_at=date(2026, 12, 1))
    assert not service.search(QUESTION, as_at=date(2026, 12, 1)).hits


def test_us11_clause_passages_of_other_editions_are_not_returned(world: SearchWorld) -> None:
    before = world.service().search(QUESTION, as_at=date(2026, 11, 15), limit=50).hits
    after = world.service().search(QUESTION, as_at=AFTER_SWITCH, limit=50).hits

    assert {h.edition for h in before} == {"2025.2"}
    assert {h.edition for h in after} == {"2026.1"}


def test_us10_non_clause_passages_are_not_subject_to_the_edition_filter(
    world: SearchWorld,
) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "guide", "1")
        save_passages(connection, page_passages(_page_document("guide", "zebracorn guide")))

    for day in (date(2025, 1, 1), date(2026, 11, 15), AFTER_SWITCH):
        assert world.service().search("zebracorn", as_at=day).hits


def test_us11_story_version_in_force_follows_the_as_at_date(world: SearchWorld) -> None:
    old = Story(
        story_key="PAY-9", version="1", summary="Reject sterling transfers", domain="payments"
    )
    new = Story(
        story_key="PAY-9", version="2", summary="Accept sterling transfers", domain="payments"
    )
    with world.database.transaction() as connection:
        add_source_item(
            connection,
            SourceKind.JIRA,
            "PAY-9",
            "1",
            state=ApprovalState.SUPERSEDED,
            superseded_at=date(2026, 11, 10),
        )
        add_source_item(
            connection, SourceKind.JIRA, "PAY-9", "2", effective_date=date(2026, 11, 10)
        )
        save_passages(connection, [*story_passages(old), *story_passages(new)])

    early = world.service().search("sterling transfers", as_at=date(2026, 11, 5), limit=50).hits
    late = world.service().search("sterling transfers", as_at=date(2026, 11, 12), limit=50).hits

    assert [(h.item_id, h.version) for h in early if h.item_id == "PAY-9"] == [("PAY-9", "1")]
    assert [(h.item_id, h.version) for h in late if h.item_id == "PAY-9"] == [("PAY-9", "2")]


def test_us10_only_the_newest_admitted_version_of_an_item_is_returned(
    world: SearchWorld,
) -> None:
    with world.database.transaction() as connection:
        add_source_item(
            connection,
            SourceKind.CONFLUENCE,
            "page-7",
            "1",
            modified_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        add_source_item(
            connection,
            SourceKind.CONFLUENCE,
            "page-7",
            "2",
            modified_at=datetime(2026, 2, 1, tzinfo=UTC),
        )
        save_passages(
            connection,
            [
                *page_passages(
                    _page_document("page-7", "zebracorn first", source=SourceKind.CONFLUENCE)
                ),
                *page_passages(
                    _page_document(
                        "page-7", "zebracorn second", source=SourceKind.CONFLUENCE, version="2"
                    )
                ),
            ],
        )

    hits = world.service().search("zebracorn", as_at=AFTER_SWITCH).hits

    assert [(h.version, h.text) for h in hits] == [("2", "zebracorn second")]


def test_us10_item_not_yet_effective_is_hidden_until_its_date(world: SearchWorld) -> None:
    with world.database.transaction() as connection:
        add_source_item(
            connection, SourceKind.DOCUMENT_LIBRARY, "future", "1", effective_date=date(2027, 1, 1)
        )
        save_passages(connection, page_passages(_page_document("future", "zebracorn plan")))

    assert not world.service().search("zebracorn", as_at=AFTER_SWITCH).hits
    assert world.service().search("zebracorn", as_at=date(2027, 1, 1)).hits


def test_us10_passages_without_a_source_item_are_not_searchable(world: SearchWorld) -> None:
    unknown = _page_document("ghost", "zebracorn ghost")
    with world.database.transaction() as connection:
        PassageStore(connection).replace_item(
            unknown.source, unknown.item_id, unknown.version, page_passages(unknown)
        )

    assert not world.service().search("zebracorn", as_at=AFTER_SWITCH).hits


def test_us10_source_authority_weight_orders_equal_matches(world: SearchWorld) -> None:
    text = "quokka protocol"
    page = DocumentText(SourceKind.REGULATORY_REPO, "annex", "1", text, domain="payments")
    note = Story(story_key="PAY-5", version="1", summary=text, domain="payments")
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.REGULATORY_REPO, "annex", "1")
        add_source_item(connection, SourceKind.JIRA, "PAY-5", "1")
        save_passages(connection, [*page_passages(page), *story_passages(note)])

    default = world.service().search("quokka", as_at=AFTER_SWITCH).hits
    flipped = (
        world.service(
            SearchSettings(
                authority_weights={SourceKind.REGULATORY_REPO: 0.1, SourceKind.JIRA: 1.0}
            )
        )
        .search("quokka", as_at=AFTER_SWITCH)
        .hits
    )

    assert [h.item_id for h in default] == ["annex", "PAY-5"]
    assert [h.item_id for h in flipped] == ["PAY-5", "annex"]


def test_us10_rebuild_index_builds_story_and_register_passages_idempotently(
    world: SearchWorld,
) -> None:
    with world.database.transaction() as connection:
        add_source_item(connection, SourceKind.JIRA, "PAY-1", "1")
        add_source_item(connection, SourceKind.DOCUMENT_LIBRARY, "register", "1")
        connection.execute(
            insert(story).values(
                story_key="PAY-1",
                version="1",
                summary="Accept euro transfers",
                description="Background.",
                acceptance_criteria="Given a euro transfer then accept it",
                links=[{"link_type": "relates to", "target_key": "PAY-2"}],
                status="Open",
                domain="payments",
                fingerprint="0" * 64,
            )
        )
        connection.execute(
            insert(requirement).values(
                requirement_id="register:Requirements:5",
                source="document_library",
                item_id="register",
                version="1",
                sheet="Requirements",
                row_number=5,
                header_confidence=0.9,
                domain="payments",
                fields={
                    "Title": "Enforce the amount limit",
                    "Description": "Reject large transfers",
                },
            )
        )
    service = world.service()

    first = service.rebuild_index()
    second = service.rebuild_index()
    with world.database.transaction() as connection:
        total = PassageStore(connection).count()
    story_hits = service.search("euro transfer accept", as_at=AFTER_SWITCH, limit=50).hits
    row_hits = service.search("amount limit", as_at=AFTER_SWITCH, limit=50).hits

    assert first == second
    assert (first.stories, first.requirements) == (2, 1)
    assert total == first.clauses + 3
    assert {h.passage_type for h in story_hits} >= {
        PassageType.STORY,
        PassageType.ACCEPTANCE_CRITERIA,
    }
    assert any(h.passage_type is PassageType.REGISTER_ROW for h in row_hits)
