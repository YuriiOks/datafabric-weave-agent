"""Persistence of the sweep: runs, cursors, item versions, change events and review items.

Every method works on the connection it was given, so the caller decides the transaction.
Only dialect-neutral Core statements are used.
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import ColumnElement, Connection, RowMapping, insert, select, update

from kp.domain import (
    ApprovalState,
    ChangeEvent,
    DocumentDetails,
    ExtractionStatus,
    ItemKey,
    ReviewItem,
    ReviewKind,
    ReviewState,
    Run,
    RunOutcome,
    SourceItemVersion,
    SourceKind,
    SweepCursor,
)
from kp.store import schema
from kp.sweep.models import CitationStatus

_ITEM = schema.source_item


def _key_filter(key: ItemKey) -> tuple[ColumnElement[bool], ...]:
    return (
        _ITEM.c.source == key.source.value,
        _ITEM.c.item_id == key.item_id,
        _ITEM.c.version == key.version,
    )


def _to_version(row: RowMapping) -> SourceItemVersion:
    return SourceItemVersion(
        source=SourceKind(row["source"]),
        item_id=row["item_id"],
        version=row["version"],
        native_id=row["native_id"],
        content_sha256=row["content_sha256"],
        media_type=row["media_type"],
        title=row["title"],
        author=row["author"],
        modified_at=row["modified_at"],
        raw_location=row["raw_location"],
        markdown_location=row["markdown_location"],
        fetched_at=row["fetched_at"],
        run_id=row["run_id"],
        attachment_parent=row["attachment_parent"],
        extraction_status=ExtractionStatus(row["extraction_status"]),
        extraction_failure=row["extraction_failure"],
        manifest_location=row["manifest_location"],
        extractor_version=row["extractor_version"],
        approval_state=ApprovalState(row["approval_state"]),
        effective_date=row["effective_date"],
        superseded_at=row["superseded_at"],
        withdrawn_at=row["withdrawn_at"],
        details=DocumentDetails(
            document_type=row["document_type"],
            domain=row["domain"],
            authority=row["authority"],
            classification=row["classification"],
            content_owner=row["content_owner"],
        ),
        machine_authored=row["machine_authored"],
    )


def _version_values(version: SourceItemVersion) -> dict[str, object]:
    values: dict[str, object] = version.model_dump(exclude={"details"})
    values.update(version.details.model_dump())
    for name in ("source", "extraction_status", "approval_state"):
        values[name] = getattr(version, name).value
    return values


class SweepStore:
    """Reads and writes the tables the sweep owns or updates.

    :param connection: An open connection from ``Database.transaction()``
    """

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    # Runs -------------------------------------------------------------------------------

    def insert_run(self, run: Run) -> None:
        """Record the start of a run.

        :param run: The run, normally still ``running``
        """
        self._connection.execute(
            insert(schema.run).values(
                run_id=run.run_id,
                kind=run.kind.value,
                sources=[source.value for source in run.sources],
                started_at=run.started_at,
                ended_at=run.ended_at,
                outcome=run.outcome.value,
                items_touched=run.items_touched,
            )
        )

    def finish_run(
        self, run_id: str, outcome: RunOutcome, ended_at: datetime, items_touched: int
    ) -> None:
        """Record how a run ended.

        :param run_id: The run to close
        :param outcome: How it ended
        :param ended_at: When it ended
        :param items_touched: Versions recorded or changed
        """
        self._connection.execute(
            update(schema.run)
            .where(schema.run.c.run_id == run_id)
            .values(outcome=outcome.value, ended_at=ended_at, items_touched=items_touched)
        )

    # Cursors ----------------------------------------------------------------------------

    def load_cursor(self, source: SourceKind, scope: str) -> SweepCursor | None:
        """Read the saved position of one source scope.

        :param source: The source
        :param scope: Its scope (``""`` for none)
        :return: The cursor, or ``None`` if the scope was never swept
        """
        table = schema.sweep_cursor
        row = (
            self._connection.execute(
                select(table).where(table.c.source == source.value, table.c.scope == scope)
            )
            .mappings()
            .first()
        )
        return None if row is None else _to_cursor(row)

    def list_cursors(self) -> list[SweepCursor]:
        """Read every saved cursor.

        :return: All cursors, ordered by source and scope
        """
        table = schema.sweep_cursor
        rows = self._connection.execute(select(table).order_by(table.c.source, table.c.scope))
        return [_to_cursor(row) for row in rows.mappings()]

    def save_cursor(self, cursor: SweepCursor) -> None:
        """Insert or update a cursor.

        :param cursor: The state to save
        """
        table = schema.sweep_cursor
        values = {
            "position": cursor.position,
            "last_success_at": cursor.last_success_at,
            "last_attempt_at": cursor.last_attempt_at,
            "consecutive_failures": cursor.consecutive_failures,
            "updated_at": cursor.updated_at,
        }
        found = self.load_cursor(cursor.source, cursor.scope)
        if found is None:
            self._connection.execute(
                insert(table).values(source=cursor.source.value, scope=cursor.scope, **values)
            )
        else:
            self._connection.execute(
                update(table)
                .where(table.c.source == cursor.source.value, table.c.scope == cursor.scope)
                .values(**values)
            )

    # Item versions ----------------------------------------------------------------------

    def get_version(self, key: ItemKey) -> SourceItemVersion | None:
        """Read one stored version.

        :param key: Source, item and version
        :return: The version, or ``None`` if never stored
        """
        row = self._connection.execute(select(_ITEM).where(*_key_filter(key))).mappings().first()
        return None if row is None else _to_version(row)

    def list_versions(self, source: SourceKind, item_id: str) -> list[SourceItemVersion]:
        """Read every stored version of one item.

        :param source: The source
        :param item_id: The item
        :return: Versions in the order they were fetched
        """
        rows = self._connection.execute(
            select(_ITEM)
            .where(_ITEM.c.source == source.value, _ITEM.c.item_id == item_id)
            .order_by(_ITEM.c.fetched_at, _ITEM.c.version)
        )
        return [_to_version(row) for row in rows.mappings()]

    def insert_version(self, version: SourceItemVersion) -> None:
        """Write a new immutable version. Never overwrites.

        :param version: The version with its approval decision
        """
        self._connection.execute(insert(_ITEM).values(**_version_values(version)))

    def save_approval(self, version: SourceItemVersion) -> None:
        """Update the only columns of a stored version that may change after it is written.

        These are the approval state and its dates, plus the five document details and the
        machine-authored mark, which a reviewed document may have corrected without a new
        version. Content columns are never touched.

        :param version: The version carrying the new state, dates and details
        """
        self._connection.execute(
            update(_ITEM)
            .where(*_key_filter(version.key))
            .values(
                approval_state=version.approval_state.value,
                effective_date=version.effective_date,
                superseded_at=version.superseded_at,
                withdrawn_at=version.withdrawn_at,
                machine_authored=version.machine_authored,
                **version.details.model_dump(),
            )
        )

    def settle_due_supersessions(self, today: date) -> int:
        """Mark admitted versions as superseded once their supersession date has arrived.

        An edition replaced from a future date stays admitted, and in force, until then.

        :param today: The current date
        :return: How many versions changed state
        """
        rows = self._connection.execute(
            select(_ITEM).where(
                _ITEM.c.approval_state == ApprovalState.ADMITTED.value,
                _ITEM.c.superseded_at.is_not(None),
                _ITEM.c.superseded_at <= today,
            )
        )
        due = [_to_version(row) for row in rows.mappings()]
        for version in due:
            self.save_approval(
                version.model_copy(update={"approval_state": ApprovalState.SUPERSEDED})
            )
        return len(due)

    def sync_edition_dates(self, version: SourceItemVersion) -> None:
        """Copy a version's supersession and withdrawal dates to its edition row, if any.

        The as-at rule reads the dates on the edition, so they must follow the approval. Only
        the dates the version actually has are written; a date already on the edition (for
        example from a manifest) is never blanked.

        :param version: The version whose dates changed
        """
        dates: dict[str, date] = {}
        if version.superseded_at is not None:
            dates["superseded_from"] = version.superseded_at
        if version.withdrawn_at is not None:
            dates["withdrawn_from"] = version.withdrawn_at
        if not dates:
            return
        table = schema.edition
        self._connection.execute(
            update(table)
            .where(
                table.c.source == version.source.value,
                table.c.item_id == version.item_id,
                table.c.version == version.version,
            )
            .values(**dates)
        )

    def citation_status(self, key: ItemKey) -> CitationStatus | None:
        """Say what a citation of a version resolves to.

        :param key: The cited version
        :return: Its state and dates, or ``None`` if the version was never stored
        """
        version = self.get_version(key)
        if version is None:
            return None
        return CitationStatus(
            key=key,
            approval_state=version.approval_state,
            superseded_at=version.superseded_at,
            withdrawn_at=version.withdrawn_at,
        )

    # Change events and reviews -----------------------------------------------------------

    def add_event(self, event: ChangeEvent) -> None:
        """Record a detected change.

        :param event: The event
        """
        self._connection.execute(
            insert(schema.change_event).values(
                event_id=event.event_id,
                source=event.source.value,
                item_id=event.item_id,
                old_version=event.old_version,
                new_version=event.new_version,
                kind=event.kind.value,
                detected_at=event.detected_at,
                run_id=event.run_id,
            )
        )

    def add_review(self, review: ReviewItem) -> None:
        """Record a question for a person.

        :param review: The review item
        """
        self._connection.execute(
            insert(schema.review_item).values(
                review_id=review.review_id,
                kind=review.kind.value,
                state=review.state.value,
                source=review.source.value,
                item_id=review.item_id,
                version=review.version,
                detail=review.detail,
                missing_details=list(review.missing_details),
                content_owner=review.content_owner,
                candidates=list(review.candidates),
                run_id=review.run_id,
                created_at=review.created_at,
                resolved_at=review.resolved_at,
            )
        )

    def has_open_review(self, key: ItemKey, kind: ReviewKind) -> bool:
        """Tell whether a review of this kind is already open for a version.

        :param key: The version
        :param kind: The kind of review
        :return: True when an open review exists, so a re-run must not add another
        """
        table = schema.review_item
        row = self._connection.execute(
            select(table.c.review_id).where(
                table.c.source == key.source.value,
                table.c.item_id == key.item_id,
                table.c.version == key.version,
                table.c.kind == kind.value,
                table.c.state == ReviewState.OPEN.value,
            )
        ).first()
        return row is not None

    def resolve_reviews(self, key: ItemKey, resolved_at: datetime) -> None:
        """Close every open review of a version, e.g. once it was admitted.

        :param key: The version
        :param resolved_at: When the reviews were resolved
        """
        table = schema.review_item
        self._connection.execute(
            update(table)
            .where(
                table.c.source == key.source.value,
                table.c.item_id == key.item_id,
                table.c.version == key.version,
                table.c.state == ReviewState.OPEN.value,
            )
            .values(state=ReviewState.RESOLVED.value, resolved_at=resolved_at)
        )


def _to_cursor(row: RowMapping) -> SweepCursor:
    return SweepCursor(
        source=SourceKind(row["source"]),
        scope=row["scope"],
        position=row["position"],
        last_success_at=row["last_success_at"],
        last_attempt_at=row["last_attempt_at"],
        consecutive_failures=row["consecutive_failures"],
        updated_at=row["updated_at"],
    )
