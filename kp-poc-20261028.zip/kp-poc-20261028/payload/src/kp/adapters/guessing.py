"""Seam: guessed links, with the texts the links package leaves to its caller.

The links package scores pairs it is given and stores the outcome; it gathers no texts. This
module gathers them, with the local term-overlap similarity (the shared AI services replace it
through :class:`~kp.links.ports.SimilarityPort`):

* every register row that no source ties to a clause is scored against the rules (leaf
  clauses) of the edition in force, as a ``constrained_by`` link;
* every rule that no schema file ties to a field is scored against the schema fields, as a
  ``resolves_to`` link.

Scores of 0.75 and above become proposed links, 0.55 up to that go to the review list, the rest
are not kept (shared contract on thresholds).
"""

from __future__ import annotations

from collections.abc import Collection

from sqlalchemy import Connection, select

from kp.adapters.stated_links import StatedLinkLoader
from kp.clock import Clock
from kp.config import Thresholds
from kp.domain import ClauseRef, ItemRef, ItemType, LinkState, Relation
from kp.links import GuessItem, GuessReport, LinkService, RuleCatalog, clause_item
from kp.store import schema


class LinkGuesser:
    """Proposes links for items that no source ties together.

    :param connection: A connection inside the caller's unit of work
    :param thresholds: Platform thresholds (score bands, guessed-share limit)
    :param clock: Time source; "today" picks the edition in force
    """

    def __init__(self, connection: Connection, *, thresholds: Thresholds, clock: Clock) -> None:
        self._connection = connection
        self._clock = clock
        self._service = LinkService(connection, thresholds=thresholds, clock=clock)
        self._loader = StatedLinkLoader(connection, thresholds=thresholds, clock=clock)

    def guess(self, schema_fields: Collection[ItemRef] = ()) -> tuple[GuessReport, ...]:
        """Score the unlinked items and store the outcome.

        :param schema_fields: The schema field endpoints found in the code repository; the
            second guess is skipped when there are none
        :return: One report per relation guessed
        :raises kp.links.NoEditionInForceError: If no edition is in force today
        """
        edition = RuleCatalog(self._connection).edition_as_at(self._clock.today())
        names = frozenset(_field_name(field) for field in schema_fields)
        rules = self._rules(edition)
        reports = [self._requirements_to_rules(edition, rules, names)]
        if schema_fields:
            reports.append(self._rules_to_fields(edition, rules, schema_fields, names))
        return tuple(reports)

    def _requirements_to_rules(
        self, edition: str, rules: list[tuple[str, str]], names: frozenset[str]
    ) -> GuessReport:
        linked = self._with_a_stated_link(Relation.CONSTRAINED_BY, outgoing=True)
        sources = [
            GuessItem.from_text(
                ItemRef(item_type=ItemType.REQUIREMENT, key=row.requirement_id),
                " ".join(row.fields.get(name, "") for name in ("Title", "Description")),
                names,
            )
            for row in self._loader.requirements()
            if row.requirement_id not in linked
        ]
        targets = [
            GuessItem.from_text(clause_item(ClauseRef(edition, number)), text, names)
            for number, text in rules
        ]
        return self._service.guess(Relation.CONSTRAINED_BY, sources, targets)

    def _rules_to_fields(
        self,
        edition: str,
        rules: list[tuple[str, str]],
        schema_fields: Collection[ItemRef],
        names: frozenset[str],
    ) -> GuessReport:
        linked = self._with_a_stated_link(Relation.RESOLVES_TO, outgoing=True)
        sources = [
            GuessItem.from_text(item, text, names)
            for number, text in rules
            if (item := clause_item(ClauseRef(edition, number))).key not in linked
        ]
        targets = [
            GuessItem.from_text(field, _field_name(field).replace("_", " "), names)
            for field in sorted(schema_fields, key=lambda ref: ref.key)
        ]
        return self._service.guess(Relation.RESOLVES_TO, sources, targets)

    def _with_a_stated_link(self, relation: Relation, *, outgoing: bool) -> set[str]:
        links = self._service.store.open_links({LinkState.STATED})
        return {
            (link.source_ref if outgoing else link.target_ref).key
            for link in links
            if link.relation is relation
        }

    def _rules(self, edition: str) -> list[tuple[str, str]]:
        """The leaf clauses of an edition as ``(number, "title text")``."""
        rows = self._connection.execute(
            select(schema.clause.c.number, schema.clause.c.title, schema.clause.c.text).where(
                schema.clause.c.edition == edition
            )
        ).all()
        parents = set(
            self._connection.execute(
                select(schema.clause.c.parent_number).where(
                    schema.clause.c.edition == edition,
                    schema.clause.c.parent_number.is_not(None),
                )
            ).scalars()
        )
        return sorted(
            (number, f"{title} {text}") for number, title, text in rows if number not in parents
        )


def _field_name(field: ItemRef) -> str:
    """The property name of a schema field endpoint (the part after ``#``)."""
    return field.key.rpartition("#")[2]
