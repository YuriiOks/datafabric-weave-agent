"""Stated-link loaders: story issue links, register rows and repository files."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import Connection

from kp.clock import FixedClock
from kp.domain import (
    ItemType,
    LinkKind,
    LinkState,
    Relation,
    Requirement,
    SourceKind,
    Story,
    StoryLink,
)
from kp.links import (
    KeyIndex,
    LinkService,
    RepositoryScanner,
    code_item,
    conformance_violation,
    find_clause_refs,
    register_link_set,
    schema_field_item,
    source_path_of,
    story_link_set,
    unit_test_item,
)
from kp.testing.dataset import SyntheticDataset
from links.builders import spec, story
from links.seed import exported_stories, register_requirements, x_clause_field_count


def _requirement(key: str, cell: str, row: int = 5) -> Requirement:
    return Requirement(
        requirement_id=key,
        source=SourceKind.GITHUB,
        item_id="register",
        version="1",
        sheet="Requirements",
        row_number=row,
        header_confidence=1.0,
        fields={"Req ID": key, "Rule reference": cell},
    )


def test_us13_register_rows_state_which_clause_constrains_each_requirement(
    dataset: SyntheticDataset,
) -> None:
    requirements = register_requirements(dataset)

    stated = register_link_set(requirements)

    assert len(requirements) == dataset.truth.requirements_register.data_row_count
    assert stated.rejected == ()
    assert all(link.relation is Relation.CONSTRAINED_BY for link in stated.links)
    assert all(link.kind is LinkKind.STATED and link.score is None for link in stated.links)
    assert all(conformance_violation(link) is None for link in stated.links)
    first = stated.links[0]
    assert (first.source_ref.item_type, first.target_ref.key) == (
        ItemType.REQUIREMENT,
        "2026.1:4.2.1",
    )
    assert {link.target_ref.key for link in stated.links} >= {
        "2026.1:4.2.1",
        "2026.1:4.2.2",
        "2026.1:4.2.3",
        "2026.1:4.1.2",
    }
    assert len(stated.owned_sources) == len(requirements)


def test_us13_a_register_cell_may_name_several_clauses_and_odd_cells_are_reported() -> None:
    stated = register_link_set(
        [
            _requirement("R1", "2026.1 clause 4.2.1 and 2026.1:4.2.2"),
            _requirement("R2", "see the rulebook"),
            _requirement("R3", "  "),
        ]
    )

    assert [(link.source_ref.key, link.target_ref.key) for link in stated.links] == [
        ("R1", "2026.1:4.2.1"),
        ("R1", "2026.1:4.2.2"),
    ]
    assert [rejected.origin for rejected in stated.rejected] == ["R2 row 5"]
    assert len(stated.owned_sources) == 3


def test_us13_story_links_the_model_cannot_express_are_reported_not_dropped(
    dataset: SyntheticDataset,
) -> None:
    stories = exported_stories(dataset, "jira/export-1.json")
    index = KeyIndex.build(
        requirements=register_requirements(dataset), story_keys=[s.story_key for s in stories]
    )

    stated = story_link_set(stories, index)

    issue_links = sum(len(s.links) for s in stories)
    assert stated.links == ()
    assert len(stated.rejected) == issue_links
    assert {r.origin for r in stated.rejected} >= {"PAY-101 implements REQ-004"}
    assert "no relation of the model links a story to a requirement" in stated.rejected[0].reason
    assert len(stated.owned_sources) == dataset.truth.stories.story_count


def test_us13_a_story_specified_by_a_spec_becomes_a_stated_link() -> None:
    item = Story(
        story_key="PAY-9",
        version="1",
        summary="s",
        links=(
            StoryLink(link_type="Is Specified By", target_key="SPEC-1"),
            StoryLink(link_type="implements", target_key="REQ-1"),
            StoryLink(link_type="blocks", target_key="NOWHERE-1"),
        ),
    )
    index = KeyIndex(specs=frozenset({"SPEC-1"}), requirements=frozenset({"REQ-1"}))

    stated = story_link_set([item], index)

    (link,) = stated.links
    assert (link.source_ref, link.relation, link.target_ref) == (
        story("PAY-9"),
        Relation.SPECIFIED_BY,
        spec("SPEC-1"),
    )
    assert sorted(r.reason for r in stated.rejected)[0].startswith("no relation")
    assert any(r.reason == "target is not a loaded item" for r in stated.rejected)
    assert stated.relations == frozenset({Relation.SPECIFIED_BY})


def test_us13_reloading_without_a_removed_story_link_closes_it(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock)
    index = KeyIndex(specs=frozenset({"SPEC-1"}))
    with_link = Story(
        story_key="PAY-9",
        version="1",
        summary="s",
        links=(StoryLink(link_type="is specified by", target_key="SPEC-1"),),
    )
    without_link = with_link.model_copy(update={"links": ()})

    first = service.apply_stated(story_link_set([with_link], index))
    clock.set(clock.now().replace(hour=10))
    unchanged = service.apply_stated(story_link_set([with_link], index))
    clock.set(clock.now().replace(hour=11))
    removed = service.apply_stated(story_link_set([without_link], index))

    assert (first.opened, unchanged.unchanged, removed.closed) == (1, 1, 1)
    assert service.store.in_use_links() == []
    assert len(service.store.history(story("PAY-9"), Relation.SPECIFIED_BY, spec("SPEC-1"))) == 1


def test_us13_repository_files_state_schema_fields_and_tests_of_code(
    dataset: SyntheticDataset,
) -> None:
    scan = RepositoryScanner().scan(dataset.root / "code_repo")

    facts = {(link.source_ref.key, link.relation, link.target_ref.key) for link in scan.links}
    assert (
        "2026.1:4.2.1",
        Relation.RESOLVES_TO,
        "schema/credit_transfer.schema.json#currency",
    ) in facts
    assert (
        "src/payments/inbound.py::validate_currency",
        Relation.VERIFIED_BY,
        "tests/test_inbound.py::test_unlisted_currency_is_rejected",
    ) in facts
    assert (
        "src/payments/inbound.py::validate_amount",
        Relation.VERIFIED_BY,
        "tests/test_inbound.py::test_amount_above_limit_is_rejected",
    ) in facts
    fields = x_clause_field_count(dataset.root / "code_repo")
    assert fields > 0
    assert sum(1 for link in scan.links if link.relation is Relation.RESOLVES_TO) == fields
    assert sum(1 for link in scan.links if link.relation is Relation.VERIFIED_BY) == 2
    assert scan.rejected == ()
    assert all(link.kind is LinkKind.STATED for link in scan.links)
    assert all(conformance_violation(link) is None for link in scan.links)
    assert len(scan.owned_targets) >= fields


def test_us13_code_that_cites_a_clause_is_reported_as_a_citation(
    dataset: SyntheticDataset,
) -> None:
    scan = RepositoryScanner().scan(dataset.root / "code_repo")

    cited = {(c.item.key, c.clause.key) for c in scan.citations}

    assert (
        "src/payments/inbound.py::validate_creditor_account",
        "2026.1:4.2.3",
    ) in cited
    assert ("tests/test_inbound.py::test_amount_above_limit_is_rejected", "2026.1:4.2.2") in cited
    assert not any(link.target_ref.item_type is ItemType.CLAUSE for link in scan.links)


def test_us13_a_revision_qualifies_every_repository_key(dataset: SyntheticDataset) -> None:
    scan = RepositoryScanner(revision="abc123").scan(dataset.root / "code_repo")

    keys = {link.target_ref.key for link in scan.links}

    assert "schema/credit_transfer.schema.json@abc123#currency" in keys
    assert "tests/test_inbound.py@abc123::test_unlisted_currency_is_rejected" in keys


def test_us13_unreadable_repository_files_are_reported(tmp_path: Path) -> None:
    (tmp_path / "broken.py").write_text("def (:\n", encoding="utf-8")
    (tmp_path / "bad.schema.json").write_text("{not json", encoding="utf-8")

    scan = RepositoryScanner().scan(tmp_path)

    assert {r.origin: r.reason for r in scan.rejected} == {
        "broken.py": "not valid Python",
        "bad.schema.json": "not valid JSON",
    }
    assert scan.links == ()


def test_us13_tests_are_linked_through_module_imports_and_module_aliases(tmp_path: Path) -> None:
    (tmp_path / "pkg").mkdir()
    (tmp_path / "pkg" / "rules.py").write_text(
        "def check() -> bool:\n    return True\n\n\nclass Engine:\n    pass\n", encoding="utf-8"
    )
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_rules.py").write_text(
        "import pkg.rules as rules\n"
        "from pkg.rules import Engine\n\n\n"
        "def test_check() -> None:\n    assert rules.check()\n\n\n"
        "class TestEngine:\n    def test_builds(self) -> None:\n        Engine()\n\n\n"
        "def helper() -> None:\n    rules.check()\n",
        encoding="utf-8",
    )

    scan = RepositoryScanner().scan(tmp_path)

    assert {(link.source_ref.key, link.target_ref.key) for link in scan.links} == {
        ("pkg/rules.py::check", "tests/test_rules.py::test_check"),
        ("pkg/rules.py::Engine", "tests/test_rules.py::TestEngine.test_builds"),
    }


def test_us13_scanned_repository_links_open_in_the_store_and_close_when_removed(
    loaded: Connection, clock: FixedClock, dataset: SyntheticDataset
) -> None:
    service = LinkService(loaded, clock=clock)
    scan = RepositoryScanner().scan(dataset.root / "code_repo")

    first = service.apply_stated(scan)
    clock.set(clock.now().replace(hour=10))
    again = service.apply_stated(scan)
    emptied = scan.model_copy(
        update={
            "links": tuple(link for link in scan.links if link.relation is Relation.RESOLVES_TO)
        }
    )
    clock.set(clock.now().replace(hour=11))
    partial = service.apply_stated(emptied)

    assert (first.opened, first.rejected) == (len(scan.links), 0)
    assert (again.opened, again.unchanged) == (0, len(scan.links))
    # Two verified-by links and the implemented-by link of the dataset leave with their entries.
    assert partial.closed == 3
    states = {link.state for link in service.store.in_use_links()}
    assert states == {LinkState.STATED}


def test_us13_repository_keys_name_their_source_path_and_clause_references_are_found() -> None:
    assert source_path_of(code_item("src/a.py", "f", "abc")) == "src/a.py"
    assert source_path_of(schema_field_item("s/x.schema.json", "currency")) == "s/x.schema.json"
    assert source_path_of(unit_test_item("tests/t.py", "test_f")) == "tests/t.py"
    assert [
        ref.format() for ref in find_clause_refs("Implements 2026.1:4.2.1; see 2026.1 clause 4.3")
    ] == [
        "2026.1:4.2.1",
        "2026.1:4.3",
    ]
    assert find_clause_refs("a dict {'a':1} and note:3") == []


@pytest.mark.parametrize(
    "text",
    ["2026.1:4.2.1a", "2026.1:4.2.1_x", "2026.1:4.2.10x"],
)
def test_us13_a_longer_or_malformed_reference_is_not_cut_back_to_its_parent(text: str) -> None:
    assert find_clause_refs(text) == []


@pytest.mark.parametrize("text", ["due 10:30", "ratio 3:1", "12 clause 5"])
def test_us13_times_and_ratios_are_not_clause_references_when_editions_are_known(
    text: str,
) -> None:
    assert find_clause_refs(text, {"2026.1", "2025.2"}) == []


def test_us13_a_reference_to_an_unloaded_edition_is_rejected_in_a_register_cell() -> None:
    stated = register_link_set(
        [_requirement("R1", "2026.1:4.2.1 and 3:1"), _requirement("R2", "9:9")],
        editions={"2026.1"},
    )

    assert [(link.source_ref.key, link.target_ref.key) for link in stated.links] == [
        ("R1", "2026.1:4.2.1")
    ]
    assert [(r.origin, r.reason) for r in stated.rejected] == [
        ("R1 row 5", "edition 3 is not loaded"),
        ("R2 row 5", "edition 9 is not loaded"),
    ]


def test_us13_a_clause_that_is_not_loaded_is_counted_as_dangling_and_not_stored(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock)
    stated = register_link_set(
        [_requirement("R1", "2026.1:4.2.1"), _requirement("R2", "2026.1:4.2.11", row=6)]
    )

    report = service.apply_stated(stated)

    assert (report.opened, report.dangling, report.rejected) == (1, 1, 1)
    assert [(r.origin, r.reason) for r in report.rejections] == [
        ("R2 row 6", "clause 2026.1:4.2.11 is not loaded")
    ]
    assert [link.source_ref.key for link in service.store.in_use_links()] == ["R1"]


def test_us13_a_dangling_link_that_was_stored_before_the_clause_went_is_closed(
    loaded: Connection, clock: FixedClock
) -> None:
    service = LinkService(loaded, clock=clock)
    service.apply_stated(register_link_set([_requirement("R1", "2026.1:4.2.1")]))
    clock.set(clock.now().replace(hour=10))

    report = service.apply_stated(register_link_set([_requirement("R1", "2026.1:4.2.11")]))

    assert (report.opened, report.dangling, report.closed) == (0, 1, 1)
    assert service.store.in_use_links() == []


def test_us13_a_name_that_is_only_an_argument_or_annotation_is_not_a_call(tmp_path: Path) -> None:
    (tmp_path / "pkg").mkdir()
    (tmp_path / "pkg" / "rules.py").write_text(
        "class RuleError(Exception):\n    pass\n\n\ndef check() -> bool:\n    return True\n",
        encoding="utf-8",
    )
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_rules.py").write_text(
        "import pytest\n"
        "from pkg.rules import RuleError, check\n\n\n"
        "def test_only_names_the_class(value: RuleError) -> None:\n"
        "    with pytest.raises(RuleError):\n        raise ValueError\n\n\n"
        "def test_calls_the_function() -> None:\n    assert check()\n",
        encoding="utf-8",
    )

    scan = RepositoryScanner().scan(tmp_path)

    assert {(link.source_ref.key, link.target_ref.key) for link in scan.links} == {
        ("pkg/rules.py::check", "tests/test_rules.py::test_calls_the_function")
    }


def test_us13_a_file_that_cannot_be_read_is_reported_and_the_scan_goes_on(tmp_path: Path) -> None:
    (tmp_path / "latin.py").write_bytes(b"x = '\xe9'\n")
    (tmp_path / "latin.schema.json").write_bytes(b'{"a": "\xe9"}')
    (tmp_path / "ok.schema.json").write_text(
        '{"properties": {"currency": {"x-clause": "2026.1:4.2.1"}}}', encoding="utf-8"
    )

    scan = RepositoryScanner().scan(tmp_path)

    assert {r.origin: r.reason for r in scan.rejected} == {
        "latin.py": "cannot be read as UTF-8 text",
        "latin.schema.json": "cannot be read as UTF-8 text",
    }
    assert [link.target_ref.key for link in scan.links] == ["ok.schema.json#currency"]


def test_us13_x_clause_of_an_unloaded_edition_is_rejected_and_documentation_ignores_it(
    tmp_path: Path,
) -> None:
    (tmp_path / "s.schema.json").write_text(
        '{"properties": {"a": {"x-clause": ["2026.1:4.2.1", "7:7"]}}}', encoding="utf-8"
    )
    (tmp_path / "m.py").write_text(
        'def f() -> None:\n    """Due 10:30 and see 2026.1:4.2.1."""\n', encoding="utf-8"
    )

    scan = RepositoryScanner(editions={"2026.1"}).scan(tmp_path)

    assert [(r.origin, r.reason) for r in scan.rejected] == [
        ("s.schema.json property a", "edition 7 is not loaded")
    ]
    assert [(c.item.key, c.clause.key) for c in scan.citations] == [("m.py::f", "2026.1:4.2.1")]


def test_us13_a_new_revision_closes_the_links_stated_under_the_old_revision_keys(
    loaded: Connection, clock: FixedClock, dataset: SyntheticDataset
) -> None:
    service = LinkService(loaded, clock=clock)
    service.apply_stated(RepositoryScanner(revision="rev1").scan(dataset.root / "code_repo"))
    clock.set(clock.now().replace(hour=10))

    report = service.apply_stated(
        RepositoryScanner(revision="rev2").scan(dataset.root / "code_repo")
    )

    keys = {
        key
        for link in service.store.in_use_links()
        for key in (link.source_ref.key, link.target_ref.key)
    }
    assert report.closed > 0
    assert not any("@rev1" in key for key in keys)
    assert any("@rev2" in key for key in keys)


def _code_that_implements(tmp_path: Path, *lines: str) -> Path:
    (tmp_path / "pkg").mkdir()
    body = "\n".join(f"    {line}" for line in lines)
    (tmp_path / "pkg" / "rules.py").write_text(
        f'def check() -> bool:\n    """Checks the rule.\n\n{body}\n    """\n    return True\n',
        encoding="utf-8",
    )
    return tmp_path


def test_us13_code_that_says_it_implements_a_loaded_spec_states_the_spec_is_implemented_by_it(
    tmp_path: Path,
) -> None:
    root = _code_that_implements(tmp_path, "Implements spec spec-pay-104.")

    scan = RepositoryScanner(specs={"spec-pay-104"}).scan(root)

    assert [(link.source_ref, link.relation, link.target_ref.key) for link in scan.links] == [
        (spec("spec-pay-104"), Relation.IMPLEMENTED_BY, "pkg/rules.py::check")
    ]
    assert Relation.IMPLEMENTED_BY in scan.relations
    assert scan.rejected == ()


def test_us13_a_spec_that_is_not_loaded_is_rejected_not_linked(tmp_path: Path) -> None:
    root = _code_that_implements(tmp_path, "Implements spec spec-unknown.")

    scan = RepositoryScanner(specs={"spec-pay-104"}).scan(root)

    assert scan.links == ()
    assert [(item.origin, item.reason) for item in scan.rejected] == [
        ("pkg/rules.py check implements spec spec-unknown", "spec spec-unknown is not loaded")
    ]


def test_us13_without_a_list_of_loaded_specs_every_named_spec_is_accepted(tmp_path: Path) -> None:
    root = _code_that_implements(tmp_path, "implements SPEC Spec-Other-1")

    scan = RepositoryScanner().scan(root)

    assert [link.source_ref.key for link in scan.links] == ["Spec-Other-1"]


def test_us13_removing_the_statement_closes_the_implemented_by_link(
    loaded: Connection, clock: FixedClock, tmp_path: Path
) -> None:
    service = LinkService(loaded, clock=clock)
    root = _code_that_implements(tmp_path, "Implements spec spec-pay-104.")
    opened = service.apply_stated(RepositoryScanner(specs={"spec-pay-104"}).scan(root))
    (root / "pkg" / "rules.py").write_text("def check() -> bool:\n    return True\n")
    clock.set(clock.now().replace(hour=11))

    closed = service.apply_stated(RepositoryScanner(specs={"spec-pay-104"}).scan(root))

    assert (opened.opened, closed.closed) == (1, 1)


def test_us13_hidden_files_and_symbolic_links_are_not_read(tmp_path: Path) -> None:
    (tmp_path / "pkg").mkdir()
    (tmp_path / "pkg" / "rules.py").write_text("def check() -> bool:\n    return True\n")
    (tmp_path / ".hidden").mkdir()
    (tmp_path / ".hidden" / "secret.py").write_text("def hidden() -> bool:\n    return True\n")
    outside = tmp_path.parent / f"{tmp_path.name}-outside.py"
    outside.write_text("def outside() -> bool:\n    return True\n")
    (tmp_path / "pkg" / "linked.py").symlink_to(outside)

    scan = RepositoryScanner().scan(tmp_path)

    assert scan.owned_paths == frozenset({"pkg/rules.py"})
    assert {item.key for item in scan.owned_sources} == {"pkg/rules.py::check"}
