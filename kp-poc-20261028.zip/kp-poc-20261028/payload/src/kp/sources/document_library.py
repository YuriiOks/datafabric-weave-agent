"""Document library reader: a folder of documents with approval metadata sidecars.

Each document ``name.ext`` may have a sidecar that states which item and version it is, its
approval status and the five required document details. The sidecar is ``name.ext.meta.json``
(named after the whole file) or, when that is absent, ``name.meta.json`` (named after the stem).
Two files that share a stem, such as ``a.md`` and ``a.pdf``, would share a stem sidecar and so
claim one item version, which is reported as malformed source data; give each its own
``a.md.meta.json`` and ``a.pdf.meta.json`` to keep both. The reader reports what the sidecar
says in ``ItemMetadata.attributes`` (see :mod:`kp.sources.attributes`) and leaves the decision to
the approval gate, with one exception: a document whose status is ``draft`` is never listed and
cannot be fetched, so a draft cannot reach a spec by any path.

A sidecar should state the version. Without one the version is ``sha-`` plus twelve characters
of the content hash, so editing such a document produces a *different* version and the old one
disappears: it is reported as deleted (and so withdrawn by the gate), not as superseded. Only
explicit versions give the "new version supersedes the old one" behaviour of US-01.

A newer draft beside an older approved version therefore leaves only the approved version
visible. When the draft is later approved its sidecar changes, it appears as a new version, and
the gate supersedes the old one. A version that disappears (file removed, or approval pulled
back to draft) is reported as deleted so the gate can mark it withdrawn; its stored content is
history and stays.
"""

from __future__ import annotations

from functools import partial
from pathlib import Path

from pydantic import AwareDatetime, BaseModel, ConfigDict, JsonValue

from kp.domain.enums import SourceKind
from kp.domain.source_items import DETAIL_NAMES, ItemKey
from kp.sources import attributes as attr
from kp.sources.base import ItemMetadata
from kp.sources.files import (
    media_type_for,
    parse_file,
    read_file,
    require_directory,
    sha256_hex,
    walk_files,
)
from kp.sources.snapshot import ReadItem, ScannedItem, SnapshotReader, fingerprint

SIDECAR_SUFFIX = ".meta.json"
DRAFT_STATUS = "draft"
_HEADING_PREFIX = "# "


class _Sidecar(BaseModel):
    """The metadata file beside a document. Unknown keys are ignored on purpose."""

    model_config = ConfigDict(extra="ignore", frozen=True, coerce_numbers_to_str=True)

    item_id: str | None = None
    version: str | None = None
    title: str | None = None
    approval_status: str | None = None
    modified_at: AwareDatetime | None = None
    document_type: str | None = None
    domain: str | None = None
    authority: str | None = None
    classification: str | None = None
    content_owner: str | None = None


class DocumentLibraryReader(SnapshotReader):
    """Read a folder of documents with approval metadata sidecars.

    A document without a sidecar is still listed, with every approval signal ``None``, so
    the gate can report it instead of it silently not existing.

    :param root: The library folder; subfolders are read too
    """

    def __init__(self, root: Path) -> None:
        super().__init__()
        self._root = root

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves.

        :return: The document library
        """
        return SourceKind.DOCUMENT_LIBRARY

    def _scan(self) -> list[ScannedItem]:
        require_directory(self._root)
        entries: list[ScannedItem] = []
        for path in walk_files(self._root):
            if path.name.endswith(SIDECAR_SUFFIX):
                continue
            item = self._read(path)
            if item is not None:
                entries.append(ScannedItem.of(item, partial(self._read, path)))
        return entries

    def _read(self, path: Path) -> ReadItem | None:
        sidecar, present = _read_sidecar(path)
        status = _clean(sidecar.approval_status)
        status = status.lower() if status else None
        if status == DRAFT_STATUS:
            return None
        content = read_file(path)
        content_sha256 = sha256_hex(content)
        relative = path.relative_to(self._root).as_posix()
        key = ItemKey(
            source=self.kind,
            item_id=sidecar.item_id or relative,
            version=sidecar.version or f"sha-{content_sha256[:12]}",
        )
        signals: dict[str, JsonValue] = {
            attr.APPROVAL_STATUS: status,
            attr.SIDECAR_PRESENT: present,
            attr.RELATIVE_PATH: relative,
        }
        for name in DETAIL_NAMES:
            signals[name] = _clean(getattr(sidecar, name))
        media_type = media_type_for(path)
        title = _clean(sidecar.title) or _first_heading(content, media_type) or path.stem
        return ReadItem(
            key=key,
            fingerprint=fingerprint(content_sha256, signals),
            title=title,
            modified_at=sidecar.modified_at,
            content=content,
            metadata=ItemMetadata(
                native_id=relative,
                media_type=media_type,
                title=title,
                modified_at=sidecar.modified_at,
                attributes=signals,
            ),
        )


def _read_sidecar(document: Path) -> tuple[_Sidecar, bool]:
    for name in (f"{document.name}{SIDECAR_SUFFIX}", f"{document.stem}{SIDECAR_SUFFIX}"):
        path = document.with_name(name)
        if path.is_file():
            return parse_file(path, _Sidecar.model_validate_json, "Metadata sidecar"), True
    return _Sidecar(), False


def _clean(value: str | None) -> str | None:
    """Strip a sidecar value and turn blank into ``None`` (a missing detail)."""
    stripped = (value or "").strip()
    return stripped or None


def _first_heading(content: bytes, media_type: str) -> str | None:
    if media_type != "text/markdown":
        return None
    for line in content.decode("utf-8", errors="replace").splitlines():
        if line.startswith(_HEADING_PREFIX):
            return line[len(_HEADING_PREFIX) :].strip() or None
    return None


__all__ = ["DRAFT_STATUS", "SIDECAR_SUFFIX", "DocumentLibraryReader"]
