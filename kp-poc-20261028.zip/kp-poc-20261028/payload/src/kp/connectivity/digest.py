"""Canonical JSON and SHA-256 helpers shared by the harness."""

from __future__ import annotations

import hashlib
import json


def canonical_json(value: object) -> bytes:
    """Serialise ``value`` to compact, key-sorted UTF-8 JSON so equal data gives equal bytes.

    :param value: Any JSON-serialisable value
    :return: The canonical encoding
    """
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def sha256_hex(data: bytes) -> str:
    """Return the lowercase hexadecimal SHA-256 of ``data``.

    :param data: The bytes to fingerprint
    :return: 64 hexadecimal characters
    """
    return hashlib.sha256(data).hexdigest()


def request_digest(namespace: str, method: str, params: object) -> str:
    """Fingerprint a gateway request so it can be recorded without its content.

    The JSON-RPC id and every credential are excluded, so the same logical request always has
    the same digest.

    :param namespace: The tool route the request was sent to
    :param method: The JSON-RPC method
    :param params: The method parameters
    :return: The digest to store in ``mcp_call.request_digest``
    """
    return sha256_hex(canonical_json({"namespace": namespace, "method": method, "params": params}))
