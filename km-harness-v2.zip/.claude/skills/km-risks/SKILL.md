---
name: km-risks
description: Use to build the risk register and the open questions from the kb. No argument needed.
argument-hint: (none)
disable-model-invocation: true
effort: xhigh
---

# km-risks

Goal: a risk register (the base of S2) and a list of open questions, every row backed by
evidence. Think hard: this feeds every story. Run id: km-risks-<date>.
Output: kb/risks/register.md, kb/risks/open-questions.md. Fixes are not designed here.

## Inputs
- kb/INDEX.md and kb/log.d/: which runs exist. An area whose source run is missing gets the
  status "not yet checked" and the reason, never "no risk".
- kb/verified/, kb/base/, kb/capture/, kb/legacy/, kb/seed/ (story-gaps.md first), and
  kb/wiki/ and kb/stories/ if they exist. Work from the kb. Read code only to settle a
  doubt, through km-verifier. Answers spread over many files: ask km-scout.
- kb/private is optional. Without it, work from code, wiki and kb/seed and mark Unverified.
- Nothing in kb/base, kb/capture and kb/verified: log it, tell the owner in two lines to run
  /km-read base and /km-read capture, stop.
- Areas to cover, and how to rate: ${CLAUDE_SKILL_DIR}/references/areas.md. Read it first.

## Rules for evidence
- A risk rests on Observed lines or a Confirmed or Narrowed verdict, with path:line or the kb
  path. Contradicted claims are never used.
- A claim that has no verdict, or comes from a document, a legacy review or kb/private:
  send it to km-verifier first (at most 15 per call, one call at a time, task in the canon
  form, clone path and numbered claims). Use the result. Not checkable: keep the row,
  label Unverified, and add a question.
- A legacy finding becomes a BASE_REPO risk only when the code shows the same pattern.
- A credential seen anywhere: "a credential is present at <path>" and nothing more.
- If kb/risks/register.md exists, keep every id, add rows, update counts. Never renumber.

## register.md
- Top: Date, Task, Status; counts by group, by impact and by label; areas not yet checked.
- Summary table: Id | Group | Label | Likelihood | Impact | Owner role.
  Groups: security, isolation, scalability, versioning, maintainability.
  Likelihood and impact: low, medium, high (scale in references/areas.md).
- Then one entry per risk, at most 4 lines, wrapped at 100 characters:
  id and risk in one sentence; Evidence: path:line or kb path; Label; Treatment: one
  proposed step (label Proposed). Owner roles, not names.
- Over 150 lines: continue in register-2.md, register-3.md as needed; the summary table stays
  in register.md and names every continuation file.

## open-questions.md
- Grouped under a heading per answering role. Each entry: Q id, blocks (S1..S6), the question,
  why it matters, source kb path. Include the questions story-gaps.md raises, every
  Not checkable claim that matters, and each contradiction between two kb files (name both).
- At most 150 lines.

## Finish
- Check: every area has a row or a not-yet-checked row; every row has evidence or Unverified;
  counts match the table; every question has a role.
- Write kb/index.d/<run>.txt (path | 12-word summary | date per file) and kb/log.d/<run>.txt
  (date, task, files, areas skipped and why, claims sent to the verifier).
- Print at most 10 lines: paths, row counts by impact, the three highest rows in one line each,
  rows resting on Unverified, and question counts per role.
