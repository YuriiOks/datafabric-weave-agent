"""Who is signed in.

Local mode offers a "Signed in as" selector over the test users of the written identity mapping;
the choice travels in the ``user`` query parameter. Real mode reads the user only from one request
header whose name is a setting, and never from the query string or a form: a link that carries
``?user=`` cannot change who the UI thinks you are.

The allowed domains come from the identity mapping in both modes, never from the request.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import yaml
from starlette.requests import Request

from kp.errors import ConfigurationError
from kp.tools import Caller, DomainDirectory, build_caller

USER_PARAMETER = "user"
AGENT_NAME = "kp-web"
SESSION_PREFIX = "web-"
_MAX_SESSION_LENGTH = 128


class IdentityResolver(Protocol):
    """Finds the caller of a request."""

    @property
    def selectable_users(self) -> tuple[str, ...]:
        """The users a person may switch between; empty when the identity is not chosen here."""
        ...

    def resolve(self, request: Request) -> Caller:
        """Read the caller of one request.

        :param request: The incoming request
        :return: The caller; unauthenticated when the request names no usable user
        """
        ...


def session_id_for(user: str) -> str:
    """The audit session of everything one user does in the UI.

    :param user: The user identity
    :return: A stable session label
    """
    return f"{SESSION_PREFIX}{user}"[:_MAX_SESSION_LENGTH]


def _caller(user: str | None) -> Caller:
    return build_caller(
        user=user, agent=AGENT_NAME, session_id=None if user is None else session_id_for(user)
    )


def load_user_names(path: Path) -> tuple[str, ...]:
    """List the users named in an identity mapping file.

    :param path: The mapping file (``version: 1`` and ``users: {<user>: {domains: [...]}}``)
    :return: The user identities, sorted
    :raises kp.errors.ConfigurationError: If the file cannot be read as a mapping
    """
    try:
        raw: object = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ConfigurationError(f"Identity mapping {path.name} is unusable") from exc
    users = raw.get("users") if isinstance(raw, Mapping) else None
    if not isinstance(users, Mapping):
        raise ConfigurationError(f"Identity mapping {path.name} lists no users")
    return tuple(sorted(str(name) for name in users))


class LocalIdentity:
    """The test-user selector of local mode.

    :param users: The users of the identity mapping
    :param default: Who is signed in until a person chooses
    :param anonymous_unless_chosen: Sign nobody in until a user is chosen. Set when the server
        is reachable from other machines, where "the default user" would be every stranger.
    """

    def __init__(
        self, users: tuple[str, ...], default: str, *, anonymous_unless_chosen: bool = False
    ) -> None:
        self._users = users
        self._default = default
        self._anonymous_unless_chosen = anonymous_unless_chosen

    @classmethod
    def for_directory(
        cls,
        users: tuple[str, ...],
        directory: DomainDirectory,
        *,
        anonymous_unless_chosen: bool = False,
    ) -> LocalIdentity:
        """Start as the user with the widest access, so a first visit shows something.

        :param users: The users of the identity mapping
        :param directory: Identity to allowed domains
        :param anonymous_unless_chosen: See the class; the default user is then never used
        :return: The resolver
        :raises kp.errors.ConfigurationError: If the mapping lists no users
        """
        if not users:
            raise ConfigurationError("The identity mapping lists no users")
        widest = max(users, key=lambda user: (len(directory.domains_for(user)), user))
        return cls(users, widest, anonymous_unless_chosen=anonymous_unless_chosen)

    @property
    def selectable_users(self) -> tuple[str, ...]:
        """The test users of the mapping."""
        return self._users

    def resolve(self, request: Request) -> Caller:
        """Read the chosen test user from the query string.

        :param request: The incoming request
        :return: The chosen user; the default one when none was chosen, or nobody when the
            server is reachable from other machines
        """
        chosen = request.query_params.get(USER_PARAMETER)
        if chosen:
            return _caller(chosen)
        return _caller(None if self._anonymous_unless_chosen else self._default)


class HeaderIdentity:
    """The identity of real mode: one request header, set by whatever authenticates the user.

    :param header: The header name (a setting)
    """

    def __init__(self, header: str) -> None:
        self._header = header

    @property
    def selectable_users(self) -> tuple[str, ...]:
        """Nobody can switch user in real mode."""
        return ()

    def resolve(self, request: Request) -> Caller:
        """Read the user from the header; the query string and forms are never consulted.

        :param request: The incoming request
        :return: The caller; unauthenticated when the header is absent or malformed
        """
        return _caller(request.headers.get(self._header))


@dataclass(frozen=True, slots=True)
class Viewer:
    """The person looking at a page: who they are and which domains they may read.

    :ivar caller: The caller the tools see.
    :ivar domains: The domains of the identity mapping for that user; empty means no access.
    """

    caller: Caller
    domains: frozenset[str]

    @property
    def user(self) -> str:
        """The signed-in user, or ``anonymous`` when none was supplied."""
        return self.caller.user

    @property
    def has_access(self) -> bool:
        """True for an authenticated user with at least one readable domain."""
        return self.caller.authenticated and bool(self.domains)

    def may_read(self, domain: str | None) -> bool:
        """Tell whether an item of this domain may be shown. An unlabelled item never may.

        :param domain: The item's domain label
        :return: True only for a labelled domain the user may read
        """
        return domain is not None and domain in self.domains
