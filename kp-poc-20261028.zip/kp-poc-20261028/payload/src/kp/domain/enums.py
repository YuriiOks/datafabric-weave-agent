"""Closed vocabularies of the domain. Values are stored verbatim in string columns."""

from __future__ import annotations

from enum import StrEnum


class SourceKind(StrEnum):
    """Where content comes from."""

    DOCUMENT_LIBRARY = "document_library"
    CONFLUENCE = "confluence"
    JIRA = "jira"
    GITHUB = "github"
    REGULATORY_REPO = "regulatory_repo"


class ApprovalState(StrEnum):
    """Approval ladder of a source item version. ``superseded`` marks older versions."""

    ADMITTED = "admitted"
    PENDING = "pending"
    NON_CONFORMING = "non_conforming"
    EXCLUDED = "excluded"
    WITHDRAWN = "withdrawn"
    SUPERSEDED = "superseded"


class ItemType(StrEnum):
    """The eight kinds of item a link can connect."""

    REQUIREMENT = "requirement"
    CLAUSE = "clause"
    STORY = "story"
    SPEC = "spec"
    TEMPLATE = "template"
    SCHEMA_FIELD = "schema_field"
    CODE = "code"
    TEST = "test"


class LinkKind(StrEnum):
    """Whether a link was stated by a source or guessed by scoring."""

    STATED = "stated"
    GUESSED = "guessed"


class LinkState(StrEnum):
    """Lifecycle of a link. Guessed links start as proposed, review or dropped."""

    STATED = "stated"
    PROPOSED = "proposed"
    REVIEW = "review"
    DROPPED = "dropped"


class ChangeKind(StrEnum):
    """What a change event records about an item."""

    NEW = "new"
    CHANGED = "changed"
    SUPERSEDED = "superseded"
    WITHDRAWN = "withdrawn"


class PassageType(StrEnum):
    """Kinds of searchable passage."""

    CLAUSE = "clause"
    PAGE = "page"
    STORY = "story"
    ACCEPTANCE_CRITERIA = "acceptance_criteria"
    CODE = "code"
    REGISTER_ROW = "register_row"
    SCHEMA_FIELD = "schema_field"


class ExitResult(StrEnum):
    """Outcome of one connectivity exit criterion. No evidence is never a pass."""

    PASS = "PASS"  # noqa: S105 - an outcome label, not a credential
    FAIL = "FAIL"
    INCONCLUSIVE = "INCONCLUSIVE"


class KnowledgeVersionState(StrEnum):
    """Lifecycle of a knowledge version: staged, checked, then published or kept as failed."""

    STAGED = "staged"
    CHECKING = "checking"
    PUBLISHED = "published"
    FAILED_KEPT = "failed_kept"
    RETIRED = "retired"


class CheckSeverity(StrEnum):
    """How a publication check affects publishing."""

    BLOCKING = "blocking"
    WARNING = "warning"
    REPORT = "report"


class ExtractionStatus(StrEnum):
    """State of document extraction for a source item version."""

    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class RunKind(StrEnum):
    """What a run is doing."""

    SWEEP = "sweep"
    CONNECTIVITY = "connectivity"
    BUILD = "build"


class RunOutcome(StrEnum):
    """How a run ended."""

    RUNNING = "running"
    SUCCEEDED = "succeeded"
    PARTIAL = "partial"
    FAILED = "failed"


class ReviewKind(StrEnum):
    """Why a human is asked to look at something."""

    MISSING_DETAIL = "missing_detail"
    UNKNOWN_DOCUMENT_TYPE = "unknown_document_type"
    REGISTER_HEADER = "register_header"
    LOW_STRUCTURE_SCORE = "low_structure_score"
    GUESSED_LINK = "guessed_link"


class ReviewState(StrEnum):
    """Lifecycle of a review item."""

    OPEN = "open"
    RESOLVED = "resolved"


class SpecState(StrEnum):
    """Lifecycle of a drafted spec."""

    DRAFTED = "drafted"
    MERGED = "merged"
    CLOSED = "closed"


class EditionState(StrEnum):
    """State of an edition on a given date."""

    NOT_YET_EFFECTIVE = "not_yet_effective"
    CURRENT = "current"
    SUPERSEDED = "superseded"
    WITHDRAWN = "withdrawn"
