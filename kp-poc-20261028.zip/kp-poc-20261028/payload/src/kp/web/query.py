"""Reading what a person typed into a page's form, with errors a person can act on."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date

from kp.web.errors import InvalidInputError

MAX_TEXT_LENGTH = 500


class QueryForm:
    """The query string of one request.

    Every page is a GET form, so a page can be bookmarked, shared and tested with a plain URL.

    :param values: The query parameters, last value wins
    """

    def __init__(self, values: Mapping[str, str]) -> None:
        self._values = values

    def text(self, name: str) -> str:
        """Read a text field.

        :param name: The field name
        :return: The trimmed text; empty when the field is absent
        :raises InvalidInputError: If the text is longer than a question may be
        """
        value = self._values.get(name, "").strip()
        if len(value) > MAX_TEXT_LENGTH:
            raise InvalidInputError(f"Enter at most {MAX_TEXT_LENGTH} characters.")
        return value

    def day(self, name: str, label: str) -> date | None:
        """Read an optional date typed as YYYY-MM-DD.

        :param name: The field name
        :param label: How the field is called on the page, for the message
        :return: The date, or ``None`` when the field is empty
        :raises InvalidInputError: If the text is not a date
        """
        value = self.text(name)
        if not value:
            return None
        try:
            return date.fromisoformat(value)
        except ValueError as exc:
            raise InvalidInputError(f"{label} must be a date written as YYYY-MM-DD.") from exc

    def number(self, name: str, label: str, *, default: int, low: int, high: int) -> int:
        """Read a whole number within bounds.

        :param name: The field name
        :param label: How the field is called on the page, for the message
        :param default: The value when the field is empty
        :param low: The smallest allowed value
        :param high: The largest allowed value
        :return: The number
        :raises InvalidInputError: If the text is not a whole number within the bounds
        """
        value = self.text(name)
        if not value:
            return default
        if not value.isdecimal() or not low <= int(value) <= high:
            raise InvalidInputError(f"{label} must be a whole number from {low} to {high}.")
        return int(value)
