from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    KeepTogether,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.graphics.shapes import Drawing, Line, Rect, String


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "output" / "pdf" / "data-manifest-ai-leadership-brief.pdf"

INK = colors.HexColor("#171717")
MUTED = colors.HexColor("#4f4f4f")
LINE = colors.HexColor("#7d7d7d")
SOFT = colors.HexColor("#f1f1f1")
ACCENT = colors.HexColor("#c9a35c")
BLUE = colors.HexColor("#5aafe0")
PALE_YELLOW = colors.HexColor("#fffedb")
PALE_PURPLE = colors.HexColor("#f4efff")
GREEN = colors.HexColor("#43c887")
YELLOW = colors.HexColor("#f1c14b")
PLANNED = colors.HexColor("#397ed5")


styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="BriefBody", parent=styles["BodyText"], fontName="Helvetica", fontSize=8.9,
    leading=12.2, textColor=INK, spaceAfter=7, alignment=TA_LEFT,
))
styles.add(ParagraphStyle(
    name="BriefSmall", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.7,
    leading=10.3, textColor=INK, spaceAfter=5,
))
styles.add(ParagraphStyle(
    name="BriefMeta", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.4,
    leading=10, textColor=MUTED, spaceAfter=8,
))
styles.add(ParagraphStyle(
    name="BriefH1", parent=styles["Heading1"], fontName="Helvetica", fontSize=20,
    leading=23, textColor=INK, spaceBefore=0, spaceAfter=6,
))
styles.add(ParagraphStyle(
    name="BriefH2", parent=styles["Heading2"], fontName="Helvetica", fontSize=17,
    leading=20, textColor=INK, spaceBefore=8, spaceAfter=8,
))
styles.add(ParagraphStyle(
    name="BriefH3", parent=styles["Heading3"], fontName="Helvetica", fontSize=12.8,
    leading=15, textColor=INK, spaceBefore=9, spaceAfter=5,
))
styles.add(ParagraphStyle(
    name="BriefH4", parent=styles["Heading4"], fontName="Helvetica-Bold", fontSize=10.2,
    leading=12, textColor=INK, spaceBefore=8, spaceAfter=4,
))
styles.add(ParagraphStyle(
    name="Cell", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.7,
    leading=10.1, textColor=INK,
))
styles.add(ParagraphStyle(
    name="CellBold", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=7.7,
    leading=10.1, textColor=INK,
))
styles.add(ParagraphStyle(
    name="CellSmall", parent=styles["BodyText"], fontName="Helvetica", fontSize=6.9,
    leading=8.7, textColor=INK,
))
styles.add(ParagraphStyle(
    name="Diagram", parent=styles["BodyText"], fontName="Helvetica", fontSize=6.3,
    leading=7.5, textColor=INK, alignment=TA_CENTER,
))


def P(text, style="BriefBody"):
    return Paragraph(text, styles[style])


def cell(text, bold=False, small=False):
    if isinstance(text, Paragraph):
        return text
    return P(text, "CellSmall" if small else ("CellBold" if bold else "Cell"))


def styled_table(rows, widths, header=True, small=False, first_bold=False):
    data = []
    for row_index, row in enumerate(rows):
        out = []
        for col_index, value in enumerate(row):
            is_header = header and row_index == 0
            out.append(cell(value, bold=is_header or (first_bold and col_index == 0 and row_index > 0), small=small))
        data.append(out)
    table = Table(data, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    commands = [
        ("LINEBELOW", (0, 0), (-1, 0 if header else -1), 0.8, LINE),
        ("LINEBELOW", (0, -1), (-1, -1), 0.8, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    if header:
        commands.append(("LINEBELOW", (0, 0), (-1, 0), 1.1, INK))
    for row_index in range(1 if header else 0, len(rows) - 1):
        commands.append(("LINEBELOW", (0, row_index), (-1, row_index), 0.45, LINE))
    table.setStyle(TableStyle(commands))
    return table


def callout(text, border=BLUE):
    table = Table([[P(text, "BriefSmall")]], colWidths=[None], hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), SOFT),
        ("LINEBEFORE", (0, 0), (0, -1), 3.5, border),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return table


def arrow(d, x1, y1, x2, y2):
    d.add(Line(x1, y1, x2, y2, strokeColor=MUTED, strokeWidth=0.7))
    if x2 >= x1:
        d.add(Line(x2, y2, x2 - 4, y2 + 2.4, strokeColor=MUTED, strokeWidth=0.7))
        d.add(Line(x2, y2, x2 - 4, y2 - 2.4, strokeColor=MUTED, strokeWidth=0.7))
    else:
        d.add(Line(x2, y2, x2 + 4, y2 + 2.4, strokeColor=MUTED, strokeWidth=0.7))
        d.add(Line(x2, y2, x2 + 4, y2 - 2.4, strokeColor=MUTED, strokeWidth=0.7))


def box(d, x, y, w, h, lines, fill=PALE_PURPLE, stroke=colors.HexColor("#a999ef"), font=6.2):
    d.add(Rect(x, y, w, h, fillColor=fill, strokeColor=stroke, strokeWidth=0.6))
    line_height = font + 1.2
    start_y = y + h / 2 + (len(lines) - 1) * line_height / 2 - font * 0.35
    for i, line in enumerate(lines):
        d.add(String(x + w / 2, start_y - i * line_height, line, fontName="Helvetica", fontSize=font, fillColor=INK, textAnchor="middle"))


def group(d, x, y, w, h, title, fill=PALE_YELLOW):
    d.add(Rect(x, y, w, h, fillColor=fill, strokeColor=colors.HexColor("#c3b96a"), strokeWidth=0.7))
    d.add(String(x + w / 2, y + h - 10, title, fontName="Helvetica", fontSize=6.2, fillColor=INK, textAnchor="middle"))


def architecture_diagram():
    d = Drawing(480, 182)
    group(d, 10, 124, 460, 48, "Authoritative Sources")
    source_labels = [
        ["HBIM / GDC / CDM", "Group Business Glossary"],
        ["ADM", "Advanced Data Mgmt", "Platform"],
        ["CxO Refinery", "Google BigQuery"],
        ["ServiceNow", "SNOW"],
        ["Application", "Source Code / DB Scan"],
        ["Collibra / DTAS", "Collibra Edge"],
    ]
    for i, label in enumerate(source_labels):
        box(d, 18 + i * 74, 133, 63, 24, label, font=5.4)
    group(d, 178, 46, 292, 67, "DMC Backend (data-controls-automation-api)")
    box(d, 198, 64, 68, 26, ["Manifest Generation", "Services"], font=5.6)
    box(d, 285, 64, 76, 26, ["AI Enrichment", "Orchestrator"], font=5.6)
    box(d, 380, 64, 74, 26, ["Validation Engine", "schema + DMOV / DUSE"], font=5.2)
    group(d, 10, 46, 154, 67, "AI Enrichment (planned / in design)")
    box(d, 18, 71, 62, 25, ["LLM Gateway", "gpt-5 / mini / batch"], font=5.3)
    box(d, 91, 71, 65, 25, ["Embeddings", "text-embedding-3-large / small"], font=5.0)
    box(d, 28, 53, 55, 13, ["Privacy / ISR"], font=5.0)
    box(d, 91, 53, 55, 13, ["DQ Rule Suggestor"], font=5.0)
    group(d, 194, 10, 108, 28, "DMC Frontend")
    box(d, 204, 15, 88, 16, ["ITSO / CDAO Review and Vetting UI"], font=5.2)
    group(d, 321, 3, 149, 36, "Downstream")
    box(d, 329, 10, 63, 19, ["Git Manifest Repos"], font=5.1)
    box(d, 401, 10, 61, 19, ["DLAS -> SNOW + Collibra", "Lineage / DataHub"], font=4.7)
    for sx in [50, 124, 198, 272, 346, 420]:
        arrow(d, sx, 124, 324, 113)
    arrow(d, 260, 46, 260, 38)
    arrow(d, 304, 15, 360, 29)
    d.add(String(240, 177, "via Group AI Platform", fontName="Helvetica", fontSize=5.3, fillColor=MUTED, textAnchor="middle"))
    return d


def workflow_diagram():
    d = Drawing(480, 92)
    labels = [
        ["User onboards", "application"],
        ["Metadata harvesting", "source-code / DB scan"],
        ["Integration retrieval", "CxO / BigQuery"],
        ["DCOS scopes key", "metadata columns"],
        ["ADM PBT enrichment", "and matching"],
        ["ITSO / CDAO", "vetting in DMC"],
        ["Approve -> Git -> DLAS", "SNOW + Collibra"],
    ]
    xs = [3, 72, 141, 210, 279, 348, 417]
    for x, label in zip(xs, labels):
        box(d, x, 45, 61, 26, label, font=5.1)
    for x in xs[:-1]:
        arrow(d, x + 61, 58, x + 69, 58)
    d.add(String(240, 28, "Integration retrieval + metadata harvesting run in parallel", fontName="Helvetica", fontSize=6.2, fillColor=MUTED, textAnchor="middle"))
    d.add(String(240, 14, "Reject / Correct -> GDC and Business Context suggestions; DQ suggestions in design", fontName="Helvetica", fontSize=5.5, fillColor=MUTED, textAnchor="middle"))
    return d


def maintenance_diagram():
    d = Drawing(480, 88)
    labels = [
        ["Active CRs", "ServiceNow / KONG"],
        ["Merged PRs"],
        ["Jira tickets"],
        ["CR Watcher / Analyser", "dmc-cr-extraction + GAIP"],
        ["Manifest-relevant", "change?"],
        ["Re-harvest /", "re-enrichment"],
        ["Re-run harvest + AI", "changed scope"],
        ["ITSO / CDAO", "review changed manifest"],
        ["Update Git repos", "DLAS -> SNOW + Collibra"],
    ]
    xs = [3, 3, 3, 74, 151, 218, 286, 354, 421]
    ys = [59, 42, 25, 42, 42, 42, 42, 42, 42]
    widths = [62, 62, 62, 70, 60, 60, 62, 62, 55]
    for x, y, w, label in zip(xs, ys, widths, labels):
        box(d, x, y, w, 20, label, font=4.8)
    arrow(d, 65, 59, 74, 52)
    arrow(d, 65, 42, 74, 49)
    arrow(d, 65, 25, 74, 43)
    for x, w in zip([144, 211, 278, 348, 416], [60, 60, 62, 62, 55]):
        arrow(d, x, 52, x + 7, 52)
    d.add(String(180, 72, "Yes", fontName="Helvetica", fontSize=5.0, fillColor=MUTED, textAnchor="middle"))
    d.add(String(108, 13, "No -> No action", fontName="Helvetica", fontSize=5.3, fillColor=MUTED, textAnchor="middle"))
    return d


class BriefDocTemplate(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="normal")
        self.addPageTemplates([PageTemplate(id="brief", frames=[frame], onPage=draw_page)])


def draw_page(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.2)
    canvas.setFillColor(MUTED)
    canvas.drawString(doc.leftMargin, A4[1] - 27, "Data Manifest AI - Leadership Brief.md")
    canvas.drawRightString(A4[0] - doc.rightMargin, A4[1] - 27, "2026-07-31")
    canvas.setStrokeColor(LINE)
    canvas.setLineWidth(0.55)
    canvas.line(doc.leftMargin, 30, A4[0] - doc.rightMargin, 30)
    canvas.setFont("Helvetica", 7.2)
    canvas.drawCentredString(A4[0] / 2, 17, f"{doc.page} / 7")
    canvas.restoreState()


def page_break():
    return PageBreak()


def build_story():
    story = []
    # Page 1
    story += [P("Data Manifest AI - Leadership Brief", "BriefH1")]
    story += [P("<b>Use case:</b> UC0004963 · <b>Product:</b> Data Management Centre (DMC) · <b>Audience:</b> Leadership · <b>Status date:</b> 2026-07-31 · <b>Companion detail:</b> <font color='#c9a35c'>UC0004963 - Best Practice Card - Data Manifest AI Use Case.md</font>", "BriefMeta")]
    story += [P("1. Executive summary", "BriefH2")]
    story += [P("HSBC runs thousands of applications and integrations. The evidence of <i>what</i> each data system holds, <i>where it moves</i>, <i>what it means</i> in business terms, and <i>how it is controlled</i> is captured in four \"Data Manifest\" files per application (<font color='#c9a35c'>application.json, integration.json, techmetadata.json, lineage.json</font>). Producing and maintaining these files by hand is slow and inconsistent, and goes stale within weeks - a direct exposure to <b>BCBS 239, GDPR and SOX</b> obligations, slow incident response, and risky migrations.")]
    story += [P("The <b>Data Manifest</b> capability in DMC assembles these files from authoritative sources, uses AI to do the <i>semantic</i> work (mapping technical columns to governed business terms, suggesting data categories and quality rules), and routes every suggestion to <b>ITSO/CDAO</b> for approval before anything is committed. <b>Nothing is straight-through - a human always vets AI output.</b>")]
    story += [P("Crucially, the manifest is a <b>living document, not a one-off onboarding artefact</b>. Applications change constantly, and metadata can drift out of date with every release. The capability watches each onboarded application's <b>Change Requests, merged PRs and Jira tickets</b>, decides whether a change affects the manifest, and re-triggers enrichment so the files stay accurate for the <b>entire lifetime of the application</b> - again, with human approval before commit.")]
    story += [callout("<b>Honest status:</b> today the platform is a working <b>metadata-orchestration engine</b> with the data plumbing and review UI in place. The <b>AI layer</b> (semantic suggestion and quality-rule generation) and the <b>ADM enrichment integration</b> are selected and designed, but not yet built.")]
    story += [P("2. The problem and why AI", "BriefH2")]
    rows = [
        ["Without this capability", "Why AI (not just rules)"],
        ["Metadata authored by hand, per application, and stale within weeks", "Mapping cryptically-named columns (<font color='#c9a35c'>cust_nm</font>) to the correct governed business term is <b>semantic and ambiguous</b> - rules and regex cannot resolve synonyms to one taxonomy term."],
        ["Inconsistent data categories and quality controls across systems", "The governed vocabularies are large and scarce experts are the bottleneck. AI can propose, a human confirms."],
        ["Regulatory evidence (BCBS 239 / GDPR / SOX) is manual and slow", "AI-assisted enrichment targets minutes per table versus hours, at high first-pass accuracy, <b>with human vetting</b>."],
    ]
    story += [styled_table(rows, [220, 273], small=True)]
    story += [callout("<b>Programme target:</b> efficiency figures such as hours -> minutes and 85-90% first-pass accuracy are not yet independently benchmarked.")]
    story += [page_break()]

    # Page 2
    story += [P("3. Overall architecture", "BriefH2"), architecture_diagram(), Spacer(1, 5)]
    story += [P("<b>How to read it.</b> Authoritative sources on the left feed the DMC backend, which assembles each manifest file and calls AI enrichment services through the Group AI Platform to add business meaning and quality rules. Everything is validated, then surfaced to ITSO/CDAO in the DMC frontend. On approval, the manifest is committed to Git and propagated by <b>DLAS</b> to ServiceNow and Collibra.")]
    story += [P("End-to-end onboarding workflow", "BriefH3"), workflow_diagram(), Spacer(1, 4)]
    story += [P("A user onboards an application; <b>integration retrieval and metadata harvesting run in parallel</b>. Harvested metadata is scoped into <b>DCOS (Data Control of Scope)</b> - the application owner's curated set of the most important columns. From there, scoped metadata is enriched through PBT matching on ADM, while AI suggestors propose data categories, business context, and quality rules. All of it is gated by ITSO/CDAO vetting before commit.")]
    story += [P("Manifests are living documents - the maintenance loop", "BriefH3"), P("Onboarding produces the first version of the manifest. Keeping it accurate for years is the harder problem. A <b>change-aware maintenance loop</b> monitors each onboarded application's activity and only re-runs enrichment when a change actually affects the manifest, avoiding both drift (stale files) and noise (unnecessary re-reviews).")]
    story += [page_break()]

    # Page 3
    story += [P("...enrichment when a change actually affects the manifest - avoiding both drift (stale files) and noise (unnecessary re-reviews).", "BriefSmall"), maintenance_diagram(), Spacer(1, 4)]
    story += [P("4. The agents - functionality, input and output", "BriefH2"), P("The solution is <b>agentic but deliberately lean</b>: three components genuinely reason and suggest. The rest are ordinary tool/API calls or a manual step, listed separately for honesty.")]
    story += [P("4.1 AI agents (owned by this solution)", "BriefH3"), P("Agent A - GDC &amp; Business Context Suggestor", "BriefH4")]
    agent_a = [
        ["What it does", "Recommends the correct <b>Group Data Category (GDC)</b> for applications and technical datasets, and refreshes an integration's <b>Business Context</b> when it lapses."],
        ["Input", "Application/dataset metadata from CxO/BigQuery (GDCR analysis tables); governed GDC/CDM domains (Collibra, surfaced via CxO); CxO reference tables for line-of-business validity; <i>planned</i> embeddings."],
        ["Functionality / triggers", "Fires when a <b>new technical dataset is added</b>, retrieved data has <b>no CDM associated</b>, or a Business Context has <b>expired</b>. Planned semantic ranking gives a confidence score and alternatives."],
        ["Output", "Suggested GDC(s), planned, with confidence score and alternatives, plus refreshed Business Context presented to ITSO/CDAO for approval."],
        ["Status", "<b>Partially built.</b> Data-driven GDC association and a CDAO tag auto-approve flow exist; AI/semantic ranking is UI-ready but <b>not yet built</b>."],
    ]
    story += [styled_table(agent_a, [115, 378], header=False, first_bold=True, small=True)]
    story += [P("Agent B - Data Quality Rule Suggestor", "BriefH4")]
    agent_b = [
        ["What it does", "Proposes <b>preventive (ingestion-time) data-quality rules</b> for each field."],
        ["Input", "Per-field <b>code / DDL evidence</b> from harvested metadata; a <b>governed catalog</b> of DQ Control Descriptions, each mapped to a Dimension."],
        ["Functionality", "An LLM is constrained to the governed catalog and may not invent rules. It fills placeholder values, avoids contradictions, and classifies each rule under a Dimension: Completeness, Conformity, Uniqueness, or Referential Integrity."],
    ]
    story += [styled_table(agent_b, [115, 378], header=False, first_bold=True, small=True)]
    story += [page_break()]

    # Page 4
    story += [P("Agent B - Data Quality Rule Suggestor (continued)", "BriefH4")]
    story += [styled_table([
        ["Output", "A list of <font color='#c9a35c'>[Dimension, DQ Control Description]</font> per field, for example <i>Conformity - Field must be formatted as YYYYMMDD</i>, human-vetted before use."],
        ["Status", "<b>In design.</b> Prototype prompt and rule catalog exist (<font color='#c9a35c'>DQRules.json, context.json</font>); functionality is not yet built."],
    ], [115, 378], header=False, first_bold=True, small=True)]
    story += [P("Agent C - Change-Aware Manifest Maintenance (CR Watcher / Analyser)", "BriefH4")]
    agent_c = [
        ["What it does", "Keeps the manifest accurate for the <b>whole life of the application</b> by watching for changes and re-triggering enrichment only when the manifest is actually affected."],
        ["Input", "<b>Active ServiceNow Change Requests</b> retrieved via KONG, keyed by business unit + application ID; <b>merged PRs</b>; and <b>Jira tickets</b> for each onboarded application."],
        ["Functionality / triggers", "Runs continuously per onboarded app. An LLM via GAIP reads CR, PR, and Jira content, decides whether a change is manifest-relevant (schema change, new dataset, new integration, control change), and triggers re-harvest/re-enrichment for the affected scope. Non-relevant changes are ignored."],
        ["Output", "A change-impact decision and, when relevant, a <b>re-enrichment job</b> that produces an updated manifest diff for ITSO/CDAO review."],
        ["Status", "<b>In early build.</b> <font color='#c9a35c'>dmc-cr-extraction</font> already retrieves ServiceNow CRs via KONG and has GAIP <font color='#c9a35c'>gpt-5</font> chat plumbing; PR/Jira ingestion, relevance classification, and the analysis-and-trigger loop are <b>not yet built</b>."],
    ]
    story += [styled_table(agent_c, [115, 378], header=False, first_bold=True, small=True)]
    story += [P("4.2 Supporting components (not agents)", "BriefH3")]
    support = [
        ["Component", "Input", "Output", "Nature"],
        ["Metadata Harvester", "Application source code / database catalogue; metadata only - never row data", "techmetadata.json", "Existing API/workflow; auto-runs on application change"],
        ["Application assembly", "ServiceNow / CxO records", "application.json", "Existing API/workflow"],
        ["Integration retrieval", "CxO / BigQuery inbound integration IDs", "integration.json", "Existing query/workflow"],
        ["HBIM PBT Mapping", "Scoped metadata (DCOS)", "PBT matches returned to Collibra/CxO", "Owned by ADM; enrichment happens on ADM side; DMC-to-ADM API is open decision"],
        ["Privacy / ISR classification", "User selection when adding a dataset", "ISR level (Non-HSBC ... Highly Restricted)", "Manual today; future AI candidate"],
    ]
    story += [styled_table(support, [104, 145, 105, 139], small=True, first_bold=True)]
    story += [page_break()]

    # Page 5
    story += [P("5. Current status vs roadmap (honest view)", "BriefH2")]
    status = [
        ["Capability", "Status"],
        ["CxO/BigQuery sourcing (service account), Collibra integration", "<font color='#43c887'>●</font> Built"],
        ["DCOS scoping, manifest assembly, validation, ITSO/CDAO vetting UI", "<font color='#43c887'>●</font> Built"],
        ["GDC data association + CDAO tag auto-approve", "<font color='#43c887'>●</font> Built"],
        ["Manual ISR / privacy classification", "<font color='#43c887'>●</font> Built"],
        ["ServiceNow CR retrieval (KONG) + GAIP gpt-5 plumbing", "<font color='#43c887'>●</font> Built (dmc-cr-extraction)"],
        ["<b>AI semantic ranking of GDC/PBT candidates</b>", "<font color='#f1c14b'>●</font> UI-ready, backend not built"],
        ["<b>DQ Rule Suggestor (LLM + governed catalog)</b>", "<font color='#f1c14b'>●</font> In design (prototype prompt exists)"],
        ["<b>Change-aware maintenance loop (CR/PR/Jira analysis + auto-trigger)</b>", "<font color='#f1c14b'>●</font> In early build (retrieval + GAIP exist; analyse-and-trigger not built)"],
        ["<b>ADM PBT enrichment integration</b>", "<font color='#f1c14b'>●</font> Designed, not built (needs ADM API discussion)"],
        ["Semantic search / natural-language discovery", "<font color='#397ed5'>●</font> Planned (candidate: Elasticsearch)"],
        ["lineage.json generation (OpenLineage)", "<font color='#397ed5'>●</font> Future scope"],
        ["AI-assisted privacy / ISR classification", "<font color='#397ed5'>●</font> Future roadmap"],
    ]
    story += [styled_table(status, [310, 243], small=True)]
    story += [callout("<b>Verified against code:</b> no LLM/embedding/vector/semantic-search libraries are present in the repositories yet. The AI models named below are <b>selected, not integrated</b>. Selected AI stack: embeddings <font color='#c9a35c'>text-embedding-3-large/small</font>; LLM <font color='#c9a35c'>gpt-5 / mini / batch</font> by use case; all through the Group AI Platform, final routing to confirm.")]
    story += [P("6. Possible future extensions", "BriefH2")]
    future = [
        "<b>Full AI semantic ranking + natural-language discovery</b> - find datasets and systems by plain-English query, such as \"which systems hold customer credit exposure\"; a copilot for data governance.",
        "<b>AI-assisted privacy &amp; ISR classification</b> - auto-detect PII or sensitive fields and propose regulatory tags.",
        "<b>Lineage automation</b> - generate <font color='#c9a35c'>lineage.json</font> using OpenLineage, with impact and root-cause analysis.",
        "<b>Learning from history</b> - feed approved and rejected suggestions back; move high-confidence items to threshold-based auto-approval.",
        "<b>Bulk / portfolio mapping</b> - enrich an entire application estate in one pass rather than table by table.",
        "<b>DQ auto-remediation</b> - raise tickets or trigger workflows when a preventive rule is breached.",
        "<b>Native ADM PBT surfacing in DMC</b> - display ADM enrichment results directly in the review UI.",
        "<b>Extend to more control frameworks</b> - automate DPRIV and DSTO alongside movement and usage.",
        "<b>Deepen change-aware maintenance</b> - extend Agent C to full PR and Jira ingestion, drift alerts, and eventual low-risk auto-approval.",
    ]
    for index, item in enumerate(future, 1):
        story.append(P(f"{index}. {item}", "BriefSmall"))
    story += [page_break()]

    # Page 6
    story += [P("7. Key dependencies and risks", "BriefH2")]
    risks = [
        "<b>Governed vocabularies must be readable by the AI</b> - approved GDC/PBT terms, business-context validity (line of business x legal entity), and technical-pattern references are required. If the AI cannot read these, it can produce values that pass schema checks but <b>fail control validation</b>.",
        "<b>ADM ownership of PBT enrichment</b> - a critical external dependency; the DMC-versus-ADM boundary for surfacing results needs a leadership-level decision.",
        "<b>Change-relevance accuracy</b> - a false negative silently lets the manifest go stale; a false positive floods owners with needless reviews. The classifier needs measurement and a conservative default.",
        "<b>AI layer not yet built</b> - the value case depends on delivering semantic suggestion and DQ modules; today the differentiator is orchestration and review workflow.",
        "<b>Human-in-the-loop is a feature, not a gap</b> - it is the control that makes AI suggestions safe to adopt in a regulated environment.",
    ]
    for risk in risks:
        story.append(P(f"- {risk}", "BriefBody"))
    story += [P("8. Glossary (quick reference)", "BriefH2")]
    glossary_first = [
        ["Term", "Meaning"],
        ["DMC", "Data Management Centre - the product delivering this capability"],
        ["GDC / CDM", "Group Data Category / Common Data Model - governed data-classification vocabularies"],
        ["HBIM / PBT", "HSBC Business Information Model / Preferred Business Term - canonical business meaning for a column"],
    ]
    story += [styled_table(glossary_first, [90, 463], small=True, first_bold=True)]
    story += [page_break()]

    # Page 7
    story += [P("8. Glossary (continued)", "BriefH2")]
    glossary_rest = [
        ["Term", "Meaning"],
        ["ADM", "Advanced Data Management Platform - owns HBIM PBT enrichment and matching"],
        ["CxO Refinery", "HSBC's Google BigQuery warehouse; source of application/integration/GDC/reference data"],
        ["DCOS", "Data Control of Scope - owner-curated set of the most important metadata columns"],
        ["TDS", "Technical Data Set - a dataset within an inbound integration, carrying ISR + GDC"],
        ["DLAS", "Data Lineage Automation Service - propagates approved manifests to ServiceNow + Collibra"],
        ["ITSO / CDAO", "IT Service Owner / Chief Data &amp; Analytics Office - the human approvers"],
        ["ISR", "Information Security classification level of a dataset"],
        ["DMOV / DUSE", "Control validations governing integration.json / techmetadata.json"],
        ["CR", "Change Request - a ServiceNow record describing a planned change to an application"],
        ["GAIP", "Group AI Platform - HSBC's governed gateway for LLM access (e.g. gpt-5)"],
        ["KONG", "API gateway used to retrieve ServiceNow change-request data"],
    ]
    story += [styled_table(glossary_rest, [90, 463], small=True, first_bold=True)]
    story += [Spacer(1, 18), callout("<b>Reading note:</b> this leadership brief is intentionally explicit about current capability, selected-but-not-integrated AI components, and the controls that remain human-owned.", border=ACCENT)]
    return story


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = BriefDocTemplate(
        str(OUT), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=15 * mm, bottomMargin=15 * mm, title="Data Manifest AI - Leadership Brief",
        author="OpenAI",
    )
    doc.build(build_story())
    print(OUT)


if __name__ == "__main__":
    main()
