"""US-25: gateway client framing, headers, renewal rules; token provider behaviour."""

from __future__ import annotations

import threading
from collections.abc import Callable
from datetime import timedelta

import httpx
import pytest
from pydantic import SecretStr

from connectivity.support import IDENTITY_HEADER, SOURCE_HEADER, SOURCE_SECRET, Stack
from kp.connectivity import (
    ClientCredentialsTokenProvider,
    FakeGateway,
    GatewayClient,
    GatewayProtocolError,
)
from kp.connectivity.fake_gateway import FAKE_BASE_URL, FAKE_TOKEN_URL
from kp.connectivity.models import CallObservation, JsonObject, Route
from kp.connectivity.tokens import FixedTokenProvider
from kp.domain import SourceKind
from kp.errors import SourceAuthRefusedError, SourceUnavailableError


class _Collect:
    def __init__(self) -> None:
        self.observations: list[CallObservation] = []

    def record(self, observation: CallObservation) -> None:
        self.observations.append(observation)


def _get_page(stack: Stack) -> JsonObject | None:
    result = stack.client_for().call_tool(
        stack.routes[SourceKind.CONFLUENCE], "get_page", {"page_id": "7001"}
    )
    return result.structured


@pytest.mark.parametrize("sse", [False, True], ids=["json", "sse"])
def test_us25_json_and_event_stream_framing_are_both_read(stack: Stack, sse: bool) -> None:
    stack.fake.sse = sse

    listing = stack.client_for().list_tools(stack.routes[SourceKind.JIRA])
    page = _get_page(stack)

    assert [tool.name for tool in listing.signatures] == ["get_issue", "get_attachment"]
    assert page is not None
    assert page["id"] == "7001"


@pytest.mark.parametrize("structured", [False, True], ids=["text-json", "structured-content"])
def test_us25_objects_are_read_from_text_or_structured_content(
    stack: Stack, structured: bool
) -> None:
    stack.fake.structured_content = structured

    page = _get_page(stack)

    assert page is not None
    assert page["title"] == "Payment operations overview"


def test_us25_prose_result_has_no_object(stack: Stack) -> None:
    stack.fake.prose_namespaces = {"confluence"}

    result = stack.client_for().call_tool(
        stack.routes[SourceKind.CONFLUENCE], "get_page", {"page_id": "7001"}
    )

    assert result.structured is None
    assert "I found" in result.text


def test_us25_header_names_come_from_settings_and_credentials_go_in_them(stack: Stack) -> None:
    seen: dict[str, str] = {}

    def spy(request: httpx.Request) -> httpx.Response:
        if request.url.path != "/oauth/token":
            seen.update({k: v for k, v in request.headers.items() if k.startswith("x-test")})
        return stack.fake.transport().handle_request(request)

    http = httpx.Client(transport=httpx.MockTransport(spy))
    tokens = ClientCredentialsTokenProvider(
        http=http,
        token_url=FAKE_TOKEN_URL,
        client_id="stand-in-client",
        client_secret=SecretStr("stand-in-secret"),
        clock=stack.clock,
        refresh_fraction=0.8,
    )
    client = GatewayClient(
        http=http,
        base_url=FAKE_BASE_URL,
        tokens=tokens,
        identity_header=IDENTITY_HEADER,
        source_header=SOURCE_HEADER,
        source_credentials={SourceKind.JIRA: SecretStr(SOURCE_SECRET)},
        clock=stack.clock,
    )

    client.list_tools(stack.routes[SourceKind.JIRA])

    assert set(seen) == {IDENTITY_HEADER, SOURCE_HEADER}
    assert seen[IDENTITY_HEADER].startswith("stand-in-token-")
    assert seen[SOURCE_HEADER] == SOURCE_SECRET


def test_us25_an_authorization_header_name_carries_a_bearer_token(stack: Stack) -> None:
    fake = FakeGateway(stack.clock, identity_header="authorization", source_header=SOURCE_HEADER)
    http = httpx.Client(transport=fake.transport())
    tokens = ClientCredentialsTokenProvider(
        http=http,
        token_url=FAKE_TOKEN_URL,
        client_id="stand-in-client",
        client_secret=SecretStr("stand-in-secret"),
        clock=stack.clock,
        refresh_fraction=0.8,
    )
    client = GatewayClient(
        http=http,
        base_url=FAKE_BASE_URL,
        tokens=tokens,
        identity_header="Authorization",
        source_header=SOURCE_HEADER,
        source_credentials={SourceKind.JIRA: SecretStr(SOURCE_SECRET)},
        clock=stack.clock,
    )

    assert len(client.list_tools(stack.routes[SourceKind.JIRA]).signatures) == 2


def test_us25_tool_list_is_followed_across_pages(stack: Stack) -> None:
    stack.fake.list_page_size = 1

    listing = stack.client_for().list_tools(stack.routes[SourceKind.CONFLUENCE])

    assert [tool.name for tool in listing.signatures] == ["get_page", "get_attachment"]
    assert len(listing.raw_tools) == 2
    assert [r.method for r in stack.fake.requests] == ["tools/list", "tools/list"]


def test_us25_one_forced_renewal_after_401_then_the_call_succeeds(stack: Stack) -> None:
    _get_page(stack)
    stack.fake.revoke_tokens()

    page = _get_page(stack)

    assert page is not None
    assert stack.fake.token_requests == 2
    assert [r.status for r in stack.fake.requests] == [200, 401, 200]


def test_us25_second_401_raises_a_typed_error_after_exactly_one_renewal(stack: Stack) -> None:
    stack.fake.reject_all = True

    with pytest.raises(SourceAuthRefusedError):
        _get_page(stack)

    assert stack.fake.token_requests == 2
    assert [r.status for r in stack.fake.requests] == [401, 401]


def test_us25_bad_parameter_is_a_typed_protocol_error_with_the_code(stack: Stack) -> None:
    with pytest.raises(GatewayProtocolError) as caught:
        stack.client_for().call_tool(stack.routes[SourceKind.CONFLUENCE], "get_page", {})

    assert caught.value.code == -32602


def test_us25_unknown_route_and_server_failure_are_typed(stack: Stack) -> None:
    with pytest.raises(GatewayProtocolError):
        stack.client_for().list_tools(Route(namespace="nowhere", source=SourceKind.JIRA))

    def failing(request: httpx.Request) -> httpx.Response:
        return (
            httpx.Response(503)
            if request.url.path != "/oauth/token"
            else (stack.fake.transport().handle_request(request))
        )

    broken = GatewayClient(
        http=httpx.Client(transport=httpx.MockTransport(failing)),
        base_url=FAKE_BASE_URL,
        tokens=FixedTokenProvider(SecretStr("x"), stack.clock),
        identity_header=IDENTITY_HEADER,
        source_header=None,
        source_credentials={},
        clock=stack.clock,
    )
    with pytest.raises(SourceUnavailableError):
        broken.list_tools(stack.routes[SourceKind.JIRA])


def test_us25_every_exchange_is_observed_with_status_and_latency(stack: Stack) -> None:
    sink = _Collect()

    stack.client_for(sink).call_tool(
        stack.routes[SourceKind.CONFLUENCE], "get_page", {"page_id": "7001"}
    )

    [seen] = sink.observations
    assert seen.tool == "confluence/get_page"
    assert seen.operation == "tools/call"
    assert seen.http_status == 200
    assert seen.object_count == 1
    assert "version.number" in seen.surviving_fields
    assert seen.latency_ms >= 0
    assert seen.token_refreshed is False  # the first sign-in is not a renewal


# -- token provider ---------------------------------------------------------------------------


def test_us25_token_is_reused_until_80_percent_of_its_life_is_used(stack: Stack) -> None:
    first = stack.tokens.acquire()
    stack.clock.set(stack.clock.now() + timedelta(seconds=1800 * 0.79))
    reused = stack.tokens.acquire()
    stack.clock.set(stack.clock.now() + timedelta(seconds=1800 * 0.02))
    renewed = stack.tokens.acquire()

    assert first.refreshed is False
    assert reused.refreshed is False
    assert reused.token.serial == first.token.serial
    assert renewed.refreshed is True
    assert renewed.token.serial == first.token.serial + 1
    assert stack.fake.token_requests == 2


def test_us25_concurrent_callers_cause_one_token_request(stack: Stack) -> None:
    results = []
    barrier = threading.Barrier(8)

    def worker() -> None:
        barrier.wait()
        results.append(stack.tokens.acquire())

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert stack.fake.token_requests == 1
    assert len({grant.token.serial for grant in results}) == 1
    assert sum(grant.refreshed for grant in results) == 0  # one sign-in, no renewal


def test_us25_concurrent_forced_renewals_of_the_same_token_fetch_once(stack: Stack) -> None:
    rejected = stack.tokens.acquire().token
    barrier = threading.Barrier(8)
    serials = []

    def worker() -> None:
        barrier.wait()
        serials.append(stack.tokens.force_refresh(rejected).token.serial)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    assert stack.fake.token_requests == 2
    assert set(serials) == {rejected.serial + 1}


@pytest.mark.parametrize(
    ("handler", "error"),
    [
        (lambda _: httpx.Response(401), SourceAuthRefusedError),
        (lambda _: httpx.Response(503), SourceUnavailableError),
        (lambda _: httpx.Response(200, json={"access_token": "t"}), GatewayProtocolError),
        (lambda _: httpx.Response(200, text="not json"), GatewayProtocolError),
        (
            lambda _: httpx.Response(200, json={"access_token": "t", "expires_in": 0}),
            GatewayProtocolError,
        ),
    ],
    ids=["refused", "down", "no-lifetime", "not-json", "zero-lifetime"],
)
def test_us25_token_endpoint_failures_are_typed(
    stack: Stack,
    handler: Callable[[httpx.Request], httpx.Response],
    error: type[Exception],
) -> None:
    provider = ClientCredentialsTokenProvider(
        http=httpx.Client(transport=httpx.MockTransport(handler)),
        token_url=FAKE_TOKEN_URL,
        client_id="c",
        client_secret=SecretStr("s"),
        clock=stack.clock,
        refresh_fraction=0.8,
    )

    with pytest.raises(error):
        provider.acquire()


def test_us25_token_value_is_not_printed(stack: Stack) -> None:
    grant = stack.tokens.acquire()

    assert grant.token.value.get_secret_value() not in repr(grant)
    assert grant.token.value.get_secret_value() not in str(grant)
