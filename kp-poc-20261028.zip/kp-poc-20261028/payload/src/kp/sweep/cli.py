"""``kp sweep``: parser registration and handler.

The integrator wires it into ``kp.cli``::

    sweep_cli.add_parser(subparsers)
    ...
    return args.handler(args, runtime)

``runtime`` is built with :func:`build_runtime` from the settings and a
:class:`~kp.sweep.ports.TargetProvider` that knows how to construct the real readers.
"""

from __future__ import annotations

import sys
import time
from argparse import ArgumentParser, Namespace, _SubParsersAction
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO

from kp.clock import Clock, SystemClock
from kp.config import Settings
from kp.domain import RunOutcome, SourceKind
from kp.store import Database
from kp.sweep.engine import Sweeper
from kp.sweep.freshness import check_freshness
from kp.sweep.gate import ApprovalGate
from kp.sweep.models import FreshnessReport, SweepSummary, TargetStatus
from kp.sweep.ports import ContentProcessor, RawStore, Sleeper, TargetProvider
from kp.sweep.processing import NullContentProcessor
from kp.sweep.rawstore import LocalRawStore
from kp.sweep.store import SweepStore


@dataclass(frozen=True)
class SweepRuntime:
    """Everything the ``sweep`` command needs besides its arguments."""

    settings: Settings
    database: Database
    targets: TargetProvider
    processor: ContentProcessor
    raw_store: RawStore
    clock: Clock
    sleeper: Sleeper


def build_runtime(
    settings: Settings,
    targets: TargetProvider,
    *,
    processor: ContentProcessor | None = None,
    raw_store: RawStore | None = None,
    database: Database | None = None,
    clock: Clock | None = None,
    sleeper: Sleeper = time.sleep,
) -> SweepRuntime:
    """Assemble the runtime, defaulting what the settings can provide.

    :param settings: Platform settings
    :param targets: Builds the readers for the selected sources
    :param processor: Content processor; the no-op one until the parsers are connected
    :param raw_store: Raw store; a local directory under ``settings.data_dir`` by default
    :param database: Database; built from the settings by default
    :param clock: Time source; the system clock by default
    :param sleeper: Called with seconds to wait when a source rate-limits
    :return: The runtime
    """
    return SweepRuntime(
        settings=settings,
        database=database or Database.from_settings(settings),
        targets=targets,
        processor=processor or NullContentProcessor(),
        raw_store=raw_store or LocalRawStore(Path(settings.data_dir) / "raw"),
        clock=clock or SystemClock(),
        sleeper=sleeper,
    )


def add_parser(subparsers: _SubParsersAction[ArgumentParser]) -> ArgumentParser:
    """Register ``sweep`` on the main parser's subparsers.

    :param subparsers: The subparsers action of the ``kp`` parser
    :return: The ``sweep`` parser, with ``handler`` set as its default
    """
    parser = subparsers.add_parser(
        "sweep", help="Sweep sources for new, changed and withdrawn items"
    )
    parser.add_argument(
        "--source",
        dest="sources",
        action="append",
        choices=[source.value for source in SourceKind],
        default=[],
        help="Sweep only this source; repeat for several (default: every configured source)",
    )
    parser.add_argument(
        "--freshness",
        action="store_true",
        help="Do not sweep; list sources without a successful sweep in the stale window",
    )
    parser.set_defaults(handler=run_sweep_command)
    return parser


def run_sweep_command(args: Namespace, runtime: SweepRuntime, out: TextIO | None = None) -> int:
    """Run ``kp sweep``.

    :param args: Parsed arguments (``sources``, ``freshness``)
    :param runtime: The assembled collaborators
    :param out: Where to print the report; standard output when omitted
    :return: 0 when nothing failed or is stale, 1 otherwise
    """
    stream = out or sys.stdout
    selected = [SourceKind(name) for name in args.sources]
    runtime.database.ensure_schema(runtime.settings)
    if args.freshness:
        return _print_freshness(_freshness(runtime, selected), stream)
    sweeper = Sweeper(
        runtime.database,
        clock=runtime.clock,
        processor=runtime.processor,
        raw_store=runtime.raw_store,
        sleeper=runtime.sleeper,
        gate=ApprovalGate(
            approved_label=runtime.settings.confluence_approved_label,
            document_types=frozenset(runtime.settings.document_types),
        ),
        thresholds=runtime.settings.thresholds,
    )
    summary = sweeper.run(list(runtime.targets.targets(selected)))
    return _print_summary(summary, stream)


def _freshness(runtime: SweepRuntime, selected: list[SourceKind]) -> FreshnessReport:
    # Without --source, every source the provider would sweep must have been swept.
    expected = selected or [target.reader.kind for target in runtime.targets.targets(selected)]
    with runtime.database.transaction() as connection:
        return check_freshness(
            SweepStore(connection),
            now=runtime.clock.now(),
            thresholds=runtime.settings.thresholds,
            expected=expected,
        )


def _print_freshness(report: FreshnessReport, out: TextIO) -> int:
    for item in report.stale:
        last = item.last_success_at.isoformat() if item.last_success_at else "never"
        out.write(f"stale {item.source.value} scope={item.scope or '-'} last_success={last}\n")
    for alert in report.alerts:
        out.write(
            f"alert {alert.source.value} scope={alert.scope or '-'} "
            f"consecutive_failures={alert.consecutive_failures}\n"
        )
    if report.is_healthy:
        out.write("all sources fresh\n")
    return 0 if report.is_healthy else 1


def _print_summary(summary: SweepSummary, out: TextIO) -> int:
    out.write(f"run {summary.run_id} {summary.outcome.value}\n")
    for target in summary.targets:
        out.write(
            f"{target.source.value} scope={target.scope or '-'} {target.status.value} "
            f"pages={target.pages}\n"
        )
    out.write(
        f"versions={summary.versions_recorded} changes={summary.state_changes} "
        f"work_items={len(summary.work_items)}\n"
    )
    for alert in summary.alerts:
        out.write(f"alert {alert.source.value} consecutive_failures={alert.consecutive_failures}\n")
    failed = any(target.status is TargetStatus.FAILED for target in summary.targets)
    return 1 if failed or summary.outcome is RunOutcome.FAILED else 0
