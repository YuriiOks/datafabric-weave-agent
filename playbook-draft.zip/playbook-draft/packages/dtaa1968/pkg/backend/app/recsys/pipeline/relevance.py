"""Stage 2b: decide whether the input describes a need at all.

A search such as "test search query", or a plan for a team picnic, still produces a
fluent need profile, and retrieval scores computed from that profile do not tell it apart
from a real need. So, before any candidate is assessed, the run decides whether the
caller's own text describes a need:

* When the vector signal ran and the closest retrieved component is still far from the
  need (the best cosine is below the floor), it does not, and no model call is made.
* When the closest component is clearly close (at or above the clear threshold), it does.
* Otherwise one bounded model call reads the caller's text and answers.

A check that cannot be answered does not fail the run: it is logged, and the run goes on
exactly as it would have without the check. The gate can remove a weak search's result;
it cannot break a run.
"""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from app.recsys.contracts import Candidate, ComponentType
from app.recsys.llm.gateway import GatewayError, LLMGateway
from app.recsys.llm.schemas import RelevanceOut
from app.recsys.prompts.relevance import build_relevance_prompt

logger = logging.getLogger(__name__)

#: The empty reason a run carries when its input described no need.
NO_RELEVANT_NEED = "no_relevant_need"


@dataclass(frozen=True, slots=True)
class RelevanceDecision:
    """Whether the run goes on, and how that was decided.

    :ivar relevant: False only when the input was judged not to describe a need.
    :ivar best_similarity: The best need-to-candidate cosine, when the vector signal ran.
    :ivar model_checked: Whether a model call was made for the decision.
    """

    relevant: bool
    best_similarity: float | None
    model_checked: bool


def best_similarity(
    candidates: Mapping[ComponentType, Sequence[Candidate]],
) -> float | None:
    """Return the highest vector score among the retrieved candidates.

    A score of exactly zero is what retrieval records for a candidate the vector signal
    never scored (it has no embedding), so it is not evidence of distance and is skipped.

    :param candidates: Retrieval output, per type.
    :return: The best cosine, or ``None`` when no retrieved candidate was scored.
    """
    scores = [
        candidate.scores.vector
        for items in candidates.values()
        for candidate in items
        if candidate.scores.vector != 0.0
    ]
    return max(scores) if scores else None


async def judge_relevance(
    text: str,
    candidates: Mapping[ComponentType, Sequence[Candidate]],
    gateway: LLMGateway,
    *,
    vector_available: bool,
    floor: float,
    clear: float,
    timeout_s: float,
) -> RelevanceDecision:
    """Decide whether the caller's text describes a need components could serve.

    :param text: The caller's own text, never the model-written need summary.
    :param candidates: Retrieval output, per type.
    :param gateway: The run's model gateway; the check is one structured call.
    :param vector_available: Whether the vector signal ran on a real need embedding.
        Without it the scores say nothing about distance, so the model decides.
    :param floor: Below this best cosine the input describes no need.
    :param clear: At or above this best cosine the input describes a need.
    :param timeout_s: Wall-clock budget for the model call.
    :return: The decision.
    """
    best = best_similarity(candidates) if vector_available else None
    if best is not None and best < floor:
        return RelevanceDecision(relevant=False, best_similarity=best, model_checked=False)
    if best is not None and best >= clear:
        return RelevanceDecision(relevant=True, best_similarity=best, model_checked=False)
    system, user = build_relevance_prompt(text)
    try:
        answer = await gateway.structured(
            system=system, user=user, schema=RelevanceOut, timeout_s=timeout_s
        )
    except GatewayError as error:
        logger.warning(
            "Recsys relevance check unanswered; the run continues",
            extra={"stage": "relevance", "error_code": error.code},
        )
        return RelevanceDecision(relevant=True, best_similarity=best, model_checked=True)
    return RelevanceDecision(
        relevant=answer.describes_need, best_similarity=best, model_checked=True
    )
