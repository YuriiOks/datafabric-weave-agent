# Agent relation evidence

How the catalogue turns declared agent dependencies into relations, what each
relation carries as evidence, where an unresolved declaration goes, and when a relation
may leave the graph.

## What a relation is

A relation is one `(source component, link type, target component)` fact that the
deterministic catalogue accepted. The link types form a closed set:

| Link type | Declared by |
|---|---|
| `USES_SKILL` | Agent Usage sheet, Skill ID column |
| `USES_MCP` | Agent Usage sheet, MCP ID column |
| `USES_KNOWLEDGE` | Agent Usage sheet, Knowledgebase ID column |
| `DEPENDS_ON_SKILL` | Skill front matter, `metadata.dependencies.skills` |
| `ALLOWS_MCP` | Skill front matter, `metadata.allowed_mcp` |

Nothing else is a relation. A recommendation, an execution, an approval or a native
Hub agent binding is never published as an edge: none of them is a link type, and the
evidence table and the ledger's `link_type` column refuse any other value.

## Stable key

Every published link carries `relation_key`:

```
sha256(json(["bpc-relation-v1", source component UUID, link type, target component UUID]))
```

The component UUIDs already fold in the publication scope, so the key needs nothing
else. It does not depend on the catalogue id, the capture time, the reference
occurrence ids or the row a declaration sits on. Rebuilding the same sources keeps
every key, and so does moving a declaration to another row. A different derivation
gets a new namespace; existing keys are never redefined.

## Evidence

Each relation keeps one evidence entry per supporting declaration, in
`recsys_relation_evidence` (one row per entry, numbered within its relation):

| Field | Meaning |
|---|---|
| `authority`, `collection` | Which source and which part of it declared the relation |
| `structural_locator` | Where the declaration sits, structure only (sheet and row, or the skill's document) |
| `field_name`, `token_ordinal` | The column or front-matter field, and the token's position in it |
| `raw_value`, `raw_value_redacted`, `raw_value_digest` | The original token, shown as a digest when it looks like a path, a credential, an address or a staff number |
| `resolution_outcome`, `matched_index` | How the token was resolved and which index matched it |
| `rule_id`, `rule_version` | The identifier rule, reviewed mapping or owner rule that bound it |

A declaration repeated in the same cell, in another row or in another source adds an
entry to the existing relation. It never adds a second edge.

`evidence_digest` on the link covers every entry in canonical order. It changes
exactly when the evidence changes: a new or removed declaration, a moved row, or a
different rule or rule version. A rebuild with identical evidence keeps the digest.

## Unresolved declarations

A declaration that does not resolve to exactly one accepted component produces no
edge. It stays in the review ledger. Each reference entry now also names:

- `resolution_outcome`: `missing`, `ambiguous`, `invalid` or `out_of_scope`, as the
  resolver emitted it;
- `owner_component_id`: the component that made the declaration, or nothing when that
  record itself has no accepted identity;
- `link_type`: the relation the declaration would have produced;
- `members`: for an ambiguous reference, every candidate it could have meant.

An unknown Skill, a Skill named in the MCP column, and an MCP whose source key is
shared by several registrations all end up here.

## Counts

`app.recsys.registry.relations.counts.count_relations` accounts for every declared
occurrence, per link type:

- `declared_occurrences` = `accepted_occurrences` + `unresolved_occurrences`;
- `accepted_occurrences` = `published_evidence`, since every accepted occurrence is
  evidence on some relation;
- `folded_duplicates` = `published_evidence` - `relations`.

Occurrences and relations are different units and are never added together. The
counts are computed, not persisted.

## Retirement

The active graph never mixes two relation sets. A build is written as a new catalogue
version with its own links and evidence, and the current pointer moves to it in the
same transaction that writes them.

Whether a relation may disappear is the transition gate's decision
(`app.recsys.registry.transition.gate.evaluate_transition`). When both builds'
relations are passed, a relation absent from the candidate is a declared retirement
only when two kinds of authority each declare `absence_is_deletion` on a complete,
current snapshot:

- every authority whose declaration supported it;
- every authority behind its target component.

Anything else refuses the candidate, and the refusal names the relation keys it would
have retired. An approval lifts the refusal only when it names this exact candidate,
this exact retired component set and this exact retired relation set.

The gate has no production caller yet. Until publication goes through it, the
evidence command below is the only path that evaluates this rule end to end. The
captures in use today declare `absence_is_not_deletion`, so any dropped declaration
would be refused.

## Evidence command

```
python -m app.recsys.relation_evidence \
  --export <export dir or workbook> --skills-repo <checkout> \
  --environment ppd --partition default --out relation-evidence.json \
  [--reference-rules <file>] \
  [--previous-export <dir> --previous-skills-repo <checkout>] \
  [--sample 5] [--include-ids]
```

It builds the catalogue exactly as the ingest does. It opens no database, calls no
gateway and computes no embedding. The report carries the per-link-type counts, the
unresolved references by link type, outcome and reason, and a sample of relations
with their evidence. Given a previous export and checkout, it also carries the
relation diff (added, retired, changed, unchanged) and the gate's verdict. Component
ids, raw tokens and non-sheet locators are digests unless `--include-ids` is passed.

## Schema and reversal

All of this is additive:

- `recsys_component_link` gains nullable `relation_key` and `evidence_digest` columns;
- `recsys_review_ledger_entry` gains nullable `resolution_outcome`,
  `owner_component_id` and `link_type` columns;
- the new table `recsys_relation_evidence` references its link and is removed with it.

The DDL lives in `backend/app/recsys/db/relation_schema.py`. The human-only reversal is
in `docs/recsys/catalogue-reversal.sql`.
