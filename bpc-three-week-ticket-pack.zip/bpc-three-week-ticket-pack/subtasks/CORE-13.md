---
pack_id: "bpc-sep26-v1"
local_id: "CORE-13"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Implement bounded Git and whole-workbook acquisition adapters"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-16"
planned_due: "2026-09-17"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-13"
architecture_sections: ["source-refresh","ingestion","security"]
---

# Implement bounded Git and whole-workbook acquisition adapters

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-13** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-16 → 2026-09-17 (D6–D7)**.
- Recommendation extension: **2026-09-16 → 2026-09-17 (D6–D7)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Replace the reported manual source-update step with registered source acquisition that the durable refresh worker can execute without arbitrary URLs, source code execution or inconsistent workbook copies.

## Scope and interfaces

Implement two acquisition adapters behind CORE-02 contracts and consumed by CORE-05: Skills Git and approved Agent Hub workbook. One immutable copy of the whole workbook supplies all required sheets, including Agent, MCP and portal Skill metadata. Type tickets own parsing/identity/field mappings, not separate workbook downloads. The complete source-set manifest records authority, scope, config version, resolved immutable revision/hash, capture time and completeness/freshness state.

## Implementation sequence

1. Reconcile approved repository/ref and whole-workbook location from CORE-01; use only server-managed read credentials and registered sources.
2. Fetch the registered Git source through isolated configuration and a read-only checkout pinned to the resolved commit. Disable hooks, submodule/LFS fetch and external filter drivers; enforce protocol/host/redirect, object/file/byte and elapsed-time bounds. Reject escaping symlinks through realpath containment. Never execute SKILL.md or fetch embedded URLs.
3. Acquire one immutable complete workbook copy with checksum and capture metadata. Detect mutation during acquisition using the source-supported version/copy contract; refuse a source that cannot satisfy consistency rather than calling a torn copy atomic.
4. Validate required source completeness/freshness and build the version-vector manifest. Failure of a required source blocks candidate publication; no silent mixture of prior stale and newly fetched inputs.
5. Expose stage evidence to CORE-05 without raw secrets or unrestricted filesystem paths, and pass approved immutable inputs to the type parsers.
6. Connect and demonstrate the adapters through the job runner and publisher in CORE-15; CORE-09 qualifies the integrated result, using the actual approved environment.

## Acceptance criteria

- [ ] A job imports an immutable Git commit and one consistent whole-workbook snapshot, with all required source manifests pinned.
- [ ] Unregistered source locations, protocol/host/ref violations, escaping paths and resource-limit failures are rejected before parsing/publication.
- [ ] Git hooks, submodule/LFS actions, filter drivers and source-defined commands never execute.
- [ ] Required-source failure, mutation, incompleteness or excessive age cannot activate a mixed candidate or imply deletion by absence.
- [ ] Type parsers consume the same captured workbook version; source freshness, fetch and activation remain independent states.

## Verification and evidence

Exercise changed branch/ref resolution, malicious path/hook/filter fixtures, partial workbook, file mutation during copy, stale required source, missing credential and mid-fetch cancellation. Attach sanitized acquisition manifests, exact refusal outcomes, bounded-resource evidence and connected refresh trace. Run approved CI/integration checks; fake local success is insufficient.

## Estimate and blocking prerequisites

Six engineering hours assumes approved Git/workbook access and reusable source I/O adapters in the reported PoC; credentials and repository/network approval are external elapsed-time prerequisites. If acquisition or the worker requires a new platform capability, keep the capability blocked and re-estimate. The task starts against the frozen contract; final real-service integration belongs to CORE-15; CORE-09 performs qualification.

## Exclusions

Agent Hub API discovery/build, browser credentials, arbitrary user repository selection, source execution, schedules, new SSO/queue/storage products and type-specific identity heuristics.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `source-refresh`, `ingestion`, `security`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
