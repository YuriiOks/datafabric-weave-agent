"""Code repository reader: the file tree of a repository with a content hash per file.

Every file is one item: ``item_id`` is its path below the root, ``version`` is the first 16
characters of its SHA-256, and the full hash is in the attributes. A changed file is therefore
a new version of the same item, and the old version is history, not a deletion; a file that
disappears from the tree is reported as deleted. Hidden files and folders, symbolic links and
tooling caches are never read.

The ``file_kind`` attribute separates tests from code from schemas, which is what the link
building needs to tell "implemented by" from "verified by".
"""

from __future__ import annotations

from functools import partial
from pathlib import Path, PurePosixPath

from pydantic import JsonValue

from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.sources import attributes as attr
from kp.sources.base import ItemMetadata
from kp.sources.files import media_type_for, read_file, require_directory, sha256_hex, walk_files
from kp.sources.snapshot import ReadItem, ScannedItem, SnapshotReader

VERSION_LENGTH = 16
_SKIPPED_DIRECTORIES = ("__pycache__", "node_modules", "venv", "build", "dist")
_TEST_DIRECTORIES = frozenset({"tests", "test", "__tests__"})
_SCHEMA_DIRECTORIES = frozenset({"schema", "schemas"})
_DOC_SUFFIXES = frozenset({".md", ".rst", ".txt"})
_LANGUAGES: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".js": "javascript",
    ".java": "java",
    ".kt": "kotlin",
    ".go": "go",
    ".rs": "rust",
    ".sql": "sql",
    ".sh": "shell",
}


class CodeRepoReader(SnapshotReader):
    """Read the code and tests of a repository checkout.

    :param root: The checkout folder
    """

    supersedes_older_versions = True

    def __init__(self, root: Path) -> None:
        super().__init__()
        self._root = root

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves.

        :return: The code repository
        """
        return SourceKind.GITHUB

    def _scan(self) -> list[ScannedItem]:
        require_directory(self._root)
        return [
            ScannedItem.of(self._read(path), partial(self._read, path))
            for path in walk_files(self._root, skip_directories=_SKIPPED_DIRECTORIES)
        ]

    def _read(self, path: Path) -> ReadItem:
        relative = PurePosixPath(path.relative_to(self._root).as_posix())
        content = read_file(path)
        content_sha256 = sha256_hex(content)
        signals: dict[str, JsonValue] = {
            attr.CONTENT_SHA256: content_sha256,
            attr.FILE_KIND: _file_kind(relative),
            attr.LANGUAGE: _LANGUAGES.get(relative.suffix.lower()),
            attr.SIZE_BYTES: len(content),
        }
        return ReadItem(
            key=ItemKey(
                source=self.kind, item_id=str(relative), version=content_sha256[:VERSION_LENGTH]
            ),
            # The path signals derive from the path and the version from the content, so the
            # content hash alone says whether anything changed.
            fingerprint=content_sha256,
            title=str(relative),
            modified_at=None,
            content=content,
            metadata=ItemMetadata(
                native_id=str(relative),
                media_type=media_type_for(path),
                title=str(relative),
                attributes=signals,
            ),
        )


def _file_kind(path: PurePosixPath) -> str:
    """Classify a path as ``test``, ``schema``, ``doc``, ``code`` or ``other``."""
    folders = set(path.parts[:-1])
    name = path.name.lower()
    suffix = path.suffix.lower()
    if (
        folders & _TEST_DIRECTORIES
        or name.startswith("test_")
        or name.endswith(("_test.py", ".test.ts", ".spec.ts", ".test.js", ".spec.js"))
    ):
        return "test"
    if name.endswith(".schema.json") or folders & _SCHEMA_DIRECTORIES:
        return "schema"
    if suffix in _DOC_SUFFIXES:
        return "doc"
    if suffix in _LANGUAGES:
        return "code"
    return "other"


__all__ = ["VERSION_LENGTH", "CodeRepoReader"]
