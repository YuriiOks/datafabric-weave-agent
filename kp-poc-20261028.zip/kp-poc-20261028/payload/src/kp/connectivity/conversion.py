"""Format conversion for the local stub extractor.

Deliberately simple: enough to turn the stand-in documents into non-empty Markdown so the
rest of the pipeline can be proven. It is not a quality benchmark for the real service.
"""

from __future__ import annotations

import html
import io
import json
import re
import zipfile
from html.parser import HTMLParser

from openpyxl import load_workbook
from pypdf import PdfReader
from pypdf.errors import PyPdfError

from kp.connectivity.errors import ExtractionError

DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

_PARAGRAPH = re.compile(r"<w:p[ >].*?</w:p>", re.DOTALL)
_TEXT_RUN = re.compile(r"<w:t(?: [^>]*)?>(.*?)</w:t>", re.DOTALL)
_HEADING = re.compile(r'<w:pStyle w:val="Heading(\d)"')
_HEADING_TAGS = {f"h{level}": level for level in range(1, 7)}


def to_markdown(media_type: str, data: bytes) -> tuple[str, int | None]:
    """Convert bytes of a declared media type to Markdown.

    :param media_type: The caller-declared media type
    :param data: The object's bytes
    :return: The Markdown text and the page count when the format has pages
    :raises kp.connectivity.errors.ExtractionError: If the bytes cannot be converted
    """
    try:
        if media_type in {"text/markdown", "text/plain"}:
            return data.decode("utf-8"), None
        if media_type == "text/html":
            return _html(data.decode("utf-8")), None
        if media_type == "application/json":
            return _issue(json.loads(data)), None
        if media_type == DOCX:
            return _docx(data), None
        if media_type == XLSX:
            return _xlsx(data), None
        if media_type == "application/pdf":
            return _pdf(data)
    except (ValueError, KeyError, zipfile.BadZipFile, PyPdfError, OSError) as exc:
        raise ExtractionError(f"Could not convert a {media_type} object") from exc
    raise ExtractionError(f"No stub converter for media type {media_type}")


class _HtmlToMarkdown(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.lines: list[str] = []
        self._text: list[str] = []
        self._heading = 0
        self._bullet = False
        self._rows: list[list[str]] = []
        self._row: list[str] | None = None

    def handle_starttag(
        self,
        tag: str,
        attrs: list[tuple[str, str | None]],  # noqa: ARG002 - HTMLParser hook signature
    ) -> None:
        if tag in _HEADING_TAGS:
            self._flush()
            self._heading = _HEADING_TAGS[tag]
        elif tag in {"p", "br", "ul", "ol"}:
            self._flush()
        elif tag == "li":
            self._flush()
            self._bullet = True
        elif tag == "tr":
            self._row = []
        elif tag in {"td", "th"}:
            self._text = []

    def handle_endtag(self, tag: str) -> None:
        if tag in {"td", "th"} and self._row is not None:
            self._row.append(" ".join("".join(self._text).split()))
            self._text = []
        elif tag == "tr" and self._row is not None:
            self._rows.append(self._row)
            self._row = None
        elif tag == "table":
            self._emit_table()
        elif tag in _HEADING_TAGS or tag in {"p", "li"}:
            self._flush()

    def handle_data(self, data: str) -> None:
        self._text.append(data)

    def finish(self) -> None:
        """Flush text that no closing tag ended."""
        self._flush()

    def _flush(self) -> None:
        text = " ".join("".join(self._text).split())
        self._text = []
        if text:
            if self._heading:
                self.lines.append(f"{'#' * self._heading} {text}")
            elif self._bullet:
                self.lines.append(f"- {text}")
            else:
                self.lines.append(text)
        self._heading = 0
        self._bullet = False

    def _emit_table(self) -> None:
        if not self._rows:
            return
        width = max(len(row) for row in self._rows)
        padded = [row + [""] * (width - len(row)) for row in self._rows]
        table = ["| " + " | ".join(padded[0]) + " |", "|" + " --- |" * width]
        table.extend("| " + " | ".join(row) + " |" for row in padded[1:])
        self.lines.append("\n".join(table))
        self._rows = []


def _html(text: str) -> str:
    parser = _HtmlToMarkdown()
    parser.feed(text)
    parser.close()
    parser.finish()
    return "\n\n".join(parser.lines) + "\n" if parser.lines else ""


def _issue(issue: dict[str, object]) -> str:
    lines = [f"# {issue['key']}: {issue['summary']}", "", f"Status: {issue['status']}"]
    description = issue.get("description")
    if isinstance(description, str) and description:
        lines += ["", description]
    labels = issue.get("labels")
    if isinstance(labels, list) and labels:
        lines += ["", "Labels: " + ", ".join(str(label) for label in labels)]
    links = issue.get("issuelinks")
    if isinstance(links, list) and links:
        lines += ["", "## Links", ""]
        lines += [f"- {json.dumps(link, sort_keys=True)}" for link in links]
    comments = issue.get("comments")
    if isinstance(comments, list) and comments:
        lines += ["", "## Comments", ""]
        lines += [f"- {comment}" for comment in comments]
    return "\n".join(lines) + "\n"


def _docx(data: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        document = archive.read("word/document.xml").decode("utf-8")
    lines: list[str] = []
    for paragraph in _PARAGRAPH.findall(document):
        text = html.unescape("".join(_TEXT_RUN.findall(paragraph)))
        if not text.strip():
            continue
        heading = _HEADING.search(paragraph)
        lines.append(f"{'#' * int(heading.group(1))} {text}" if heading else text)
    return "\n\n".join(lines) + "\n" if lines else ""


def _xlsx(data: bytes) -> str:
    workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    lines: list[str] = []
    for sheet in workbook.worksheets:
        rows = [
            ["" if cell is None else str(cell) for cell in row]
            for row in sheet.iter_rows(values_only=True)
        ]
        rows = [row for row in rows if any(row)]
        if not rows:
            continue
        lines += [f"## {sheet.title}", "", "| " + " | ".join(rows[0]) + " |"]
        lines.append("|" + " --- |" * len(rows[0]))
        lines += ["| " + " | ".join(row) + " |" for row in rows[1:]]
        lines.append("")
    return "\n".join(lines)


def _pdf(data: bytes) -> tuple[str, int]:
    reader = PdfReader(io.BytesIO(data))
    pages = [(page.extract_text() or "").strip() for page in reader.pages]
    text = "\n\n".join(page for page in pages if page)
    return (text + "\n" if text else ""), len(pages)
