"""The relational schema: tables, integrity rules and agreement with the domain models."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta, timezone

import pytest
from sqlalchemy import Engine, insert, inspect, select
from sqlalchemy.exc import IntegrityError, StatementError

from kp.config import Settings
from kp.domain import (
    DETAIL_NAMES,
    ChangeEvent,
    Citation,
    Clause,
    DomainModel,
    Edition,
    KnowledgeVersion,
    Link,
    McpCallRecord,
    Passage,
    Requirement,
    ReviewItem,
    Run,
    RunKind,
    RunOutcome,
    SourceItemVersion,
    Spec,
    SpecCorrection,
    Story,
    SweepCursor,
    Template,
    ToolCallRecord,
)
from kp.store import Database, create_engine_from_settings, metadata
from kp.store.schema import run, spec

EXPECTED_TABLES = {
    "source_item",
    "mcp_call",
    "run",
    "sweep_cursor",
    "edition",
    "clause",
    "requirement",
    "story",
    "passage",
    "link",
    "change_event",
    "knowledge_version",
    "review_item",
    "tool_call",
    "citation",
    "template",
    "spec",
    "session_retrieval",
    "spec_correction",
}

# Domain model -> (table, fields stored under other names, columns that exist only in the table).
_MAPPING: dict[type[DomainModel], tuple[str, dict[str, tuple[str, ...]], set[str]]] = {
    SourceItemVersion: ("source_item", {"details": DETAIL_NAMES}, set()),
    Run: ("run", {}, set()),
    SweepCursor: ("sweep_cursor", {}, set()),
    McpCallRecord: ("mcp_call", {}, set()),
    ChangeEvent: ("change_event", {}, set()),
    Edition: ("edition", {}, set()),
    Clause: ("clause", {"ref": ("edition", "number"), "parent_ref": ("parent_number",)}, set()),
    Requirement: ("requirement", {}, set()),
    Story: ("story", {}, {"fingerprint"}),
    Passage: ("passage", {}, set()),
    Link: (
        "link",
        {
            "source_ref": ("source_item_type", "source_key"),
            "target_ref": ("target_item_type", "target_key"),
        },
        set(),
    ),
    KnowledgeVersion: ("knowledge_version", {}, set()),
    ReviewItem: ("review_item", {}, set()),
    ToolCallRecord: ("tool_call", {}, set()),
    Citation: ("citation", {}, set()),
    Template: ("template", {}, set()),
    Spec: ("spec", {}, set()),
    SpecCorrection: ("spec_correction", {}, set()),
}


def test_create_all_creates_every_table(engine: Engine) -> None:
    assert set(inspect(engine).get_table_names()) == EXPECTED_TABLES
    assert set(metadata.tables) == EXPECTED_TABLES


def test_create_all_is_idempotent(database: Database) -> None:
    database.create_all()

    assert set(inspect(database.engine).get_table_names()) == EXPECTED_TABLES


@pytest.mark.parametrize("model", list(_MAPPING), ids=lambda m: m.__name__)
def test_columns_match_domain_fields(model: type[DomainModel]) -> None:
    table_name, renamed, table_only = _MAPPING[model]
    expected = {name for name in model.model_fields if name not in renamed}
    expected |= {column for columns in renamed.values() for column in columns}
    expected |= table_only

    assert {column.name for column in metadata.tables[table_name].columns} == expected


def test_settings_build_an_engine(local_settings: Settings) -> None:
    engine = create_engine_from_settings(local_settings)

    assert engine.dialect.name == "sqlite"
    engine.dispose()


def _run_row(run_id: str = "r1", **overrides: object) -> dict[str, object]:
    row: dict[str, object] = {
        "run_id": run_id,
        "kind": RunKind.SWEEP.value,
        "sources": ["jira"],
        "started_at": datetime(2026, 11, 1, 9, 0, tzinfo=UTC),
        "outcome": RunOutcome.RUNNING.value,
        "items_touched": 0,
    }
    return row | overrides


def test_datetimes_round_trip_as_utc_aware(database: Database) -> None:
    offset = timezone(timedelta(hours=2))
    started = datetime(2026, 11, 1, 11, 0, tzinfo=offset)

    with database.transaction() as connection:
        connection.execute(insert(run).values(_run_row(started_at=started)))
    with database.transaction() as connection:
        stored = connection.execute(select(run.c.started_at)).scalar_one()

    assert stored == started
    assert stored.utcoffset() == timedelta(0)
    assert Run.model_validate({**_run_row(), "started_at": stored}).started_at == started


def test_naive_datetimes_are_rejected(database: Database) -> None:
    with (
        pytest.raises(StatementError, match="timezone-aware"),
        database.transaction() as connection,
    ):
        connection.execute(insert(run).values(_run_row(started_at=datetime(2026, 11, 1))))


def test_enum_columns_reject_unknown_values(database: Database) -> None:
    with pytest.raises(IntegrityError), database.transaction() as connection:
        connection.execute(insert(run).values(_run_row(outcome="exploded")))


def test_foreign_keys_are_enforced(database: Database) -> None:
    template_row = {
        "spec_id": "s1",
        "story_key": "PAY-1",
        "path": "specs/s1.md",
        "template_id": "missing",
        "template_version": "1",
        "branch": "spec/pay-1",
        "state": "drafted",
        "coverage": {},
        "open_items": [],
        "content_sha256": "0" * 64,
        "created_at": datetime(2026, 11, 1, tzinfo=UTC),
    }

    with pytest.raises(IntegrityError), database.transaction() as connection:
        connection.execute(insert(spec).values(template_row))


def test_transaction_rolls_back_on_error(database: Database) -> None:
    def fail_after_insert() -> None:
        with database.transaction() as connection:
            connection.execute(insert(run).values(_run_row()))
            raise RuntimeError("boom")

    with pytest.raises(RuntimeError):
        fail_after_insert()

    with database.transaction() as connection:
        assert connection.execute(select(run.c.run_id)).all() == []


def test_primary_keys_prevent_duplicate_rows(database: Database) -> None:
    with database.transaction() as connection:
        connection.execute(insert(run).values(_run_row()))

    with pytest.raises(IntegrityError), database.transaction() as connection:
        connection.execute(insert(run).values(_run_row()))
