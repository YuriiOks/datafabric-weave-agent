"""Errors specific to the source readers. All derive from the shared source errors."""

from __future__ import annotations

from kp.errors import SourceError


class MalformedSourceDataError(SourceError):
    """A source file or record does not have the agreed shape.

    Raised instead of skipping the item: a document that cannot be read must be visible to
    the operator, never silently missing from the knowledge base.
    """


class InvalidReadRequestError(SourceError, ValueError):
    """The caller passed an argument the reader cannot honour, such as a page size below one."""


class InvalidCursorError(InvalidReadRequestError):
    """A cursor was not issued by this reader, or has been altered."""
