"""Render the acceptance matrix as Markdown for the release evidence."""

from __future__ import annotations

from app.recsys.qualification.matrix import (
    AcceptanceMatrix,
    AcceptanceMode,
    completion_blockers,
    status_counts,
)

NO_PASS_STATEMENT = (
    "No requirement is marked passed: a pass is a recorded CI or rehearsal run, kept with "
    "the release evidence."
)


def _cell(text: str | None) -> str:
    """Make text safe for one Markdown table cell.

    :param text: The text, or nothing.
    :return: The text with pipes escaped and newlines flattened, or ``-``.
    """
    if not text:
        return "-"
    return text.replace("|", "\\|").replace("\n", " ")


def render_matrix(
    matrix: AcceptanceMatrix, mode: AcceptanceMode = AcceptanceMode.graph
) -> str:
    """Render the rows of one delivery, the blockers and the completion state.

    :param matrix: The matrix.
    :param mode: The delivery; recommendation mode also shows the graph rows.
    :return: The Markdown, ending with the explicit no-pass statement.
    """
    selected = {AcceptanceMode.graph, mode}
    rows = [row for row in matrix.rows if row.mode in selected]
    lines = [
        f"# Acceptance matrix: {mode.value} delivery",
        "",
        "| Status | Rows |",
        "|---|---|",
    ]
    counts = status_counts(matrix, mode)
    lines.extend(f"| {status.value} | {count} |" for status, count in counts.items())
    lines.extend(
        [
            "",
            "| Requirement | Title | Owner | Evidence | Status | Blocked by |",
            "|---|---|---|---|---|---|",
        ]
    )
    for row in rows:
        evidence = row.evidence_kind.value
        if row.evidence_reference:
            evidence = f"{evidence}: `{row.evidence_reference}`"
        lines.append(
            f"| {row.requirement_id} | {_cell(row.title)} | {row.owner_role.value} "
            f"| {_cell(evidence)} | {row.status.value} | {_cell(', '.join(row.blocked_by))} |"
        )
    lines.extend(
        [
            "",
            "| Blocker | Why | Stops | Decision needed | Owner |",
            "|---|---|---|---|---|",
        ]
    )
    for blocker in matrix.blockers:
        stops = ", ".join(matrix.blocked_rows(blocker.blocker_id))
        lines.append(
            f"| {blocker.blocker_id} | {_cell(blocker.summary)} | {_cell(stops)} "
            f"| {_cell(blocker.decision)} | {blocker.owner_role.value} |"
        )
    gaps = [row for row in rows if row.gap]
    if gaps:
        lines.extend(["", "Gaps in the cited evidence:"])
        lines.extend(f"- {row.requirement_id}: {row.gap}" for row in gaps)
    reasons = completion_blockers(matrix, mode)
    lines.extend(["", f"Parent completion is blocked by {len(reasons)} requirements.", ""])
    lines.append(NO_PASS_STATEMENT)
    return "\n".join(lines) + "\n"
