"""Ports: what the read tools need from other lanes, and the write side needs from its lane.

Each port is a small ``typing.Protocol`` with plain value types defined here. The integrator
adapts the real search, link, coverage, rule and template implementations to these ports;
tests use the in-memory fakes in :mod:`kp.tools.testing`.

Every port that returns items receives the caller's allowed domains and must apply them
before ranking. The tools filter again on the way out (defence in depth) and add whatever
the port reports as ``filtered_out`` to the count shown to the agent.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date
from typing import Annotated, Protocol

from pydantic import Field, JsonValue

from kp.domain import (
    Clause,
    DomainModel,
    Edition,
    ItemRef,
    LinkKind,
    LinkState,
    PassageType,
    Relation,
    Template,
)

# Review-list and dropped guesses are not used anywhere; agents never see them.
SHOWN_LINK_STATES = frozenset({LinkState.STATED, LinkState.PROPOSED})


class SearchHit(DomainModel):
    """One passage matching a query.

    :ivar reference: The parent reference of the passage (a clause reference text for clauses).
    :ivar version: The edition label or source version the passage belongs to.
    """

    passage_id: str
    passage_type: PassageType
    reference: str
    text: str
    page: Annotated[int, Field(ge=1)] | None = None
    char_start: Annotated[int, Field(ge=0)] | None = None
    char_end: Annotated[int, Field(ge=0)] | None = None
    version: str
    domain: str | None = None
    score: float | None = None


class SearchResponse(DomainModel):
    """Ranked hits plus how many matches the domain filter hid."""

    hits: tuple[SearchHit, ...] = ()
    filtered_out: Annotated[int, Field(ge=0)] = 0


class SearchPort(Protocol):
    """Keyword (and optional vector) search over passages."""

    def search(
        self, query: str, *, domains: frozenset[str], as_at: date, limit: int
    ) -> SearchResponse:
        """Search passages.

        :param query: The question or keywords
        :param domains: Domains the caller may read; applied before ranking
        :param as_at: Only versions in force on this date; withdrawn items never appear
        :param limit: Maximum number of hits
        :return: Ranked hits, best first, and the number of matches hidden by ``domains``
        """
        ...


class LinkCounts(DomainModel):
    """How many stated and guessed links an item has."""

    stated: Annotated[int, Field(ge=0)] = 0
    guessed: Annotated[int, Field(ge=0)] = 0


class LinkedItem(DomainModel):
    """One item reached by following links.

    :ivar steps: Distance from the start item, 1 to 3.
    :ivar relation: The relation of the edge that reached this item.
    :ivar outgoing: True when the edge points from ``via`` to ``item``, False when reversed.
    :ivar via: The item the edge started from.
    """

    item: ItemRef
    domain: str | None = None
    steps: Annotated[int, Field(ge=1, le=3)]
    relation: Relation
    outgoing: bool
    via: ItemRef
    kind: LinkKind
    state: LinkState
    score: Annotated[float, Field(ge=0, le=1)] | None = None
    evidence: str = ""


class LinkTraversal(DomainModel):
    """The result of following links from one item.

    :ivar root_domain: The domain of the start item; ``None`` when unlabelled or unknown.
    :ivar filtered_out: Linked items hidden by the domain filter.
    """

    root_domain: str | None = None
    items: tuple[LinkedItem, ...] = ()
    filtered_out: Annotated[int, Field(ge=0)] = 0


class LinkPort(Protocol):
    """Read access to the link store."""

    def traverse(self, root: ItemRef, *, steps: int, domains: frozenset[str]) -> LinkTraversal:
        """Follow links in either direction up to ``steps`` edges away.

        :param root: The start item
        :param steps: Maximum distance, 1 to 3
        :param domains: Domains the caller may read
        :return: Linked items with their stated or guessed marking
        :raises kp.tools.errors.LinkStoreUnavailableError: If the link store is down
        """
        ...

    def link_counts(
        self, items: Sequence[ItemRef], *, domains: frozenset[str]
    ) -> Mapping[ItemRef, LinkCounts]:
        """Count the links of items that an agent may follow.

        Only open links in the state stated or proposed are counted (never review-list or
        dropped guesses), and only when the item at the other end lies in ``domains``. These
        are the links the ``links`` tool would show one step away.

        :param items: The items to count for
        :param domains: Domains the caller may read
        :return: Counts per item; a missing item has no such links
        :raises kp.tools.errors.LinkStoreUnavailableError: If the link store is down
        """
        ...


class RuleClause(DomainModel):
    """A clause together with the domain of the document it belongs to."""

    clause: Clause
    domain: str | None = None


class RulePort(Protocol):
    """Read access to rulebook editions and their clauses."""

    def editions(self) -> Sequence[Edition]:
        """List every edition known, whatever its state.

        :return: The editions, in any order
        """
        ...

    def clause(self, edition: str, number: str) -> RuleClause | None:
        """Fetch one clause of one edition.

        :param edition: Edition label
        :param number: Dotted clause number
        :return: The clause, or ``None`` when that edition has no such clause
        """
        ...

    def edition_domain(self, edition: str) -> str | None:
        """Tell which access domain an edition's document belongs to.

        Every clause of an edition has this domain, so it says who may learn anything about the
        edition's clauses, including that one does not exist.

        :param edition: Edition label
        :return: The domain, or ``None`` when the edition is unlabelled or unknown
        """
        ...


class TemplatePort(Protocol):
    """Read access to governed templates."""

    def get(self, spec_type: str, version: str | None = None) -> Template | None:
        """Fetch a governed template.

        :param spec_type: The kind of spec the template is for
        :param version: A specific version, or ``None`` for the latest
        :return: The template, or ``None`` when none is governed (there is no fallback)
        """
        ...


class RuleCoverage(DomainModel):
    """Whether one rule has a path to a test, and the links that say so."""

    reference: str
    domain: str | None = None
    has_test: bool
    linked_stories: Annotated[int, Field(ge=0)] = 0
    stated_links: Annotated[int, Field(ge=0)] = 0
    guessed_links: Annotated[int, Field(ge=0)] = 0


class StoryGap(DomainModel):
    """A story that has no requirement or clause behind it."""

    story_key: str
    summary: str = ""
    domain: str | None = None


class CoverageSnapshot(DomainModel):
    """Coverage of the rules in force, and stories without a requirement or clause."""

    rules: tuple[RuleCoverage, ...] = ()
    story_gaps: tuple[StoryGap, ...] = ()
    filtered_out: Annotated[int, Field(ge=0)] = 0


class CoveragePort(Protocol):
    """Read access to coverage queries."""

    def snapshot(self, *, domains: frozenset[str], as_at: date) -> CoverageSnapshot:
        """Compute coverage for the rules in force on ``as_at``.

        :param domains: Domains the caller may read
        :param as_at: The date the rules are read at
        :return: Per-rule coverage, story gaps and the number of items hidden by ``domains``
        :raises kp.tools.errors.LinkStoreUnavailableError: If the link store is down
        """
        ...


@dataclass(frozen=True, slots=True)
class ReadPorts:
    """The five ports the read server needs, bundled for wiring."""

    search: SearchPort
    links: LinkPort
    rules: RulePort
    templates: TemplatePort
    coverage: CoveragePort


class WriteToolDescriptor(DomainModel):
    """Name, description and JSON input schema of one write tool provided by another lane."""

    name: str
    description: str
    input_schema: dict[str, JsonValue]


class WriteToolCall(DomainModel):
    """One write call as handed to the write port. Identity and domains come from the server.

    :ivar domains: The domains the caller may read; the write lane decides what they allow.
    """

    tool: str
    arguments: dict[str, JsonValue]
    caller: str
    agent: str
    session_id: str
    domains: tuple[str, ...]


class WriteToolResult(DomainModel):
    """What a write tool reports back.

    :ivar spec_id: The spec the call acted on, so the audit trail can be listed from it.
    """

    payload: dict[str, JsonValue]
    items_returned: Annotated[int, Field(ge=0)] = 0
    spec_id: str | None = None


class WriteToolPort(Protocol):
    """The write tools (publish spec, update Jira), provided by the write lane."""

    def describe(self) -> Sequence[WriteToolDescriptor]:
        """List the write tools this port serves.

        :return: One descriptor per tool
        """
        ...

    def invoke(self, call: WriteToolCall) -> WriteToolResult:
        """Run one write tool.

        :param call: The call, with identity taken from the transport
        :return: The result to show the agent
        :raises ValueError: If the arguments are malformed
        :raises kp.errors.WriteNotPermittedError: If the target is outside the server-side
            allow-list; the refusal is recorded
        """
        ...
