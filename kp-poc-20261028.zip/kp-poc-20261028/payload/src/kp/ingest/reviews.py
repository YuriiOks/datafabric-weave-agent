"""Builders for the review items the parsers ask for.

Review ids are derived from the item version (and sheet), so building the same question
twice gives the same id and a re-run adds nothing. Missing details and unknown document types
are the approval gate's to raise (``kp.sweep``), not this package's.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from kp.config import Thresholds
from kp.domain import ItemKey, ReviewItem, ReviewKind
from kp.ingest.models import ParsedRulebook, SheetReport

_MAX_ANOMALIES_SHOWN = 5


@dataclass(frozen=True)
class ReviewContext:
    """What every review item of one processing call shares.

    :ivar key: The item version the questions are about.
    :ivar run_id: The run that processed it.
    :ivar created_at: When the items are created.
    """

    key: ItemKey
    run_id: str
    created_at: datetime


def structure_review_id(key: ItemKey) -> str:
    """Give the id of the structure review item for a rulebook version.

    :param key: The rulebook version
    :return: The id :func:`structure_review` uses, so a later call can look the item up
    """
    return f"{ReviewKind.LOW_STRUCTURE_SCORE.value}:{key}"


def register_header_review(
    sheet: SheetReport, thresholds: Thresholds, context: ReviewContext
) -> ReviewItem:
    """Build the review item for a refused register sheet.

    :param sheet: A refused sheet report
    :param thresholds: Supplies the confidence threshold quoted in the text
    :param context: Register identity, run and time
    :return: An item whose candidates are the best header row numbers
    """
    return ReviewItem(
        review_id=f"{ReviewKind.REGISTER_HEADER.value}:{context.key}:{sheet.sheet}",
        kind=ReviewKind.REGISTER_HEADER,
        source=context.key.source,
        item_id=context.key.item_id,
        version=context.key.version,
        detail=(
            f"Sheet {sheet.sheet!r}: header row confidence {sheet.header_confidence:.2f} is "
            f"below {thresholds.register_header_min_confidence:.2f}; sheet refused"
        ),
        candidates=tuple(str(row) for row in sheet.candidate_rows),
        run_id=context.run_id,
        created_at=context.created_at,
    )


def structure_review(parsed: ParsedRulebook, context: ReviewContext) -> ReviewItem:
    """Build the review item for a rulebook whose structure is doubtful.

    :param parsed: The parse result
    :param context: Rulebook identity, run and time
    :return: An item stating the score, the decision and the first findings
    """
    findings = "; ".join(parsed.anomalies[:_MAX_ANOMALIES_SHOWN])
    return ReviewItem(
        review_id=structure_review_id(context.key),
        kind=ReviewKind.LOW_STRUCTURE_SCORE,
        source=context.key.source,
        item_id=context.key.item_id,
        version=context.key.version,
        detail=(
            f"Edition {parsed.edition}: structure score {parsed.structure_score:.2f} "
            f"({parsed.decision.value}), {len(parsed.clauses)} clauses"
            + (f". {findings}" if findings else "")
        ),
        run_id=context.run_id,
        created_at=context.created_at,
    )
