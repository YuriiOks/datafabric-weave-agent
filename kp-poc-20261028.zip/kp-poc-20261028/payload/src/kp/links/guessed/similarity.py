"""The local similarity implementation: cosine overlap of term counts."""

from __future__ import annotations

import math
from collections import Counter
from collections.abc import Sequence

from kp.links.guessed.terms import term_counts


def _cosine(left: Counter[str], right: Counter[str]) -> float:
    if not left or not right:
        return 0.0
    dot = sum(count * right[term] for term, count in left.items())
    norm = math.sqrt(sum(c * c for c in left.values())) * math.sqrt(
        sum(c * c for c in right.values())
    )
    return dot / norm if norm else 0.0


class TermOverlapSimilarity:
    """Search agreement from term overlap, with no index and no network.

    The score is the cosine of the two texts' term-count vectors, so it already lies in
    0-1 and :attr:`max_score` is 1.
    """

    @property
    def max_score(self) -> float:
        """The cosine of identical texts."""
        return 1.0

    def agreement(self, query: str, candidates: Sequence[str]) -> list[float]:
        """Score candidate texts against a query text.

        :param query: The text of the item the link starts at
        :param candidates: The texts of the items it might link to
        :return: One cosine per candidate, in order
        """
        query_terms = term_counts(query)
        return [_cosine(query_terms, term_counts(candidate)) for candidate in candidates]
