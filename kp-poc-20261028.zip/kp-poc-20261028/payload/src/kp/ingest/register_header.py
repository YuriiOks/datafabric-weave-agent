"""Header-row detection for a register sheet, with a confidence score.

A candidate row is scored as ``fill * (0.35 label + 0.15 distinct + 0.30 data_below +
0.20 vocabulary)`` where, for the non-blank cells of the row:

* ``fill`` is how many of the sheet's columns the row fills (a title above the table fills
  one column, a header fills them all), measured against the widest row in the scan window;
* ``label`` is the share of cells that read like a column label: short, at most four words,
  no closing sentence punctuation, mostly letters;
* ``distinct`` is 1 when no two cells repeat (0.5 for a single cell, 0 for repeats);
* ``data_below`` is the share of the next five rows that are at least half as full;
* ``vocabulary`` is the share of cells containing a common register column word.

The confidence is the best row's score, reduced when a second row scores almost as high
(``x min(1, 0.5 + 3 * gap)``, so a tie halves it): an ambiguous sheet is refused, not guessed.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

_SCAN_ROWS = 50
_BELOW_ROWS = 5
_MAX_LABEL_CHARS = 40
_MAX_LABEL_WORDS = 4
_MAX_DIGIT_SHARE = 0.3
_CANDIDATES = 3
_WORDS = re.compile(r"[a-z]+")
_VOCABULARY = frozenset(
    {
        "id",
        "key",
        "ref",
        "reference",
        "title",
        "name",
        "description",
        "summary",
        "domain",
        "priority",
        "owner",
        "status",
        "type",
        "category",
        "requirement",
        "requirements",
        "rule",
        "source",
        "comment",
        "comments",
        "date",
    }
)


@dataclass(frozen=True)
class HeaderGuess:
    """The best header row of a sheet.

    :ivar row: One-based row number of the best row; ``None`` when the sheet is empty.
    :ivar confidence: Confidence in that row, 0 to 1.
    :ivar candidates: Up to three best-scoring row numbers, best first.
    """

    row: int | None
    confidence: float
    candidates: tuple[int, ...]


def detect_header(rows: Sequence[Sequence[str]]) -> HeaderGuess:
    """Find the header row of a sheet.

    :param rows: The sheet's rows from row 1, each cell as stripped text (``""`` if empty)
    :return: The best row, its confidence and the best candidates
    """
    window = rows[:_SCAN_ROWS]
    width = max((_filled(row) for row in window), default=0)
    if width == 0:
        return HeaderGuess(None, 0.0, ())
    scored = sorted(
        ((_score(rows, index, width), index + 1) for index in range(len(window))),
        key=lambda pair: (-pair[0], pair[1]),
    )
    best, row = scored[0]
    gap = best - scored[1][0] if len(scored) > 1 else best
    confidence = best * min(1.0, 0.5 + 3 * gap)
    candidates = tuple(number for score, number in scored[:_CANDIDATES] if score > 0)
    return HeaderGuess(row, round(confidence, 4), candidates)


def _filled(row: Sequence[str]) -> int:
    return sum(1 for cell in row if cell)


def _score(rows: Sequence[Sequence[str]], index: int, width: int) -> float:
    cells = [cell for cell in rows[index] if cell]
    if not cells:
        return 0.0
    fill = len(cells) / width
    label = sum(_looks_like_label(cell) for cell in cells) / len(cells)
    distinct = _distinctness(cells)
    vocabulary = sum(_has_vocabulary(cell) for cell in cells) / len(cells)
    below = rows[index + 1 : index + 1 + _BELOW_ROWS]
    data = sum(_filled(row) >= max(1, len(cells) / 2) for row in below) / len(below) if below else 0
    return fill * (0.35 * label + 0.15 * distinct + 0.30 * data + 0.20 * vocabulary)


def _distinctness(cells: Sequence[str]) -> float:
    if len(cells) == 1:
        return 0.5
    return 1.0 if len({cell.casefold() for cell in cells}) == len(cells) else 0.0


def _looks_like_label(cell: str) -> bool:
    if len(cell) > _MAX_LABEL_CHARS or len(cell.split()) > _MAX_LABEL_WORDS:
        return False
    if cell.endswith((".", "!", "?")):
        return False
    return sum(char.isdigit() for char in cell) / len(cell) <= _MAX_DIGIT_SHARE


def _has_vocabulary(cell: str) -> bool:
    return any(word in _VOCABULARY for word in _WORDS.findall(cell.casefold()))
