"""Test support: the wired local stack and its constants."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import httpx
from pydantic import SecretStr

from kp.clock import FixedClock
from kp.connectivity import (
    CallSink,
    ClientCredentialsTokenProvider,
    ConfluenceAdapter,
    ConnectivityRunner,
    ExtractionClient,
    FakeGateway,
    GatewayClient,
    GitHubAdapter,
    JiraAdapter,
    LocalObjectStore,
    RunCallRecorder,
    SignatureStore,
    StubExtractionService,
    default_sample_items_path,
    load_sample_items,
)
from kp.connectivity.fake_gateway import (
    FAKE_BASE_URL,
    FAKE_CLIENT_ID,
    FAKE_CLIENT_SECRET,
    FAKE_EXTRACTION_URL,
    FAKE_TOKEN_URL,
)
from kp.connectivity.models import Route, SampleSet
from kp.connectivity.ports import ExtractionPort
from kp.connectivity.tokens import FixedTokenProvider
from kp.domain import SourceKind
from kp.store import Database

IDENTITY_HEADER = "x-test-identity"
SOURCE_HEADER = "x-test-source"
USE_CASE = "use-case-needle-0042"
SOURCE_SECRET = "source-secret-needle"  # noqa: S105 - test value
REFRESH_FRACTION = 0.8


@dataclass
class Stack:
    """Everything a test needs to drive the job and look at what it left."""

    clock: FixedClock
    fake: FakeGateway
    database: Database
    raw: LocalObjectStore
    markdown: LocalObjectStore
    stub: StubExtractionService
    tokens: ClientCredentialsTokenProvider
    client: GatewayClient
    recorder: RunCallRecorder
    samples: SampleSet
    routes: dict[SourceKind, Route]
    signatures: SignatureStore
    ledger_dir: Path
    sleeps: list[float]
    http: httpx.Client

    def client_for(self, sink: CallSink | None = None) -> GatewayClient:
        """Build a gateway client on this stack's transport that writes observations to ``sink``."""
        return GatewayClient(
            http=self.http,
            base_url=FAKE_BASE_URL,
            tokens=self.tokens,
            identity_header=IDENTITY_HEADER,
            source_header=SOURCE_HEADER,
            source_credentials={kind: SecretStr(SOURCE_SECRET) for kind in self.routes},
            clock=self.clock,
            sink=sink,
            sleep=self.sleeps.append,
        )

    def runner(self, extractor: ExtractionPort | None = None) -> ConnectivityRunner:
        """Build a job; by default it extracts through the real client and the stub service."""
        if extractor is None:
            extractor = ExtractionClient(
                http=httpx.Client(transport=self.stub.transport()), endpoint=FAKE_EXTRACTION_URL
            )
        adapters = {
            SourceKind.CONFLUENCE: ConfluenceAdapter(
                self.client,
                self.routes[SourceKind.CONFLUENCE],
                self.samples.for_source(SourceKind.CONFLUENCE),
            ),
            SourceKind.JIRA: JiraAdapter(
                self.client,
                self.routes[SourceKind.JIRA],
                self.samples.for_source(SourceKind.JIRA),
            ),
            SourceKind.GITHUB: GitHubAdapter(
                self.client,
                self.routes[SourceKind.GITHUB],
                self.samples.for_source(SourceKind.GITHUB),
            ),
        }
        probe = GatewayClient(
            http=self.http,
            base_url=FAKE_BASE_URL,
            tokens=FixedTokenProvider(SecretStr("not-a-valid-credential"), self.clock),
            identity_header=IDENTITY_HEADER,
            source_header=SOURCE_HEADER,
            source_credentials={kind: SecretStr(SOURCE_SECRET) for kind in self.routes},
            clock=self.clock,
            sink=self.recorder,
            sleep=self.sleeps.append,
        )
        return ConnectivityRunner(
            database=self.database,
            recorder=self.recorder,
            client=self.client,
            routes=self.routes,
            fetchers=adapters,
            samples=self.samples,
            raw_store=self.raw,
            extractor=extractor,
            signatures=self.signatures,
            ledger_dir=self.ledger_dir,
            clock=self.clock,
            probe_client=probe,
        )


def build_stack(database: Database, fixed_clock: FixedClock, tmp_path: Path) -> Stack:
    """Wire a local stack: fake gateway, stub extractor, local stores, the given database."""
    fake = FakeGateway(fixed_clock, identity_header=IDENTITY_HEADER, source_header=SOURCE_HEADER)
    http = httpx.Client(transport=fake.transport())
    raw = LocalObjectStore(tmp_path / "raw")
    markdown = LocalObjectStore(tmp_path / "markdown")
    tokens = ClientCredentialsTokenProvider(
        http=http,
        token_url=FAKE_TOKEN_URL,
        client_id=FAKE_CLIENT_ID,
        client_secret=SecretStr(FAKE_CLIENT_SECRET),
        clock=fixed_clock,
        refresh_fraction=REFRESH_FRACTION,
    )
    recorder = RunCallRecorder(database)
    sleeps: list[float] = []
    routes = {
        SourceKind.CONFLUENCE: Route(namespace="confluence", source=SourceKind.CONFLUENCE),
        SourceKind.JIRA: Route(namespace="jira", source=SourceKind.JIRA),
        SourceKind.GITHUB: Route(namespace="github", source=SourceKind.GITHUB),
    }
    client = GatewayClient(
        http=http,
        base_url=FAKE_BASE_URL,
        tokens=tokens,
        identity_header=IDENTITY_HEADER,
        source_header=SOURCE_HEADER,
        source_credentials={kind: SecretStr(SOURCE_SECRET) for kind in routes},
        clock=fixed_clock,
        sink=recorder,
        use_case_id=USE_CASE,
        sleep=sleeps.append,
    )
    return Stack(
        clock=fixed_clock,
        fake=fake,
        database=database,
        raw=raw,
        markdown=markdown,
        stub=StubExtractionService(raw, markdown, fixed_clock),
        tokens=tokens,
        client=client,
        recorder=recorder,
        samples=load_sample_items(default_sample_items_path()),
        routes=routes,
        signatures=SignatureStore(tmp_path / "signatures"),
        ledger_dir=tmp_path / "runs",
        sleeps=sleeps,
        http=http,
    )
