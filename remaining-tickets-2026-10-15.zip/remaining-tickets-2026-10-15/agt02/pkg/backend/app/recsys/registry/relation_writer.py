"""Persist the evidence behind every published relation.

Called by :func:`app.recsys.registry.writer.write_version` inside its transaction, after
the link rows, so a reader can never see a relation whose evidence is missing. The
evidence of one catalogue version is replaced as a whole on a forced rewrite of that
same version, exactly like the review ledger: no other version's evidence is touched,
and nothing is deleted from the link table.
"""

from __future__ import annotations

from typing import Any, Iterable

from app.recsys.registry.models import ComponentLink

_DELETE_RELATION_EVIDENCE = (
    "DELETE FROM recsys_relation_evidence WHERE catalogue_version = $1"
)

_INSERT_RELATION_EVIDENCE = """
INSERT INTO recsys_relation_evidence (
    catalogue_version, src_id, dst_id, link_type, entry_ordinal, relation_key,
    authority, collection, structural_locator, field_name, token_ordinal, raw_value,
    raw_value_redacted, raw_value_digest, resolution_outcome, matched_index, rule_id,
    rule_version
) VALUES (
    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18
)
"""


def relation_evidence_params(
    version: str, links: Iterable[ComponentLink]
) -> list[tuple[Any, ...]]:
    """Render every evidence entry of every link as query parameters.

    Entries are numbered within their relation in canonical order, so a rewrite of the
    same sources produces the same rows.

    :param version: The catalogue version the links belong to.
    :param links: Links produced by :func:`app.recsys.registry.links.build_links`.
    :return: One parameter tuple per entry, for :data:`_INSERT_RELATION_EVIDENCE`.
    :raises ValueError: If a link carries evidence but no relation key.
    """
    params: list[tuple[Any, ...]] = []
    for link in links:
        if not link.evidence:
            continue
        if link.relation_key is None:
            raise ValueError("a link carries evidence but no relation key")
        for ordinal, entry in enumerate(link.evidence):
            rendered = entry.as_dict()
            params.append(
                (
                    version,
                    link.src_id,
                    link.dst_id,
                    link.link_type.value,
                    ordinal,
                    link.relation_key,
                    rendered["authority"],
                    rendered["collection"],
                    rendered["structural_locator"],
                    rendered["field_name"],
                    rendered["token_ordinal"],
                    rendered["raw_value"],
                    bool(rendered["raw_value_redacted"]),
                    rendered["raw_value_digest"],
                    rendered["resolution_outcome"],
                    rendered["matched_index"],
                    rendered["rule_id"],
                    rendered["rule_version"],
                )
            )
    return params


async def write_relation_evidence(
    conn: Any, version: str, links: list[ComponentLink]
) -> int:
    """Replace one catalogue version's relation evidence.

    :param conn: The connection :func:`~app.recsys.registry.writer.write_version` is
        writing through, inside its open transaction.
    :param version: The catalogue version being written.
    :param links: Every link written for that version.
    :return: How many evidence entries were written.
    :raises asyncpg.PostgresError: If a statement fails at the driver level.
    """
    await conn.execute(_DELETE_RELATION_EVIDENCE, version)
    params = relation_evidence_params(version, links)
    if params:
        await conn.executemany(_INSERT_RELATION_EVIDENCE, params)
    return len(params)
