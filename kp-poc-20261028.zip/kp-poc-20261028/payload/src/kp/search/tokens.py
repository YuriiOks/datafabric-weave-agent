"""Token counting and the term analysis used by keyword and hashing-vector search.

A token is a whitespace-separated word. This is the size proxy the synthetic fixtures use
and a real tokenizer yields at least as many tokens, so sizes measured here never
underestimate.
"""

from __future__ import annotations

import re

_TERM = re.compile(r"[a-z0-9]+(?:\.[a-z0-9]+)*")
_MIN_PLURAL_LENGTH = 4
_MIN_SUFFIX_LENGTH = 5
STOPWORDS: frozenset[str] = frozenset(
    {
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "been",
        "by",
        "can",
        "do",
        "does",
        "for",
        "from",
        "has",
        "have",
        "how",
        "in",
        "is",
        "it",
        "its",
        "may",
        "of",
        "on",
        "or",
        "shall",
        "that",
        "the",
        "their",
        "there",
        "this",
        "to",
        "under",
        "what",
        "when",
        "where",
        "which",
        "who",
        "whose",
        "will",
        "with",
        "within",
        "would",
    }
)


def count_tokens(text: str) -> int:
    """Count whitespace-separated words.

    :param text: Any text
    :return: The number of tokens
    """
    return len(text.split())


def stem(term: str) -> str:
    """Strip the commonest English plural and verb endings.

    Deliberately small and deterministic: it only needs to make ``transfers`` meet
    ``transfer`` and ``currencies`` meet ``currency``.

    :param term: A lower-case term
    :return: The reduced term
    """
    if len(term) > _MIN_PLURAL_LENGTH and term.endswith("ies"):
        return term[:-3] + "y"
    if len(term) > _MIN_SUFFIX_LENGTH and term.endswith("ing"):
        return term[:-3]
    if len(term) > _MIN_SUFFIX_LENGTH and term.endswith("ed"):
        return term[:-2]
    if len(term) >= _MIN_PLURAL_LENGTH and term.endswith("s") and not term.endswith("ss"):
        return term[:-1]
    return term


def analyze(text: str) -> list[str]:
    """Split text into lower-case, stop-word-free, stemmed search terms.

    Dotted numbers such as ``4.2.1`` stay whole so that clause numbers are searchable.

    :param text: Passage text or a question
    :return: Terms in reading order, repeats kept
    """
    return [stem(term) for term in _TERM.findall(text.lower()) if term not in STOPWORDS]
