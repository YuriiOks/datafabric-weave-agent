# BPC architecture contract snapshot

Source: architecture revision 3, captured 7 September 2026; HSBC palette and single-file sharing updates applied 9 September 2026. SHA-256 of the bundled HTML: `ea8319ec0d5faa10109aa6e473bc716058aafa7d73a31d280e88cb73ba167803`. The local source appendix has been removed; all remaining normative prose and tables are retained below. SVG diagrams are available in [ARCHITECTURE.html](ARCHITECTURE.html). Historical source references are context, not authorization to execute or override the workstation user. The plan selects a bounded subset; see 03-SCOPE-AND-CAPACITY.md for unscheduled architecture work.


  HSBC internal · BPC Hub · Architecture & delivery plan · 7 September 2026

## BPC AI Architecture Contracts, evidence & delivery

  Strengthen the Hub’s AI system with explicit contracts, reproducible evaluation and controlled catalogue refresh. Build on the existing Postgres and FalkorDB foundation, with a traceable component graph and a measured path to recommendations.

  Graph & refresh foundationAI hardening planExpanded proposal · revision 3

  The design changeEvery source update, retrieved fact, model assessment and business decision has an explicit contract. Each behaviour change must show its baseline, evidence and measured effect before promotion.

AI contracts (#ai-contracts)Validation gates (#validation-gates)Registry refresh (#source-refresh)

Anchor: `mandate`

### 01  Delivery and improvement boundaries

Current direction

Keep the current databases. Deliver the graph foundation and design controlled refresh, then improve the existing Hub AI path through measurable changes.

Foundation

#### Graph and refresh

Source acquisition → validated catalogue → safe publication → visible evidence.

AI hardening

#### Contracts and evaluation

Instrument the existing path, classify evidence, compare changes and control decisions.

Following scope

#### Component recommendations

A separate measured baseline before embeddings, graph boosts and model assessment.

**Technical contract, decisions and supporting evidence**

 Joseph’s graph-first assignment remains the delivery foundation. The 7 September follow-up requests a broader AI improvement architecture and retains the current Postgres/FalkorDB stack. This revision adds controlled refresh, shared AI contracts and explicit validation gates to the plan; it does not report those features as already implemented. Dmytro’s separate CxO-to-app pipeline remains source-owned.

#### Deliver in this phase

- A versioned, scoped component catalogue and graph of source-declared relationships.
- A read-only demonstration with provenance, quality status and unresolved-reference diagnostics: reuse the current registry/graph view where practical; otherwise use bounded queries and an accessible generated list.
- A repeatable import, publication, rollback and recovery path.
- The engine architecture, evaluation contract, decision record and presentation walkthrough.

#### Separate implementation gate

- Semantic retrieval, embeddings, model assessments, ranking and recommendation jobs.
- A recommendation UI, automatic component attachment or any execution of skills/tools.
- An outward-facing Hub MCP service, governance synchronisation or Knowledge Source expansion.
- Changes to existing novelty, completeness or similarity behaviour require the AI validation and promotion gates in this expanded plan; they are not part of graph acceptance.

 Existing PoC work is reusable evidence. Review the current workstation branch before changing it. Reuse compatible registry/parsing/UI code; do not delete a working PoC or treat its existence as approval to extend the engine. The new graph feature must not start model calls through old startup hooks or routes.

 Initial data scope: build the first candidate from a newly verified, approved PPD snapshot. Production requires a separate complete export, identity/visibility policy and rollout decision; the historical PPD workbook is not evidence of current Production state.

 This document replaces the earlier build-pack design as the proposed plan for this assignment. Historical files remain snapshots. Exact current code paths, deployed versions and the cleaned workstation architecture require reconciliation at delivery gate G0.

Scope and reuse: reconciliation is the first task. Keep compatible existing PoC code; extend shared interfaces before adding behaviour. The reported CLI-only source workflow is a starting observation to verify, not proof that refresh auth, a durable worker or an Agent Hub API exists. The UI button is enabled only after its write and recovery contracts pass.

Anchor: `review`

### 02  What the review changes

Design findings

The review strengthens identity, publication, access and evaluation. The complete findings remain available with their replacement contracts.

**All 19 findings and replacement contracts**

 The original architecture has useful foundations: a typed registry, deterministic candidate membership, provenance, bounded calls and legitimate empty results. Its weakest points concern the graph lifecycle and the gap between structural validation and trustworthy recommendations. The findings below describe design gaps, not claims of newly executed exploits.

 Scroll table horizontally →

What the review changes — table 1
ID / priority | Weak point and consequence | Replacement contract |

W01 · Critical | Graph is optional behind a full recommender build. The delivery order contradicts the current request. | Graph implementation first; engine remains a documented design. §1 (#mandate) |

W02 · Critical | Folder slug, portal ID and order-based duplicate suffixes compete as identity. Renames or reordered exports can corrupt joins. | Durable internal identity, scoped aliases, explicit duplicate and rename decisions. §8 (#identity) |

W03 · Critical | Platform auth is assumed without a graph/cache/history contract. Tenant and environment boundaries can disappear in joins. | Server-derived scope and current authorisation at every read, traversal and cache return. §14 (#security) |

W04 · High | Recommendation eligibility controls graph visibility. An agent with a missing description disappears despite valid identity and declared links. | Separate graph validity, matching readiness and execution permission. §7 (#model) |

W05 · Critical | MERGE-only refresh retains deleted relationships; mid-import readers can see a mixed catalogue. | Immutable candidate publications and one reader-visible publication pointer. Retire by omission only from validated complete sources. §11 (#publication) |

W06 · High | No complete-source manifest, precedence or schema-drift gate. Missing sheets/headers can silently remove links. | Versioned source contracts, field authority, count reconciliation and explicit quarantines. §9 (#ingestion) |

W07 · High | Tool references are matched to MCP servers by a string heuristic. Plausible matches become false facts. | Typed resolution with exact mapping evidence; ambiguous heuristic candidates remain unresolved. §8 (#identity) |

W08 · High | Allow-lists and dependency declarations lack a sufficiently explicit boundary from actual execution evidence. | Distinct edge meanings and evidence; no inferred execution or production approval. §7 (#model) |

W09 · High | Treating a component Agent as a native Hub Agent, or joining them by display name, can misattach existing UseCase→Agent relationships. | Unbound by default; only an exact, authorised native-ID adapter may add a Hub connection later. §3 (#boundaries) |

W10 · Critical | Graph errors can become empty answers; partial model runs can become successful empty recommendations. | Typed unavailable, stale, partial and complete outcomes; missing measurements stay unmeasured. §12 (#read-contract), §16 (#evaluation) |

W11 · High | Exact quote existence is presented as eliminating hallucination, even when the “need” was itself model-inferred. | Evidence anchored in authorised original input and source fields; semantic correctness evaluated separately. §15 (#engine) |

W12 · High | Per-query min/max rank scores and a fixed 0.45 threshold change as candidates change, without calibration. | Stable baseline retrieval, separate fit decision, validation-set calibration and no confidence percentages from rank. §15 (#engine) |

W13 · High | Co-occurrence rewards popular agents; incomplete or forbidden dependencies can look ready to use. | Disable graph boosts initially; evaluate them independently. Expose prerequisite and permission status. §15 (#engine) |

W14 · High | Cache keys omit scope/policy and model or embedding details; per-call timeouts do not bound total cost. | Full lineage, scoped keyed hashes, reauthorisation and one request budget covering retries. §15 (#engine) |

W15 · High | Persisted “result” and evidence quotes can reconstruct input despite a no-raw-input claim. | Minimised storage, protected source locators, explicit retention and safe logs. §14 (#security) |

W16 · High | Illustrative quality targets and fixtures are easily confused with measured live quality. | Separate infrastructure completion, label coverage and quality; failures never improve metrics. §16 (#evaluation) |

W17 · High | Deployment, orphan cleanup, rollback, old readers and source revocation lack a coherent owner. | Bounded retention, guarded cleanup, compatibility gates and operational ownership. §13 (#operations) |

W18 · Medium | Old data counts, ORM assumptions and unrelated onboarding docs look current. | Dated evidence, G0 workstation reconciliation and BPC-specific onboarding. |

W19 · Critical | A global component primary key contradicts immutable rows per catalogue version; a single merged source field loses field lineage. | Separate durable identity from snapshot-scoped records, with source occurrences, field claims and same-publication endpoint constraints. §7 (#model) |

Anchor: `boundaries`

### 03  Architecture and system boundaries

The target keeps Postgres for authority and durable state, FalkorDB for graph and approved retrieval indexes, and typed services for AI decisions. Existing tables and worker capabilities must first be reconciled.

#### Current stack retained

Postgres

#### Authority and durable state

Proposed responsibilities: catalogue, lineage, publication, jobs and review records. Reuse verified tables or add the minimum reviewed schema.

FalkorDB

#### Graph and retrieval

Bounded relationships and approved indexes, qualified against the actual deployed version.

Database product replacement and vendor comparisons are outside this programme. Read the existing-stack qualification contract (#storage-decision).

**Technical contract, decisions and supporting evidence**

 Postgres owns the catalogue, evidence and publication descriptor. FalkorDB serves a rebuildable graph projection. The graph is never an independent source of component truth. Use the existing Hub backend, Postgres, FalkorDB and frontend; this plan introduces no separate platform service, graph vendor, queue or vector database.

#### Recommended: isolated graph namespace

Use a dedicated named graph key per scope and publication within the existing FalkorDB instance. It keeps candidate/stale component generations away from existing Hub queries. Approve the namespace and capacity with the platform owner at G0; the earlier “no new graph” constraint must be reconciled explicitly.

#### Alternatives considered

A shared graph with versioned labels is possible only if every legacy reader/index excludes staged and retired data. That is a larger compatibility burden. The current direction retains FalkorDB for graph serving and Postgres for authority. If required isolation is unavailable, correct the existing deployment or narrow the supported capability before activation; a database migration is a separate decision.

#### Existing-stack qualification

Current direction: retain Postgres and FalkorDB. Database product replacement, a second vector database and a vendor benchmark are outside this programme. The engineering question is whether the proposed contracts are implemented safely on the actual deployed stack. The platform owner still confirms named graph keys, privileges, capacity and compatibility with legacy readers.

Scroll table horizontally →

Architecture and system boundaries — table 1
Responsibility | Current store / service | What must be proven |

Identity, evidence and publication | Existing Postgres | Scoped stable identity, immutable records, versioned manifests, atomic publication selection and recovery. Map to verified existing tables or review the minimum schema additions; no ORM or existing job table is assumed. |

Relationships and retrieval indexes | Existing FalkorDB | Bounded authorised graph queries, generation isolation, index/query behaviour, readback sealing, resource budgets and safe retirement on the deployed version. |

Durable refresh and request coordination | Existing Postgres plus the approved worker mechanism | Durable job state, idempotency, ownership, restart recovery and current policy. Redis notifications or process-local background tasks are not themselves a durability guarantee. |

Model and decision boundary | Existing approved AI gateway and Hub services | Versioned model/schema/prompt configuration, finite budgets, evidence validation, task-specific policy, reproducible comparison and explicit failures. |

#### Correctness before optional retrieval features

Qualify one-/two-hop reads, identity lookup, denied intermediate nodes, provenance, source removal, refresh, rollback and uncertain-writer recovery. Record latency, memory with active/candidate/retained generations, ingestion time and operational steps. Use the proposed read budgets (#read-contract) until the owners approve measured limits. The validation gates (#validation-gates) specify the experiments and their evidence.

The current FalkorDB vector-index documentation notes limitations combining vector queries with property filters. Verify the exact plan and deployed version before enabling a policy-sensitive vector path; this is not a claim that ordinary graph predicates are unsupported. A global ANN top-k followed by application filtering is not the required scoped retrieval contract. If a safe vector path cannot be proven, keep that channel disabled, retain a separately validated authorised exact/lexical mode only when the task permits it, and report the capability gap. Never silently relax access rules or claim equivalent recall. FalkorDB vector-index documentation (https://docs.falkordb.com/cypher/indexing/vector-index).

Existing-stack retention does not make every feature mandatory. Tune or narrow the supported capability when a gate fails; if no authorised mode meets the minimum task contract, return unavailable. Escalating a measured platform limitation is a separate decision, not an automatic migration fallback.

#### The earlier improvement programme, made executable

The earlier evaluation design and operating prerequisites supply the foundation: typed stages, evidence maturity, comparable experiments, versioned generations, distributed ownership and calibrated decision behaviour. This revision carries those controls into shared AI contracts (#ai-contracts), decision authority (#decision-authority), controlled refresh (#source-refresh) and AI operations (#operations). Prior proposals remain historical evidence of intent, not proof of deployed fixes.

#### Optional later connection to the existing Hub

 Component Agents are intentionally unbound in the first graph. Native Hub binding is an adapter design, not a graph-delivery dependency. Reuse it in this phase only if G0 proves an existing exact mapping and a negligible integration change; otherwise defer its implementation and acceptance.

 Keep the native Hub Agent and its existing `EMPLOYS_AGENT` relationships intact. A `HubAgentBinding` maps a component Agent ID to a native Hub Agent ID using an exact, scoped identity assertion. The read adapter can then show authorised use cases alongside component relationships. Do not merge on display name, create cross-graph edges or rewrite native Agent nodes.

 Binding status is `verified | unbound | ambiguous | stale`. An unbound Agent can still appear in the component graph; its Hub connection is visibly unavailable. Each binding records the Hub identity version/time checked. If the native Hub has no versioned snapshot, the UI labels that join as current Hub metadata rather than claiming an atomic historical view of both systems. CxO governance remains owned by its source pipeline.

Anchor: `validation-gates`

### 04  Architecture validation before implementation

Proposed · evidence required

A working slice must prove its contracts before the plan expands. AI changes then compete against a measurable incumbent on the existing stack.

**Experiments, exit criteria and evidence to retain**

#### Every gate has an observable exit

Freeze the hypothesis, source manifest, configuration and pass/fail rules before the run. Save the code revision, environment, per-case outputs, stage measurements, exclusions and reviewer decision. A screenshot or a successful CLI exit is insufficient. Existing-stack failures lead to correction, a smaller supported scope or a blocked capability; this programme does not silently switch databases.

Validation gates
Gate / hypothesis | Bounded experiment | Exit and evidence | Owner / next step blocked |
V0 · The current state is known | Inspect the live checkout, cleaned architecture, PoC routes, startup hooks, model access, source availability, auth and worker mechanisms. Record approved source scope and immutable inputs. | A baseline manifest and open-gap register distinguish observed, reported and proposed behaviour. Missing auth or credentials remain blockers for their dependent paths. | Yurii: contracts and baseline. Mayank: source/runtime reconnaissance. Blocks new write paths and unsupported implementation assumptions. |
V1 · Source facts survive ingestion | Use real, authorised fixtures with reviewed expected nodes/edges; include duplicate MCP IDs, renames, missing descriptions, malformed metadata, incomplete sheets and source removal. Repeat after row reordering. | Exact expected fact/identity parity on the fixture; every row and reference accounted for. Malformed or incomplete input never becomes an inferred removal. Retain fixture hashes, expected-output manifest and differences. | Mayank prepares fixtures; Yurii owns resolver/oracle semantics. Blocks catalogue and refresh activation. |
V2 · The existing graph and refresh are safe | Run a thin existing-FalkorDB slice: bounded one-/two-hop reads, denied intermediate nodes, policy changes, concurrent refresh, interrupted writes, expired lease, uncertain acknowledgement and rollback. | Zero observed access leaks; no mixed/unsealed publication; revoked access remains revoked after rollback. Preserve fault-injection traces, publication IDs and recovery steps. Prove feasibility before expanding implementation. | Yurii owns graph/job/policy mechanisms; Mayank assembles source-to-UI evidence. Blocks graph/read and refresh enablement. |
V3 · AI comparison is measurable | Record incumbent behaviour in non-authoritative BaselineObservation envelopes; map comparable retrieval evidence without turning a legacy model verdict into a policy decision. Run the same authorised, adjudicated cases with frozen task policy and versions. A contracts-only first slice must preserve recorded behaviour. | Report all planned-case outcomes, including failures and unjudged items. The prior attempted evaluation produced no valid quality measurements for 16 planned cases; missing evaluation coverage is not a quality score. Retain a comparable replay report and manifest; document any unavailable retrieval observations. | Yurii owns adapter and scoring harness; Mayank owns replay fixtures and diagnostic presentation. Domain reviewer owns labels. Blocks quality claims and default-path changes. |
V4 · A proposed AI change earns promotion | Compare one change at a time: evidence policy, channel normalisation, weighted fusion versus RRF, deduplication/diversity, optional reranker. Use the frozen task-specific evaluation contract. | Pre-agreed per-task quality and risk gates, no access/fabricated-ID regression, and explicit latency/cost trade-off. A failed comparison leaves the incumbent in place. Retain paired per-case results and adjudicated disagreements. | Yurii owns candidate implementation; Mayank prepares comparison/review views. Product/domain owner accepts the trade-off. Blocks shadow/canary promotion. |
V5 · The selected implementation can operate | Measure current corpus, growth stress and approved forecast with realistic high-degree nodes, selective policies, cold/warm cache, imports alongside reads, active/candidate/retained generations and worker loss. Exercise rollout and rollback. | Meet agreed p95/p99, freshness, memory, queue and token/cost budgets. No reduced scope or skipped cohort disappears from the report. Retain capacity report, CI run references and a rehearsed operator runbook. | Yurii owns service budgets/recovery; Mayank assembles acceptance evidence. Platform owner confirms limits and rollout. Blocks broad enablement. |

#### Three tasks need three evaluation meanings

Task-specific evaluation
Task | Ground truth and checks | A misleading success to reject |
Completeness scoring | Approved card fields, taxonomy and expected computation. Trace what the scorer actually read; check that agreed equivalent aliases/normalisation preserve recognised values and satisfy the defined monotonicity property. Close the original zero-score case independently. | An alias fix is not proof that the original completeness defect is fixed. A completeness score is not a novelty or suitability score. |
Hub novelty / coverage | Adjudicated NOVEL / PARTIAL / COVERED labels, required/forbidden evidence, evidence maturity and review-routing decisions. Measure false-COVERED and false-NOVEL separately, plus retrieval and evidence quality. | A plausible explanation or planned-only capability cannot establish implemented coverage. REVIEW_REQUIRED is a decision status, not a fourth business verdict. |
Component recommendation | A separate relevance pool per Agent, Skill and MCP; hard negatives, genuine empty needs, authorisation, duplicate saturation and prerequisite coverage. Measure lexical baseline before adding vectors, graph signals or model assessments. | Declared co-use is not suitability ground truth. A disabled, failed or unassessed run is not a correct no-match. |

Related source/card families stay in one split. Use development and validation for tuning, a separate calibration split if probabilities are shown, and a frozen final test for release claims. Domain reviewers adjudicate labels and disputes; model outputs and clicks only nominate cases. Synthetic cases stress load, failures and injection, while representative adjudicated cases establish quality. Small seed cohorts are exploratory and cannot hide weak types behind an aggregate score.

For every comparison, state the denominator: all valid planned cases, successfully completed cases, judged outputs and any unjudged pool. A result omitted for missing permissions, unavailable models or incomplete sources still appears in coverage. Keep relevance metrics, business-risk errors, evidence support, latency and cost separate. Set numeric promotion targets with the accountable owners before seeing candidate results.

Source: earlier evaluation design and capacity ladder. The earlier review is a proposal, not a record of deployment.

Anchor: `ai-contracts`

### 05  Shared contracts for an evidence-bound decision path

Proposed · not implemented

  One typed contract chain can harden the existing bounded Hub route without adding a framework, a database, or a third retrieval pipeline. Task-specific adapters keep Hub entity decisions separate from a future component fit.

**Normative shared interfaces, evidence semantics and model boundary**

      Scope and placement. These are boundary records for the existing Hub request path, not proposed deployed modules. They preserve the current Postgres catalogue and FalkorDB graph delivery. Before implementation, confirm in current code which route invokes the six bounded channels and exact/identifier matching; the hardening wraps or replaces stages in that path only. It does not create a third retrieval pipeline, a new framework, or another store.

#### Request and retrieval records

- `RequestContext` is the common envelope: generated run ID, server-derived principal and current policy scope, task discriminator, validated opaque request/card ID, immutable input version and pinned configuration. Its discriminated payload is exactly one of `HubDecisionRequest` (Hub input and permitted evidence domain), `CompletenessRequest` (validated card fields and scoring-taxonomy version), or `ComponentRecommendationRequest` (requested component types, explicit must-have/optional/excluded requirements and vocabulary version). Reject fields belonging to another task and unknown discriminators. Inferred prose never replaces an explicit requirement.

- `CandidateHit` contains an `EntityRef` with validated stable ID, entity type, scope and immutable version; frozen catalogue/corpus generation; retrieval channel; channel-local rank or trace; retrieval configuration version; and truncation/budget status. For a Hub novelty task, the entity reference is a `UseCase` or `Card`; for the separately scoped future recommender it may be an `Agent`, `Skill`, or `MCP`. A hit is never proof of fit, completeness, or novelty.

- A logical task-specific adapter binds `RequestContext` to the permitted entity domain and retrieval configuration. It is a contract boundary, not an invented deployment module. Confirm the current Hub route and its six bounded channels in code before hardening it; do not describe the existing Hub path as already retrieving components. Any later component-retrieval mode remains a separate implementation scope.

- For the confirmed Hub adapter, retain the current bounded composition of exact/identifier matching plus vector, capability, text, technology, data-source, and domain channels, with bounded graph evidence where configured. Channel limits, fusion, eligibility and minimum-service rules are task policy/configuration inputs recorded in the manifest, never LLM choices.

#### Evidence is typed per material claim

      `SourceEvidence` binds a claim to a source ID, immutable source/version locator, field or offset range, content hash, observation time, and visibility context. Its lifecycle is independently `implemented`, `planned`, `retired`, or `unknown`; freshness is independently `current`, `stale`, or `unknown`; and conflict status is independently `consistent`, `conflicting`, or `unknown`. Policy defines which combinations can support a given decision. Claim completeness describes whether the required evidence set was collected. It is not a novelty conclusion.

      Quote validity and semantic truth are separate checks. A validator can prove that a quotation exists at the recorded offset and belongs to the frozen source. It cannot prove that the quotation entails the claim, that the source is current, or that a planned capability is implemented. Semantic support, contradiction and freshness require the typed evidence policy and, where specified, human adjudication.

#### Candidate fit is not a Hub novelty verdict

      BaselineObservation is a separate envelope. Instrument the incumbent without changing its served behaviour: record `origin=legacy`, its observed status/verdict, candidate/evidence observations where available, execution coverage, failures and run lineage. This is a non-authoritative observation for comparison, never a new `TaskDecision`. If the incumbent uses an LLM verdict, the adapter retains that origin explicitly. The deterministic candidate policy alone emits the proposed authoritative `TaskDecision`; both paths expose comparable observations to evaluation without converting the legacy verdict into policy authority.

      `CandidateAssessment` is per future component candidate and per explicit requirement. Its fit is `strong`, `partial`, `none`, or `insufficient_evidence`; its assessment state separately records whether it was `assessed` or `unassessed`. It also records supporting and contradicting evidence references, missing prerequisites, known execution permission, `assessment_origin` and `semantic_support=unreviewed|adjudicated`. Structural validation does not make the fit human-verified. `none` means sufficiently assessed evidence supports no fit; `insufficient_evidence` and `unassessed` do not. An unknown or unmet mandatory prerequisite makes a suggestion conditional or non-actionable.

      `TaskDecision` is a separate Hub task result. Only a frozen, task-specific policy may return `NOVEL`, `PARTIAL`, or `COVERED`; it carries status, deterministic reason codes, evidence IDs and policy version. A numeric probability is optional and may be included only when a held-out calibrated method/version exists. A future component fit is never converted into a Hub novelty label.

#### Manifest and optional model output

      Version compatibility is enforced, not only logged. Resolve request-time aliases through server-owned configuration before execution and pin the resolved configuration digest. Each stage and cache hit validates the compatible tuple of contract schema, task policy, prompt, model/deployment, embedding space, text/evidence builder and catalogue/publication. Capture the actual endpoint/deployment and returned model identifier when available; reject detected drift or missing required version evidence for cache reuse and release evaluation. A client cannot override those identifiers.

      Some approved providers do not expose immutable weights or a model artefact hash. Record the observable deployment, response metadata, observation window and `reproducibility=deployment_scoped`; never invent a hash or claim bit-for-bit replay. Such a mode requires an explicit evaluation and cache policy, drift monitoring and a release decision for that deployment. Undetected provider weight changes remain a stated limitation; an unqualified mode cannot support cross-version cache reuse or a reproducible promotion claim.

      `RunManifest` is immutable after completion and joins the request context, task/entity domain, entity-hit hash, evidence IDs, policy/version inputs, retrieval configuration, outcome, task-specific failure/coverage state, and audit links. It records a Hub decision and a future component assessment only in their own task/mode fields; neither derives the other. It pins code revision; input and catalogue/corpus generation; graph publication descriptor; schema and output-schema hashes; prompt/template version; model provider, revision and artefact hash where available; embedding model, revision, dimensions and text-builder version; and policy version. Missing lineage is a failure to reproduce the outcome, not an invitation to guess a version.

      An optional LLM may propose attributed claim candidates or render an evidence-bound explanation from frozen records in a separately approved mode. Its structured output is validated before use and must identify the entity reference and evidence anchors it relies on. It cannot select an entity outside `CandidateHit[]`, declare a quote semantically true, select a Hub verdict, set execution permission, set capability constraints, or authorise an action. Capability constraints, eligibility, prerequisites, fit normalisation and task verdict rules remain deterministic and policy-owned.

      Corpus text, descriptions and model-produced prose are untrusted data. Apply layered controls: source and access boundaries, no free-form tools or execution authority for the model, bounded excerpts, typed output and evidence validation, and review for material uncertainty. As the OWASP prompt-injection guidance (https://genai.owasp.org/llmrisk/llm01-prompt-injection/) explains, layered controls reduce exposure; no sanitisation or filter is claimed to eliminate indirect prompt injection.

#### Prior review → disposition

      Scroll table horizontally →

      Prior AI review findings and proposed disposition
Prior review theme | Disposition in this proposal |

Golden data and comparable experiment lineage | Use adjudicated, versioned cases and immutable manifests that pin corpus, policy, models, prompts, schemas and code. No benchmark or quality result is claimed today. |

Evidence maturity, calibration and human review | Represent material-claim state and freshness explicitly; allow numeric confidence only after held-out calibration; record review as an audited event, not automatic ground truth. |

Six-channel retrieval and rank fusion | Confirm the existing bounded Hub channel composition in code and retain it for its Hub entity domain. Any reciprocal-rank fusion or alternative weighting is a versioned policy/configuration choice that must beat the held-out baseline; it is not a parallel component-retrieval pipeline. |

Contributor/schema quality | Validate stable identity, source version, field/offset anchors, claim state and provenance before records become usable evidence. Ambiguity and missing material remain visible rather than silently normalised. |

Embedding generations and version pinning | Pin embedding model revision, dimensions, text-builder, content hash and corpus/publication generation. Never compare mixed embedding spaces; this adds no new retrieval store or database product replacement. |

Safe intent telemetry | Collect only approved category-level intent and operational outcome telemetry. Do not log raw queries, source excerpts, prompts, generated prose, credentials or connection strings in ordinary traces. |

Pipeline and framework changes | Defer workflow/framework replacement. Ordinary typed contracts and deterministic policy boundaries are proposed around the existing path; any future engine implementation remains separately approved work. |

      Technical basis: earlier review §4, typed ordinary pipeline; §5, target architecture and contract boundary; §6, evaluation and reproducible lineage. These references describe the proposed target; they do not evidence that it has been implemented.

Anchor: `decision-authority`

### 06  Decision authority, failure semantics and lineage

Proposed control plane

  An authoritative Hub verdict is available only after a validated request, typed material evidence and a frozen task policy. Everything else returns an explicit state with enough lineage to investigate it.

**Verdict rules, review controls, reproducibility and scope boundaries**

#### Authoritative decision predicate

      The decision function is entered only with validated stable IDs, current authorisation, a pinned input version, a frozen task-specific policy version, and typed evidence references that remain visible to the caller. The policy defines eligible claim states, minimum evidence, permitted channels, candidate limits, deterministic thresholds, abstention rules, reason codes, and whether any calibrated probability may be exposed. It also defines capability constraints and execution prerequisites; neither is inferred from prose or delegated to a model.

      Only the function operating on those pinned records may return `DECIDED` with `NOVEL`, `PARTIAL`, or `COVERED`. A raw similarity, retrieval rank, weighted score, or an LLM’s numeric confidence is not a probability. Numeric confidence is absent until held-out calibration establishes its method and version; when enabled, its calibration artefact/version is part of the manifest.

#### Mutually intelligible non-verdict states

- `invalid_input`: the request fails schema, stable-ID, scope, or immutable-version validation. Do not invoke search or a model. Return only a safe reason code so invalid and inaccessible references do not disclose catalogue information.

- `needs_information`: the request is valid but lacks material, explicit requirements needed to apply the policy. Return bounded, structured questions or missing fields; do not turn unknown requirements into negative evidence.

- `REVIEW_REQUIRED`: the request and required dependency path completed, but the policy abstains because material evidence is planned-only, unknown, conflicting, stale, semantically unsupported, or otherwise insufficient. Return no Hub verdict and create a durable review item with evidence references.

- `dependency_failure`: an authoritative dependency such as current policy, authorisation view, required source/evidence, retrieval minimum, or manifest persistence cannot meet the declared contract. Preserve the failure reason and lineage; do not report it as an empty result, a negative match, or an evidence abstention.

      An unavailable optional explanation call does not invalidate an already deterministic decision: return the evidence, policy result and manifest without prose. Provider output that fails schema validation may be retried only when explicitly repairable and within that task’s declared deadline and retry budget. Current Hub task limits must be measured and configured for that task; this proposal does not assign them a component-engine cap.

#### Review and feedback are audited, not automatic ground truth

      A reviewer may resolve a `REVIEW_REQUIRED` item or override a prior decision only through a separate audit event containing the reviewer identity/role, time, reason, policy and manifest versions, cited evidence, and the resulting disposition. The original decision and source evidence remain immutable. An override does not silently alter corpus facts, policy thresholds, benchmark labels, or model calibration. A label becomes evaluation ground truth only after the domain-owned adjudication and dataset-version process has accepted it.

#### Lineage, bounded retries and cost control

      Every request and evaluation run records its immutable manifest before it is eligible to support an outcome claim. At minimum pin: request/card version; catalogue/corpus generation and FalkorDB publication descriptor; policy and schema/output-schema versions; retrieval configuration; prompt/template version; provider, model revision and available artefact hash; embedding model revision, dimensions and text-builder version; code revision; and evidence/candidate-set hashes. A changed policy, corpus, embedding space, prompt or model revision is a new run configuration, not a comparable continuation.

      All model calls use the approved gateway and declared admission, excerpt, token and cost reservations. Backoff waits only within the applicable request deadline. If the separately approved future component-assessment engine is implemented, its model calls retain the stated total ceiling of four attempts for that engine run, including retries and schema repair; no separate retry budget exists. This does not impose a four-attempt ceiling on current Hub tasks. Do not stitch partial provider responses from different candidate contexts. On an exhausted deadline, budget, or attempt ceiling, return the applicable partial or failure state with covered/unassessed work recorded in the manifest.

#### What is delivered, proposed and still unknown

#### Graph delivery

Current scope: a traceable component graph with Postgres as catalogue/evidence authority and the existing FalkorDB instance as the rebuildable projection. This section does not change that storage decision.

#### AI hardening proposal

Proposed: typed contracts, deterministic policy ownership, explicit failure semantics, provenance/lineage, review audit and evaluation gates around the existing bounded Hub path. No implementation is asserted here.

#### Separate engine scope

Future retrieval/assessment calls, embeddings, model providers, asynchronous jobs, recommendation UI, component attachment and execution remain subject to a separate implementation decision.

      Owners and governance remain open. Name the accountable policy owner, domain adjudication owner, model-risk and human-oversight classification, production approval authority, retention/audit owner, approved model endpoint, and operational cost/latency limits before implementation or rollout. This document proposes the controls; it does not assign or evidence approval for them.

      Technical basis: earlier review §5, authority boundary and failure semantics; §6, frozen evaluation and manifest discipline. The target document’s existing future engine (#engine), evaluation (#evaluation), authorisation (#security), and Postgres/FalkorDB boundary (#boundaries) remain the governing presentation context.

Anchor: `model`

### 07  The graph means exactly what the sources say

Every edge means a specific source declaration. Visibility, suitability for matching and permission to execute are separate decisions.

**Technical contract, decisions and supporting evidence**

 Skill

#### A reusable instruction

Identity and aliases plus versioned metadata. Parsing a SKILL.md file never runs it or follows its instructions.

MCP server

#### A tool-serving component

The server is the component node. Tool names are reference metadata unless a later scope adds Tool nodes.

Agent

#### A configured agent

A scoped source identity with declared component usage. Usage declarations are not execution telemetry.

Scroll table horizontally →

The graph means exactly what the sources say — table 1
Directed relationship | Precise meaning | Evidence required |

Agent → `USES_SKILL` → Skill | The agent’s source configuration declares this skill. | Snapshot, source row/field and exact resolved target. |

Agent → `USES_MCP` → MCP | The configuration references this MCP server or a tool mapped to it. | Original tool/server token and verified server mapping. |

Skill → `DEPENDS_ON_SKILL` → Skill | The skill explicitly declares a dependency. | Recognised field and declaration; required/optional/unknown qualifier. |

Skill → `ALLOWS_MCP` → MCP | The skill source lists particular tools associated with this server as allowed. This is a configuration claim, not a grant of runtime access. | Recognised allow-list syntax and verified tool mapping. No implied actual use. |

 Unknown syntax, an unresolved target or a conflicting identity stays in a reference ledger, outside the resolved edge set. Cycles remain truthful facts with a cycle flag; traversal uses a visited set and a depth limit. Dependencies are not silently promoted into usage edges. No inferred “recommended”, similarity or governance-approval edges are written in this phase.

#### Three separate decisions

- Graph-valid: a supported type, known scope, stable identity, permitted metadata and admissible source. Missing descriptive text does not automatically hide an otherwise valid node.
- Recommendation-ready: future matching has sufficient evidence, current allowed status, resolved mandatory prerequisites and a compatible supported version. This is a policy result, not a permanent node property.
- Executable: the user has the required access, configuration and runtime approvals. Neither graph visibility nor a future suggestion grants these permissions.

#### Logical records

 These are responsibilities to map onto existing tables during G0, not a requirement to create one new table per row below.

 Scroll table horizontally →

The graph means exactly what the sources say — table 2
Record | Required contract |

`ComponentIdentity` | Immutable UUID, type and owner-defined source namespace (authority, environment and native registration partition where identity depends on it); aliases and lifecycle maintained separately. Visibility is a versioned policy reference, not part of the immutable ID. No embedding column needed for graph delivery. |

`SourceOccurrence` / `FieldClaim` | Immutable manifest + artifact + row/path locator, original value or protected reference, hash, field name, authority and effective-value decision. Row order locates evidence within a snapshot only; it never identifies the durable component. Conflicting values remain separately traceable. |

`ComponentSnapshot` | Unique publication + component ID; name, description locator, version, graph status, quality reasons, source evidence and content hash. |

`RelationFact` | Unique publication + source component ID + relation kind + target component ID + qualifier; both endpoints must reference ComponentSnapshot records in that same publication and allowed scope, enforced by relational constraints. Assign a stable `relation_key` from canonical source ID, relation kind, target ID and qualifier, independent of publication/evidence content, for deny and retirement checks. Retain an evidence-set digest. Multiple source rows aggregate evidence, not duplicate edges. |

`ReferenceResolution` | Raw source token in restricted storage; expected type/scope, candidate IDs, outcome, method, mapping version and reviewer when applicable. |

`SourceManifest` | Authority, environment, tenant partition, export/schema version, capture time, completeness declaration, file/content hashes, row counts and accepted/quarantined reasons. |

`Publication` / `ActivePublication` | Immutable input/version manifest and state; one active descriptor per scope with catalogue ID, exact graph key, schema version, checksum, activated time and previous pointer. Keep current component/relation validity and security policy generations separately so rollback cannot rewind them. |

`HubAgentBinding` · optional later | Component Agent ID, native Hub ID, scope, verification evidence/version and binding state. |

 Use one unique descriptor row per stable `PublicationScope`: environment plus an owner-defined source/security partition. Caller entitlements are evaluated at read time; they do not create a graph per user or redefine its storage key. A component’s `observed_usage_tenants` is evidence of usage only. Visibility must come from an authoritative access policy. Unknown visibility stays restricted to the explicitly approved review audience.

 Graph properties stay small: opaque identity, kind, publication, safe display label, status and evidence reference. Full source content, credentials, employee identifiers and executable payloads do not belong in FalkorDB.

Anchor: `identity`

### 08  Identity and reference resolution

Resolve a scoped identity before publishing a relationship. Ambiguity stays visible as a diagnostic; names and similarity never silently merge records.

**Technical contract, decisions and supporting evidence**

 Names locate candidates; they do not establish identity. Assign one durable internal component ID after resolving a scoped source identity. Preserve that ID through future snapshots. Use `(authority, environment, tenant/domain partition, component type, external ID)` as the preferred source key only after the owner confirms that ID is stable and unique within that namespace.

 Scroll table horizontally →

Identity and reference resolution — table 1
Case | Deterministic decision |

Portal ID versus repository folder | Keep both as typed aliases. Where a portal ID is owner-confirmed stable, bind the repository skill to it. For repo-only skills, use an explicit durable mapping registry. A rename adds an alias after review; it does not mint a new component by default. |

No trustworthy stable ID | Retain the source record with a snapshot locator. An owner-reviewed mapping is required before it becomes a stable graph identity. File path, row number and display name alone are not durable identity. |

Duplicate source IDs | Keep conflicting records separate in quarantine. Never use `#2` based on row order. Publish separately only after the owner supplies a stable disambiguator; references without it remain ambiguous. |

PPD and Production; two tenants | Different identity namespaces unless an explicit scoped equivalence exists. PPD is never silently promoted into Production. A shared/public component needs a declared access policy, not a missing tenant value. |

MCP tool token → server | Resolve exact typed aliases first, then a versioned server/tool mapping. A longest-prefix heuristic can propose a mapping for review; it cannot establish an edge by itself. Require recognised separators and one admissible target in the same scope. |

Case, Unicode and spelling variants | Preserve original tokens. Apply only the source’s documented normalisation rules; distinguish a search-normalised value from an identity alias. Collisions become diagnostics. |

Alias reassigned or components merged | Record a reviewed mapping change with effective version and redirects. Each publication pins its mapping version; its graph endpoints keep that historical meaning. Show a current redirect only as separately authorised current metadata. Merges/splits/reassignments never rewrite old evidence; invalidate derived bindings and future caches. Reject aliases that map to multiple active identities within one namespace. |

 Source-specific parsing is necessary. The September workbook used agent-level field variants and MCP tool tokens. The reported fallback resolved 693 of 830 unique MCP references, leaving 137 unresolved. Those are historical resolver outcomes, not verified relationship truth or current edge counts. Reassess the accepted mappings before promotion.

 Resolution returns `resolved_exact`, `resolved_reviewed_mapping`, `missing`, `ambiguous`, `invalid` or `out_of_scope`. Report the denominator as unique reference tokens and separately as affected rows/edges. Ordinary users do not receive candidate names or counts from inaccessible scopes.

Anchor: `ingestion`

### 09  Ingestion that can explain its output

Capture, validate, resolve and reconcile before publishing. Keep uncertain source claims outside the resolved fact set.

**Technical contract, decisions and supporting evidence**

- Capture an immutable input set. Record source hashes, authority, PPD/Production, partition, capture time and full-snapshot versus delta semantics. No input files may change during the run. Never combine exports from different environments.
- Validate the source contract. Check required sheets, real header aliases, supported file sizes and parser shapes. An unknown mandatory relationship column fails validation. Empty sheets are legitimate only with explicit completeness evidence, not merely because parsing returned zero rows.
- Parse source records without execution. Treat markdown, YAML, descriptions and URLs as data. Restrict file paths to the import root; reject traversal, unsafe archive expansion and oversized documents. No automatic URL fetching, skill execution or MCP connections.
- Resolve identity and field authority. Agent Hub owns its exported identifiers and usage declarations; the repository owns skill content and declared tool/dependency metadata. Governance remains CxO-owned. Conflicts retain both evidence values and a reason; no “last row wins”.
- Classify records and relationships. Graph-valid nodes and exact/reviewed resolved facts can project. Bad identity/scope records are quarantined. Source-supported test or planned records remain graph-valid when admitted by the approved scope, with their status visible; exclude them only under an explicit source/scope policy. Missing descriptions are quality warnings. Required-dependency gaps are preserved even when the future matcher would exclude the component.
- Reconcile and compare. For each source/type/partition account for all input rows, duplicates, graph-valid records, quarantines, reference outcomes and deduplicated edges. Compare to the active publication and show additions, changes and removals by cause.
- Build and publish only after the gates pass. Produce an immutable catalogue, candidate graph and validation report. Publication follows the publication contract (#publication); ingest completion alone is not publication.

#### Completeness and removal rules

 The first importer accepts complete snapshots only. Delta support is a later adapter extension requiring explicit base revision, ordering and tombstone tests. A complete, authoritative snapshot can remove a previously declared fact from the next publication. A future delta must contain explicit tombstones; the first importer rejects delta mode rather than treating it as a full replacement. A missing file, unknown header, incomplete export or failed source is not a deletion instruction. Carrying an older source snapshot is allowed only under a documented freshness policy with its original timestamp; the resulting version vector must disclose that age.

 Structural/schema failures block the affected publication. A previously accepted identity or mandatory relationship becoming unparseable also blocks promotion until corrected or explicitly excluded by a reviewed exception. Other new malformed rows can be quarantined under the approved quality policy, with counts visible. Unresolved-reference acceptance thresholds and any exception are versioned, owned and attached to the publication; default G0 requires reviewing every unresolved class and every removal.

 Monotonic source versions: track completeness and order per authority, partition and collection (Agent records, usage declarations, Skill content, and so on). A complete Agent sheet cannot authorise removal of usage relationships from a missing usage sheet. Activation rejects any collection-version regression; carrying a source means reusing the identical prior occurrence and its original age. Use an authoritative revision sequence where available. If only timestamps exist, the source owner must approve a version order before promotion; ambiguous order cannot auto-activate.

#### Make noisy developer input reviewable

Better storage cannot decide which source is trustworthy. Treat duplicates, generic copied descriptions, planned capabilities, stale registrations and ambiguous tool names as distinct data conditions. A polished description is not a quality signal. The trusted catalogue admits only facts whose identity, scope and source authority are resolved; descriptive quality then controls future matching separately.

Scroll table horizontally →

Ingestion that can explain its output — table 1
Noise condition | Admission / retrieval rule | Accountable package |

Duplicate IDs, clones, renamed folders | Resolve durable identity before joining. Keep ambiguous collisions separate. Exact copies may form a review group; semantic similarity alone cannot merge identities. Future retrieval limits duplicate saturation without deleting source evidence. | M2 diagnostics; Y2 identity; Y5 future policy. |

Generic, copied or marketing-like descriptions | Preserve source text and mark insufficient evidence. Future matching prioritises explicit capabilities, inputs/outputs and constraints; boilerplate removal uses a versioned text builder and retains source anchors. | M2 fixtures; Y2 quality reasons; Y5 future evidence design. |

Planned versus implemented; stale versus current | Use only source-supported lifecycle facts and their timestamps. A source declaration does not establish deployment or approval. Unknown status stays unknown; freshness and allowed-use policy remain explicit. | Y2 source authority; M3 visible states. |

Ambiguous tool/server names or dense usage hubs | No guessed links. Review exact alias mappings; cap traversal before expansion. Future graph ranking starts disabled, with contribution caps and a separate ablation before enablement. | M2 mapping proposals; Y2 resolution; Y4 bounded reads. |

Contradictory metadata, poison text or hidden records | Retain conflicting field claims with authority decisions. Parse as data; no execution. Enforce current scope and deny rules before traversal, counts and retrieval, then recheck before returning evidence. | Y2 lineage; Y4 policy; M3 safe presentation. |

Close the feedback loop: Mayank’s diagnostic pack groups unresolved classes by source owner, severity and affected references. Owners correct the authoritative source or approve an exact mapping; Yurii’s importer records the decision in a new immutable version. Track quarantine age, duplicate/ambiguity rates, missing-evidence coverage and recurring source regressions. Set review cadence and escalation ownership at G0; do not silently lower admission rules to make the dashboard green.

#### Version the decisions as well as the files

 Compute a full publication-manifest digest from environment/partition, source authority/revision/as-of/completeness metadata, sorted source hashes, immutable identity mapping digest, code build/commit, parser/schema/resolver versions and graph policy. Maintain a separate normalized fact-set digest for semantic parity; a changed file hash, evidence locator or timestamp can change the manifest without changing graph facts. Use an opaque publication UUID as the operational key; a short digest is display-only. Same inputs and decision versions produce the same normalized facts, even if a new import attempt gets a different ID. Embedding/model versions are unnecessary until engine work is authorised.

Anchor: `source-refresh`

### 10  Controlled source refresh

    Report-led · checkout unverified

  The proposed refresh acquires a pinned Skills repository and an approved Agent Hub workbook, then applies the validation and publication contracts. The button becomes available only after authorised durable execution and recovery have been proven.

**Refresh contract, prerequisites, proposed DTOs and acceptance cases**

#### G0 prerequisites

- Choose the existing approved server identity, write policy and recovery path. The proposed job record lives in the existing PostgreSQL service. Reuse a verified suitable table or implement the minimum reviewed, versioned schema change; neither a job table nor a durable worker is assumed to exist today. An approved worker and optional Redis notification may deliver work. The PoC report says SSO is absent; do not assume a browser identity or create a new authentication or queue stack.

- Register each source with a fixed authority, scope, acquisition method, permitted credential, completeness rule, freshness policy and deletion semantics. The reported workflow uses Excel for Agents and MCPs and a manually updated local clone for Skills. An Agent Hub API is not known or assumed. Knowledge Sources in the historical workbook stay outside this three-type graph scope. Verify that report in the current checkout.

- Approve the existing PostgreSQL/FalkorDB namespace, publication descriptor and unique candidate-key strategy. The registry is a logical control plane. This plan does not replace a database product or add another database service; necessary schema changes inside the existing Postgres are scoped, reviewed and versioned as implementation work.

- Agree which operators may request, cancel, retry, inspect or activate jobs, and which aggregates may be exposed to a status reader.

#### Source acquisition is controlled evidence, not execution

      The Skill adapter uses a narrowly scoped, server-managed credential to fetch only its registered repository and ref, then creates a read-only checkout pinned to the resolved immutable commit. It never runs `git pull` on a user-mutable branch. Use an isolated Git configuration and allow-listed protocol/host; disable hooks, submodule/LFS auto-fetch and external filter drivers, and bound redirects, object bytes, files and elapsed time. Enforce realpath containment before reading a checked-out file; reject symlinks escaping the import root. It does not use browser-held secrets, accept arbitrary repository URLs or refs, run `SKILL.md` content, follow embedded links or fetch referenced tools. The workbook adapter reads only its registered approved location, copies the complete file atomically into immutable job evidence, and records checksum, scope and capture timestamp. If the worker cannot return the registered file, it refuses the refresh for that source and preserves the old active publication. A source that is stale, incomplete or failed never creates a deletion by absence. Any required source that fails, is incomplete or exceeds the approved freshness limit blocks the whole candidate publication. Optional omission needs a pre-agreed versioned completeness policy and visible manifest entry; never silently combine a stale prior source with newly fetched sources.

#### Durable job semantics

      A request carries an idempotency key bound to the current principal, publication scope and canonical request hash, including the approved source set and source-configuration version. The UI and CLI submit the same contract. Within the recorded retention window, the same key and payload return the same job, including a terminal job; a different payload with that key is a conflict. An explicit retry uses a new key and creates one new job linked to its predecessor, after current eligibility and admission checks. The retry repeats the immutable predecessor request and source-configuration version, with fresh acquisition of the same registered sources. If that configuration is no longer current or authorised, reject the retry and require a new top-level refresh; never silently substitute a new configuration. PostgreSQL stores durable intent and stage evidence before acceptance; notifications only wake the worker. A transactional outbox or equivalent recoverable dispatch closes the persist-before-enqueue gap, and workers also reconcile pending durable records.

Scope ownership uses a lease, monotonically increasing fence and heartbeat in the authoritative control records. Those records and activation checks enforce the fence; a Postgres check does not transactionally fence a remote FalkorDB write. If a writer or acknowledgement is uncertain, permanently abandon its unique candidate graph key. A replacement uses a new key. Activate only after confirmed writer exit, checksum readback and sealing, followed by the existing descriptor compare-and-swap. Restart reuses verified source/stage evidence but never resumes an uncertain graph key for publication.

Check current initiating-operator permissions and approved source configuration at admission and again before activation. Revocation blocks publication; the service credential does not substitute for the operator’s authority. Retry, cancel and every status read require current policy. Apply server-side rate/admission limits to all entry points, including CLI and retries.

      Cancellation is safe only before final activation begins. It records a terminal cancellation only after future stage work is stopped and any in-flight candidate is either confirmed stopped or permanently abandoned under the publication contract; it leaves the active descriptor unchanged. A cancellation request or lost heartbeat alone is not proof that a remote write stopped. Once the final activation transaction has started, status resolves the activation outcome from the authoritative descriptor rather than claiming cancellation. Failed validation, projection, sealing or activation leaves the active publication in place. Activation remains the existing sealed-candidate and descriptor compare-and-swap flow.

#### Progress and read contract

      Progress records completed stages and actual, policy-permitted counts: copied sources, validated records, quarantines, resolved relations, sealed candidate and activation outcome. It does not invent a percentage. The read-only status operation and optional SSE stream are separately policy-gated; SSE reconnects and continued delivery revalidate policy on bounded expiry, retain only a bounded event history, and return an explicit expired cursor requiring a fresh status snapshot. They expose only approved summaries and redact sensitive source detail. The UI has explicit `unsupported`, `unavailable`, `queued`, `running`, `failed`, `cancelled` and `succeeded` states, together with current version, last successful fetch, source freshness and retry eligibility.

#### Proposed transport and DTO shape  Names illustrative; routes do not yet exist

```text
`UI → authenticated proposed refresh request
{ "scope_id": "approved-scope", "idempotency_key": "client-generated-key" }

202 Accepted → { "job_id": "opaque-id", "state": "queued", "accepted_at": "server-time" }`
```

      The request is an illustrative contract, not an existing frontend endpoint. It must be authenticated and authorised before the server creates the durable job record; process-local request background work is not accepted as the recovery mechanism for this refresh.

      Scroll table horizontally →

          Proposed refresh transport and DTOs

Proposed operation | Input / result | Required meaning |

`requestRefresh` | Authenticated `scope_id`, approved `source_ids[]`, `idempotency_key` → `job_id`, `accepted_at`, `state=queued` | Authorise and persist intent in the proposed durable PostgreSQL job record before returning `202 Accepted`. It performs no source write or publication in the HTTP request. |

`retryRefresh` | `job_id`, new `idempotency_key` → linked successor job | Reauthorise actor, scope and the pinned predecessor source configuration; reject configuration drift and require a new top-level request; check predecessor eligibility and quotas; atomically admit one linked successor per retry key. Replays return it, including its terminal outcome. |

`getRefreshStatus` | `job_id` → state, stage, timestamps, policy-permitted counters, failure category, retry/cancel eligibility | Read-only. `fetched`, `validated` and `activated` are separate booleans or stage outcomes, never one inferred success flag. |

`streamRefreshStatus` | `job_id` cursor → ordered status events | Optional SSE after policy approval. Events are replayable from durable state, contain no raw secrets or private inventory, and do not authorise writes. |

`cancelRefresh` | `job_id`, reason → acknowledged cancellation state or activation-resolution state | Uses the same authorisation and scope fence. It cannot interrupt or misreport a final activation already in progress. |

`refreshSummary` | `scope_id` → current version, last successful fetch, per-source freshness and safe retry hint | Separates the active publication from the most recent job. A failed run leaves the active version visible with its own freshness. |

#### Acceptance cases before a button or schedule

      Scroll table horizontally →

          Source refresh acceptance cases

Case | Observable result |

Unauthorised or unconfigured request | No job and no source access. The UI reports `unsupported` or `unavailable`; there is no unauthenticated refresh endpoint. |

Duplicate request | The same scoped key and payload return the same job even after completion; key reuse with a different payload is rejected. Overlapping publication scopes cannot acquire overlapping writer ownership. |

Skill or workbook capture | The job records pinned commit or atomic workbook copy, immutable checksum, scope and timestamp; no arbitrary URL/ref or skill-content execution occurs. |

Failed, stale or incomplete source | The source status is explicit, no removals are inferred, and the existing active publication remains readable under its freshness policy. |

Worker crash, lease loss or uncertain write | The candidate key is abandoned; a replacement uses a different key. No candidate becomes reader-visible before confirmed writer exit and readback sealing; only the current control owner can activate. |

Activation, cancel and recovery | Only a sealed candidate changes the descriptor. A pre-activation cancellation preserves the current version; an in-flight activation is resolved from the descriptor before the job becomes terminal. |

Status truthfulness | Progress reflects completed work and policy-permitted counts, with separate fetched/validated/activated outcomes, current version, last successful fetch, freshness and retry state. |

      Technical basis: FastAPI background-task guidance (https://fastapi.tiangolo.com/tutorial/background-tasks/#caveat) distinguishes simple in-process work from heavier worker execution. The durable-job protocol here is an architectural requirement, not a claim that BackgroundTasks provides it. GitHub installation authentication (https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/about-authentication-with-a-github-app) is one automation option if approved; use the bank-approved credential mechanism rather than prescribing a new integration.

#### Accountability and rollout order

      Yurii owns the shared authorisation, job, publication and recovery contracts. Mayank owns the source adapters and status UI against those contracts. Prove the authorised button path and its recovery cases first; only then propose a schedule that invokes the same job runner and policy checks.

Anchor: `publication`

### 11  Safe publication, retirement and rollback

Core correctness contract

Build the candidate out of sight, verify it, then switch one Postgres descriptor. Current policy continues to apply after rollback.

**Technical contract, decisions and supporting evidence**

 The atomic boundary is what readers can discover. Postgres and FalkorDB do not share an assumed transaction. First make a complete graph available under an invisible candidate key; then switch one Postgres descriptor that contains both the catalogue and graph identity.

 Captured→Validated→Projected→Sealed→Active→Retained→Retiring→Reclaimed

 Only Retained may be reserved for a guarded rollback to Active. Retiring is irreversible; it cannot become a rollback target.

- One controlled import per scope. A durable job ID, expected active publication and exclusive worker ownership prevent overlapping writers. Every attempt gets its own candidate graph key. Use a supervised single builder; loss of ownership makes that attempt permanently ineligible for publication. A replacement gets a different key. A lease flag alone is not a write fence.
- Build endpoints before relationships. Insert/merge nodes by immutable ID, then match existing endpoints and write deduplicated relationships. Never merge an entire path with mutable properties. Validate distinct identities, allowed labels/types, scopes and exact graph/catalogue fact-set equality.
- Seal the candidate. Complete all writes and retries, close the graph write session and require confirmed builder termination. A separate publisher verifies the candidate and persists the sorted fact-set checksum before sealing. Unknown worker liveness or write outcome means abandon the candidate; it must never be sealed or reused by a replacement. Published keys are never assigned to a builder. A delayed old write can then affect only its abandoned key, not active data.
- Activate with a compare-and-swap. In a short Postgres transaction lock the scope’s descriptor row; verify the expected base still matches, candidate is sealed, its collection versions do not regress and policy approval is current; atomically advance the current component/relation validity overlay, replace the descriptor and record the audit event. A competing publication must rebase and revalidate its diff rather than overwrite a newer active one.
- Pin every request. Read the descriptor once from the authoritative Postgres primary and use its catalogue ID and graph key throughout that request and, where pagination is used, its cursor. Never mix an active catalogue lookup with a graph selected from a mutable “current” alias.
- Retire and reclaim deliberately. A removed fact is absent from the new graph, while the prior graph is retained temporarily for bounded in-flight reads and rollback. Cleanup acts only on owned, inactive keys after retention and reader/cursor expiry. Activation, rollback and cleanup lock the same scope descriptor. Cleanup first marks its target `retiring` transactionally; activation/rollback reject retiring targets. It may then drop only that owned graph key and mark it reclaimed. A failed drop stays retiring and is retried idempotently. No deletion against the native Hub graph.

 Readers and cleanup cannot race. Give every request a hard total deadline. A cursor for an old publication cannot extend that publication’s fixed expiry; new historical reads are rejected after its allowed window. Reclaim only after the last possible cursor start time plus the maximum request deadline and a defined clock margin, or after a verified equivalent read-lease mechanism. A rollback target is reserved under the same lock before integrity verification, and cleanup skips that reservation. Abandoned graphs are not reclaimed until their builder and outstanding server writes are proven finished; otherwise fence that writer through the platform’s supported controls before cleanup.

#### What the seal verifies

 Define one versioned projection schema and property allow-list. Canonical node tuples contain `(component_id, kind, safe_label, graph_status, evidence_ref)`; relation tuples contain `(relation_key, kind, source_id, target_id, qualifier, evidence_set_digest)`. Compare the exact stored approved strings; do not apply search normalisation. Distinguish null from empty. Prefix each tuple with its node/edge kind. Serialize fixed-order string-or-null arrays as UTF-8 JSON with no whitespace, raw Unicode except required JSON escapes, and one defined control-character escaping rule. Sort the encoded tuples lexicographically by bytes and hash the newline-delimited representation with SHA-256. The projection-schema version freezes this serializer and the relation-key recipe. Reject duplicate tuples, unknown labels/properties, invalid qualifiers and wrong publication stamps.

 Postgres computes the expected tuples from immutable snapshots; after acknowledged writes and confirmed builder exit, the publisher reads back all candidate tuples through a read-only connection. The seal stores projection-schema version, expected/observed full digest and node/edge/per-kind counts. Property and evidence-reference changes must change that digest. A process-local “completed” flag or matching counts alone cannot seal a graph.

 FalkorDB documents that full-path MERGE can create unintended duplicate endpoints; binding endpoints separately avoids that construction error. Its query “version” argument is for schema-cache coordination, not this application publication ID. MERGE reference (https://docs.falkordb.com/cypher/merge) · query reference (https://docs.falkordb.com/commands/graph.query). The descriptor lock uses the existing Postgres transaction layer; verify the deployed version and driver before implementation. Postgres locking reference (https://www.postgresql.org/docs/current/explicit-locking.html).

 Scroll table horizontally →

Safe publication, retirement and rollback — table 1
Failure point | Required result |

Projection crashes or times out | Active descriptor unchanged; partial candidate invisible. A known rejected operation may retry while the builder remains owned. An uncertain write or worker state abandons that key permanently; rebuild under a new attempt. |

Graph written; activation fails | Candidate remains inactive and can be verified/retried. No request discovers it through ordinary APIs. |

Activation succeeded; acknowledgement lost | Read the descriptor by job/publication ID. Treat activation as idempotent; never flip it again blindly. |

Graph unavailable after activation | Return typed unavailable; show last known publication metadata. Never label an empty graph as a successful response. |

Rollback requested | Reserve a retained, non-retiring target under the scope lock; revalidate its integrity, freshness, schema and current access/revocation policy; then reacquire the lock, check the expected active pointer and reservation, repoint it and audit the reason. Clear abandoned reservations through the supervised operator path. Never revive a revoked record through rollback. |

Cursor references reclaimed graph | Return an expired-snapshot response and require a fresh request. Do not splice remaining pages from the active graph. |

Anchor: `read-contract`

### 12  API, explorer and truthful user states

One request pins one publication. Bounded queries return provenance and explicit freshness, completeness and error states.

**Technical contract, decisions and supporting evidence**

 Expose a narrow internal read service for component browsing and bounded neighbourhood queries. G0 selects a thin extension of the current registry/graph UI, or an operator walkthrough using bounded queries and an accessible list. A new graph canvas/library is not required. Proposed routes below are contracts to map onto the workstation’s existing routers at G0, not claims that these endpoints already exist.

 Scroll table horizontally →

API, explorer and truthful user states — table 1
Surface | Contract |

`GET /api/components` | Authorised type/status filters and paginated identities; stable sort by kind/name/ID. Scope is server-derived. |

`GET /api/components/{id}` | Snapshot fields, evidence summaries, quality reasons and binding status; no raw import payload by default. |

`GET /api/components/{id}/graph` | Allowed edge types and bounded depth, nodes/edges, publication, truncation and provenance. No user-supplied Cypher. |

`GET /api/components/status` | Active publication and freshness. Detailed quarantines/import counts require operator permission and never leak other scopes. |

Operator import/publish command | Existing authenticated operational mechanism with dry-run, exact scope, immutable input manifest and job ID. No anonymous upload or public mutation route. |

 Every successful response contains `publication_id`, `sources[]` with per-authority revision/as-of/completeness/freshness, overall `freshness`, `completeness` and `truncated`. Overall freshness follows the strictest required-source policy; any displayed aggregate as-of is explicitly the oldest required source. Errors use a typed envelope and only include last-known metadata when authorised. Where pagination is needed, a signed cursor pins publication, filters and caller authorisation context, has an expiry and is reauthorised on each use. Use current entitlement checks even when reading historical publications.

#### Explorer content

Select an Agent, Skill or MCP. Show directly declared relationships, then optional expansion to two hops. A side panel explains the selected edge, source and resolution method. The list/table view exposes the same information and is usable by keyboard and screen reader.

#### Small, bounded graph queries

Initial proposed ceilings: depth 2, 100 returned nodes, 200 returned edges, 50 list rows per page and a 2-second server query deadline within a 5-second total read deadline. Bound expansion at each hop, not only after a global traversal. Show truncation and let users narrow filters. Validate these budgets on representative data at G3.

 Scroll table horizontally →

API, explorer and truthful user states — table 2
User state | Meaning and behaviour |

Ready | A valid publication was read. “No declared relationships” means a successful scoped query returned none; it never means “no suitable component”. |

Ready · incomplete evidence | Known unresolved references are disclosed without inventing edges or exposing hidden target names. Completeness is about the admitted source set. |

Stale | Last valid publication remains readable only within the agreed freshness policy. Show age and last failed refresh separately. |

Unavailable | Graph/query dependency failed. No empty-success response. A source-file diagnostic view, if retained, is separately labelled and never substitutes for the published graph. |

Absent or inaccessible | Use the Hub’s non-enumerating object-access behaviour. Do not reveal whether an inaccessible identity exists. |

Expired publication / disabled | Restart browsing against the active version, or show feature-disabled state. No engine work is triggered as a fallback. |

#### Response envelope

 Successful data responses use `{status: "ok", publication, metadata, data, cursor?}`. Failures use `{status: "error", code, retryable, diagnostic_publication?}` with no graph data or cursor. Staleness within policy, incomplete source evidence and truncation are orthogonal metadata on success; stale beyond the cutoff is an error. Align exact HTTP conventions with the existing Hub contract at G0.

 Scroll table horizontally →

API, explorer and truthful user states — table 3
Code / proposed HTTP | Data and recovery |

`ok` · 200 | Pinned authorised data; optional cursor only within its fixed publication expiry. |

`absent_or_inaccessible` · 404 | No object-existence disclosure; no automatic cross-scope fallback. |

`snapshot_expired` · 410 | Discard cursor and restart against the active publication. |

`policy_changed` · 409 | One in-budget reauthorised retry, otherwise ask the caller to restart. |

`deadline_exceeded` · 504 | Retry only within the caller’s budget, preferably with narrower filters. |

`dependency_unavailable` · 503 | Retry with bounded backoff; authorised last-known publication metadata is diagnostic only. |

`disabled` / `stale_expired` · 503 | Distinct typed reasons; no automatic retry until feature/data status changes. |

`invalid_request` · 400; `busy` · 429 | Correct invalid filters, or retry overload according to the bounded retry hint. |

Anchor: `operations`

### 13  Operations and compatibility

Coordinate refresh, model budgets and release state across the existing services. Every enabled capability has a measured operating envelope and a recovery owner.

**Technical contract, decisions and supporting evidence**

 Yurii owns the service and publication lifecycle; Mayank owns source diagnostics and the operator evidence pack. Keep ingestion a controlled job through the existing deployment/operations mechanism. Adopt an existing durable job facility if present; otherwise a supervised explicit import command is sufficient for this phase. Do not add a queue solely for the architecture.

 Scroll table horizontally →

Operations and compatibility — table 1
Control | Implementation requirement |

Schema and rollout | Reconcile existing asyncpg/raw-SQL patterns before writing DDL; no assumed Alembic/SQLAlchemy. Add backward-compatible schema first, deploy reader support with graph disabled, build a candidate, validate, enable an agreed scope, then observe. An existing engine flag is not the graph rollout flag. |

Health and error handling | Separate graph transport/query failure from an authoritative empty result. Return typed errors from the adapter; do not trust a helper that swallows exceptions. A ping alone does not prove the requested query completed. |

Monitoring | Log job/publication IDs, source contract version, elapsed phases, counts by reason, checksum outcome and activation/rollback events. Observe failed imports, active age, unresolved rate, graph query latency/errors, truncation and capacity. |

Freshness and alerting | Choose import cadence, maximum readable age, owner and escalation channel at G0. These are release settings, not hidden defaults. A refresh failure keeps the prior publication and emits a visible operational failure; it never resets the source timestamp. |

Capacity and cleanup | Budget for active + retained rollback + one candidate graph at minimum. Size on the actual source corpus. Bound candidate age, retained generations, cursor lifetime and job retries before rollout. Stop new imports rather than evict active data on pressure. |

Recovery | Retain manifests and catalogue snapshots under the approved retention policy; rebuild a graph from them and prove its digest before activation. Retention/cleanup respects legal deletion and current revocation even for inactive copies. |

Legacy compatibility | Verify native graph keys and any wildcard/admin readers, graph/index privileges and startup hooks. Do not touch existing vector indexes or graph scoring. Run the current Hub regression CI on the actual branch. |

 Activation and rollback acquire the scope descriptor lock and publication locks in a fixed order. Cleanup’s `retiring` state is irreversible: new requests, pins, activations and rollbacks reject it even if deletion fails. The current validity/security overlay is updated in Postgres and is never rolled back with the graph descriptor.

 Feature disablement stops new graph reads and imports; it does not erase data. Rollback of reader code must remain compatible with retained schema, or the graph feature stays disabled until the matching version is restored. Destructive schema cleanup is a separate change after the rollback window.

#### AI execution and release contracts

AI operational boundaries
Boundary | Required behaviour | Evidence / disposition |
Distributed work and admission | Use authoritative durable job state for polling from any replica. Admission, fairness and gateway reservations must cover all replicas and every retry. Define bounded pending-job age, ownership, heartbeat, lease expiry and takeover. Redis may support coordination only with its actual durability/failure behaviour understood. | Verify current infrastructure first; reuse the approved worker model. Single-replica demos are not evidence of multi-replica safety. |
Model calls and fallback | Resolve model/provider/revision, prompt/schema, decoding and limits through approved server configuration. Authentication or invalid-request errors fail explicitly; retry only classified transient failures within the common deadline and cost reservation. A fallback uses an approved, evaluated configuration, records the switch and cannot reset budgets. | Hub budgets are agreed from the baseline; the separate component-engine experiment retains its four-total-attempt proposal. Record actual attempts, cancellations and provider truncation. |
Field-aware embeddings and indexes | Use field-aware text builders with versioned normalisation. Persist model/revision/dimension, builder hash and exact content hash. Re-embed changed content or changed representation; build a candidate generation, validate, shadow, switch, retain and prune under the existing publication discipline. | Confirm deployed FalkorDB update/index behaviour and Gateway quotas. Do not drop an active serving index for a backfill. Component catalogue and native Hub generations remain distinct unless an explicit shared publication contract exists. |
Fusion, graph expansion and diversity | Bound every retrieval channel, hop, candidate hydration and rerank. Compare weighted fusion versus RRF before adoption. Deduplicate canonical identities before scoring; measure result diversity separately. Limit SIMILAR_TO maintenance/degree and verify its exact current semantics. | No automatic graph boost or cross-encoder. Approve availability first and retain only a measured gain on the applicable task. Inferred similarity does not become a source-declared component edge. |
Safe observability | Emit request/run IDs, stage/status, approved intent category, duration, count, cost and configuration IDs. Keep raw requests, prompts, source excerpts, auth headers, credentials and sensitive high-cardinality labels out of ordinary logs. Protect any essential evidence store with current access, retention and deletion rules. | Review existing search-session, admin-log and telemetry routes; category-only intent telemetry does not itself remove older raw-query storage. Models may classify intent only as bounded metadata, never as an authorisation decision. |
Promotion and rollback | Keep a versioned release configuration tying schema, policy, model, prompt, index and evidence builders to compatible data generations. Shadow must not change user answers or perform business writes; authorise and budget shadow runs too. Promote a controlled cohort after offline and operational gates, then monitor agreed rollback triggers. | Avoid dual unbounded model spend. Rollback preserves current deny/deletion policy and checks release/data compatibility. Do not retire the incumbent path before parity and rollback are demonstrated. |
CI and operating ownership | Require schema/contract, integration, security, content, evaluation and capacity evidence appropriate to the change, with immutable build/run references. Assign an operator to every freshness/latency/cost alert, pending-job age breach and review backlog. | No test, benchmark or deployment success is claimed by this document. Verify the actual HSBC CI and approved runtime/dependencies. |

#### Disposition of the remaining earlier proposals

Earlier programme disposition
Earlier proposal | Current treatment |
Contributor schema and source quality | Included in ingestion contracts: versioned fields, alias policy, size/path/schema checks, source authority, quarantine and source-owner correction. Adding a consumer guard does not prove marketplace CI has been fixed; upstream enforcement has its own owner. |
Human review and calibrated confidence | Included in the decision contract. Review ownership, queue age, override reason and evidence are explicit. Hide unsupported probabilities; confidence calibration requires held-out evidence. |
Runtime and developer hardening | Keep dependency/image pinning, non-root runtime, secret injection, endpoint exposure review, linting and OpenAPI-to-TypeScript freshness in the operating backlog. Confirm actual runtime versions rather than inheriting the historical Python 3.12 suggestion blindly. |
Per-PR preview environments | A useful separate platform workstream with approved data, credentials, namespace, DNS/TLS, quota and teardown. It is not a prerequisite for the graph/AI architecture, and does not authorise new infrastructure here. |
AIRCO prefill, notifications and new recommendation interfaces | Separate product features; require their own UX, privacy, policy and implementation scope. The shared contracts make later consumers possible without implementing them now. |
PydanticAI, workflow frameworks, another vector database | No framework or store migration in this programme. Use typed services and approved existing components. A new package is considered only for a demonstrated missing capability and a separate decision. |

Source: earlier improvement backlog. The current plan retains its contract, evaluation, evidence and operating principles while replacing the database-comparison work with qualification of the existing stack.

Anchor: `security`

### 14  Access, privacy and untrusted content

Authorisation applies before expansion and again before output. Historical snapshots and cached results cannot bypass current revocations.

**Technical contract, decisions and supporting evidence**

 Existing authentication is a dependency to integrate and verify. It is not evidence that new graph reads, historical snapshots, administrative counts or future caches are correctly scoped. Keep publication scope (a stable environment/data partition) separate from request authorisation (current principal entitlements). Obtain both from server-side policy, never from the caller’s chosen tenant or graph key. A visibility change does not mint a new component identity.

 First access shape: one approved PPD review cohort with visibility over the entire admitted publication. Restrict the read service to that cohort. Apply current component and relationship deny IDs inside every traversal predicate, including intermediate nodes, before expansion/counting/truncation. Load the current deny set from the authoritative policy layer; inability to load or enforce it fails closed. Broader per-user visibility requires a verified policy-aware traversal implementation before exposing this graph outside the cohort. Do not simulate access control by post-filtering results.

- Filter authorised identities and relationships before traversal and aggregation. Both endpoints and any intermediate node must be visible to the caller. A hidden node must not leak through counts, degrees, labels, suggestions or timing-sensitive diagnostics.
- Keep all graph queries in allow-listed, parameterised templates. Validate types, depth, limits and opaque IDs. Select graph keys from the server-owned publication descriptor, never a request parameter.
- Separate importer, publisher and reader capabilities using the existing service-account model. Limit writes to owned component namespaces. Administrative diagnostics and source downloads require separate access.
- Apply current revocations, tombstones and entitlement changes to every active, retained and cached read. Maintain a current deny policy that can take effect before a full refresh; if it cannot be loaded, fail closed. Rollback must respect it.
- Exclude employee/contributor IDs, credentials and internal connection strings from graph properties, public reports and ordinary logs. Retain only approved display text and evidence locators; source content remains in controlled storage.
- Source descriptions, SKILL.md and tool metadata are untrusted text. Sanitize rendered markdown/HTML, allow-list link schemes and escape labels. Parsing never executes content or fetches referenced URLs.

 Distinguish ordinary source retirement from a security/legal revocation. A normal removed declaration disappears from the new publication. Its current-validity overlay also prevents it being presented as current through a retained graph or technical rollback; restricted historical evidence can still describe what was previously declared. Reinstatement needs a newer authoritative source and a reviewed correction. Technical rollback restores service data, not source validity or permissions. A revoked identity, relation key or evidence source is denied immediately across every retained view, binding, generated report and future cache, and later purged under policy. The deny decision must use stable keys so a new publication or rollback cannot reset it. Pin the policy generation for query predicates and check the principal, component IDs, relation keys and evidence locators against the current generation again before serialization. If it changed, discard and retry once within the read budget, or return `policy_changed`. The guarantee is authorisation at this final decision point; already delivered data cannot be retracted. Future jobs repeat this check for card/evidence access before persisting and on every result fetch.

#### Future input and result retention

 The first future engine should accept authorised card IDs only, with immutable, re-readable card versions. Use source locators/offsets and a scoped keyed digest for deduplication. Stored quotes and rationale can also reproduce sensitive input. Free text is deferred until its retention model is agreed: either encrypt the input for the auditable result lifetime and cascade deletion through results/evidence/cache, or return an ephemeral result whose need-side evidence expires with its input. Do not promise durable evidence revalidation after deleting its only source.

 Future model requests use the approved gateway and data policy. Logs and traces contain reason codes, timings and version IDs, not raw prompts, generated excerpts or provider credentials. Retention durations, audit access and deletion coverage must be set before shared rollout; this document does not invent an enterprise retention policy.

Anchor: `engine`

### 15  How recommendations would work

Design only

Design only. Start from an authorised need, assess a bounded candidate set, verify evidence and return a truthful result.

**Technical contract, decisions and supporting evidence**

 The graph supplies evidence and candidate context; it does not decide fit. The future engine reuses one authorised, pinned catalogue. Start with a measurable lexical baseline; add embeddings, graph signals and model assessment only when each improves held-out evaluation. No part of this pipeline is a graph-phase implementation deliverable.

  1

#### Capture the need

Authorise a card ID (free text is a later extension), pin its source version and choose requested component types. Preserve explicit needs and constraints. A model may propose a controlled need profile, but inferred items are labelled as inference and never serve as proof that the user requested a capability.

  2

#### Retrieve eligible candidates

Apply scope, current policy, supported version and evidence-readiness filters first. Use deterministic lexical retrieval as baseline. Later combine lexical and semantic ranks with versioned reciprocal-rank fusion and stable ID ties. Record retrieval channels and candidate truncation. Graph co-occurrence starts disabled and must beat the baseline in an ablation.

  3

#### Assess each candidate

Bind an opaque candidate token to exactly one registry identity. The initial proposal uses one bounded assessment batch per requested type, with a separate structured result for every candidate. The model sees bounded source excerpts, explicit requirements and constraints, with no tools. Validate duplicate/missing candidate responses and treat failures as unassessed coverage. Return fit `strong | partial | none | insufficient_evidence`, supporting citations, contradictions, missing prerequisites and uncertainty. Never invent a component or change its identity.

  4

#### Verify and apply deterministic policy

Check schema, candidate membership and citation ranges against immutable original input/source versions. Normalisation must retain an offset map to the original text. A quote’s existence does not prove semantic support. Reject unsupported claims; separate required-dependency/permission failures from match strength. Human-labelled evaluation measures entailment and suitability.

  5

#### Rank and explain

Prefer deterministic ordering by policy-eligible assessed fit class, unmet requirements, retrieval rank and stable ID. Calibrate inclusion criteria on grouped development/validation cases per component type; keep the final test set untouched. Do not reuse per-query min/max scores or present rank as probability. Start with templated explanations; optional synthesis may later paraphrase verified facts but cannot add/drop identities, change policy or introduce new claims.

  6

#### Return a truthful outcome

Return candidates, source-linked reasons, prerequisites, coverage and version lineage. `complete` can contain zero results only when the required retrieval/assessment work completed for the declared shortlist. Distinguish `no_eligible_candidates` from `no_verified_match_in_assessed_set`; neither claims an exhaustive judgement of the catalogue. `partial`, `failed`, `disabled` and `cancelled` are separate states. The user reviews suggestions; no component is automatically installed, attached or executed.

#### Minimum future contracts

 Scroll table horizontally →

How recommendations would work — table 1
Contract | Required fields and limits |
Need profile | Authorised card/version; requested types; explicit must-have, optional and excluded requirements; data/actions/integrations; controlled vocabulary version; original-input anchors. Unknown requirements stay unknown. |
Compatibility evidence | Source-backed inputs/outputs, supported component/client versions, declared read/write actions, required connection/authentication profile and execution permissions where known. Missing metadata is not evidence of compatibility. Credentials and connection strings never enter the prompt. |
Assessment | Candidate token, per-requirement fit, supporting/contradicting anchors, prerequisite states and uncertainty; assessment_origin and semantic_support=unreviewed|adjudicated. Shape, membership and quote checks establish valid attribution, not human-verified suitability. Visibility permission is mandatory before assessment; unknown execution permission can only produce a conditional, non-actionable candidate. |
Result | Principal-owned run ID; pinned card/catalogue/policy versions; execution mode; completion state; per-type eligible, retrieved, planned, assessed, rejected and unassessed counts (authorised counts only); truncation; attempts/tokens/cost; evidence references. Keep policy-eligible assessed suggestions separate from conditional candidates and insufficient-evidence results. |

 All returned IDs must belong to the authorised candidate set. Known forbidden or unsupported components are excluded; unresolved mandatory prerequisites prevent an actionable suggestion. A lexical-only baseline returns labelled retrieval candidates, not model-assessed recommendations. Assessment completion is measured against the frozen shortlist, with upstream truncation disclosed.

#### Graph signals and bundles

 A declared Agent→MCP edge says “this configuration uses it”, not “this is the best server”. Popularity, duplicated agents and sparse skill metadata bias co-occurrence. If evaluated later, cap per-agent contributions, deduplicate equivalent configurations, normalise by prevalence and prevent evaluation leakage from the exact relationships used to label test cases. A required dependency must be authorised and compatible; unresolved mandatory prerequisites make a component non-actionable. Optional or unknown requirements are shown explicitly. Do not optimise multi-component bundles until single-component precision and prerequisite reporting work.

#### Bound the complete request

 Proposed first experiment: up to 8 candidates per requested type, one optional need-profile call and one structured assessment batch per type. Cap the entire run at 4 model attempts including retries, with at most 3 concurrent assessment calls and no synthesis. Pre-plan and reserve one initial batch attempt per requested type. Residual attempts fund the optional profile first, then at most a bounded retry if any remain; a retry cannot consume another type’s initial reservation. Three types plus a profile leave no retry slot. A retry never increases the ceiling. Separate per-candidate calls remain an experimental alternative only if held-out evidence justifies their cost, with a smaller candidate set under the same total budget. Use one 120-second end-to-end deadline, per-call caps within the remaining deadline, a hard token/cost budget, input/excerpt limits and cancellation. Count tokens before dispatch, reserve bounded structured-output capacity per candidate and refuse oversized requests. Deterministic excerpt selection records every omission; if required evidence does not fit, mark that candidate unassessed or insufficient-evidence rather than silently claiming a full assessment. Pack candidates in stable retrieval order with a versioned excerpt builder and a per-candidate minimum evidence allowance. Any candidate that cannot fit remains explicitly unassessed and makes the run partial. A provider-truncated batch is partial/failed; do not keep a prefix as a complete batch. Select one fully validated authoritative attempt per batch; never stitch responses from attempts with different candidate context. These are proposed starting limits to validate with the approved model, not latency promises. An exhausted budget yields partial/failed, never complete-empty.

 Apply service-wide and per-principal admission limits, bounded waiting and token/cost reservations through the existing gateway or job service, including all replicas. Per-request concurrency alone cannot cap aggregate spend. Reject excess work with a typed busy outcome. Async jobs need durable state, ownership/heartbeat, idempotency and restart recovery; a process-local background task is not the job store.

Cache only schema- and evidence-validated assessments, scoped to the current access policy. Set TTL, maximum size, encryption and deletion handling before enablement. The key includes a keyed input digest, source/card version, component content hash, catalogue/resolver/schema versions, requested constraints, prompt version, model/provider/revision, decoding settings and assessment-policy version. Also hash the exact ordered serialized assessment input: explicit/inferred need-profile claims, card/source versions, excerpt hashes and builder version, candidate tokens and output schema. For a batch, cache the validated batch as a unit and include the full ordered candidate/content-hash set; a candidate-only key is insufficient because other candidates influence the assessment. Default to per-principal caching unless an identical authorised policy context is proven. Reauthorise every cache hit. Do not cache transient failures as negative recommendations. Embeddings, if added, need model ID, dimension, text-builder version and exact content hash; never assume that all deployed models use 3,072 dimensions.

#### Delivery interfaces

 One service owns recommendation semantics. A future portal route and optional Hub MCP adapter may consume it; neither duplicates ranking or bypasses authorisation. Recommending MCP servers is distinct from exposing a Hub MCP server. Live, replay and disabled modes must remain visibly distinct; replay validates contracts, not live quality. Persist explicit run lineage and enforce idempotent submission and scoped job ownership before exposing an asynchronous API.

 Example for Joseph — illustrative, not catalogue evidence. An authorised card needs to extract invoice fields and read a document store. Lexical retrieval finds candidate Skills and MCP servers. A server’s exact source description supports read access, but the required permission is unknown: show a conditional fit with that prerequisite. A source that only mentions invoice storage cannot be claimed to extract invoice fields. A graph edge to a popular Agent does not override the missing evidence.

Anchor: `evaluation`

### 16  Component recommendation evaluation

This contract evaluates the later component recommender. Hub novelty and completeness have separate labels and gates in architecture validation (#validation-gates).

**Technical contract, decisions and supporting evidence**

#### Graph acceptance now

Verify source accounting, deterministic identity, exact edge evidence, publication integrity, access isolation, stale/unavailable behaviour, rollback and legacy compatibility. Use genuine source fixtures with known defects plus constructed failure scenarios. A working graph does not establish recommendation quality.

#### Recommendation evaluation later

Create an adjudicated labelled set with domain reviewers. Cover positives for each type, hard negatives, legitimate empty needs, permissions, ambiguous input, required dependencies, duplicates and noisy descriptions. Group related cards/agents to prevent train/test leakage.

 Scroll table horizontally →

Evidence before a quality claim — table 1
Measure | Definition and denominator |

Execution coverage | Successfully completed assessable cases / all valid planned cases. Failed, disabled, cancelled, missing-source and skipped cases are reported separately. No metric silently shrinks its planned denominator. |

Precision / recall | Adjudicated relevant returned IDs divided by judged returned IDs, with per-type and macro summaries. Unjudged outputs are reported separately and block an acceptance claim until adjudicated; recall is reported only against a sufficiently complete relevant pool. Zero returned items has undefined precision, while positive-case recall is zero. Report case coverage and result count alongside the metric. |

Empty-control false positives | Completed empty-control cases with an impermissible suggestion / completed eligible empty controls. Also show completion coverage out of all planned empty controls. Failures do not count as correct empty answers. |

Forbidden hits | Any inaccessible, revoked, wrong-environment, unsupported or fabricated ID is a blocking safety failure. Report absolute counts and covered scenarios, not only averages. |

Evidence and prerequisites | Citation validity, human-judged semantic support, contradiction handling and required-dependency completeness, each with a stated adjudicated denominator. |

Stability and sensitivity | Repeat successful runs under frozen versions. Compare top-k sets/order; separately test meaningful input changes and batch composition/order sensitivity. Failed/disabled runs are unmeasured, not perfectly stable. |

Operational cost | End-to-end latency distribution, model attempts/tokens/cost, cache hit rate, partial/timeout rate and cancellation. Split cold/warm cache and component type. |

 Compare lexical baseline, lexical+vector, then optional graph signals and model assessment on the same frozen held-out set. Report uncertainty and class coverage; do not promote on a small aggregate that hides weak MCP or Skill results. Build a blinded judgement pool from all compared methods’ candidates plus domain-expert nominations, labelled relevant / partially relevant / not relevant / unjudged. Define partial-credit policy before scoring. Use grouped development, validation and final test partitions. Tune prompts, thresholds and policy on development/validation only. Freeze pooled labels and tuning choices before one final held-out test; changes prompted by that test make the result exploratory and require a new held-out set for an acceptance claim. unjudged outputs cannot silently count as irrelevant or disappear from coverage. Human reviewers settle disputed labels before scoring. Usage co-occurrence is evidence for constructing cases, not ground-truth suitability by itself.

 Engine-build gate: Joseph agrees the scope and presentation; the domain owner agrees labels and per-type acceptance targets; access/privacy and cost budgets are concrete; authorised model access is verified. The earlier PoC targets (precision@5 ≥0.6, empty FPR ≤0.2, stability ≥0.8) were proposals, not achieved or production-approved thresholds. The prior attempted evaluation produced no valid quality measurements for its 16 planned cases. This is missing evaluation coverage, not a measured quality score.

Anchor: `delivery`

### 17  Implementation sequence

Yurii owns the shared contracts, graph lifecycle and AI core. Mayank owns source adapters, status/review interfaces and diagnostic evidence.

**Detailed responsibilities, dependencies and completion criteria**

 Scroll table horizontally →

Two people, explicit ownership — table 1
Package / owner | Owned deliverable and evidence | Depends on |

Y1 · Contracts & identity | Current-code reconciliation, scope/auth contract, stable ID/alias rules, graph schema decision, publication DTO and CI fixtures for collisions/renames. | M1 evidence; platform/data decisions |

Y2 · Catalogue & resolution | Versioned records, source precedence, resolution engine, typed references, authoritative removal rules, manifests and deterministic output verification. | Y1; M2 source adapters |

Y3 · Projection & lifecycle | Candidate graph writer, endpoint-safe edges, seals/checksums, activation ownership/CAS, rollback/recovery and bounded cleanup; failure-injection CI. | Y2; G1; D1 |

Y4 · Authorised read service | Authorised read service for the chosen thin surface, current revocation policy, bounded queries, pinned snapshots and unavailable/error contracts. Reuse existing APIs; add pagination/cursors only where needed. | D4; Y1 DTO; Y3 integration |

Y5 · Integration & architecture handoff | Legacy regression evidence, deployment/rollback runbook, engine/evaluation specification, technical presentation and final delivery gate. | Y3/Y4; M3/M4; D5 |

M1 · Source & Hub reconnaissance | Current source manifest, exact sheets/headers, graph keys/legacy query boundaries, permissions and BPC-specific onboarding notes; raise unresolved identity decisions. | Access to current workstation |

M2 · Adapters & diagnostics | Source-specific parsers/normalisers behind Y1 interfaces, real export fixtures, duplicate/unresolved reports and reviewable mapping proposals; no independent canonical-ID policy. | M1; Y1 |

M3 · Read-only evidence surface | Thin reuse of current registry/graph view, or accessible generated list + bounded-query walkthrough; provenance, quality and error states. No new graph-canvas framework. Remaining effort funds source trace/diagnostic coverage if UI reuse is unavailable. | Y1 DTO for mocks; Y4 for integration |

M4 · Acceptance pack & demonstration | Source-to-graph trace samples, CI/rehearsal evidence, operator diagnostics guide and graph demonstration; verify source freshness and link semantics. | M2/M3; Y3/Y4 |

 Yurii owns shared identity, publication, API contracts and lifecycle code. Mayank owns source adapters, diagnostic presentation and the chosen read-only evidence surface. Both review changes across their interface; the package owner implements the feedback. Exact repository paths are recorded after M1/Y1. Do not invent new module locations until the current architecture and PoC have been inspected.

 External inputs are explicit: M1 gathers workstation/source evidence; platform/data owners resolve D1–D4 and D6; Y1 records the contract. Y3 requires the D1 namespace/capacity decision. Y4 requires the D4 policy hook. Y5 requires D5 operational settings. Owner decisions are external dependencies. M3 prepares the evidence-view contract after Y1, then integrates after Y4.

#### Work in dependency order

- G0 — reconcile and decide. M1 gathers source/Hub evidence; platform/data owners make the required decisions; Y1 records the accepted positions and locks the contracts. Freeze an authorised source set and record the existing branch/commit.
- G1 — trustworthy catalogue. M2 adapters and Y2 resolution run against the same fixtures. M3 can build UI states from frozen DTOs. Review duplicate handling, removals and all unresolved classes before graph writes.
- G2 — sealed graph and safe reads. Y3 projection and Y4 reads integrate; M3 connects the selected evidence surface. Demonstrate a source removal, an interrupted import and a forbidden cross-scope request.
- G3 — controlled rollout. Y5 and M4 assemble CI, capacity, freshness and rollback evidence. Enable one agreed scope after platform approval and observe its first refresh.
- G4 — Joseph walkthrough. Mayank demonstrates graph facts and provenance; Yurii presents the engine stages, evaluation and remaining decisions. Agree the next implementation scope separately.

 Dmytro’s CxO work is a dependency boundary, not a third share of this plan. It does not block a graph using an approved static export unless that export’s authority or permission depends on his pipeline.

#### Expanded implementation slices

The earlier package table covers the graph baseline. The following slices add controlled refresh and existing-Hub AI hardening; estimates are reworked after current-code reconciliation. They are not silently absorbed into the old graph estimate. No new database or recommendation-engine build is required by these slices.

Additional AI and refresh responsibilities
Slice | Yurii | Mayank | Dependency / done when |
Validate architecture | Own hypotheses, fault semantics, graph oracle and feasibility decisions. | Gather approved source fixtures, replay inputs and current PoC evidence. | V0–V2; unresolved facts remain visible. |
Controlled refresh | Provide authorised durable jobs, admission, fencing and safe publisher integration. | Implement pinned Git / approved-workbook acquisition adapters and refresh/status UI against agreed contracts. | Source and write access confirmed; repeated, failed and cancelled runs preserve correct publication. |
Typed AI baseline | Wrap existing paths with request/hit/evidence contracts and a BaselineObservation replay adapter; authoritative TaskDecision stays separate. | Build report/comparison views and collect representative cases with domain reviewers. | V3; observed behaviour is preserved and failures become measurable. |
Evidence and decision hardening | Implement versioned evidence policy, bounded retrieval, task-specific deterministic decision and candidate changes one at a time. | Implement explicit missing-input/review/error states and adjudication diagnostics. | V4; domain owner fixes labels and risk limits. |
Measured release | Own gateway/admission budgets, compatibility, shadow/canary and rollback controls. | Assemble CI/benchmark/source traces, operator walkthrough and acceptance evidence. | V5; promote only the evaluated configuration; future component engine remains separately gated. |

Anchor: `acceptance`

### 18  Acceptance scenarios

These 19 cases cover graph implementation. Refresh, AI behaviour and operating acceptance additionally require the contracts in controlled refresh (#source-refresh) and validation gates (#validation-gates).

**All acceptance scenarios and expected results**

 These are implementation checks to execute on the current HSBC branch and deployment, with evidence attached to the relevant package. They are not tests already run by this document review.

 Scroll table horizontally →

Acceptance scenarios — table 1
ID | Scenario | Required observable result | Owner |

A01 | Reorder identical export rows; rename a mapped folder. | Stable IDs and unchanged semantic edge set for row reorder; manifest/evidence hashes may change. Reviewed rename preserves identity, while affected aliases, display properties and their digests change explicitly. | Y2 / M2 |

A02 | Duplicate MCP ID; ambiguous tool prefix. | No guessed edge, no order-dependent suffix; evidence and affected-reference counts remain visible to operators. | Y2 / M2 |

A03 | Same external ID in two tenants and PPD/Production. | No cross-scope identity, traversal, cache or aggregate leakage. | Y4 |

A04 | Empty description on an otherwise valid Agent. | Node and valid declared edges remain visible with quality reason; no readiness/approval claim. | Y2 / M3 |

A05 | Missing sheet/header; partial export; previously valid row becomes invalid. | No inferred removals or silent promotion; active publication remains unchanged until policy permits a reviewed result. | Y2 / M2 |

A06 | Valid full snapshot removes an edge; an input claims delta mode. | First removes it only in the next active publication; the initial importer rejects delta mode and cannot infer deletion. | Y2 / Y3 |

A07 | Crash after graph batch, seal or activation; acknowledgement lost. | Readers see a complete old or new publication. Uncertain builders are abandoned/rebuilt; sealed activation can be retried idempotently after reading its recorded outcome. No mixed data. | Y3 |

A08 | Two imports race; former worker resumes late. | Ownership loss permanently abandons that key; builder termination is required before sealing. A delayed stale write cannot affect active data or overwrite a newer publication. | Y3 |

A09 | Graph down; query timeout; authoritative zero relationships. | Unavailable, timeout and successful empty are distinct; no disk fallback masquerades as a graph result. | Y4 / M3 |

A10 | Permission revoked after a cursor/cache/rollback target was created. | Current policy denies the object and its connecting paths; no resurrection through historical state. | Y4 / Y3 |

A11 | Dependency cycle; high-degree Agent; oversized request. | Bounded expansion, typed validation and visible truncation; no unbounded traversal or browser freeze. | Y4 / M3 |

A12 | Component Agent has no native Hub binding. | Graph remains valid and explicitly unbound; no native relationship or name-based attachment is implied. If the optional adapter is reused, verify its stale/missing behaviour. | Y4 / M1 |

A13 | Prompt-like source text, unsafe HTML and path traversal. | Text stays data, HTML is safe, paths rejected; no tool execution or remote fetch. | Y2 / M3 |

A14 | Roll back then reclaim expired generations. | Retained target validated; active/in-flight data survives; expired cursors restart; only owned inactive keys removed. | Y3 / Y5 |

A15 | Use the chosen evidence surface with keyboard and unavailable/stale data. | Accessible list/query evidence, clear status and provenance. If an existing interactive view is reused, verify its desktop/mobile and keyboard behaviour. | M3 / M4 |

A16 | Enable graph feature on existing PoC branch. | No model calls, new recommendation runs, native graph/index changes or regression in current Hub workflows. | Y5 |

A17 | Cleanup selects a rollback target while an old cursor is still valid. | The shared lock/reservation/retiring state prevents deletion of a rollback target; fixed cursor lifetime plus read-deadline grace protects valid reads. | Y3 / Y4 |

A18 | New source removes an edge; delayed older source tries activation. | Reject collection-version regression. Technical rollback still applies current validity; changing evidence/publication cannot evade a denied relation key. | Y2 / Y3 |

A19 | An alias moves from X to Y; one identity splits. | Old publications retain their mapping and endpoints. New ambiguous references are unresolved; current redirects are separate, and derived caches/bindings invalidate. | Y2 / M2 |

Anchor: `decisions`

### 19  Decisions that make the plan implementable

Record owner decisions before the dependent implementation or rollout. Unknown platform facts remain explicit.

**Technical contract, decisions and supporting evidence**

 The architecture chooses a default direction and identifies the missing organisational facts. Resolve these at G0 with the existing owners; none is silently described as already approved.

 Scroll table horizontally →

Decisions that make the plan implementable — table 1
Decision | Recommended position | Required owner/evidence |

D1 · Existing-stack isolation | Keep Postgres and FalkorDB. Validate separate component graph keys, privileges, compatibility and capacity; native graph remains unchanged. | Joseph/platform owner reconciles prior “no new graph” wording; confirm key/ACL/capacity support. If isolation or safety fails, block the affected path and correct or narrow the existing-stack design before writes. A migration requires a separate decision. |

D2 · Authoritative identity | Durable internal IDs with scoped, verified external aliases; source-owner review for collisions and repo-only identities. | Agent Hub/skills owners validate ID lifetime, tenant/env boundaries and mapping policy. |

D3 · Source completeness | Complete-snapshot manifests and per-collection authority/removal rules now; recognise and reject delta inputs. Delta ingestion needs a later adapter decision with explicit base revision, ordering and tombstone tests. | Data owner confirms export semantics, mandatory sheets/headers and acceptable quality exceptions. |

D4 · Access and retention | Current Hub authorisation applies to every graph/history/diagnostic read; immediate revocations; minimal source storage. | Platform/data owner identifies actual policy hooks, retention/deletion rules and importer/publisher/reader privileges. |

D5 · Refresh and capacity | Controlled imports initially, bounded retention and monitored active age. | Yurii/platform owner sets cadence, stale cutoff, query budgets, generation/cursor retention and recovery owner using measured workload. |

D6 · Existing PoC and native Agent join | Reuse proven components; keep native binding deferred unless an existing exact adapter is trivial to reuse, and keep engine startup disabled for graph delivery. | M1/Y1 reconcile current commit, cleaned architecture and existing UI/routes. Confirm whether a thin evidence view is reusable; no native-ID integration is required to accept the component graph. |

D7 · Future engine | Approve a measured lexical baseline first; embeddings, graph boosts, LLM and MCP adapter require explicit later scope. | Joseph + domain reviewer agree purpose, label set, acceptance targets and cost/privacy constraints. Default to card-ID input; agree a specific evidence/retention model before adding free text. |

#### Presentation sequence for Joseph

 1. Show one Agent with its declared Skills/MCPs and the source of an edge. 2. Show an ambiguous reference as an honest gap. 3. Show refresh/retirement and how failure preserves a valid publication. 4. Walk through the six future recommendation stages using the illustrative invoice example. 5. Explain what must be measured before a quality claim. 6. Confirm graph acceptance and the next scope decision.

#### Additional decisions for the expanded AI plan

New decisions before dependent work
Decision | Required agreement | Blocks |
Refresh source and worker contract | Approved repository/ref and credential owner; workbook location/completeness; authenticated write role; durable worker and publisher ownership. No Agent Hub API is assumed. | UI refresh enablement and scheduling. |
Hub decision authority | Product/domain policy owner, applicable governance review, task-specific labels, false-COVERED/false-NOVEL limits and review-routing ownership. | Changing authoritative novelty/coverage behaviour. |
Evaluation and release configuration | Baseline corpus/cases, adapter coverage, approved models, data/trace retention, cost/SLO budgets and compatibility/rollback rules. | Quality claims and default-path promotion. |

Anchor: `verification`

### 20  Review record and evidence limits

The earlier graph proposal and this AI extension have separate review records. Runtime and quality gates remain unexecuted in this documentation task.

**Technical contract, decisions and supporting evidence**

 This review checks the rewritten design and the document itself. It does not substitute for implementation CI, security testing or a live HSBC workstation validation.

#### Historical graph proposal: three completed reviews

These records predate the AI and controlled-refresh expansion; they do not certify the new sections.

 Round 1 · Source and contract review · Completed

#### Fix the foundation

Reconciled Joseph’s graph-first scope, source history and the old architecture. Corrected identity/snapshot keys, field provenance, PPD scope, publication versus access scope, writer termination, source version vectors, optional native-Agent binding and evidence retention. Reduced the proposed first engine experiment to four attempts and made the evidence surface depend on practical reuse.

 Round 2 · Failure and delivery review · Completed

#### Close the failure paths

Walked through interrupted writes, competing publications, old source exports, permission changes, rollback and cleanup. Added guarded irreversible retirement, fixed reader expiry, stable relation denies, monotonic collection revisions, explicit API errors, batch reservations/cache identity and acyclic package dependencies. Separated validation tuning from the untouched final test set.

 Round 3 · Final consistency and presentation · Completed

#### Make the plan clear and reviewable

Rechecked the rewritten contracts and both earlier correction lists. Clarified unbound Agents, the full-snapshot-only boundary, decision ownership and the complete retirement state diagram. Checked the HTML in light/dark themes at 1920×1080, 1440×1000 and 390×844; corrected mobile toolbar overlap and small-text contrast; verified anchors, diagram labels, contained scrolling and the exact responsibility allocation.

These were three sequential self-review and revision rounds, supported by independent adversarial reviews. The outcome is a reviewed architecture proposal. G0 owner decisions, current-code reconciliation and implementation CI remain required before rollout; no runtime or live recommendation-quality result is claimed.

#### AI and refresh expansion: current review record

AI expansion review record
Round | Review and corrections | Evidence limit |
1 · Source and contract review · complete | Mapped the earlier Hub improvement backlog to the retained database stack. Separated reported ingestion capabilities from proposed endpoints, jobs and authentication. Defined independent completeness, Hub coverage and component-fit contracts. | The HSBC workstation checkout and runtime have not been directly verified. |
2 · Adversarial failure review · complete | Added non-authoritative legacy observations, runtime compatibility enforcement and explicit semantic-support status. Corrected idempotency, linked retry, recoverable dispatch, bounded Git acquisition, remote-writer uncertainty and activation-time authorisation. | Review establishes a proposed contract, not proof that code implements it. |
3 · Integration and visual verification · complete | Reconciled source links, task vocabularies, scope, ownership and failure outcomes. Checked 20 sections and 25 diagrams, contained page widths at 1920, 1440 and 390 pixels, light/dark presentation, mobile navigation, disclosures and diagram expansion. Corrected overlapping labels and ambiguous historical review claims. | Document checks only; no application test or benchmark result is claimed. |

BPC Hub · AI contracts, graph & controlled refresh · revision 3

Prepared for the graph delivery and AI improvement discussion. Implementation follows reconciled contracts and recorded validation gates on the existing stack.

Back to the overview ↑ (#overview)
