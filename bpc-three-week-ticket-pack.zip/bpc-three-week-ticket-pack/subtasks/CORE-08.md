---
pack_id: "bpc-sep26-v1"
local_id: "CORE-08"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Deliver one authorised lexical recommendation baseline for all component types"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "recommendations"
create_by_default: false
planned_start: "2026-09-22"
planned_due: "2026-09-22"
dates_profile: "recommendations"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-03","CORE-07"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-08"
architecture_sections: ["engine","evaluation","read-contract"]
---

# Deliver one authorised lexical recommendation baseline for all component types

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-08** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **not scheduled; do not create by default**.
- Recommendation extension: **2026-09-22 → 2026-09-22 (D10–D10)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Provide a measurable first recommendation service for Skills, MCP and Agents without building three engines or enabling unmeasured model/graph boosts.

## Scope and contract

This is a separately gated extension beyond Joseph’s earlier graph-only engine boundary. It is a lexical candidate baseline with explicit type filters, source evidence, exclusions, prerequisites and truthful outcomes. It is not the full six-stage LLM-assessed recommender.

## Implementation sequence

1. Confirm recommendation implementation scope and existing PoC reuse in CORE-01 before work starts.
2. Implement one bounded authorized lexical retrieval/ranking adapter over canonical component records, with type-specific input mapping supplied by source tasks.
3. Apply independent type eligibility, required/excluded constraints and current access before retrieval/expansion and again before output.
4. Return stable IDs, source evidence, ranking reason and evaluated prerequisites, distinguishing complete/partial/failed/disabled/busy/unavailable and assessed/no-match/unassessed meanings.
5. Use a pre-agreed minimum service contract; an unavailable source/store or budget exhaustion cannot become complete-empty.
6. Wire the shared result interface and per-type tests; keep vectors, graph boosts, model fit and external MCP execution disabled.

## Acceptance criteria

- [ ] The same API/core returns bounded results for each requested supported type with explicit lineage.
- [ ] No denied/fabricated IDs or unresolved mandatory prerequisites become actionable suggestions.
- [ ] An authentic fully processed no-match differs from unsupported, unavailable, unassessed and failed runs.
- [ ] Feature enablement waits for type-specific frozen evaluation and cross-type release gates.

## Verification

- Run known lexical relevance/empty/hard-negative fixtures per type; test authorization, duplicate saturation, budget truncation and missing source evidence.
- Compare the actual PoC behavior with the baseline and document all intentional changes.

## Evidence to attach

- Shared engine/API diff, per-type replay outputs, outcome-state tests and configuration manifest.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

Building embeddings, RRF experiments, graph boosts, LLM batches, confidence calibration, bundle optimization or a new MCP endpoint is not hidden in this estimate. The complete architecture backlog remains in the follow-on register.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.
- [CORE-07](CORE-07.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `engine`, `evaluation`, `read-contract`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
