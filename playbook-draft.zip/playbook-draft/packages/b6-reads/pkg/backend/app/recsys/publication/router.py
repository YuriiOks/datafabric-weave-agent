"""The bounded publication read, mounted under ``/api/recsys/publication``.

One endpoint serves :class:`~app.recsys.publication.reads.BoundedReader`: a pinned,
budgeted, policy-checked traversal of the scope's active publication. The caller names
seeds, relations and budgets; the scope comes from configuration and the principal from
the server-owned session, never from the request.

It fails closed. Unless pre-production reads are switched on, the configured scope is
pre-production and the caller is a listed reader, it refuses before touching the graph.
Production stays refused until the entitlement service replaces the reader list.

Every budget refusal that still produced a page returns it, flagged with the budget that
ran out, so a caller can page on or widen the budget. The other refusals keep their own
status codes because the caller's response to each differs.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict
from redis.exceptions import ConnectionError as GraphConnectionError
from redis.exceptions import TimeoutError as GraphTimeoutError

from app.auth.middleware import get_current_user
from app.middleware.rate_limit import limiter
from app.recsys.api.deps import resolve_pool
from app.recsys.config import RecsysSettings, recsys_settings
from app.recsys.contracts import Principal, PublicationScope, SourceEnvironment

from .graph_store import CandidateGraphStore
from .models import (
    BoundedReadRequest,
    BoundedReadResult,
    BudgetExhausted,
    CursorExpired,
    CursorMismatch,
    PolicyChanged,
    PublicationUnavailable,
    ReadBudget,
    ReadCursor,
    ScopeNotPermitted,
)
from .preproduction_policy import PreproductionReadPolicy, parse_readers
from .reads import BoundedReader
from .repository import PublicationRepository

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/publication", tags=["recsys-publication"])

#: A read walks the graph under its own duration budget, so it is limited like browsing.
READ_LIMIT = "60/minute"

_store: CandidateGraphStore | None = None


class PublicationRead(BaseModel):
    """One bounded read, or the next page of one."""

    model_config = ConfigDict(extra="forbid")

    request: BoundedReadRequest
    cursor: ReadCursor | None = None


class PublicationReadPage(BaseModel):
    """A page of a bounded read.

    :ivar result: The authorised nodes and edges of this page.
    :ivar exhausted_budget: Set when a budget ran out; ``result.cursor`` resumes a read
        that ran out of result count, and a depth-limited read needs a larger depth.
    """

    result: BoundedReadResult
    exhausted_budget: ReadBudget | None = None


def read_scope(settings: RecsysSettings = recsys_settings) -> PublicationScope:
    """Return the one scope publication reads are served from.

    :param settings: The recsys settings.
    :return: The configured refresh scope, which is the scope the refresh publishes to.
    """
    return PublicationScope(
        environment=SourceEnvironment(settings.recsys_refresh_environment),
        partition=settings.recsys_refresh_partition,
    )


def _graph_store() -> CandidateGraphStore:
    """Return the process-level graph adapter, created on first use."""
    global _store
    if _store is None:
        # Imported here: the hub settings require the hub's environment.
        from app.config import settings as hub_settings

        _store = CandidateGraphStore(
            host=hub_settings.falkordb_host,
            port=hub_settings.falkordb_port,
            username=hub_settings.falkordb_username or None,
            password=hub_settings.falkordb_password or None,
        )
    return _store


async def get_bounded_reader(
    user: dict[str, object] = Depends(get_current_user),
) -> BoundedReader:
    """Build the reader for this caller, or refuse before anything is read.

    :param user: The authenticated principal from the server-owned session.
    :return: A reader pinned to the caller and the configured scope.
    :raises HTTPException: 503 when reads are off or the scope is not pre-production;
        403 when the caller is not a listed reader.
    """
    settings = recsys_settings
    if not settings.recsys_publication_reads_enabled:
        raise HTTPException(status_code=503, detail="publication_reads_unavailable")
    scope = read_scope(settings)
    readers = parse_readers(settings.recsys_publication_readers)
    if scope.environment is not SourceEnvironment.ppd or not readers:
        raise HTTPException(status_code=503, detail="publication_reads_unavailable")
    principal_id = str(user.get("employee_id", "")).strip()
    policy = PreproductionReadPolicy(scope=scope, principal_id=principal_id, readers=readers)
    if not principal_id or not policy.admits_caller:
        raise HTTPException(status_code=403, detail="publication_read_not_authorized")
    principal = Principal(
        principal_id=principal_id,
        roles=[str(user.get("role", "")) or "viewer"],
        policy_scope=scope,
    )
    return BoundedReader(
        PublicationRepository(resolve_pool()),
        _graph_store(),
        principal,
        policy,
    )


@router.post("/reads", response_model=PublicationReadPage)
@limiter.limit(READ_LIMIT)
async def read_publication(
    request: Request,
    body: PublicationRead,
    reader: BoundedReader = Depends(get_bounded_reader),
) -> PublicationReadPage:
    """Run one bounded read of the active publication.

    :param request: The incoming request (required by the rate limiter).
    :param body: The traversal and, for a next page, its cursor.
    :param reader: The caller's reader.
    :return: The page, with the exhausted budget when one ran out.
    :raises HTTPException: 410 for an expired cursor, 403 when the caller's authority
        changed or the cursor belongs to another scope, 409 for a cursor issued for
        another traversal, 503 when no publication is active, the read ran out of time
        or the graph cannot be reached. Unavailable, timed out and an authoritative
        empty answer stay three different responses.
    """
    try:
        result = await reader.read(body.request, body.cursor)
    except CursorExpired as error:
        raise HTTPException(status_code=410, detail="cursor_expired") from error
    except BudgetExhausted as error:
        if error.page is None:
            raise HTTPException(
                status_code=503, detail=f"budget_exhausted:{error.budget.value}"
            ) from error
        return PublicationReadPage(result=error.page, exhausted_budget=error.budget)
    except PolicyChanged as error:
        raise HTTPException(status_code=403, detail="policy_changed") from error
    except ScopeNotPermitted as error:
        raise HTTPException(status_code=403, detail="scope_not_permitted") from error
    except CursorMismatch as error:
        raise HTTPException(status_code=409, detail="cursor_mismatch") from error
    except PublicationUnavailable as error:
        raise HTTPException(status_code=503, detail="publication_unavailable") from error
    except (GraphConnectionError, GraphTimeoutError) as error:
        logger.error(
            "Publication read refused: graph unreachable",
            extra={"error_type": type(error).__name__},
        )
        raise HTTPException(status_code=503, detail="graph_unavailable") from error
    return PublicationReadPage(result=result)
