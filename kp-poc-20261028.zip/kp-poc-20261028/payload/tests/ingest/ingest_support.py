"""Helpers shared by the ingest tests (imported by name, like the other lanes' support modules)."""

from __future__ import annotations

import random
from collections.abc import Callable
from datetime import UTC, datetime

from sqlalchemy import Connection, insert, select

from kp.domain import SourceItemVersion
from kp.sources.base import FetchedItem
from kp.store.schema import run, source_item

NOW = datetime(2026, 11, 1, 9, 30, tzinfo=UTC)
RUN_ID = "run-ingest-1"
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

DAMAGE_SEED = 20261028

ItemFactory = Callable[..., SourceItemVersion]
FetchFactory = Callable[[SourceItemVersion, bytes], FetchedItem]


def damaged_copies(content: bytes) -> list[bytes]:
    """Truncated and bit-flipped copies of a file, the same on every run."""
    rng = random.Random(DAMAGE_SEED)  # noqa: S311 - reproducible damage, not security
    copies = [content[: len(content) * share // 10] for share in range(1, 10)]
    for _ in range(60):
        damaged = bytearray(content)
        for _flip in range(rng.randint(1, 8)):
            damaged[rng.randrange(len(damaged))] ^= 1 << rng.randrange(8)
        copies.append(bytes(damaged))
    return copies


def seed_run(connection: Connection, run_id: str = RUN_ID) -> None:
    """Insert the run row that review items and source items point to, unless it exists."""
    if connection.execute(select(run.c.run_id).where(run.c.run_id == run_id)).first() is None:
        connection.execute(
            insert(run).values(
                run_id=run_id,
                kind="sweep",
                sources=[],
                started_at=NOW,
                outcome="running",
                items_touched=0,
            )
        )


def store_item(connection: Connection, item: SourceItemVersion) -> None:
    """Insert the run (if absent) and the source item row that other tables point to."""
    seed_run(connection, item.run_id)
    row = item.model_dump(exclude={"details"})
    row.update(item.details.model_dump())
    for name in ("source", "extraction_status", "approval_state"):
        row[name] = row[name].value
    connection.execute(insert(source_item).values(**row))
