# Review comment voice (shared by /km-review-pr and /km-code-review)

Read this before writing any comment text that the owner might paste into a pull request.
Applies to the Suggestion/Fix wording in reports too. Nothing here posts anything.

## Anatomy of one comment

In this order, nothing else:
1. Severity word first: blocker, should-fix, question or nit (definitions in routing.md).
2. `path:line` on the reviewed head (new version of the file).
3. A short code quote that proves the point (one to three lines). No quote, no comment.
   For something missing (no test, no validation, no handler), quote the nearest line that
   should have it (the call site or the signature) and say what was searched and not
   found, for example: searched tests/ for the new branch, found nothing.
4. Why it matters: the input or state that makes it go wrong, in plain words.
5. A concrete fix: name the function, field or test, and prefer one fix over a menu.
6. A question to the author only when the decision is theirs or the owner's. Say who decides
   and what waits on it. Never use a question to soften a finding.

Length: nit 1 to 3 sentences. Blocker or should-fix 2 to 5 sentences plus the fix. If it is
longer, cut; do not compress.

The draft or report ends with a "Could not verify" list: what no reviewer could check and
why (no run environment, consumer outside the tree, missing conventions). A review without
that list is incomplete; "nothing" is allowed when true.

## Sound like a colleague

- Open with the point. No greeting, no sign-off, no thanks.
- Talk about the code, not the person: "this guard never fires", not "you forgot".
- Short, direct, active voice. One honest hedge at most, and it says what would settle it.
- Praise only as half a line about a fact in the code, never first, never as padding.
- Roles, not names: "the author", "the owner", "the tech lead".
- No lecture: do not explain a pattern the author obviously knows.
- Do not restate the diff. Do not mention tools, reviewers, levels or skeptics.
- A comment on code outside the diff, or code not read at the head, is not allowed.
- A demand that moves scope says so in one clause ("outside this change, but ...").

## Strip list

Delete or rewrite any of these: "Certainly", "Great catch", "Great question", "I have
carefully reviewed", "It is worth noting", "Additionally", "Furthermore", "Moreover",
"In summary", "Overall", "solid implementation", "Would you consider", "Would you mind",
"Let me know if you have questions", "I hope this helps", "consider" or "maybe" as the whole
fix, three-item lists of adjectives, nested bullets for a one-line fix, bold headings on a
short comment, any tool or session attribution.

## Four checks before a comment stays

1. Is it true in the code? Open the lines at the head and see it.
2. Is it about this change? Not old code, not taste, not a linter's job.
3. Would I say it aloud to the author at their desk?
4. Is the fix concrete enough to act on without asking me?

One "no" means rewrite, or drop it. Count dropped comments in the report.

## Worked examples

Invented snippet, `src/orders/total.py`, line 42:

    total = sum(line.price * line.qty for line in lines)
    return round(total * (1 + rate), 2)

Good (should-fix):

> should-fix src/orders/total.py:42 `round(total * (1 + rate), 2)` rounds once on the whole
> order. The per-line rule in `invoice.py:18` rounds each line first, so an order with many
> small lines can differ by a cent from its invoice. Round each line at 41, then sum.

Bad (all five problems at once):

> Great work on this! It is worth noting that the rounding here might possibly be a little
> inconsistent in some situations. Would you consider maybe looking into whether this could
> be improved? Let me know if you have questions.

Why it fails: praise first, no place, no quote, no input that breaks it, no fix, closing
offer. Rewritten, it is the good version above.

Good (question with an owner):

> question src/orders/total.py:42 `rate` is read from the request body. Who decides whether
> a client may set it? If the answer is "the server only", this needs to come from config
> instead; I did not find a check in `routes.py`.

Bad (a question used to soften):

> Do you think it might be better, perhaps, to validate rate somewhere?

Rewritten: state the finding as a should-fix with the quote and the missing check, then ask
only who owns the rule.

Good (something missing):

> should-fix src/orders/total.py:42 `return round(total * (1 + rate), 2)` has a new branch
> for `rate == 0` upstream, but I searched tests/ for it and found nothing. An order with a
> zero rate skips the rounding path. Add a case in `test_total.py` for a zero rate.

Good (nit):

> nit src/orders/total.py:40 `lines` is rebuilt as a list one line above and only iterated
> here. A generator is enough.

Bad (a linter's job, and a lecture):

> Nit: please be careful with line length and import ordering, since consistent style
> improves readability across the whole team and makes onboarding easier.

Rewritten: drop it. A formatter catches it.
