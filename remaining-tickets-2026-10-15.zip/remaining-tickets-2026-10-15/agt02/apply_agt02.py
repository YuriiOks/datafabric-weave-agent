"""Apply the AGT-02 change package to a clean worktree. Harness file: never committed.

Usage: python3 apply_agt02.py <worktree-root> [--check]

Copies every file under ./pkg into the worktree (refusing to overwrite anything), then
applies anchored edits to existing files. Every anchor must occur exactly once. All
anchors are checked before anything is written; one miss writes nothing.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / "pkg"
BRANCH = "feat/agt-02-relations"

EDITS: list[tuple[str, str, str]] = []


def edit(path: str, old: str, new: str) -> None:
    EDITS.append((path, old, new))


# ---------------------------------------------------------------- registry/models.py
M = "backend/app/recsys/registry/models.py"
edit(
    M,
    """from typing import Any

from app.recsys.contracts import (
    BLOCKING_FLAGS,
    ComponentType,
    LinkType,
    QualityFlag,
)
""",
    """from typing import TYPE_CHECKING, Any

from app.recsys.contracts import (
    BLOCKING_FLAGS,
    ComponentType,
    LinkType,
    QualityFlag,
)

if TYPE_CHECKING:
    from app.recsys.registry.relations.evidence import EvidenceEntry
""",
)
edit(
    M,
    """    resolution_rules: list[dict[str, str]] = field(default_factory=list)
""",
    """    resolution_rules: list[dict[str, str]] = field(default_factory=list)
    # The relation's stable key (the two component UUIDs and the link type, nothing
    # else), the digest of its evidence set, and one entry per supporting source
    # declaration in canonical order. Unset only on a link not built from a fact.
    relation_key: str | None = None
    evidence_digest: str | None = None
    evidence: list[EvidenceEntry] = field(default_factory=list)
""",
)

# ----------------------------------------------------------------- registry/links.py
L = "backend/app/recsys/registry/links.py"
edit(
    L,
    """looks populated but is mostly inferred is worse than one that is visibly empty.
\"\"\"
""",
    """looks populated but is mostly inferred is worse than one that is visibly empty.

Every link also carries a stable relation key, derived from the two component UUIDs and
the link type only, and one evidence entry per supporting declaration: authority,
locator, field, token position, the original token and the rule that bound it.
Repeated declarations of one relation stay one link with several entries; see
:mod:`app.recsys.registry.relations`.
\"\"\"
""",
)
edit(
    L,
    """from app.recsys.registry.models import ComponentLink, ComponentRow
from app.recsys.registry.rule_stamps import RuleStamp, stamp_for
""",
    """from app.recsys.registry.models import ComponentLink, ComponentRow
from app.recsys.registry.relations.evidence import (
    evidence_by_reference,
    evidence_digest,
    ordered_evidence,
)
from app.recsys.registry.relations.keys import relation_key
from app.recsys.registry.rule_stamps import RuleStamp, stamp_for
""",
)
edit(
    L,
    """    result = LinkBuildResult()
    for fact in catalogue.facts:
""",
    """    entry_by_reference = evidence_by_reference(catalogue)

    result = LinkBuildResult()
    for fact in catalogue.facts:
""",
)
edit(
    L,
    """        result.links.append(
            ComponentLink(
                src_id=src_id,
                dst_id=dst_id,
                link_type=fact.link_type,
                source=";".join(source_labels),
                resolved=True,
                matched_indexes=sorted(index.value for index in matched),
                resolution_rules=[stamp.as_dict() for stamp in stamps],
            )
        )
""",
    """        # Repeated declarations of one relation stay one link; each declaration is one
        # evidence entry, so the repetition stays visible without becoming a second edge.
        supporting = ordered_evidence(
            entry_by_reference[reference]
            for reference in fact.supporting_reference_ids
            if reference in entry_by_reference
        )
        result.links.append(
            ComponentLink(
                src_id=src_id,
                dst_id=dst_id,
                link_type=fact.link_type,
                source=";".join(source_labels),
                resolved=True,
                matched_indexes=sorted(index.value for index in matched),
                resolution_rules=[stamp.as_dict() for stamp in stamps],
                relation_key=relation_key(
                    fact.source_component_uuid,
                    fact.link_type,
                    fact.target_component_uuid,
                ),
                evidence_digest=evidence_digest(supporting),
                evidence=supporting,
            )
        )
""",
)

# ---------------------------------------------------------------- registry/ledger.py
G = "backend/app/recsys/registry/ledger.py"
edit(
    G,
    """from app.recsys.contracts import (
    AccountingOutcome,
    CatalogueBuildResult,
    ComponentType,
    PublicationScope,
)
""",
    """from app.recsys.contracts import (
    AccountingOutcome,
    CatalogueBuildResult,
    ComponentType,
    PublicationScope,
    ResolutionEvidence,
)
""",
)
edit(
    G,
    """    members: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
""",
    """    members: tuple[str, ...] = ()
    # Reference entries only: how the resolver classified the reference, the legacy id
    # of the component that declared it (unset when that record has no accepted
    # identity), and the relation kind it would have produced.
    resolution_outcome: str | None = None
    owner_component_id: str | None = None
    link_type: str | None = None

    def as_dict(self) -> dict[str, Any]:
""",
)
edit(
    G,
    """        if self.members:
            payload["members"] = list(self.members)
        return payload
""",
    """        if self.members:
            payload["members"] = list(self.members)
        if self.resolution_outcome is not None:
            payload["resolution_outcome"] = self.resolution_outcome
        if self.owner_component_id is not None:
            payload["owner_component_id"] = self.owner_component_id
        if self.link_type is not None:
            payload["link_type"] = self.link_type
        return payload
""",
)
edit(
    G,
    """def _reference_entries(
    catalogue: CatalogueBuildResult,
    adapter: AdapterResult,
    ledger: ReviewLedger,
) -> None:
    \"\"\"Turn every non-accepted reference outcome into a ledger entry.

    :param catalogue: The built catalogue candidate.
    :param adapter: The adapter provenance for locators and raw values.
    :param ledger: Mutated in place.
    \"\"\"
    for evidence in catalogue.reference_outcomes:
        origin = adapter.reference_origins.get(evidence.reference_occurrence_id)
        if evidence.accounting_outcome is AccountingOutcome.accepted:
            ledger.resolved_references += 1
            continue
        ledger.unresolved_references += 1
        raw, redacted = redact(origin.raw_value if origin is not None else None)
        ledger.entries.append(
            LedgerEntry(
                kind="reference",
                environment=ledger.environment,
                component_type=(
                    origin.target_type.value if origin is not None else "unknown"
                ),
                reason=evidence.reason or "unknown",
                source_locator=origin.locator if origin is not None else "",
                raw_value=raw,
                raw_value_redacted=redacted,
                field_name=origin.field_name if origin is not None else None,
            )
        )
""",
    """def _legacy_ids(catalogue: CatalogueBuildResult) -> tuple[dict[str, str], dict[str, str]]:
    \"\"\"Map durable UUIDs and record occurrences onto the legacy component id.

    :param catalogue: The built catalogue candidate.
    :return: ``(by_uuid, by_record_occurrence)``, each onto the ``type:external_id`` id
        the component and link tables use.
    \"\"\"
    by_uuid: dict[str, str] = {}
    by_occurrence: dict[str, str] = {}
    for record in catalogue.records:
        legacy_id = (
            f"{record.identity.component_type.value}:"
            f"{record.identity.source_key.external_id}"
        )
        by_uuid[str(record.identity.component_uuid)] = legacy_id
        for source in record.source_evidence:
            by_occurrence[source.record_occurrence_id] = legacy_id
    return by_uuid, by_occurrence


def _candidate_labels(
    evidence: ResolutionEvidence,
    by_uuid: dict[str, str],
    row_locators: dict[str, str],
) -> tuple[str, ...]:
    \"\"\"Name every candidate the resolver weighed, the way a reviewer can find it.

    :param evidence: The resolution evidence of one reference.
    :param by_uuid: Durable UUID to legacy component id.
    :param row_locators: Record occurrence to its structural source locator.
    :return: A legacy id for a catalogued candidate, otherwise the source row locator.
    \"\"\"
    labels: list[str] = []
    for candidate in evidence.candidates:
        if candidate.component_uuid is not None:
            text = str(candidate.component_uuid)
            labels.append(by_uuid.get(text, text))
        else:
            occurrence = candidate.record_occurrence_id or ""
            labels.append(row_locators.get(occurrence, occurrence))
    return tuple(sorted(labels))


def _reference_entries(
    catalogue: CatalogueBuildResult,
    adapter: AdapterResult,
    ledger: ReviewLedger,
) -> None:
    \"\"\"Turn every non-accepted reference outcome into a ledger entry.

    Each entry names the resolver's outcome, the component that declared the reference
    and the relation kind it would have produced, and lists every candidate an
    ambiguous reference could have meant. None of it creates an edge.

    :param catalogue: The built catalogue candidate.
    :param adapter: The adapter provenance for locators and raw values.
    :param ledger: Mutated in place.
    \"\"\"
    by_uuid, by_occurrence = _legacy_ids(catalogue)
    declared = {
        reference.occurrence_id: (record.occurrence_id, reference.link_type)
        for batch in catalogue.source_batches
        for record in batch.records
        for reference in record.references
    }
    row_locators = {
        occurrence: origin.locator for occurrence, origin in adapter.row_origins.items()
    }
    for evidence in catalogue.reference_outcomes:
        origin = adapter.reference_origins.get(evidence.reference_occurrence_id)
        if evidence.accounting_outcome is AccountingOutcome.accepted:
            ledger.resolved_references += 1
            continue
        ledger.unresolved_references += 1
        declaration = declared.get(evidence.reference_occurrence_id)
        parent = declaration[0] if declaration is not None else None
        link_type = declaration[1] if declaration is not None else None
        raw, redacted = redact(origin.raw_value if origin is not None else None)
        ledger.entries.append(
            LedgerEntry(
                kind="reference",
                environment=ledger.environment,
                component_type=(
                    origin.target_type.value if origin is not None else "unknown"
                ),
                reason=evidence.reason or "unknown",
                source_locator=origin.locator if origin is not None else "",
                raw_value=raw,
                raw_value_redacted=redacted,
                field_name=origin.field_name if origin is not None else None,
                members=_candidate_labels(evidence, by_uuid, row_locators),
                resolution_outcome=evidence.outcome.value,
                owner_component_id=(
                    by_occurrence.get(parent) if parent is not None else None
                ),
                link_type=link_type.value if link_type is not None else None,
            )
        )
""",
)

# ---------------------------------------------------------------- registry/writer.py
W = "backend/app/recsys/registry/writer.py"
edit(
    W,
    """    summarise,
)

logger = logging.getLogger(__name__)
""",
    """    summarise,
)
from app.recsys.registry.relation_writer import write_relation_evidence

logger = logging.getLogger(__name__)
""",
)
edit(
    W,
    """    resolution_rules
) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8::jsonb)
""",
    """    resolution_rules, relation_key, evidence_digest
) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8::jsonb, $9, $10)
""",
)
edit(
    W,
    """    resolution_rules = EXCLUDED.resolution_rules
""",
    """    resolution_rules = EXCLUDED.resolution_rules,
    relation_key = EXCLUDED.relation_key,
    evidence_digest = EXCLUDED.evidence_digest
""",
)
edit(
    W,
    """    source_locator, raw_value, raw_value_redacted, field_name, members
) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11::jsonb)
""",
    """    source_locator, raw_value, raw_value_redacted, field_name, members,
    resolution_outcome, owner_component_id, link_type
) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11::jsonb, $12, $13, $14)
""",
)
edit(
    W,
    """    members = EXCLUDED.members
""",
    """    members = EXCLUDED.members,
    resolution_outcome = EXCLUDED.resolution_outcome,
    owner_component_id = EXCLUDED.owner_component_id,
    link_type = EXCLUDED.link_type
""",
)
edit(
    W,
    """    traced to its owner from the generation that published it.
""",
    """    traced to its owner from the generation that published it. Every link's evidence
    entries are written right after the link rows, in the same transaction, so a
    relation is never visible without the declarations behind it.
""",
)
edit(
    W,
    """                        json.dumps(link.resolution_rules, sort_keys=True),
                    )
                    for link in links
                ],
            )
""",
    """                        json.dumps(link.resolution_rules, sort_keys=True),
                        link.relation_key,
                        link.evidence_digest,
                    )
                    for link in links
                ],
            )
            await write_relation_evidence(conn, version, links)
""",
)
edit(
    W,
    """                        json.dumps(entry.get("members", [])),
                    )
""",
    """                        json.dumps(entry.get("members", [])),
                        entry.get("resolution_outcome"),
                        entry.get("owner_component_id"),
                        entry.get("link_type"),
                    )
""",
)

# -------------------------------------------------------------- registry/__init__.py
I = "backend/app/recsys/registry/__init__.py"
edit(
    I,
    """#: yield a fresh version whose rows have it.
INGEST_CODE_VERSION = "5"
""",
    """#: yield a fresh version whose rows have it.
#: ``"6"``: every link carries a stable relation key, an evidence digest and its
#: evidence entries, and every unresolved reference names its outcome, owner and link
#: type, so a byte-identical export must still yield a fresh version that has them.
INGEST_CODE_VERSION = "6"
""",
)

# --------------------------------------------------------------------- db/schema.py
S = "backend/app/recsys/db/schema.py"
edit(
    S,
    """from .transition_schema import TRANSITION_ALTERS, TRANSITION_INDEXES, TRANSITION_SCHEMA
""",
    """from .relation_schema import RELATION_ALTERS, RELATION_INDEXES, RELATION_SCHEMA
from .transition_schema import TRANSITION_ALTERS, TRANSITION_INDEXES, TRANSITION_SCHEMA
""",
)
edit(
    S,
    """            for statement in (*TRANSITION_SCHEMA, *TRANSITION_ALTERS, *TRANSITION_INDEXES):
                await conn.execute(statement)
""",
    """            for statement in (*TRANSITION_SCHEMA, *TRANSITION_ALTERS, *TRANSITION_INDEXES):
                await conn.execute(statement)
            for statement in (*RELATION_ALTERS, *RELATION_SCHEMA, *RELATION_INDEXES):
                await conn.execute(statement)
""",
)

# ------------------------------------------------------ registry/transition/models.py
T = "backend/app/recsys/registry/transition/models.py"
edit(
    T,
    """"Retirement" here always means a *component* that a candidate catalogue version no longer
contains relative to the current one. It is never a publication lifecycle state.
""",
    """"Retirement" here always means a *component*, or a *relation* between two components,
that a candidate catalogue version no longer contains relative to the current one. It is
never a publication lifecycle state.
""",
)
edit(
    T,
    """    SourceAuthority,
    SourceManifest,
)


class _TransitionModel(BaseModel):
""",
    """    SourceAuthority,
    SourceManifest,
)
from app.recsys.registry.relations.diff import RelationDiff


class _TransitionModel(BaseModel):
""",
)
edit(
    T,
    """    scope_changed = "scope_changed"
""",
    """    scope_changed = "scope_changed"
    relation_retirement_not_declared = "relation_retirement_not_declared"
""",
)
edit(
    T,
    """    component_ids: list[str] = Field(default_factory=list)
""",
    """    component_ids: list[str] = Field(default_factory=list)
    relation_keys: list[str] = Field(default_factory=list)
""",
)
edit(
    T,
    """    approved_at: datetime

    @field_validator("retired_component_ids")
""",
    """    approved_at: datetime
    #: The exact relation keys this approval lets retire; empty when the transition
    #: retires no relation or the relation clause was not evaluated.
    retired_relation_keys: tuple[str, ...] = ()

    @field_validator("retired_component_ids", "retired_relation_keys")
""",
)
edit(
    T,
    """    approval_applied: bool = False
""",
    """    approval_applied: bool = False
    #: The relation-level diff, when the caller supplied both builds' relations.
    relation_diff: RelationDiff | None = None
""",
)

# -------------------------------------------------------- registry/transition/gate.py
X = "backend/app/recsys/registry/transition/gate.py"
edit(
    X,
    """  scope than the publication it would replace is a scope change, not a retirement.

An approval that names this exact candidate and this exact retired set lifts all three.
""",
    """  scope than the publication it would replace is a scope change, not a retirement.

When the caller also passes both builds' relations, a fourth rule applies:

* **Relations.** A relation absent from the candidate is a declared retirement only when
  every authority whose declaration supported it, and every authority behind its
  target component, declares ``absence_is_deletion`` on a complete, current snapshot.
  Anything else is refused, naming the relation keys it would have retired.

An approval that names this exact candidate, this exact retired component set and this
exact retired relation set lifts every breach.
""",
)
edit(
    X,
    """from app.recsys.registry.models import ComponentRow
""",
    """from app.recsys.registry.models import ComponentRow
from app.recsys.registry.relations.diff import RelationDiff, RelationFact, diff_relations
""",
)
edit(
    X,
    """def _approval_applies(
    approval: RetirementApproval | None, to_version: str, diff: TransitionDiff
) -> bool:
    return (
        approval is not None
        and approval.candidate_version == to_version
        and list(approval.retired_component_ids) == diff.retired
    )
""",
    """def _undeclared_relations(
    retired: list[RelationFact],
    prior_components: Mapping[str, ComponentFact],
    manifests: Sequence[SourceManifest],
) -> list[str]:
    \"\"\"Name every retired relation that no deleting authority accounts for.

    :param retired: The current version's relations that the candidate no longer has.
    :param prior_components: The current version's components, keyed by id.
    :param manifests: The candidate's source manifests.
    :return: The sorted keys of retirements that are absence rather than deletion.
    \"\"\"
    deleting = {manifest.authority for manifest in manifests if declares_deletion(manifest)}
    undeclared: list[str] = []
    for fact in retired:
        target = prior_components.get(fact.dst_id)
        target_authorities = (
            AUTHORITIES_BY_SOURCE.get(target.source) if target is not None else None
        )
        if not target_authorities:
            undeclared.append(fact.relation_key)
            continue
        required = {SourceAuthority(value) for value in fact.evidence_authorities}
        if not (required | target_authorities) <= deleting:
            undeclared.append(fact.relation_key)
    return sorted(undeclared)


def _relation_clause(
    prior: PriorPublication | None,
    prior_relations: Mapping[str, RelationFact] | None,
    candidate_relations: Mapping[str, RelationFact] | None,
    manifests: Sequence[SourceManifest],
    breaches: list[Breach],
) -> RelationDiff | None:
    \"\"\"Diff both builds' relations and refuse every undeclared relation retirement.

    :param prior: The current version, or ``None`` when nothing is current yet.
    :param prior_relations: The current version's relations, keyed by relation key.
    :param candidate_relations: The candidate's relations; ``None`` skips the clause.
    :param manifests: The candidate's source manifests.
    :param breaches: Mutated in place; gains one breach naming every undeclared key.
    :return: The relation diff, or ``None`` when the clause was not evaluated.
    :raises ValueError: If the candidate's relations are compared against a current
        version without that version's relations.
    \"\"\"
    if candidate_relations is None:
        return None
    if prior is not None and prior_relations is None:
        raise ValueError("prior_relations is required when a version is current")
    previous = prior_relations or {}
    relation_diff = diff_relations(previous, candidate_relations)
    undeclared = _undeclared_relations(
        [previous[key] for key in relation_diff.retired],
        prior.components if prior is not None else {},
        manifests,
    )
    if undeclared:
        breaches.append(
            Breach(
                kind=BreachKind.relation_retirement_not_declared,
                retired=len(undeclared),
                relation_keys=undeclared,
            )
        )
    return relation_diff


def _approval_applies(
    approval: RetirementApproval | None,
    to_version: str,
    diff: TransitionDiff,
    relation_diff: RelationDiff | None = None,
) -> bool:
    retired_relations = relation_diff.retired if relation_diff is not None else []
    return (
        approval is not None
        and approval.candidate_version == to_version
        and list(approval.retired_component_ids) == diff.retired
        and list(approval.retired_relation_keys) == retired_relations
    )
""",
)
edit(
    X,
    """    approval: RetirementApproval | None = None,
) -> TransitionDecision:
""",
    """    approval: RetirementApproval | None = None,
    prior_relations: Mapping[str, RelationFact] | None = None,
    candidate_relations: Mapping[str, RelationFact] | None = None,
) -> TransitionDecision:
""",
)
edit(
    X,
    """    :param approval: An explicit human decision for this exact transition, if any.
    :return: The decision, carrying the diff, every breach and the inputs it relied on.
""",
    """    :param approval: An explicit human decision for this exact transition, if any.
    :param prior_relations: The current version's relations, keyed by relation key;
        required when ``candidate_relations`` is given and a version is current.
    :param candidate_relations: The candidate's relations, keyed by relation key; when
        ``None`` the relation rule is not evaluated and ``relation_diff`` stays unset.
    :return: The decision, carrying the diff, every breach and the inputs it relied on.
    :raises ValueError: If ``candidate_relations`` is given without ``prior_relations``
        while a version is current.
""",
)
edit(
    X,
    """                component_ids=undeclared,
            ))
    return TransitionDecision(
""",
    """                component_ids=undeclared,
            ))
    relation_diff = _relation_clause(
        prior, prior_relations, candidate_relations, manifests, breaches
    )
    return TransitionDecision(
""",
)
edit(
    X,
    """        approval_applied=bool(breaches) and _approval_applies(approval, to_version, diff),
    )
""",
    """        approval_applied=bool(breaches)
        and _approval_applies(approval, to_version, diff, relation_diff),
        relation_diff=relation_diff,
    )
""",
)

# ------------------------------------------------------- docs/recsys reversal script
R = "docs/recsys/catalogue-reversal.sql"
edit(
    R,
    """-- This removes only the additive canonical catalogue and the additive review-ledger
-- surface. It deliberately preserves the five proof-of-concept recsys tables and never
-- requests dependency propagation. The four additive columns on the legacy tables are
-- removed as well, so a rolled-back revision sees exactly the shape it expects.
--
-- The review status above was reset to pending when the rule-stamp and rule-record
-- columns were added; it needs the named reviewer again.
""",
    """-- This removes only the additive canonical catalogue, the additive review-ledger
-- surface and the additive relation-evidence table. It deliberately preserves the five
-- proof-of-concept recsys tables and never requests dependency propagation. The six
-- additive columns on the legacy tables are removed as well, so a rolled-back revision
-- sees exactly the shape it expects.
--
-- The review status above was reset to pending when the rule-stamp and rule-record
-- columns were added, and again when the relation-evidence table and the relation-key
-- and evidence-digest columns were added; it needs the named reviewer again.
""",
)
edit(
    R,
    """BEGIN;

DROP TABLE IF EXISTS recsys_review_ledger_entry;
""",
    """BEGIN;

DROP TABLE IF EXISTS recsys_relation_evidence;
DROP TABLE IF EXISTS recsys_review_ledger_entry;
""",
)
edit(
    R,
    """ALTER TABLE recsys_component_link DROP COLUMN IF EXISTS resolution_rules;
""",
    """ALTER TABLE recsys_component_link DROP COLUMN IF EXISTS resolution_rules;
ALTER TABLE recsys_component_link DROP COLUMN IF EXISTS relation_key;
ALTER TABLE recsys_component_link DROP COLUMN IF EXISTS evidence_digest;
""",
)


def _diagnose(text: str, old: str) -> list[str]:
    """Show where an anchor nearly matched, so one screen fixes it.

    :param text: The file as it stands.
    :param old: The anchor that was not found exactly once.
    :return: Indented report lines.
    """
    report: list[str] = []
    anchor_lines = old.splitlines()
    first = next((line for line in anchor_lines if line.strip()), "")
    report.append(f"    expected first line: {first!r}")
    lines = text.splitlines()
    hits = [number for number, line in enumerate(lines) if first.strip() in line]
    if not hits:
        report.append("    first line not found anywhere")
    for number in hits[:4]:
        report.append(f"    L{number + 1}: {lines[number]!r}")
        offset = anchor_lines.index(first)
        for step, expected in enumerate(anchor_lines[offset:], start=0):
            actual = lines[number + step] if number + step < len(lines) else "<eof>"
            if actual != expected:
                column = next(
                    (i for i, (a, b) in enumerate(zip(actual, expected)) if a != b),
                    min(len(actual), len(expected)),
                )
                report.append(
                    f"      first difference at L{number + step + 1} col {column + 1}: "
                    f"file {actual[column:column + 24]!r} vs anchor "
                    f"{expected[column:column + 24]!r}"
                )
                break
        else:
            report.append("      every anchor line matches here (count problem only)")
    return report


def _git(root: Path, *args: str) -> str:
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def main(argv: list[str]) -> int:
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 2
    root = Path(argv[0]).resolve()
    check_only = "--check" in argv[1:]
    problems: list[str] = []

    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if branch != BRANCH:
        problems.append(f"branch is {branch}, expected {BRANCH}")
    if _git(root, "status", "--porcelain"):
        problems.append("worktree is not clean")

    new_files: list[tuple[Path, bytes]] = []
    for source in sorted(PKG.rglob("*")):
        if source.is_dir() or "__pycache__" in source.parts:
            continue
        target = root / source.relative_to(PKG)
        if target.exists():
            problems.append(f"new file already exists: {source.relative_to(PKG)}")
        new_files.append((target, source.read_bytes()))

    texts: dict[str, str] = {}
    for rel, old, new in EDITS:
        if rel not in texts:
            path = root / rel
            if not path.is_file():
                problems.append(f"missing file: {rel}")
                texts[rel] = ""
                continue
            texts[rel] = path.read_text(encoding="utf-8")
        count = texts[rel].count(old)
        if count != 1:
            problems.append(f"{rel}: anchor found {count}x")
            problems.extend(_diagnose(texts[rel], old))
            continue
        texts[rel] = texts[rel].replace(old, new, 1)

    for rel, text in texts.items():
        if rel.endswith(".py") and text:
            try:
                compile(text, rel, "exec")
            except SyntaxError as error:
                problems.append(f"{rel}: edited text does not compile: {error}")

    if problems:
        print("NOTHING WRITTEN. Problems:")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print(f"OK: {len(new_files)} new files, {len(EDITS)} edits in {len(texts)} files")
    if check_only:
        return 0
    for target, data in new_files:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    for rel, text in texts.items():
        (root / rel).write_text(text, encoding="utf-8")
    print("written")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
