"""Regulatory repository reader: one directory per edition, each with a manifest.

Layout::

    <root>/<edition label>/edition.yaml      edition, effective_date, merged, ...
    <root>/<edition label>/<document>.md     the edition's document, in one or more formats
    <root>/<edition label>/<document>.pdf

A new edition arrives as a reviewed pull request that adds a directory. The manifest's
``merged`` flag stands in for "the pull request was merged": only an edition whose manifest says
``merged: true`` is listed. An edition with ``merged: false``, with no flag, or with no manifest
is never listed and cannot be fetched, so nothing from an unreviewed edition is loaded (the
reader fails closed, because a checkout may include open pull request branches).

The reader reports each edition's own dates in the attributes. Marking an older edition as
superseded from the new edition's effective date is the sweep's job: both stay listed, and the
older one stays available for earlier dates.

When a document exists in several formats the Markdown is the item content and the other
formats are named in the ``formats`` attribute.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from datetime import date
from functools import partial
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, JsonValue, StrictStr

from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.sources import attributes as attr
from kp.sources.base import ItemMetadata
from kp.sources.errors import MalformedSourceDataError
from kp.sources.files import (
    media_type_for,
    parse_file,
    read_file,
    require_directory,
    sha256_hex,
    walk_files,
)
from kp.sources.snapshot import ReadItem, ScannedItem, SnapshotReader, fingerprint

logger = logging.getLogger(__name__)

MANIFEST_NAME = "edition.yaml"
_FORMAT_PREFERENCE = (".md", ".pdf")


class _Manifest(BaseModel):
    """The edition manifest. ``edition`` must be quoted text so ``2026.10`` stays itself."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    edition: StrictStr
    effective_date: date
    merged: bool = False
    domain: str | None = None
    superseded_from: date | None = None
    withdrawn_from: date | None = None
    title: str | None = None


class RegulatoryRepoReader(SnapshotReader):
    """Read the editions of a regulatory document from a repository checkout.

    :param root: The repository folder holding one directory per edition
    """

    def __init__(self, root: Path) -> None:
        super().__init__()
        self._root = root

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves.

        :return: The regulatory repository
        """
        return SourceKind.REGULATORY_REPO

    def _scan(self) -> list[ScannedItem]:
        require_directory(self._root)
        entries: list[ScannedItem] = []
        for directory in sorted(self._root.iterdir()):
            if directory.name.startswith(".") or not directory.is_dir():
                continue
            manifest = self._merged_manifest(directory)
            if manifest is None:
                continue
            documents = _documents(directory)
            if not documents:
                logger.warning("Edition has no documents", extra={"edition": manifest.edition})
            for name, files in sorted(documents.items()):
                item = self._read(manifest, name, files)
                entries.append(ScannedItem.of(item, partial(self._reread, directory, name)))
        return entries

    def _reread(self, directory: Path, name: str) -> ReadItem | None:
        manifest = self._merged_manifest(directory)
        files = _documents(directory).get(name)
        if manifest is None or files is None:
            return None
        return self._read(manifest, name, files)

    def _merged_manifest(self, directory: Path) -> _Manifest | None:
        """The edition's manifest, or ``None`` when it is missing or not merged."""
        manifest = _read_manifest(directory)
        if manifest is None:
            return None
        return manifest if manifest.merged else None

    def _read(self, manifest: _Manifest, name: str, files: list[Path]) -> ReadItem:
        chosen = min(files, key=lambda path: _format_rank(path.suffix))
        content = read_file(chosen)
        key = ItemKey(source=self.kind, item_id=name, version=manifest.edition)
        signals: dict[str, JsonValue] = {
            attr.EDITION_LABEL: manifest.edition,
            attr.EFFECTIVE_DATE: manifest.effective_date.isoformat(),
            attr.MERGED: True,
            attr.SUPERSEDED_FROM: _iso(manifest.superseded_from),
            attr.WITHDRAWN_FROM: _iso(manifest.withdrawn_from),
            attr.DOMAIN: manifest.domain,
            attr.DOCUMENT: name,
            attr.FORMATS: [*sorted(path.suffix for path in files)],
        }
        title = manifest.title or name.replace("-", " ").title()
        return ReadItem(
            key=key,
            fingerprint=fingerprint(sha256_hex(content), signals),
            title=title,
            modified_at=None,
            content=content,
            metadata=ItemMetadata(
                native_id=chosen.relative_to(self._root).as_posix(),
                media_type=media_type_for(chosen),
                title=title,
                attributes=signals,
            ),
        )


def _documents(directory: Path) -> dict[str, list[Path]]:
    """The edition's documents by name (path without suffix), each with its formats."""
    documents: dict[str, list[Path]] = defaultdict(list)
    for path in walk_files(directory):
        relative = path.relative_to(directory)
        if relative.as_posix() != MANIFEST_NAME:
            documents[relative.with_suffix("").as_posix()].append(path)
    return documents


def _read_manifest(directory: Path) -> _Manifest | None:
    path = directory / MANIFEST_NAME
    if not path.is_file():
        # Without a manifest nothing says the edition was reviewed, so it is not listed.
        logger.warning("Edition directory has no manifest", extra={"directory": directory.name})
        return None
    manifest = parse_file(
        path,
        lambda data: _Manifest.model_validate(yaml.safe_load(data)),
        "Edition manifest",
        errors=(ValueError, yaml.YAMLError),
    )
    if manifest.edition != directory.name:
        raise MalformedSourceDataError(f"Edition label differs from directory: {directory.name}")
    return manifest


def _format_rank(suffix: str) -> tuple[int, str]:
    lowered = suffix.lower()
    if lowered in _FORMAT_PREFERENCE:
        return (_FORMAT_PREFERENCE.index(lowered), lowered)
    return (len(_FORMAT_PREFERENCE), lowered)


def _iso(value: date | None) -> str | None:
    return value.isoformat() if value else None


__all__ = ["MANIFEST_NAME", "RegulatoryRepoReader"]
