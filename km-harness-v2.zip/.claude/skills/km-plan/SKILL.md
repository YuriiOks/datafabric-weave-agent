---
name: km-plan
description: Use before /km-build to turn a design file or a one-line goal into a build plan with slices per layer. Arguments a task id, then a design path or the goal.
argument-hint: <task-id> <designs/file.md | one-line goal>
disable-model-invocation: true
effort: xhigh
---

# km-plan

Goal: a plan that builders can execute without asking the orchestrator what to do. The plan
is the contract of /km-build. Think hard: a wrong cut of slices costs a whole build.
Output: work/plans/$0.md. No code is written or changed here.

Arguments: $0 is the task id: lower case letters, digits and hyphens, at most 30 characters,
else print "usage: /km-plan <task-id> <design path | goal>" and stop. An id that starts with
"pr-" is also refused (it collides with /km-review-pr names). The rest of $ARGUMENTS
after the id is a path under designs/ or kb/, or a one-line goal. Empty: same usage, stop.
Run id: km-plan-$0-<date>.

## 1 Inputs
- kb/conventions/layers.md must exist, and kb/conventions/<layer>.md for every layer the
  plan will use (kb/conventions/capture/ when the task is in CAPTURE_REPO). Missing: tell the
  owner "run /km-conventions <layer>" and stop.
- A design file: read it whole. A goal: write it back as three lines (goal, done when, left
  out) in the plan and treat it as the ask.
- The conventions of the layers involved, and kb/verified/ files the design cites. A design
  fact that is not Observed or verified is Reported: the plan checks it against code before
  a slice depends on it.
- The code the change touches: more than 5 files or 60 KB, delegate to km-reader (output
  kb/base/plan-$0-<n>.md, or kb/capture/ for CAPTURE_REPO); otherwise read it yourself.
  Facts about code reach the plan as path:line.
- If work/plans/$0.md exists, read it and update in place: keep slice ids, mark changed
  slices with the date. If work/builds/$0.md exists, never change a slice whose state is
  committed; say so in the reply and add a new slice instead.

## 2 The plan: work/plans/$0.md
Lines at most 100 characters. Sections in order:
- Header lines: Task, Date, Status (draft or ready), Clone (path of the clone to work in),
  Branch (feat/<ticket-or-task>-<short-slug>, lower case ASCII; the ticket key only if the
  owner gave it), Base (origin/main), Conventions (kb/conventions/ for BASE_REPO,
  kb/conventions/capture/ for CAPTURE_REPO; chosen by the clone), Advisor calls used (0 of 3).
- Goal, Done when (answerable yes or no), Left out.
- Slices: one table, one row per slice. Columns: Id (S1, S2), Layer, Agent (km-build-<layer>),
  Owned paths (exact files or folders, including the slice's test files or test folder; no
  overlap between slices, tests included), Does (two lines), Tests
  (test files and the named tests to run), Needs (slice ids), Check (layer commands, from
  the conventions file).
- Contracts: every interface between slices (route and payload, schema, event, tool
  definition, shared type): one entry each with producer slice, consumer slices and the
  exact shape. A contract change in an existing interface is marked CHANGE.
- Order: waves. A wave holds slices with no Needs among them, at most 3 per wave, disjoint
  owned paths. Contract producers come before their consumers.
- Risks: what could go wrong, with a path:line. Say which slice touches access control,
  migrations or data deletion. For any of these, also write "level 6 go/no-go needed" here.
- Advisor: yes only for trigger A: a decision crosses two layers, or a contract is CHANGEd.
  Name the trigger and one concrete question. Access control, migrations and data deletion
  alone do not make it yes; they are the level 6 go/no-go of /km-build, not a plan-time call.
- Open questions: by role, what each blocks.

## 3 Rules for the cut
- A slice has one layer and one builder. A file belongs to one slice. A shared path from the
  Shared table of layers.md goes to the layer that owns it; the other layers consume it.
- Every behaviour change has a named test. A slice with no test says why.
- Never plan a path under .claude or .github, a secret, an env file, or a new dependency
  without a line in Risks that names it.
- Prefer the repo's existing patterns (cite the example). Do not plan refactors the goal does
  not need.
- Decide; do not defer. At most 2 open questions for the owner, only if they block a slice.

## 4 Review and finish
- Before Status ready, check every Owned path with `git -C <clone> ls-files <path>`; for a
  NEW path check its parent folder. A path that exists nowhere and is not marked NEW is fixed.
- Every kb file a reader wrote in step 1 (kb/base or kb/capture) is listed in
  kb/index.d/<run>.txt.
- A plan with a CHANGE contract or an Advisor yes: call km-advisor once now with the contract
  and the question in canon task form (goal, inputs as paths, reply: recommendation, reason,
  what would change its mind, risk of the other option). Apply the answer and record it under
  Contracts. Update Advisor calls used.
- Set Status ready when no open question blocks a slice, else draft.
- Write kb/log.d/<run>.txt (date, task, files, what was skipped).
- Print at most 10 lines: plan path, slices per layer with their wave, advisor use, open
  questions, next command: /km-build $0.
- Missing inputs, a goal too vague to cut into slices, or a denied command: log, tell the
  owner in two lines, stop.
