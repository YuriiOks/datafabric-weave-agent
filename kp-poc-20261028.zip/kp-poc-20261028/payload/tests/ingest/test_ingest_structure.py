"""Structure score: how each check moves the clause score and the document score."""

from __future__ import annotations

import pytest

from kp.ingest import TocEntry
from kp.ingest.structure import ClauseDraft, document_score, score_clauses, toc_findings


def _draft(
    number: str, *, title: str | None = None, page: int = 3, text: str = "Body."
) -> ClauseDraft:
    return ClauseDraft(
        number=number,
        title=title or f"Title {number}",
        heading_page=page,
        page=page,
        char_start=0,
        char_end=len(text),
        text=text,
    )


def _toc(number: str, *, title: str | None = None, page: int | None = 3) -> TocEntry:
    return TocEntry(number=number, title=title or f"Title {number}", page=page)


NUMBERS = ("1", "1.1", "1.2", "2")
DRAFTS = [_draft(number) for number in NUMBERS]
TOC = [_toc(number) for number in NUMBERS]


def test_us07_a_clean_structure_scores_one() -> None:
    scores = score_clauses(DRAFTS, TOC, check_pages=True)
    assert scores == (1.0, 1.0, 1.0, 1.0)
    assert document_score(scores, DRAFTS, TOC) == 1.0
    assert toc_findings(DRAFTS, TOC) == (True, [])


def test_us07_clause_missing_from_the_toc_loses_the_toc_checks() -> None:
    scores = score_clauses(DRAFTS, TOC[:-1], check_pages=True)
    assert scores[:3] == (1.0, 1.0, 1.0)
    # In-TOC (0.30) lost; sequence, parent and content (0.45) kept, of 0.75 that apply.
    assert scores[3] == pytest.approx(0.45 / 0.75)
    assert document_score(scores, DRAFTS, TOC[:-1]) < 0.85


def test_us07_title_and_page_disagreements_lower_the_score() -> None:
    toc = [_toc("1", title="Something else", page=9), *TOC[1:]]
    scores = score_clauses(DRAFTS, toc, check_pages=True)
    assert scores[0] == pytest.approx(0.75)
    assert score_clauses(DRAFTS, toc, check_pages=False)[0] == pytest.approx(0.75 / 0.9)


def test_us07_numbering_gap_lowers_the_sequence_check() -> None:
    drafts = [_draft("1"), _draft("1.1"), _draft("1.3"), _draft("2")]
    toc = [_toc(draft.number) for draft in drafts]
    scores = score_clauses(drafts, toc, check_pages=True)
    assert scores[2] == pytest.approx(0.75)
    assert scores[3] == 1.0


def test_us07_missing_parent_lowers_the_parent_check() -> None:
    drafts = [_draft("1"), _draft("2"), _draft("2.1.1")]
    scores = score_clauses(drafts, [], check_pages=False)
    assert scores[2] == pytest.approx(0.10 / 0.45)


def test_us07_empty_body_is_fine_for_a_heading_with_children_only() -> None:
    drafts = [_draft("1", text=""), _draft("1.1"), _draft("1.2", text="")]
    scores = score_clauses(drafts, [], check_pages=False)
    assert scores[0] == 1.0
    assert scores[2] == pytest.approx(0.35 / 0.45)


def test_us07_without_a_toc_only_structural_checks_apply() -> None:
    scores = score_clauses(DRAFTS, [], check_pages=True)
    assert scores == (1.0, 1.0, 1.0, 1.0)
    assert document_score(scores, DRAFTS, []) == 1.0
    assert toc_findings(DRAFTS, []) == (False, ["no table of contents found"])


def test_us07_toc_findings_list_every_difference() -> None:
    drafts = [_draft("1"), _draft("2"), _draft("3")]
    toc = [_toc("1"), _toc("2"), _toc("2"), _toc("4")]
    matches, findings = toc_findings(drafts, toc)
    assert not matches
    assert "table of contents lists 4 clauses, body has 3" in findings
    assert "table of contents lists a clause number more than once" in findings
    assert "listed but not found in the body: 4" in findings
    assert "found in the body but not listed: 3" in findings


def test_us07_long_difference_lists_are_shortened() -> None:
    drafts = [_draft(str(number)) for number in range(1, 13)]
    _, findings = toc_findings(drafts, [_toc("99")])
    assert any(finding.endswith("and 4 more") for finding in findings)


def test_us07_empty_document_scores_zero() -> None:
    assert document_score((), [], []) == 0.0
