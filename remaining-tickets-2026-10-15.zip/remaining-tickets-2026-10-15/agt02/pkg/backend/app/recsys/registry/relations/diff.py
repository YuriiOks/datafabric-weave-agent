"""Compare the relations of two builds by stable key.

The diff is pure: it says which relation keys were added, retired, changed or left
unchanged, and nothing else. Whether a retirement is allowed is the transition gate's
decision, made with the candidate's source manifests in hand; see
:func:`app.recsys.registry.transition.gate.evaluate_transition`.
"""

from __future__ import annotations

from typing import Iterable, Mapping

from pydantic import BaseModel, ConfigDict, Field

from app.recsys.contracts import LinkType
from app.recsys.registry.models import ComponentLink


class _RelationModel(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class RelationFact(_RelationModel):
    """One published relation, as the gate compares it."""

    relation_key: str = Field(pattern=r"^[0-9a-f]{64}$")
    src_id: str = Field(min_length=1)
    link_type: LinkType
    dst_id: str = Field(min_length=1)
    evidence_digest: str = Field(pattern=r"^[0-9a-f]{64}$")
    #: The source authorities whose declarations support the relation.
    evidence_authorities: tuple[str, ...] = Field(min_length=1)


class RelationDiff(_RelationModel):
    """The exact relation-level difference between two builds.

    Every list is required and sorted. An empty retirement is an empty list.
    """

    added: list[str]
    retired: list[str]
    changed: list[str]
    unchanged: list[str]


def relation_facts(links: Iterable[ComponentLink]) -> dict[str, RelationFact]:
    """Key every link by its relation key.

    :param links: Links produced by :func:`app.recsys.registry.links.build_links`.
    :return: Relation key to its fact.
    :raises ValueError: If a link carries no key, digest or evidence, or two links
        share a key. Either would mean the link was not built from a catalogue fact.
    """
    facts: dict[str, RelationFact] = {}
    for link in links:
        if link.relation_key is None or link.evidence_digest is None or not link.evidence:
            raise ValueError("link carries no relation key, digest or evidence")
        if link.relation_key in facts:
            raise ValueError("two links share one relation key")
        facts[link.relation_key] = RelationFact(
            relation_key=link.relation_key,
            src_id=link.src_id,
            link_type=link.link_type,
            dst_id=link.dst_id,
            evidence_digest=link.evidence_digest,
            evidence_authorities=tuple(
                sorted({entry.authority for entry in link.evidence})
            ),
        )
    return facts


def diff_relations(
    prior: Mapping[str, RelationFact], candidate: Mapping[str, RelationFact]
) -> RelationDiff:
    """Compute the exact relation-level difference between two builds.

    :param prior: The current build's relations, keyed by relation key.
    :param candidate: The candidate's relations, keyed by relation key.
    :return: Added, retired, changed and unchanged keys, each sorted. A relation is
        changed when its key survives and its evidence digest does not.
    """
    shared = prior.keys() & candidate.keys()
    return RelationDiff(
        added=sorted(candidate.keys() - prior.keys()),
        retired=sorted(prior.keys() - candidate.keys()),
        changed=sorted(
            key
            for key in shared
            if prior[key].evidence_digest != candidate[key].evidence_digest
        ),
        unchanged=sorted(
            key
            for key in shared
            if prior[key].evidence_digest == candidate[key].evidence_digest
        ),
    )
