---
name: km-build
description: "Use to build a planned task: work tree, builders per slice, checking levels 1 to 6, commits pushed to the task branch, draft pull request. Argument the task id with a plan in work/plans/."
argument-hint: <task-id>
disable-model-invocation: true
effort: high
---

# km-build

Goal: the plan in work/plans/$0.md is implemented in one work tree, checked on six levels,
committed, and pushed. Level 7 is the owner. You orchestrate; you never edit code yourself.
All code changes go through a builder. Starting /km-build is the owner's go (decision of
10 Nov) to push this task's branch after every commit and to open its draft pull request
(section 3b). Nothing else is posted or opened.
Task text templates are in ${CLAUDE_SKILL_DIR}/references/templates.md; the format of the
build file and the restart rules are in ${CLAUDE_SKILL_DIR}/references/build-file.md. Read both.
The fix loop brake, the decision journal and the error log (kb/errors.md) are in
${CLAUDE_SKILL_DIR}/references/fix-loop.md: read it before step 3.

Argument: $0 is the task id, else print "usage: /km-build <task-id>" and stop. Run id:
km-build-$0-<date>. Progress file: work/builds/$0.md, updated after every state change.

## 0 Preconditions, then stop and report if any fails
- work/plans/$0.md exists with Status ready. Else: "run /km-plan $0".
- kb/conventions/layers.md and the file of every layer in the plan exist, in the folder named
  by the plan's Conventions header (kb/conventions/ or kb/conventions/capture/). Else: name
  them. Below, <conv> means that folder; builder and km-test tasks get the full file path.
- Slices overlap in Owned paths, a wave has more than 3 slices, or a path is under .claude or
  .github: stop, tell the owner what to fix in the plan.
- A command is denied, a check needs a service that is not running, or a login or approval
  is needed: stop, write the reason to the build file and kb/log.d/<run>.txt, tell the owner
  in two lines. Do not try a variant.

## 1 Restart
If work/builds/$0.md exists, this is a continuation: follow the restart rules in the build
file reference, then go on from the first slice that is not committed. Never recreate a work
tree, branch or commit that exists. Git is the truth; the file is the log.

## 2 Work tree
- `git -C <clone> fetch origin`, then `git -C <clone> worktree add /home/user/km/work/wt/$0
  -b <branch> origin/main` with clone and branch from the plan header.
- Branch exists but the tree does not, or the tree is on another branch: stop and ask.
- Never run git in the clone's own checkout beyond this fetch and the worktree add. Never
  remove a work tree. Record tree, branch and base sha in the build file.

## 2b Baseline
Before any builder: for each layer the plan touches, run its lint and type command and one
existing test on the untouched tree, as the layer file's "Running checks in a fresh work
tree" item says (no installs, no env files). Record the commands and exit codes as the
baseline in the build file. A layer that cannot run (needs install, a service, a login):
stop, write two lines to the owner on what to install or start. Level 1 compares later
results with this baseline; a failure that was already in it is reported, not blamed.

## 3 Waves
Run the plan's waves in order. At most 3 agents at once in total (builders, km-test and
reviewers together), on disjoint paths. Per wave, in this order:
1. Builders. One task per slice from the template: slice pasted whole, contracts it uses
   (the real shape from earlier slices, see step 2), the work tree path, the full path of the
   conventions file, owned paths, reply format. Agent km-build-<layer>. Wait for all of them.
2. Producer check. For each slice that produced a contract or migration, compare the
   reply and the committed or written code with the plan's entry. If they differ, record it
   under Plan changes and paste the real shape into the consumer tasks; a CHANGE is advisor
   trigger A. A builder question the plan answers is answered from the plan; any other goes
   to Open for owner.
3. Attribute files. Compare `git -C <tree> status --short` with the union of the wave's
   owned paths and give each file to its slice. A file outside the union: send that builder
   back to undo it or justify it (one attempt). A builder that needs a file of another
   slice: if no slice owns it and nobody is running there, extend the slice and note it under
   Plan changes; if another slice owns it, run that slice first; if it changes a contract,
   that is advisor trigger A.
4. Level 1. Run the lint and type commands of every touched layer once, in the tree, and
   compare the exit codes with the baseline. A failure the reply hid is a failed attempt.
5. Level 2. km-test per slice (template). Source failures go back to the builder, test
   failures to km-test. km-test reruns at most once per slice.
6. Commit the slices one at a time, when levels 1 and 2 pass. Stage file by file from
   `git status --short`, only inside the slice's owned paths; skip env, key, cache and
   generated files and list them in the build file. Never `git add -A`, `.` or a folder
   path, never `-a`, `--amend` or `--no-verify`. Before committing, `git diff --cached
   --name-only` must hold only owned paths and nothing under .claude or .github. One commit
   per logical step: `<type>: <what>` in plain words, type from feat, fix, refactor, test,
   chore, docs. Write no attribution or session line by hand. Settings turn the environment's
   own lines off. If the environment still adds a tool-credit line, leave it (no amend),
   tell the owner once and go on. A session link line is a stop: no push, tell the owner.
   No ticket text beyond the key the owner gave. A failing commit hook is a failed check.
7. Record state, commit sha and attempts in the build file. Then push (section 3b).
Attempts per slice: at most 3 (first try, retry, retry after advice). Every builder pass
counts as one attempt, whether it follows a check, km-test or review. A slice that fails
twice triggers the advisor (trigger C). A third failure marks it blocked; slices that need it
are skipped; independent slices go on. Brake (fix-loop.md): the same failure twice in a row
goes straight to trigger C or to blocked with a Stuck block; no test is weakened, skipped or
deleted to pass; read kb/errors.md before any retry; a slice that needed over 2 attempts gets
an error-log entry. Non-trivial choices go to the journal in Plan changes.

## 3b Push and draft pull request (after EVERY commit, here and in steps 5 and 8)
Only you push; builders never run git writes. The session folder is not a git repository:
every gh command and the guard run in a subshell, `(cd /home/user/km/work/wt/$0 && <cmd>)`,
written <in-tree> below. Always push with an explicit destination, never a bare `git push`:
`git -C <tree> push -u origin <branch>` (first and every later push; a new branch may track
origin/main, so a bare push could go to main). Never --force, --force-with-lease or
--no-verify; never push main or a branch this skill did not create; never a tag push or a
delete.
- Pre-check, every time: `git -C <tree> rev-parse --abbrev-ref HEAD` equals the plan's branch,
  it matches feat/... and is not main, `git -C <tree> config branch.<branch>.merge` is not
  refs/heads/main, `git -C <tree> status --short` shows nothing staged under .claude,
  .github, kb, designs or work, no commit message carries a session link or a line the
  session wrote as attribution,
  and `<in-tree> /home/user/km/.claude/bin/pre-push-guard.sh --check` passes. A failed
  pre-check stops the push: report it, never bypass. Before gh pr create or gh pr edit the
  body file has no session link and no attribution line either.
- First pushed commit: open a DRAFT pull request at once. Write work/builds/$0-pr.md as
  /km-pr references/pr-body.md says (title line, blank, body); unknown sections say
  "pending", never invented results. Then: `(cd <tree> && gh pr create --draft --base main
  --head <branch> --title "<title>" --body-file /home/user/km/work/builds/$0-pr.md)`. If the
  epic or ticket key is unknown (plan, owner, Keys line, kb/private): still push, do not open
  the pull request, name the missing key in the build file and go on building.
- Later pushes: find the number each time with `(cd <tree> && gh pr list --head <branch>
  --json number,headRefName,isDraft)`. Edit only if headRefName equals the branch and it is a
  draft; otherwise stop and report. Then refresh the body from the live body
  (`(cd <tree> && gh pr view <n> --json body)`, merge your changes in, keep images, then
  `(cd <tree> && gh pr edit <n> --body-file <file>)`).
- Stays the owner's: ready for review, merge, close, approve, reviewers, labels, ticket
  status. Never run them.
- Checks: after a push, read the checks for that exact head, read-only
  (`(cd <tree> && gh pr checks <n>)` or `... gh pr view <n> --json statusCheckRollup`).
  Record the state in the build file and in
  the body's Checks section. A red required check caused by this push goes through the fix
  loop (fix-loop.md) and is pushed again.
- A push or gh command may raise an approval prompt: wait for it. Denied or timed out:
  write "push pending" in the build file, keep working locally, retry once at the next
  commit. Never use a variant command to get around a prompt; never choose a permanent allow.

## 4 Levels 3 and 4: review round 1
When all slices are committed or blocked, run the procedure of /km-code-review on the work
tree: read /home/user/km/.claude/skills/km-code-review/SKILL.md and references/routing.md
and follow them with name $0 and tag r1 (it is not callable through the Skill tool; do not
rewrite it here). Its report is work/reviews/$0.md. The proven findings of severity
blocker and should-fix are the work list. Nits and questions are not fixed; they go to the
owner. Unclear findings go to the owner too.

## 5 Level 5: fix loop, review round 2
- Group the proven findings by owned path and send each group to the builder of that slice
  (fix template: finding text, path:line, the fix suggested; owned paths; nothing else).
  Then levels 1 and 2 again, commit as `fix: <what>`, one commit per group, and push (3b).
- Round 2: follow the same skill files again with name $0 and tag r2; it limits itself to
  the files changed since round 1 and appends to the report under "Round 2".
- Two rounds at most. What is still proven and open after round 2 goes to "Open for owner".
  Builders get one fix pass per round, not more.

## 6 Level 6: advisor go or no-go
Only if the diff against origin/main touches the Risky areas in layers.md (access control,
migrations, data deletion) or the plan said so. One km-advisor call (template) with the
review report and the build file. A no-go is reported as no-go with the reasons; do not start
a third round. Safe diffs skip this level; write "not needed" in the build file.

## 7 Advisor rules
- Triggers: A a decision crosses two layers or changes a contract; B evidence conflicts after
  km-verifier ran on the claims in dispute; C the same slice failed twice; D the go or no-go
  of level 6. Nothing else justifies a call.
- At most 3 calls per task, counting those made in /km-plan; the count is in the build file.
  A fourth need: stop and put the question to the owner.
- Task text carries the question, the evidence as paths and path:line, and the options. Apply
  the answer in the build file under Advisor calls: trigger, question, answer in one line.

## 8 Finish
- Fill the Summary section of work/builds/$0.md: branch, tree, commits (sha and subject), a
  table per slice with levels 1 to 6, Open for owner (open journal questions included), Not
  done, Advisor calls, Stuck blocks, next step.
- Write kb/log.d/<run>.txt (date, task, files, what was skipped, what was denied).
- Print at most 12 lines: branch and tree path, commit count, per-level result, the open
  findings count, advisor calls used, push state, the draft pull request number or the
  missing key, check state for the head, and "next: read the diff, then /km-pr $0".
- Make sure the last commit is pushed and the pull request body is current (3b). Do not
  mark it ready.
