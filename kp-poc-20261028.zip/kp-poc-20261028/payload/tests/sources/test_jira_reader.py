"""Jira-like reader: US-05 (stories loaded; status moves cause no rework), reader side."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from kp.domain.enums import SourceKind
from kp.errors import ConfigurationError, SourceItemNotFoundError, SourceUnavailableError
from kp.sources import (
    ChangedItem,
    InvalidCursorError,
    InvalidReadRequestError,
    JiraExportReader,
    MalformedSourceDataError,
)
from kp.sources import attributes as attr
from kp.testing.dataset import SyntheticDataset

from .support import drain, ids, key, write_json

JIRA = SourceKind.JIRA
BASE = datetime(2026, 10, 1, 9, 0, tzinfo=UTC)


def _first(dataset: SyntheticDataset) -> Path:
    return dataset.path(dataset.truth.stories.first_export)


def _second(dataset: SyntheticDataset) -> Path:
    return dataset.path(dataset.truth.stories.second_export)


def _issue(number: int, updated: datetime, *, summary: str = "Story") -> dict[str, object]:
    return {
        "key": f"PAY-{number}",
        "fields": {
            "summary": f"{summary} {number}",
            "description": "",
            "acceptance_criteria": "",
            "status": {"name": "To Do"},
            "parent": None,
            "issuelinks": [],
            "labels": [],
            "updated": updated.isoformat(),
        },
    }


def _export(path: Path, issues: list[dict[str, object]]) -> Path:
    write_json(path, {"project": "PAY", "issues": issues})
    return path


def _fingerprints(reader: JiraExportReader, items: list[ChangedItem]) -> dict[tuple[str, str], str]:
    result: dict[tuple[str, str], str] = {}
    for item in items:
        fetched = reader.fetch(item.key)
        result[(fetched.key.item_id, fetched.key.version)] = str(
            fetched.metadata.attributes[attr.STORY_FINGERPRINT]
        )
    return result


def test_us05_first_sweep_loads_every_story(dataset: SyntheticDataset) -> None:
    reader = JiraExportReader(_first(dataset))

    items, _ = drain(reader)

    assert len(items) == dataset.truth.stories.story_count
    assert {item.key.item_id for item in items} == {f"PAY-{n}" for n in range(100, 107)}


def test_us05_story_content_keeps_acceptance_criteria_separate_from_the_description(
    dataset: SyntheticDataset,
) -> None:
    reader = JiraExportReader(_first(dataset))
    items, _ = drain(reader)
    fetched = reader.fetch(next(i.key for i in items if i.key.item_id == "PAY-104"))

    fields = json.loads(fetched.content)["fields"]

    assert fields["summary"] == "Accept permitted currencies on inbound transfers"
    assert fields["description"].startswith("Restrict the currency")
    assert fields["acceptance_criteria"].startswith("Given a transfer in an unlisted currency")
    assert "Given a transfer" not in fields["description"]
    assert fetched.metadata.media_type == "application/json"


def test_us05_links_and_parent_travel_in_the_attributes(dataset: SyntheticDataset) -> None:
    reader = JiraExportReader(_first(dataset))
    items, _ = drain(reader)
    by_id = {item.key.item_id: reader.fetch(item.key).metadata.attributes for item in items}

    assert by_id["PAY-103"][attr.PARENT_KEY] == "PAY-100"
    assert by_id["PAY-103"][attr.LINKS] == [
        {"link_type": "implements", "target_key": "REQ-002"},
        {"link_type": "relates to", "target_key": "PAY-102"},
    ]
    assert by_id["PAY-100"][attr.PARENT_KEY] is None
    assert by_id["PAY-100"][attr.LINKS] == []
    assert by_id["PAY-106"][attr.DOMAIN] == "cards"
    assert by_id["PAY-101"][attr.STATUS] == "Done"


def test_us05_status_only_change_keeps_the_story_fingerprint(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.stories
    old_reader = JiraExportReader(_first(dataset))
    old_items, cursor = drain(old_reader)
    old = _fingerprints(old_reader, old_items)

    new_reader = JiraExportReader(_second(dataset))
    new_items, _ = drain(new_reader, cursor)
    new = _fingerprints(new_reader, new_items)

    moved = [k for k in new if k[0] == truth.status_only_key]
    before = next(v for k, v in old.items() if k[0] == truth.status_only_key)
    assert len(moved) == 1
    assert new[moved[0]] == before
    assert (
        new_reader.fetch(key(JIRA, moved[0][0], moved[0][1])).metadata.attributes[attr.STATUS]
        == "In Progress"
    )


def test_us05_acceptance_criteria_change_alters_only_that_stories_fingerprint(
    dataset: SyntheticDataset,
) -> None:
    truth = dataset.truth.stories
    old_reader = JiraExportReader(_first(dataset))
    old_items, cursor = drain(old_reader)
    old = _fingerprints(old_reader, old_items)

    new_reader = JiraExportReader(_second(dataset))
    new_items, _ = drain(new_reader, cursor)
    new = _fingerprints(new_reader, new_items)

    by_story_old = {k[0]: v for k, v in old.items()}
    changed = {k[0] for k, v in new.items() if by_story_old[k[0]] != v}
    assert changed == {truth.criteria_changed_key}


def test_us05_only_the_two_edited_stories_get_a_new_version(dataset: SyntheticDataset) -> None:
    truth = dataset.truth.stories
    old_reader = JiraExportReader(_first(dataset))
    old_items, cursor = drain(old_reader)

    new_items, _ = drain(JiraExportReader(_second(dataset)), cursor)

    fresh = ids(new_items) - ids(old_items)
    assert {item_id for item_id, _ in fresh} == {truth.status_only_key, truth.criteria_changed_key}


def test_us05_a_folder_of_exports_reads_the_newest_state_of_each_story(
    data_root: Path, dataset: SyntheticDataset
) -> None:
    reader = JiraExportReader(data_root / "jira")

    items, _ = drain(reader)

    assert len(items) == dataset.truth.stories.story_count
    status = reader.fetch(
        next(i.key for i in items if i.key.item_id == dataset.truth.stories.status_only_key)
    ).metadata.attributes[attr.STATUS]
    assert status == "In Progress"


def test_us05_a_listed_version_that_was_updated_since_is_no_longer_fetchable(
    tmp_path: Path,
) -> None:
    path = _export(tmp_path / "e.json", [_issue(1, BASE)])
    reader = JiraExportReader(path)
    old_key = drain(reader)[0][0].key
    _export(path, [_issue(1, BASE + timedelta(hours=1))])

    with pytest.raises(SourceItemNotFoundError):
        reader.fetch(old_key)


def test_us05_next_sweep_starts_sixty_seconds_before_the_saved_position(tmp_path: Path) -> None:
    path = _export(
        tmp_path / "e.json",
        [
            _issue(1, BASE - timedelta(minutes=10)),
            _issue(2, BASE - timedelta(seconds=61)),
            _issue(3, BASE - timedelta(seconds=60)),
            _issue(4, BASE),
        ],
    )
    reader = JiraExportReader(path)
    _, cursor = drain(reader)

    items, _ = drain(reader, cursor)

    assert {item.key.item_id for item in items} == {"PAY-3", "PAY-4"}


def test_us05_overlap_and_page_size_default_to_sixty_seconds_and_one_hundred(
    tmp_path: Path,
) -> None:
    issues = [_issue(n, BASE + timedelta(seconds=n)) for n in range(1, 251)]
    reader = JiraExportReader(_export(tmp_path / "e.json", issues))

    first = reader.list_changed(None)
    second = reader.list_changed(first.next_cursor)
    third = reader.list_changed(second.next_cursor)

    assert [len(first.items), len(second.items), len(third.items)] == [100, 100, 50]
    assert [first.exhausted, second.exhausted, third.exhausted] == [False, False, True]


def test_us05_page_size_caps_the_limit_the_caller_asks_for(tmp_path: Path) -> None:
    issues = [_issue(n, BASE + timedelta(seconds=n)) for n in range(1, 8)]
    reader = JiraExportReader(_export(tmp_path / "e.json", issues), page_size=3)

    batch = reader.list_changed(None, limit=500)

    assert len(batch.items) == 3
    assert batch.exhausted is False


def test_us05_a_stopped_run_continues_from_its_last_saved_page_without_duplicates(
    tmp_path: Path,
) -> None:
    # Ten issues share one updated time: the overlap window must not make pages repeat.
    path = _export(tmp_path / "e.json", [_issue(n, BASE) for n in range(1, 11)])
    first = JiraExportReader(path).list_changed(None, limit=4)

    resumed, _ = drain(JiraExportReader(path), first.next_cursor, limit=4)

    seen = [item.key.item_id for item in first.items] + [item.key.item_id for item in resumed]
    assert sorted(seen) == sorted(f"PAY-{n}" for n in range(1, 11))
    assert len(seen) == len(set(seen))


def test_us05_unchanged_source_lists_only_the_overlap_and_keeps_the_same_position(
    tmp_path: Path,
) -> None:
    path = _export(tmp_path / "e.json", [_issue(1, BASE - timedelta(hours=2)), _issue(2, BASE)])
    reader = JiraExportReader(path)
    _, cursor = drain(reader)

    items, again = drain(reader, cursor)

    assert {item.key.item_id for item in items} == {"PAY-2"}
    assert again == cursor


def test_us05_items_are_ordered_by_updated_time(tmp_path: Path) -> None:
    path = _export(
        tmp_path / "e.json",
        [_issue(3, BASE + timedelta(seconds=3)), _issue(1, BASE + timedelta(seconds=1))],
    )

    items, _ = drain(JiraExportReader(path))

    assert [item.key.item_id for item in items] == ["PAY-1", "PAY-3"]
    assert items[0].modified_at == BASE + timedelta(seconds=1)


def test_us05_project_filter_limits_the_stories(dataset: SyntheticDataset) -> None:
    items, cursor = drain(JiraExportReader(_first(dataset), project_key="OTHER"))

    assert items == []
    assert cursor is None


def test_us05_unknown_status_or_missing_optional_fields_do_not_break_a_story(
    tmp_path: Path,
) -> None:
    path = tmp_path / "e.json"
    write_json(
        path,
        {
            "issues": [
                {"key": "PAY-9", "fields": {"summary": "Bare", "updated": BASE.isoformat()}},
            ]
        },
    )
    reader = JiraExportReader(path)

    attributes = reader.fetch(drain(reader)[0][0].key).metadata.attributes

    assert attributes[attr.STATUS] == ""
    assert attributes[attr.LINKS] == []
    assert attributes[attr.PROJECT] == "PAY"


def test_us05_issue_with_the_wrong_shape_raises(tmp_path: Path) -> None:
    path = tmp_path / "e.json"
    write_json(path, {"issues": [{"key": "PAY-1", "fields": {"summary": "No time"}}]})

    with pytest.raises(MalformedSourceDataError):
        drain(JiraExportReader(path))


def test_us05_missing_export_is_a_source_error(tmp_path: Path) -> None:
    with pytest.raises(SourceUnavailableError):
        drain(JiraExportReader(tmp_path / "gone.json"))


@pytest.mark.parametrize(
    "cursor",
    [
        "",
        "garbage",
        "jira1:x|2026-10-01T09:00:00+00:00|",
        "jira1:c|not-a-time|",
        "jira1:c|2026-10-01T09:00:00|k",
        "snap1:abc",
    ],
)
def test_us05_foreign_or_corrupt_cursor_is_refused(tmp_path: Path, cursor: str) -> None:
    reader = JiraExportReader(_export(tmp_path / "e.json", [_issue(1, BASE)]))

    with pytest.raises(InvalidCursorError):
        reader.list_changed(cursor)


def test_us05_limit_below_one_is_refused(tmp_path: Path) -> None:
    reader = JiraExportReader(_export(tmp_path / "e.json", [_issue(1, BASE)]))

    with pytest.raises(InvalidReadRequestError):
        reader.list_changed(None, limit=0)


def test_us05_a_run_resumed_from_a_partial_cursor_ends_on_the_normal_position(
    tmp_path: Path,
) -> None:
    issues = [_issue(n, BASE + timedelta(hours=n)) for n in range(1, 11)]
    path = _export(tmp_path / "e.json", issues)
    first = JiraExportReader(path).list_changed(None, limit=4)
    assert first.exhausted is False

    resumed, final_cursor = drain(JiraExportReader(path), first.next_cursor, limit=4)
    next_sweep, _ = drain(JiraExportReader(path), final_cursor)

    assert len(first.items) + len(resumed) == 10
    # The final cursor is the newest updated time again, so only the overlap is re-listed.
    assert [item.key.item_id for item in next_sweep] == ["PAY-10"]


@pytest.mark.parametrize(
    ("page_size", "overlap_seconds", "message"),
    [(0, 60, "page size"), (-5, 60, "page size"), (100, -1, "overlap")],
)
def test_us05_bad_settings_are_a_configuration_error_naming_the_setting(
    tmp_path: Path, page_size: int, overlap_seconds: int, message: str
) -> None:
    with pytest.raises(ConfigurationError, match=message):
        JiraExportReader(tmp_path / "e.json", page_size=page_size, overlap_seconds=overlap_seconds)


def test_us05_fetching_a_page_of_issues_does_not_parse_every_export_again(
    tmp_path: Path,
) -> None:
    first = _export(tmp_path / "a.json", [_issue(1, BASE)])
    other = _export(tmp_path / "b.json", [_issue(2, BASE + timedelta(seconds=1))])
    reader = JiraExportReader(tmp_path)
    items, _ = drain(reader)

    other.write_text("{broken", encoding="utf-8")  # a full re-read would now raise

    assert first.exists()
    assert reader.fetch(items[0].key).metadata.native_id == "PAY-1"


def test_us05_a_version_the_reader_has_not_listed_yet_is_found_after_one_fresh_read(
    tmp_path: Path,
) -> None:
    path = _export(tmp_path / "e.json", [_issue(1, BASE)])
    reader = JiraExportReader(path)
    drain(reader)

    _export(path, [_issue(1, BASE + timedelta(hours=1))])
    newer = key(JIRA, "PAY-1", (BASE + timedelta(hours=1)).isoformat())

    assert reader.fetch(newer).metadata.native_id == "PAY-1"
