---
pack_id: "bpc-sep26-v1"
local_id: "CORE-10"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Complete the qualified demonstration and parent acceptance handoff"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 1
scope: "foundation"
create_by_default: true
planned_start: "2026-09-28"
planned_due: "2026-09-28"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-09","CORE-14"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-10"
architecture_sections: ["delivery","evidence","operations"]
---

# Complete the qualified demonstration and parent acceptance handoff

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-10** is not a Jira key.
- Estimate: **1 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-28 → 2026-09-28 (D14–D14)**.
- Recommendation extension: **2026-09-29 → 2026-09-29 (D15–D15)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Leave a usable implementation, a truthful demo and a clear recovery handoff for Joseph and the team.

## Scope and contract

Use the real approved implementation and its evidence. Show each component type, its source provenance, a refresh failure/retry, denied or unavailable state, and retained publication recovery. Separate delivered capabilities from future architecture.

## Implementation sequence

1. Prepare a short walkthrough and status/evidence screenshots from the qualified build.
2. Write the operational steps for source credential ownership, approved refresh, failed jobs, source correction/quarantine, freshness alerts and rollback.
3. Link the exact deployment/config, code/CI references, remaining blockers and all parent/subtask acceptance evidence.
4. Walk through the runbook with Yurii and the nominated operator; record unresolved ownership or access gaps.
5. Update only verified issue completion fields through the normal team workflow; a date is not completion evidence.

## Acceptance criteria

- [ ] Demo covers all committed types and explicit failure states using real outputs.
- [ ] A named operator can follow refresh/failure/rollback steps without undocumented source credentials.
- [ ] Parent closure records match demonstrated scope and all blocking dependencies.
- [ ] Future recommender/model experiments are visibly distinct from shipped capability.

## Verification

- Perform a dry walkthrough from the runbook and verify every referenced evidence link.
- Confirm all imported Jira parent/subtask relationships and assignee/dates after creation through the workstation workflow.

## Evidence to attach

- Demo script, operator runbook, accepted evidence index and issue readback report.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

No speculative success narrative, external notification campaign or auto-closing unresolved parents.

## Preparation boundary

Runbook, evidence-index and demo preparation are separately estimated in CORE-14. This one-hour task is the final walkthrough of the qualified output and acceptance-link readback after CORE-09; it does not absorb documentation preparation or new implementation.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-09](CORE-09.md) must finish its stated contract boundary before this task starts.
- [CORE-14](CORE-14.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `delivery`, `evidence`, `operations`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
