"""Every declared reference occurrence is accounted for, per link type."""

from __future__ import annotations

import unittest

from app.recsys.contracts import LinkType
from app.recsys.registry.relations.counts import count_relations
from tests.recsys.registry.relations._builds import (
    agent_usage,
    build,
    build_export,
    widget_row,
)


class RelationCountTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result, cls.links = build()
        cls.counts = count_relations(cls.result.catalogue, cls.links)

    def test_every_link_type_is_counted(self):
        self.assertEqual(set(self.counts), {link_type.value for link_type in LinkType})

    def test_every_declared_occurrence_is_accepted_or_unresolved(self):
        for name, bucket in self.counts.items():
            with self.subTest(link_type=name):
                self.assertEqual(
                    bucket.declared_occurrences,
                    bucket.accepted_occurrences + bucket.unresolved_occurrences,
                )

    def test_every_accepted_occurrence_is_evidence_on_a_published_relation(self):
        for name, bucket in self.counts.items():
            with self.subTest(link_type=name):
                self.assertEqual(bucket.accepted_occurrences, bucket.published_evidence)

    def test_relations_match_the_published_links(self):
        for name, bucket in self.counts.items():
            with self.subTest(link_type=name):
                self.assertEqual(
                    bucket.relations,
                    sum(1 for link in self.links if link.link_type.value == name),
                )
                self.assertGreaterEqual(bucket.folded_duplicates, 0)

    def test_unresolved_occurrences_match_the_review_ledger(self):
        ledger_references = [
            entry
            for entry in self.result.ledger.entries
            if entry.kind == "reference" and entry.link_type is not None
        ]
        self.assertEqual(
            sum(bucket.unresolved_occurrences for bucket in self.counts.values()),
            len(ledger_references),
        )

    def test_the_fixture_mcp_column_is_three_unresolved_occurrences_and_no_relation(self):
        bucket = self.counts[LinkType.uses_mcp.value]
        self.assertEqual(bucket.relations, 0)
        self.assertEqual(bucket.unresolved_occurrences, 3)

    def test_the_rendering_names_its_units(self):
        rendered = self.counts[LinkType.uses_skill.value].as_dict()
        self.assertEqual(
            set(rendered),
            {
                "declared_occurrences",
                "accepted_occurrences",
                "published_evidence",
                "relations",
                "folded_duplicates",
                "unresolved_occurrences",
                "unresolved_by_outcome",
                "unattributed_unresolved",
            },
        )


class FoldingTests(unittest.TestCase):
    def test_a_repeated_declaration_is_counted_as_folded(self):
        result, links = build_export(agent_usage(widget_row("alpha-helper,alpha-helper")))
        bucket = count_relations(result.catalogue, links)[LinkType.uses_skill.value]
        self.assertGreaterEqual(bucket.folded_duplicates, 1)
        self.assertEqual(bucket.published_evidence - bucket.relations, bucket.folded_duplicates)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
