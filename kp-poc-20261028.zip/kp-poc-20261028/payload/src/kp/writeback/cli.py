"""``kp draft-spec <story-key> [--publish]``: the reference drafting client.

Reads a story, retrieves the rules and register rows it rests on, drafts a spec from the
latest governed template without a model, and prints it with its citation check. With
``--publish`` the draft goes through the same write tools an agent would call: a branch and
pull request, then the Jira story. Without it nothing is written anywhere.

The integrator wires this into ``kp.cli`` with ``add_parser(subparsers)``; the parsed
arguments carry ``handler`` (:func:`run`).
"""

from __future__ import annotations

import argparse
import sys
import uuid
from collections.abc import Callable
from collections.abc import Set as AbstractSet
from dataclasses import dataclass, field
from datetime import date

from pydantic import Field
from sqlalchemy import Connection

from kp.clock import Clock, SystemClock
from kp.config import Settings, load_settings
from kp.domain import DomainModel
from kp.errors import ConfigurationError, KpError
from kp.store import Database
from kp.writeback.citations import CitationReport, check_citations
from kp.writeback.drafter import TemplateDrafter
from kp.writeback.models import (
    CallContext,
    PublishSpecArguments,
    PublishSpecResult,
    UpdateJiraArguments,
    UpdateJiraResult,
)
from kp.writeback.ports import AuditSink, Drafter, DraftRequest
from kp.writeback.retrieval import (
    DatabaseRetriever,
    InMemorySessionRetrievals,
    LinkGraphCoverage,
    load_story,
)
from kp.writeback.service import JiraSyncService, SpecPublishingService
from kp.writeback.store import (
    DatabaseAuditSink,
    DatabaseReferenceResolver,
    SpecRepository,
    TemplateRepository,
)
from kp.writeback.tools import WriteTools

COMMAND = "draft-spec"
DEFAULT_SPEC_TYPE = "functional"
_CLIENT_NAME = "kp-draft-spec"


class DraftSpecReport(DomainModel):
    """What ``kp draft-spec`` produced.

    :ivar markdown: The drafted spec.
    :ivar citations: The citation check the figures below summarise (not part of the JSON output).
    :ivar skipped: Why nothing was drafted, when the story already has a merged spec.
    :ivar published: The pull request, when ``--publish`` was given.
    :ivar jira: The Jira update, when it succeeded.
    :ivar jira_error: Why the Jira update failed after retries; the pull request still stands.
    """

    story_key: str
    markdown: str
    citations: CitationReport | None = Field(default=None, exclude=True)
    rule_statements: int
    valid_citations: int
    flagged: int
    citation_rate: float
    citation_target: float
    open_items: tuple[str, ...] = ()
    published: PublishSpecResult | None = None
    jira: UpdateJiraResult | None = None
    jira_error: str | None = None
    skipped: str | None = None


@dataclass(frozen=True)
class DraftSpecRuntime:
    """Everything ``draft-spec`` needs, so tests can swap the writers.

    :ivar tools_factory: Builds the write tools; called only when publishing.
    """

    database: Database
    settings: Settings
    tools_factory: Callable[[InMemorySessionRetrievals], WriteTools]
    reference_domains: Callable[[Connection], Callable[[str], str | None]] | None = None
    drafter: Drafter = field(default_factory=TemplateDrafter)
    clock: Clock = field(default_factory=SystemClock)


def default_runtime(settings: Settings, database: Database) -> DraftSpecRuntime:
    """Wire the runtime from settings.

    :param settings: Platform settings
    :param database: The platform database
    :return: A runtime whose writers are chosen by mode when publishing starts
    """

    def tools(retrievals: InMemorySessionRetrievals) -> WriteTools:
        # Imported here: the adapters package sits above this lane and imports it.
        from kp.adapters.publishers import choose_writers  # noqa: PLC0415 - cycle, see above

        writers = choose_writers(settings, SystemClock())
        publisher, jira = writers.publisher, writers.jira
        audit: AuditSink = DatabaseAuditSink(database)
        return WriteTools(
            publishing=SpecPublishingService(
                database=database, settings=settings, publisher=publisher
            ),
            jira=JiraSyncService(database=database, settings=settings, jira=jira),
            retrievals=retrievals,
            audit=audit,
        )

    return DraftSpecRuntime(database=database, settings=settings, tools_factory=tools)


def draft_spec(
    story_key: str,
    *,
    runtime: DraftSpecRuntime,
    publish: bool = False,
    spec_type: str = DEFAULT_SPEC_TYPE,
    as_at: date | None = None,
    viewer_domains: AbstractSet[str] | None = None,
) -> DraftSpecReport:
    """Draft (and optionally publish) the spec of a story.

    :param story_key: The story to draft for
    :param runtime: Database, settings and writers
    :param publish: Open the pull request and update Jira
    :param spec_type: The kind of spec; the latest governed template of that type is used
    :param as_at: The date the rules are read at; defaults to today
    :param viewer_domains: When given, the draft rests only on material of these access
        domains (what a person looking at the draft may read); ``None`` for the local
        operator's own run, which sees everything
    :return: The draft with its citation check and, when published, the results
    :raises kp.errors.ConfigurationError: If ``viewer_domains`` is given and the runtime cannot
        place material in a domain
    :raises kp.errors.KpError: If the story, the template or a write target is missing, or
        the publish is refused or fails (any failure of the Jira update after publishing is
        reported in ``jira_error`` instead, so the pull request is never lost from the report)
    """
    day = as_at or runtime.clock.today()
    retrievals = InMemorySessionRetrievals()
    session_id = f"{_CLIENT_NAME}-{uuid.uuid4().hex}"
    with runtime.database.transaction() as connection:
        story = load_story(connection, story_key)
        merged = SpecRepository(connection).merged_spec_id(story_key)
        if merged is not None:
            # Loaded back as knowledge, the merged spec is the story's spec; a second draft would
            # compete with what a person reviewed and merged.
            return DraftSpecReport(
                story_key=story_key,
                markdown="",
                rule_statements=0,
                valid_citations=0,
                flagged=0,
                citation_rate=0.0,
                citation_target=runtime.settings.thresholds.citation_rate_target,
                skipped=f"The story already has a merged spec ({merged}); it is not drafted again",
            )
        template = TemplateRepository(connection).latest(spec_type)
        retrieval = DatabaseRetriever(
            connection, allowed=_visibility(runtime, connection, viewer_domains)
        ).retrieve(story, as_at=day)
        coverage = LinkGraphCoverage(connection)
        tests = {
            item.reference: tuple(coverage.tests_for(item.reference)) for item in retrieval.evidence
        }
    drafted = runtime.drafter.draft(
        DraftRequest(story=story, template=template, retrieval=retrieval, tests_by_reference=tests)
    )
    retrievals.record(session_id, [item.reference for item in retrieval.evidence])
    with runtime.database.transaction() as connection:
        report = check_citations(
            drafted.markdown,
            resolves=DatabaseReferenceResolver(connection).resolves,
            retrieved=retrievals.references(session_id, _CLIENT_NAME),
            target=runtime.settings.thresholds.citation_rate_target,
        )
    result = DraftSpecReport(
        story_key=story_key,
        markdown=drafted.markdown,
        citations=report,
        rule_statements=report.rule_statements,
        valid_citations=report.valid_statements,
        flagged=len(report.flagged),
        citation_rate=report.rate,
        citation_target=report.target,
        open_items=drafted.open_items,
    )
    if not publish:
        return result
    tools = runtime.tools_factory(retrievals)
    # The reference client is a local operator: it may write for the domain of the story it drafts.
    context = CallContext(
        session_id=session_id,
        caller=_CLIENT_NAME,
        agent=_CLIENT_NAME,
        domains=(story.domain,) if story.domain is not None else (),
    )
    published = tools.publish_spec(
        context,
        PublishSpecArguments(
            story_key=story_key,
            spec_markdown=drafted.markdown,
            template_id=drafted.template_id,
            template_version=drafted.template_version,
            coverage=drafted.coverage,
            open_items=drafted.open_items,
        ),
    )
    result = result.model_copy(update={"published": published})
    try:
        jira = tools.update_jira(context, UpdateJiraArguments(story_key=story_key))
    except KpError as exc:
        return result.model_copy(update={"jira_error": str(exc)})
    return result.model_copy(update={"jira": jira})


def _visibility(
    runtime: DraftSpecRuntime, connection: Connection, domains: AbstractSet[str] | None
) -> Callable[[str], bool] | None:
    """Build the test that keeps material outside ``domains`` out of a draft."""
    if domains is None:
        return None
    if runtime.reference_domains is None:
        raise ConfigurationError("This runtime cannot tell which domain a reference belongs to")
    domain_of = runtime.reference_domains(connection)
    return lambda reference: domain_of(reference) in domains


def add_parser(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Register ``draft-spec`` on the ``kp`` command line.

    :param subparsers: The subparsers action of the main parser
    :return: The new subparser, with ``handler`` set to :func:`run`
    """
    parser = subparsers.add_parser(COMMAND, help="Draft a spec for a story, optionally publish it")
    parser.add_argument("story_key", help="Tracker key of the story, e.g. ABC-123")
    parser.add_argument(
        "--publish", action="store_true", help="Open the pull request and update Jira"
    )
    parser.add_argument("--spec-type", default=DEFAULT_SPEC_TYPE, help="Kind of spec to draft")
    parser.add_argument(
        "--as-at", type=date.fromisoformat, default=None, help="Read the rules as at YYYY-MM-DD"
    )
    parser.set_defaults(handler=run)
    return parser


def run(args: argparse.Namespace, *, runtime: DraftSpecRuntime | None = None) -> int:
    """Execute ``draft-spec`` for parsed arguments.

    :param args: Parsed arguments (``story_key``, ``publish``, ``spec_type``, ``as_at``)
    :param runtime: A prepared runtime; built from the environment when omitted
    :return: 0 on success, 1 on any platform error or when Jira failed after publishing
    """
    try:
        if runtime is None:
            settings = load_settings()
            runtime = default_runtime(settings, Database.from_settings(settings))
        report = draft_spec(
            args.story_key,
            runtime=runtime,
            publish=args.publish,
            spec_type=args.spec_type,
            as_at=args.as_at,
        )
    except KpError as exc:
        sys.stderr.write(f"kp {COMMAND}: {exc}\n")
        return 1
    if report.skipped:
        sys.stdout.write(f"{report.skipped}\n")
        return 0
    if args.publish:
        sys.stdout.write(report.model_dump_json(indent=2, exclude={"markdown"}) + "\n")
    else:
        sys.stdout.write(report.markdown)
        sys.stderr.write(
            f"citations: {report.valid_citations}/{report.rule_statements} valid, "
            f"rate {report.citation_rate:.0%} against {report.citation_target:.0%}; "
            f"{report.flagged} flagged; nothing was written\n"
        )
    return 1 if report.jira_error else 0
