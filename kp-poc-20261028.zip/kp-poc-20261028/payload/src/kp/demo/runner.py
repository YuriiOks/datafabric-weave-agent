"""Run the demo: stage the data, build, judge the three lines, run the connectivity job."""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from pydantic import SecretStr

from kp.app import build_application
from kp.clock import FixedClock
from kp.config import Mode, Settings
from kp.demo.build import run_build
from kp.demo.connectivity import run_connectivity
from kp.demo.model import DemoOutcome
from kp.demo.staging import StagedData, find_dataset, stage
from kp.demo.week1 import evaluate_week1
from kp.demo.week2 import evaluate_week2
from kp.demo.week3 import evaluate_week3
from kp.errors import ConfigurationError

SPEC_REPOSITORY = "example-org/example-specs"
SPEC_PATH = "specs"
JIRA_FIELDS = ("status", "spec_link")
DATABASE_FILE = "kp-demo.db"
DATA_FOLDER = "var"
_NOTES = (
    "The drafter is a deterministic template, a stand-in for the model-backed client: the demo "
    "proves the guards around a draft (citations, targets, review, load-back), not its wording.",
    "Every number above comes from synthetic data. Nothing was sent anywhere: the spec "
    "publication is a local record and the Jira update is a dry run.",
    "A rule reaches a test only through a spec: the one spec a person merged before the first "
    "sweep gives clause 4.2.1 a test, so every other rule is listed as untested.",
)


@dataclass(frozen=True)
class DemoOptions:
    """What the command line asked for.

    :ivar data: The dataset folder; the bundled one when omitted.
    :ivar database: Where to create the database; a file in the working folder when omitted.
    :ivar workdir: Where the staged data, raw store, spec repository and database go.
    """

    data: Path | None
    database: Path | None
    workdir: Path


def demo_settings(staged: StagedData, workdir: Path, database: Path) -> Settings:
    """The settings the demo runs with: local mode, folders staged, generic write targets.

    :param staged: The staged dataset
    :param workdir: The working folder
    :param database: The database file
    :return: The settings
    """
    return Settings(
        mode=Mode.LOCAL,
        log_level="WARNING",
        database_url=SecretStr(f"sqlite+pysqlite:///{database}"),
        data_dir=workdir / DATA_FOLDER,
        document_library_root=staged.library,
        regulatory_repo_path=staged.regulatory,
        confluence_export_path=staged.confluence,
        jira_export_path=staged.jira,
        code_repo_path=staged.code_repo,
        identity_mapping_file=staged.identity_mapping,
        spec_repo=SPEC_REPOSITORY,
        spec_path=SPEC_PATH,
        jira_fields_allowed=JIRA_FIELDS,
    )


def _prepare(options: DemoOptions) -> Path:
    """Clear what an earlier run left in the working folder and pick the database file."""
    options.workdir.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(options.workdir / DATA_FOLDER, ignore_errors=True)
    for leftover in ("connectivity.db",):
        (options.workdir / leftover).unlink(missing_ok=True)
    if options.database is not None:
        if options.database.exists():
            raise ConfigurationError(
                f"{options.database.name} already exists; the demo creates its own database"
            )
        options.database.parent.mkdir(parents=True, exist_ok=True)
        return options.database
    database = options.workdir / DATABASE_FILE
    database.unlink(missing_ok=True)
    return database


def run_demo(options: DemoOptions) -> DemoOutcome:
    """Run the whole demo.

    :param options: The command line options
    :return: The three lines, the build facts and the connectivity table
    :raises kp.errors.ConfigurationError: If no dataset is found or the database exists
    """
    source = find_dataset(options.data)
    database = _prepare(options)
    staged = stage(source, options.workdir)
    clock = FixedClock(staged.demo_instant())
    settings = demo_settings(staged, options.workdir, database)
    application = build_application(settings, clock=clock, sleeper=lambda _seconds: None)
    try:
        build = run_build(application, staged)
        lines = (
            evaluate_week1(application, staged, build),
            evaluate_week2(application, staged, build),
            evaluate_week3(application, build, clock),
        )
    finally:
        application.close()
    connectivity = run_connectivity(settings, clock, options.workdir)
    return DemoOutcome(
        lines=lines,
        facts=build.facts(staged.demo_instant().date().isoformat()),
        connectivity=connectivity,
        notes=_NOTES,
    )
