# BPC three-week implementation ticket pack

Prepared 7 September 2026. This is a proposed Jira import package, not a report of created issues or implemented functionality.

## What to upload to the workstation agent

Upload this folder (or its ZIP), including the Markdown files in parents/, subtasks/ and reference/. The Markdown alone carries the technical contracts and both date profiles; manifest.json provides the same identifiers, estimates, dependencies and calendar in machine-readable form. The separate HTML is the visual planning index. Do not treat filenames such as CORE-01 as real Jira issue keys.

## Existing parents and proposed shared parent

- DTAA-1169 — **Enable suggesting relevant SKILLS** (screenshot: In Progress).
- DTAA-1347 — **Enable recommending MCP** (screenshot: To Do).
- DTAA-1345 — **Enable recommending AGENTS** (screenshot: To Do).
- FOUNDATION — **Establish shared component graph and AI delivery foundation** (proposed fourth parent; Jira key unresolved).

The screenshot gives 30 September 2026 as the existing parents’ due date. Current status, descriptions, assignees, issue types and epic membership must be read from Jira before mutation. Retain exact existing titles. Common identity, catalogue, graph/read, refresh and AI/evaluation services belong to the fourth parent, with dependency links from the type-specific work. If a fourth parent is unavailable, do not create an improvised hierarchy or duplicate the common work; record the board constraint for a revised mapping.

## Calendar and scope assumptions

**Confirmed start; planned window: 9–29 September 2026, 15 weekdays in Europe/London.** The user confirmed the start date as 9 September. Engine scope remains a separate pending choice; the default preserves the previous graph/Hub boundary. The existing parents retain their 30 September due date, one additional reserve day after the three-week window. Six focused engineering hours per person per working day is a planning assumption; check leave, bank calendars, other assignments and reviewer availability. No schedule is an unconditional delivery promise.

Select exactly one profile for the entire import:

1. **foundation (default): 26 subtasks, 134 estimated engineering hours.** Graph, controlled refresh, typed existing-Hub AI baseline, evidence policy and operating controls. Scheduled implementation/handoff ends 2026-09-28; the rest of the deadline window is contingency. This preserves the earlier engine-build boundary and does not automatically close recommendation parent stories.
2. **recommendations (scope confirmation required): 31 subtasks, 165 hours.** Adds one shared lexical recommendation baseline and type-specific evaluation. Scheduled finish 2026-09-29, with **zero final-chain slack inside the three-week window**. The parent deadline on 30 September adds one reserve day outside that window. This is a stretch proposal conditional on substantial reusable PoC code, prompt decisions and ready domain reviewers; it is not a credible new-build commitment. It does not include the complete future LLM/embedding/graph-boost recommender.

The technical core, policy and release acceptance stay with Yurii; Mayank owns bounded acquisition/adapters, shared UI and evidence preparation. Estimates describe execution work, not a visible ownership percentage.

## Read order

1. [Workstation import](01-WORKSTATION-IMPORT.md): resolve actual Jira fields/users and reconcile existing issues before creating anything.
2. [Execution calendar](02-EXECUTION-CALENDAR.md): one coherent resource/dependency schedule per profile.
3. [Scope and capacity](03-SCOPE-AND-CAPACITY.md): assumptions, gates, omitted architecture work and replan rules.
4. [Architecture snapshot](reference/ARCHITECTURE-CONTRACT.md): the full normative technical basis, including error and safety semantics.
5. Four parent files, then selected per-task Markdown in dependency order.

## Workstation prompt

> Read all files in this pack and use the default foundation profile unless I explicitly select recommendations. First produce the import preflight and honour the confirmed 9 September start, validate availability/current Jira hierarchy and resolve actual assignee identifiers. Once the required inputs are concrete, create/reconcile the selected parent/subtask plan under the existing AI Hub recommendations epic using the idempotent import procedure. Preserve existing unrelated fields and exact parent titles. Assign the specified implementers, set verified date fields, create correct dependency links and read back every result. Report blocked items and the local-ID-to-Jira-key mapping. Do not implement code, transition issues to Done or create the conditional/follow-on scope merely because its description is included.

## Evidence boundary

Task metadata comes from the supplied screenshot; architecture evidence is captured from the reviewed local revision. No bank checkout, current Jira account identity, live worker/auth capability or quality result was verified by this document task. CORE-01 reconciles implementation reuse after import; Jira creation preflight is a separate non-ticket step before CORE-01 can exist.
