"""Structured JSON logging with redaction.

Convention for every lane: a static message plus variable data in ``extra``::

    logger.info("Sweep finished", extra={"source": "jira", "items": 12})

Keys that look like secrets, and keys that usually carry request or response bodies, are
replaced by ``***`` before anything is written. Never interpolate values into the message.
"""

from __future__ import annotations

import json
import logging
import re
import sys
import traceback
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import IO

REDACTED = "***"

_SENSITIVE_KEY = re.compile(
    r"(secret|token|password|passwd|authorization|credential|api[_-]?key|cookie|"
    r"^body$|request_body|response_body|^payload$)",
    re.IGNORECASE,
)

# Attributes every LogRecord carries; anything else came from ``extra``.
_STANDARD_ATTRIBUTES = frozenset(
    logging.LogRecord("", 0, "", 0, "", (), None).__dict__.keys() | {"message", "asctime"}
)


def redact(values: Mapping[str, object]) -> dict[str, object]:
    """Return a copy of ``values`` with sensitive entries masked, recursively.

    :param values: Structured log fields
    :return: A new dict in which secret-like and body-like keys hold ``***``
    """
    return {key: _redact_value(key, value) for key, value in values.items()}


def _redact_value(key: str, value: object) -> object:
    if _SENSITIVE_KEY.search(key):
        return REDACTED
    if isinstance(value, Mapping):
        return redact({str(inner_key): inner for inner_key, inner in value.items()})
    return value


class JsonFormatter(logging.Formatter):
    """Format records as one JSON object per line, with redacted extras."""

    def format(self, record: logging.LogRecord) -> str:
        """Render ``record`` as a single JSON line.

        :param record: The record to render
        :return: The JSON text
        """
        payload: dict[str, object] = {
            "time": datetime.fromtimestamp(record.created, UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        extras = {k: v for k, v in record.__dict__.items() if k not in _STANDARD_ATTRIBUTES}
        payload.update(redact(extras))
        if record.exc_info and record.exc_info[0] is not None:
            # The exception class and the frames only. The message is left out because
            # database and validation errors repeat the parameters and the input they rejected.
            error_class, _, trace = record.exc_info
            payload["exception"] = (
                f"{error_class.__name__}\n{''.join(traceback.format_tb(trace))}".rstrip()
            )
        return json.dumps(payload, default=str, sort_keys=True)


def configure_logging(level: str = "INFO", stream: IO[str] | None = None) -> None:
    """Install the JSON handler on the root logger, replacing earlier handlers.

    :param level: A standard level name such as ``INFO``
    :param stream: Where to write; defaults to standard error
    """
    handler = logging.StreamHandler(stream if stream is not None else sys.stderr)
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
