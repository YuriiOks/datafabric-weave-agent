"""Interfaces the sweep needs from other parts of the system.

The sweep never imports another lane's package. Whatever parses content, stores raw bytes or
builds source readers is plugged in through the protocols below, with fakes in tests.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Protocol

from sqlalchemy import Connection

from kp.domain import ItemKey, SourceItemVersion, SourceKind
from kp.sweep.models import SweepTarget

Sleeper = Callable[[float], None]


class ContentProcessor(Protocol):
    """Turns an admitted item version into parsed knowledge (clauses, rows, passages ...).

    The integrator connects the parsers behind this port.
    """

    def fingerprint(self, version: SourceItemVersion, content: bytes) -> str | None:
        """Hash the parts of the content whose change means the item must be reprocessed.

        A Jira story, for instance, ignores its status. Two versions with the same
        fingerprint are semantically the same, so the newer one causes no rework.

        :param version: The version being considered
        :param content: Its raw bytes
        :return: A fingerprint, or ``None`` to say every new version must be processed
        """
        ...

    def process(self, connection: Connection, version: SourceItemVersion, content: bytes) -> None:
        """Process one admitted version inside the sweep's page transaction.

        :param connection: The page's open connection; writes commit or roll back with the page
        :param version: The admitted version
        :param content: Its raw bytes
        """
        ...


class RawStore(Protocol):
    """Immutable store of raw bytes keyed by source, item and version."""

    def put(self, key: ItemKey, content: bytes) -> str:
        """Store the bytes once; storing the same bytes again is a no-op.

        :param key: The version the bytes belong to
        :param content: The raw bytes
        :return: The location to record in ``raw_location``
        :raises kp.sweep.errors.RawStoreConflictError: If other bytes are already stored
        """
        ...

    def get(self, location: str) -> bytes:
        """Read stored bytes back.

        :param location: A location returned by :meth:`put`
        :return: The stored bytes
        """
        ...


class TargetProvider(Protocol):
    """Builds the readers a command line sweep should run (the integrator's wiring)."""

    def targets(self, sources: Sequence[SourceKind]) -> Sequence[SweepTarget]:
        """Return the targets for the named sources.

        :param sources: Sources to sweep; empty means every configured source
        :return: One target per reader and scope
        """
        ...
