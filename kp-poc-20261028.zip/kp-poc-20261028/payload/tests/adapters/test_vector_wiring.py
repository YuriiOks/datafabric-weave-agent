"""The flag makes the sweep embed passages; real mode refuses the hashing stand-in."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import func, select

from kp.app import build_application
from kp.config import Mode, Settings
from kp.errors import ConfigurationError
from kp.store import Database, create_engine_for_url, schema
from kp.store.engine import IN_MEMORY_SQLITE
from world_support import build_world


def test_switching_the_vector_side_on_gives_the_swept_passages_vectors(
    committed_fixtures_dir: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("KP_SEARCH_VECTOR_ENABLED", "true")
    world = build_world(committed_fixtures_dir, tmp_path)
    try:
        with world.application.database.transaction() as connection:
            total = connection.execute(select(func.count()).select_from(schema.passage)).scalar()
            embedded = connection.execute(
                select(func.count())
                .select_from(schema.passage)
                .where(schema.passage.c.model_version.is_not(None))
            ).scalar()
        response = world.application.search.search(
            "which currency may an inbound credit transfer use?"
        )
    finally:
        world.application.close()

    assert total
    assert embedded == total
    assert response.vector_used is True


def test_with_the_flag_off_nothing_is_embedded(
    committed_fixtures_dir: Path, tmp_path: Path
) -> None:
    world = build_world(committed_fixtures_dir, tmp_path)
    try:
        with world.application.database.transaction() as connection:
            embedded = connection.execute(
                select(func.count())
                .select_from(schema.passage)
                .where(schema.passage.c.model_version.is_not(None))
            ).scalar()
    finally:
        world.application.close()

    assert embedded == 0


def test_real_mode_refuses_the_hashing_stand_in_for_an_embedding_model(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("KP_SEARCH_VECTOR_ENABLED", "true")
    local = Settings(_env_file=None, data_dir=tmp_path)
    database = Database(create_engine_for_url(IN_MEMORY_SQLITE))

    with pytest.raises(ConfigurationError, match="embedding model"):
        build_application(local.model_copy(update={"mode": Mode.REAL}), database=database)

    database.dispose()
