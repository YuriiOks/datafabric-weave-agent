"""Which access domain an item belongs to."""

from __future__ import annotations

from kp.adapters.domains import ItemDomains
from kp.domain import ItemRef, ItemType
from world_support import World


def _ref(item_type: ItemType, key: str) -> ItemRef:
    return ItemRef(item_type=item_type, key=key)


def test_each_item_type_is_placed_from_its_own_table(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        placer = ItemDomains(connection)

    assert placer.of(_ref(ItemType.CLAUSE, "2026.1:4.2.1")) == "payments"
    assert (
        placer.of(_ref(ItemType.REQUIREMENT, "requirements-register:Requirements:5")) == "payments"
    )
    assert placer.of(_ref(ItemType.REQUIREMENT, "requirements-register:Requirements:14")) == "cards"
    assert placer.of(_ref(ItemType.STORY, "PAY-101")) == "payments"
    assert placer.of(_ref(ItemType.STORY, "PAY-106")) == "cards"


def test_code_tests_and_fields_take_the_domain_they_were_reached_from(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        placer = ItemDomains(connection)

    field = _ref(ItemType.SCHEMA_FIELD, "schema/credit_transfer.schema.json#currency")
    assert placer.of(field, reached_from="payments") == "payments"
    assert placer.of(field) is None


def test_an_item_that_cannot_be_placed_has_no_domain(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        placer = ItemDomains(connection)

    assert placer.of(_ref(ItemType.CLAUSE, "not a clause")) is None
    assert placer.of(_ref(ItemType.CLAUSE, "1999.1:1.1")) is None
    assert placer.of(_ref(ItemType.SPEC, "spec-unknown")) is None
