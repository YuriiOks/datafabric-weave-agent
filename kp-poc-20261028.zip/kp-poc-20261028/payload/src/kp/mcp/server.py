"""The MCP protocol layer: ``initialize``, ``ping``, ``tools/list`` and ``tools/call``.

Transport-independent and stateless between messages, so the same server object serves stdio
and HTTP. The caller is passed in by the transport on every message; it is never read from
the message itself.
"""

from __future__ import annotations

import importlib.metadata
import json
import logging
from typing import Final

from pydantic import JsonValue

import kp
from kp.errors import KpError
from kp.mcp.errors import to_jsonrpc_error
from kp.mcp.jsonrpc import (
    ErrorCode,
    JsonRpcError,
    Message,
    Request,
    decode,
    error_response,
    parse_request,
    result_response,
)
from kp.tools import Caller, ToolRegistry

logger = logging.getLogger(__name__)

SUPPORTED_PROTOCOL_VERSIONS: Final = ("2025-06-18", "2025-03-26", "2024-11-05")


def _package_version() -> str:
    try:
        return importlib.metadata.version("kp")
    except importlib.metadata.PackageNotFoundError:
        return kp.__version__


SERVER_VERSION: Final = _package_version()


class McpServer:
    """A minimal MCP server over a tool registry.

    :param registry: The tools served, with access control and audit
    :param name: The server name reported in ``initialize``
    :param instructions: Optional usage hints reported in ``initialize``
    """

    def __init__(
        self, registry: ToolRegistry, *, name: str, instructions: str | None = None
    ) -> None:
        self._registry = registry
        self._name = name
        self._instructions = instructions

    @property
    def name(self) -> str:
        """The server name."""
        return self._name

    def handle_text(self, text: str, caller: Caller) -> Message | None:
        """Handle one raw JSON text.

        :param text: The message as received from the transport
        :param caller: The caller asserted by the transport
        :return: The response, or ``None`` when none is due (a notification)
        """
        try:
            return self.handle(decode(text), caller)
        except JsonRpcError as error:
            return error_response(None, error)

    def handle(self, message: JsonValue, caller: Caller) -> Message | None:
        """Handle one decoded message.

        :param message: A decoded JSON value
        :param caller: The caller asserted by the transport
        :return: The response, or ``None`` when none is due (a notification or a peer response)
        """
        try:
            request = parse_request(message)
        except JsonRpcError as error:
            return error_response(None, error)
        if request is None:
            return None
        try:
            result = self._dispatch(request, caller)
        except JsonRpcError as error:
            failure = error
        except KpError as error:
            failure = to_jsonrpc_error(error)
        except Exception as error:
            # No traceback: exception arguments may echo the agent's input.
            logger.error(
                "Unhandled error while serving a request",
                extra={"method": request.method, "error_class": type(error).__name__},
            )
            failure = JsonRpcError(ErrorCode.INTERNAL_ERROR, "Internal error")
        else:
            if request.request_id is None:
                return None
            return result_response(request.request_id, result)
        if request.is_notification:
            return None
        return error_response(request.request_id, failure)

    def _dispatch(self, request: Request, caller: Caller) -> JsonValue:
        if request.is_notification:
            return {}
        match request.method:
            case "initialize":
                return self._initialize(request.params)
            case "ping":
                return {}
            case "tools/list":
                return {
                    "tools": [
                        {
                            "name": definition.name,
                            "description": definition.description,
                            "inputSchema": definition.input_schema,
                        }
                        for definition in self._registry.definitions()
                    ]
                }
            case "tools/call":
                return self._call_tool(request.params, caller)
            case _:
                raise JsonRpcError(ErrorCode.METHOD_NOT_FOUND, "Method not found")

    def _initialize(self, params: dict[str, JsonValue]) -> JsonValue:
        requested = params.get("protocolVersion")
        version = (
            requested
            if isinstance(requested, str) and requested in SUPPORTED_PROTOCOL_VERSIONS
            else SUPPORTED_PROTOCOL_VERSIONS[0]
        )
        result: dict[str, JsonValue] = {
            "protocolVersion": version,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": self._name, "version": SERVER_VERSION},
        }
        if self._instructions is not None:
            result["instructions"] = self._instructions
        return result

    def _call_tool(self, params: dict[str, JsonValue], caller: Caller) -> JsonValue:
        name = params.get("name")
        if not isinstance(name, str) or not name:
            raise JsonRpcError(ErrorCode.INVALID_PARAMS, "params.name must be a tool name")
        arguments = params.get("arguments", {})
        if not isinstance(arguments, dict):
            raise JsonRpcError(ErrorCode.INVALID_PARAMS, "params.arguments must be an object")
        result = self._registry.call(caller, name, arguments)
        return {
            "content": [{"type": "text", "text": json.dumps(result.payload, ensure_ascii=True)}],
            "structuredContent": result.payload,
            "isError": False,
            "_meta": {"kp/callId": result.call_id},
        }
