"""Code repository reader: the tree of code and tests with a content hash per file."""

from __future__ import annotations

import hashlib
from pathlib import Path

from kp.domain.enums import SourceKind
from kp.sources import CodeRepoReader
from kp.sources import attributes as attr
from kp.sources.code_repo import VERSION_LENGTH

from .support import drain, ids

GITHUB = SourceKind.GITHUB


def _repo(data_root: Path) -> Path:
    return data_root / "code_repo"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_tree_lists_every_file_with_its_content_hash(data_root: Path) -> None:
    reader = CodeRepoReader(_repo(data_root))

    items, _ = drain(reader)

    expected = {
        path.relative_to(_repo(data_root)).as_posix(): _sha(path)
        for path in _repo(data_root).rglob("*")
        if path.is_file()
    }
    assert {i.key.item_id for i in items} == set(expected)
    for item in items:
        fetched = reader.fetch(item.key)
        digest = expected[item.key.item_id]
        assert item.key.version == digest[:VERSION_LENGTH]
        assert fetched.metadata.attributes[attr.CONTENT_SHA256] == digest
        assert hashlib.sha256(fetched.content).hexdigest() == digest


def test_files_are_classified_as_code_tests_schema_or_docs(data_root: Path) -> None:
    reader = CodeRepoReader(_repo(data_root))
    items, _ = drain(reader)

    kinds = {
        item.key.item_id: reader.fetch(item.key).metadata.attributes[attr.FILE_KIND]
        for item in items
    }

    assert kinds == {
        "README.md": "doc",
        "schema/credit_transfer.schema.json": "schema",
        "src/payments/inbound.py": "code",
        "tests/test_inbound.py": "test",
    }


def test_language_and_media_type_come_from_the_suffix(data_root: Path) -> None:
    reader = CodeRepoReader(_repo(data_root))
    items, _ = drain(reader)
    by_id = {item.key.item_id: reader.fetch(item.key).metadata for item in items}

    assert by_id["src/payments/inbound.py"].attributes[attr.LANGUAGE] == "python"
    assert by_id["src/payments/inbound.py"].media_type == "text/x-python"
    assert by_id["README.md"].attributes[attr.LANGUAGE] is None


def test_changed_file_is_a_new_version_and_the_old_one_is_not_a_deletion(
    data_root: Path,
) -> None:
    reader = CodeRepoReader(_repo(data_root))
    first, cursor = drain(reader)
    target = _repo(data_root) / "src" / "payments" / "inbound.py"
    old_version = next(i.key.version for i in first if i.key.item_id == "src/payments/inbound.py")

    target.write_text(target.read_text(encoding="utf-8") + "\n# edited\n", encoding="utf-8")
    items, _ = drain(reader, cursor)

    assert [(i.key.item_id, i.deleted) for i in items] == [("src/payments/inbound.py", False)]
    assert items[0].key.version != old_version


def test_unchanged_tree_reports_nothing(data_root: Path) -> None:
    reader = CodeRepoReader(_repo(data_root))
    _, cursor = drain(reader)

    items, again = drain(reader, cursor)

    assert items == []
    assert again == cursor


def test_removed_file_is_reported_deleted(data_root: Path) -> None:
    reader = CodeRepoReader(_repo(data_root))
    _, cursor = drain(reader)

    (_repo(data_root) / "tests" / "test_inbound.py").unlink()
    items, _ = drain(reader, cursor)

    assert [(i.key.item_id, i.deleted) for i in items] == [("tests/test_inbound.py", True)]


def test_new_file_is_listed_on_the_next_sweep(data_root: Path) -> None:
    reader = CodeRepoReader(_repo(data_root))
    _, cursor = drain(reader)

    (_repo(data_root) / "tests" / "test_outbound.py").write_text("x = 1\n", encoding="utf-8")
    items, _ = drain(reader, cursor)

    assert ids(items) == {("tests/test_outbound.py", _sha_prefix(b"x = 1\n"))}


def test_hidden_files_caches_and_symbolic_links_are_never_read(
    data_root: Path, tmp_path: Path
) -> None:
    repo = _repo(data_root)
    (repo / ".env").write_text("hidden\n", encoding="utf-8")
    (repo / ".git").mkdir()
    (repo / ".git" / "config").write_text("hidden\n", encoding="utf-8")
    (repo / "__pycache__").mkdir()
    (repo / "__pycache__" / "x.pyc").write_bytes(b"\x00")
    outside = tmp_path / "outside.txt"
    outside.write_text("outside\n", encoding="utf-8")
    (repo / "link.txt").symlink_to(outside)

    items, _ = drain(CodeRepoReader(repo))

    assert {i.key.item_id for i in items} == {
        "README.md",
        "schema/credit_transfer.schema.json",
        "src/payments/inbound.py",
        "tests/test_inbound.py",
    }


def _sha_prefix(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:VERSION_LENGTH]
