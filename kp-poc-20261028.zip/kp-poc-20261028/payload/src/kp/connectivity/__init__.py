"""Connectivity harness: gateway client, source adapters, storage, extraction and the report.

The harness proves the route (sign-in, tool servers, storage, extraction) before real data
depends on it. Local mode runs against stand-ins; the architect's own harness can replace the
job behind :class:`ConnectivityJob`.
"""

from kp.connectivity.adapters import (
    ConfluenceAdapter,
    GatewayToolAdapter,
    GitHubAdapter,
    JiraAdapter,
)
from kp.connectivity.cli import add_parser, handle
from kp.connectivity.discovery import SignatureStore, discover_routes
from kp.connectivity.errors import (
    BucketClientUnavailableError,
    ConnectivityError,
    ExtractionError,
    ExtractionUnavailableError,
    FidelityError,
    GatewayForbiddenError,
    GatewayProtocolError,
    ImmutableObjectError,
    InvalidObjectKeyError,
    MissingExtractorVersionError,
    SampleItemsError,
)
from kp.connectivity.evidence import Evidence, collect_evidence
from kp.connectivity.extraction import ExtractionClient, ensure_extractor_version
from kp.connectivity.fake_gateway import FakeGateway
from kp.connectivity.gateway import CallSink, GatewayClient
from kp.connectivity.models import (
    CallObservation,
    ExtractionRequest,
    ExtractionResponse,
    Manifest,
    Route,
    RunResult,
    SampleItem,
    SampleSet,
    ToolSignature,
)
from kp.connectivity.ports import ConnectivityJob, ExtractionPort, ObjectStore, PutOutcome
from kp.connectivity.records import ConnectivityStore, RunCallRecorder
from kp.connectivity.report import ExitReport, build_report, render_markdown
from kp.connectivity.runner import ConnectivityRunner
from kp.connectivity.samples import default_sample_items_path, load_sample_items
from kp.connectivity.scoring import CriterionResult, score_criteria
from kp.connectivity.storage import BucketObjectStore, LocalObjectStore, object_key
from kp.connectivity.stub_extractor import StubExtractionService
from kp.connectivity.tokens import (
    AccessToken,
    ClientCredentialsTokenProvider,
    TokenGrant,
    TokenProvider,
)
from kp.connectivity.wiring import Harness, build_harness, load_evidence

__all__ = [
    "AccessToken",
    "BucketClientUnavailableError",
    "BucketObjectStore",
    "CallObservation",
    "CallSink",
    "ClientCredentialsTokenProvider",
    "ConfluenceAdapter",
    "ConnectivityError",
    "ConnectivityJob",
    "ConnectivityRunner",
    "ConnectivityStore",
    "CriterionResult",
    "Evidence",
    "ExitReport",
    "ExtractionClient",
    "ExtractionError",
    "ExtractionPort",
    "ExtractionRequest",
    "ExtractionResponse",
    "ExtractionUnavailableError",
    "FakeGateway",
    "FidelityError",
    "GatewayClient",
    "GatewayForbiddenError",
    "GatewayProtocolError",
    "GatewayToolAdapter",
    "GitHubAdapter",
    "Harness",
    "ImmutableObjectError",
    "InvalidObjectKeyError",
    "JiraAdapter",
    "LocalObjectStore",
    "Manifest",
    "MissingExtractorVersionError",
    "ObjectStore",
    "PutOutcome",
    "Route",
    "RunCallRecorder",
    "RunResult",
    "SampleItem",
    "SampleItemsError",
    "SampleSet",
    "SignatureStore",
    "StubExtractionService",
    "TokenGrant",
    "TokenProvider",
    "ToolSignature",
    "add_parser",
    "build_harness",
    "build_report",
    "collect_evidence",
    "default_sample_items_path",
    "discover_routes",
    "ensure_extractor_version",
    "handle",
    "load_evidence",
    "load_sample_items",
    "object_key",
    "render_markdown",
    "score_criteria",
]
