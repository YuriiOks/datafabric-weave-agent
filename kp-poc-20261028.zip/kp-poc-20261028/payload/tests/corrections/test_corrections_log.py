"""US-24 (build side): corrections are logged with a reason and reported per spec."""

from __future__ import annotations

import json
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from sqlalchemy import Connection

from kp.cli import main
from kp.clock import FixedClock
from kp.corrections import (
    CorrectionLog,
    InvalidCorrectionError,
    UnknownSpecError,
    build_report,
    format_report,
)
from kp.domain import Citation, Spec, Template
from kp.store import Database, create_engine_for_url
from kp.writeback import SpecRepository, TemplateRepository

NOW = datetime(2026, 11, 20, 9, 0, tzinfo=UTC)
SHA = "a" * 64


def _spec(spec_id: str) -> Spec:
    return Spec(
        spec_id=spec_id,
        story_key=spec_id.removeprefix("spec-").upper(),
        path=f"specs/{spec_id}.md",
        template_id="functional-spec",
        template_version="1.0.0",
        branch=f"spec/{spec_id}",
        content_sha256=SHA,
        created_at=NOW,
    )


def _citation(spec_id: str, index: int, *, valid: bool, rule: bool = True) -> Citation:
    return Citation(
        citation_id=f"{spec_id}-{index}",
        spec_id=spec_id,
        statement_index=index,
        statement=f"Statement {index}",
        is_rule_statement=rule,
        reference="2026.1:4.2.1" if valid or index % 2 else None,
        resolved=valid,
        retrieved_in_session=valid,
    )


def _seed(connection: Connection) -> None:
    """Two drafted specs: one fully cited, one with a bad rule statement and a non-rule line."""
    TemplateRepository(connection).save(
        Template(
            template_id="functional-spec",
            version="1.0.0",
            spec_type="functional",
            body="# T",
            content_sha256=SHA,
        )
    )
    specs = SpecRepository(connection)
    specs.save(
        _spec("spec-pay-1"),
        [_citation("spec-pay-1", 0, valid=True), _citation("spec-pay-1", 1, valid=True)],
    )
    specs.save(
        _spec("spec-pay-2"),
        [
            _citation("spec-pay-2", 0, valid=True),
            _citation("spec-pay-2", 1, valid=False),
            _citation("spec-pay-2", 2, valid=False, rule=False),
        ],
    )


@pytest.fixture
def connection(database: Database) -> Iterator[Connection]:
    with database.transaction() as open_connection:
        _seed(open_connection)
        yield open_connection


def test_us24_a_correction_is_stored_with_its_reason_and_wrong_clause_flag(
    connection: Connection,
) -> None:
    log = CorrectionLog(connection, FixedClock(NOW))

    stored = log.add(
        "spec-pay-2",
        "  Cited 4.2.2 instead of 4.2.1  ",
        " The limit is in 4.2.2 ",
        wrong_clause=True,
    )

    (kept,) = log.for_spec("spec-pay-2")
    assert kept == stored
    assert (kept.correction, kept.reason, kept.wrong_clause) == (
        "Cited 4.2.2 instead of 4.2.1",
        "The limit is in 4.2.2",
        True,
    )
    assert kept.recorded_at == NOW
    assert log.for_spec("spec-pay-1") == ()


@pytest.mark.parametrize(("correction", "reason"), [("", "why"), ("what", "  "), ("x" * 4001, "y")])
def test_us24_a_correction_needs_text_and_a_reason_of_reasonable_size(
    connection: Connection, correction: str, reason: str
) -> None:
    with pytest.raises(InvalidCorrectionError):
        CorrectionLog(connection).add("spec-pay-1", correction, reason)


def test_us24_a_correction_of_an_unknown_spec_is_refused(connection: Connection) -> None:
    with pytest.raises(UnknownSpecError):
        CorrectionLog(connection).add("spec-nope", "what", "why")


def test_us24_the_report_gives_citation_rate_wrong_clause_and_correction_counts_per_spec(
    connection: Connection,
) -> None:
    log = CorrectionLog(connection, FixedClock(NOW))
    log.add("spec-pay-2", "Replaced clause", "Wrong clause", wrong_clause=True)
    log.add("spec-pay-2", "Reworded", "Unclear", wrong_clause=False)
    log.add("spec-pay-2", "Replaced another", "Wrong again", wrong_clause=True)

    report = build_report(connection)

    first, second = report.specs
    assert (first.spec_id, first.rule_statements, first.citation_rate) == ("spec-pay-1", 2, 1.0)
    assert (first.wrong_clause_count, first.correction_count) == (0, 0)
    assert (second.rule_statements, second.valid_statements) == (2, 1)  # one is not a rule
    assert second.citation_rate == 0.5
    assert (second.wrong_clause_count, second.correction_count) == (2, 3)
    assert (report.correction_count, report.wrong_clause_count) == (3, 2)
    assert report.citation_rate == 0.75


def test_us24_a_spec_without_rule_statements_has_a_full_citation_rate(
    database: Database,
) -> None:
    with database.transaction() as connection:
        TemplateRepository(connection).save(
            Template(
                template_id="functional-spec",
                version="1.0.0",
                spec_type="functional",
                body="# T",
                content_sha256=SHA,
            )
        )
        SpecRepository(connection).save(_spec("spec-pay-3"), [])
        report = build_report(connection)

    assert report.specs[0].citation_rate == 1.0


def test_us24_with_no_drafted_spec_the_report_says_so(database: Database) -> None:
    with database.transaction() as connection:
        report = build_report(connection)

    assert report.specs == ()
    assert report.citation_rate == 1.0
    assert format_report(report) == "No drafted specs to report on."


def test_us24_the_text_report_lists_every_spec_and_the_totals(connection: Connection) -> None:
    CorrectionLog(connection, FixedClock(NOW)).add(
        "spec-pay-1", "Fix", "Because", wrong_clause=True
    )

    text = format_report(build_report(connection))

    assert "spec-pay-1" in text
    assert "spec-pay-2" in text
    assert text.splitlines()[-1].startswith("all specs")


@pytest.fixture
def cli_database(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """A database file with two drafted specs, which the commands find through the settings."""
    url = f"sqlite+pysqlite:///{tmp_path / 'kp.db'}"
    database = Database(create_engine_for_url(url))
    database.create_all()
    with database.transaction() as open_connection:
        _seed(open_connection)
    database.dispose()
    monkeypatch.setenv("KP_MODE", "local")
    monkeypatch.setenv("KP_DATABASE_URL", url)


def test_us24_kp_corrections_add_then_report(
    cli_database: None, capsys: pytest.CaptureFixture[str]
) -> None:
    add = [
        "corrections",
        "add",
        "spec-pay-2",
        "--correction",
        "Swapped clause",
        "--reason",
        "Wrong",
    ]

    assert main([*add, "--wrong-clause"]) == 0
    assert "recorded correction" in capsys.readouterr().out
    assert main(["corrections", "report", "--json"]) == 0
    report = json.loads(capsys.readouterr().out)
    rows = {row["spec_id"]: row for row in report["specs"]}
    assert rows["spec-pay-2"]["wrong_clause_count"] == 1
    assert rows["spec-pay-2"]["correction_count"] == 1
    assert rows["spec-pay-1"]["correction_count"] == 0
    assert main(["corrections", "report"]) == 0
    assert "spec-pay-2" in capsys.readouterr().out


def test_us24_the_commands_say_what_is_wrong(
    cli_database: None, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["corrections", "add", "spec-nope", "--correction", "x", "--reason", "y"]) == 2
    assert "kp corrections" in capsys.readouterr().err
    assert main(["corrections", "add", "spec-pay-1", "--correction", "x", "--reason", " "]) == 2
    assert "needs both" in capsys.readouterr().err
