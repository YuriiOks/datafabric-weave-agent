import type { CSSProperties, ReactNode } from 'react'
import { safeHref } from './markdown'
import { isProd } from './model'
import type { ComponentSource } from './model'
import {
  emptyBoxStyle,
  linkStyle,
  monoStyle,
  mutedStyle,
  prodPillStyle,
  rowLabelStyle,
  rowStyle,
  rowValueStyle,
  sectionCardStyle,
  sectionHeaderStyle,
  sectionLabelStyle,
  stackedRowStyle,
} from './styles'

type Props = {
  source: ComponentSource
  /** Narrow screens stack each label above its value. */
  stacked?: boolean | undefined
}

/**
 * Where the component came from: the platform and environment, the file and revision, when and
 * how it was last pulled, and the registry's own source fields. Rows without a value are left out.
 */
export function SourceCard({ source, stacked = false }: Props) {
  const prod = isProd(source.environment)
  const href = source.url ? safeHref(source.url) : null
  const rows: Array<[string, ReactNode]> = []
  const add = (label: string, value: ReactNode | null) => {
    if (value !== null && value !== '') rows.push([label, value])
  }

  add('Origin system', source.originSystem)
  add(
    'Environment',
    source.environment === null ? null : prod ? (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        <ProdPill />
        <span style={mutedStyle}>Tested in Prod</span>
      </span>
    ) : (
      <span>
        {source.environment} <span style={mutedStyle}>(not Prod)</span>
      </span>
    ),
  )
  add('File path', source.path ? <span style={monoStyle}>{source.path}</span> : null)
  add('Revision', source.revision ? <span style={monoStyle}>{source.revision}</span> : null)
  add(
    'Last synced',
    source.lastSynced
      ? [source.syncTrigger, source.lastSynced].filter((part): part is string => !!part).join(' \u00b7 ')
      : source.syncTrigger,
  )
  add('Pulled by', source.pulledBy)
  add('Source', source.source)
  add('Source reference', source.sourceReference ? <span style={monoStyle}>{source.sourceReference}</span> : null)
  add(
    'External ids',
    source.externalIds.length > 0 ? (
      <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {source.externalIds.map(([system, value]) => (
          <span key={system + ':' + value}>
            <span style={mutedStyle}>{system}</span> <span style={monoStyle}>{value}</span>
          </span>
        ))}
      </span>
    ) : null,
  )
  add('Catalogue version', source.catalogueVersion ? <span style={monoStyle}>{source.catalogueVersion}</span> : null)

  return (
    <section style={sectionCardStyle} aria-label="Source">
      <div style={sectionHeaderStyle}>
        <h2 style={sectionLabelStyle}>Where it comes from</h2>
        {href && (
          <a href={href} style={linkStyle}>
            Open source
          </a>
        )}
      </div>
      {rows.length === 0 ? (
        <div style={{ padding: 'var(--space-4)' }}>
          <div style={emptyBoxStyle}>No source recorded.</div>
        </div>
      ) : (
        <dl style={{ margin: 0 }}>
          {rows.map(([label, value]) => (
            <div key={label} style={stacked ? stackedRowStyle : rowStyle}>
              <dt style={rowLabelStyle}>{label}</dt>
              <dd style={{ ...rowValueStyle, margin: 0 }}>{value}</dd>
            </div>
          ))}
        </dl>
      )}
      {prod && (
        <p style={captionStyle}>
          Only Prod is ingested from this platform, because components that are not tested must not be
          recommended.
        </p>
      )}
    </section>
  )
}

export function ProdPill() {
  return (
    <span style={prodPillStyle} title="Tested in Prod">
      <svg width="11" height="11" viewBox="0 0 16 16" aria-hidden="true">
        <path d="m3 8.5 3.2 3L13 4.8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      Prod
    </span>
  )
}

const captionStyle: CSSProperties = {
  margin: 0,
  padding: 'var(--space-3) var(--space-4)',
  fontSize: '0.75rem',
  lineHeight: 1.5,
  color: 'var(--color-text-tertiary)',
}
