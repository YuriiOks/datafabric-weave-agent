"""Small builders so tests read as the graph they set up."""

from __future__ import annotations

from kp.domain import ItemRef, ItemType, LinkState, Relation
from kp.links import LinkCandidate, LinkService


def item(item_type: ItemType, key: str) -> ItemRef:
    """Build an item endpoint."""
    return ItemRef(item_type=item_type, key=key)


def clause(number: str, edition: str = "2026.1") -> ItemRef:
    """Build a clause endpoint."""
    return item(ItemType.CLAUSE, f"{edition}:{number}")


def requirement(key: str) -> ItemRef:
    """Build a requirement endpoint."""
    return item(ItemType.REQUIREMENT, key)


def story(key: str) -> ItemRef:
    """Build a story endpoint."""
    return item(ItemType.STORY, key)


def spec(key: str) -> ItemRef:
    """Build a spec endpoint."""
    return item(ItemType.SPEC, key)


def code(key: str) -> ItemRef:
    """Build a code endpoint."""
    return item(ItemType.CODE, key)


def verifying_test(key: str) -> ItemRef:
    """Build a test endpoint."""
    return item(ItemType.TEST, key)


def state_link(service: LinkService, source: ItemRef, relation: Relation, target: ItemRef) -> None:
    """Assert a stated link."""
    service.assert_link(LinkCandidate.stated(source, relation, target))


def guess_link(
    service: LinkService,
    source: ItemRef,
    relation: Relation,
    target: ItemRef,
    score: float = 0.8,
    state: LinkState = LinkState.PROPOSED,
) -> None:
    """Assert a guessed link."""
    service.assert_link(
        LinkCandidate.guessed(
            source, relation, target, score=score, state=state, evidence="test evidence"
        )
    )
