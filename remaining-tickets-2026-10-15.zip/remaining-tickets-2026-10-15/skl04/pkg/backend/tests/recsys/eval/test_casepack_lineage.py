"""Case-pack lineage: one validated catalogue, one revision per source, a stable digest."""

from __future__ import annotations

import unittest

from app.recsys.contracts.sources import SourceAuthority
from app.recsys.eval.casepack.lineage import CasePackError, CasePackLineage, lineage_for

from . import casepack_support as support


class LineageTests(unittest.TestCase):
    def test_pins_snapshot_and_record_evidence(self) -> None:
        records = [support.record(1), support.record(2)]
        lineage = lineage_for(support.snapshot(), records)
        self.assertEqual(lineage.catalogue_id, support.CATALOGUE_ID)
        self.assertEqual(
            [pin.key() for pin in lineage.sources],
            [
                (
                    SourceAuthority.skills_repo.value,
                    support.SKILLS_CONFIGURATION,
                    support.SKILLS_REVISION,
                )
            ],
        )

    def test_digest_ignores_record_order(self) -> None:
        records = [support.record(1), support.record(2)]
        forward = lineage_for(support.snapshot(), records)
        backward = lineage_for(support.snapshot(), list(reversed(records)))
        self.assertEqual(forward.digest(), backward.digest())

    def test_digest_follows_access_policy(self) -> None:
        records = [support.record(1)]
        open_policy = lineage_for(support.snapshot(), records)
        pinned = lineage_for(support.snapshot(), records, access_policy_revision="read-policy-1")
        self.assertNotEqual(open_policy.digest(), pinned.digest())

    def test_refuses_captured_snapshot(self) -> None:
        with self.assertRaisesRegex(CasePackError, "validated"):
            lineage_for(support.snapshot(state="captured"), [support.record(1)])

    def test_refuses_record_of_another_catalogue(self) -> None:
        stray = support.record(2, catalogue_id="cat-" + "2" * 32)
        with self.assertRaisesRegex(CasePackError, "another catalogue"):
            lineage_for(support.snapshot(), [support.record(1), stray])

    def test_refuses_one_source_at_two_revisions(self) -> None:
        moved = support.record(2, evidence_items=[support.evidence(2, revision="commit-0ther")])
        with self.assertRaisesRegex(CasePackError, "more than one revision"):
            lineage_for(support.snapshot(), [support.record(1), moved])

    def test_sources_sorted_and_each_authority_pinned_once(self) -> None:
        export = support.evidence(
            3,
            authority=SourceAuthority.agent_hub_export,
            revision="export-7",
            configuration="registered-export-1",
        )
        records = [support.record(1), support.record(3, evidence_items=[export])]
        lineage = lineage_for(support.snapshot(), records)
        authorities = [pin.authority for pin in lineage.sources]
        self.assertEqual(authorities, sorted(authorities))
        data = lineage.model_dump()
        data["sources"] = [data["sources"][0], data["sources"][0]]
        with self.assertRaises(ValueError):
            CasePackLineage.model_validate(data)
