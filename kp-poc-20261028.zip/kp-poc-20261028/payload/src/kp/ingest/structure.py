"""Structure score of a parsed rulebook and the cross-check against its table of contents.

Each clause earns points for the checks that apply to it (weights add up to 1.0):

========  ======  ===============================================================
check     weight  passes when
========  ======  ===============================================================
in_toc    0.30    the table of contents lists the clause number
title     0.15    the heading title equals (or starts like) the listed title
sequence  0.25    the number directly follows the previous clause (no gap)
parent    0.10    the enclosing clause exists (or the clause is top level)
content   0.10    the clause has body text or sub-clauses
page      0.10    the heading sits on the page the table of contents gives (PDF only)
========  ======  ===============================================================

Checks that cannot apply (no table of contents, no page numbers) are left out and the
remaining weights are rescaled. The document score is the mean clause score times the
agreement between the numbers in the table of contents and the numbers found in the body
(intersection over union), so one lost or invented clause lowers it.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass

from kp.config import Thresholds
from kp.domain import parse_clause_number
from kp.ingest.headings import is_successor
from kp.ingest.models import StructureDecision, TocEntry

_WEIGHTS = {
    "in_toc": 0.30,
    "title": 0.15,
    "sequence": 0.25,
    "parent": 0.10,
    "content": 0.10,
    "page": 0.10,
}
_MAX_LISTED = 8
_SPACE = re.compile(r"\s+")


@dataclass(frozen=True)
class ClauseDraft:
    """A clause before it becomes a domain :class:`~kp.domain.Clause`.

    :ivar heading_page: Page of the heading line.
    :ivar page: Page where the body text starts (the page positions refer to).
    :ivar char_start: Offset of the body in that page's text.
    :ivar char_end: Offset of the body end, clipped to that page's text.
    :ivar text: The full body, which may continue on following pages.
    """

    number: str
    title: str
    heading_page: int
    page: int
    char_start: int
    char_end: int
    text: str


def classify(score: float, thresholds: Thresholds) -> StructureDecision:
    """Apply the structure thresholds.

    :param score: A document structure score
    :param thresholds: Provisional thresholds from settings
    :return: Proceed at or above ``structure_proceed``, review at or above
        ``structure_review``, otherwise block
    """
    if score >= thresholds.structure_proceed:
        return StructureDecision.PROCEED
    if score >= thresholds.structure_review:
        return StructureDecision.REVIEW
    return StructureDecision.BLOCK


def score_clauses(
    drafts: Sequence[ClauseDraft], toc: Sequence[TocEntry], *, check_pages: bool
) -> tuple[float, ...]:
    """Score each clause (see the module description for the checks).

    :param drafts: Clauses in reading order
    :param toc: Table-of-contents entries; may be empty
    :param check_pages: Compare heading pages with the table's page numbers
    :return: One score per draft, 0 to 1
    """
    listed = {entry.number: entry for entry in toc}
    numbers = {draft.number for draft in drafts}
    scores = []
    for index, draft in enumerate(drafts):
        entry = listed.get(draft.number)
        previous = drafts[index - 1].number if index else None
        following = drafts[index + 1] if index + 1 < len(drafts) else None
        parent_number = draft.number.rpartition(".")[0]
        has_children = following is not None and following.number.startswith(f"{draft.number}.")
        checks: dict[str, bool | None] = {
            "in_toc": entry is not None if toc else None,
            "title": _titles_agree(draft.title, entry.title) if entry else None,
            "sequence": is_successor(previous, draft.number),
            "parent": not parent_number or parent_number in numbers,
            "content": bool(draft.text) or has_children,
            "page": (
                draft.heading_page == entry.page
                if check_pages and entry is not None and entry.page
                else None
            ),
        }
        applicable = {name: passed for name, passed in checks.items() if passed is not None}
        earned = sum(_WEIGHTS[name] for name, passed in applicable.items() if passed)
        scores.append(earned / sum(_WEIGHTS[name] for name in applicable))
    return tuple(scores)


def document_score(
    clause_scores: Sequence[float], drafts: Sequence[ClauseDraft], toc: Sequence[TocEntry]
) -> float:
    """Combine clause scores with the agreement between table of contents and body.

    :param clause_scores: Scores from :func:`score_clauses`
    :param drafts: The clauses the scores belong to
    :param toc: Table-of-contents entries; may be empty
    :return: The structure score of the whole edition; 0 when no clause was found
    """
    if not clause_scores:
        return 0.0
    mean = sum(clause_scores) / len(clause_scores)
    if not toc:
        return mean
    listed = {entry.number for entry in toc}
    found = {draft.number for draft in drafts}
    return mean * len(listed & found) / len(listed | found)


def toc_findings(drafts: Sequence[ClauseDraft], toc: Sequence[TocEntry]) -> tuple[bool, list[str]]:
    """Cross-check the clause count and numbers against the table of contents.

    :param drafts: Clauses found in the body
    :param toc: Table-of-contents entries
    :return: Whether the table exists and lists exactly the numbers found, and findings
        describing every difference
    """
    if not toc:
        return False, ["no table of contents found"]
    listed = [entry.number for entry in toc]
    found = [draft.number for draft in drafts]
    findings = []
    if len(listed) != len(found):
        findings.append(f"table of contents lists {len(listed)} clauses, body has {len(found)}")
    if len(set(listed)) != len(listed):
        findings.append("table of contents lists a clause number more than once")
    missing = sorted(set(listed) - set(found), key=parse_clause_number)
    extra = sorted(set(found) - set(listed), key=parse_clause_number)
    if missing:
        findings.append(f"listed but not found in the body: {_join(missing)}")
    if extra:
        findings.append(f"found in the body but not listed: {_join(extra)}")
    return not findings, findings


def _join(numbers: Sequence[str]) -> str:
    shown = ", ".join(numbers[:_MAX_LISTED])
    return f"{shown} and {len(numbers) - _MAX_LISTED} more" if len(numbers) > _MAX_LISTED else shown


def _titles_agree(heading: str, listed: str) -> bool:
    first, second = (_SPACE.sub(" ", text).strip().casefold() for text in (heading, listed))
    return first.startswith(second) or second.startswith(first)
