# BPC workstation ticket pack

Start with [00-START-HERE.md](00-START-HERE.md). The default foundation profile contains 26 subtasks; the separately scoped lexical recommendation extension contains 31. Four parent specifications reuse three observed Jira keys and propose one new shared parent. Start is confirmed as 9 September; task dates are conditional on the selected profile, reuse and verified availability. Jira identities are resolved during preflight.

The bundled architecture snapshot contains the current design and contracts. Links inside that snapshot to older source material are historical references; the original evidence corpus is not included in this ticket pack.
