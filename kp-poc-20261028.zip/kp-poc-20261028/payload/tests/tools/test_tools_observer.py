"""The registry tells an observer about every answered call, after it is recorded."""

from __future__ import annotations

import pytest
from tools_fixtures import *  # noqa: F403 - pytest fixtures

from kp.clock import FixedClock
from kp.errors import AccessForbiddenError
from kp.tools import (
    Caller,
    IdentityMapping,
    ReadPorts,
    ToolResult,
    build_caller,
    build_read_registry,
)
from kp.tools.testing import InMemoryAudit

Seen = list[tuple[str, str, str]]


def _registry(
    ports: ReadPorts,
    mapping: IdentityMapping,
    audit: InMemoryAudit,
    clock: FixedClock,
    seen: Seen,
) -> tuple[object, Caller]:
    def observe(caller: Caller, tool: str, result: ToolResult) -> None:
        seen.append((caller.session_id, tool, result.call_id))

    registry = build_read_registry(ports, mapping, audit, clock=clock, observer=observe)
    return registry, build_caller(user="user-full-access", session_id="sess-observer")


def test_an_answered_call_is_observed_after_its_audit_record(
    ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    seen: Seen = []
    registry, caller = _registry(ports, mapping, audit, fixed_clock, seen)

    result = registry.call(caller, "rule_as_at", {"number": "4.2.1"})  # type: ignore[attr-defined]

    assert seen == [("sess-observer", "rule_as_at", result.call_id)]
    assert [record.call_id for record in audit.records] == [result.call_id]


def test_a_refused_call_is_recorded_but_not_observed(
    ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    seen: Seen = []
    registry, _ = _registry(ports, mapping, audit, fixed_clock, seen)
    nobody = build_caller(user="user-no-access", session_id="sess-refused")

    with pytest.raises(AccessForbiddenError):
        registry.call(nobody, "search", {"query": "currency"})  # type: ignore[attr-defined]

    assert seen == []
    assert audit.records[-1].refused
