"""The sweep engine: pages through sources, applies each page atomically, saves cursors.

Safety properties, and what provides them:

* A cursor is saved in the same transaction as the page it follows, so a stopped run
  restarts from the last processed page and nothing is processed twice (US-09).
* Versions are keyed source/item/version and never rewritten; a version seen again with the
  same decision changes nothing, so a run with no changes creates no rows and no work.
* A source that asks to slow down is waited for; one that keeps asking is left for a later
  run without counting as a failure.
* Failure counters are saved outside the rolled-back page, so repeated failures are visible.
  This holds for unexpected errors too (for example a processor that fails on one item): the
  attempt is counted and the error is raised again.
"""

from __future__ import annotations

import logging
import uuid
from collections.abc import Callable, Sequence
from functools import partial
from typing import TypeVar

from kp.clock import Clock
from kp.config import Thresholds
from kp.domain import ItemKey, Run, RunKind, RunOutcome, SourceKind, SweepCursor
from kp.errors import SourceError, SourceItemNotFoundError, SourceRateLimitedError
from kp.sources.base import ChangeBatch, FetchedItem
from kp.store import Database
from kp.sweep.apply import ApplyServices, PageApplier, PageResult
from kp.sweep.errors import SweepDeferredError
from kp.sweep.gate import ApprovalGate
from kp.sweep.models import (
    Alert,
    RateLimitPolicy,
    SweepSummary,
    SweepTarget,
    TargetStatus,
    TargetSummary,
)
from kp.sweep.ports import ContentProcessor, RawStore, Sleeper
from kp.sweep.store import SweepStore

logger = logging.getLogger(__name__)

_T = TypeVar("_T")
DEFAULT_PAGE_SIZE = 100


class Sweeper:
    """Sweeps source readers and records what changed.

    :param database: Where runs, cursors and item versions are stored
    :param clock: The time source
    :param processor: Receives every admitted version (a port; fake in tests)
    :param raw_store: Write-once store of raw bytes
    :param sleeper: Called with the seconds a source asked to wait; injectable for tests
    :param gate: The approval rules; defaults to :class:`ApprovalGate` with its defaults
    :param thresholds: Supplies the number of failures that raises an alert
    :param rate_limit: How long to wait before leaving a source for a later run
    :param page_size: Items requested per page
    """

    def __init__(
        self,
        database: Database,
        *,
        clock: Clock,
        processor: ContentProcessor,
        raw_store: RawStore,
        sleeper: Sleeper,
        gate: ApprovalGate | None = None,
        thresholds: Thresholds | None = None,
        rate_limit: RateLimitPolicy | None = None,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> None:
        self._database = database
        self._clock = clock
        self._services = ApplyServices(gate or ApprovalGate(), processor, raw_store)
        self._sleeper = sleeper
        self._thresholds = thresholds or Thresholds()
        self._rate_limit = rate_limit or RateLimitPolicy()
        self._page_size = page_size

    def run(self, targets: Sequence[SweepTarget]) -> SweepSummary:
        """Sweep every target once.

        :param targets: Readers with their scopes
        :return: What the run did; its outcome is ``succeeded`` only if every target completed
        :raises Exception: Any unexpected error, after the run is recorded as failed
        """
        run_id = uuid.uuid4().hex
        self._start_run(run_id, targets)
        tally = PageResult()
        summaries: list[TargetSummary] = []
        alerts: list[Alert] = []
        try:
            for target in targets:
                summary, alert = self._sweep_target(run_id, target, tally)
                summaries.append(summary)
                if alert is not None:
                    alerts.append(alert)
        except Exception:
            self._finish_run(run_id, RunOutcome.FAILED, tally)
            raise
        outcome = _outcome(summaries)
        self._finish_run(run_id, outcome, tally)
        return SweepSummary(
            run_id=run_id,
            outcome=outcome,
            targets=tuple(summaries),
            versions_recorded=tally.versions_recorded,
            state_changes=tally.state_changes,
            conflicts=tally.conflicts,
            work_items=tuple(tally.work_items),
            loaded_specs=tuple(tally.loaded_specs),
            alerts=tuple(alerts),
        )

    # Run bookkeeping ----------------------------------------------------------------------

    def _start_run(self, run_id: str, targets: Sequence[SweepTarget]) -> None:
        sources = tuple(dict.fromkeys(target.reader.kind for target in targets))
        now = self._clock.now()
        with self._database.transaction() as connection:
            store = SweepStore(connection)
            store.insert_run(
                Run(run_id=run_id, kind=RunKind.SWEEP, sources=sources, started_at=now)
            )
            settled = store.settle_due_supersessions(self._clock.today())
        logger.info("Sweep started", extra={"run_id": run_id, "settled": settled})

    def _finish_run(self, run_id: str, outcome: RunOutcome, tally: PageResult) -> None:
        with self._database.transaction() as connection:
            SweepStore(connection).finish_run(
                run_id,
                outcome,
                self._clock.now(),
                tally.versions_recorded + tally.state_changes,
            )
        logger.info("Sweep finished", extra={"run_id": run_id, "outcome": outcome.value})

    # One target ---------------------------------------------------------------------------

    def _sweep_target(
        self, run_id: str, target: SweepTarget, tally: PageResult
    ) -> tuple[TargetSummary, Alert | None]:
        source, scope = target.reader.kind, target.scope
        position = self._saved_position(source, scope)
        pages = 0
        try:
            while True:
                batch = self._call(
                    partial(target.reader.list_changed, position, limit=self._page_size)
                )
                fetched = self._fetch_page(target, batch)
                position = batch.next_cursor if batch.next_cursor is not None else position
                finished = batch.exhausted or batch.next_cursor is None
                with self._database.transaction() as connection:
                    page = PageApplier(
                        connection, self._services, run_id=run_id, now=self._clock.now()
                    ).apply(batch.items, fetched)
                    self._save_progress(SweepStore(connection), source, scope, position, finished)
                _merge(tally, page)
                pages += 1
                if finished:
                    return TargetSummary(
                        source=source, scope=scope, status=TargetStatus.COMPLETED, pages=pages
                    ), None
        except SweepDeferredError:
            self._record_attempt(source, scope, failed=False)
            logger.info(
                "Source asked to wait; remaining work left for a later run",
                extra={"source": source.value, "scope": scope, "pages": pages},
            )
            return TargetSummary(
                source=source, scope=scope, status=TargetStatus.DEFERRED, pages=pages
            ), None
        except SourceError as exc:
            alert = self._record_failure(source, scope)
            return TargetSummary(
                source=source,
                scope=scope,
                status=TargetStatus.FAILED,
                pages=pages,
                error=type(exc).__name__,
            ), alert
        except Exception:
            # The page transaction is already rolled back; count the failure outside it so
            # an item that fails every time (a poison item) reaches the alert threshold.
            self._record_failure(source, scope)
            raise

    def _fetch_page(self, target: SweepTarget, batch: ChangeBatch) -> dict[ItemKey, FetchedItem]:
        fetched: dict[ItemKey, FetchedItem] = {}
        for changed in batch.items:
            if changed.deleted:
                continue
            try:
                fetched[changed.key] = self._call(partial(target.reader.fetch, changed.key))
            except SourceItemNotFoundError:
                logger.warning(
                    "Listed item no longer exists at the source",
                    extra={"source": changed.key.source.value, "item_id": changed.key.item_id},
                )
        return fetched

    def _call(self, operation: Callable[[], _T]) -> _T:
        """Run a reader call, waiting as instructed when the source rate-limits.

        :raises SweepDeferredError: If the source keeps asking to wait
        """
        waits = 0
        while True:
            try:
                return operation()
            except SourceRateLimitedError as exc:
                wait = exc.retry_after_seconds
                if waits >= self._rate_limit.max_waits or wait > self._rate_limit.max_wait_seconds:
                    raise SweepDeferredError("Source rate limit outlasted the wait budget") from exc
                waits += 1
                logger.info("Waiting as the source instructed", extra={"seconds": wait})
                self._sleeper(wait)

    # Cursors and failures -----------------------------------------------------------------

    def _saved_position(self, source: SourceKind, scope: str) -> str | None:
        with self._database.transaction() as connection:
            cursor = SweepStore(connection).load_cursor(source, scope)
        return None if cursor is None else cursor.position

    def _save_progress(
        self,
        store: SweepStore,
        source: SourceKind,
        scope: str,
        position: str | None,
        finished: bool,
    ) -> None:
        now = self._clock.now()
        cursor = store.load_cursor(source, scope) or SweepCursor(
            source=source, scope=scope, updated_at=now
        )
        changes: dict[str, object] = {
            "position": position,
            "last_attempt_at": now,
            "updated_at": now,
        }
        if finished:
            changes.update(last_success_at=now, consecutive_failures=0)
        store.save_cursor(cursor.model_copy(update=changes))

    def _record_attempt(self, source: SourceKind, scope: str, *, failed: bool) -> int:
        now = self._clock.now()
        with self._database.transaction() as connection:
            store = SweepStore(connection)
            cursor = store.load_cursor(source, scope) or SweepCursor(
                source=source, scope=scope, updated_at=now
            )
            failures = cursor.consecutive_failures + (1 if failed else 0)
            store.save_cursor(
                cursor.model_copy(
                    update={
                        "last_attempt_at": now,
                        "updated_at": now,
                        "consecutive_failures": failures,
                    }
                )
            )
        return failures

    def _record_failure(self, source: SourceKind, scope: str) -> Alert | None:
        failures = self._record_attempt(source, scope, failed=True)
        logger.warning(
            "Sweep of source failed",
            extra={"source": source.value, "scope": scope, "consecutive_failures": failures},
        )
        if failures < self._thresholds.fetch_failures_before_alert:
            return None
        logger.error(
            "Source keeps failing; alert raised",
            extra={"source": source.value, "scope": scope, "consecutive_failures": failures},
        )
        now = self._clock.now()
        return Alert(
            source=source,
            scope=scope,
            consecutive_failures=failures,
            last_attempt_at=now,
            raised_at=now,
        )


def _merge(total: PageResult, page: PageResult) -> None:
    total.work_items.extend(page.work_items)
    total.loaded_specs.extend(page.loaded_specs)
    total.versions_recorded += page.versions_recorded
    total.state_changes += page.state_changes
    total.conflicts += page.conflicts


def _outcome(summaries: Sequence[TargetSummary]) -> RunOutcome:
    statuses = {summary.status for summary in summaries}
    if statuses <= {TargetStatus.COMPLETED}:
        return RunOutcome.SUCCEEDED
    if statuses == {TargetStatus.FAILED}:
        return RunOutcome.FAILED
    return RunOutcome.PARTIAL
