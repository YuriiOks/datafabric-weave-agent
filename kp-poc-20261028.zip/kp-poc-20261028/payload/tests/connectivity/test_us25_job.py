"""US-25: the connectivity job against stand-ins."""

from __future__ import annotations

import json
from datetime import timedelta

import pytest
from sqlalchemy import select

from connectivity.support import SOURCE_SECRET, USE_CASE, Stack
from kp.connectivity import (
    ConnectivityStore,
    ExtractionError,
    GatewayForbiddenError,
    MissingExtractorVersionError,
)
from kp.connectivity.digest import request_digest, sha256_hex
from kp.connectivity.ledger import load_run_results
from kp.connectivity.models import (
    ExtractionRequest,
    ExtractionResponse,
    ItemStatus,
    RunActivity,
    RunResult,
)
from kp.connectivity.storage import object_key
from kp.domain import ExtractionStatus, RunOutcome, SourceItemVersion, SourceKind
from kp.errors import SourceAuthRefusedError, SourceRateLimitedError
from kp.store.schema import mcp_call, run, source_item


def _items(stack: Stack) -> list[dict[str, object]]:
    with stack.database.transaction() as connection:
        return [dict(row._mapping) for row in connection.execute(select(source_item))]


def _calls(stack: Stack) -> list[dict[str, object]]:
    with stack.database.transaction() as connection:
        return [dict(row._mapping) for row in connection.execute(select(mcp_call))]


def _snapshot(stack: Stack) -> dict[str, tuple[int, bytes]]:
    """Every stored file with its modification time and content."""
    files = {}
    for store_root in (stack.raw, stack.markdown):
        root = store_root._root
        for path in sorted(root.rglob("*")):
            if path.is_file():
                files[str(path)] = (path.stat().st_mtime_ns, path.read_bytes())
    return files


def test_us25_nine_items_stored_with_markdown_manifest_and_rows(stack: Stack) -> None:
    result = stack.runner().run()

    assert result.outcome is RunOutcome.SUCCEEDED
    assert result.stored_count == 9
    rows = _items(stack)
    assert len(rows) == 9
    assert {row["source"] for row in rows} == {"confluence", "jira", "github"}
    for row in rows:
        raw_key = object_key(str(row["source"]), str(row["item_id"]), str(row["version"]))
        raw = stack.raw.get(raw_key)
        assert sha256_hex(raw) == row["content_sha256"]
        markdown = stack.markdown.get(f"{raw_key}.md")
        assert markdown.decode("utf-8").strip()
        manifest = json.loads(stack.markdown.get(f"{raw_key}.manifest.json"))
        assert manifest["content_sha256"] == row["content_sha256"]
        assert manifest["version"] == row["version"]
        assert row["extraction_status"] == "succeeded"
        assert row["extractor_version"] == manifest["extractor_version"]
        assert stack.markdown.key_of(str(row["markdown_location"])) == f"{raw_key}.md"
        assert stack.markdown.key_of(str(row["manifest_location"])) == f"{raw_key}.manifest.json"


def test_us25_item_and_call_records_are_written_under_a_run(stack: Stack) -> None:
    result = stack.runner().run()

    with stack.database.transaction() as connection:
        run_rows = [dict(row._mapping) for row in connection.execute(select(run))]
    assert [row["run_id"] for row in run_rows] == [result.run_id]
    assert run_rows[0]["kind"] == "connectivity"
    assert run_rows[0]["outcome"] == "succeeded"
    assert run_rows[0]["items_touched"] == 9
    calls = _calls(stack)
    assert len(calls) == 9
    assert {call["run_id"] for call in calls} == {result.run_id}
    assert {call["operation"] for call in calls} == {"tools/call"}
    assert all(call["http_status"] == 200 and call["error_class"] is None for call in calls)
    assert all(call["surviving_fields"] for call in calls)
    assert [item.run_id for item in _items_domain(stack)] == [result.run_id] * 9


def _items_domain(stack: Stack) -> tuple[SourceItemVersion, ...]:
    with stack.database.transaction() as connection:
        return ConnectivityStore(connection).items(SourceKind)


def test_us25_attachments_carry_their_parent(stack: Stack) -> None:
    stack.runner().run()

    parents = {item.item_id: item.attachment_parent for item in _items_domain(stack)}
    assert parents["conf-pdf"] == "7003"
    assert parents["jira-word"] == "SYN-103"
    assert parents["conf-headings"] is None


def test_us25_second_run_adds_nothing_and_overwrites_nothing(stack: Stack) -> None:
    first = stack.runner().run()
    rows_before = _items(stack)
    files_before = _snapshot(stack)

    second = stack.runner().run()

    assert first.stored_count == 9
    assert second.stored_count == 0
    assert {item.status for item in second.items} == {ItemStatus.UNCHANGED}
    assert _items(stack) == rows_before
    assert _snapshot(stack) == files_before
    assert stack.stub.requests.__len__() == 9  # the second run never asked for extraction again


def test_us25_changed_source_adds_one_version_and_keeps_the_old_one(stack: Stack) -> None:
    stack.runner().run()
    old_files = _snapshot(stack)

    stack.fake.edit_page("7001", "<h1>Operations overview</h1><p>Changed wording.</p>")
    second = stack.runner().run()

    assert second.stored_count == 1
    rows = [row for row in _items(stack) if row["item_id"] == "conf-headings"]
    assert sorted(str(row["version"]) for row in rows) == ["1", "2"]
    new_files = _snapshot(stack)
    assert all(new_files[path] == value for path, value in old_files.items())
    assert len(new_files) == len(old_files) + 3


def test_us25_token_expiry_mid_run_renews_once_and_the_run_continues(stack: Stack) -> None:
    def expire_after_four_calls(count: int) -> None:
        if count == 5:
            stack.fake.revoke_tokens()

    stack.fake.before_request = expire_after_four_calls

    result = stack.runner().run()

    assert result.outcome is RunOutcome.SUCCEEDED
    assert result.stored_count == 9
    assert stack.fake.token_requests == 2
    calls = sorted(_calls(stack), key=lambda call: str(call["call_id"]))
    refused = [call for call in calls if call["http_status"] == 401]
    assert len(refused) == 1
    assert refused[0]["error_class"] == "SourceAuthRefusedError"
    retried = calls[calls.index(refused[0]) + 1]
    assert retried["http_status"] == 200
    assert retried["token_refreshed"] is True
    assert sum(1 for call in calls if call["token_refreshed"]) == 1  # the renewal; sign-in is not


def test_us25_token_renewed_before_use_once_it_has_used_80_percent_of_its_life(
    stack: Stack,
) -> None:
    def pass_80_percent(count: int) -> None:
        if count == 4:
            stack.clock.set(stack.clock.now() + timedelta(seconds=1800 * 0.8))

    stack.fake.before_request = pass_80_percent

    result = stack.runner().run()

    assert result.stored_count == 9
    assert stack.fake.token_requests == 2
    assert not [call for call in _calls(stack) if call["http_status"] == 401]


def test_us25_second_refusal_stops_the_run_with_a_typed_error(stack: Stack) -> None:
    def refuse_everything_from_the_fifth_call(count: int) -> None:
        if count == 5:
            stack.fake.reject_all = True

    stack.fake.before_request = refuse_everything_from_the_fifth_call

    with pytest.raises(SourceAuthRefusedError):
        stack.runner().run()

    assert stack.fake.token_requests == 2  # sign-in plus exactly one forced renewal
    assert len(_items(stack)) == 4  # what was stored before the refusal is kept
    refused = [call for call in _calls(stack) if call["http_status"] == 401]
    assert len(refused) == 2
    with stack.database.transaction() as connection:
        outcome = connection.execute(select(run.c.outcome)).scalar_one()
    assert outcome == "failed"
    [kept] = load_run_results(stack.ledger_dir)
    assert kept.outcome is RunOutcome.FAILED
    assert kept.abort_reason == "SourceAuthRefusedError"
    assert len(kept.items) == 4


def test_us25_call_records_hold_a_digest_of_the_request_never_the_request(stack: Stack) -> None:
    stack.runner().run()

    calls = _calls(stack)
    expected = {
        request_digest(r.namespace, "tools/call", {"name": r.tool, "arguments": r.arguments})
        for r in stack.fake.requests
        if r.method == "tools/call"
    }
    assert {call["request_digest"] for call in calls} == expected
    needles = (
        "SYN-102",
        "att-5001",
        "docs/overview.md",
        "example-org",
        "page_id",
        "issue_key",
        USE_CASE,
        SOURCE_SECRET,
    )
    identifiers = {"call_id", "run_id", "request_digest", "called_at", "latency_ms"}
    for call in calls:
        text = json.dumps({k: str(v) for k, v in call.items() if k not in identifiers})
        assert not any(needle in text for needle in needles)
        assert set(str(call["request_digest"])) <= set("0123456789abcdef")
    assert all(len(str(call["request_digest"])) == 64 for call in calls)


def test_us25_credentials_never_reach_the_log(
    stack: Stack, caplog: pytest.LogCaptureFixture
) -> None:
    caplog.set_level("DEBUG")

    stack.runner().run()

    logged = " ".join(f"{record.getMessage()} {record.__dict__}" for record in caplog.records)
    assert SOURCE_SECRET not in logged
    assert "stand-in-secret" not in logged
    assert "stand-in-token" not in logged
    assert USE_CASE not in logged


def test_us25_discovery_keeps_signatures_of_all_three_servers(stack: Stack) -> None:
    result = stack.runner().discover()

    assert result.activity is RunActivity.DISCOVER
    assert result.tools_by_namespace == {"confluence": 2, "jira": 2, "github": 1}
    for namespace, count in result.tools_by_namespace.items():
        loaded = stack.signatures.load_latest(namespace)
        assert loaded is not None
        assert len(loaded) == count
        assert all(signature.input_schema for signature in loaded)
    assert stack.signatures.load_latest("unknown") is None


def test_us25_prose_responses_are_named_and_do_not_stop_the_other_sources(stack: Stack) -> None:
    stack.fake.prose_namespaces = {"jira"}

    result = stack.runner().run()

    assert result.outcome is RunOutcome.PARTIAL
    failed = {item.item_id for item in result.failed_items}
    assert failed == {"jira-description", "jira-comments", "jira-word"}
    assert {item.error_class for item in result.failed_items} == {"FidelityError"}
    assert result.stored_count == 6
    assert {row["source"] for row in _items(stack)} == {"confluence", "github"}
    prose_calls = [call for call in _calls(stack) if str(call["tool"]).startswith("jira/")]
    assert all(call["surviving_fields"] == [] for call in prose_calls)


def test_us25_missing_extractor_version_stops_the_run_with_a_typed_error(stack: Stack) -> None:
    class NoVersion:
        def extract(self, request: ExtractionRequest) -> ExtractionResponse:
            return ExtractionResponse(
                item_id=request.item_id, markdown_location="local:x", manifest_location="local:y"
            )

    with pytest.raises(MissingExtractorVersionError):
        stack.runner(NoVersion()).run()

    assert _items(stack) == []  # no half-recorded item
    [kept] = load_run_results(stack.ledger_dir)
    assert kept.abort_reason == "MissingExtractorVersionError"


def test_us25_an_object_the_service_cannot_convert_is_recorded_as_failed(stack: Stack) -> None:
    class Rejecting:
        def extract(self, request: ExtractionRequest) -> ExtractionResponse:
            raise ExtractionError("cannot convert")

    result = stack.runner(Rejecting()).run()

    assert result.outcome is RunOutcome.SUCCEEDED
    rows = _items(stack)
    assert {row["extraction_status"] for row in rows} == {"failed"}
    assert all("cannot convert" in str(row["extraction_failure"]) for row in rows)
    assert all(row["markdown_location"] is None for row in rows)


def test_us25_extraction_can_be_skipped_to_prove_the_route_first(stack: Stack) -> None:
    result = stack.runner().run(skip_extraction=True)

    assert result.stored_count == 9
    assert {row["extraction_status"] for row in _items(stack)} == {"pending"}
    assert stack.stub.requests == []


def test_us25_rate_limit_is_waited_out_as_instructed(stack: Stack) -> None:
    stack.fake.rate_limit_next(2, retry_after=3.0)

    result = stack.runner().run()

    assert result.stored_count == 9
    assert stack.sleeps == [3.0, 3.0]
    assert [call["error_class"] for call in _calls(stack) if call["http_status"] == 429] == [
        "SourceRateLimitedError"
    ] * 2


def test_us25_rate_limit_that_does_not_clear_ends_the_run_with_a_typed_error(
    stack: Stack,
) -> None:
    stack.fake.rate_limit_next(50)

    with pytest.raises(SourceRateLimitedError):
        stack.runner().run()

    assert len(stack.sleeps) == 2


def test_us25_missing_entitlement_stops_the_run_with_a_typed_error(stack: Stack) -> None:
    stack.fake.forbidden_namespaces = {"confluence"}

    with pytest.raises(GatewayForbiddenError):
        stack.runner().run()

    assert _items(stack) == []


def test_us25_extraction_request_is_a_reference_never_the_bytes(stack: Stack) -> None:
    stack.runner().run()

    assert len(stack.stub.requests) == 9
    for request in stack.stub.requests:
        assert request.storage_reference.startswith("local:")
        assert set(request.model_dump()) == {
            "item_id",
            "source_type",
            "version",
            "storage_reference",
            "media_type",
            "hints",
        }
        raw = stack.raw.get(stack.raw.key_of(request.storage_reference))
        assert raw.decode("latin-1") not in request.model_dump_json()


def test_us25_item_results_in_the_run_file_match_the_rows(stack: Stack) -> None:
    result = stack.runner().run()

    [kept] = load_run_results(stack.ledger_dir)
    assert kept == RunResult.model_validate_json(result.model_dump_json())
    assert {item.extraction_status for item in kept.items} == {ExtractionStatus.SUCCEEDED}


def test_us25_a_run_with_extraction_skipped_is_completed_by_the_next_full_run(stack: Stack) -> None:
    stack.runner().run(skip_extraction=True)
    before = _snapshot(stack)

    second = stack.runner().run()

    assert second.stored_count == 0
    assert second.touched_count == 9
    assert {item.status for item in second.items} == {ItemStatus.EXTRACTED}
    assert {item.extraction_status for item in second.items} == {ExtractionStatus.SUCCEEDED}
    rows = _items(stack)
    assert len(rows) == 9
    for row in rows:
        raw_key = object_key(str(row["source"]), str(row["item_id"]), str(row["version"]))
        assert row["extraction_status"] == "succeeded"
        assert stack.markdown.key_of(str(row["markdown_location"])) == f"{raw_key}.md"
        assert stack.markdown.key_of(str(row["manifest_location"])) == f"{raw_key}.manifest.json"
        assert row["extractor_version"]
        assert row["run_id"] != second.run_id  # the row keeps the run that stored it
    after = _snapshot(stack)
    assert all(after[path] == value for path, value in before.items())  # no raw rewrite
    assert len(stack.stub.requests) == 9
    with stack.database.transaction() as connection:
        touched = connection.execute(
            select(run.c.items_touched).where(run.c.run_id == second.run_id)
        ).scalar_one()
    assert touched == 9

    third = stack.runner().run()

    assert {item.status for item in third.items} == {ItemStatus.UNCHANGED}
    assert len(stack.stub.requests) == 9
    assert _snapshot(stack) == after


def test_us25_a_skipped_extraction_stays_pending_while_extraction_is_still_skipped(
    stack: Stack,
) -> None:
    stack.runner().run(skip_extraction=True)

    again = stack.runner().run(skip_extraction=True)

    assert {item.status for item in again.items} == {ItemStatus.UNCHANGED}
    assert {row["extraction_status"] for row in _items(stack)} == {"pending"}
    assert stack.stub.requests == []


def test_us25_an_extraction_that_failed_is_not_retried_by_a_later_run(stack: Stack) -> None:
    class Rejecting:
        def extract(self, request: ExtractionRequest) -> ExtractionResponse:
            raise ExtractionError("cannot convert")

    stack.runner(Rejecting()).run()

    again = stack.runner().run()

    assert {item.status for item in again.items} == {ItemStatus.UNCHANGED}
    assert {row["extraction_status"] for row in _items(stack)} == {"failed"}


def test_us25_runs_keep_their_order_when_the_clock_does_not_move(stack: Stack) -> None:
    runner = stack.runner()
    created = [runner.discover().run_id, runner.run().run_id, runner.run().run_id]

    assert [kept.run_id for kept in load_run_results(stack.ledger_dir)] == created
    assert len(set(created)) == 3


def test_us25_a_probe_that_fails_unexpectedly_still_closes_its_run(stack: Stack) -> None:
    runner = stack.runner()
    runner.discover()

    def explode(count: int) -> None:
        raise RuntimeError("transport broke")

    stack.fake.before_request = explode

    with pytest.raises(RuntimeError):
        runner.probe_errors()

    probe = next(r for r in load_run_results(stack.ledger_dir) if r.activity is RunActivity.PROBE)
    assert probe.outcome is RunOutcome.FAILED
    assert probe.abort_reason == "RuntimeError"
    with stack.database.transaction() as connection:
        outcomes = connection.execute(select(run.c.outcome)).scalars().all()
    assert "running" not in outcomes
