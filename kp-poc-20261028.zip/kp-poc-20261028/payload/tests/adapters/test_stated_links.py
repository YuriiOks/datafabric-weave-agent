"""Stated links loaded from stored stories, register rows and a code repository."""

from __future__ import annotations

from sqlalchemy import Connection, select

from kp.adapters.stated_links import StatedLinkLoader
from kp.domain import MERGED_SPEC_EVIDENCE, ItemType, Relation
from kp.store import schema
from world_support import World


def _loader(world: World, connection: Connection) -> StatedLinkLoader:
    return StatedLinkLoader(
        connection, thresholds=world.settings.thresholds, clock=world.application.clock
    )


def test_loading_the_register_again_changes_nothing(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        report = _loader(built_world, connection).sync_register()

    assert (report.opened, report.changed, report.closed) == (0, 0, 0)
    assert report.unchanged == 10


def test_story_issue_links_that_the_model_cannot_hold_are_rejected_not_stored(
    built_world: World,
) -> None:
    with built_world.application.database.transaction() as connection:
        report = _loader(built_world, connection).sync_stories({"PAY-101", "PAY-103"})
        stored = connection.execute(
            select(schema.link).where(schema.link.c.source_item_type == ItemType.STORY.value)
        ).all()

    assert report.opened == 0
    # The only story link is the one a merged spec states; the issue links are rejected.
    assert [row.evidence.startswith(MERGED_SPEC_EVIDENCE) for row in stored] == [True]


def test_the_repository_scan_states_the_test_of_a_function_and_the_field_of_a_clause(
    built_world: World,
) -> None:
    with built_world.application.database.transaction() as connection:
        scan, report = _loader(built_world, connection).sync_repository(
            built_world.staged.code_repo
        )
        relations = {
            row.relation for row in connection.execute(select(schema.link.c.relation)).all()
        }

    assert {Relation.VERIFIED_BY.value, Relation.RESOLVES_TO.value} <= relations
    assert report.opened == 0  # the build already loaded them
    assert scan.citations  # code that cites a clause is reported, not linked
