"""Confluence-like reader: a folder of JSON page exports with versions, states and labels.

Rules of this route:

* Only the newest *published* version of a page is ever listed. A draft version, however new,
  never surfaces: it is not listed and cannot be fetched.
* A page without the agreed approval label (a setting) is still listed, with
  ``has_required_label`` false, so the gate can record it as pending instead of the page
  silently not existing. Labels are compared without regard to case, as the gate compares
  them. The reader never admits anything itself.
* A later edit publishes a new version. It replaces the old one in the source, so the old
  version is not reported as deleted.
"""

from __future__ import annotations

from functools import partial
from pathlib import Path

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, JsonValue

from kp.domain.enums import SourceKind
from kp.domain.source_items import ItemKey
from kp.sources import attributes as attr
from kp.sources.base import ItemMetadata
from kp.sources.files import parse_file, require_directory, sha256_hex, walk_files
from kp.sources.snapshot import ReadItem, ScannedItem, SnapshotReader, fingerprint

PUBLISHED_STATE = "published"


class _PageVersion(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    number: int
    state: str
    modified: AwareDatetime
    body: str


class _Page(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    id: str
    title: str
    space: str | None = None
    labels: list[str] = Field(default_factory=list)
    versions: list[_PageVersion] = Field(default_factory=list)


class ConfluenceExportReader(SnapshotReader):
    """Read page exports (one ``.json`` file per page) of a Confluence-like tool.

    :param root: Folder holding the page exports
    :param approved_label: The label that marks a page as approved for use (a setting)
    """

    supersedes_older_versions = True

    def __init__(self, root: Path, *, approved_label: str) -> None:
        super().__init__()
        self._root = root
        self._approved_label = approved_label

    @property
    def kind(self) -> SourceKind:
        """Which kind of source this reader serves.

        :return: Confluence
        """
        return SourceKind.CONFLUENCE

    def _scan(self) -> list[ScannedItem]:
        require_directory(self._root)
        entries: list[ScannedItem] = []
        for path in walk_files(self._root):
            if path.suffix != ".json":
                continue
            item = self._read(path)
            if item is not None:
                entries.append(ScannedItem.of(item, partial(self._read, path)))
        return entries

    def _read(self, path: Path) -> ReadItem | None:
        """The newest published version of the page in ``path``, or ``None`` if it has none."""
        page = parse_file(path, _Page.model_validate_json, "Page export")
        published = [v for v in page.versions if v.state == PUBLISHED_STATE]
        if not published:
            return None
        version = max(published, key=lambda v: v.number)
        key = ItemKey(source=self.kind, item_id=page.id, version=str(version.number))
        labels = sorted(set(page.labels))
        approved = self._approved_label.lower()
        signals: dict[str, JsonValue] = {
            attr.LABELS: [*labels],
            attr.REQUIRED_LABEL: self._approved_label,
            attr.HAS_REQUIRED_LABEL: any(label.lower() == approved for label in labels),
            attr.WORKFLOW_STATE: version.state,
            attr.SPACE: page.space,
            attr.PAGE_VERSION: version.number,
        }
        content = version.body.encode("utf-8")
        return ReadItem(
            key=key,
            fingerprint=fingerprint(sha256_hex(content), {**signals, "title": page.title}),
            title=page.title,
            modified_at=version.modified,
            content=content,
            metadata=ItemMetadata(
                native_id=page.id,
                media_type="text/markdown",
                title=page.title,
                modified_at=version.modified,
                attributes=signals,
            ),
        )


__all__ = ["PUBLISHED_STATE", "ConfluenceExportReader"]
