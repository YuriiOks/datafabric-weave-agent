"""What the pages share: the application, the tools every page reads through, and who is looking.

Every page that shows knowledge reads it through the same read tools an agent uses, with the
viewer as the caller. Access control, the forbidden state and the audit trail are therefore the
platform's own, not a second copy in the UI.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from pydantic import JsonValue
from starlette.requests import Request

from kp.app import Application
from kp.config import Mode, Settings
from kp.errors import AccessForbiddenError, ConfigurationError
from kp.tools import (
    DatabaseAuditSink,
    IdentityMapping,
    ToolRegistry,
    build_read_registry,
)
from kp.web.identity import HeaderIdentity, IdentityResolver, LocalIdentity, Viewer, load_user_names
from kp.web.settings import WebSettings


@dataclass
class WebState:
    """Everything the pages need, built once.

    :param application: The assembled platform
    :param settings: Web settings
    :param identity: Finds the caller of a request
    :param directory: Identity to allowed domains
    :param connectivity: The settings the connectivity harness is built from (its own database
        and data folder) when the last run did not use the platform's; the platform's own
        settings when omitted
    """

    application: Application
    settings: WebSettings
    identity: IdentityResolver
    directory: IdentityMapping
    connectivity: Settings | None = None
    registry: ToolRegistry = field(init=False)

    def __post_init__(self) -> None:
        # No observer: the UI is not an agent session, so what it shows is not "retrieved in a
        # session" for the citation check of the write side.
        self.registry = build_read_registry(
            self.application.read_ports(),
            self.directory,
            DatabaseAuditSink(self.application.database),
            clock=self.application.clock,
        )

    def viewer(self, request: Request) -> Viewer:
        """Find who is looking at a page.

        :param request: The incoming request
        :return: The viewer with the domains the identity mapping gives that user
        """
        caller = self.identity.resolve(request)
        domains = self.directory.domains_for(caller.user) if caller.authenticated else frozenset()
        return Viewer(caller=caller, domains=domains)

    def call(
        self, viewer: Viewer, tool: str, arguments: Mapping[str, JsonValue]
    ) -> dict[str, JsonValue]:
        """Run one read tool as the viewer; the call is recorded in the audit trail.

        :param viewer: Who is asking
        :param tool: The tool name
        :param arguments: The tool arguments (never a domain)
        :return: The tool's JSON result
        :raises kp.errors.AccessForbiddenError: If the viewer has no access to the material
        :raises kp.errors.KpError: Any other typed failure of the tool
        """
        return self.registry.call(viewer.caller, tool, arguments).payload

    @staticmethod
    def require_access(viewer: Viewer) -> None:
        """Refuse a viewer who may read nothing, for pages that do not go through a tool.

        :param viewer: Who is asking
        :raises kp.errors.AccessForbiddenError: If the viewer is anonymous or has no domain
        """
        if not viewer.has_access:
            raise AccessForbiddenError("The viewer has no access to any domain")


def build_identity(
    application: Application,
    settings: WebSettings,
    directory: IdentityMapping,
    *,
    loopback_only: bool = True,
) -> IdentityResolver:
    """Choose how the UI learns who is signed in, for the mode of the application.

    :param application: The assembled platform
    :param settings: Web settings
    :param directory: Identity to allowed domains
    :param loopback_only: False when the server is reachable from other machines
    :return: The test-user selector in local mode, the identity header in real mode
    :raises kp.errors.ConfigurationError: If local mode has no identity mapping file to list
        the test users from
    """
    if application.settings.mode is Mode.REAL:
        return HeaderIdentity(settings.identity_header)
    path = application.settings.identity_mapping_file
    if path is None:
        raise ConfigurationError("KP_IDENTITY_MAPPING_FILE is required to run the UI")
    return LocalIdentity.for_directory(
        load_user_names(path), directory, anonymous_unless_chosen=not loopback_only
    )
