"""Locating numbered clause headings in page texts and Markdown, with their offsets.

All offsets are into the *joined text*: the page texts joined with a single ``"\\n"``
(a Markdown file is one page). A heading is a line that starts with a clause number
followed by a title.
"""

from __future__ import annotations

import re
from collections.abc import Collection, Iterator, Sequence
from dataclasses import dataclass

from kp.domain import parse_clause_number
from kp.ingest.patterns import CLAUSE_NUMBER

_PDF_HEADING = re.compile(rf"^(?P<number>{CLAUSE_NUMBER})\.?\s+(?P<title>\S.*?)\s*$")
_NUMBERED_MARKDOWN_HEADING = re.compile(
    rf"^#{{1,6}}\s+(?P<number>{CLAUSE_NUMBER})\.?\s+(?P<title>\S.*?)\s*#*\s*$"
)
_FENCE = re.compile(r"^\s*(?:```|~~~)")
_FIRST_NUMBERS = frozenset({(0,), (1,)})


@dataclass(frozen=True)
class Heading:
    """A clause heading line.

    :ivar number: The clause number as written, e.g. ``4.2.1``.
    :ivar title: The heading text after the number.
    :ivar page: One-based page of the heading line.
    :ivar start: Offset of the line start in the joined text.
    :ivar end: Offset just past the line text (before its newline).
    """

    number: str
    title: str
    page: int
    start: int
    end: int


def iter_lines(text: str) -> Iterator[tuple[int, int]]:
    """Yield ``(start, end)`` offsets of each line of ``text``, newline excluded.

    :param text: Any text
    :return: Line spans in order; a trailing newline yields no extra empty line
    """
    position = 0
    while position <= len(text):
        newline = text.find("\n", position)
        end = len(text) if newline == -1 else newline
        if newline == -1 and position == len(text):
            return
        yield position, end
        position = end + 1


def is_successor(previous: str | None, number: str) -> bool:
    """Tell whether ``number`` may directly follow ``previous`` in reading order.

    The successors of ``4.2.3`` are its first child ``4.2.3.1``, its next sibling ``4.2.4``
    and the next sibling of any ancestor (``4.3``, ``5``). The first clause is ``0`` or ``1``.

    :param previous: The preceding clause number, or ``None`` before the first clause
    :param number: The candidate number
    :return: True when the candidate continues the numbering without a gap
    """
    candidate = parse_clause_number(number)
    if previous is None:
        return candidate in _FIRST_NUMBERS
    parts = parse_clause_number(previous)
    allowed = {(*parts, 1)}
    allowed.update((*parts[:depth], parts[depth] + 1) for depth in range(len(parts)))
    return candidate in allowed


def find_pdf_headings(
    pages: Sequence[str],
    page_offsets: Sequence[int],
    skip_pages: Collection[int],
    toc_numbers: Collection[str],
) -> list[Heading]:
    """Find clause headings in per-page PDF texts.

    A numbered line is a heading only if it continues the numbering of the previous heading
    or the table of contents lists it further on. That keeps wrapped body lines that begin
    with a figure (``99.9 percent of ...``) from becoming clauses.

    :param pages: Extracted text of each page
    :param page_offsets: Offset of each page's start in the joined text
    :param skip_pages: Zero-based pages to ignore, normally the table of contents
    :param toc_numbers: Clause numbers the table of contents lists
    :return: Headings in reading order
    """
    headings: list[Heading] = []
    last: str | None = None
    for index, text in enumerate(pages):
        if index in skip_pages:
            continue
        for start, end in iter_lines(text):
            match = _PDF_HEADING.match(text[start:end])
            if match is None or not _accept(last, match["number"], toc_numbers):
                continue
            offset = page_offsets[index]
            headings.append(
                Heading(match["number"], match["title"], index + 1, offset + start, offset + end)
            )
            last = match["number"]
    return headings


def _accept(last: str | None, number: str, toc_numbers: Collection[str]) -> bool:
    if is_successor(last, number):
        return True
    ahead = last is None or parse_clause_number(number) > parse_clause_number(last)
    return ahead and number in toc_numbers


def find_markdown_headings(text: str) -> list[Heading]:
    """Find numbered headings (``### 4.2.1 Title``) in a Markdown document.

    Lines inside fenced code blocks are ignored. The document is one page.

    :param text: The Markdown source
    :return: Headings in reading order; page is always 1
    """
    headings: list[Heading] = []
    fenced = False
    for start, end in iter_lines(text):
        line = text[start:end]
        if _FENCE.match(line):
            fenced = not fenced
        elif not fenced and (match := _NUMBERED_MARKDOWN_HEADING.match(line)):
            headings.append(Heading(match["number"], match["title"], 1, start, end))
    return headings
