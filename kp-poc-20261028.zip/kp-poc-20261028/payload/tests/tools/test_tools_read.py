"""US-16: one set of read tools for agents (search, links, template, rule as at, coverage)."""

from __future__ import annotations

from dataclasses import replace
from datetime import date

import pytest
from pydantic import JsonValue
from tools_fixtures import *  # noqa: F403 - pytest fixtures

from kp.clock import FixedClock
from kp.errors import AccessForbiddenError, TemplateNotFoundError
from kp.testing.dataset import SyntheticDataset
from kp.tools import (
    CoverageSnapshot,
    IdentityMapping,
    InvalidToolArgumentsError,
    LinkStoreUnavailableError,
    NoEditionInForceError,
    ReadPorts,
    RuleNotFoundError,
    ToolRegistry,
    UnknownToolError,
    build_caller,
    build_read_registry,
)
from kp.tools.testing import FakeLinks, FakeRules, FakeSearch, InMemoryAudit

CLAUSE = "2026.1:4.2.1"


def call(
    registry: ToolRegistry, tool: str, arguments: dict[str, JsonValue]
) -> dict[str, JsonValue]:
    caller = build_caller(user="user-full-access", agent="spec-agent", session_id="s-1")
    return registry.call(caller, tool, arguments).payload


def items(payload: dict[str, JsonValue], key: str) -> list[dict[str, JsonValue]]:
    value = payload[key]
    assert isinstance(value, list)
    assert all(isinstance(entry, dict) for entry in value)
    return [entry for entry in value if isinstance(entry, dict)]


def test_us16_registry_offers_exactly_the_five_read_tools(registry: ToolRegistry) -> None:
    names = [definition.name for definition in registry.definitions()]

    assert names == ["search", "links", "template", "rule_as_at", "coverage"]
    assert all(definition.description for definition in registry.definitions())


def test_us16_search_returns_reference_page_position_and_version(
    registry: ToolRegistry, truth: SyntheticDataset
) -> None:
    payload = call(registry, "search", {"query": "currency", "limit": 5})

    hit = next(h for h in items(payload, "hits") if h["reference"] == CLAUSE)
    assert hit["version"] == "2026.1"
    assert hit["page"] == 4
    markdown = truth.path("regulatory_repo/2026.1/payments-rulebook.md").read_text(encoding="utf-8")
    assert isinstance(hit["char_start"], int)
    assert isinstance(hit["char_end"], int)
    assert markdown[hit["char_start"] : hit["char_end"]] == hit["text"]


def test_us16_search_adds_stated_and_guessed_link_counts(registry: ToolRegistry) -> None:
    payload = call(registry, "search", {"query": "inbound credit transfer"})

    hit = next(h for h in items(payload, "hits") if h["reference"] == CLAUSE)
    # l1 stated; l2 and l7 guessed and shown; l8 sits on the review list and is not counted.
    assert hit["stated_links"] == 1
    assert hit["guessed_links"] == 2
    assert payload["links_available"] is True
    assert payload["notice"] is None


def test_us16_search_link_counts_leave_out_links_to_items_the_caller_cannot_read(
    registry: ToolRegistry,
) -> None:
    caller = build_caller(user="user-one-domain", agent="spec-agent", session_id="s-5")

    payload = registry.call(caller, "search", {"query": "inbound credit transfer"}).payload

    hit = next(h for h in items(payload, "hits") if h["reference"] == CLAUSE)
    # The cards guess (l7) is in a domain this user cannot read, so it is not counted.
    assert (hit["stated_links"], hit["guessed_links"]) == (1, 1)


def test_us16_search_gives_no_link_counts_for_hits_that_are_not_clauses(
    registry: ToolRegistry,
) -> None:
    caller = build_caller(user="user-no-payments-access", agent="spec-agent", session_id="s-6")

    payload = registry.call(caller, "search", {"query": "currency"}).payload

    (hit,) = items(payload, "hits")
    assert hit["passage_type"] == "page"
    assert (hit["stated_links"], hit["guessed_links"]) == (None, None)
    assert payload["links_available"] is True


def test_us16_search_still_answers_from_passages_when_link_store_is_down(
    registry: ToolRegistry, links: FakeLinks
) -> None:
    links.available = False

    payload = call(registry, "search", {"query": "currency"})

    assert items(payload, "hits")
    assert payload["links_available"] is False
    assert isinstance(payload["notice"], str)
    assert "passages only" in payload["notice"]
    assert all(h["stated_links"] is None for h in items(payload, "hits"))


def test_us16_search_limit_is_enforced(registry: ToolRegistry) -> None:
    payload = call(registry, "search", {"query": "currency", "limit": 1})

    assert len(items(payload, "hits")) == 1


@pytest.mark.parametrize(
    "arguments",
    [
        {},
        {"query": ""},
        {"query": "x", "limit": 0},
        {"query": "x", "limit": 51},
        {"query": "x" * 501},
    ],
)
def test_us16_search_rejects_malformed_arguments(
    registry: ToolRegistry, arguments: dict[str, JsonValue]
) -> None:
    with pytest.raises(InvalidToolArgumentsError):
        call(registry, "search", arguments)


def test_us16_links_follows_three_steps_and_marks_stated_or_guessed(
    registry: ToolRegistry,
) -> None:
    payload = call(registry, "links", {"item_type": "clause", "key": CLAUSE})

    found = {(i["item_type"], i["key"]): i for i in items(payload, "items")}
    assert found[("requirement", "REQ-1")]["steps"] == 1
    assert found[("requirement", "REQ-1")]["kind"] == "stated"
    guessed = found[("spec", "SPEC-1")]
    assert (guessed["steps"], guessed["kind"], guessed["state"]) == (1, "guessed", "proposed")
    assert guessed["score"] == 0.8
    assert guessed["evidence"] == "shared schema field and terms"
    assert found[("story", "PAY-101")]["steps"] == 2
    assert found[("code", "code:inbound")]["steps"] == 2
    assert found[("test", "test:inbound")]["steps"] == 3
    assert found[("test", "test:inbound")]["via_key"] == "code:inbound"
    # Four steps away: out of reach.
    assert ("code", "code:other") not in found


def test_us16_links_never_shows_review_list_or_dropped_guesses(registry: ToolRegistry) -> None:
    payload = call(registry, "links", {"item_type": "clause", "key": CLAUSE})

    assert ("spec", "SPEC-REVIEW") not in {
        (i["item_type"], i["key"]) for i in items(payload, "items")
    }


def test_us16_links_counts_stated_and_guessed(registry: ToolRegistry) -> None:
    payload = call(registry, "links", {"item_type": "clause", "key": CLAUSE, "steps": 3})

    # Full access sees the cards guess too; the review-list guess is never counted.
    assert payload["stated"] == 4
    assert payload["guessed"] == 2


def test_us16_links_steps_limits_the_reach(registry: ToolRegistry) -> None:
    payload = call(registry, "links", {"item_type": "clause", "key": CLAUSE, "steps": 1})

    assert {i["steps"] for i in items(payload, "items")} == {1}


def test_us16_links_rejects_more_than_three_steps(registry: ToolRegistry) -> None:
    with pytest.raises(InvalidToolArgumentsError):
        call(registry, "links", {"item_type": "clause", "key": CLAUSE, "steps": 4})


def test_us16_links_with_no_links_says_so(registry: ToolRegistry) -> None:
    payload = call(registry, "links", {"item_type": "clause", "key": "2026.1:4.2.2"})

    assert payload["items"] == []
    assert payload["message"] is not None
    assert "No links" in str(payload["message"])


def test_us16_links_hides_items_of_other_domains_but_counts_them(
    registry: ToolRegistry,
) -> None:
    caller = build_caller(user="user-one-domain", agent="spec-agent", session_id="s-2")

    payload = registry.call(caller, "links", {"item_type": "clause", "key": CLAUSE}).payload

    keys = {i["key"] for i in items(payload, "items")}
    assert "SPEC-CARDS" not in keys
    assert payload["filtered_out"] == 1


def test_us16_links_for_an_item_outside_the_callers_domains_is_forbidden(
    registry: ToolRegistry,
) -> None:
    caller = build_caller(user="user-no-payments-access", agent="spec-agent", session_id="s-3")

    with pytest.raises(AccessForbiddenError):
        registry.call(caller, "links", {"item_type": "clause", "key": CLAUSE})


def test_us16_links_fails_clearly_when_link_store_is_down(
    registry: ToolRegistry, links: FakeLinks
) -> None:
    links.available = False

    with pytest.raises(LinkStoreUnavailableError):
        call(registry, "links", {"item_type": "clause", "key": CLAUSE})


def test_us16_template_returns_latest_governed_version(registry: ToolRegistry) -> None:
    payload = call(registry, "template", {"spec_type": "functional"})

    assert payload["version"] == "1.1.0"
    assert payload["template_id"] == "functional-spec"
    assert payload["body"] == "# Template 1.1.0"


def test_us16_template_returns_the_requested_version(registry: ToolRegistry) -> None:
    payload = call(registry, "template", {"spec_type": "functional", "version": "1.0.0"})

    assert payload["version"] == "1.0.0"


def test_us16_template_without_governed_type_is_an_error_never_a_fallback(
    registry: ToolRegistry,
) -> None:
    with pytest.raises(TemplateNotFoundError):
        call(registry, "template", {"spec_type": "technical"})


def test_us16_template_with_unknown_version_does_not_fall_back_to_latest(
    registry: ToolRegistry,
) -> None:
    with pytest.raises(TemplateNotFoundError):
        call(registry, "template", {"spec_type": "functional", "version": "9.9.9"})


def test_us16_rule_as_at_day_before_cutover_returns_old_edition(
    registry: ToolRegistry, truth: SyntheticDataset
) -> None:
    payload = call(registry, "rule_as_at", {"number": "4.2.1", "as_at": "2026-11-15"})

    assert payload["edition"] == "2025.2"
    assert payload["reference"] == "2025.2:4.2.1"
    assert "euro only" in str(payload["text"])


def test_us16_rule_as_at_cutover_day_returns_new_edition(registry: ToolRegistry) -> None:
    payload = call(registry, "rule_as_at", {"number": "4.2.1", "as_at": "2026-11-16"})

    assert payload["edition"] == "2026.1"
    assert "pounds sterling" in str(payload["text"])
    assert payload["effective_date"] == "2026-11-16"


def test_us16_rule_as_at_without_date_uses_today_from_the_clock(registry: ToolRegistry) -> None:
    payload = call(registry, "rule_as_at", {"number": "4.2.1"})

    # The fixed clock reads 1 Nov 2026, before the 2026.1 edition takes effect.
    assert payload["as_at"] == date(2026, 11, 1).isoformat()
    assert payload["edition"] == "2025.2"


def test_us16_rule_as_at_before_any_edition_is_an_error(registry: ToolRegistry) -> None:
    with pytest.raises(NoEditionInForceError):
        call(registry, "rule_as_at", {"number": "4.2.1", "as_at": "2020-01-01"})


def test_us16_rule_as_at_shows_the_date_an_edition_is_later_withdrawn(
    ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    rule = ports.rules.clause("2025.2", "4.2.1")
    assert rule is not None
    editions = [
        edition.model_copy(update={"withdrawn_from": date(2027, 1, 1)})
        if edition.label == "2025.2"
        else edition
        for edition in ports.rules.editions()
    ]
    registry = build_read_registry(
        replace(ports, rules=FakeRules(editions, {("2025.2", "4.2.1"): rule})),
        mapping,
        audit,
        clock=fixed_clock,
    )

    payload = call(registry, "rule_as_at", {"number": "4.2.1", "as_at": "2026-11-15"})

    assert payload["edition"] == "2025.2"
    assert payload["superseded_from"] == "2026-11-16"
    assert payload["withdrawn_from"] == "2027-01-01"


def test_us16_rule_as_at_has_no_withdrawal_date_for_an_edition_in_good_standing(
    registry: ToolRegistry,
) -> None:
    payload = call(registry, "rule_as_at", {"number": "4.2.1", "as_at": "2026-11-16"})

    assert payload["withdrawn_from"] is None


def test_us16_rule_as_at_unknown_clause_is_an_error(registry: ToolRegistry) -> None:
    with pytest.raises(RuleNotFoundError):
        call(registry, "rule_as_at", {"number": "99.9"})


def test_us17_rule_as_at_cannot_be_used_to_tell_whether_a_clause_exists_in_another_domain(
    registry: ToolRegistry,
) -> None:
    """A caller without payments access gets the same refusal for a real and an invented clause."""
    caller = build_caller(user="user-no-payments-access", agent="spec-agent", session_id="s-7")

    with pytest.raises(AccessForbiddenError) as existing:
        registry.call(caller, "rule_as_at", {"number": "4.2.1"})
    with pytest.raises(AccessForbiddenError) as invented:
        registry.call(caller, "rule_as_at", {"number": "99.9"})

    assert str(existing.value) == str(invented.value)


@pytest.mark.parametrize("number", ["", "4..2", "four", "4.2.1; drop", "04.2"])
def test_us16_rule_as_at_rejects_malformed_numbers(registry: ToolRegistry, number: str) -> None:
    with pytest.raises(InvalidToolArgumentsError):
        call(registry, "rule_as_at", {"number": number})


def test_us16_coverage_separates_rules_with_and_without_tests(registry: ToolRegistry) -> None:
    payload = call(registry, "coverage", {})

    assert [r["reference"] for r in items(payload, "rules_with_tests")] == ["2026.1:4.2.1"]
    assert [r["reference"] for r in items(payload, "rules_without_tests")] == [
        "2026.1:4.2.2",
        "2026.1:5.1",
    ]
    assert [g["story_key"] for g in items(payload, "stories_without_basis")] == [
        "PAY-109",
        "CRD-1",
    ]
    assert (payload["stated_links"], payload["guessed_links"]) == (4, 3)
    assert payload["filtered_out"] == 0
    assert payload["truncated"] is False
    assert (
        payload["total_rules_with_tests"],
        payload["total_rules_without_tests"],
        payload["total_stories_without_basis"],
    ) == (1, 2, 2)


def test_us16_coverage_pages_each_list_and_says_when_it_is_cut(
    registry: ToolRegistry, audit: InMemoryAudit
) -> None:
    first = call(registry, "coverage", {"limit": 1})

    assert [r["reference"] for r in items(first, "rules_without_tests")] == ["2026.1:4.2.2"]
    assert len(items(first, "stories_without_basis")) == 1
    assert first["truncated"] is True
    assert first["total_rules_without_tests"] == 2
    # Links are summed over every visible rule, not just the page.
    assert (first["stated_links"], first["guessed_links"]) == (4, 3)
    assert audit.records[-1].items_returned == 3

    rest = call(registry, "coverage", {"limit": 1, "offset": 1})

    assert [r["reference"] for r in items(rest, "rules_without_tests")] == ["2026.1:5.1"]
    assert [g["story_key"] for g in items(rest, "stories_without_basis")] == ["CRD-1"]
    assert rest["truncated"] is False


@pytest.mark.parametrize("arguments", [{"limit": 0}, {"limit": 501}, {"offset": -1}])
def test_us16_coverage_rejects_malformed_paging(
    registry: ToolRegistry, arguments: dict[str, JsonValue]
) -> None:
    with pytest.raises(InvalidToolArgumentsError):
        call(registry, "coverage", arguments)


def test_us16_coverage_for_partial_access_hides_other_domains_and_counts_them(
    registry: ToolRegistry,
) -> None:
    caller = build_caller(user="user-one-domain", agent="spec-agent", session_id="s-4")

    payload = registry.call(caller, "coverage", {}).payload

    assert [r["reference"] for r in items(payload, "rules_without_tests")] == ["2026.1:4.2.2"]
    assert [g["story_key"] for g in items(payload, "stories_without_basis")] == ["PAY-109"]
    assert payload["filtered_out"] == 2


class _DownCoverage:
    def snapshot(self, *, domains: frozenset[str], as_at: date) -> CoverageSnapshot:
        raise LinkStoreUnavailableError("The link store is down")


def test_us16_coverage_reports_link_store_outage_as_an_error(
    ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit, fixed_clock: FixedClock
) -> None:
    registry = build_read_registry(
        replace(ports, coverage=_DownCoverage()), mapping, audit, clock=fixed_clock
    )

    with pytest.raises(LinkStoreUnavailableError):
        call(registry, "coverage", {})

    assert audit.records[-1].error_class == "LinkStoreUnavailableError"
    assert audit.records[-1].refused is False


@pytest.mark.parametrize(
    "tool", ["fetch_source", "query_database", "sql", "read_file", "http_get", "shell"]
)
def test_us16_there_is_no_tool_that_reaches_a_source_or_the_database(
    registry: ToolRegistry, search: FakeSearch, tool: str
) -> None:
    with pytest.raises(UnknownToolError):
        call(registry, tool, {"query": "select 1", "url": "x", "path": "/etc/passwd"})

    assert search.calls == []
