"""Server-side citation check.

Rule statements are the sentences in the template's rules section plus any other sentence
containing ``must``, ``must not``, ``shall``, ``is required`` or ``is rejected``. Each must
cite material the agent retrieved in the same session, and each citation must resolve to an
existing clause or register row. The check proves existence, not support.

A citation is either the marker ``[ref: <reference>]`` (clause reference ``2026.1:4.2.1`` or
a requirement id) or the spoken form ``2026.1 clause 4.2.1``. A marker may sit before or after
the closing full stop of its sentence.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from collections.abc import Set as AbstractSet
from dataclasses import dataclass
from enum import StrEnum
from typing import Annotated

from pydantic import Field

from kp.domain import Citation, ClauseRef, DomainModel
from kp.errors import InvalidClauseRefError
from kp.writeback.template import split_front_matter

RULES_HEADING = "Rules"
CITATION_MARKER = "[ref: {reference}]"

_MARKER = re.compile(r"\[ref:\s*(?P<reference>[^\]]+?)\s*\]")
# The edition must contain a digit: "see the clause 4" is prose, "2026.1 clause 4" is a citation.
_SPOKEN = re.compile(
    r"(?<![\w.:-])(?P<edition>(?=[A-Za-z0-9])[A-Za-z0-9._-]*\d[A-Za-z0-9._-]*)\s+clause\s+"
    r"(?P<number>(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))*)\b",
    re.IGNORECASE,
)
_RULE_KEYWORD = re.compile(r"\b(?:must(?: not)?|shall|is required|is rejected)\b", re.IGNORECASE)
_SENTENCE_BREAK = re.compile(r"(?<=[.!?])\s+")
_LIST_ITEM = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
_HEADING_LINE = re.compile(r"^\s*#{1,6}\s+(?P<title>.+?)\s*#*\s*$")


class Problem(StrEnum):
    """Why a rule statement is flagged."""

    UNCITED = "uncited"
    UNRESOLVED = "unresolved"
    NOT_RETRIEVED = "not_retrieved"


def canonical_reference(text: str) -> str:
    """Normalise a reference to the form used for retrieval and storage.

    :param text: A clause reference in canonical or spoken form, or a requirement id
    :return: ``<edition>:<number>`` for a clause reference, otherwise the stripped text
    """
    stripped = text.strip()
    try:
        return ClauseRef.parse(stripped).format()
    except InvalidClauseRefError:
        return stripped


def extract_references(text: str) -> tuple[str, ...]:
    """Find the citations in a piece of text.

    :param text: A sentence or paragraph
    :return: Canonical references in order of appearance, without duplicates
    """
    found = [canonical_reference(match["reference"]) for match in _MARKER.finditer(text)]
    unmarked = _MARKER.sub(" ", text)
    found.extend(
        ClauseRef(match["edition"], match["number"]).format()
        for match in _SPOKEN.finditer(unmarked)
    )
    return tuple(dict.fromkeys(found))


def split_sentences(text: str) -> list[str]:
    """Split a block of prose into sentences, keeping markers with their sentence.

    :param text: A paragraph or list item
    :return: The sentences; a fragment holding only a marker joins the sentence before it
    """
    sentences: list[str] = []
    for fragment in _SENTENCE_BREAK.split(text.strip()):
        only_marker = bool(_MARKER.search(fragment)) and not _MARKER.sub("", fragment).strip(" .;,")
        if only_marker and sentences:
            sentences[-1] = f"{sentences[-1]} {fragment.strip()}"
        elif fragment.strip():
            sentences.append(fragment.strip())
    return sentences


@dataclass(frozen=True, slots=True)
class Statement:
    """A rule statement and the references it cites."""

    index: int
    text: str
    references: tuple[str, ...]


def _blocks(markdown: str) -> list[tuple[str, str]]:
    """Return ``(section title, block text)`` pairs; list items are blocks of their own."""
    blocks: list[tuple[str, str]] = []
    section = ""
    paragraph: list[str] = []
    in_fence = False

    def flush() -> None:
        if paragraph:
            blocks.append((section, " ".join(paragraph)))
            paragraph.clear()

    for raw in split_front_matter(markdown)[1].splitlines():
        if raw.lstrip().startswith("```"):
            flush()
            in_fence = not in_fence
            continue
        heading = None if in_fence else _HEADING_LINE.match(raw)
        line = raw.strip().removeprefix(">").strip()
        if in_fence or not line:
            flush()
        elif heading is not None:
            flush()
            section = heading["title"]
        elif _LIST_ITEM.match(raw):
            flush()
            paragraph.append(_LIST_ITEM.sub("", raw).strip())
        else:
            paragraph.append(line)
    flush()
    return blocks


def extract_rule_statements(
    markdown: str, *, rules_heading: str = RULES_HEADING
) -> tuple[Statement, ...]:
    """Find the rule statements of a drafted spec.

    :param markdown: The spec, with or without front matter
    :param rules_heading: Title of the template's rules section
    :return: Sentences of the rules section plus sentences with a rule keyword elsewhere
    """
    statements: list[Statement] = []
    for section, block in _blocks(markdown):
        in_rules = section.strip().casefold() == rules_heading.casefold()
        for sentence in split_sentences(block):
            if in_rules or _RULE_KEYWORD.search(_MARKER.sub("", sentence)):
                statements.append(
                    Statement(len(statements), sentence, extract_references(sentence))
                )
    return tuple(statements)


class StatementCheck(DomainModel):
    """The outcome for one rule statement."""

    index: Annotated[int, Field(ge=0)]
    statement: str
    references: tuple[str, ...] = ()
    unresolved: tuple[str, ...] = ()
    unretrieved: tuple[str, ...] = ()

    @property
    def valid(self) -> bool:
        """True when cited, every citation resolves and every one was retrieved this session."""
        return bool(self.references) and not self.unresolved and not self.unretrieved

    @property
    def problems(self) -> tuple[Problem, ...]:
        """The reasons this statement is flagged; empty when valid."""
        found: list[Problem] = []
        if not self.references:
            found.append(Problem.UNCITED)
        if self.unresolved:
            found.append(Problem.UNRESOLVED)
        if self.unretrieved:
            found.append(Problem.NOT_RETRIEVED)
        return tuple(found)


class CitationReport(DomainModel):
    """Citation check of one spec against the target rate."""

    checks: tuple[StatementCheck, ...] = ()
    target: Annotated[float, Field(ge=0, le=1)]

    @property
    def rule_statements(self) -> int:
        """Number of rule statements found."""
        return len(self.checks)

    @property
    def valid_statements(self) -> int:
        """Number of rule statements that are cited and valid."""
        return sum(check.valid for check in self.checks)

    @property
    def rate(self) -> float:
        """Cited-and-valid rule statements over rule statements; 1.0 when there are none."""
        return self.valid_statements / self.rule_statements if self.checks else 1.0

    @property
    def meets_target(self) -> bool:
        """True when the rate reaches the target."""
        return self.rate >= self.target

    @property
    def flagged(self) -> tuple[StatementCheck, ...]:
        """The statements that are uncited or whose citations are broken."""
        return tuple(check for check in self.checks if not check.valid)

    def to_citations(self, spec_id: str) -> tuple[Citation, ...]:
        """Build one citation row per rule statement.

        A statement with several references stores the first broken one, else the first.
        ``resolved`` and ``retrieved_in_session`` are true only when they hold for all of them.

        :param spec_id: The spec the statements belong to
        :return: The domain citations, in statement order
        """
        return tuple(
            Citation(
                citation_id=f"{spec_id}:{check.index}",
                spec_id=spec_id,
                statement_index=check.index,
                statement=check.statement,
                is_rule_statement=True,
                reference=_stored_reference(check),
                resolved=bool(check.references) and not check.unresolved,
                retrieved_in_session=bool(check.references) and not check.unretrieved,
            )
            for check in self.checks
        )


def _stored_reference(check: StatementCheck) -> str | None:
    if check.unresolved:
        return check.unresolved[0]
    if check.unretrieved:
        return check.unretrieved[0]
    return check.references[0] if check.references else None


def check_citations(
    markdown: str,
    *,
    resolves: Callable[[str], bool],
    retrieved: AbstractSet[str],
    target: float,
    rules_heading: str = RULES_HEADING,
) -> CitationReport:
    """Check every rule statement of a spec.

    :param markdown: The drafted spec
    :param resolves: Tells whether a canonical reference names an existing clause or row
    :param retrieved: References the agent retrieved in the same session
    :param target: The citation rate to report against (provisional 0.95)
    :param rules_heading: Title of the template's rules section
    :return: One check per rule statement and the rate against ``target``
    """
    seen = {canonical_reference(reference) for reference in retrieved}
    checks = tuple(
        StatementCheck(
            index=statement.index,
            statement=statement.text,
            references=statement.references,
            unresolved=tuple(ref for ref in statement.references if not resolves(ref)),
            unretrieved=tuple(ref for ref in statement.references if ref not in seen),
        )
        for statement in extract_rule_statements(markdown, rules_heading=rules_heading)
    )
    return CitationReport(checks=checks, target=target)
