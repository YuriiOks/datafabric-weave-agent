import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { SuggestedComponentsPanel } from './SuggestedComponentsPanel'

// Demo mode off and the recommender off: its router is not mounted, so every call is a 404.
vi.mock('../client', async () => {
  const { ApiError } = await import('@/lib/api')
  const notMounted = async () => {
    throw new ApiError(404, 'Not Found')
  }
  return {
    recsysApi: {
      getSuggestedComponents: notMounted,
      submitRecommendation: notMounted,
      getRecommendation: notMounted,
    },
    RECSYS_MOCK_ENABLED: false,
    recsysLive: async () => false,
  }
})

function renderPanel(cardId: string) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter>
        <SuggestedComponentsPanel cardId={cardId} pollIntervalMs={5} />
      </MemoryRouter>
    </QueryClientProvider>,
  )
}

describe('SuggestedComponentsPanel outside demo mode', () => {
  afterEach(() => {
    cleanup()
  })

  it('says suggestions are unavailable rather than offering to generate them', async () => {
    renderPanel('UC0001234')

    expect(await screen.findByText('Suggestions are unavailable right now.')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Generate suggestions' })).not.toBeInTheDocument()
    expect(screen.queryByText('Demo data')).not.toBeInTheDocument()
  })
})
