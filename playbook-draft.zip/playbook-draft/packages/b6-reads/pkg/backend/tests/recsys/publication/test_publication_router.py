"""Bounded publication read route: fail-closed admission and one status per refusal."""

from __future__ import annotations

import asyncio
import unittest
from unittest import mock
from uuid import UUID

from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from redis.exceptions import ConnectionError as GraphConnectionError

from app.middleware.rate_limit import limiter
from app.recsys.config import recsys_settings
from app.recsys.publication import router as route_module
from app.recsys.publication.models import (
    BoundedReadResult,
    BudgetExhausted,
    CursorExpired,
    CursorMismatch,
    PolicyChanged,
    PublicationUnavailable,
    ReadBudget,
    ReadNode,
    ScopeNotPermitted,
)
from app.recsys.publication.reads import BoundedReader
from app.recsys.publication.router import get_bounded_reader, router

PUBLICATION = UUID("eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee")
BODY = {"request": {"seed_component_ids": ["agent:fixture"]}}
READER = {"employee_id": "reader-1", "role": "viewer"}


def _page(*, truncated: bool) -> BoundedReadResult:
    return BoundedReadResult(
        publication_uuid=PUBLICATION,
        nodes=(
            ReadNode(
                component_id="agent:fixture",
                component_type="agent",
                name="Fixture agent",
                depth=0,
            ),
        ),
        edges=(),
        truncated=truncated,
    )


class _Reader:
    def __init__(self, outcome) -> None:
        self.outcome = outcome

    async def read(self, request, cursor=None):
        if isinstance(self.outcome, BaseException):
            raise self.outcome
        return self.outcome


class ReadRouteTests(unittest.TestCase):
    def setUp(self) -> None:
        self._limiter_enabled = limiter.enabled
        limiter.enabled = False
        self.app = FastAPI()
        self.app.state.limiter = limiter
        self.app.include_router(router)
        self.client = TestClient(self.app)

    def tearDown(self) -> None:
        limiter.enabled = self._limiter_enabled
        self.app.dependency_overrides.clear()

    def _post(self, outcome):
        reader = _Reader(outcome)
        self.app.dependency_overrides[get_bounded_reader] = lambda: reader
        return self.client.post("/publication/reads", json=BODY)

    def test_a_complete_read_returns_its_page(self) -> None:
        response = self._post(_page(truncated=False))

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertIsNone(body["exhausted_budget"])
        self.assertFalse(body["result"]["truncated"])
        self.assertEqual(body["result"]["nodes"][0]["component_id"], "agent:fixture")

    def test_a_page_cut_by_a_budget_comes_back_with_that_budget(self) -> None:
        response = self._post(BudgetExhausted(ReadBudget.result_count, page=_page(truncated=True)))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["exhausted_budget"], "result_count")
        self.assertTrue(response.json()["result"]["truncated"])

    def test_every_refusal_keeps_its_own_answer(self) -> None:
        cases = [
            (BudgetExhausted(ReadBudget.duration), 503, "budget_exhausted:duration"),
            (CursorExpired(), 410, "cursor_expired"),
            (PolicyChanged(), 403, "policy_changed"),
            (ScopeNotPermitted(), 403, "scope_not_permitted"),
            (CursorMismatch(), 409, "cursor_mismatch"),
            (PublicationUnavailable(), 503, "publication_unavailable"),
            (GraphConnectionError("graph down"), 503, "graph_unavailable"),
        ]
        for outcome, status, detail in cases:
            with self.subTest(detail=detail):
                response = self._post(outcome)

                self.assertEqual(response.status_code, status)
                self.assertEqual(response.json()["detail"], detail)

    def test_a_request_naming_a_scope_is_rejected(self) -> None:
        self.app.dependency_overrides[get_bounded_reader] = lambda: _Reader(_page(truncated=False))

        response = self.client.post(
            "/publication/reads",
            json={"request": {"seed_component_ids": ["agent:fixture"], "scope": "prod"}},
        )

        self.assertEqual(response.status_code, 422)


class AdmissionTests(unittest.TestCase):
    def _settings(self, **values):
        defaults = {
            "recsys_publication_reads_enabled": True,
            "recsys_publication_readers": "reader-1, reader-2",
            "recsys_refresh_environment": "ppd",
            "recsys_refresh_partition": "shared",
        }
        defaults.update(values)
        return [
            mock.patch.object(recsys_settings, name, value) for name, value in defaults.items()
        ]

    def _admit(self, user=READER, **values):
        patches = self._settings(**values)
        for patch in patches:
            patch.start()
        try:
            with mock.patch.object(route_module, "resolve_pool", return_value=object()), \
                    mock.patch.object(route_module, "_graph_store", return_value=object()):
                return asyncio.run(get_bounded_reader(user))
        finally:
            for patch in reversed(patches):
                patch.stop()

    def _refusal(self, **kwargs) -> tuple[int, str]:
        with self.assertRaises(HTTPException) as raised:
            self._admit(**kwargs)
        return raised.exception.status_code, raised.exception.detail

    def test_a_listed_reader_gets_a_reader_for_the_configured_scope(self) -> None:
        reader = self._admit()

        self.assertIsInstance(reader, BoundedReader)

    def test_reads_are_refused_unless_switched_on(self) -> None:
        self.assertEqual(
            self._refusal(recsys_publication_reads_enabled=False),
            (503, "publication_reads_unavailable"),
        )

    def test_production_and_an_empty_reader_list_are_refused(self) -> None:
        self.assertEqual(
            self._refusal(recsys_refresh_environment="prod"),
            (503, "publication_reads_unavailable"),
        )
        self.assertEqual(
            self._refusal(recsys_publication_readers=" , "),
            (503, "publication_reads_unavailable"),
        )

    def test_an_unlisted_or_anonymous_caller_is_refused(self) -> None:
        self.assertEqual(
            self._refusal(user={"employee_id": "someone-else", "role": "viewer"}),
            (403, "publication_read_not_authorized"),
        )
        self.assertEqual(
            self._refusal(user={"role": "viewer"}),
            (403, "publication_read_not_authorized"),
        )


if __name__ == "__main__":
    unittest.main()
