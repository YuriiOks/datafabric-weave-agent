"""Caller identity and access control.

The allowed domains of a call are derived only from the caller's identity and the written
identity mapping. Tool arguments never carry a domain, so an agent cannot widen its access.
An item with no domain label is visible to nobody: access control fails closed.
"""

from __future__ import annotations

import re
import uuid
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated, Literal, Protocol, TypeGuard, TypeVar

import yaml
from pydantic import BaseModel, ConfigDict, StringConstraints, ValidationError

from kp.clock import Clock
from kp.domain import DomainModel
from kp.errors import AccessForbiddenError
from kp.tools.errors import IdentityMappingError

ANONYMOUS_USER = "anonymous"
UNKNOWN_AGENT = "unknown-agent"

_NAME_BODY = r"[A-Za-z0-9][A-Za-z0-9._@:-]{0,127}"
_NAME_RE = re.compile(_NAME_BODY)
_Name = Annotated[str, StringConstraints(pattern=rf"^{_NAME_BODY}$")]

T = TypeVar("T")


class Caller(DomainModel):
    """Who is calling, as asserted by the transport (never by tool arguments).

    :ivar user: The end user's identity; the key into the identity mapping.
    :ivar agent: The agent acting for the user; recorded in the audit trail.
    :ivar session_id: Groups the calls of one drafting session.
    :ivar spec_id: The spec being drafted, when the transport knows it; labels the audit trail.
    :ivar authenticated: False when the transport supplied no usable identity.
    """

    user: _Name
    agent: _Name = UNKNOWN_AGENT
    session_id: _Name
    spec_id: _Name | None = None
    authenticated: bool = True


def build_caller(
    *,
    user: str | None,
    agent: str | None = None,
    session_id: str | None = None,
    spec_id: str | None = None,
) -> Caller:
    """Build a caller from transport claims, degrading safely.

    A missing or malformed user yields an unauthenticated anonymous caller, who is refused
    by every tool and recorded. A malformed agent, session or spec label is replaced by a
    default (they are audit labels, not credentials).

    :param user: The claimed user identity
    :param agent: The claimed agent name
    :param session_id: The claimed session identifier; generated when absent
    :param spec_id: The claimed spec identifier
    :return: The caller
    """
    return Caller(
        user=user if _is_name(user) else ANONYMOUS_USER,
        agent=agent if _is_name(agent) else UNKNOWN_AGENT,
        session_id=session_id if _is_name(session_id) else uuid.uuid4().hex,
        spec_id=spec_id if _is_name(spec_id) else None,
        authenticated=_is_name(user),
    )


def _is_name(value: str | None) -> TypeGuard[str]:
    return value is not None and _NAME_RE.fullmatch(value) is not None


class DomainDirectory(Protocol):
    """Answers which domains a user identity may read."""

    def domains_for(self, user: str) -> frozenset[str]:
        """Return the domains ``user`` may read.

        :param user: The authenticated user identity
        :return: The allowed domains; empty for an unknown user
        """
        ...


class _UserEntry(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    domains: tuple[str, ...]


class _MappingFile(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal[1]
    users: dict[str, _UserEntry]


class IdentityMapping:
    """The written mapping from user identity to allowed domains.

    :param domains_by_user: Allowed domains per user identity
    """

    def __init__(self, domains_by_user: Mapping[str, Iterable[str]]) -> None:
        self._domains = {user: frozenset(domains) for user, domains in domains_by_user.items()}

    @classmethod
    def from_file(cls, path: Path) -> IdentityMapping:
        """Load the mapping from its YAML file.

        :param path: A file with ``version: 1`` and ``users: {<user>: {domains: [...]}}``
        :return: The mapping
        :raises IdentityMappingError: If the file is unreadable or malformed
        """
        try:
            raw = yaml.safe_load(path.read_text(encoding="utf-8"))
            parsed = _MappingFile.model_validate(raw)
        except (OSError, yaml.YAMLError, ValidationError) as exc:
            raise IdentityMappingError(f"Identity mapping {path.name} is unusable") from exc
        if ANONYMOUS_USER in parsed.users:
            raise IdentityMappingError(f"User name {ANONYMOUS_USER!r} is reserved")
        return cls({user: entry.domains for user, entry in parsed.users.items()})

    def domains_for(self, user: str) -> frozenset[str]:
        """Return the domains ``user`` may read.

        :param user: The user identity
        :return: The allowed domains; empty for an unknown user
        """
        return self._domains.get(user, frozenset())

    def all_domains(self) -> frozenset[str]:
        """Return every domain any user of the mapping may read.

        :return: The union of the users' domains
        """
        return frozenset().union(*self._domains.values())


@dataclass(frozen=True, slots=True)
class ToolContext:
    """What a tool handler may know about the call: identity-derived access, never arguments.

    :param caller: The authenticated caller
    :param domains: The domains the caller may read (never empty inside a handler)
    :param clock: The time source; "no date" means ``clock.today()``
    """

    caller: Caller
    domains: frozenset[str]
    clock: Clock

    def is_visible(self, domain: str | None) -> bool:
        """Tell whether an item with ``domain`` may be shown to the caller.

        :param domain: The item's domain label, or ``None`` when unlabelled
        :return: True only for a labelled domain the caller may read
        """
        return domain is not None and domain in self.domains

    def require_visible(self, domain: str | None) -> None:
        """Refuse access to an item the caller may not read.

        :param domain: The item's domain label, or ``None`` when unlabelled
        :raises AccessForbiddenError: If the item is not visible to the caller
        """
        if not self.is_visible(domain):
            raise AccessForbiddenError(
                "The item is unknown or belongs to a domain the caller may not read"
            )

    def split_visible(
        self, items: Iterable[T], domain_of: Callable[[T], str | None]
    ) -> tuple[list[T], int]:
        """Keep the visible items and count the hidden ones.

        :param items: Candidate items
        :param domain_of: Reads an item's domain label
        :return: The visible items in order, and the number hidden
        """
        visible: list[T] = []
        hidden = 0
        for item in items:
            if self.is_visible(domain_of(item)):
                visible.append(item)
            else:
                hidden += 1
        return visible, hidden
