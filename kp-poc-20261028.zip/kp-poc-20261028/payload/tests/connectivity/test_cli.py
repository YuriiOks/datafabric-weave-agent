"""US-25 / US-26: ``kp connectivity discover|run|report``."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pytest

from kp.connectivity.cli import add_parser, handle, main
from kp.connectivity.report import LOCAL_VERDICT


@pytest.fixture(autouse=True)
def _local_environment(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    for name in list(__import__("os").environ):
        if name.startswith("KP_"):
            monkeypatch.delenv(name)
    monkeypatch.setenv("KP_MODE", "local")
    monkeypatch.setenv("KP_DATA_DIR", str(tmp_path / "var"))
    monkeypatch.setenv("KP_DATABASE_URL", f"sqlite+pysqlite:///{tmp_path / 'kp.db'}")


def test_us25_cli_registers_under_the_connectivity_command() -> None:
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))

    args = parser.parse_args(["connectivity", "run", "--skip-extraction"])

    assert args.command == "connectivity"
    assert args.connectivity_command == "run"
    assert args.skip_extraction is True
    assert args.handler is handle
    with pytest.raises(SystemExit):
        parser.parse_args(["connectivity"])


def test_us25_cli_discover_run_and_second_run(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["connectivity", "discover"]) == 0
    discovered = capsys.readouterr().out
    assert "confluence: 2 tools kept" in discovered

    assert main(["connectivity", "run"]) == 0
    first = capsys.readouterr().out
    assert first.count(": stored succeeded") == 9
    assert "stored 9, extracted 0, unchanged 0, failed 0" in first

    assert main(["connectivity", "run"]) == 0
    second = capsys.readouterr().out
    assert second.count(": unchanged") == 9
    assert "stored 0, extracted 0, unchanged 9, failed 0" in second


def test_us26_cli_report_prints_the_local_verdict(capsys: pytest.CaptureFixture[str]) -> None:
    main(["connectivity", "discover"])
    main(["connectivity", "run"])
    main(["connectivity", "run", "--probe-errors"])
    capsys.readouterr()

    assert main(["connectivity", "report"]) == 0

    out = capsys.readouterr().out
    assert LOCAL_VERDICT in out
    assert "| X-09 | Re-run changes nothing (same count, files unchanged) | PASS |" in out
    assert "probe" not in out


def test_us26_cli_report_can_write_json_to_a_file(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    main(["connectivity", "discover"])
    main(["connectivity", "run"])
    capsys.readouterr()
    target = tmp_path / "report.json"

    assert main(["connectivity", "report", "--format", "json", "--output", str(target)]) == 0

    document = json.loads(target.read_text(encoding="utf-8"))
    assert document["mode"] == "local"
    assert [c["id"] for c in document["criteria"]][:2] == ["X-01", "X-02"]
    assert "Report written to" in capsys.readouterr().out


def test_us25_cli_probe_errors_prints_what_the_gateway_said(
    capsys: pytest.CaptureFixture[str],
) -> None:
    main(["connectivity", "discover"])
    capsys.readouterr()

    assert main(["connectivity", "run", "--probe-errors"]) == 0

    out = capsys.readouterr().out
    assert "probe bad_credential: SourceAuthRefusedError" in out
    assert "probe bad_parameter: GatewayProtocolError" in out


def test_us25_cli_probe_without_discovery_is_a_clear_error(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["connectivity", "run", "--probe-errors"]) == 1

    assert "Run discover before probing errors" in capsys.readouterr().err


def test_us25_cli_bad_sample_file_is_a_clear_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    broken = tmp_path / "items.yaml"
    broken.write_text("items: []\n", encoding="utf-8")
    monkeypatch.setenv("KP_SAMPLE_ITEMS_FILE", str(broken))

    assert main(["connectivity", "run"]) == 1

    assert "3 items per source" in capsys.readouterr().err


def test_us25_cli_real_mode_without_configuration_is_a_clear_error(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("KP_MODE", "real")

    assert main(["connectivity", "discover"]) == 1

    err = capsys.readouterr().err
    assert "KP_GATEWAY_BASE_URL" in err
    assert "secret" not in err.lower().replace("client_secret", "")
