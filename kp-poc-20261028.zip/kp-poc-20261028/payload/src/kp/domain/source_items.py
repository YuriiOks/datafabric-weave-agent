"""Source item versions, runs, sweep cursors and gateway call records."""

from __future__ import annotations

from datetime import date
from typing import Annotated

from pydantic import AwareDatetime, Field

from kp.domain.base import DomainModel
from kp.domain.enums import (
    ApprovalState,
    ChangeKind,
    ExtractionStatus,
    RunKind,
    RunOutcome,
    SourceKind,
)

DETAIL_NAMES: tuple[str, ...] = (
    "document_type",
    "domain",
    "authority",
    "classification",
    "content_owner",
)


class ItemKey(DomainModel):
    """Identity of one immutable item version: source + item + version.

    A re-run that sees the same key is a no-op.
    """

    source: SourceKind
    item_id: str
    version: str

    def __str__(self) -> str:
        return f"{self.source.value}/{self.item_id}@{self.version}"


class DocumentDetails(DomainModel):
    """The five details every governed document must carry. ``None`` means missing."""

    document_type: str | None = None
    domain: str | None = None
    authority: str | None = None
    classification: str | None = None
    content_owner: str | None = None

    def missing(self) -> tuple[str, ...]:
        """List the required details that are absent or blank.

        :return: Names from :data:`DETAIL_NAMES`, in that order
        """
        return tuple(name for name in DETAIL_NAMES if not (getattr(self, name) or "").strip())

    @property
    def is_complete(self) -> bool:
        """True when all five details are present."""
        return not self.missing()


class SourceItemVersion(DomainModel):
    """One version of one item as stored: content identity plus its approval decision.

    The content fields are immutable once written. ``approval_state`` and the three dates
    are the only fields a later sweep may update (admit, supersede, withdraw).
    """

    source: SourceKind
    item_id: str
    version: str
    native_id: str
    content_sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    media_type: str
    title: str
    author: str | None = None
    modified_at: AwareDatetime | None = None
    raw_location: str
    markdown_location: str | None = None
    fetched_at: AwareDatetime
    run_id: str
    attachment_parent: str | None = None
    extraction_status: ExtractionStatus = ExtractionStatus.NOT_REQUIRED
    extraction_failure: str | None = None
    manifest_location: str | None = None
    extractor_version: str | None = None
    approval_state: ApprovalState = ApprovalState.PENDING
    effective_date: date | None = None
    superseded_at: date | None = None
    withdrawn_at: date | None = None
    details: DocumentDetails = DocumentDetails()
    machine_authored: bool = False

    @property
    def key(self) -> ItemKey:
        """The immutable identity of this version."""
        return ItemKey(source=self.source, item_id=self.item_id, version=self.version)


class Run(DomainModel):
    """One execution of a sweep, a connectivity job or a knowledge build."""

    run_id: str
    kind: RunKind
    sources: tuple[SourceKind, ...] = ()
    started_at: AwareDatetime
    ended_at: AwareDatetime | None = None
    outcome: RunOutcome = RunOutcome.RUNNING
    items_touched: int = 0


class SweepCursor(DomainModel):
    """Saved sweep position of one source scope. Restarts continue from ``position``.

    ``scope`` narrows a source (a Jira project, a repository); use ``""`` for none.
    ``position`` is opaque to everyone except the source reader that wrote it.
    """

    source: SourceKind
    scope: str = ""
    position: str | None = None
    last_success_at: AwareDatetime | None = None
    last_attempt_at: AwareDatetime | None = None
    consecutive_failures: int = 0
    updated_at: AwareDatetime


class ChangeEvent(DomainModel):
    """A detected change of an item. Drives "what is affected" and the no-rework check.

    ``old_version`` is ``None`` for a new item; ``new_version`` is ``None`` when an item is
    withdrawn without a replacement.
    """

    event_id: str
    source: SourceKind
    item_id: str
    old_version: str | None = None
    new_version: str | None = None
    kind: ChangeKind
    detected_at: AwareDatetime
    run_id: str


class McpCallRecord(DomainModel):
    """One gateway call of the connectivity job. Holds a request digest, never the request."""

    call_id: str
    run_id: str
    tool: str
    operation: str
    request_digest: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    http_status: int | None = None
    error_class: str | None = None
    object_count: int = 0
    truncated: bool = False
    latency_ms: Annotated[float, Field(ge=0)]
    token_refreshed: bool = False
    surviving_fields: tuple[str, ...] = ()
    called_at: AwareDatetime
