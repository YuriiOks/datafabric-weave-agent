"""An in-memory view of the links in use, and the walks the queries make over it."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass, field

from kp.domain import ItemRef, Link, LinkKind, Relation


@dataclass(frozen=True, slots=True)
class Edge:
    """A link seen from one of its ends.

    :param link: The link
    :param other: The item at the far end
    :param forward: True when the walk follows the link from source to target
    """

    link: Link
    other: ItemRef
    forward: bool


class LinkGraph:
    """Adjacency over a set of links; edges can be followed in either direction.

    :param links: The links to index, normally those in use
    """

    def __init__(self, links: Iterable[Link]) -> None:
        self._links = tuple(links)
        adjacency: dict[ItemRef, list[Edge]] = defaultdict(list)
        for link in self._links:
            adjacency[link.source_ref].append(Edge(link, link.target_ref, forward=True))
            adjacency[link.target_ref].append(Edge(link, link.source_ref, forward=False))
        self._adjacency = {ref: tuple(edges) for ref, edges in adjacency.items()}

    @property
    def links(self) -> tuple[Link, ...]:
        """Every indexed link."""
        return self._links

    def stated_only(self) -> LinkGraph:
        """Return the graph restricted to stated links.

        :return: A new graph without the guessed links
        """
        return LinkGraph(link for link in self._links if link.kind is LinkKind.STATED)

    def edges(self, ref: ItemRef) -> tuple[Edge, ...]:
        """List the edges at an item.

        :param ref: The item
        :return: Its edges; empty when the item has no links
        """
        return self._adjacency.get(ref, ())

    def edges_via(self, ref: ItemRef, relation: Relation, *, forward: bool) -> tuple[Edge, ...]:
        """List the edges of one relation at an item in one direction.

        :param ref: The item to start at
        :param relation: The relation to follow
        :param forward: True from source to target, False from target to source
        :return: The edges, sorted by the key of the item at the far end
        """
        return tuple(
            sorted(
                (
                    edge
                    for edge in self.edges(ref)
                    if edge.link.relation is relation and edge.forward == forward
                ),
                key=lambda edge: edge.other.key,
            )
        )

    def follow(self, ref: ItemRef, relation: Relation, *, forward: bool) -> list[ItemRef]:
        """Follow one relation from an item in one direction.

        :param ref: The item to start at
        :param relation: The relation to follow
        :param forward: True from source to target, False from target to source
        :return: The items at the far end, in a stable order
        """
        return [edge.other for edge in self.edges_via(ref, relation, forward=forward)]

    def linked_items(self) -> frozenset[ItemRef]:
        """List every item that has at least one link.

        :return: The linked items
        """
        return frozenset(self._adjacency)


@dataclass(slots=True)
class RuleWalk:
    """What is reachable from a rule along the specification chain, and the links used."""

    requirements: set[ItemRef] = field(default_factory=set)
    specs: set[ItemRef] = field(default_factory=set)
    stories: set[ItemRef] = field(default_factory=set)
    code: set[ItemRef] = field(default_factory=set)
    tests: set[ItemRef] = field(default_factory=set)
    links: dict[str, Link] = field(default_factory=dict)

    def cross(
        self, graph: LinkGraph, ref: ItemRef, relation: Relation, *, forward: bool
    ) -> list[ItemRef]:
        """Follow one relation from an item, recording every link crossed.

        :param graph: The links in use
        :param ref: The item to start at
        :param relation: The relation to follow
        :param forward: True from source to target, False from target to source
        :return: The items reached, in a stable order
        """
        edges = graph.edges_via(ref, relation, forward=forward)
        for edge in edges:
            self.links[edge.link.link_id] = edge.link
        return [edge.other for edge in edges]


def walk_rule(graph: LinkGraph, clause: ItemRef) -> RuleWalk:
    """Walk the specification chain from a rule down to its tests.

    Requirements constrained by the clause, specs derived from the clause or from those
    requirements, stories specified by those specs, code implementing those specs and tests
    verifying that code. A path to a test exists when the walk reaches one.

    :param graph: The links in use
    :param clause: The rule's clause endpoint
    :return: The reachable items and every link crossed
    """
    walk = RuleWalk()
    walk.requirements.update(walk.cross(graph, clause, Relation.CONSTRAINED_BY, forward=False))
    walk.specs.update(walk.cross(graph, clause, Relation.DERIVED_FROM, forward=False))
    for requirement in sorted(walk.requirements, key=lambda item: item.key):
        walk.specs.update(walk.cross(graph, requirement, Relation.DERIVED_FROM, forward=False))
    for spec in sorted(walk.specs, key=lambda item: item.key):
        walk.stories.update(walk.cross(graph, spec, Relation.SPECIFIED_BY, forward=False))
        walk.code.update(walk.cross(graph, spec, Relation.IMPLEMENTED_BY, forward=True))
    for code in sorted(walk.code, key=lambda item: item.key):
        walk.tests.update(walk.cross(graph, code, Relation.VERIFIED_BY, forward=True))
    return walk


def reaches_requirement_or_clause(graph: LinkGraph, story: ItemRef) -> bool:
    """Tell whether a story is tied to a requirement or a clause through a spec.

    :param graph: The links in use
    :param story: The story endpoint
    :return: True when story, spec and requirement-or-clause are connected
    """
    for spec in graph.follow(story, Relation.SPECIFIED_BY, forward=True):
        if graph.follow(spec, Relation.DERIVED_FROM, forward=True):
            return True
    return False
