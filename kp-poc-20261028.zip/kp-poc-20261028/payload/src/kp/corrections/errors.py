"""Errors of the corrections log."""

from __future__ import annotations

from kp.errors import KpError


class CorrectionError(KpError):
    """Base class of failures in the corrections package."""


class UnknownSpecError(CorrectionError):
    """A correction names a spec that was never drafted here."""


class InvalidCorrectionError(CorrectionError, ValueError):
    """A correction lacks its text or its reason, or one of them is too long."""
