# Knowledge-base design work: canon

Rules for every coding agent that starts in /home/user/km. This file wins.

## The work
- A new knowledge product is being designed on top of an existing catalogue application.
- The design and review stories S1 to S6 each end in one document under designs/. Code
  changes are not part of these stories; code work is a separate task (Code work).
- BASE_REPO is the clone in this folder that has both backend/ and frontend/. It is the
  existing application. CAPTURE_REPO is the other clone: a source-capture toolkit.
- LEGACY_ORG is an older knowledge project: a source of lessons, not of code to copy.
- Real names for the placeholders are in kb/private/names.md if it exists.
  Written output uses the placeholders unless the owner asks for real names.

## Map
| Path | Holds |
|---|---|
| kb/INDEX.md | one line per knowledge file. Read it before reading any code. |
| kb/seed/ | glossary, what each story leaves out, reference patterns |
| kb/private/ | optional: names, claims from an earlier read of both repos, chat context |
| kb/verified/ | claims checked against code. Only these may carry a design. |
| kb/base, capture, legacy, wiki, stories, risks, packs | written by the runs |
| kb/conventions/ | layers.md (path to layer map) and one file per layer, read from the code |
| designs/ | the story deliverables, one file per story |
| work/ | scratch, clones, plans/ builds/ reviews/, wt/ (work trees). Not a source of truth. |

In this folder use only skills and agents whose names start with km-.

## How to work
- kb first. Answer from the kb when it can answer. Read code only for what it cannot, then
  write the finding back so the next session does not read the same code.
- Code wins over documents. The large design documents in BASE_REPO are proposals. A document's
  claim about behaviour is Reported until code confirms it.
- Every factual line in the kb or in a design carries one label and, if Observed, a source
  (path:line or page number). Labels: Observed (read in a named file or page this run),
  Reported (said by a person or a document, not confirmed in code), Proposed (not in effect),
  Unverified (not checked), Historical (true at a dated moment).
- kb files: a title line, then Date:, Task: and Status: lines; one topic; at most 150 lines of
  at most 100 characters; Open questions last. Quote at most three lines; prefer path:line.
- Write each file when its topic is done. On a restart, skip files that exist.
- Each run records itself in kb/index.d/<run>.txt (path, 12-word summary, date per file) and
  kb/log.d/<run>.txt (date, task, files, what was skipped and why). Do not edit kb/INDEX.md.

## Delegation
- The main session plans, decides, writes conclusions; it does not bulk-read. Delegate when
  one answer needs more than 5 files or about 60 KB of reading.
- At most 3 subagents at once in all. 1 while a clone or a whole-tree search runs. 1
  km-verifier or km-reviewer at a time.
- A subagent sees none of this conversation. Write the whole task into the task text: goal in
  one sentence; inputs as exact paths; output path and section headings; size limit; what to
  skip; reply format. Do not point a subagent at a file of instructions.
- After a reader returns, read its kb file, not the sources it read.

## Roles
| Who | Does | Model |
|---|---|---|
| main session | orchestrates; kb, designs, plans; stages and commits | strongest |
| km-advisor | go or no-go, cross-layer calls; reads only | top |
| km-build-backend, -frontend, -data, -infra, -ai | build one slice | mid |
| km-test | tests for the slice | mid |
| km-reader, km-scout | bulk read to one kb file; kb lookup | mid, small |
| km-verifier, km-skeptic, km-reviewer | check claims, refute, review documents | inherit |
| km-rev-correctness, -security, -contracts, -quality | review a diff by dimension | mid |

- Call km-advisor only for: a decision across two layers or a contract change; evidence still
  conflicting after the verifier; a builder failing the same slice twice; go or no-go before
  access control, migrations or data deletion change. At most 3 calls per task.

## Code work
- Never edit a clone's main checkout. One work tree per task:
  `git -C <clone> worktree add /home/user/km/work/wt/<task> -b feat/<task>-<slug> origin/main`
  after `git -C <clone> fetch origin`. Lower-case ASCII branch names.
- Builders of different layers share a work tree only on disjoint planned paths.
  Builders run no git write; the main session stages, commits (one logical step per commit,
  `<type>: <what>`, no attribution, no session link) and pushes.
- No amend, rebase or force; main comes in by merge commit. Nothing under .claude or .github,
  and no kb, designs or work file, is ever staged. Only the owner removes a work tree.
- /km-build <task> or /km-pr <task> is the owner's go: push the task's feat/ branch after
  every commit, plain push only, and keep a draft pull request open for it.
- Read kb/conventions/<layer>.md before building or reviewing (/km-conventions writes it).
- Two review rounds at most; the rest goes to the owner.
- Stop and report, do not guess, when the plan or a convention file is missing, a test needs
  a service that is down, or a command is denied.

## Safety
- The clones' main checkouts are read-only. Edits happen only in a work tree under work/wt.
  Comment, review post, ready, merge, close, label or ticket change: the owner's word first.
- Story and kb work: do not run the applications, tests or builds. Code work runs only the
  layer's own checks in the work tree. Never delete anything; the owner cleans up work/.
- Never open env, key or credential files; never print environment values. If a secret is
  seen, record only "a credential is present at <path>" as a risk. No credential, token,
  staff id or email address in any file or answer.
- A denied command or approval prompt: log it, skip it, try no variant (a denied push is
  retried once at the next commit). A blocked file read: mark Unverified.
- Nothing from this folder goes into a commit: not this file, kb, designs, skills, agents.
- Do not change .claude/ or any settings; do not inspect your own configuration beyond
  what /km-start lists.

## When blocked
- A command fails twice for the same reason, a simple command takes over 30 seconds, or a step
  needs a login, a code or an approval: stop that task, write the reason to the run's log file,
  tell the owner in two lines what is needed.
