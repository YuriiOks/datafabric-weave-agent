"""The link store: Core persistence of links as facts with a validity period.

A change closes the old fact (``valid_to``) and opens a new one (``valid_from``); no row is
ever updated except to set ``valid_to``. Validity periods are half-open: a link applies at
``t`` when ``valid_from <= t < valid_to``.
"""

from __future__ import annotations

import hashlib
import logging
from collections.abc import Collection, Iterable
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Annotated

from pydantic import Field, ValidationError
from sqlalchemy import ColumnElement, Connection, RowMapping, func, insert, or_, select, update

from kp.clock import Clock, SystemClock
from kp.domain import DomainModel, ItemRef, ItemType, Link, LinkKind, LinkState, Relation
from kp.links.candidate import LinkCandidate, conformance_violation
from kp.links.errors import LinkModelViolationError, LinkNotFoundError
from kp.store.schema import link as link_table

logger = logging.getLogger(__name__)

_IN_USE_STATES = (LinkState.STATED.value, LinkState.PROPOSED.value)
_CHECKED_STATES = (LinkState.STATED.value, LinkState.PROPOSED.value, LinkState.REVIEW.value)
_ONE_TICK = timedelta(microseconds=1)


class AssertOutcome(StrEnum):
    """What asserting a link did to the store."""

    OPENED = "opened"
    CHANGED = "changed"
    UNCHANGED = "unchanged"


class AssertedLink(DomainModel):
    """The link now in force for a fact, and whether asserting it changed anything."""

    link: Link
    outcome: AssertOutcome


class LinkStatistics(DomainModel):
    """Counts over the open links, for the guessed-share report and the publication checks.

    ``in_use`` links are the stated and proposed ones; ``review`` links are listed for a
    person and never used by queries. ``checked`` counts the open links tested against the
    model (in use plus review) and ``nonconforming`` those that failed.
    """

    in_use: int
    stated: int
    guessed: int
    review: int
    checked: int
    nonconforming: int
    average_guessed_score: Annotated[float, Field(ge=0, le=1)] | None

    @property
    def guessed_share(self) -> float:
        """Guessed share of the links in use; 0 when there are none."""
        return self.guessed / self.in_use if self.in_use else 0.0

    @property
    def model_conformance(self) -> float:
        """Share of checked links that conform to the model; 1 when there are none."""
        return (self.checked - self.nonconforming) / self.checked if self.checked else 1.0


def link_identity(candidate: LinkCandidate, valid_from: datetime) -> str:
    """Derive the stable identity of a link fact that opens at ``valid_from``.

    :param candidate: The link content
    :param valid_from: When the fact opens
    :return: ``lnk-`` followed by 24 hex characters
    """
    parts = (
        candidate.source_ref.item_type.value,
        candidate.source_ref.key,
        candidate.relation.value,
        candidate.target_ref.item_type.value,
        candidate.target_ref.key,
        valid_from.isoformat(),
    )
    digest = hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()
    return f"lnk-{digest[:24]}"


def _to_link(row: RowMapping) -> Link:
    return Link(
        link_id=row["link_id"],
        source_ref=ItemRef(item_type=ItemType(row["source_item_type"]), key=row["source_key"]),
        relation=Relation(row["relation"]),
        target_ref=ItemRef(item_type=ItemType(row["target_item_type"]), key=row["target_key"]),
        kind=LinkKind(row["kind"]),
        state=LinkState(row["state"]),
        score=row["score"],
        evidence=row["evidence"],
        valid_from=row["valid_from"],
        valid_to=row["valid_to"],
    )


def _to_row(link: Link) -> dict[str, object]:
    return {
        "link_id": link.link_id,
        "source_item_type": link.source_ref.item_type.value,
        "source_key": link.source_ref.key,
        "relation": link.relation.value,
        "target_item_type": link.target_ref.item_type.value,
        "target_key": link.target_ref.key,
        "kind": link.kind.value,
        "state": link.state.value,
        "score": link.score,
        "evidence": link.evidence,
        "valid_from": link.valid_from,
        "valid_to": link.valid_to,
    }


def _same_content(link: Link, candidate: LinkCandidate) -> bool:
    return (
        link.kind is candidate.kind
        and link.state is candidate.state
        and link.score == candidate.score
        and link.evidence == candidate.evidence
    )


class SqlLinkStore:
    """Link persistence over the ``link`` table. Dialect-neutral; the PostgreSQL stand-in.

    :param connection: A connection inside the caller's unit of work
    :param clock: Time source for validity periods
    """

    def __init__(self, connection: Connection, clock: Clock | None = None) -> None:
        self._connection = connection
        self._clock = clock if clock is not None else SystemClock()

    def assert_link(self, candidate: LinkCandidate) -> AssertedLink:
        """Make a fact true now, without overwriting anything.

        With no open link for the fact, a new one opens, never before an earlier link of the
        same fact was closed, so the periods of a fact do not overlap. With an open link
        that has the same kind, state, score and evidence, nothing changes. Otherwise the
        open link is closed and a new one opens at the same instant.

        :param candidate: The link content
        :return: The link now in force and what happened
        :raises LinkModelViolationError: If the candidate violates the relation model
        """
        violation = conformance_violation(candidate)
        if violation is not None:
            raise LinkModelViolationError(violation)
        current = self.open_fact(*candidate.fact)
        effective = self._clock.now()
        outcome = AssertOutcome.OPENED
        if current is None:
            effective = max(effective, self._latest_close(*candidate.fact) or effective)
        else:
            if _same_content(current, candidate):
                return AssertedLink(link=current, outcome=AssertOutcome.UNCHANGED)
            effective = self._close_at(current)
            outcome = AssertOutcome.CHANGED
        link = candidate.to_link(link_identity(candidate, effective), effective)
        self._connection.execute(insert(link_table).values(_to_row(link)))
        return AssertedLink(link=link, outcome=outcome)

    def close_fact(self, source: ItemRef, relation: Relation, target: ItemRef) -> Link | None:
        """Close the open link of a fact, if any, as of now.

        :param source: Where the edge starts
        :param relation: The relation
        :param target: Where the edge ends
        :return: The closed link, or ``None`` when no link was open
        """
        current = self.open_fact(source, relation, target)
        if current is None:
            return None
        closed_at = self._close_at(current)
        return current.model_copy(update={"valid_to": closed_at})

    def close_links_of(self, ref: ItemRef) -> int:
        """Close every open link that starts or ends at an item (it was withdrawn or replaced).

        :param ref: The item
        :return: How many links were closed
        """
        links = self.links_of(ref, open_only=True)
        for link in links:
            self._close_at(link)
        return len(links)

    def open_fact(self, source: ItemRef, relation: Relation, target: ItemRef) -> Link | None:
        """Return the open link of a fact, whatever its state.

        :param source: Where the edge starts
        :param relation: The relation
        :param target: Where the edge ends
        :return: The open link, or ``None``
        """
        statement = (
            select(link_table)
            .where(*_fact_filter(source, relation, target), link_table.c.valid_to.is_(None))
            .order_by(link_table.c.valid_from.desc())
            .limit(1)
        )
        row = self._connection.execute(statement).mappings().first()
        return None if row is None else _to_link(row)

    def open_facts(self, relation: Relation) -> dict[tuple[ItemRef, Relation, ItemRef], Link]:
        """Return the open link of every fact of one relation, whatever its state.

        One query instead of one lookup per pair, for callers that visit many pairs.

        :param relation: The relation
        :return: The open links keyed by their ``(source, relation, target)`` fact
        """
        statement = select(link_table).where(
            link_table.c.relation == relation.value, link_table.c.valid_to.is_(None)
        )
        links = (_to_link(row) for row in self._connection.execute(statement).mappings())
        return {(link.source_ref, link.relation, link.target_ref): link for link in links}

    def get(self, link_id: str) -> Link:
        """Fetch one link by identity.

        :param link_id: The link identity
        :return: The link
        :raises LinkNotFoundError: If no such link exists
        """
        row = (
            self._connection.execute(select(link_table).where(link_table.c.link_id == link_id))
            .mappings()
            .first()
        )
        if row is None:
            raise LinkNotFoundError(f"No link {link_id}")
        return _to_link(row)

    def history(self, source: ItemRef, relation: Relation, target: ItemRef) -> list[Link]:
        """List every fact ever held for the triple, oldest first.

        :param source: Where the edge starts
        :param relation: The relation
        :param target: Where the edge ends
        :return: The closed and open links in order of ``valid_from``
        """
        statement = (
            select(link_table)
            .where(*_fact_filter(source, relation, target))
            .order_by(link_table.c.valid_from)
        )
        return [_to_link(row) for row in self._connection.execute(statement).mappings()]

    def links_of(self, ref: ItemRef, *, open_only: bool = True) -> list[Link]:
        """List the links that start or end at an item.

        :param ref: The item
        :param open_only: When True, only links that have not been closed
        :return: The links, in a stable order
        """
        statement = select(link_table).where(
            or_(
                (link_table.c.source_item_type == ref.item_type.value)
                & (link_table.c.source_key == ref.key),
                (link_table.c.target_item_type == ref.item_type.value)
                & (link_table.c.target_key == ref.key),
            )
        )
        if open_only:
            statement = statement.where(link_table.c.valid_to.is_(None))
        statement = statement.order_by(link_table.c.valid_from, link_table.c.link_id)
        return [_to_link(row) for row in self._connection.execute(statement).mappings()]

    def open_links(self, states: Collection[LinkState] | None = None) -> list[Link]:
        """List the open links, optionally limited to some states.

        :param states: States to keep; ``None`` keeps all
        :return: The open links in a stable order
        """
        statement = select(link_table).where(link_table.c.valid_to.is_(None))
        if states is not None:
            statement = statement.where(link_table.c.state.in_([s.value for s in states]))
        statement = statement.order_by(link_table.c.link_id)
        return self._conforming(self._connection.execute(statement).mappings())

    def in_use_links(self, as_at: datetime | None = None) -> list[Link]:
        """List the stated and proposed links that apply at an instant.

        Review and dropped links are never in use. Rows that no longer conform to the model
        are skipped and counted in the log.

        :param as_at: A timezone-aware instant; ``None`` means the links open now
        :return: The links in force, in a stable order
        """
        statement = select(link_table).where(link_table.c.state.in_(_IN_USE_STATES))
        if as_at is None:
            statement = statement.where(link_table.c.valid_to.is_(None))
        else:
            statement = statement.where(
                link_table.c.valid_from <= as_at,
                or_(link_table.c.valid_to.is_(None), link_table.c.valid_to > as_at),
            )
        statement = statement.order_by(link_table.c.link_id)
        return self._conforming(self._connection.execute(statement).mappings())

    def review_list(self) -> list[Link]:
        """List the guessed links waiting for a person, best score first.

        :return: Open links in state ``review``
        """
        links = self.open_links({LinkState.REVIEW})
        return sorted(links, key=lambda link: (-(link.score or 0.0), link.link_id))

    def statistics(self) -> LinkStatistics:
        """Count the open links for the guessed-share report and the publication checks.

        :return: The statistics over stated, proposed and review links
        """
        statement = select(link_table).where(
            link_table.c.valid_to.is_(None), link_table.c.state.in_(_CHECKED_STATES)
        )
        rows = list(self._connection.execute(statement).mappings())
        links = self._conforming(rows)
        in_use = [link for link in links if link.state is not LinkState.REVIEW]
        guessed_scores = [link.score or 0.0 for link in in_use if link.kind is LinkKind.GUESSED]
        return LinkStatistics(
            in_use=len(in_use),
            stated=len(in_use) - len(guessed_scores),
            guessed=len(guessed_scores),
            review=len(links) - len(in_use),
            checked=len(rows),
            nonconforming=len(rows) - len(links),
            average_guessed_score=(
                sum(guessed_scores) / len(guessed_scores) if guessed_scores else None
            ),
        )

    def _conforming(self, rows: Iterable[RowMapping]) -> list[Link]:
        links: list[Link] = []
        skipped = 0
        for row in rows:
            try:
                links.append(_to_link(row))
            except (ValidationError, ValueError):
                skipped += 1
        if skipped:
            logger.warning(
                "Skipped links that do not conform to the model", extra={"skipped": skipped}
            )
        return links

    def _latest_close(
        self, source: ItemRef, relation: Relation, target: ItemRef
    ) -> datetime | None:
        """Return when the most recently closed link of a fact ended, if any."""
        statement = select(func.max(link_table.c.valid_to)).where(
            *_fact_filter(source, relation, target)
        )
        return self._connection.execute(statement).scalar()

    def _close_at(self, link: Link) -> datetime:
        """Close an open link now (strictly after its start) and return the closing instant."""
        closed_at = max(self._clock.now(), link.valid_from + _ONE_TICK)
        self._connection.execute(
            update(link_table)
            .where(link_table.c.link_id == link.link_id)
            .values(valid_to=closed_at)
        )
        return closed_at


def _fact_filter(source: ItemRef, relation: Relation, target: ItemRef) -> list[ColumnElement[bool]]:
    return [
        link_table.c.source_item_type == source.item_type.value,
        link_table.c.source_key == source.key,
        link_table.c.relation == relation.value,
        link_table.c.target_item_type == target.item_type.value,
        link_table.c.target_key == target.key,
    ]
