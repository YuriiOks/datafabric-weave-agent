"""US-19 / US-22 for the REST publisher, against an in-memory fake of the repository API."""

from __future__ import annotations

import base64
import json
from collections.abc import Callable

import httpx
import pytest
from pydantic import SecretStr

from kp.config import Settings
from kp.errors import ConfigurationError, WriteNotPermittedError
from kp.writeback import GitHubRestPublisher, PublishError, PublishRequest
from writeback.writeback_support import REPOSITORY

BRANCH = "spec/pay-101"
PATH = "specs/PAY-101.md"
API = "https://api.example.invalid"
ROOT = f"/repos/{REPOSITORY}"


class FakeRepositoryApi:
    """Just enough of a repository API: refs, contents and pull requests."""

    def __init__(self) -> None:
        self.refs: dict[str, str] = {"main": "b" * 40}
        self.files: dict[tuple[str, str], str] = {}
        self.pulls: list[dict[str, object]] = []
        self.calls: list[tuple[str, str]] = []
        self.bodies: list[dict[str, object]] = []
        self.fail: Callable[[httpx.Request], httpx.Response | None] = lambda _request: None

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.calls.append((request.method, request.url.path))
        if request.content:
            self.bodies.append(json.loads(request.content))
        failure = self.fail(request)
        if failure is not None:
            return failure
        path = request.url.path
        if not path.startswith(ROOT + "/"):
            return httpx.Response(404, json={"message": "wrong repository"})
        rest = path.removeprefix(ROOT + "/")
        if rest.startswith("git/"):
            return self._git(request, rest.removeprefix("git/"))
        if rest.startswith("contents/"):
            return self._contents(request, rest.removeprefix("contents/"))
        if rest.startswith("pulls"):
            return self._pulls(request, rest)
        return httpx.Response(500, json={"message": "unexpected request"})

    def _git(self, request: httpx.Request, rest: str) -> httpx.Response:
        if rest.startswith("ref/heads/"):
            sha = self.refs.get(rest.removeprefix("ref/heads/"))
            if sha is None:
                return httpx.Response(404, json={})
            return httpx.Response(200, json={"object": {"sha": sha}})
        body = json.loads(request.content)
        self.refs[str(body["ref"]).removeprefix("refs/heads/")] = str(body["sha"])
        return httpx.Response(201, json={})

    def _pulls(self, request: httpx.Request, rest: str) -> httpx.Response:
        if request.method == "GET":
            head = request.url.params["head"].split(":", 1)[1]
            return httpx.Response(200, json=[p for p in self.pulls if p["head_name"] == head])
        body = json.loads(request.content)
        if request.method == "PATCH":
            pull = self.pulls[int(rest.removeprefix("pulls/")) - 1]
            pull.update(title=body["title"], body=body["body"])
            return httpx.Response(200, json=pull)
        number = len(self.pulls) + 1
        self.pulls.append(
            {
                "number": number,
                "html_url": f"{API}/pull/{number}",
                "state": "open",
                "title": body["title"],
                "body": body["body"],
                "head_name": body["head"],
            }
        )
        return httpx.Response(201, json=self.pulls[-1])

    def _contents(self, request: httpx.Request, path: str) -> httpx.Response:
        if request.method == "GET":
            branch = request.url.params["ref"]
            text = self.files.get((branch, path))
            if text is None:
                return httpx.Response(404, json={})
            encoded = base64.encodebytes(text.encode("utf-8")).decode("ascii")
            return httpx.Response(200, json={"sha": "f" * 40, "content": encoded})
        body = json.loads(request.content)
        branch = str(body["branch"])
        if branch not in self.refs:
            return httpx.Response(404, json={})
        if (branch, path) in self.files and "sha" not in body:
            return httpx.Response(422, json={})
        self.files[(branch, path)] = base64.b64decode(str(body["content"])).decode("utf-8")
        self.refs[branch] = f"{len(self.files):040d}"
        return httpx.Response(201, json={"commit": {"sha": self.refs[branch]}})


def make_publisher(api: FakeRepositoryApi) -> GitHubRestPublisher:
    client = httpx.Client(base_url=API, transport=httpx.MockTransport(api))
    return GitHubRestPublisher(client, repository=REPOSITORY)


def request(content: str = "# Spec\n", **overrides: str) -> PublishRequest:
    values = {
        "repository": REPOSITORY,
        "branch": BRANCH,
        "path": PATH,
        "content": content,
        "commit_message": "Draft spec\n\nMachine-Authored: true\n",
        "pr_title": "[PAY-101] Title",
        "pr_body": "body",
    }
    values.update(overrides)
    return PublishRequest.model_validate(values)


def test_us19_publish_creates_branch_file_and_pull_request() -> None:
    api = FakeRepositoryApi()

    result = make_publisher(api).publish(request())

    assert (result.created, result.committed, result.pr_number) == (True, True, 1)
    assert result.pr_url == f"{API}/pull/1"
    assert api.refs[BRANCH] == result.commit_sha
    assert api.files[(BRANCH, PATH)] == "# Spec\n"
    assert api.pulls[0]["head_name"] == BRANCH


def test_us19_the_commit_is_machine_authored() -> None:
    api = FakeRepositoryApi()

    make_publisher(api).publish(request())

    (put,) = [body for body in api.bodies if "content" in body]
    assert "Machine-Authored: true" in str(put["message"])
    assert "machine" in str(put["author"]).lower()
    assert put["author"] == put["committer"]
    assert put["branch"] == BRANCH


def test_us19_same_draft_published_twice_yields_no_second_pull_request() -> None:
    api = FakeRepositoryApi()
    publisher = make_publisher(api)

    first = publisher.publish(request())
    api.calls.clear()
    second = publisher.publish(request())

    assert (second.created, second.committed) == (False, False)
    assert (second.pr_number, second.pr_url, second.commit_sha) == (
        first.pr_number,
        first.pr_url,
        first.commit_sha,
    )
    assert len(api.pulls) == 1
    assert [call for call in api.calls if call[0] in {"POST", "PUT", "PATCH"}] == []


def test_us19_a_changed_draft_updates_the_same_pull_request() -> None:
    api = FakeRepositoryApi()
    publisher = make_publisher(api)
    first = publisher.publish(request("# One\n", pr_body="first"))

    second = publisher.publish(request("# Two\n", pr_body="second"))

    assert (second.created, second.committed, second.pr_number) == (False, True, first.pr_number)
    assert api.files[(BRANCH, PATH)] == "# Two\n"
    assert api.pulls[0]["body"] == "second"
    assert len(api.pulls) == 1


def test_us22_nothing_is_written_to_the_base_branch() -> None:
    api = FakeRepositoryApi()
    publisher = make_publisher(api)

    publisher.publish(request("# One\n"))
    publisher.publish(request("# Two\n"))

    assert api.refs["main"] == "b" * 40
    assert not any(branch == "main" for branch, _ in api.files)
    assert all(body.get("branch") != "main" for body in api.bodies)
    assert all(body.get("ref") != "refs/heads/main" for body in api.bodies)
    assert {path for method, path in api.calls if method != "GET"} <= {
        f"{ROOT}/git/refs",
        f"{ROOT}/contents/{PATH}",
        f"{ROOT}/pulls",
        f"{ROOT}/pulls/1",
    }


def test_us22_a_request_for_the_base_branch_is_refused_before_any_call() -> None:
    api = FakeRepositoryApi()

    with pytest.raises(WriteNotPermittedError):
        make_publisher(api).publish(request(branch="main"))

    assert api.calls == []


def test_us22_a_request_for_another_repository_is_refused_before_any_call() -> None:
    api = FakeRepositoryApi()

    with pytest.raises(WriteNotPermittedError):
        make_publisher(api).publish(request(repository="other-org/other-repo"))

    assert api.calls == []


def test_us19_an_api_refusal_is_a_typed_publish_error() -> None:
    api = FakeRepositoryApi()
    api.fail = lambda _request: httpx.Response(403, json={"message": "forbidden"})

    with pytest.raises(PublishError):
        make_publisher(api).publish(request())


def test_us19_an_unreachable_api_is_a_typed_publish_error() -> None:
    def refuse(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("down", request=request)

    publisher = GitHubRestPublisher(
        httpx.Client(base_url=API, transport=httpx.MockTransport(refuse)), repository=REPOSITORY
    )

    with pytest.raises(PublishError):
        publisher.publish(request())


def test_us19_a_closed_pull_request_is_not_reopened_or_duplicated() -> None:
    api = FakeRepositoryApi()
    publisher = make_publisher(api)
    first = publisher.publish(request())
    api.pulls[0]["state"] = "closed"
    refs_before, files_before = dict(api.refs), dict(api.files)
    api.calls.clear()

    with pytest.raises(PublishError):
        publisher.publish(request("# Two\n"))

    assert len(api.pulls) == 1
    assert (api.refs, api.files) == (refs_before, files_before)
    assert api.refs[BRANCH] == first.commit_sha
    assert [call for call in api.calls if call[0] != "GET"] == []


def test_us19_a_listing_that_is_not_json_is_a_typed_publish_error_before_any_write() -> None:
    api = FakeRepositoryApi()
    api.fail = lambda request: (
        httpx.Response(200, content=b"<html>", headers={"content-type": "text/html"})
        if request.url.path.endswith("/pulls")
        else None
    )

    with pytest.raises(PublishError, match="invalid JSON"):
        make_publisher(api).publish(request())

    assert api.files == {}
    assert set(api.refs) == {"main"}


@pytest.mark.parametrize("listing", [{"not": "a list"}, ["not an object"]])
def test_us19_a_listing_of_the_wrong_shape_is_a_typed_publish_error(listing: object) -> None:
    api = FakeRepositoryApi()
    api.fail = lambda request: (
        httpx.Response(200, json=listing) if request.url.path.endswith("/pulls") else None
    )

    with pytest.raises(PublishError, match="unexpected shape"):
        make_publisher(api).publish(request())


def test_us19_a_rejected_branch_creation_is_not_mistaken_for_an_existing_branch() -> None:
    api = FakeRepositoryApi()
    api.fail = lambda request: (
        httpx.Response(422, json={"message": "invalid"})
        if request.method == "POST" and request.url.path.endswith("/git/refs")
        else None
    )

    with pytest.raises(PublishError, match="branch"):
        make_publisher(api).publish(request())

    assert api.files == {}
    assert api.pulls == []


def test_us19_a_branch_created_concurrently_is_used_as_it_is() -> None:
    api = FakeRepositoryApi()

    def lose_the_race(request: httpx.Request) -> httpx.Response | None:
        if request.method == "POST" and request.url.path.endswith("/git/refs"):
            api.refs[BRANCH] = "c" * 40
            return httpx.Response(422, json={"message": "Reference already exists"})
        return None

    api.fail = lose_the_race

    result = make_publisher(api).publish(request())

    assert (result.created, result.committed) == (True, True)
    assert api.files[(BRANCH, PATH)] == "# Spec\n"


def test_us19_from_settings_uses_the_configured_repository_and_credential() -> None:
    seen: list[httpx.Request] = []

    api = FakeRepositoryApi()

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return api(request)

    settings = Settings(
        _env_file=None,
        spec_repo=REPOSITORY,
        source_token_github=SecretStr("synthetic-token"),
        source_token_header="X-Source-Token",  # noqa: S106 - a header name
    )
    publisher = GitHubRestPublisher.from_settings(
        settings, base_url=API, transport=httpx.MockTransport(handler)
    )

    publisher.publish(request())

    assert seen[0].headers["X-Source-Token"] == "synthetic-token"
    assert "authorization" not in seen[0].headers
    assert all(call.url.path.startswith(ROOT) for call in seen)


def test_us19_from_settings_without_a_repository_is_a_configuration_error() -> None:
    with pytest.raises(ConfigurationError):
        GitHubRestPublisher.from_settings(Settings(_env_file=None), base_url=API)
