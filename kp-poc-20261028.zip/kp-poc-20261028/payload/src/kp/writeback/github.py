"""Publisher that talks to a GitHub-style REST API: branch ref, file, pull request by head.

Every step is find-or-create, so a repeated publish adds nothing: the branch ref is created
only when missing, the file is written only when its content differs, and the pull request is
found by its head branch before one is opened. The repository comes from the constructor
(settings), never from the request; a request naming another repository is refused.
"""

from __future__ import annotations

import base64
import binascii
import logging
from collections.abc import Collection
from typing import cast
from urllib.parse import quote

import httpx
from pydantic import JsonValue

from kp.config import Settings
from kp.errors import ConfigurationError
from kp.writeback.errors import BranchNotPermittedError, PublishError, RepositoryNotPermittedError
from kp.writeback.http import (
    HTTP_CREATED,
    HTTP_NOT_FOUND,
    HTTP_OK,
    HTTP_UNPROCESSABLE,
    build_client,
    source_token_header,
)
from kp.writeback.models import PublishRequest, PublishResult
from kp.writeback.rendering import MACHINE_AUTHOR_EMAIL, MACHINE_AUTHOR_NAME

logger = logging.getLogger(__name__)

_Json = dict[str, JsonValue]


class GitHubRestPublisher:
    """Publishes specs through REST calls.

    :param client: An HTTP client whose base URL is the API root
    :param repository: ``<owner>/<repository>``, the only repository this publisher writes
    :param base_branch: The branch pull requests target; it is never written to
    """

    def __init__(self, client: httpx.Client, *, repository: str, base_branch: str = "main") -> None:
        self._client = client
        self._repository = repository
        self._owner = repository.split("/", 1)[0]
        self._base = base_branch

    @classmethod
    def from_settings(
        cls,
        settings: Settings,
        *,
        base_url: str,
        base_branch: str = "main",
        transport: httpx.BaseTransport | None = None,
    ) -> GitHubRestPublisher:
        """Build a publisher for the configured spec repository.

        :param settings: Platform settings (``spec_repo`` and the GitHub source token)
        :param base_url: API root of the repository host
        :param base_branch: The branch pull requests target
        :param transport: A transport to use instead of the network (tests)
        :return: The publisher; it owns its HTTP client
        :raises kp.errors.ConfigurationError: If ``KP_SPEC_REPO`` is not set
        """
        repository = (settings.spec_repo or "").strip()
        if not repository or repository.startswith("<"):
            raise ConfigurationError("KP_SPEC_REPO must be set before the write tools can write")
        client = build_client(
            base_url,
            token=settings.source_token_github,
            token_header=source_token_header(settings),
            transport=transport,
        )
        return cls(client, repository=repository, base_branch=base_branch)

    def publish(self, request: PublishRequest) -> PublishResult:
        """Create the branch, write the spec file and find or open the pull request.

        :param request: A request that passed the write limits
        :return: The pull request and the branch head commit
        :raises kp.writeback.errors.RepositoryNotPermittedError: If the request names another
            repository
        :raises kp.writeback.errors.BranchNotPermittedError: If the branch is the base branch
        :raises kp.writeback.errors.PublishError: If the API refuses or fails, or the pull
            request for the branch is no longer open (nothing is written then)
        """
        if request.repository.casefold() != self._repository.casefold():
            raise RepositoryNotPermittedError("Repository is not the configured spec repository")
        if request.branch == self._base:
            raise BranchNotPermittedError(
                "Branch is the base branch; specs go through a pull request"
            )
        pull = self._find_open_pull_request(request.branch)
        head = self._ensure_branch(request.branch)
        commit_sha, committed = self._ensure_file(request, head)
        number, url, created = self._ensure_pull_request(request, pull)
        logger.info(
            "Spec published through REST",
            extra={"branch": request.branch, "pr_number": number, "committed": committed},
        )
        return PublishResult(
            branch=request.branch,
            pr_url=url,
            pr_number=number,
            commit_sha=commit_sha,
            created=created,
            committed=committed,
        )

    def _call(
        self,
        method: str,
        path: str,
        *,
        expected: Collection[int],
        json_body: _Json | None = None,
        params: dict[str, str] | None = None,
    ) -> httpx.Response:
        try:
            response = self._client.request(method, path, json=json_body, params=params)
        except httpx.HTTPError as exc:
            raise PublishError("The repository API could not be reached") from exc
        if response.status_code not in expected:
            logger.warning(
                "Repository API refused a request",
                extra={"method": method, "status": response.status_code},
            )
            raise PublishError(f"The repository API answered {response.status_code} to {method}")
        return response

    def _repo_path(self, suffix: str) -> str:
        return f"/repos/{self._repository}/{suffix}"

    @staticmethod
    def _json(response: httpx.Response) -> _Json:
        try:
            body = response.json()
        except ValueError as exc:
            raise PublishError("The repository API answered with invalid JSON") from exc
        if not isinstance(body, dict):
            raise PublishError("The repository API answered with an unexpected shape")
        return cast(_Json, body)

    def _ensure_branch(self, branch: str) -> str:
        found = self._call(
            "GET",
            self._repo_path(f"git/ref/heads/{quote(branch, safe='/')}"),
            expected={HTTP_OK, HTTP_NOT_FOUND},
        )
        if found.status_code == HTTP_OK:
            return self._sha_of(self._json(found))
        base = self._call(
            "GET",
            self._repo_path(f"git/ref/heads/{quote(self._base, safe='/')}"),
            expected={HTTP_OK},
        )
        base_sha = self._sha_of(self._json(base))
        created = self._call(
            "POST",
            self._repo_path("git/refs"),
            expected={HTTP_CREATED, HTTP_UNPROCESSABLE},
            json_body={"ref": f"refs/heads/{branch}", "sha": base_sha},
        )
        if created.status_code == HTTP_CREATED:
            return base_sha
        # A 422 means the branch exists already (created concurrently) or the request was
        # invalid; only the first is acceptable, so look the branch up again.
        again = self._call(
            "GET",
            self._repo_path(f"git/ref/heads/{quote(branch, safe='/')}"),
            expected={HTTP_OK, HTTP_NOT_FOUND},
        )
        if again.status_code != HTTP_OK:
            raise PublishError("The repository API refused to create the branch")
        return self._sha_of(self._json(again))

    @staticmethod
    def _sha_of(body: _Json) -> str:
        reference = body.get("object")
        sha = reference.get("sha") if isinstance(reference, dict) else None
        if not isinstance(sha, str):
            raise PublishError("The repository API answered without a commit id")
        return sha

    def _ensure_file(self, request: PublishRequest, head_sha: str) -> tuple[str, bool]:
        file_path = self._repo_path(f"contents/{quote(request.path, safe='/')}")
        existing = self._call(
            "GET", file_path, expected={HTTP_OK, HTTP_NOT_FOUND}, params={"ref": request.branch}
        )
        body: _Json = {
            "message": request.commit_message,
            "content": base64.b64encode(request.content.encode("utf-8")).decode("ascii"),
            "branch": request.branch,
            "author": {"name": MACHINE_AUTHOR_NAME, "email": MACHINE_AUTHOR_EMAIL},
            "committer": {"name": MACHINE_AUTHOR_NAME, "email": MACHINE_AUTHOR_EMAIL},
        }
        if existing.status_code == HTTP_OK:
            current = self._json(existing)
            if self._decoded(current) == request.content:
                return head_sha, False
            file_sha = current.get("sha")
            if isinstance(file_sha, str):
                body["sha"] = file_sha
        written = self._json(
            self._call("PUT", file_path, expected={HTTP_OK, HTTP_CREATED}, json_body=body)
        )
        commit = written.get("commit")
        sha = commit.get("sha") if isinstance(commit, dict) else None
        if not isinstance(sha, str):
            raise PublishError("The repository API answered without a commit id")
        return sha, True

    @staticmethod
    def _decoded(current: _Json) -> str | None:
        content = current.get("content")
        if not isinstance(content, str):
            return None
        try:
            return base64.b64decode(content).decode("utf-8")
        except (binascii.Error, UnicodeDecodeError):
            return None

    def _find_open_pull_request(self, branch: str) -> _Json | None:
        """Look up the pull request of a branch before anything is written.

        :raises kp.writeback.errors.PublishError: If the pull request exists and is not open
        """
        listing = self._call(
            "GET",
            self._repo_path("pulls"),
            expected={HTTP_OK},
            params={"head": f"{self._owner}:{branch}", "base": self._base, "state": "all"},
        )
        try:
            found = listing.json()
        except ValueError as exc:
            raise PublishError("The repository API answered with invalid JSON") from exc
        if not isinstance(found, list):
            raise PublishError("The repository API answered with an unexpected shape")
        if not found:
            return None
        pull = found[0]
        if not isinstance(pull, dict):
            raise PublishError("The repository API answered with an unexpected shape")
        if pull.get("state") != "open":
            raise PublishError("The pull request for this branch is no longer open")
        return cast(_Json, pull)

    def _ensure_pull_request(
        self, request: PublishRequest, pull: _Json | None
    ) -> tuple[int, str, bool]:
        if pull is not None:
            number = self._int_of(pull)
            if pull.get("title") != request.pr_title or pull.get("body") != request.pr_body:
                self._call(
                    "PATCH",
                    self._repo_path(f"pulls/{number}"),
                    expected={HTTP_OK},
                    json_body={"title": request.pr_title, "body": request.pr_body},
                )
            return number, self._url_of(pull), False
        created = self._json(
            self._call(
                "POST",
                self._repo_path("pulls"),
                expected={HTTP_CREATED},
                json_body={
                    "title": request.pr_title,
                    "head": request.branch,
                    "base": self._base,
                    "body": request.pr_body,
                },
            )
        )
        return self._int_of(created), self._url_of(created), True

    @staticmethod
    def _int_of(pull: _Json) -> int:
        number = pull.get("number")
        if not isinstance(number, int) or isinstance(number, bool):
            raise PublishError("The repository API answered without a pull request number")
        return number

    @staticmethod
    def _url_of(pull: _Json) -> str:
        url = pull.get("html_url")
        if not isinstance(url, str):
            raise PublishError("The repository API answered without a pull request link")
        return url
