"""Catalogue port: batch attestation, revision-vector check and capture binding."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from app.recsys.contract_fixtures import CAPTURED_AT, COMPLETE_MANIFEST, PPD_SCOPE, digest
from app.recsys.contracts.resolution import SourceBatch
from app.recsys.contracts.sources import (
    CompletenessState,
    FreshnessState,
    SourceAuthority,
    SourceCollection,
)
from app.recsys.publication.errors import CatalogueSnapshotRefused
from app.recsys.refresh.integration.catalogue_version import (
    CapturedCatalogueVersion,
    attest_batch,
    verify_revision_vector,
)
from app.recsys.refresh.integration.staging import ArtifactStaging, StagedArtifactMissing
from app.recsys.registry.source_records.capture import make_manifest

from . import protocol_fixtures as fixtures

BUILD_DIGEST = digest("build-of-captured-workbook")
CAPTURED = {SourceAuthority.agent_hub_export: COMPLETE_MANIFEST}


def _build_batch(collection: SourceCollection = SourceCollection.agent_records) -> SourceBatch:
    """Return a batch as the registry adapters emit it: diagnostic manifest, no rows."""
    return SourceBatch(
        scope=PPD_SCOPE,
        authority=SourceAuthority.agent_hub_export,
        manifest=make_manifest(
            SourceAuthority.agent_hub_export,
            PPD_SCOPE,
            BUILD_DIGEST,
            CAPTURED_AT,
            [(collection, 12)],
        ),
        failure=None,
        expected_record_occurrence_ids=[],
        expected_reference_occurrence_ids=[],
        records=[],
    )


class AttestBatchTests(unittest.TestCase):
    def _refusal(self, call) -> str:
        with self.assertRaises(CatalogueSnapshotRefused) as raised:
            call()
        return raised.exception.reason

    def test_batch_takes_capture_properties_and_keeps_its_build_identity(self) -> None:
        batch = _build_batch()
        self.assertEqual(batch.manifest.completeness, CompletenessState.unknown)

        attested = attest_batch(batch, CAPTURED)

        manifest = attested.manifest
        self.assertEqual(manifest.content_hash, BUILD_DIGEST)
        self.assertEqual(manifest.row_counts, batch.manifest.row_counts)
        self.assertEqual(manifest.completeness, CompletenessState.complete_snapshot)
        self.assertEqual(manifest.freshness, FreshnessState.current)
        self.assertEqual(manifest.deletion_semantics, COMPLETE_MANIFEST.deletion_semantics)
        self.assertEqual(manifest.captured_at, COMPLETE_MANIFEST.captured_at)
        self.assertEqual(manifest.resolved_revision, COMPLETE_MANIFEST.resolved_revision)
        self.assertEqual(
            list(manifest.collection_revisions),
            [COMPLETE_MANIFEST.revision_for(SourceCollection.agent_records)],
        )
        self.assertEqual(attested.records, batch.records)

    def test_collection_the_capture_does_not_carry_is_refused(self) -> None:
        batch = _build_batch(SourceCollection.knowledge_records)

        self.assertEqual(
            self._refusal(lambda: attest_batch(batch, CAPTURED)), "collection_not_captured"
        )

    def test_authority_without_a_capture_is_refused(self) -> None:
        self.assertEqual(
            self._refusal(lambda: attest_batch(_build_batch(), {})), "required_source_missing"
        )

    def test_stored_manifest_must_match_the_capture_revisions(self) -> None:
        attested = attest_batch(_build_batch(), CAPTURED)
        result = SimpleNamespace(reused_sources=[], source_batches=[attested])
        verify_revision_vector(result, CAPTURED)

        moved = COMPLETE_MANIFEST.model_copy(
            update={
                "collection_revisions": [
                    revision.model_copy(update={"revision": revision.revision + 1})
                    for revision in COMPLETE_MANIFEST.collection_revisions
                ]
            }
        )
        self.assertEqual(
            self._refusal(
                lambda: verify_revision_vector(result, {SourceAuthority.agent_hub_export: moved})
            ),
            "capture_revision_mismatch",
        )

    def test_reused_source_is_refused(self) -> None:
        result = SimpleNamespace(reused_sources=["agent_hub_export"], source_batches=[])

        self.assertEqual(
            self._refusal(lambda: verify_revision_vector(result, CAPTURED)),
            "source_reuse_not_captured",
        )


class _NoWrites:
    async def write_candidate(self, result):
        raise AssertionError("a refused candidate must not be written")


class CapturedCatalogueVersionTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.staging = ArtifactStaging(Path(self._tmp.name) / "staging")
        self.port = CapturedCatalogueVersion(None, self.staging, repository=_NoWrites())

    def tearDown(self) -> None:
        self._tmp.cleanup()

    async def _refusal(self, captures, snapshot=fixtures.SNAPSHOT) -> str:
        with self.assertRaises(CatalogueSnapshotRefused) as raised:
            await self.port.resolve(captures, snapshot)
        return raised.exception.reason

    async def test_capture_set_must_match_the_configured_sources(self) -> None:
        snapshot = fixtures.SNAPSHOT.model_copy(update={"adapter_ids": ("another-source",)})

        self.assertEqual(await self._refusal((fixtures.CAPTURE,), snapshot), "source_set_mismatch")

    async def test_capture_without_a_staged_artifact_is_refused(self) -> None:
        self.assertEqual(await self._refusal((fixtures.CAPTURE,)), "artifact_unavailable")

    async def test_staged_artifact_with_another_digest_is_refused_and_released(self) -> None:
        reference = self.staging.register(
            job_id=fixtures.LEASE.job_id,
            attempt_id=fixtures.LEASE.attempt_id,
            source_id=fixtures.CAPTURE.adapter_id,
            acquired=SimpleNamespace(manifest=fixtures.CAPTURE.manifest),
            digest=digest("a-different-artifact"),
        )
        capture = fixtures.CAPTURE.model_copy(update={"artifact_reference": reference})

        self.assertEqual(await self._refusal((capture,)), "artifact_digest_mismatch")
        with self.assertRaises(StagedArtifactMissing):
            self.staging.get(reference, digest("a-different-artifact"))

    async def test_staged_artifact_that_is_neither_workbook_nor_tree_is_refused(self) -> None:
        reference = self.staging.register(
            job_id=fixtures.LEASE.job_id,
            attempt_id=fixtures.LEASE.attempt_id,
            source_id=fixtures.CAPTURE.adapter_id,
            acquired=SimpleNamespace(manifest=fixtures.CAPTURE.manifest),
            digest=fixtures.CAPTURE.artifact_digest,
        )
        capture = fixtures.CAPTURE.model_copy(update={"artifact_reference": reference})

        self.assertEqual(await self._refusal((capture,)), "artifact_unavailable")
