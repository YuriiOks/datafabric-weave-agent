"""Register parser: US-06 (header row with confidence, one requirement per data row)."""

from __future__ import annotations

import io
from collections.abc import Sequence
from datetime import date, datetime

import pytest
from openpyxl import Workbook

from ingest.ingest_support import damaged_copies
from kp.config import Thresholds
from kp.domain import ItemKey, SourceKind
from kp.ingest import RegisterParseError, parse_register
from kp.ingest.register_header import detect_header
from kp.testing.dataset import SyntheticDataset

KEY = ItemKey(source=SourceKind.DOCUMENT_LIBRARY, item_id="register-1", version="3")


def _register(dataset: SyntheticDataset) -> bytes:
    return dataset.path(dataset.truth.requirements_register.path).read_bytes()


def _workbook(sheets: dict[str, Sequence[Sequence[object]]]) -> bytes:
    workbook = Workbook()
    first = True
    for name, rows in sheets.items():
        sheet = workbook.active if first else workbook.create_sheet()
        assert sheet is not None
        sheet.title = name
        for row in rows:
            sheet.append(list(row))
        first = False
    out = io.BytesIO()
    workbook.save(out)
    return out.getvalue()


HEADER = ["Req ID", "Title", "Description", "Domain"]


def _rows(count: int) -> list[list[object]]:
    return [
        [f"REQ-{i:03d}", f"Handle case {i} of the inbound flow", "Long enough text.", "payments"]
        for i in range(1, count + 1)
    ]


def test_us06_clear_header_row_gives_one_requirement_per_row(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    truth = dataset.truth.requirements_register
    parsed = parse_register(_register(dataset), key=KEY, thresholds=thresholds)
    main = next(sheet for sheet in parsed.sheets if sheet.sheet == truth.main_sheet)
    assert main.header_row == truth.header_row
    assert main.header_confidence >= thresholds.register_header_min_confidence
    assert not main.refused
    assert len(parsed.requirements) == main.data_row_count == truth.data_row_count


def test_us06_each_requirement_carries_sheet_name_and_row_number(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    truth = dataset.truth.requirements_register
    parsed = parse_register(_register(dataset), key=KEY, thresholds=thresholds)
    first, last = parsed.requirements[0], parsed.requirements[-1]
    assert (first.sheet, first.row_number) == (truth.main_sheet, truth.header_row + 1)
    assert last.row_number == truth.header_row + truth.data_row_count
    assert [r.row_number for r in parsed.requirements] == list(
        range(truth.header_row + 1, truth.header_row + 1 + truth.data_row_count)
    )
    assert first.requirement_id == f"register-1:{truth.main_sheet}:{first.row_number}"
    assert (first.source, first.item_id, first.version) == (KEY.source, "register-1", "3")
    assert tuple(first.fields) == truth.header
    assert first.fields["Req ID"] == "REQ-001"
    assert first.header_confidence == parsed.sheets[0].header_confidence


def test_us06_domain_comes_from_the_domain_column(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    parsed = parse_register(_register(dataset), key=KEY, thresholds=thresholds)
    assert {r.domain for r in parsed.requirements} == {"payments", "cards"}


def test_us06_sheet_without_a_header_is_refused_with_candidate_rows(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    truth = dataset.truth.requirements_register
    parsed = parse_register(_register(dataset), key=KEY, thresholds=thresholds)
    notes = next(sheet for sheet in parsed.sheets if sheet.sheet == truth.headerless_sheet)
    assert notes.refused
    assert notes.header_confidence < thresholds.register_header_min_confidence
    assert notes.header_row is None
    assert notes.data_row_count == 0
    assert 1 <= len(notes.candidate_rows) <= 3
    assert all(1 <= row <= 4 for row in notes.candidate_rows)
    assert truth.headerless_sheet not in {r.sheet for r in parsed.requirements}
    assert parsed.refused_sheets == (notes,)


def test_us06_requirement_count_equals_data_row_count_with_blank_rows() -> None:
    rows: list[Sequence[object]] = [HEADER, *_rows(3), [], *_rows(2), [None, "", None, None]]
    parsed = parse_register(_workbook({"Reqs": rows}), key=KEY, thresholds=Thresholds())
    sheet = parsed.sheets[0]
    assert sheet.data_row_count == len(parsed.requirements) == 5
    assert [r.row_number for r in parsed.requirements] == [2, 3, 4, 6, 7]


def test_us06_header_below_title_rows_is_found() -> None:
    rows: list[Sequence[object]] = [
        ["Quarterly requirements register"],
        ["Owner: business analysis"],
        [],
        HEADER,
        *_rows(4),
    ]
    parsed = parse_register(_workbook({"Reqs": rows}), key=KEY, thresholds=Thresholds())
    assert parsed.sheets[0].header_row == 4
    assert len(parsed.requirements) == 4


def test_us06_two_equally_likely_header_rows_are_refused() -> None:
    rows: list[Sequence[object]] = [HEADER, HEADER, *_rows(5)]
    parsed = parse_register(_workbook({"Dup": rows}), key=KEY, thresholds=Thresholds())
    sheet = parsed.sheets[0]
    assert sheet.refused
    assert sheet.header_confidence < 0.7
    assert sheet.candidate_rows[:2] == (1, 2)
    assert parsed.requirements == ()


def test_us06_confidence_threshold_comes_from_settings(dataset: SyntheticDataset) -> None:
    lenient = parse_register(
        _register(dataset),
        key=KEY,
        thresholds=Thresholds(register_header_min_confidence=0.0),
    )
    assert lenient.refused_sheets == ()
    assert len(lenient.requirements) > dataset.truth.requirements_register.data_row_count


def test_us06_empty_sheet_is_reported_not_refused() -> None:
    parsed = parse_register(
        _workbook({"Empty": [], "Reqs": [HEADER, *_rows(2)]}), key=KEY, thresholds=Thresholds()
    )
    empty = next(sheet for sheet in parsed.sheets if sheet.sheet == "Empty")
    assert not empty.refused
    assert empty.header_row is None
    assert len(parsed.requirements) == 2


def test_us06_duplicate_and_blank_header_names_are_made_unique() -> None:
    data = [
        [f"REQ-{i:03d}", f"Handle case {i} of the inbound flow", "Long enough text."]
        for i in range(1, 5)
    ]
    rows: list[Sequence[object]] = [
        ["Req ID", "Title", "Title", "Domain", "Status", ""],
        *[[*row, "payments", "Open", ""] for row in data],
        [*data[0], "payments", "Open", "Overflow cell"],
    ]
    parsed = parse_register(_workbook({"Reqs": rows}), key=KEY, thresholds=Thresholds())
    assert not parsed.sheets[0].refused
    expected = ("Req ID", "Title", "Title_2", "Domain", "Status", "column_6")
    assert all(tuple(r.fields) == expected for r in parsed.requirements)
    assert parsed.requirements[-1].fields["column_6"] == "Overflow cell"


def test_us06_default_domain_fills_rows_without_a_domain() -> None:
    rows: list[Sequence[object]] = [
        ["Req ID", "Title", "Description"],
        *[[f"R{i}", "Check the account", "Details."] for i in range(3)],
    ]
    parsed = parse_register(
        _workbook({"Reqs": rows}), key=KEY, thresholds=Thresholds(), default_domain="payments"
    )
    assert {r.domain for r in parsed.requirements} == {"payments"}


def test_us06_cells_become_text() -> None:
    rows: list[Sequence[object]] = [
        ["Req ID", "Title", "Priority", "Date", "Done"],
        ["R1", "Check the account", 3.0, date(2026, 10, 1), True],
        ["R2", "Check the amount", 2.5, datetime(2026, 10, 2, 9, 0), False],
    ]
    parsed = parse_register(
        _workbook({"Reqs": rows}),
        key=KEY,
        thresholds=Thresholds(register_header_min_confidence=0.0),
    )
    first, second = (r.fields for r in parsed.requirements)
    assert (first["Priority"], first["Date"], first["Done"]) == ("3", "2026-10-01", "true")
    assert (second["Priority"], second["Date"], second["Done"]) == (
        "2.5",
        "2026-10-02T09:00:00",
        "false",
    )


def test_us06_unreadable_workbook_is_a_typed_error(thresholds: Thresholds) -> None:
    with pytest.raises(RegisterParseError):
        parse_register(b"not a workbook", key=KEY, thresholds=thresholds)


def test_us06_damaged_workbooks_give_the_typed_error_or_a_parse_and_nothing_else(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    failures = 0
    for damaged in damaged_copies(_register(dataset)):
        try:
            parse_register(damaged, key=KEY, thresholds=thresholds)
        except RegisterParseError:
            failures += 1
    assert failures > 0


def test_us06_header_detection_prefers_the_label_row() -> None:
    rows = [
        [],
        ["Req ID", "Title", "Domain"],
        ["R1", "Check the account balance first", "payments"],
    ]
    guess = detect_header(rows)
    assert guess.row == 2
    assert guess.candidates[0] == 2
    assert detect_header([]).row is None
