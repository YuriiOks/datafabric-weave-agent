"""Deterministic synthetic data for the whole build.

``generate(target, seed)`` writes, under ``target``:

* ``regulatory_repo/<edition>/`` the fictional Payments Rulebook, editions 2025.2 and 2026.1
  (2026.1 effective 2026-11-16), each as PDF and Markdown with ``edition.yaml``;
* ``register/`` a requirements register whose header row is not the first row, plus a sheet
  with no recognisable header;
* ``jira/`` two exports of one project (a status-only change and a criteria change between);
* ``confluence/`` pages: approved, unlabelled, and one with a draft newer than the approved
  version;
* ``library/`` documents with metadata sidecars (approved and draft, a missing detail, an
  unknown document type);
* ``code_repo/`` code, tests and a schema referencing clauses;
* ``spec_repo/`` the spec a person merged for one story, implemented by that code;
* ``templates/`` the governed spec template;
* ``identity/`` the identity-to-domain mapping with test users;
* ``ground_truth.json`` the facts tests assert against.

The same seed gives byte-identical ``.md``, ``.json`` and ``.yaml`` files, a byte-identical
``.xlsx`` (zip timestamps are fixed) and PDFs whose creation date is fixed.

Requires the ``dev`` extra (fpdf2).
"""

from __future__ import annotations

import json
from pathlib import Path

from kp.testing.dataset import GROUND_TRUTH_FILE, GroundTruth, SyntheticDataset
from kp.testing.rulebook import EDITIONS, write_edition
from kp.testing.sources import (
    write_code_repo,
    write_confluence,
    write_identity_mapping,
    write_library,
    write_register,
    write_spec_repo,
    write_stories,
    write_template,
)

DEFAULT_SEED = 20261027


def generate(target: Path, seed: int = DEFAULT_SEED) -> SyntheticDataset:
    """Write the complete synthetic dataset into ``target``.

    Existing files with the same names are overwritten; other files are left alone.

    :param target: Directory to write into; created if needed
    :param seed: Seed for the few randomised parts (the long clause, register priorities)
    :return: The dataset with its ground truth
    """
    target.mkdir(parents=True, exist_ok=True)
    truth = GroundTruth(
        seed=seed,
        editions=tuple(write_edition(edition, target, seed) for edition in EDITIONS),
        requirements_register=write_register(target, seed),
        stories=write_stories(target),
        confluence=write_confluence(target),
    )
    write_library(target)
    write_code_repo(target)
    write_spec_repo(target)
    write_template(target)
    write_identity_mapping(target)
    (target / GROUND_TRUTH_FILE).write_text(
        json.dumps(truth.model_dump(mode="json"), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return SyntheticDataset(root=target, truth=truth)
