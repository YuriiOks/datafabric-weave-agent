# Screenshots in a pull request

Read when the change alters what people see on screen. The owner captures and uploads; this
skill only plans the views and checks the text. It never uploads; images the owner adds in
the browser must survive every body refresh.

## Rules

- Proof goes in the description, in a table under `## Screenshots`, the last section. Never
  in a comment. Never terminal output. Unit tests are not proof of a visible change.
- Take the shots after a click-through of the running app on the pushed head, not before.
  Say in the intro line what data the app was showing.
- Capture page content only: no address bar, other tabs, chat, mail or personal data.
- A shot that shows a host name, address, staff id or real customer data is retaken.
- File names: `<ticket>-<nn>-<view>`, lower case, hyphens, two-digit number from 01, for
  example `<ticket>-01-detail-card`. `<ticket>` is the owner's key in lower case.
- Do not number captions in the table; the editor continues lists. Use the name in the
  image alt text and a plain product-language caption.

## Which views to list

Hand the owner a short list, in this order, only for what the diff really changes:
1. One view per changed kind of screen element (a card, a form, a badge, a filter).
2. One view of a result page or flow that uses the change end to end.
3. One list or count view when the change affects what appears in a list.
4. One view of the empty, error or negative state the How to verify section names.

Derive the list from the diff (frontend paths and the routes they serve), and say which
screen to open for each. Five to six views is the ceiling.

## Table shape

    ## Screenshots
    One line: what data the app showed when these were taken.

    | What it shows | Screenshot |
    |---|---|
    | Detail card with the new field | <img width="640" alt="<ticket>-01-detail-card" src="..."> |
    | List after filtering | <img width="640" alt="<ticket>-02-filtered-list" src="..."> |

The first column is product language. The `src` values come from the upload the owner makes.

## Check before handing over

- Change is visible but the draft has no Screenshots section: report it.
- A row has no image, or an alt name that breaks the pattern: report it.
- The shots were taken before the last frontend commit: say they are stale.
