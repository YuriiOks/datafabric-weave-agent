"""Build passages from the stored clauses, stories and register rows.

Each function rebuilds the passages of every item version it finds, replacing earlier ones,
so running it twice leaves the same rows. Pages, code and schema fields come from files, not
tables: build them with :mod:`kp.search.passages` and store them with
:meth:`kp.search.store.PassageStore.replace_item`.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Collection

from sqlalchemy import Connection, select

from kp.domain import Clause, ClauseRef, Passage, Requirement, SourceKind, Story, StoryLink
from kp.search.passages import clause_passages, requirement_passage, story_passages
from kp.search.store import PassageStore
from kp.store.schema import clause as clause_table
from kp.store.schema import requirement as requirement_table
from kp.store.schema import story as story_table


def index_clauses(connection: Connection) -> int:
    """Build clause passages for every searchable edition.

    :param connection: An open connection; the caller commits
    :return: The number of passages written
    """
    store = PassageStore(connection)
    domains = store.edition_domains()
    written = 0
    for edition in store.searchable_editions():
        rows = connection.execute(
            select(clause_table)
            .where(clause_table.c.edition == edition.label)
            .order_by(clause_table.c.number)
        ).mappings()
        passages: list[Passage] = []
        for row in rows:
            clause = _clause(dict(row))
            passages += clause_passages(clause, edition, domains.get(edition.label))
        written += store.replace_item(edition.source, edition.item_id, edition.version, passages)
    return written


def _clause(row: dict[str, object]) -> Clause:
    ref = ClauseRef(str(row.pop("edition")), str(row.pop("number")))
    parent = row.pop("parent_number")
    return Clause.model_validate(
        {
            **row,
            "ref": ref,
            "parent_ref": ClauseRef(ref.edition, str(parent)) if parent is not None else None,
        }
    )


def index_stories(connection: Connection, story_keys: Collection[str] | None = None) -> int:
    """Build story and acceptance-criteria passages for stored story versions.

    A story is searchable once an approved ``source_item`` row exists for its key and version.

    :param connection: An open connection; the caller commits
    :param story_keys: Only index these stories; every stored story when omitted
    :return: The number of passages written
    """
    store = PassageStore(connection)
    written = 0
    statement = select(story_table)
    if story_keys is not None:
        statement = statement.where(story_table.c.story_key.in_(story_keys))
    for row in connection.execute(statement).mappings():
        values = dict(row)
        values.pop("fingerprint")
        values["links"] = tuple(StoryLink.model_validate(link) for link in values["links"])
        story = Story.model_validate(values)
        written += store.replace_item(
            SourceKind.JIRA, story.story_key, story.version, story_passages(story)
        )
    return written


def index_requirements(connection: Connection) -> int:
    """Build one passage per stored register row.

    :param connection: An open connection; the caller commits
    :return: The number of passages written
    """
    store = PassageStore(connection)
    grouped: dict[tuple[SourceKind, str, str], list[Passage]] = defaultdict(list)
    for row in connection.execute(select(requirement_table)).mappings():
        requirement = Requirement.model_validate(dict(row))
        key = (requirement.source, requirement.item_id, requirement.version)
        grouped[key].append(requirement_passage(requirement))
    return sum(
        store.replace_item(source, item_id, version, passages)
        for (source, item_id, version), passages in grouped.items()
    )
