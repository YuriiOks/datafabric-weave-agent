"""Seam helper: which access domain an item belongs to.

Clauses belong to the domain of their rulebook document, register rows and stories carry their
own, a spec takes the domain of its story. Code, tests, schema fields and templates carry none
of their own: they take the domain of the item they were reached from, so a test linked to a
payments spec is a payments item. An item that cannot be placed has no domain, and access
control treats that as visible to nobody.
"""

from __future__ import annotations

from sqlalchemy import Connection, select

from kp.domain import ClauseRef, ItemRef, ItemType, Relation
from kp.errors import InvalidClauseRefError
from kp.store import schema

_INHERITING = frozenset({ItemType.CODE, ItemType.TEST, ItemType.SCHEMA_FIELD, ItemType.TEMPLATE})


class ItemDomains:
    """Looks up the access domain of linked items.

    The tables are read once, when the object is built, so build one per call.

    :param connection: A connection inside the caller's unit of work
    """

    def __init__(self, connection: Connection) -> None:
        self._editions = _edition_domains(connection)
        self._requirements = _requirement_domains(connection)
        self._stories = _story_domains(connection)
        self._specs = _spec_domains(connection, self._stories)

    def of(self, item: ItemRef, *, reached_from: str | None = None) -> str | None:
        """Return the domain of an item.

        :param item: The item
        :param reached_from: The domain of the item it was reached from; used by types that
            carry no domain of their own
        :return: The domain, or ``None`` when it cannot be placed
        """
        kind = item.item_type
        if kind in _INHERITING:
            return reached_from
        if kind is ItemType.CLAUSE:
            try:
                return self._editions.get(ClauseRef.parse(item.key).edition)
            except InvalidClauseRefError:
                return None
        if kind is ItemType.REQUIREMENT:
            return self._requirements.get(item.key)
        if kind is ItemType.STORY:
            return self._stories.get(item.key)
        return self._specs.get(item.key)

    def of_reference(self, reference: str) -> str | None:
        """Return the domain of a clause reference or a register row id.

        :param reference: ``<edition>:<number>`` or a requirement id
        :return: The domain, or ``None`` when it cannot be placed
        """
        try:
            ClauseRef.parse(reference)
        except InvalidClauseRefError:
            return self.of(ItemRef(item_type=ItemType.REQUIREMENT, key=reference))
        return self.of(ItemRef(item_type=ItemType.CLAUSE, key=reference))


def _edition_domains(connection: Connection) -> dict[str, str | None]:
    rows = connection.execute(
        select(schema.edition.c.label, schema.source_item.c.domain).select_from(
            schema.edition.join(
                schema.source_item,
                (schema.source_item.c.source == schema.edition.c.source)
                & (schema.source_item.c.item_id == schema.edition.c.item_id)
                & (schema.source_item.c.version == schema.edition.c.version),
            )
        )
    )
    return {label: domain for label, domain in rows}


def _requirement_domains(connection: Connection) -> dict[str, str | None]:
    rows = connection.execute(
        select(schema.requirement.c.requirement_id, schema.requirement.c.domain)
    )
    return {requirement_id: domain for requirement_id, domain in rows}


def _story_domains(connection: Connection) -> dict[str, str | None]:
    rows = connection.execute(select(schema.story.c.story_key, schema.story.c.domain))
    return {story_key: domain for story_key, domain in rows}


def _spec_domains(connection: Connection, stories: dict[str, str | None]) -> dict[str, str | None]:
    """A spec takes its story's domain: from its own row, or from the link a merged spec states.

    A spec only a person wrote has no row; the link the load-back opens from its story is all
    that ties it to the story.
    """
    domains: dict[str, str | None] = {}
    rows = connection.execute(select(schema.spec.c.spec_id, schema.spec.c.story_key))
    domains.update({spec_id: stories.get(story_key) for spec_id, story_key in rows})
    stated = connection.execute(
        select(schema.link.c.source_key, schema.link.c.target_key).where(
            schema.link.c.relation == Relation.SPECIFIED_BY.value
        )
    )
    for story_key, spec_id in stated:
        domains.setdefault(spec_id, stories.get(story_key))
    return domains
