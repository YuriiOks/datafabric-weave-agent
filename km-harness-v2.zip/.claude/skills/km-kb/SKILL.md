---
name: km-kb
description: Look up facts in the kb before reading code, and write new findings back in the right shape. Use when a question may already be answered in kb/, and whenever a run has produced facts that must be saved.
argument-hint: <question>
---

# km-kb

Rules for labels, size, secrets and the per-run records are in the canon. This adds the procedure.

Look up ($ARGUMENTS is the question):
1. Read kb/INDEX.md. If it is missing or stale, list kb/index.d/ and the kb folders instead.
2. If the answer needs more than 3 kb files, or the kb holds more than 30 files, pass the
   question to km-scout and use its answer. Otherwise open only the matching files.
3. Answer first, then sources as kb path:line, each with the label it carries there. Never
   upgrade a label. Report conflicts between files.
4. If the kb cannot answer, name the gap. Read code or wiki pages only when the owner's task
   needs it (km-reader when it is over 5 files or 60 KB), then write the finding back.
5. If kb/private is missing, say when an answer would have come from it, and carry on.

Write back (run = km-kb-<topic>-<date>):
- One topic per file. Folder by source: base or capture for a clone, legacy, wiki, stories,
  risks, packs for syntheses. File name: lowercase words with hyphens.
- If the file exists, do not rewrite it. To correct a line, change it in place and keep the old
  claim as `Historical (<date>): ...` with the reason.
- Observed needs path:line or a page number; Historical carries its date. Code and a document
  disagree: code as Observed, document as Reported.
- Record the run in kb/index.d and kb/log.d as the canon says. Never edit kb/INDEX.md.
- Then run `bash /home/user/km/.claude/bin/kb-lint.sh`. On FAIL fix the file it names. If the
  script is missing, say so and go on.
- A needed input is missing (topic, source path): log it, tell the owner in two lines, stop.

End with a summary of at most 10 lines: the answer or the files written, the lint result.
