"""Fixtures for the MCP transport tests: a small read server and a write server over fakes."""

from __future__ import annotations

from datetime import UTC, date, datetime
from pathlib import Path

import pytest

from kp.clock import FixedClock
from kp.domain import Clause, ClauseRef, Edition, PassageType, Template
from kp.mcp import McpServer, build_read_server, build_write_server
from kp.tools import CoverageSnapshot, IdentityMapping, ReadPorts, RuleClause, SearchHit
from kp.tools.testing import (
    FakeCoverage,
    FakeLinks,
    FakeRules,
    FakeSearch,
    FakeTemplates,
    FakeWritePort,
    InMemoryAudit,
)

__all__ = ["audit", "mapping", "ports", "read_server", "write_server"]

_NOW = datetime(2026, 11, 1, 9, 30, tzinfo=UTC)
CLAUSE_TEXT = "An inbound credit transfer may be denominated in euro or in pounds sterling."


@pytest.fixture
def mapping(committed_fixtures_dir: Path) -> IdentityMapping:
    """The committed test users and their domains."""
    return IdentityMapping.from_file(committed_fixtures_dir / "identity" / "identity-mapping.yaml")


@pytest.fixture
def audit() -> InMemoryAudit:
    """A list-backed audit sink."""
    return InMemoryAudit()


@pytest.fixture
def ports() -> ReadPorts:
    """Five small fakes: two search hits (payments, cards), one edition with one clause."""
    ref = ClauseRef("2026.1", "4.2.1")
    clause = Clause(
        ref=ref,
        title="Currency",
        page=4,
        char_start=10,
        char_end=10 + len(CLAUSE_TEXT),
        text=CLAUSE_TEXT,
        structure_score=1.0,
        parent_ref=ref.parent(),
    )
    hits = [
        SearchHit(
            passage_id="p1",
            passage_type=PassageType.CLAUSE,
            reference=ref.format(),
            text=CLAUSE_TEXT,
            page=4,
            char_start=10,
            char_end=10 + len(CLAUSE_TEXT),
            version="2026.1",
            domain="payments",
        ),
        SearchHit(
            passage_id="p2",
            passage_type=PassageType.PAGE,
            reference="cards-guide:1",
            text="Cards use the same credit transfer currency rules.",
            version="1",
            domain="cards",
        ),
    ]
    edition = Edition(
        label="2026.1",
        effective_date=date(2026, 11, 16),
        item_id="payments-rulebook",
        version="2026.1",
    )
    template = Template(
        template_id="functional-spec",
        version="1.0.0",
        spec_type="functional",
        body="# Template",
        content_sha256="c" * 64,
    )
    return ReadPorts(
        search=FakeSearch(hits),
        links=FakeLinks([], {}),
        rules=FakeRules(
            [edition], {("2026.1", "4.2.1"): RuleClause(clause=clause, domain="payments")}
        ),
        templates=FakeTemplates([template]),
        coverage=FakeCoverage(CoverageSnapshot()),
    )


@pytest.fixture
def read_server(ports: ReadPorts, mapping: IdentityMapping, audit: InMemoryAudit) -> McpServer:
    """The read server over the fakes."""
    return build_read_server(ports, mapping, audit, clock=FixedClock(_NOW))


@pytest.fixture
def write_server(mapping: IdentityMapping, audit: InMemoryAudit) -> McpServer:
    """The write server over the fake write port."""
    return build_write_server(FakeWritePort(), mapping, audit, clock=FixedClock(_NOW))
