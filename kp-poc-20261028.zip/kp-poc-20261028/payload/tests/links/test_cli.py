"""The ``impact`` and ``coverage`` commands, run against a database file."""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path

import pytest

from kp.domain import Relation
from kp.links import LinkService
from kp.links.cli import add_parser
from kp.store import Database, create_engine_for_url
from kp.testing.dataset import SyntheticDataset
from links.builders import clause, code, spec, state_link, story
from links.seed import seed_rulebook


@pytest.fixture
def database_file(
    tmp_path: Path, dataset: SyntheticDataset, monkeypatch: pytest.MonkeyPatch
) -> Path:
    """A SQLite file with the rulebook and a small link web, selected through the environment."""
    path = tmp_path / "kp.db"
    url = f"sqlite+pysqlite:///{path}"
    monkeypatch.setenv("KP_DATABASE_URL", url)
    monkeypatch.setenv("KP_MODE", "local")
    database = Database(create_engine_for_url(url))
    database.create_all()
    with database.transaction() as connection:
        seed_rulebook(connection, dataset)
        service = LinkService(connection)
        state_link(service, spec("S1"), Relation.DERIVED_FROM, clause("4.2.1"))
        state_link(service, story("PAY-104"), Relation.SPECIFIED_BY, spec("S1"))
        state_link(service, spec("S1"), Relation.IMPLEMENTED_BY, code("src/a.py::f"))
    database.dispose()
    return path


def _run(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="kp")
    add_parser(parser.add_subparsers(dest="command", required=True))
    args = parser.parse_args(argv)
    return int(args.handler(args))


@pytest.mark.usefixtures("database_file")
def test_us13_impact_command_lists_affected_items_and_their_kind(
    capsys: pytest.CaptureFixture[str],
) -> None:
    status = _run(["impact", "2026.1:4.2.1"])

    output = capsys.readouterr().out
    assert status == 0
    assert "Impact of clause 2026.1:4.2.1 (up to 3 steps)" in output
    assert "spec" in output
    assert "S1" in output
    assert "PAY-104" in output
    assert "[stated]" in output
    assert "3 stated, 0 guessed" in output


@pytest.mark.usefixtures("database_file")
def test_us13_impact_command_accepts_the_spoken_form_and_writes_json(
    capsys: pytest.CaptureFixture[str],
) -> None:
    status = _run(["impact", "2026.1 clause 4.2.1", "--steps", "1", "--json"])

    document = json.loads(capsys.readouterr().out)
    assert status == 0
    assert document["clause"] == "2026.1:4.2.1"
    assert [item["ref"]["key"] for item in document["items"]] == ["S1"]


@pytest.mark.usefixtures("database_file")
def test_us13_impact_command_says_so_when_the_clause_has_no_links(
    capsys: pytest.CaptureFixture[str],
) -> None:
    status = _run(["impact", "2026.1:6.2.1"])

    assert status == 0
    assert "No links are recorded for clause 2026.1:6.2.1" in capsys.readouterr().out


@pytest.mark.usefixtures("database_file")
def test_us13_impact_command_reports_unknown_clauses_on_stderr(
    capsys: pytest.CaptureFixture[str],
) -> None:
    status = _run(["impact", "2026.1:9.9.9"])

    captured = capsys.readouterr()
    assert status == 2
    assert captured.out == ""
    assert "not loaded and has no links" in captured.err


def test_us13_impact_steps_must_be_positive() -> None:
    with pytest.raises(SystemExit):
        _run(["impact", "2026.1:4.2.1", "--steps", "0"])


@pytest.mark.usefixtures("database_file")
def test_us12_coverage_command_lists_untested_rules_with_the_link_split(
    capsys: pytest.CaptureFixture[str],
) -> None:
    status = _run(["coverage", "--edition", "2026.1"])

    output = capsys.readouterr().out
    assert status == 0
    assert "Coverage of edition 2026.1:" in output
    assert "2026.1:4.2.1  stories=1  links=3 stated/0 guessed" in output
    assert "The list rests on 3 links (3 stated, 0 guessed)." in output


@pytest.mark.usefixtures("database_file")
def test_us12_coverage_command_writes_json(
    capsys: pytest.CaptureFixture[str], dataset: SyntheticDataset
) -> None:
    status = _run(["coverage", "--edition", "2026.1", "--json", "--all-clauses"])

    document = json.loads(capsys.readouterr().out)
    assert status == 0
    assert document["edition"] == "2026.1"
    assert len(document["without_tests"]) == len(dataset.truth.edition("2026.1").clauses)
    assert document["with_tests"] == []


@pytest.mark.usefixtures("database_file")
def test_us12_coverage_command_reports_an_edition_that_is_not_loaded(
    capsys: pytest.CaptureFixture[str],
) -> None:
    status = _run(["coverage", "--edition", "2099.9"])

    captured = capsys.readouterr()
    assert status == 2
    assert "Edition 2099.9 is not loaded" in captured.err
