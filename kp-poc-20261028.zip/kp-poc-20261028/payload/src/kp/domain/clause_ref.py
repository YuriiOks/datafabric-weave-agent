"""Stable reference to one clause of one edition, e.g. edition ``2026.1`` clause ``4.2.1``."""

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import total_ordering
from typing import Self

from kp.errors import InvalidClauseRefError

_EDITION = r"[A-Za-z0-9][A-Za-z0-9._-]*"
# No leading zeros, so equal numbers always have equal text and ordering agrees with equality.
_NUMBER = r"(?:0|[1-9]\d*)(?:\.(?:0|[1-9]\d*))*"
_EDITION_RE = re.compile(rf"^{_EDITION}$")
_NUMBER_RE = re.compile(rf"^{_NUMBER}$")
# Accepts the canonical "2026.1:4.2.1" and the spoken "2026.1 clause 4.2.1".
_REF_RE = re.compile(
    rf"^(?P<edition>{_EDITION})(?::|\s+clause\s+)(?P<number>{_NUMBER})$", re.IGNORECASE
)
_EDITION_TOKEN_RE = re.compile(r"\d+|\D+")


def parse_clause_number(number: str) -> tuple[int, ...]:
    """Split a dotted clause number into integers.

    :param number: A number such as ``4.2.1``
    :return: ``(4, 2, 1)``
    :raises InvalidClauseRefError: If a part is not a plain decimal integer
    """
    if not _NUMBER_RE.match(number):
        raise InvalidClauseRefError(f"Invalid clause number: {number!r}")
    return tuple(int(part) for part in number.split("."))


def edition_sort_key(edition: str) -> tuple[tuple[int, int, str], ...]:
    """Natural ordering of edition labels (``2026.10`` sorts after ``2026.9``)."""
    return tuple(
        (0, int(token), "") if token.isdigit() else (1, 0, token)
        for token in _EDITION_TOKEN_RE.findall(edition)
    )


@total_ordering
@dataclass(frozen=True, slots=True)
class ClauseRef:
    """Edition label plus dotted clause number.

    Canonical text form is ``<edition>:<number>``; :meth:`human` gives the spoken form.
    Ordering is by edition (natural order), then by the clause number compared as integers,
    so ``4.10`` sorts after ``4.2`` and ``4.2`` before ``4.2.1``.

    :param edition: Edition label, e.g. ``2026.1``
    :param number: Dotted clause number, e.g. ``4.2.1``
    :raises InvalidClauseRefError: If either part is malformed
    """

    edition: str
    number: str

    def __post_init__(self) -> None:
        if not _EDITION_RE.match(self.edition):
            raise InvalidClauseRefError(f"Invalid edition label: {self.edition!r}")
        parse_clause_number(self.number)

    @classmethod
    def parse(cls, text: str) -> Self:
        """Parse the canonical or spoken form.

        :param text: ``2026.1:4.2.1`` or ``2026.1 clause 4.2.1``
        :return: The reference
        :raises InvalidClauseRefError: If ``text`` matches neither form
        """
        match = _REF_RE.match(text.strip())
        if match is None:
            raise InvalidClauseRefError(f"Invalid clause reference: {text!r}")
        return cls(match["edition"], match["number"])

    def format(self) -> str:
        """Return the canonical text form.

        :return: ``<edition>:<number>``
        """
        return f"{self.edition}:{self.number}"

    def human(self) -> str:
        """Return the spoken form used in prose and citations.

        :return: ``<edition> clause <number>``
        """
        return f"{self.edition} clause {self.number}"

    @property
    def parts(self) -> tuple[int, ...]:
        """The clause number as integers."""
        return parse_clause_number(self.number)

    @property
    def depth(self) -> int:
        """Nesting level: ``4`` is 1, ``4.2`` is 2, ``4.2.1`` is 3."""
        return len(self.parts)

    def parent(self) -> Self | None:
        """Return the enclosing clause in the same edition.

        :return: ``4.2`` for ``4.2.1``; ``None`` for a top-level clause
        """
        if "." not in self.number:
            return None
        return type(self)(self.edition, self.number.rsplit(".", 1)[0])

    def is_descendant_of(self, other: ClauseRef) -> bool:
        """Tell whether this clause lies below ``other`` in the same edition.

        :param other: A candidate ancestor
        :return: True for ``4.2.1`` below ``4.2``; False for equal or unrelated clauses
        """
        mine, theirs = self.parts, other.parts
        return (
            self.edition == other.edition
            and len(mine) > len(theirs)
            and mine[: len(theirs)] == theirs
        )

    def _sort_key(self) -> tuple[tuple[tuple[int, int, str], ...], tuple[int, ...]]:
        return (edition_sort_key(self.edition), self.parts)

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, ClauseRef):
            return NotImplemented
        return self._sort_key() < other._sort_key()

    def __str__(self) -> str:
        return self.format()
