---
name: km-code-review
description: "Use to review your own change before the owner reads it, levels 3 and 4 on the diff of a work tree against origin/main. Argument is a task id or a work tree path."
argument-hint: <task id | work tree path>
disable-model-invocation: true
effort: high
---

# km-code-review

Argument: $0 is a task id or a path. A task id means the work tree /home/user/km/work/wt/$0;
a path is the work tree itself. It must exist and be a git work tree, else print
"usage: /km-code-review <task id|work tree path>", say what is missing, stop. Name = task id
(for a path: its last folder name). Depth: read the code, do not skim; the owner decides on
push from this report. Nothing is ever posted, pushed or commented: the report is a file.
Nothing is edited here either; fixes are the orchestrator's step in /km-build.

## 1 Round
- Report file: work/reviews/<name>.md. If it does not exist, this is round 1. If it holds
  "Round 1" and no "Round 2", this is round 2. If it holds both: print "two rounds done", the
  open items of the report, and stop. Never a third round.
- Round 2 covers only files changed since round 1: the report records the reviewed head
  sha. List them with `git -C <wt> diff --name-only <sha> HEAD`. No such file: print "nothing
  changed since round 1" and stop. Round 2 also asks the skeptic, in again mode, about every
  blocker and should-fix of round 1.

## 2 Diff
- First command: `mkdir -p /home/user/km/work/reviews`. Use absolute paths for every file.
- `git -C <wt> fetch origin` (read-only). Then
  `git -C <wt> diff origin/main...HEAD > /home/user/km/work/reviews/<name>-<tag>.diff` (tag
  r1 or r2; in round 2 diff `<sha>..HEAD` instead). Record `git -C <wt> rev-parse HEAD`.
- Uncommitted changes in the tree (`git status --short`): note them in the report; only
  committed changes are reviewed. Empty diff: say so, stop.
- Plan: work/plans/<name>.md if it exists; the reviewers check the change against it. Build
  summary work/builds/<name>.md if it exists: read its "not done" and "questions" lines.
  The plan's Conventions line names the conventions folder (kb/conventions/ for BASE_REPO,
  kb/conventions/capture/ for CAPTURE_REPO); no plan: kb/conventions/.

## 3 Level 3 and 4
Follow /home/user/km/.claude/skills/km-code-review/references/routing.md: layers from
kb/conventions/layers.md, the 2 to 4 reviewers, at most 3 subagents at once, merge, skeptic,
spot-check. Reviewer tasks name: the diff file, the work tree, the plan, the convention
files of the touched layers, the changed paths.

## 4 Report: work/reviews/<name>.md
Create it in round 1; in round 2 add a section at the end and leave round 1 as it is. At
most 150 lines of at most 100 characters; if longer, continue in <name>-2.md and say so.
Per round:
- Heading "Round N", date, head sha, base sha, work tree, files reviewed (count).
- Reviewers run and the reason for each skipped one; unmapped paths; missing convention files.
- Verdict, one line: ready for the owner, fix first, or not ready. Fix first or not ready
  when a blocker is proven. A blocker the skeptic left unclear keeps its severity: the verdict
  then reads "owner decides: unresolved blocker".
- Say which layer map and conventions folder were used.
- Table of proven findings, worst first:
  | # | Severity | Dimension | Place | What breaks and how | Fix | Skeptic |
- Unclear blockers also go in the table above (Skeptic = unclear, plus the one check that
  would settle it).
- Open questions: the unclear findings, each with what is missing.
- Counts: raised, proven, refuted (numbers), unclear.
- Round 2 only: table of round 1 blockers and should-fix: # | fixed, partly or not addressed |
  evidence. Then "Still open after two rounds" listing everything proven and not fixed,
  for the owner.
- Wording of every Fix cell and open question: read
  /home/user/km/.claude/skills/km-code-review/references/comment-voice.md first (severity
  word, path:line, quote, why, concrete fix; no padding). End the round with a
  "Could not verify" line, or "nothing" when true.
- Risk areas: if the diff touches access control, migrations or data deletion, say
  "advisor go or no-go needed before a pull request" (the orchestrator calls km-advisor).

## 5 Finish
- Write kb/log.d/<run>.txt with run id km-code-review-<name>-<tag>-<date>: date, task,
  report path, verdict, counts, what was skipped and why. No kb knowledge file, so no
  index.d entry.
- Print at most 8 lines: report path, verdict, counts by severity, the blockers in one line
  each, the next step (fix through the builder then round 2, or hand to the owner).
