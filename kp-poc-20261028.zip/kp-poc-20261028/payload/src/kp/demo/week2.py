"""Week 2, "search and links": a currency question returns the right clause with page and
position, and "which rules have no test" and "this rule changed, what is affected" answer."""

from __future__ import annotations

from datetime import timedelta

from kp.app import Application
from kp.demo.build import BuildRun
from kp.demo.model import Check, LineResult
from kp.demo.staging import StagedData
from kp.domain import ClauseRef, ItemType
from kp.links import CoverageEvidence, LinkService
from kp.search import quote_matches

CURRENCY_QUESTION = "which currency may an inbound credit transfer use?"
EXPECTED_CLAUSE = "4.2.1"
TOP = 3


def evaluate_week2(application: Application, staged: StagedData, build: BuildRun) -> LineResult:
    """Judge the week 2 line.

    :param application: The application the build ran on
    :param staged: The staged dataset (for the ground truth)
    :param build: What the build phases returned
    :return: The line with its checks
    """
    checks = (
        _currency_question(application, staged),
        _rule_as_at(application, staged),
        *_link_answers(application),
        _guessed_links(application, build),
        _publication(build),
    )
    return LineResult("W2", checks)


def _newest_edition(staged: StagedData) -> tuple[str, str]:
    editions = sorted(staged.dataset.truth.editions, key=lambda e: e.effective_date)
    return editions[-1].label, editions[-1].markdown_path


def _currency_question(application: Application, staged: StagedData) -> Check:
    label, markdown_path = _newest_edition(staged)
    expected = ClauseRef(label, EXPECTED_CLAUSE).format()
    day = application.clock.today()
    response = application.search.search(CURRENCY_QUESTION)
    rank = next((i for i, hit in enumerate(response.hits, 1) if hit.reference == expected), None)
    if rank is None:
        return Check("A currency question returns clause 4.2.1", False, f"{expected} not in hits")
    hit = response.hits[rank - 1]
    markdown = staged.dataset.path(markdown_path).read_text(encoding="utf-8")
    quoted = quote_matches(hit, markdown)
    ok = rank <= TOP and hit.page is not None and hit.char_start is not None and quoted
    detail = (
        f"'{CURRENCY_QUESTION}' as at {day.isoformat()} returns {hit.human_reference} at rank "
        f"{rank} (page {hit.page}, characters {hit.char_start}-{hit.char_end}); the quoted text "
        f"equals the source at that position: {'yes' if quoted else 'NO'}"
    )
    return Check("A currency question returns clause 4.2.1 with page and position", ok, detail)


def _rule_as_at(application: Application, staged: StagedData) -> Check:
    editions = sorted(staged.dataset.truth.editions, key=lambda e: e.effective_date)
    older, newer = editions[-2], editions[-1]
    before = newer.effective_date - timedelta(days=1)
    first = application.search.rule_as_at(EXPECTED_CLAUSE, as_at=before)
    second = application.search.rule_as_at(EXPECTED_CLAUSE, as_at=newer.effective_date)
    today = application.search.rule_as_at(EXPECTED_CLAUSE)
    ok = (
        first.ref.edition == older.label
        and second.ref.edition == newer.label
        and today.ref.edition == newer.label
    )
    detail = (
        f"clause {EXPECTED_CLAUSE} as at {before.isoformat()} is edition {first.ref.edition}; "
        f"as at {newer.effective_date.isoformat()} it is edition {second.ref.edition}; "
        f"with no date ({application.clock.today().isoformat()}) it is edition "
        f"{today.ref.edition}"
    )
    return Check("A rule can be read as at any date", ok, detail)


_CHAIN_TYPES = (
    ItemType.REQUIREMENT,
    ItemType.SPEC,
    ItemType.STORY,
    ItemType.CODE,
    ItemType.TEST,
)


def _link_answers(application: Application) -> tuple[Check, Check]:
    with application.database.transaction() as connection:
        service = LinkService(
            connection, thresholds=application.settings.thresholds, clock=application.clock
        )
        untested = service.rules_without_tests()
        covered = service.coverage().with_tests
        label = untested.edition
        impact = service.impact(ClauseRef(label, EXPECTED_CLAUSE))
        unlinked = next(
            (rule.reference for rule in untested.rules if not service.impact(rule.reference).items),
            None,
        )
        gap = service.impact(unlinked) if unlinked else None
    tested = ClauseRef(label, EXPECTED_CLAUSE).format()
    still_listed = {rule.reference for rule in untested.rules}
    with_test = {rule.reference: rule for rule in covered}
    listed = ", ".join(
        f"{rule.reference} ({rule.story_count} stories)" for rule in untested.rules[:4]
    )
    # The rule has a test only through a person's merged spec, code that says it implements the
    # spec, and a test that calls the code: the answer must therefore both list the other rules
    # and leave this one out.
    coverage_ok = (
        untested.total_rules > 0
        and tested in with_test
        and with_test[tested].test_evidence is CoverageEvidence.STATED
        and tested not in still_listed
        and len(untested.rules) + len(with_test) == untested.total_rules
        and 0 < len(untested.rules) < untested.total_rules
    )
    coverage = Check(
        "Which rules have no test",
        coverage_ok,
        f"{untested.summary} Rule with a test: {', '.join(sorted(with_test)) or 'none'} "
        f"(clause, spec, code and test linked by stated links, so it is not listed). "
        f"First without: {listed}",
    )
    kinds = ", ".join(
        f"{item.ref.item_type.value} {item.ref.key} [{item.kind.value}]" for item in impact.items
    )
    types = {item.ref.item_type for item in impact.items}
    gap_text = (
        f" A clause with no links ({unlinked}) says so: '{gap.message}'"
        if gap is not None and gap.message
        else ""
    )
    affected = Check(
        "This rule changed, what is affected",
        all(item_type in types for item_type in _CHAIN_TYPES)
        and impact.stated_count == len(impact.items)
        and (gap is None or bool(gap.message)),
        f"clause {impact.clause}, up to {impact.max_steps} steps: {kinds}. "
        f"{impact.stated_count} stated, {impact.guessed_count} guessed.{gap_text}",
    )
    return coverage, affected


def _guessed_links(application: Application, build: BuildRun) -> Check:
    after = build.after_sweep
    if not after.guessed:
        return Check("Guessed links are proposals within their share", False, "no edition in force")
    minimum = application.settings.thresholds.link_proposed_min
    proposed = [link for report in after.guessed for link in report.proposed]
    ok = after.share_within_limit and all(
        link.score is not None and link.score >= minimum for link in proposed
    )
    limit = after.guessed[-1].guessed_share_limit
    detail = (
        f"{after.proposed} proposed (score and evidence kept), {after.review} on the review "
        f"list (never used by answers), {after.dropped} not kept; guessed share "
        f"{after.guessed_share:.0%} against a limit of {limit:.0%}"
    )
    if not proposed:
        # An empty list satisfies "all proposed links score high enough" for free; say so.
        detail += (
            "; no pair scores high enough on this data, so the proposed band is not exercised "
            "here (the link tests cover it)"
        )
    return Check("Guessed links are proposals within their share", ok, detail)


def _publication(build: BuildRun) -> Check:
    version = build.publication.version
    failed = [check.name for check in version.blocking_failures()]
    detail = (
        f"knowledge version {version.version_id}: "
        f"{'published in one switch' if build.publication.published else 'kept, not published'}; "
        f"{len(version.checks)} checks, blocking failures: {failed or 'none'}"
    )
    return Check(
        "A knowledge version is published only when the checks pass",
        build.publication.published,
        detail,
    )
