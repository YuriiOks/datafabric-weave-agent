"""A write-once raw store on the local file system."""

from __future__ import annotations

from pathlib import Path
from urllib.parse import quote

from kp.domain import ItemKey
from kp.sweep.errors import RawStoreConflictError


def _component(text: str) -> str:
    """Make one path component safe: no separators, no dot-only names."""
    quoted = quote(text, safe="")
    return quoted.replace(".", "%2E") if quoted in {".", ".."} else quoted


class LocalRawStore:
    """Keeps raw bytes under ``<root>/<source>/<item>/<version>``; never overwrites.

    :param root: Directory that holds the raw files
    """

    def __init__(self, root: Path) -> None:
        self._root = root

    def put(self, key: ItemKey, content: bytes) -> str:
        """Store the bytes once.

        :param key: The version the bytes belong to
        :param content: The raw bytes
        :return: The location relative to the root
        :raises RawStoreConflictError: If other bytes are already stored for the key
        """
        location = "/".join(
            (_component(key.source.value), _component(key.item_id), _component(key.version))
        )
        path = self._root / location
        if path.exists():
            if path.read_bytes() != content:
                raise RawStoreConflictError("Raw location already holds different content")
            return location
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return location

    def get(self, location: str) -> bytes:
        """Read stored bytes back.

        :param location: A location returned by :meth:`put`
        :return: The stored bytes
        :raises FileNotFoundError: If nothing is stored at the location
        """
        return (self._root / location).read_bytes()
