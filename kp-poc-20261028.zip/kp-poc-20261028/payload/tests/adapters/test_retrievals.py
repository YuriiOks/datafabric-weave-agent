"""What each session was shown by the read tools, kept for the citation check."""

from __future__ import annotations

import pytest
from pydantic import JsonValue

from kp.adapters.retrievals import DatabaseSessionRetrievals, RetrievalRecorder, references_in
from kp.tools import DatabaseAuditSink, ToolResult, build_caller, build_read_registry
from world_support import World


def test_references_are_found_in_hits_rules_and_linked_items() -> None:
    payload: dict[str, JsonValue] = {
        "hits": [
            {"reference": "2026.1:4.2.1"},
            {"reference": "requirements-register:Requirements:5"},
        ],
        "items": [
            {"item_type": "requirement", "key": "REQ-1"},
            {"item_type": "test", "key": "tests/test_x.py::test_a"},
        ],
        "root_type": "clause",
        "root_key": "2026.1:4.2.2",
    }

    assert references_in(payload) == {
        "2026.1:4.2.1",
        "requirements-register:Requirements:5",
        "REQ-1",
        "2026.1:4.2.2",
    }


def test_a_payload_without_references_yields_none() -> None:
    assert references_in({"template_id": "x", "body": "text"}) == frozenset()


def test_the_recorder_stores_references_by_session_in_canonical_form(built_world: World) -> None:
    recorder = RetrievalRecorder(built_world.application.database, built_world.application.clock)
    caller = build_caller(user="user-full-access", session_id="sess-recorder")

    recorder(
        caller,
        "search",
        ToolResult(call_id="c1", payload={"hits": [{"reference": "2026.1 clause 4.2.1"}]}),
    )
    recorder(caller, "rule_as_at", ToolResult(call_id="c2", payload={"reference": "2026.1:4.2.1"}))

    seen = DatabaseSessionRetrievals(built_world.application.database)
    assert seen.references("sess-recorder", "user-full-access") == {"2026.1:4.2.1"}
    assert seen.references("another-session", "user-full-access") == frozenset()


def test_another_caller_naming_the_same_session_is_credited_with_nothing(
    built_world: World,
) -> None:
    recorder = RetrievalRecorder(built_world.application.database, built_world.application.clock)
    owner = build_caller(user="user-full-access", session_id="shared-label")
    recorder(owner, "rule_as_at", ToolResult(call_id="c1", payload={"reference": "2026.1:4.2.1"}))

    seen = DatabaseSessionRetrievals(built_world.application.database)

    assert seen.references("shared-label", "user-full-access") == {"2026.1:4.2.1"}
    assert seen.references("shared-label", "user-one-domain") == frozenset()


def test_the_registry_survives_an_observer_that_fails(
    built_world: World, caplog: pytest.LogCaptureFixture
) -> None:
    def failing(*_args: object) -> None:
        raise RuntimeError("observer broke")

    registry = build_read_registry(
        built_world.application.read_ports(),
        built_world.application.identity_mapping(),
        DatabaseAuditSink(built_world.application.database),
        clock=built_world.application.clock,
        observer=failing,
    )
    caller = build_caller(user="user-full-access", session_id="sess-observer")

    result = registry.call(caller, "rule_as_at", {"number": "4.2.1"})

    assert result.payload["reference"] == "2026.1:4.2.1"
    assert "Tool observer failed" in caplog.text
