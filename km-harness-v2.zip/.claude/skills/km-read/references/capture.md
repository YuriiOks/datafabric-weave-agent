# km-read capture

Goal: record what CAPTURE_REPO does, how its output could feed the ingestion design (S6), and
what is missing, as labelled facts with sources.
Input: CAPTURE_REPO, read only. Output: /home/user/km/kb/capture/. Do not run the tool, call a
remote system or use a token. Docs and comments are Reported; code decides.
Compare with kb/base/storage.md and the S6 part of kb/seed/story-gaps.md when they exist.

## Pick the mode
- Gap mode when /home/user/km/kb/private/claims.md exists. Its "Not read yet" section lists what
  an earlier read left out. Do not re-read what its claims cover.
- Full mode when it is absent. Map the whole repo by slices.

Every file ends with Weak points seen (path:line, one line each) and then Open questions.

## Output files and headings
- pipeline.md. End to end flow; Entry points (commands, arguments by name, Python interface,
  stable or internal); Run settings (names only); Authentication mechanisms to the agent
  platform (names only, never values); Output layout.
- sources-and-fidelity.md. Source types captured (table: type, unit captured, fields kept, how
  items are listed, attachments and links, output format); Fidelity proof (method, what it
  covers, what it does not); Raw copies and round trips.
- storage-and-audit.md. Path rule for raw objects; Write-once and idempotence; Local and bucket
  backends; Audit schema (tables, keys, columns by name); Events written; Link from a capture
  to user, run and source version; Lineage read-back.
- workbench.md. What a reviewer sees; Actions (accept, reject, edit, annotate); States; Where
  decisions are stored; Access control; Gap to a producer and steward flow (review, approve,
  publish).
- open-items.md. Mapping to S6 ingestion; Missing for S6 (table: item, level, evidence);
  Open questions.

open-items.md, Mapping to S6 ingestion, answers:
- which captured fields could become path segments (domain, sub-domain, namespace, product);
- where raw files would land in object storage, and how the audit trail links object to source;
- how a processing service could be called after capture;
- which S6 source types capture covers and which not (unstructured documents, database
  sources, REST sources).
Missing for S6, one row each, level working, partial or missing, evidence path: database and
REST capture, path layout rules, per-domain table creation, scheduling, incremental updates,
access control, quality checks, attachments.

## Full mode
Slices: readme and config; capture code by source type; storage and audit schema; command line
and Python interface; workbench (backend and UI). Batches of 3: pipeline, sources-and-fidelity,
storage-and-audit; then workbench; then open-items last (inputs: the four kb files above and
kb/base/storage.md; it reads code only to check a mapping). At most 8 reader calls.

## Gap mode
1. Read the "Not read yet" section at the end of /home/user/km/kb/private/claims-2.md
   (claims.md has none) for CAPTURE_REPO. If there is none, treat tests
   and workbench UI code as the gap.
2. Cover only those items: workbench.md for UI and workbench code, tests-and-deployment.md for
   tests and deployment files (default reader headings), pipeline.md for unread modules.
3. sources-and-fidelity.md, storage-and-audit.md and open-items.md restate what is known, short,
   and only after /km-verify has confirmed it. Find the verifier output through the
   kb/index.d/ entries of a km-verify run. None listed: do not write them, tell the owner
   "run /km-verify all first". Otherwise one km-reader per file, inputs = the verifier output
   and the Confirmed and Narrowed claims, no code reading, Observed only with the verifier's
   path:line.
4. At most 6 reader calls.

## Done when
- Each planned file exists with Date, Task, Status and labelled lines.
- open-items.md has the mapping and the missing table, each row with a level and a path.
- Every Observed line names path:line.
- Run record and kb-lint.sh PASS as in the method; summary printed.

## Stop
- A topic is not in the code: say so and list the paths searched.
- A reader returns partial twice for one topic: leave the rest in Open questions.
