"""Helpers that load the synthetic dataset into the tables the link queries read."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import openpyxl
from sqlalchemy import Connection, insert

from kp.domain import Requirement, SourceKind, Story, StoryLink
from kp.store.schema import clause, edition, passage, requirement, run, source_item, story
from kp.testing.dataset import SyntheticDataset

LOADED_AT = datetime(2026, 10, 1, 12, 0, tzinfo=UTC)
RUN_ID = "run-seed"


def insert_run(connection: Connection, run_id: str = RUN_ID, kind: str = "sweep") -> None:
    """Insert a run row that other rows can point at."""
    connection.execute(
        insert(run).values(
            run_id=run_id,
            kind=kind,
            sources=[],
            started_at=LOADED_AT,
            ended_at=LOADED_AT,
            outcome="succeeded",
            items_touched=0,
        )
    )


def insert_source_item(
    connection: Connection,
    source: SourceKind,
    item_id: str,
    version: str = "1",
    *,
    run_id: str = RUN_ID,
    approval_state: str = "admitted",
) -> None:
    """Insert a source item version with the minimum columns."""
    connection.execute(
        insert(source_item).values(
            source=source.value,
            item_id=item_id,
            version=version,
            native_id=item_id,
            content_sha256="0" * 64,
            media_type="text/markdown",
            title=item_id,
            raw_location=f"raw/{item_id}",
            fetched_at=LOADED_AT,
            run_id=run_id,
            extraction_status="not_required",
            approval_state=approval_state,
            machine_authored=False,
        )
    )


def seed_rulebook(connection: Connection, dataset: SyntheticDataset) -> None:
    """Load both rulebook editions, with their clauses, as the ingest lane would."""
    insert_run(connection)
    for truth in dataset.truth.editions:
        insert_source_item(connection, SourceKind.REGULATORY_REPO, truth.label)
        connection.execute(
            insert(edition).values(
                label=truth.label,
                effective_date=truth.effective_date,
                superseded_from=truth.superseded_from,
                withdrawn_from=None,
                title="Payments Rulebook",
                source=SourceKind.REGULATORY_REPO.value,
                item_id=truth.label,
                version="1",
            )
        )
        connection.execute(
            insert(clause),
            [
                {
                    "edition": truth.label,
                    "number": item.number,
                    "title": item.title,
                    "page": item.page,
                    "char_start": item.md_char_start,
                    "char_end": item.md_char_end,
                    "text": item.text,
                    "structure_score": 1.0,
                    "parent_number": item.number.rsplit(".", 1)[0] if "." in item.number else None,
                }
                for item in truth.clauses
            ],
        )


def register_requirements(dataset: SyntheticDataset) -> list[Requirement]:
    """Read the generated register into requirements, keyed by its own header names."""
    truth = dataset.truth.requirements_register
    workbook = openpyxl.load_workbook(dataset.path(truth.path), read_only=True)
    rows = list(workbook[truth.main_sheet].iter_rows(values_only=True))
    header = [str(cell) for cell in rows[truth.header_row - 1]]
    requirements = []
    for number, cells in enumerate(rows[truth.header_row :], start=truth.header_row + 1):
        if cells[0] is None:
            continue
        fields = {
            name: "" if cell is None else str(cell)
            for name, cell in zip(header, cells, strict=True)
        }
        requirements.append(
            Requirement(
                requirement_id=f"register:{truth.main_sheet}:{number}",
                source=SourceKind.GITHUB,
                item_id="register",
                version="1",
                sheet=truth.main_sheet,
                row_number=number,
                header_confidence=1.0,
                domain=fields.get("Domain"),
                fields=fields,
            )
        )
    return requirements


def exported_stories(dataset: SyntheticDataset, export: str) -> list[Story]:
    """Read one generated Jira export into stories."""
    document: dict[str, Any] = json.loads(dataset.path(export).read_text(encoding="utf-8"))
    stories = []
    for issue in document["issues"]:
        fields = issue["fields"]
        parent = fields["parent"]
        stories.append(
            Story(
                story_key=issue["key"],
                version=fields["updated"],
                summary=fields["summary"],
                description=fields["description"],
                acceptance_criteria=fields["acceptance_criteria"],
                links=tuple(
                    StoryLink(link_type=link["type"], target_key=link["key"])
                    for link in fields["issuelinks"]
                ),
                parent_key=None if parent is None else parent["key"],
                status=fields["status"]["name"],
            )
        )
    return stories


def insert_stories(
    connection: Connection, stories: list[Story], *, with_source: bool = True
) -> None:
    """Store stories (and, by default, the source item each one was read from)."""
    for item in stories:
        if with_source:
            insert_source_item(connection, SourceKind.JIRA, item.story_key, item.version)
        connection.execute(
            insert(story).values(
                story_key=item.story_key,
                version=item.version,
                summary=item.summary,
                description=item.description,
                acceptance_criteria=item.acceptance_criteria,
                links=[link.model_dump() for link in item.links],
                parent_key=item.parent_key,
                status=item.status,
                domain=None,
                fingerprint=item.fingerprint(),
            )
        )


def insert_requirements(connection: Connection, requirements: list[Requirement]) -> None:
    """Store requirements and the source item they were read from."""
    for item in requirements:
        connection.execute(
            insert(requirement).values(
                requirement_id=item.requirement_id,
                source=item.source.value,
                item_id=item.item_id,
                version=item.version,
                sheet=item.sheet,
                row_number=item.row_number,
                header_confidence=item.header_confidence,
                domain=item.domain,
                fields=item.fields,
            )
        )


def insert_passage(connection: Connection, passage_id: str, item_id: str) -> None:
    """Store a clause passage cut from version 1 of a regulatory-repository item."""
    connection.execute(
        insert(passage).values(
            passage_id=passage_id,
            passage_type="clause",
            parent_ref="2026.1:4.2.1",
            source=SourceKind.REGULATORY_REPO.value,
            item_id=item_id,
            version="1",
            text="text",
            tokens=1,
        )
    )


def x_clause_field_count(root: Path) -> int:
    """Count the schema properties under a repository root that carry an ``x-clause`` entry."""
    return sum(
        1
        for schema in root.rglob("*.schema.json")
        for definition in json.loads(schema.read_text(encoding="utf-8"))["properties"].values()
        if "x-clause" in definition
    )
