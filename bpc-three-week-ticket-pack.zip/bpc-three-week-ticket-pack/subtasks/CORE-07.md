---
pack_id: "bpc-sep26-v1"
local_id: "CORE-07"
kind: "subtask"
existing_jira_key: null
parent_ref: "FOUNDATION"
summary: "Instrument the existing Hub path with typed baseline observations"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-21"
planned_due: "2026-09-21"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["CORE-02"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-core-07"
architecture_sections: ["ai-contracts","decision-authority","validation-gates"]
---

# Instrument the existing Hub path with typed baseline observations

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **FOUNDATION**. Local reference **CORE-07** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-21 → 2026-09-21 (D9–D9)**.
- Recommendation extension: **2026-09-18 → 2026-09-18 (D8–D8)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

Establish a reproducible incumbent baseline before changing AI behavior. Preserve legacy served outcomes while making their origin, failures and evidence coverage measurable.

## Scope and contract

Use non-authoritative BaselineObservation for legacy model verdicts and a separate authoritative TaskDecision contract for the candidate policy. Capture task-specific CandidateHit/SourceEvidence observations only where the current implementation exposes them; missing observations remain explicit.

## Implementation sequence

1. Map incumbent and bounded Hub routes and feature defaults in the current checkout; do not add a third pipeline.
2. Wrap request/retrieval/evidence/outcome seams using CORE-02 discriminated contracts without changing incumbent user-visible behavior.
3. Resolve and pin server-owned schema/policy/prompt/model/deployment/builder/data configuration; capture actual returned model identity where available and reject detected incompatible drift for cache/evaluation.
4. Create immutable RunManifest and a replay adapter that records all planned cases, execution failures and unavailable observations.
5. Add safe stage metrics and evidence retention rules without logging raw prompts/queries/secrets in normal telemetry.
6. Reproduce the original completeness case separately; map field aliases to what the scorer actually consumes and report whether its cause/fix is verified.

## Acceptance criteria

- [ ] Legacy model output is never relabelled as an authoritative deterministic decision.
- [ ] Typed wrapping preserves recorded behavior on replay; intentional differences require a separate candidate change.
- [ ] Complete-case, failed-case, judged and unjudged denominators are separately recorded.
- [ ] Unavailable immutable provider identity is marked deployment-scoped with explicit policy, never fabricated.
- [ ] Completeness, novelty and component fit remain separate tasks and metrics.

## Verification

- Compare old/new wrapper output on the same frozen inputs and inspect failed/missing-dependency cases.
- Test task mismatch, missing lineage, provider metadata drift and raw telemetry leakage.

## Evidence to attach

- Baseline manifest, replay comparison, stage coverage map, completeness diagnostic and CI reference.

## Integration map and estimate conditions

Inspect the current bank checkout and record exact files, symbols, routes, schema mechanism and approved CI commands in the CORE-01 map before editing. Logical boundaries here are proposed responsibilities, not claims that named modules exist. The estimate includes focused implementation, relevant tests, peer review and one correction pass. It assumes the reported working PoC and approved access can be reused; a missing foundational capability triggers a revised estimate, not reduced acceptance.

## Boundaries and blockers

No quality claim from the historical unmeasured 16-case attempt. Missing model access or labels blocks comparison rather than becoming an empty-success result.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `ai-contracts`, `decision-authority`, `validation-gates`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
