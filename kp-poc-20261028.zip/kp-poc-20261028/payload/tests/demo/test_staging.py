"""Staging the synthetic dataset for the demo."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import pytest

from kp.demo.staging import REGISTER_SIDECAR, StagedData, find_dataset, stage
from kp.errors import ConfigurationError


@pytest.fixture
def staged(committed_fixtures_dir: Path, tmp_path: Path) -> StagedData:
    return stage(committed_fixtures_dir, tmp_path)


def test_the_register_enters_the_library_with_a_sidecar_that_approves_it(
    staged: StagedData,
) -> None:
    sidecar = json.loads((staged.library / "requirements-register.meta.json").read_text("utf-8"))

    assert (staged.library / "requirements-register.xlsx").is_file()
    assert sidecar == REGISTER_SIDECAR
    assert sidecar["approval_status"] == "approved"
    assert sidecar["document_type"] == "register"


def test_the_second_jira_export_is_held_back_until_revealed(staged: StagedData) -> None:
    second = staged.second_jira_export.name

    assert not (staged.jira / second).exists()
    assert (staged.jira / "export-1.json").exists()

    staged.reveal_second_jira_export()

    assert (staged.jira / second).exists()


def test_staging_twice_starts_from_a_clean_copy(
    committed_fixtures_dir: Path, tmp_path: Path
) -> None:
    first = stage(committed_fixtures_dir, tmp_path)
    first.reveal_second_jira_export()
    (first.library / "stray.md").write_text("left behind", encoding="utf-8")

    again = stage(committed_fixtures_dir, tmp_path)

    assert not (again.library / "stray.md").exists()
    assert not (again.jira / again.second_jira_export.name).exists()


def test_the_demo_runs_four_days_after_the_newest_edition_takes_effect(staged: StagedData) -> None:
    assert staged.demo_instant() == datetime(2026, 11, 20, 9, tzinfo=UTC)


def test_a_folder_without_ground_truth_is_not_a_dataset(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="No synthetic dataset"):
        find_dataset(tmp_path)


def test_the_bundled_dataset_is_found_when_none_is_named() -> None:
    assert (find_dataset(None) / "ground_truth.json").is_file()
