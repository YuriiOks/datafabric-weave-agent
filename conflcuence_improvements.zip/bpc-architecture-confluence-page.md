# BPC / AI Playbooks Hub — Verified Findings and Proposed Follow-on

**Owner:** Yurii Oksamytnyi  
**Working partner:** Joseph  
**Date:** 4 August 2026  
**Status:** Draft for review — publish as Final only after the publication gates below are closed  
**Scope:** Current one-week assignment plus a separately estimated follow-on proposal  
**Technical appendix:** `architecture-improvement-review-v3-1.html` (full v3.1 review)  

## Executive summary

The reviewed BPC architecture has a sound base: FalkorDB already combines graph and vector retrieval, ingestion is diff-based, graph hydration is batched, most transient state is externalized to Redis, and search admission is bounded. There is no current evidence that adding ChromaDB, Qdrant, a second graph database, or another orchestration framework would improve the product.

The main issue is not the choice of vector database. The reviewed materials indicate that the default legacy LangGraph/LangChain path allows an LLM to decide the authoritative `NOVEL / PARTIAL / COVERED` verdict, while the existing deterministic bounded path is opt-in and has no adjudicated benchmark. Before this is described as a bank-wide governance capability, the team needs an explicit Model Risk / AI-governance classification, a named decision-policy owner, validation requirements, human-review controls, and a reproducible evaluation baseline.

The recommendation is to harden the bounded path that already exists. Use typed Pydantic contracts, deterministic scoring, evidence maturity, benchmarked rank fusion, calibrated confidence, and a real review workflow. Keep LLMs behind narrow, non-authoritative boundaries such as structured intent extraction and evidence-bound explanation.

![Current default authority compared with the proposed deterministic target architecture](./bpc-confluence-assets/01-decision-authority-architecture.png)

*Figure 1 — The target reuses the existing bounded retrieval implementation and moves authoritative verdict ownership into a versioned deterministic policy.*

## Decision requested from Marcin

1. Confirm that the current one-week commitment remains limited to the agreed UI fixes with Joseph, source verification, and this concise Confluence page.
2. Confirm who should own the proposed follow-on programme and whether it should be estimated for prioritisation.
3. Route the Model Risk / AI-governance, Security/Privacy, and decision-policy questions to named owners; this page does not invent those answers.

## What is working and should be retained

| Area | Current strength | Recommendation |
| --- | --- | --- |
| Storage | FalkorDB already supports graph and vector retrieval in one platform, with PostgreSQL for durable state and Redis for transient state. | Keep the existing store topology until a controlled benchmark proves it misses an agreed quality, latency, freshness, or cost gate. |
| Ingestion | File/registry hashing and idempotent `MERGE` operations avoid unnecessary reprocessing. | Extend toward record-level changes and immutable generation manifests. |
| Search API | Submit/poll semantics, bounded admission, `503 + Retry-After`, and owner-scoped job IDs are appropriate under load. | Keep the API shape; externalize the remaining process-local state before enabling multiple replicas. |
| Graph retrieval | Batched hydration avoids N+1 graph queries and the graph can explain shared capabilities, technologies, sources, and domains. | Use bounded, deterministic traversal after candidate generation. |
| Security baseline | Parameterized Cypher, security headers, narrow CORS, path guards, and secret-aware builds are good foundations. | Complete the AI-specific threat model for untrusted card content, data privacy, and retrieval-time entitlements. |
| Typed application stack | FastAPI and Pydantic v2 are already present. | Extend Pydantic contracts through the internal pipeline; do not replace LangGraph one-for-one with another graph runtime. |

## Findings that need action

| Priority | Finding | Why it matters | Immediate action |
| --- | --- | --- | --- |
| Publication blocker | An unvalidated GenAI path appears to own the default business verdict. | The result can influence governance decisions without a documented validation obligation or accountable policy owner. | Verify the exact default path and raise the formal Model Risk / AI-governance control questions. |
| Publication blocker | Contributor-controlled Markdown/card content can reach the legacy decision model. | This creates an indirect prompt-injection and corpus-poisoning surface. | Verify the data flow; treat card text as untrusted evidence; keep the authoritative verdict deterministic. |
| High | There is source data but no golden benchmark. | The current corpus does not provide fixed queries, relevance labels, expected verdicts, or adjudicated evidence, so improvement claims are not reproducible. | Create an adjudicated dataset and a common legacy/bounded evaluation adapter as follow-on work. |
| High | The flagship UC0004963 card appears to be outside the ingester's expected path. | Demo/reference content may be invisible to the platform without a hard failure. | Verify the path in source and add an empty-source failure or warning. |
| High | Job, admission, embedding-cache, or gateway state remains process-local. | A non-sticky multi-replica deployment can lose polls or exceed intended limits. | Keep one replica until the residual state is externalized or routing requirements are explicit. |
| High | No immutable run/model/corpus lineage is documented. | Model, prompt, embedding, retrieval-policy, and corpus changes cannot be compared or reconstructed reliably. | Introduce a versioned run manifest and experiment registry before claiming model improvements. |

## Current one-week delivery

Only the first row below is an implementation commitment. The remaining rows are verification and recommendation outputs unless separate repository access and approval are provided.

| ID | Deliverable | Yurii | Joseph | Evidence / exit |
| --- | --- | --- | --- | --- |
| `UI-001` | Complete and verify the agreed small UI fixes. | Implement the assigned technical/UI items and capture the final state. | Confirm the user journey, pair on assigned fixes, and mark completed Feedback/Suggestions items as Done. | Agreed screenshots, URLs, or acceptance evidence. |
| `ING-001` | Verify the UC0004963 source-path issue and recommend an empty-source guard. | Verify against the BPC repository and record the exact path/behaviour. | Confirm the expected card/user journey where relevant. | Source reference plus observed ingestion result. |
| `SEC-001` | Verify the default Postgres-password finding and recommend approved secret injection/rotation. | Confirm the configuration and document the required owner. | No architecture ownership implied. | Source reference and named secret/rotation owner. |
| `DX-002` | Recommend Ruff pre-commit rules aligned with the future CI command. | Draft the recommendation without presenting local hooks as the authoritative gate. | — | Proposed command/config and CI dependency. |
| `DOC-002` | Publish this concise evidence page and link the full technical appendix. | Own the page, source citations, open questions, and follow-on framing. | Confirm current-state UI evidence. | Page reviewed, appendix linked, blockers visible. |

## Proposed follow-on programme

This is a recommendation for prioritisation, not a commitment inside the current week.

### Outcome A — govern and measure the decision

- Obtain the formal Model Risk / AI-governance classification, policy owner, validation obligation, and human-review requirements.
- Build an adjudicated golden dataset with retrieval labels, expected verdicts, evidence annotations, a calibration split, a frozen release set, and an indirect-injection cohort.
- Record immutable run lineage: corpus generation, embedding and reranker identifiers, LLM/provider, prompt version, retrieval configuration, scoring policy, sampling parameters, code revision, cost, and latency.
- Define evidence-maturity policy, confidence calibration, privacy/retention rules, and a review queue with SLA and override audit.

![Benchmark comparison and immutable model, prompt, policy and corpus lineage](./bpc-confluence-assets/04-benchmark-model-lineage.png)

*Figure 2 — A common adapter makes legacy and bounded runs comparable; an immutable run manifest makes every improvement claim reconstructable.*

### Outcome B — harden the existing bounded path

- Introduce Pydantic contracts for queries, candidates, evidence, score components, decision status, verdict, review context, and run context.
- Keep `NOVEL / PARTIAL / COVERED` as the three business verdicts; represent abstention with an orthogonal `decision_status` and enforce the invariant `DECIDED ⇔ verdict != null ⇔ confidence != null`.
- Compare the legacy and bounded implementations through one evaluation adapter.
- Harden the existing six retrieval channels; compare weighted sum with Reciprocal Rank Fusion; include `SIMILAR_TO` and evidence maturity only where the benchmark supports them.
- Add a versioned contributor-card schema, CI validation, quarantine/repair flow, duplicate checks, and a dual-generation embedding migration playbook.
- Evaluate a reranker only after confirming an approved Gateway/hosting path and a measured benchmark win.

![Bounded graph-assisted retrieval with allow-listed relations and deterministic budgets](./bpc-confluence-assets/02-bounded-graph-retrieval.png)

*Figure 3 — Graph/RAG expansion is seeded by deterministic channels, bounded by explicit budgets, and returned as typed evidence; LLM-generated Cypher is excluded from the authority path.*

![Dual-generation embedding backfill, validation, atomic cutover and rollback](./bpc-confluence-assets/03-embedding-generation-cutover.png)

*Figure 4 — A new embedding space is built and shadowed in parallel; old and new vectors are never mixed in one active generation.*

### Outcome C — scale and operate safely

- Externalize process-local job, admission, cache, and gateway state before multi-replica rollout.
- Publish immutable data/embedding generations with version-pinned reads, atomic cutover, draining, rollback, retention, and pruning.
- Add stage metrics, privacy-safe traces, SLOs, alerts, runbooks, error budgets, and daily/monthly Gateway call-token-cost budgets.
- Run 1×, 10×, and forecast-scale tests, including `SIMILAR_TO` maintenance, hot-node behaviour, quota exhaustion, replica loss, and in-flight generation cutover.
- Reconsider Qdrant or a durable workflow engine only if the existing platform fails a pre-agreed benchmark or operational gate.

![Capacity testing ladder from the current corpus to forecast scale](./bpc-confluence-assets/05-capacity-test-ladder.png)

*Figure 5 — Store and scale decisions are based on repeatable 1×, 10×, and forecast-tier evidence rather than an arbitrary item-count threshold.*

![Proposed CI and CD pipeline with separate code, content, security, benchmark and rollout gates](./bpc-confluence-assets/06-cicd-quality-gates.png)

*Figure 6 — Conventional CI, contributor-card validation, the frozen AI-quality benchmark, and shadow/canary rollout protect different failure surfaces and converge on one release decision.*

## Technology decisions

| Proposal | Decision | Reason / reopen gate |
| --- | --- | --- |
| Add ChromaDB | Reject | Duplicates current vector capability without an identified quality, scale, governance, or operational gain. |
| Migrate to Qdrant now | Reject | Reopen only if FalkorDB fails an agreed controlled benchmark and Qdrant wins the comparison. |
| Replace LangGraph with Pydantic Graph | Reject | The online path should be ordinary typed services, not the same dynamic orchestration hidden behind another framework. |
| Use Pydantic / PydanticAI | Adopt narrowly | Pydantic owns contracts and validation. PydanticAI is optional only at approved intent/explanation boundaries; it does not own retrieval or verdicts. |
| Build a third retrieval pipeline | Reject | Harden the existing bounded implementation instead. |
| Add `REVIEW_REQUIRED` as a fourth verdict | Reject | Preserve the three-class business taxonomy; model review/abstention as an orthogonal status backed by a real queue and SLA. |
| Let an LLM choose graph traversal or verdict | Reject for the authoritative path | Allowed only for clearly non-binding exploration. |

## How Yurii and Joseph will work together

### Yurii

- Own the architecture review, source verification, and this Confluence proposal.
- Implement the small technical/UI items explicitly assigned in the current workstream.
- Frame governance, benchmark, security, and scaling work as estimated follow-on, with unknown owners stated honestly.
- If follow-on is approved, define the typed contracts, evaluation schema, metrics, and run/model lineage with the assigned platform and control owners.

### Joseph

- Confirm what Feedback/Suggestions and user-flow items are already complete, with evidence.
- Provide or help obtain real URLs, access, screenshots, and acceptance evidence.
- Pair on the UI items explicitly assigned to the current workstream.
- Joseph is not reassigned by this proposal to benchmark labelling or platform architecture; any future domain-review role needs explicit agreement.

### Joint contract

1. Joseph validates the current user journey and delivered UI state.
2. Yurii maps the evidence and source findings into the final page.
3. Neither person silently expands the one-week scope into benchmark creation, Model Risk remediation, or platform rearchitecture.
4. Any approved follow-on receives named product, platform, Security/Privacy, Model Risk, and domain-review owners.
5. Every future “improved” claim includes a baseline, candidate run, corpus generation, configuration, and metric delta.

## Publication gates

Before changing this page from **Draft** to **Final**:

1. Confirm the exact default value and ownership of `BOUNDED_SEARCH_REASONING_ENABLED`, including whether raw card text reaches the verdict-owning LLM.
2. Reconcile the documented graph relationships, score weights, model identifiers/dimensions, storage implementation, and current corpus counts against the BPC source and runtime configuration.
3. Confirm the `SIMILAR_TO` generation/update algorithm and FalkorDB HNSW behaviour on indexed vector-property updates.
4. Confirm whether any golden cases, evaluation scripts, experiment records, or production feedback labels already exist outside the reviewed material.
5. Obtain named answers for Model Risk / AI-governance classification, decision-policy ownership, human oversight, privacy/retention, and contributor-card validation.
6. Confirm retrieval-time product/project access-control requirements and required corpus/query languages.
7. Confirm the exact current-week scope and acceptance evidence with Marcin and Joseph.
8. Keep the complete 20-item VERIFY checklist and detailed design in the technical appendix.

## Scope boundary

**Committed now:** agreed AI Playbooks Hub UI quick wins with Joseph, source verification, and this concise proposal page.

**Recommended follow-on only:** decision governance, benchmark/evaluation, bounded-path hardening, review workflow, contributor schema, embedding/data generations, safe scale-out, observability, SLOs, and cost controls.

**Future product work:** structured AIRCO draft-to-corpus matching, form prefill, review-queue UI, decision-status display, and verdict-change notifications. These are useful extensions but are not part of the current UI commitment.

**Out of scope:** DMC Workspace implementation, Data Fabric/Weave repositories, and speculative changes to unreviewed HSBC platform infrastructure.

---

**Appendix handling:** keep `architecture-improvement-review.md` as the canonical versioned repository document. For readers without repository access, attach `architecture-improvement-review-v3-1.html` to this page or publish it as a read-only child page/PDF, and link that canonical copy here.
