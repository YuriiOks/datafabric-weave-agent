Component page bundle (2026-10-14)
==================================

The approved design for a registry component's page: the hero with the facet band, four summary
tiles, the full definition (.md rendered, with a Markdown toggle), details, eligibility with the
Recommend action, where it comes from, and related components. Two columns on wide screens and
one column on phones.

Contents
  files/frontend/src/features/recsys/component-page/   18 new files (13 source, 4 tests, 1 index)
  install.py        copies them into the worktree (Python 3, standard library only)
  MANIFEST.sha256   checksum of every file under files/
  WIRING.md         how to plug the page into the current component route

Install
  1. Unzip outside the repository, for example:
       cd /home/user/bpc-port && unzip component-page-2026-10-14.zip
  2. Read only, changes nothing:
       python3 /home/user/bpc-port/component-page/install.py --inspect
  3. Copy the files (default target: the poc-suggested-components worktree):
       python3 /home/user/bpc-port/component-page/install.py
     Another checkout:   --target /path/to/checkout
     Replace an earlier install of this bundle:   --update (backs up the old files first)
  4. Wire it as WIRING.md describes.

install.py never overwrites a file without --update, never stages, commits or pushes, and never
runs tests, lint or type checks. It prints those commands at the end.

No new npm packages. The Markdown reader is part of the bundle and renders React elements only,
so HTML in a .md file shows as text, and links other than http(s), mailto, anchors and relative
paths are dropped.
