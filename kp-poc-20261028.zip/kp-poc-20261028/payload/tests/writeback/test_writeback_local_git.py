"""US-19 / US-22 against a real local repository (skipped when no git binary works)."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

from kp.clock import FixedClock
from kp.errors import WriteNotPermittedError
from kp.writeback import LocalGitPublisher, PublishError, PublishRequest
from kp.writeback.rendering import MACHINE_AUTHOR_NAME, MACHINE_TRAILER

BRANCH = "spec/pay-101"
PATH = "specs/PAY-101.md"


def run_git(git_binary: str, repository: Path, *args: str) -> str:
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    done = subprocess.run(  # noqa: S603 - fixed argument vector in a test
        [git_binary, "-C", str(repository), *args],
        capture_output=True,
        check=True,
        env=env,
    )
    return done.stdout.decode("utf-8").strip()


def request(
    content: str = "# Spec\n", *, branch: str = BRANCH, body: str = "body"
) -> PublishRequest:
    return PublishRequest(
        repository="example-org/example-specs",
        branch=branch,
        path=PATH,
        content=content,
        commit_message=f"Draft spec for PAY-101\n\n{MACHINE_TRAILER}\n",
        pr_title="[PAY-101] Title",
        pr_body=body,
    )


@pytest.fixture
def repository(tmp_path: Path, git_binary: str, clock: FixedClock) -> Path:
    path = tmp_path / "specs-repo"
    LocalGitPublisher.initialise(path, git_binary, clock=clock)
    return path


@pytest.fixture
def publisher(repository: Path, git_binary: str, clock: FixedClock) -> LocalGitPublisher:
    return LocalGitPublisher(repository, git_binary, clock=clock)


def test_us19_publish_creates_a_branch_with_the_spec_and_a_pull_request_record(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    result = publisher.publish(request("# Spec\n\nBody.\n", body="PR body"))

    assert (result.created, result.committed, result.pr_number) == (True, True, 1)
    assert result.pr_url == "local-pr:1"
    assert run_git(git_binary, repository, "show", f"{BRANCH}:{PATH}") == "# Spec\n\nBody."
    assert run_git(git_binary, repository, "rev-parse", BRANCH) == result.commit_sha
    git_dir = Path(run_git(git_binary, repository, "rev-parse", "--absolute-git-dir"))
    record = json.loads((git_dir / "kp-pull-requests" / "spec__pay-101.json").read_text("utf-8"))
    assert (record["head"], record["base"], record["state"], record["body"]) == (
        BRANCH,
        "main",
        "open",
        "PR body",
    )
    assert record["title"] == "[PAY-101] Title"


def test_us19_the_commit_is_machine_authored(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    publisher.publish(request())

    author = run_git(git_binary, repository, "log", "-1", "--format=%an", BRANCH)
    committer = run_git(git_binary, repository, "log", "-1", "--format=%cn", BRANCH)
    message = run_git(git_binary, repository, "log", "-1", "--format=%B", BRANCH)
    assert author == committer == MACHINE_AUTHOR_NAME
    assert MACHINE_TRAILER in message.splitlines()


def test_us19_same_draft_published_twice_yields_no_second_pull_request(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    first = publisher.publish(request())
    second = publisher.publish(request())

    assert (second.created, second.committed) == (False, False)
    assert (second.pr_number, second.commit_sha) == (first.pr_number, first.commit_sha)
    assert run_git(git_binary, repository, "rev-list", "--count", BRANCH) == "2"
    git_dir = Path(run_git(git_binary, repository, "rev-parse", "--absolute-git-dir"))
    assert len(list((git_dir / "kp-pull-requests").glob("*.json"))) == 1


def test_us19_a_changed_draft_adds_a_commit_to_the_same_pull_request(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    first = publisher.publish(request("# One\n", body="first"))
    second = publisher.publish(request("# Two\n", body="second"))

    assert (second.created, second.committed, second.pr_number) == (False, True, first.pr_number)
    assert run_git(git_binary, repository, "show", f"{BRANCH}:{PATH}") == "# Two"
    assert run_git(git_binary, repository, "rev-list", "--count", BRANCH) == "3"
    git_dir = Path(run_git(git_binary, repository, "rev-parse", "--absolute-git-dir"))
    record = json.loads((git_dir / "kp-pull-requests" / "spec__pay-101.json").read_text("utf-8"))
    assert record["body"] == "second"


def test_us19_other_stories_get_their_own_pull_request(publisher: LocalGitPublisher) -> None:
    first = publisher.publish(request())
    other = publisher.publish(request(branch="spec/pay-102"))

    assert (first.pr_number, other.pr_number) == (1, 2)


def test_us22_the_base_branch_is_never_committed_to(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    before = run_git(git_binary, repository, "rev-parse", "main")

    publisher.publish(request("# One\n"))
    publisher.publish(request("# Two\n"))

    assert run_git(git_binary, repository, "rev-parse", "main") == before
    assert run_git(git_binary, repository, "ls-tree", "-r", "--name-only", "main") == ""


def test_us22_a_request_for_the_base_branch_is_refused_and_changes_nothing(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    before = run_git(git_binary, repository, "rev-parse", "main")

    with pytest.raises(WriteNotPermittedError):
        publisher.publish(request(branch="main"))

    assert run_git(git_binary, repository, "rev-parse", "main") == before
    git_dir = Path(run_git(git_binary, repository, "rev-parse", "--absolute-git-dir"))
    assert not (git_dir / "kp-pull-requests").exists()


def test_us19_the_callers_working_tree_and_checked_out_branch_are_untouched(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    publisher.publish(request())

    assert run_git(git_binary, repository, "symbolic-ref", "--short", "HEAD") == "main"
    assert run_git(git_binary, repository, "status", "--porcelain") == ""
    assert not (repository / PATH).exists()


def test_us19_initialise_is_idempotent(
    repository: Path, git_binary: str, clock: FixedClock
) -> None:
    before = run_git(git_binary, repository, "rev-parse", "main")

    LocalGitPublisher.initialise(repository, git_binary, clock=clock)

    assert run_git(git_binary, repository, "rev-parse", "main") == before


def test_us19_a_closed_pull_request_record_is_not_reopened_or_committed_to(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    first = publisher.publish(request("# One\n"))
    git_dir = Path(run_git(git_binary, repository, "rev-parse", "--absolute-git-dir"))
    record_path = git_dir / "kp-pull-requests" / "spec__pay-101.json"
    record = json.loads(record_path.read_text(encoding="utf-8"))
    record["state"] = "merged"
    record_path.write_text(json.dumps(record), encoding="utf-8")

    with pytest.raises(PublishError):
        publisher.publish(request("# Two\n"))

    assert run_git(git_binary, repository, "rev-parse", BRANCH) == first.commit_sha
    assert json.loads(record_path.read_text(encoding="utf-8"))["state"] == "merged"


def test_us22_a_request_for_another_repository_is_refused_and_changes_nothing(
    repository: Path, git_binary: str, clock: FixedClock
) -> None:
    bound = LocalGitPublisher(
        repository, git_binary, clock=clock, repository="example-org/example-specs"
    )
    other = request().model_copy(update={"repository": "other-org/other-repo"})

    with pytest.raises(WriteNotPermittedError):
        bound.publish(other)

    assert run_git(git_binary, repository, "branch", "--list", BRANCH) == ""
    assert bound.publish(request()).created is True


def test_us23_merging_puts_the_branch_file_on_the_base_branch_and_dates_the_merge(
    publisher: LocalGitPublisher, repository: Path, git_binary: str, clock: FixedClock
) -> None:
    publisher.publish(request("# Spec\n\nBody.\n"))

    merged = publisher.merge(BRANCH)

    assert (merged.merged, merged.path, merged.merged_at) == (True, PATH, clock.now())
    assert run_git(git_binary, repository, "show", f"main:{PATH}") == "# Spec\n\nBody."
    assert run_git(git_binary, repository, "rev-parse", "main") == merged.commit_sha
    (listed,) = publisher.merged_specs()
    assert (listed.path, listed.content, listed.merged_at) == (
        PATH,
        b"# Spec\n\nBody.\n",
        clock.now(),
    )


def test_us23_an_unmerged_branch_is_not_a_merged_spec(publisher: LocalGitPublisher) -> None:
    publisher.publish(request())

    assert publisher.merged_specs() == []


def test_us23_merging_twice_changes_nothing_and_a_merged_branch_takes_no_more_commits(
    publisher: LocalGitPublisher, repository: Path, git_binary: str
) -> None:
    publisher.publish(request())
    first = publisher.merge(BRANCH)
    base = run_git(git_binary, repository, "rev-parse", "main")

    again = publisher.merge(BRANCH)

    assert (again.merged, again.commit_sha) == (False, first.commit_sha)
    assert run_git(git_binary, repository, "rev-parse", "main") == base
    with pytest.raises(PublishError, match="no longer open"):
        publisher.publish(request("# Changed\n"))


def test_us23_merging_a_branch_that_was_never_published_is_refused(
    publisher: LocalGitPublisher,
) -> None:
    with pytest.raises(PublishError, match="no open pull request"):
        publisher.merge("spec/unknown")


def test_us23_a_later_merge_of_the_same_file_replaces_it_in_the_listing(
    publisher: LocalGitPublisher, clock: FixedClock
) -> None:
    publisher.publish(request("# First\n"))
    publisher.merge(BRANCH)
    clock.set(clock.now().replace(day=clock.now().day + 1))
    publisher.publish(request("# Edited by a person\n", branch="people/edit"))

    second = publisher.merge("people/edit")

    (listed,) = publisher.merged_specs()
    assert listed.content == b"# Edited by a person\n"
    assert listed.merged_at == second.merged_at > publisher.merge(BRANCH).merged_at
