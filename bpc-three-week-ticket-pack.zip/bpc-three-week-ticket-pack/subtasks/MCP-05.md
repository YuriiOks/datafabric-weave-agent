---
pack_id: "bpc-sep26-v1"
local_id: "MCP-05"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1347"
summary: "Connect MCP evidence to the authorised lexical recommendation baseline"
assignee_key: "mayank"
assignee_display_name: "Mayank"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "recommendations"
create_by_default: false
planned_start: "2026-09-23"
planned_due: "2026-09-23"
dates_profile: "recommendations"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["MCP-02","MCP-03","MCP-04","CORE-04","CORE-08"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-mcp-05"
architecture_sections: ["engine","evaluation","security","read-contract"]
---

# Connect MCP evidence to the authorised lexical recommendation baseline

## Assignment and delivery window

- Accountable implementer: **Mayank**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1347**. Local reference **MCP-05** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **not scheduled; do not create by default**.
- Recommendation extension: **2026-09-23 → 2026-09-23 (D11–D11)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem and outcome

The shared lexical baseline needs an MCP-specific evidence adapter that returns truthful candidate states. It must not call MCP servers, infer unsupported capability, or treat a graph relationship as fit.

## Scope and contract

Consume CORE-08 authorised request/shortlist and current publication. Emit resolved MCP candidate references, source-backed evidence, lifecycle/freshness/conflict state, source-known prerequisites, eligibility/actionability, and shared coverage/truncation. Unknown material fields yield conditional, insufficient-evidence, or unassessed outcomes, not a negative fit. The baseline applies current authorisation at retrieval and serialisation.

## Steps

1. Map only MCP-01-approved source fields into CORE-08 candidate/evidence records.
2. Enforce current access/publication scope through CORE-04/08 seams.
3. Return evidence-linked eligible, conditional, insufficient-evidence, unassessed, unavailable, and ineligible outcomes.
4. Keep lexical ranking/completion in CORE-08; add no parallel MCP path.

## Acceptance and verification

- Authorised resolved MCPs return with evidence locators and publication lineage.
- Unknown required prerequisites remain conditional or insufficient-evidence, never silently actionable.
- Duplicate, unresolved, revoked, or out-of-scope records cannot leak as eligible suggestions or counts.
- No-eligible, complete lexical no-match, and dependency failure retain distinct CORE-08 semantics.
- No source fetch, credential handling, MCP execution, component attachment, or external endpoint occurs.

## Evidence, blockers and exclusions

Attach result examples for resolved, conditional, insufficient-evidence, duplicate, revoked/out-of-scope, and no-eligible cases. Block on CORE-08 or absent required source evidence. Embeddings, model assessment, graph boosts, UI, execution, and Hub MCP exposure are excluded.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [MCP-02](MCP-02.md) must finish its stated contract boundary before this task starts.
- [MCP-03](MCP-03.md) must finish its stated contract boundary before this task starts.
- [MCP-04](MCP-04.md) must finish its stated contract boundary before this task starts.
- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.
- [CORE-08](CORE-08.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `engine`, `evaluation`, `security`, `read-contract`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
