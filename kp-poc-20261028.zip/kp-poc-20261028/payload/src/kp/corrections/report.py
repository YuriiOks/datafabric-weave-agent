"""The per-spec report: citation rate, wrong-clause count and correction count (US-24)."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field
from sqlalchemy import Connection, case, func, select

from kp.domain import DomainModel
from kp.store import schema


class SpecReportRow(DomainModel):
    """One drafted spec with what its review shows.

    :ivar citation_rate: Rule statements that were cited and valid when the spec was published,
        over all rule statements; 1.0 for a spec without rule statements.
    :ivar wrong_clause_count: Corrections that fixed a wrongly cited clause.
    :ivar correction_count: All corrections, wrong-clause ones included.
    """

    spec_id: str
    story_key: str
    state: str
    rule_statements: Annotated[int, Field(ge=0)]
    valid_statements: Annotated[int, Field(ge=0)]
    citation_rate: Annotated[float, Field(ge=0, le=1)]
    wrong_clause_count: Annotated[int, Field(ge=0)]
    correction_count: Annotated[int, Field(ge=0)]


class CorrectionReport(DomainModel):
    """Every drafted spec's row and the totals over them."""

    specs: tuple[SpecReportRow, ...] = ()

    @property
    def correction_count(self) -> int:
        """Corrections over all specs."""
        return sum(row.correction_count for row in self.specs)

    @property
    def wrong_clause_count(self) -> int:
        """Wrong-clause corrections over all specs."""
        return sum(row.wrong_clause_count for row in self.specs)

    @property
    def citation_rate(self) -> float:
        """Valid rule statements over all rule statements of all specs; 1.0 when there are none."""
        total = sum(row.rule_statements for row in self.specs)
        return sum(row.valid_statements for row in self.specs) / total if total else 1.0


def build_report(connection: Connection) -> CorrectionReport:
    """Build the report from the specs, their citations and their corrections.

    :param connection: An open connection
    :return: One row per drafted spec, ordered by spec identity
    """
    return CorrectionReport(specs=tuple(_row(connection, spec) for spec in _specs(connection)))


def _specs(connection: Connection) -> list[tuple[str, str, str]]:
    table = schema.spec
    rows = connection.execute(
        select(table.c.spec_id, table.c.story_key, table.c.state).order_by(table.c.spec_id)
    )
    return [(row.spec_id, row.story_key, row.state) for row in rows]


def _row(connection: Connection, spec: tuple[str, str, str]) -> SpecReportRow:
    spec_id, story_key, state = spec
    citation = schema.citation
    valid = case(
        (
            (citation.c.reference.is_not(None))
            & citation.c.resolved
            & citation.c.retrieved_in_session,
            1,
        ),
        else_=0,
    )
    statements, valid_statements = connection.execute(
        select(func.count(), func.coalesce(func.sum(valid), 0)).where(
            citation.c.spec_id == spec_id, citation.c.is_rule_statement
        )
    ).one()
    correction = schema.spec_correction
    total, wrong = connection.execute(
        select(
            func.count(),
            func.coalesce(func.sum(case((correction.c.wrong_clause, 1), else_=0)), 0),
        ).where(correction.c.spec_id == spec_id)
    ).one()
    return SpecReportRow(
        spec_id=spec_id,
        story_key=story_key,
        state=state,
        rule_statements=statements,
        valid_statements=int(valid_statements),
        citation_rate=int(valid_statements) / statements if statements else 1.0,
        wrong_clause_count=int(wrong),
        correction_count=total,
    )


def format_report(report: CorrectionReport) -> str:
    """Write the report as a table for a terminal.

    :param report: The report
    :return: Multi-line text; says so when no spec has been drafted
    """
    if not report.specs:
        return "No drafted specs to report on."
    lines = [
        f"{'spec':<28} {'state':<8} {'citation rate':>13} {'wrong clause':>13} {'corrections':>12}"
    ]
    lines += [
        f"{row.spec_id:<28} {row.state:<8} {row.citation_rate:>13.0%} "
        f"{row.wrong_clause_count:>13} {row.correction_count:>12}"
        for row in report.specs
    ]
    lines.append(
        f"{'all specs':<28} {'':<8} {report.citation_rate:>13.0%} "
        f"{report.wrong_clause_count:>13} {report.correction_count:>12}"
    )
    return "\n".join(lines)
