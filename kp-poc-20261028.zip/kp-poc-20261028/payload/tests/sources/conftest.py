"""Fixtures of the source reader tests: a private, writable copy of the synthetic data."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from kp.testing.dataset import SyntheticDataset


@pytest.fixture
def data_root(dataset: SyntheticDataset, tmp_path: Path) -> Path:
    """A writable copy of the generated dataset, so a test can edit the sources."""
    target = tmp_path / "data"
    shutil.copytree(dataset.root, target)
    return target
