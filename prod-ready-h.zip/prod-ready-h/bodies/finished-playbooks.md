## What changed

A playbook page no longer shows the "Suggested components" block once the playbook is finished. A playbook counts as finished when its stage is Production, or when one of its governance requests is Closed Complete or at the Production stage. Every other playbook keeps the block as before, including one whose request is Closed Incomplete.

## Why

Suggesting reusable components only helps while a solution is still being built. On a delivered playbook the block is noise.

## How to verify

1. Open a playbook whose governance request is Open. The "Suggested components" block is shown.
2. Open a playbook whose governance request is Closed Complete. The block is not shown; the rest of the page is unchanged.
3. Open a playbook whose stage is Production. The block is not shown.
4. Negative case: open a playbook whose governance request is Closed Incomplete. The block is still shown.

## Review focus

- The rule in `isFinishedPlaybook`: exact, case-insensitive matches only, so a combined stage such as "Pilot/Production" does not count as Production.
- One Closed Complete request is enough to hide the block, even when the playbook has other requests.
