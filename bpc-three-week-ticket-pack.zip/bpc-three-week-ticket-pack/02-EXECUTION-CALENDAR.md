# Execution calendar

User-confirmed start: 9 September 2026; planned three-week window: 9–29 September; timezone Europe/London. Fifteen weekdays, six focused engineering hours per person per day. The start date is user-confirmed; per-person availability and reuse assumptions still require reconciliation. Choose one entire profile; do not combine rows across profiles. Slots are cumulative focus-hour offsets from day 1 (0–90), not clock times. A task can cross days; weekends are omitted. Finish-to-start links and each person’s exclusive focus slots are validated.

## foundation: Graph, refresh and existing Hub AI

26 subtasks; 134 estimated engineering hours; scheduled finish 2026-09-28. Final-chain slack to the three-week window end (29 September): 11 focus-hour slots; to the parent deadline (30 September): 17 slots. This is not the sum of unused team hours and cannot be redistributed freely across dependencies.

| Local ID | Assignee | Hours | Start | Due | Day / slot | Predecessors |
|---|---|---:|---|---|---|---|
| [CORE-01](subtasks/CORE-01.md) | Yurii | 4 | 2026-09-09 | 2026-09-09 | D1–D1; 0–4 | — |
| [CORE-02](subtasks/CORE-02.md) | Yurii | 4 | 2026-09-09 | 2026-09-10 | D1–D2; 4–8 | CORE-01 |
| [MCP-01](subtasks/MCP-01.md) | Mayank | 4 | 2026-09-09 | 2026-09-10 | D1–D2; 4–8 | CORE-01 |
| [CORE-03](subtasks/CORE-03.md) | Yurii | 6 | 2026-09-10 | 2026-09-11 | D2–D3; 8–14 | CORE-02 |
| [MCP-02](subtasks/MCP-02.md) | Mayank | 6 | 2026-09-10 | 2026-09-11 | D2–D3; 8–14 | MCP-01, CORE-02 |
| [SKL-01](subtasks/SKL-01.md) | Mayank | 4 | 2026-09-11 | 2026-09-11 | D3–D3; 14–18 | CORE-01 |
| [MCP-03](subtasks/MCP-03.md) | Yurii | 6 | 2026-09-11 | 2026-09-14 | D3–D4; 14–20 | MCP-01, MCP-02, CORE-02, CORE-03 |
| [SKL-02](subtasks/SKL-02.md) | Mayank | 6 | 2026-09-14 | 2026-09-14 | D4–D4; 18–24 | SKL-01, CORE-02 |
| [CORE-04](subtasks/CORE-04.md) | Yurii | 10 | 2026-09-14 | 2026-09-15 | D4–D5; 20–30 | CORE-03 |
| [AGT-01](subtasks/AGT-01.md) | Mayank | 5 | 2026-09-15 | 2026-09-15 | D5–D5; 24–29 | CORE-01 |
| [CORE-06](subtasks/CORE-06.md) | Mayank | 6 | 2026-09-15 | 2026-09-16 | D5–D6; 29–35 | CORE-02 |
| [AGT-02](subtasks/AGT-02.md) | Yurii | 6 | 2026-09-16 | 2026-09-16 | D6–D6; 30–36 | AGT-01, CORE-02, CORE-03 |
| [CORE-13](subtasks/CORE-13.md) | Mayank | 6 | 2026-09-16 | 2026-09-17 | D6–D7; 35–41 | CORE-02 |
| [SKL-03](subtasks/SKL-03.md) | Yurii | 6 | 2026-09-17 | 2026-09-17 | D7–D7; 36–42 | SKL-02, CORE-02, CORE-03, MCP-03 |
| [AGT-03](subtasks/AGT-03.md) | Mayank | 6 | 2026-09-18 | 2026-09-18 | D8–D8; 42–48 | AGT-01, AGT-02, CORE-03, CORE-04, SKL-03, MCP-03 |
| [SKL-04](subtasks/SKL-04.md) | Yurii | 6 | 2026-09-18 | 2026-09-18 | D8–D8; 42–48 | SKL-02, SKL-03, CORE-03, CORE-04 |
| [CORE-07](subtasks/CORE-07.md) | Yurii | 6 | 2026-09-21 | 2026-09-21 | D9–D9; 48–54 | CORE-02 |
| [MCP-04](subtasks/MCP-04.md) | Mayank | 5 | 2026-09-21 | 2026-09-21 | D9–D9; 48–53 | MCP-02, MCP-03, CORE-03, CORE-04, SKL-04, AGT-03 |
| [AGT-04](subtasks/AGT-04.md) | Mayank | 5 | 2026-09-21 | 2026-09-22 | D9–D10; 53–58 | AGT-02, AGT-03, CORE-04, CORE-06 |
| [CORE-05](subtasks/CORE-05.md) | Yurii | 5 | 2026-09-22 | 2026-09-22 | D10–D10; 54–59 | CORE-02 |
| [CORE-11](subtasks/CORE-11.md) | Yurii | 6 | 2026-09-22 | 2026-09-23 | D10–D11; 59–65 | CORE-07 |
| [CORE-12](subtasks/CORE-12.md) | Yurii | 4 | 2026-09-23 | 2026-09-24 | D11–D12; 65–69 | CORE-07 |
| [CORE-15](subtasks/CORE-15.md) | Yurii | 3 | 2026-09-24 | 2026-09-24 | D12–D12; 69–72 | CORE-04, CORE-05, CORE-13, SKL-04, MCP-04, AGT-03, CORE-06 |
| [CORE-09](subtasks/CORE-09.md) | Yurii | 6 | 2026-09-25 | 2026-09-25 | D13–D13; 72–78 | CORE-04, CORE-05, CORE-06, CORE-07, CORE-11, CORE-12, SKL-04, MCP-04, AGT-04, CORE-13, CORE-15 |
| [CORE-14](subtasks/CORE-14.md) | Mayank | 2 | 2026-09-25 | 2026-09-25 | D13–D13; 72–74 | CORE-05, CORE-06, CORE-13, SKL-04, MCP-04, AGT-04, CORE-15 |
| [CORE-10](subtasks/CORE-10.md) | Mayank | 1 | 2026-09-28 | 2026-09-28 | D14–D14; 78–79 | CORE-09, CORE-14 |

## recommendations: Add the three-type lexical baseline

31 subtasks; 165 estimated engineering hours; scheduled finish 2026-09-29. Final-chain slack to the three-week window end (29 September): 0 focus-hour slots; to the parent deadline (30 September): 6 slots. This is not the sum of unused team hours and cannot be redistributed freely across dependencies.

| Local ID | Assignee | Hours | Start | Due | Day / slot | Predecessors |
|---|---|---:|---|---|---|---|
| [CORE-01](subtasks/CORE-01.md) | Yurii | 4 | 2026-09-09 | 2026-09-09 | D1–D1; 0–4 | — |
| [CORE-02](subtasks/CORE-02.md) | Yurii | 4 | 2026-09-09 | 2026-09-10 | D1–D2; 4–8 | CORE-01 |
| [MCP-01](subtasks/MCP-01.md) | Mayank | 4 | 2026-09-09 | 2026-09-10 | D1–D2; 4–8 | CORE-01 |
| [CORE-03](subtasks/CORE-03.md) | Yurii | 6 | 2026-09-10 | 2026-09-11 | D2–D3; 8–14 | CORE-02 |
| [MCP-02](subtasks/MCP-02.md) | Mayank | 6 | 2026-09-10 | 2026-09-11 | D2–D3; 8–14 | MCP-01, CORE-02 |
| [SKL-01](subtasks/SKL-01.md) | Mayank | 4 | 2026-09-11 | 2026-09-11 | D3–D3; 14–18 | CORE-01 |
| [MCP-03](subtasks/MCP-03.md) | Yurii | 6 | 2026-09-11 | 2026-09-14 | D3–D4; 14–20 | MCP-01, MCP-02, CORE-02, CORE-03 |
| [SKL-02](subtasks/SKL-02.md) | Mayank | 6 | 2026-09-14 | 2026-09-14 | D4–D4; 18–24 | SKL-01, CORE-02 |
| [CORE-04](subtasks/CORE-04.md) | Yurii | 10 | 2026-09-14 | 2026-09-15 | D4–D5; 20–30 | CORE-03 |
| [AGT-01](subtasks/AGT-01.md) | Mayank | 5 | 2026-09-15 | 2026-09-15 | D5–D5; 24–29 | CORE-01 |
| [CORE-06](subtasks/CORE-06.md) | Mayank | 6 | 2026-09-15 | 2026-09-16 | D5–D6; 29–35 | CORE-02 |
| [AGT-02](subtasks/AGT-02.md) | Yurii | 6 | 2026-09-16 | 2026-09-16 | D6–D6; 30–36 | AGT-01, CORE-02, CORE-03 |
| [CORE-13](subtasks/CORE-13.md) | Mayank | 6 | 2026-09-16 | 2026-09-17 | D6–D7; 35–41 | CORE-02 |
| [SKL-03](subtasks/SKL-03.md) | Yurii | 6 | 2026-09-17 | 2026-09-17 | D7–D7; 36–42 | SKL-02, CORE-02, CORE-03, MCP-03 |
| [CORE-07](subtasks/CORE-07.md) | Yurii | 6 | 2026-09-18 | 2026-09-18 | D8–D8; 42–48 | CORE-02 |
| [AGT-03](subtasks/AGT-03.md) | Mayank | 6 | 2026-09-18 | 2026-09-18 | D8–D8; 42–48 | AGT-01, AGT-02, CORE-03, CORE-04, SKL-03, MCP-03 |
| [SKL-04](subtasks/SKL-04.md) | Yurii | 6 | 2026-09-21 | 2026-09-21 | D9–D9; 48–54 | SKL-02, SKL-03, CORE-03, CORE-04 |
| [AGT-04](subtasks/AGT-04.md) | Mayank | 5 | 2026-09-21 | 2026-09-21 | D9–D9; 48–53 | AGT-02, AGT-03, CORE-04, CORE-06 |
| [CORE-08](subtasks/CORE-08.md) | Yurii | 6 | 2026-09-22 | 2026-09-22 | D10–D10; 54–60 | CORE-03, CORE-07 |
| [MCP-04](subtasks/MCP-04.md) | Mayank | 5 | 2026-09-22 | 2026-09-22 | D10–D10; 54–59 | MCP-02, MCP-03, CORE-03, CORE-04, SKL-04, AGT-03 |
| [MCP-05](subtasks/MCP-05.md) | Mayank | 6 | 2026-09-23 | 2026-09-23 | D11–D11; 60–66 | MCP-02, MCP-03, MCP-04, CORE-04, CORE-08 |
| [CORE-05](subtasks/CORE-05.md) | Yurii | 5 | 2026-09-23 | 2026-09-23 | D11–D11; 60–65 | CORE-02 |
| [CORE-11](subtasks/CORE-11.md) | Yurii | 6 | 2026-09-23 | 2026-09-24 | D11–D12; 65–71 | CORE-07 |
| [SKL-05](subtasks/SKL-05.md) | Mayank | 8 | 2026-09-24 | 2026-09-25 | D12–D13; 66–74 | SKL-04, CORE-04, CORE-07, CORE-08 |
| [MCP-06](subtasks/MCP-06.md) | Yurii | 5 | 2026-09-24 | 2026-09-25 | D12–D13; 71–76 | MCP-05, CORE-07 |
| [AGT-05](subtasks/AGT-05.md) | Mayank | 6 | 2026-09-25 | 2026-09-28 | D13–D14; 74–80 | AGT-02, AGT-03, CORE-07, CORE-08 |
| [CORE-12](subtasks/CORE-12.md) | Yurii | 4 | 2026-09-25 | 2026-09-28 | D13–D14; 76–80 | CORE-07 |
| [CORE-15](subtasks/CORE-15.md) | Yurii | 3 | 2026-09-28 | 2026-09-28 | D14–D14; 80–83 | CORE-04, CORE-05, CORE-13, SKL-04, MCP-04, AGT-03, CORE-06 |
| [CORE-09](subtasks/CORE-09.md) | Yurii | 6 | 2026-09-28 | 2026-09-29 | D14–D15; 83–89 | CORE-04, CORE-05, CORE-06, CORE-07, CORE-11, CORE-12, SKL-04, MCP-04, AGT-04, CORE-13, CORE-15, CORE-08, SKL-05, MCP-06, AGT-05 |
| [CORE-14](subtasks/CORE-14.md) | Mayank | 2 | 2026-09-28 | 2026-09-29 | D14–D15; 83–85 | CORE-05, CORE-06, CORE-13, SKL-04, MCP-04, AGT-04, CORE-15 |
| [CORE-10](subtasks/CORE-10.md) | Mayank | 1 | 2026-09-29 | 2026-09-29 | D15–D15; 89–90 | CORE-09, CORE-14 |

## Calendar changes

The user selected 9 September. Do not revert to an earlier proposed start or re-ask this supplied preference. If availability changes, recalculate every task, check dependencies/owner overlap and regenerate all issue dates together before import. Preserve the live parent deadline unless the user explicitly changes it. If the graph no longer fits, show the missing capacity or changed scope instead of compressing estimates.
