"""Guessed links for register rows and rules that no source ties together."""

from __future__ import annotations

from sqlalchemy import select

from kp.adapters.guessing import LinkGuesser
from kp.domain import LinkKind, LinkState, Relation
from kp.store import schema
from world_support import World

UNLINKED_ROWS = {"requirements-register:Requirements:14", "requirements-register:Requirements:15"}


def test_unlinked_pairs_are_scored_and_only_the_review_band_is_kept(built_world: World) -> None:
    after = built_world.build.after_sweep

    assert after.proposed == 0
    assert after.review > 0
    assert after.dropped > after.review
    assert after.share_within_limit


def test_review_links_carry_a_score_and_evidence_and_are_never_in_use(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        rows = connection.execute(
            select(schema.link).where(schema.link.c.kind == LinkKind.GUESSED.value)
        ).all()

    assert rows
    for row in rows:
        assert row.state == LinkState.REVIEW.value
        assert 0.55 <= row.score < 0.75
        assert row.evidence


def test_a_row_with_a_stated_rule_is_not_guessed(built_world: World) -> None:
    with built_world.application.database.transaction() as connection:
        reports = LinkGuesser(
            connection,
            thresholds=built_world.settings.thresholds,
            clock=built_world.application.clock,
        ).guess()
        sources = {
            row.source_key
            for row in connection.execute(
                select(schema.link).where(
                    schema.link.c.kind == LinkKind.GUESSED.value,
                    schema.link.c.relation == Relation.CONSTRAINED_BY.value,
                )
            )
        }

    assert len(reports) == 1  # no schema fields given: register rows to rules only
    assert sources <= UNLINKED_ROWS
