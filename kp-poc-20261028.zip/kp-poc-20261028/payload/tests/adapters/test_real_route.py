"""Real mode is configuration: gateway readers, the raw bucket, swept code links, no DDL."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest
from pydantic import SecretStr
from sqlalchemy import func, select
from sqlalchemy.exc import OperationalError

from kp.adapters.code_checkout import swept_code_checkout
from kp.adapters.raw_store import ObjectRawStore, choose_raw_store
from kp.adapters.real_route import RealRoute, real_reader_builders
from kp.app import build_application
from kp.clock import FixedClock
from kp.config import Mode, Settings
from kp.connectivity.fake_gateway import (
    FAKE_BASE_URL,
    FAKE_CLIENT_ID,
    FAKE_CLIENT_SECRET,
    FAKE_EXTRACTION_URL,
    FAKE_TOKEN_URL,
    LOCAL_IDENTITY_HEADER,
    LOCAL_SOURCE_CREDENTIAL,
    LOCAL_SOURCE_HEADER,
    FakeGateway,
)
from kp.connectivity.storage import LocalObjectStore
from kp.domain import ItemKey, SourceKind
from kp.errors import ConfigurationError
from kp.store import Database, create_engine_for_url, schema
from kp.store.engine import IN_MEMORY_SQLITE
from kp.sweep import RawStoreConflictError
from world_support import World


def _real_settings(tmp_path: Path, **overrides: object) -> Settings:
    """Real-mode settings; the database stays in memory because the tests carry no PostgreSQL."""
    values: dict[str, object] = {
        "gateway_base_url": FAKE_BASE_URL,
        "gateway_token_url": FAKE_TOKEN_URL,
        "gateway_client_id": FAKE_CLIENT_ID,
        "gateway_client_secret": SecretStr(FAKE_CLIENT_SECRET),
        "gateway_token_header": LOCAL_IDENTITY_HEADER,
        "source_token_header": LOCAL_SOURCE_HEADER,
        "source_token_confluence": SecretStr(LOCAL_SOURCE_CREDENTIAL),
        "source_token_jira": SecretStr(LOCAL_SOURCE_CREDENTIAL),
        "source_token_github": SecretStr(LOCAL_SOURCE_CREDENTIAL),
        "use_case_id": "case",
        "tool_namespace_confluence": "confluence",
        "tool_namespace_jira": "jira",
        "tool_namespace_github": "github",
        "extraction_base_url": FAKE_EXTRACTION_URL,
        "raw_bucket": "raw-bucket",
        "markdown_bucket": "markdown-bucket",
        "spec_repo": "example-org/example-specs",
        "spec_path": "specs",
        "jira_fields_allowed": ("status", "spec_link"),
        "data_dir": tmp_path / "var",
    }
    values.update(overrides)
    local = Settings(
        _env_file=None,
        mode=Mode.LOCAL,
        database_url=SecretStr(IN_MEMORY_SQLITE),
        **values,  # type: ignore[arg-type]  # keyword overrides of typed settings
    )
    return local.model_copy(update={"mode": Mode.REAL})


def test_real_mode_sweeps_the_gateway_sources_and_keeps_the_bytes_in_the_raw_store(
    tmp_path: Path, fixed_clock: FixedClock
) -> None:
    settings = _real_settings(tmp_path)
    gateway = FakeGateway(
        fixed_clock, identity_header=LOCAL_IDENTITY_HEADER, source_header=LOCAL_SOURCE_HEADER
    )
    route = RealRoute(settings, fixed_clock, http=httpx.Client(transport=gateway.transport()))
    raw_bucket = LocalObjectStore(tmp_path / "raw-bucket")
    database = Database(create_engine_for_url(IN_MEMORY_SQLITE))
    database.create_all()  # what `kp init-db` does; real mode never does it on its own
    application = build_application(
        settings,
        clock=fixed_clock,
        database=database,
        real_builders=real_reader_builders(route),
        raw_store=ObjectRawStore(raw_bucket),
    )
    try:
        # The tracker's sample issue is not shaped like a story export, so it is left out here:
        # which shape the real tracker tool answers with is what the first live discover shows.
        summary = application.sweep([SourceKind.CONFLUENCE, SourceKind.GITHUB])
        with database.transaction() as connection:
            stored = connection.execute(
                select(schema.source_item.c.source, schema.source_item.c.raw_location)
            ).all()
    finally:
        application.close()
        route.close()
        database.dispose()

    assert summary.outcome.value == "succeeded"
    assert summary.versions_recorded == 6  # the sample items of those two sources
    assert {row.source for row in stored} == {"confluence", "github"}
    assert all(raw_bucket.exists(raw_bucket.key_of(row.raw_location)) for row in stored)


def test_real_mode_without_a_reader_builder_builds_the_gateway_readers_from_the_settings(
    tmp_path: Path,
) -> None:
    application = build_application(
        _real_settings(tmp_path), database=Database(create_engine_for_url(IN_MEMORY_SQLITE))
    )
    try:
        targets = application.targets.targets([SourceKind.JIRA])
    finally:
        application.close()

    assert [target.reader.kind for target in targets] == [SourceKind.JIRA]


def test_real_mode_names_the_source_token_it_lacks_instead_of_failing_later(
    tmp_path: Path,
) -> None:
    settings = _real_settings(tmp_path, source_token_github=None)
    application = build_application(
        settings, database=Database(create_engine_for_url(IN_MEMORY_SQLITE))
    )
    try:
        with pytest.raises(ConfigurationError, match="KP_SOURCE_TOKEN_GITHUB"):
            application.targets.targets([SourceKind.CONFLUENCE])
    finally:
        application.close()


def test_real_mode_never_creates_tables_on_its_own(tmp_path: Path, fixed_clock: FixedClock) -> None:
    settings = _real_settings(tmp_path)
    gateway = FakeGateway(
        fixed_clock, identity_header=LOCAL_IDENTITY_HEADER, source_header=LOCAL_SOURCE_HEADER
    )
    route = RealRoute(settings, fixed_clock, http=httpx.Client(transport=gateway.transport()))
    database = Database(create_engine_for_url(IN_MEMORY_SQLITE))
    application = build_application(
        settings,
        clock=fixed_clock,
        database=database,
        real_builders=real_reader_builders(route),
        raw_store=ObjectRawStore(LocalObjectStore(tmp_path / "raw-bucket")),
    )
    try:
        with pytest.raises(OperationalError):
            application.sweep([SourceKind.CONFLUENCE])
    finally:
        application.close()
        route.close()
        database.dispose()


def test_the_raw_store_is_the_bucket_in_real_mode_and_a_folder_otherwise(tmp_path: Path) -> None:
    bucket = LocalObjectStore(tmp_path / "bucket")

    assert isinstance(choose_raw_store(_real_settings(tmp_path), bucket), ObjectRawStore)
    local = choose_raw_store(Settings(_env_file=None, mode=Mode.LOCAL, data_dir=tmp_path / "var"))
    key = ItemKey(source=SourceKind.JIRA, item_id="PAY-1", version="1")
    assert (tmp_path / "var" / "raw" / local.put(key, b"x")).read_bytes() == b"x"


def test_real_mode_without_a_raw_bucket_says_so(tmp_path: Path) -> None:
    settings = _real_settings(tmp_path).model_copy(update={"raw_bucket": None})

    with pytest.raises(ConfigurationError, match="KP_RAW_BUCKET"):
        choose_raw_store(settings)


def test_the_object_raw_store_writes_once_and_reads_back_by_location(tmp_path: Path) -> None:
    store = ObjectRawStore(LocalObjectStore(tmp_path / "bucket"))
    key = ItemKey(source=SourceKind.GITHUB, item_id="src/a.py", version="abc")

    location = store.put(key, b"one")

    assert store.put(key, b"one") == location
    assert store.get(location) == b"one"
    with pytest.raises(RawStoreConflictError):
        store.put(key, b"two")


def test_the_code_checkout_is_rebuilt_from_the_swept_items(built_world: World) -> None:
    application = built_world.application
    with application.database.transaction() as connection:
        with swept_code_checkout(connection, application.raw_store) as root:
            assert root is not None
            text = (root / "src" / "payments" / "inbound.py").read_text(encoding="utf-8")
            assert (root / "tests" / "test_inbound.py").is_file()
        count = connection.execute(select(func.count()).select_from(schema.source_item)).scalar()

    assert "def validate_currency" in text
    assert count


def test_the_links_after_a_sweep_need_no_checkout_folder(
    built_world: World, tmp_path: Path
) -> None:
    """Real mode has no folder: the code links are read from what the sweep stored."""
    world = built_world
    application = build_application(
        world.settings.model_copy(update={"code_repo_path": None, "data_dir": tmp_path / "other"}),
        clock=world.application.clock,
        database=world.application.database,
        raw_store=world.application.raw_store,
    )

    report = application.after_sweep()

    assert report.repository is not None
    assert report.repository.unchanged >= 3  # test, schema and implemented-by links of the build
    assert (report.repository.opened, report.repository.closed) == (0, 0)
