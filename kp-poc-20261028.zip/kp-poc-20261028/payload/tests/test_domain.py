"""Domain rules that are shared by several lanes."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from kp.domain import (
    DETAIL_NAMES,
    EMBEDDING_DIMENSIONS,
    CheckResult,
    CheckSeverity,
    Citation,
    DocumentDetails,
    ItemRef,
    ItemType,
    KnowledgeVersion,
    Link,
    LinkKind,
    LinkState,
    Passage,
    PassageType,
    Relation,
    SourceKind,
    Story,
    StoryLink,
)

NOW = datetime(2026, 11, 1, tzinfo=UTC)


def _story(**overrides: object) -> Story:
    values: dict[str, object] = {
        "story_key": "PAY-1",
        "version": "1",
        "summary": "Accept currencies",
        "description": "Rule: 2026.1 clause 4.2.1",
        "acceptance_criteria": "Given X then Y",
        "links": (StoryLink(link_type="implements", target_key="REQ-1"),),
        "parent_key": "PAY-0",
        "status": "To Do",
    }
    return Story.model_validate(values | overrides)


def test_story_status_change_does_not_change_the_fingerprint() -> None:
    assert _story().fingerprint() == _story(status="In Progress", version="2").fingerprint()


@pytest.mark.parametrize(
    "change",
    [
        {"acceptance_criteria": "Given X then Z"},
        {"summary": "Other"},
        {"description": "Other"},
        {"parent_key": "PAY-9"},
        {"links": ()},
    ],
)
def test_story_content_change_changes_the_fingerprint(change: dict[str, object]) -> None:
    assert _story().fingerprint() != _story(**change).fingerprint()


def test_story_fingerprint_ignores_link_order_and_surrounding_whitespace() -> None:
    a = StoryLink(link_type="implements", target_key="REQ-1")
    b = StoryLink(link_type="relates to", target_key="PAY-2")

    assert (
        _story(links=(a, b)).fingerprint()
        == _story(links=(b, a), summary="  Accept currencies ").fingerprint()
    )


def test_relation_with_several_endpoint_pairs() -> None:
    assert Relation.DERIVED_FROM.allows(ItemType.SPEC, ItemType.REQUIREMENT)
    assert Relation.DERIVED_FROM.allows(ItemType.SPEC, ItemType.CLAUSE)
    assert not Relation.DERIVED_FROM.allows(ItemType.SPEC, ItemType.TEST)
    assert not Relation.DERIVED_FROM.allows(ItemType.CLAUSE, ItemType.SPEC)


def test_there_are_seven_relations_and_eight_item_types() -> None:
    assert len(Relation) == 7
    assert len(ItemType) == 8


def _link(**overrides: object) -> Link:
    values: dict[str, object] = {
        "link_id": "l1",
        "source_ref": ItemRef(item_type=ItemType.REQUIREMENT, key="REQ-1"),
        "relation": Relation.CONSTRAINED_BY,
        "target_ref": ItemRef(item_type=ItemType.CLAUSE, key="2026.1:4.2.1"),
        "kind": LinkKind.STATED,
        "state": LinkState.STATED,
        "valid_from": NOW,
    }
    return Link.model_validate(values | overrides)


def test_valid_stated_link_is_open_until_closed() -> None:
    link = _link()

    assert link.is_open
    assert not _link(valid_to=NOW).is_open


def test_link_must_follow_the_relation_model() -> None:
    with pytest.raises(ValidationError, match="cannot connect"):
        _link(relation=Relation.VERIFIED_BY)


def test_stated_and_guessed_links_have_consistent_state_and_score() -> None:
    with pytest.raises(ValidationError):
        _link(score=0.9)
    with pytest.raises(ValidationError):
        _link(kind=LinkKind.GUESSED, state=LinkState.STATED, score=0.9)
    with pytest.raises(ValidationError):
        _link(kind=LinkKind.GUESSED, state=LinkState.PROPOSED)
    guessed = _link(kind=LinkKind.GUESSED, state=LinkState.PROPOSED, score=0.8)
    assert guessed.score == 0.8


def test_link_validity_period_cannot_run_backwards() -> None:
    with pytest.raises(ValidationError):
        _link(valid_to=datetime(2026, 10, 1, tzinfo=UTC))


def test_document_details_report_missing_required_details() -> None:
    details = DocumentDetails(document_type="guide", domain="payments", content_owner="  ")

    assert details.missing() == ("authority", "classification", "content_owner")
    assert not details.is_complete
    assert DocumentDetails(**dict.fromkeys(DETAIL_NAMES, "x")).is_complete


def _passage(**overrides: object) -> Passage:
    values: dict[str, object] = {
        "passage_id": "p1",
        "passage_type": PassageType.CLAUSE,
        "parent_ref": "2026.1:4.2.1",
        "source": SourceKind.REGULATORY_REPO,
        "item_id": "rulebook",
        "version": "2026.1",
        "text": "x",
        "tokens": 1,
    }
    return Passage.model_validate(values | overrides)


def test_passage_embedding_and_model_version_come_together() -> None:
    vector = tuple([0.0] * EMBEDDING_DIMENSIONS)

    assert _passage(embedding=vector, model_version="m1").model_version == "m1"
    with pytest.raises(ValidationError):
        _passage(embedding=vector)
    with pytest.raises(ValidationError):
        _passage(embedding=(0.1, 0.2), model_version="m1")


def test_domain_models_are_immutable_and_reject_unknown_fields() -> None:
    story = _story()

    with pytest.raises(ValidationError):
        story.status = "Done"  # type: ignore[misc]  # deliberate: frozen model
    with pytest.raises(ValidationError):
        _story(unexpected=1)


def test_knowledge_version_lists_only_failed_blocking_checks() -> None:
    version = KnowledgeVersion(
        version_id="kv1",
        run_id="r1",
        created_at=NOW,
        checks=(
            CheckResult(name="conformance", severity=CheckSeverity.BLOCKING, passed=True),
            CheckResult(name="guessed_share", severity=CheckSeverity.BLOCKING, passed=False),
            CheckResult(name="no_links", severity=CheckSeverity.WARNING, passed=False),
        ),
    )

    assert [c.name for c in version.blocking_failures()] == ["guessed_share"]


def _citation(**overrides: object) -> Citation:
    values: dict[str, object] = {
        "citation_id": "c1",
        "spec_id": "s1",
        "statement_index": 0,
        "statement": "Must reject.",
        "is_rule_statement": True,
    }
    return Citation.model_validate(values | overrides)


def test_citation_is_valid_only_when_cited_resolved_and_retrieved() -> None:
    cited = {"reference": "2026.1:4.2.1", "resolved": True}

    assert not _citation().is_valid
    assert not _citation(**cited).is_valid
    assert _citation(**cited, retrieved_in_session=True).is_valid
