"""Seam: the sweep's content-processor port, backed by ingest, search indexing and link loading.

For every admitted item version the sweep hands over, this processor runs the parser that fits
(:mod:`kp.ingest`), builds the passages of what was stored (:mod:`kp.search`) and loads the
links the item states about itself (:mod:`kp.links`), all on the page's connection. So a page,
its parsed content, its passages, its links and its cursor commit together or not at all.

Story versions that differ only in status are recognised by the Story fingerprint (shared
contract 5): the sweep calls :meth:`PipelineProcessor.fingerprint` and does no rework when it is
unchanged.
"""

from __future__ import annotations

import logging

from sqlalchemy import Connection

from kp.adapters.stated_links import StatedLinkLoader
from kp.clock import Clock
from kp.config import Thresholds
from kp.domain import SourceItemVersion, SourceKind
from kp.ingest.processor import IngestProcessor, ProcessingOutcome, ProcessingResult
from kp.ingest.sweep_adapter import SweepContentProcessor
from kp.search.embedding import Embedder, embed_pending
from kp.search.indexing import index_clauses, index_requirements, index_stories
from kp.sources.base import FetchedItem, ItemMetadata

logger = logging.getLogger(__name__)


class PipelineProcessor:
    """Parses, indexes and links one admitted item version.

    :param thresholds: Structure, header and link thresholds from the settings
    :param clock: Time source for review items and link validity
    :param accept_review_band: Store rulebooks whose structure score is in the review band
        without waiting for a person (a local-mode override; see :class:`IngestProcessor`)
    :param embedder: The vector side's embedder; when given, passages without a vector from its
        model are embedded after every processed item, so the vector side has something to rank
    :param embedding_batch_size: Largest batch sent to the embedder
    """

    def __init__(
        self,
        thresholds: Thresholds,
        clock: Clock,
        *,
        accept_review_band: bool = False,
        embedder: Embedder | None = None,
        embedding_batch_size: int = 96,
    ) -> None:
        self._thresholds = thresholds
        self._clock = clock
        self._embedder = embedder
        self._embedding_batch_size = embedding_batch_size
        self._ingest = IngestProcessor(thresholds, clock, accept_review_band=accept_review_band)
        self._fingerprints = SweepContentProcessor(self._ingest)

    def fingerprint(self, version: SourceItemVersion, content: bytes) -> str | None:
        """Hash the parts of the content whose change means rework.

        :param version: The version being considered
        :param content: Its raw bytes
        :return: The story-export fingerprint for tracker JSON (status ignored); ``None`` for
            everything else, so every new version of those is work
        """
        return self._fingerprints.fingerprint(version, content)

    def process(self, connection: Connection, version: SourceItemVersion, content: bytes) -> None:
        """Process one admitted version inside the sweep's page transaction.

        :param connection: The page's open connection
        :param version: The admitted version
        :param content: Its raw bytes
        :raises kp.ingest.errors.IngestError: If the content is unreadable or conflicts with
            what is stored
        """
        fetched = FetchedItem(
            key=version.key,
            content=content,
            metadata=ItemMetadata(
                native_id=version.native_id, media_type=version.media_type, title=version.title
            ),
        )
        result = self._ingest.process(version, fetched, connection)
        if result.outcome is not ProcessingOutcome.PROCESSED:
            return
        links = StatedLinkLoader(connection, thresholds=self._thresholds, clock=self._clock)
        if version.source is SourceKind.REGULATORY_REPO:
            self._after_rulebook(connection, links)
        elif version.source is SourceKind.JIRA:
            self._after_stories(connection, links, result)
        elif result.requirements_stored:
            index_requirements(connection)
            links.sync_register()
        if self._embedder is not None:
            embed_pending(connection, self._embedder, self._embedding_batch_size)
        logger.info(
            "Item indexed and linked",
            extra={"source": version.source.value, "item_id": version.item_id},
        )

    @staticmethod
    def _after_rulebook(connection: Connection, links: StatedLinkLoader) -> None:
        index_clauses(connection)
        # A register swept before the rulebook cited clauses that were not loaded yet.
        links.sync_register()

    @staticmethod
    def _after_stories(
        connection: Connection, links: StatedLinkLoader, result: ProcessingResult
    ) -> None:
        keys = result.stories_to_reprocess
        if not keys:
            return
        index_stories(connection, keys)
        links.sync_stories(keys)
