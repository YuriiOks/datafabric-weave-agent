---
pack_id: "bpc-sep26-v1"
local_id: "SKL-03"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1169"
summary: "Resolve Skill aliases and declared dependency endpoints through the shared oracle"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-17"
planned_due: "2026-09-17"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["SKL-02","CORE-02","CORE-03","MCP-03"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-skl-03"
architecture_sections: ["model","identity","ingestion","validation-gates"]
---

# Resolve Skill aliases and declared dependency endpoints through the shared oracle

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1169**. Local reference **SKL-03** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-17 → 2026-09-17 (D7–D7)**.
- Recommendation extension: **2026-09-17 → 2026-09-17 (D7–D7)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

A Skill can be known by directory name, declared name and portal ID, while dependency metadata names targets without stable addresses. Apply the shared identity oracle to Skills so all accepted identities and declared relationships are evidence-backed and every ambiguous target remains visible.

## Scope

Configure the Skills-specific mapping inputs and review workflow for the CORE-03 oracle. Compare directory aliases, declared-name aliases and approved workbook portal identifiers only within the authorised source scope and environment. Resolve explicit Skill dependencies and allowed-MCP declarations only when the oracle can evidence their endpoints in the same catalogue scope.

## Boundaries, inputs and outputs

Inputs are SKL-02 occurrences and claims, the approved workbook mapping evidence, CORE-02 identity rules and CORE-03 oracle. Outputs are Skill identity assertions, alias and conflict records, endpoint-resolution records, unresolved-reference diagnostics and reviewer decisions. The shared oracle owns durable IDs and policy; this task must not create a second canonical-ID rule.

## Technical steps

1. Submit directory name and declared name as scoped aliases with separate evidence anchors; submit workbook IDs only from approved, matching workbook evidence.
2. Classify each proposed identity assertion as exact, ambiguous, conflicting, unbound or stale according to the shared oracle contract.
3. Send metadata dependency Skill names to exact scoped target resolution and record every accepted match with declaration evidence and resolution method.
4. Send allowed-MCP names only through the approved MCP identity mapping. Where no exact server identity exists, retain an unresolved declaration instead of creating an edge.
5. Preserve allowed-tools and tools as non-server declarations unless another approved source makes an explicit, separately evidenced tool-to-server assertion.
6. Provide a reviewer queue for alias collisions, folder/name disagreement, duplicate names and cross-environment mismatches; retain the decision and evidence used.

## Acceptance criteria

- [ ] Each Skill alias and workbook portal assertion is resolved, unbound, ambiguous, conflicting or stale with a source anchor and explanation.
- [ ] No directory name, display name or fuzzy string match independently creates a portal identity or canonical Skill identity.
- [ ] Every published candidate dependency endpoint has exact scoped resolution evidence; all other declarations remain unresolved diagnostics.
- [ ] A resolved declaration is labelled as a source fact only and carries no authorisation, execution, maturity or recommendation-suitability meaning.
- [ ] Alias review decisions are reproducible against the pinned source and workbook snapshots.

## Meaningful verification cases

- A directory/name mismatch requires an explicit alias decision rather than an implicit rename.
- Two Skills declaring the same name remain ambiguous until scoped evidence distinguishes them.
- A dependency referring to a missing Skill stays unresolved and does not produce a dangling graph edge.
- An allowed MCP name with no exact registered server address stays unresolved.
- A tool declaration that resembles a server name is not promoted to an MCP edge.

## Evidence to attach

Attach the identity-resolution report, alias-decision log, unresolved-reference report, endpoint-resolution sample set and snapshot IDs used by the oracle.

## Blockers

Approved identity policy and the CORE-03 oracle contract are required. Missing or scope-incompatible workbook data blocks portal binding and endpoint confirmation; it does not permit fallback matching.

## Out of scope

Changing the shared identity policy, creating portal records, editing source declarations, granting access, recommendation labels and inferred relationships.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [SKL-02](SKL-02.md) must finish its stated contract boundary before this task starts.
- [CORE-02](CORE-02.md) must finish its stated contract boundary before this task starts.
- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.
- [MCP-03](MCP-03.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `model`, `identity`, `ingestion`, `validation-gates`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
