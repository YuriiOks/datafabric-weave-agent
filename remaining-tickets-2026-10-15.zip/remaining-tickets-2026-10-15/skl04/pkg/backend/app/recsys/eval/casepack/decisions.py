"""The reviewer decision log: the only way a relevance label enters a case pack.

Each decision names its reviewer and cites where the decision was recorded. The latest
decision for a case is its adjudication; the log is append-only and the case pack must
agree with it.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.recsys.eval.casepack.cases import (
    Adjudication,
    AdjudicationState,
    EvaluationCase,
    RelevanceLabel,
)
from app.recsys.eval.casepack.lineage import CasePackError


class ReviewDecision(BaseModel):
    """One reviewer's relevance decision for one case."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    decision_id: str = Field(min_length=1, max_length=64)
    case_id: str = Field(min_length=1, max_length=16)
    reviewer: str = Field(min_length=1, max_length=128)
    decided_at: datetime
    decision_reference: str = Field(min_length=1, max_length=256)
    labels: dict[str, RelevanceLabel] = Field(default_factory=dict)
    note: str = Field(default="", max_length=2000)

    @model_validator(mode="after")
    def _is_a_decision(self) -> ReviewDecision:
        """A decision obeys the same rules as the adjudication it sets.

        :return: The decision.
        :raises ValueError: When the reviewer or labels could not form a judged adjudication.
        """
        self.adjudication()
        return self

    def adjudication(self) -> Adjudication:
        """Return the adjudication this decision sets.

        :return: The judged adjudication, validated like any other.
        """
        return Adjudication(
            state=AdjudicationState.judged,
            reviewer=self.reviewer,
            decision_reference=self.decision_reference,
            labels=self.labels,
        )


def latest_decisions(decisions: Sequence[ReviewDecision]) -> dict[str, ReviewDecision]:
    """Select the latest decision per case.

    :param decisions: The decision log.
    :return: The latest decision by case id; ties break on the decision id.
    :raises CasePackError: When a decision id repeats.
    """
    ids = [decision.decision_id for decision in decisions]
    if len(set(ids)) != len(ids):
        raise CasePackError("a decision id appears twice in the log")
    latest: dict[str, ReviewDecision] = {}
    for decision in sorted(decisions, key=lambda item: (item.decided_at, item.decision_id)):
        latest[decision.case_id] = decision
    return latest


def apply_decisions(
    cases: Sequence[EvaluationCase], decisions: Sequence[ReviewDecision]
) -> list[EvaluationCase]:
    """Set each case's adjudication from its latest decision.

    The updated case is validated again, so a decision that contradicts the case's expected
    outcome or scenario is refused rather than applied.

    :param cases: The cases.
    :param decisions: The decision log.
    :return: The cases, adjudicated where the log decides them.
    :raises CasePackError: When a decision names an unknown case or contradicts its case.
    """
    latest = latest_decisions(decisions)
    known = {case.case_id for case in cases}
    unknown = sorted(set(latest) - known)
    if unknown:
        raise CasePackError(f"decisions name unknown cases: {', '.join(unknown)}")
    updated = []
    for case in cases:
        decision = latest.get(case.case_id)
        if decision is None:
            updated.append(case)
            continue
        data = case.model_dump(mode="json")
        data["adjudication"] = decision.adjudication().model_dump(mode="json")
        try:
            updated.append(EvaluationCase.model_validate(data))
        except ValueError as error:
            raise CasePackError(f"decision for {case.case_id} contradicts the case") from error
    return updated


def check_decision_log(
    cases: Sequence[EvaluationCase], decisions: Sequence[ReviewDecision]
) -> None:
    """Check that every case agrees with the decision log.

    :param cases: The cases.
    :param decisions: The decision log.
    :raises CasePackError: When a judged case has no matching decision, or a decided case
        is still unjudged.
    """
    latest = latest_decisions(decisions)
    for case in cases:
        decision = latest.get(case.case_id)
        if decision is None:
            if case.adjudication.judged:
                raise CasePackError(f"case {case.case_id} is judged without a logged decision")
            continue
        if case.adjudication != decision.adjudication():
            raise CasePackError(f"case {case.case_id} differs from its latest logged decision")
