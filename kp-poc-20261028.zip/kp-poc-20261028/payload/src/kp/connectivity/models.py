"""Value types of the connectivity harness. Immutable and strictly shaped."""

from __future__ import annotations

from collections import Counter
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Self

from pydantic import AwareDatetime, Field, JsonValue, StringConstraints, model_validator

from kp.domain import ExtractionStatus, RunOutcome, SourceKind
from kp.domain.base import DomainModel

JsonObject = dict[str, JsonValue]

PROOF_SOURCES: tuple[SourceKind, ...] = (SourceKind.CONFLUENCE, SourceKind.JIRA, SourceKind.GITHUB)
ITEMS_PER_SOURCE = 3
HINT_MAX_CHARS = 1024

_SafeId = Annotated[str, StringConstraints(pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")]
_Sha256 = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{64}$")]


class SampleKind(StrEnum):
    """What a sample item is in its source."""

    PAGE = "page"
    ISSUE = "issue"
    FILE = "file"
    ATTACHMENT = "attachment"


_KIND_SOURCES: dict[SampleKind, frozenset[SourceKind]] = {
    SampleKind.PAGE: frozenset({SourceKind.CONFLUENCE}),
    SampleKind.ISSUE: frozenset({SourceKind.JIRA}),
    SampleKind.FILE: frozenset({SourceKind.GITHUB}),
    SampleKind.ATTACHMENT: frozenset({SourceKind.CONFLUENCE, SourceKind.JIRA}),
}


class SampleItem(DomainModel):
    """One of the fixed connectivity sample items.

    :ivar item_id: Our stable id; also a path segment of the storage key, hence the pattern.
    :ivar native_id: Page id, issue key, file path or attachment id in the source.
    :ivar media_type: The caller-declared media type of the stored bytes. Never guessed.
    :ivar parent_native_id: Page id or issue key that owns an attachment.
    :ivar repository: GitHub repository of a file.
    :ivar ref: GitHub commit the file is pinned to.
    """

    item_id: _SafeId
    source: SourceKind
    kind: SampleKind
    native_id: str = Field(min_length=1)
    media_type: str = Field(min_length=3)
    parent_native_id: str | None = None
    repository: str | None = None
    ref: str | None = None

    @model_validator(mode="after")
    def _consistent(self) -> Self:
        if self.source not in _KIND_SOURCES[self.kind]:
            raise ValueError(f"a {self.kind.value} cannot come from {self.source.value}")
        if self.kind is SampleKind.ATTACHMENT and not self.parent_native_id:
            raise ValueError("an attachment needs parent_native_id")
        if self.kind is SampleKind.FILE and not (self.repository and self.ref):
            raise ValueError("a file needs repository and ref")
        return self


class SampleSet(DomainModel):
    """The nine sample items: three per source, unique ids."""

    items: tuple[SampleItem, ...]

    @model_validator(mode="after")
    def _fixed_shape(self) -> Self:
        ids = [item.item_id for item in self.items]
        if len(set(ids)) != len(ids):
            raise ValueError("sample item ids must be unique")
        counts = Counter(item.source for item in self.items)
        expected = dict.fromkeys(PROOF_SOURCES, ITEMS_PER_SOURCE)
        if dict(counts) != expected:
            raise ValueError(f"expected {ITEMS_PER_SOURCE} items per source, got {dict(counts)}")
        return self

    def for_source(self, source: SourceKind) -> tuple[SampleItem, ...]:
        """Return the items of one source in file order.

        :param source: Which source
        :return: Its sample items
        """
        return tuple(item for item in self.items if item.source is source)


class Route(DomainModel):
    """Where a tool server sits behind the gateway.

    :ivar namespace: The tool namespace; the gateway picks the server from it.
    :ivar source: The source whose credential accompanies calls on this route.
    """

    namespace: _SafeId
    source: SourceKind


class ToolSignature(DomainModel):
    """A tool as the gateway lists it. Kept so the adapters can be checked against reality."""

    namespace: str
    name: str
    description: str = ""
    input_schema: JsonObject = Field(default_factory=dict)


class ToolResult(DomainModel):
    """What a ``tools/call`` returned.

    :ivar structured: The result as an object, when the tool returned one.
    :ivar text: The text content (the prose when ``structured`` is ``None``).
    :ivar is_error: True when the tool reported its own failure.
    """

    structured: JsonObject | None = None
    text: str = ""
    is_error: bool = False


class CallObservation(DomainModel):
    """One HTTP exchange with the gateway, before it gets a run and call id."""

    tool: str
    operation: str
    request_digest: _Sha256
    http_status: int | None = None
    error_class: str | None = None
    object_count: int = 0
    truncated: bool = False
    latency_ms: Annotated[float, Field(ge=0)]
    token_refreshed: bool = False
    surviving_fields: tuple[str, ...] = ()
    called_at: AwareDatetime


class ExtractionRequest(DomainModel):
    """What the extraction service is sent: identity and where to read, never the bytes.

    :ivar storage_reference: Where the service reads the raw object itself.
    :ivar media_type: The media type the caller declares for the object.
    :ivar hints: Small descriptive strings (title, author, native id ...), each short enough
        that a document cannot be smuggled through them.
    """

    item_id: str
    source_type: SourceKind
    version: str
    storage_reference: str
    media_type: str
    hints: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _hints_are_small(self) -> Self:
        for name, value in self.hints.items():
            if len(value) > HINT_MAX_CHARS:
                raise ValueError(f"hint {name!r} is longer than {HINT_MAX_CHARS} characters")
        return self


class ExtractionResponse(DomainModel):
    """What the extraction service answers.

    ``extractor_version`` is mandatory in the contract; an empty value is rejected by
    :func:`kp.connectivity.extraction.ensure_extractor_version`.
    """

    item_id: str
    markdown_location: str
    manifest_location: str
    extractor_version: str = ""
    page_count: int | None = None
    warnings: tuple[str, ...] = ()


class Manifest(DomainModel):
    """The JSON sidecar beside each Markdown document. All fields must be present."""

    item_id: str
    source_type: SourceKind
    native_id: str
    version: str
    content_sha256: _Sha256
    title: str
    author: str | None
    modified_at: AwareDatetime | None
    extracted_at: AwareDatetime
    extractor_version: str = Field(min_length=1)


class RunActivity(StrEnum):
    """What a connectivity run did."""

    DISCOVER = "discover"
    FETCH = "fetch"
    PROBE = "probe"


class ItemStatus(StrEnum):
    """What happened to one sample item in a fetch run.

    ``EXTRACTED`` means the version was already stored with extraction pending and this run
    completed the extraction without writing a new raw object or version.
    """

    STORED = "stored"
    EXTRACTED = "extracted"
    UNCHANGED = "unchanged"
    FAILED = "failed"


class ItemOutcome(DomainModel):
    """The result for one sample item in one run."""

    item_id: str
    source: SourceKind
    media_type: str
    status: ItemStatus
    version: str | None = None
    extraction_status: ExtractionStatus | None = None
    error_class: str | None = None
    detail: str | None = None


class RunResult(DomainModel):
    """The evidence file of one run, kept beside the database rows.

    :ivar tools_by_namespace: For a discovery run, how many tools each server listed.
    :ivar probes: For a probe run, the error class each provoked failure produced.
    :ivar abort_reason: Set when the run stopped early with a typed error.
    """

    run_id: str
    activity: RunActivity
    started_at: datetime
    ended_at: datetime
    outcome: RunOutcome
    items: tuple[ItemOutcome, ...] = ()
    tools_by_namespace: dict[str, int] = Field(default_factory=dict)
    probes: dict[str, str] = Field(default_factory=dict)
    abort_reason: str | None = None

    @property
    def stored_count(self) -> int:
        """How many item versions this run newly stored."""
        return sum(1 for item in self.items if item.status is ItemStatus.STORED)

    @property
    def touched_count(self) -> int:
        """How many item versions this run stored or completed."""
        return sum(
            1 for item in self.items if item.status in {ItemStatus.STORED, ItemStatus.EXTRACTED}
        )

    @property
    def failed_items(self) -> tuple[ItemOutcome, ...]:
        """The items that could not be read or extracted."""
        return tuple(item for item in self.items if item.status is ItemStatus.FAILED)

    @property
    def duration_seconds(self) -> float:
        """Wall-clock length of the run."""
        return (self.ended_at - self.started_at).total_seconds()
