#!/usr/bin/env bash
# Run every quality gate: lint, format check, types, tests. Stops at the first failure.
set -euo pipefail

cd "$(dirname "$0")/.."

if [ -x .venv/bin/python ]; then
    PY=.venv/bin/python
else
    PY=python3
fi

# The local spec repository tests and the demo's "git" publisher need a working git. Without one
# they skip, and the checks would pass without ever running the publisher a workstation uses.
# So look for one (KP_GIT_BINARY wins), and stop when there is none unless KP_ALLOW_NO_GIT=1.
git_works() {
    "$1" --version >/dev/null 2>&1
}

if [ -z "${KP_GIT_BINARY:-}" ] && ! git_works git; then
    for candidate in /usr/bin/git /usr/local/bin/git /opt/homebrew/bin/git; do
        if [ -x "$candidate" ] && git_works "$candidate"; then
            export KP_GIT_BINARY="$candidate"
            break
        fi
    done
fi
if [ -z "${KP_GIT_BINARY:-}" ] && ! git_works git && [ "${KP_ALLOW_NO_GIT:-}" != "1" ]; then
    echo "check.sh: no working git binary found; set KP_GIT_BINARY to one," >&2
    echo "          or KP_ALLOW_NO_GIT=1 to run without the git publisher tests." >&2
    exit 1
fi

# The packaging tests import the build scripts, which are not an installed package.
export MYPYPATH="scripts${MYPYPATH:+:$MYPYPATH}"

"$PY" -m ruff check .
"$PY" -m ruff format --check .
"$PY" -m mypy src tests scripts/bank_install_template.py
"$PY" -m pytest -q
