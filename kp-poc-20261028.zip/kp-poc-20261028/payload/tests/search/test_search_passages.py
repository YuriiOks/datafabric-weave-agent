"""US-10 passage builder: sizes, splitting and exact positions."""

from __future__ import annotations

from datetime import date

from kp.domain import Clause, ClauseRef, Edition, PassageType, Requirement, SourceKind, Story
from kp.search import (
    CodeFile,
    DocumentText,
    SchemaDocument,
    clause_passages,
    code_passages,
    count_tokens,
    page_passages,
    requirement_passage,
    schema_field_passages,
    story_passages,
)
from kp.testing.dataset import SyntheticDataset

LONG_CLAUSE = "6.3.2"
CURRENCY_CLAUSE = "4.2.1"


def _edition(label: str) -> Edition:
    return Edition(
        label=label,
        effective_date=date(2026, 11, 16),
        item_id="payments-rulebook",
        version=label,
    )


def _clause(dataset: SyntheticDataset, label: str, number: str) -> Clause:
    truth = next(c for c in dataset.truth.edition(label).clauses if c.number == number)
    ref = ClauseRef(label, number)
    return Clause(
        ref=ref,
        title=truth.title,
        page=truth.page,
        char_start=truth.md_char_start,
        char_end=truth.md_char_end,
        text=truth.text,
        structure_score=1.0,
        parent_ref=ref.parent(),
    )


def test_us10_every_clause_is_one_passage_unless_over_1800_tokens(
    committed_dataset: SyntheticDataset,
) -> None:
    edition = _edition("2026.1")
    for truth in committed_dataset.truth.edition("2026.1").clauses:
        if truth.number == LONG_CLAUSE:
            continue
        passages = clause_passages(
            _clause(committed_dataset, "2026.1", truth.number), edition, None
        )

        assert len(passages) == 1
        assert passages[0].text == truth.text
        assert passages[0].parent_ref == f"2026.1:{truth.number}"
        assert passages[0].part_index is None


def test_us10_clause_token_count_is_whitespace_words(committed_dataset: SyntheticDataset) -> None:
    clause = _clause(committed_dataset, "2026.1", CURRENCY_CLAUSE)

    passage = clause_passages(clause, _edition("2026.1"), "payments")[0]

    assert passage.tokens == len(clause.text.split()) == 39
    assert passage.domain == "payments"
    assert passage.edition_label == "2026.1"
    assert passage.passage_type is PassageType.CLAUSE


def test_us10_long_clause_is_split_at_subparagraphs_into_parts_of_about_1200(
    committed_dataset: SyntheticDataset,
) -> None:
    clause = _clause(committed_dataset, "2026.1", LONG_CLAUSE)
    assert count_tokens(clause.text) > 1800

    parts = clause_passages(clause, _edition("2026.1"), None)

    assert len(parts) >= 3
    assert [p.part_index for p in parts] == list(range(len(parts)))
    assert {p.parent_ref for p in parts} == {"2026.1:6.3.2"}
    assert all(1000 <= p.tokens <= 1200 for p in parts[:-1])
    assert all(p.text.startswith("(") for p in parts)
    assert sum(p.tokens for p in parts) == count_tokens(clause.text)


def test_us10_split_parts_quote_the_source_at_their_position(
    committed_dataset: SyntheticDataset,
) -> None:
    markdown = committed_dataset.path(
        committed_dataset.truth.edition("2026.1").markdown_path
    ).read_text(encoding="utf-8")
    clause = _clause(committed_dataset, "2026.1", LONG_CLAUSE)

    parts = clause_passages(clause, _edition("2026.1"), None)

    for part in parts:
        assert part.char_start is not None
        assert part.char_end is not None
        assert markdown[part.char_start : part.char_end] == part.text
    assert parts[0].char_start == clause.char_start
    assert parts[-1].char_end == clause.char_end


def test_us10_unsplittable_long_clause_falls_back_to_sentences_then_words() -> None:
    text = " ".join(f"word{n}" for n in range(2500))
    clause = Clause(
        ref=ClauseRef("1.0", "1"),
        page=1,
        char_start=10,
        char_end=10 + len(text),
        text=text,
        structure_score=1.0,
        parent_ref=None,
    )

    parts = clause_passages(clause, _edition("1.0"), None)

    assert [p.tokens for p in parts] == [1200, 1200, 100]
    assert all(p.text == text[(p.char_start or 0) - 10 : (p.char_end or 0) - 10] for p in parts)


def test_us10_pages_are_800_tokens_with_120_overlap() -> None:
    words = [f"w{n}" for n in range(2000)]
    document = DocumentText(
        SourceKind.CONFLUENCE,
        "page-1",
        "3",
        " ".join(words),
        domain="payments",
        page_starts=(0, 3000),
    )

    passages = page_passages(document)

    assert [p.tokens for p in passages] == [800, 800, 640]
    assert passages[1].text.split()[:120] == passages[0].text.split()[-120:]
    assert passages[0].page == 1
    assert passages[-1].page == 2
    assert all(p.passage_type is PassageType.PAGE for p in passages)
    assert all(document.text[p.char_start or 0 : p.char_end] == p.text for p in passages)


def test_us10_short_page_text_is_one_passage_without_page_number_when_unknown() -> None:
    passages = page_passages(DocumentText(SourceKind.CONFLUENCE, "p", "1", "just a few words"))

    assert len(passages) == 1
    assert passages[0].page is None


def test_us10_story_passage_keeps_acceptance_criteria_separate() -> None:
    story = Story(
        story_key="PAY-1",
        version="2",
        summary="Accept euro transfers",
        description="Background text.",
        acceptance_criteria="Given a euro transfer\nThen it is accepted",
        domain="payments",
    )

    passages = story_passages(story)

    assert [p.passage_type for p in passages] == [
        PassageType.STORY,
        PassageType.ACCEPTANCE_CRITERIA,
    ]
    assert passages[0].text == "Accept euro transfers\n\nBackground text."
    assert passages[1].text == "Given a euro transfer\nThen it is accepted"
    assert {p.parent_ref for p in passages} == {"PAY-1"}
    assert {p.source for p in passages} == {SourceKind.JIRA}


def test_us10_long_story_is_split_to_about_600_tokens() -> None:
    description = "\n\n".join(" ".join(f"s{n}x{m}" for m in range(100)) for n in range(14))
    story = Story(story_key="PAY-2", version="1", summary="Big", description=description)

    passages = story_passages(story)

    assert len(passages) == 3
    assert all(p.tokens <= 600 for p in passages)
    assert all(p.passage_type is PassageType.STORY for p in passages)


def test_us10_story_without_criteria_has_no_criteria_passage() -> None:
    passages = story_passages(Story(story_key="PAY-3", version="1", summary="S"))

    assert [p.passage_type for p in passages] == [PassageType.STORY]


def test_us10_code_is_cut_by_function_with_exact_positions() -> None:
    source = (
        '"""Module."""\n\nLIMIT = 5\n\n\n'
        "def first(a: int) -> int:\n    return a + LIMIT\n\n\n"
        "class Box:\n    size = 1\n\n    def second(self) -> int:\n        return self.size\n\n"
        "    @staticmethod\n    def third() -> int:\n        return 3\n"
    )
    code = CodeFile(SourceKind.GITHUB, "repo", "abc123", "src/mod.py", source)

    passages = code_passages(code)

    assert [p.text.strip().splitlines()[0] for p in passages] == [
        '"""Module."""',
        "def first(a: int) -> int:",
        "class Box:",
        "def second(self) -> int:",
        "@staticmethod",
    ]
    assert all(source[p.char_start or 0 : p.char_end] == p.text for p in passages)
    assert {p.parent_ref for p in passages} == {"src/mod.py"}
    assert all(p.passage_type is PassageType.CODE for p in passages)


def test_us10_long_function_is_cut_at_lines_to_about_900_tokens() -> None:
    body = "\n".join(f"    value_{n} = compute({n}, {n + 1}, {n + 2})" for n in range(400))
    code = CodeFile(SourceKind.GITHUB, "repo", "v1", "big.py", f"def big():\n{body}\n")

    passages = code_passages(code)

    assert len(passages) > 1
    assert all(p.tokens <= 900 for p in passages)
    assert "".join(p.text for p in passages).count("compute") == 400


def test_us10_non_python_and_broken_python_are_cut_at_lines() -> None:
    lines = "\n".join(f"line {n} of some configuration text here" for n in range(500))

    other = code_passages(CodeFile(SourceKind.GITHUB, "r", "v", "x.cfg", lines))
    broken = code_passages(CodeFile(SourceKind.GITHUB, "r", "v", "x.py", "def (:\n" + lines))

    assert all(p.tokens <= 900 for p in [*other, *broken])
    assert len(other) == 4
    assert len(broken) == 4


def test_us10_register_row_is_one_passage() -> None:
    requirement = Requirement(
        requirement_id="reg:Requirements:5",
        source=SourceKind.DOCUMENT_LIBRARY,
        item_id="reg",
        version="1",
        sheet="Requirements",
        row_number=5,
        header_confidence=0.9,
        domain="payments",
        fields={"Title": "Accept euro", "Owner": " ", "Rule reference": "2026.1 clause 4.2.1"},
    )

    passage = requirement_passage(requirement)

    assert passage.passage_type is PassageType.REGISTER_ROW
    assert passage.text == "Title: Accept euro\nRule reference: 2026.1 clause 4.2.1"
    assert passage.parent_ref == "reg:Requirements:5"


def test_us10_each_schema_field_is_one_passage() -> None:
    schema = {
        "title": "CreditTransfer",
        "properties": {
            "currency": {"type": "string", "x-clause": "2026.1:4.2.1"},
            "party": {
                "type": "object",
                "properties": {"name": {"type": "string", "description": "Legal name"}},
            },
        },
    }

    passages = schema_field_passages(
        SchemaDocument(SourceKind.GITHUB, "credit-transfer", "abc", schema, domain="payments")
    )

    assert [p.parent_ref for p in passages] == [
        "credit-transfer#currency",
        "credit-transfer#party",
        "credit-transfer#party.name",
    ]
    assert "x-clause: 2026.1:4.2.1" in passages[0].text
    assert "description: Legal name" in passages[2].text
    assert all(p.passage_type is PassageType.SCHEMA_FIELD for p in passages)
