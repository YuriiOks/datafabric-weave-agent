---
pack_id: "bpc-sep26-v1"
local_id: "SKL-04"
kind: "subtask"
existing_jira_key: null
parent_ref: "DTAA-1169"
summary: "Project validated Skill facts and declared edges into the shared catalogue contract"
assignee_key: "yurii"
assignee_display_name: "Yurii"
review_owner: "Yurii owns architecture/security acceptance; peer and domain reviewers resolved in CORE-01"
estimate_hours: 6
scope: "foundation"
create_by_default: true
planned_start: "2026-09-18"
planned_due: "2026-09-18"
dates_profile: "foundation"
dates_status: "proposed; select one calendar profile for the entire import"
depends_on: ["SKL-02","SKL-03","CORE-03","CORE-04"]
recommendation_dependencies: []
jira_marker: "bpc-sep26-skl-04"
architecture_sections: ["model","ingestion","publication","read-contract","validation-gates"]
---

# Project validated Skill facts and declared edges into the shared catalogue contract

## Assignment and delivery window

- Accountable implementer: **Yurii**; map the display name to the actual assignable Jira user on the workstation.
- Parent: **DTAA-1169**. Local reference **SKL-04** is not a Jira key.
- Estimate: **6 focused engineering hours**, including relevant verification and review correction. Not elapsed duration or an unconditional commitment.
- Foundation profile: **2026-09-18 → 2026-09-18 (D8–D8)**.
- Recommendation extension: **2026-09-21 → 2026-09-21 (D9–D9)**. Use this profile only after scope confirmation; change the whole calendar together.
- Execution order: use the profile’s start/finish slots in the manifest. Dates can coincide for sequential same-day tasks; this does not make them parallel. Slots are planning offsets, not promised clock appointments.

## Problem / outcome

A published Skill catalogue must distinguish source facts from unresolved data and must be reproducible from one pinned snapshot. Translate resolved Skill occurrences into the shared catalogue and projection inputs with complete provenance, while leaving uncertain records visible without manufacturing edges.

## Scope

Implement the Skills adapter to the catalogue and projection interfaces delivered by CORE-03 and CORE-04. Emit component facts and source-quality state for resolved Skill identities, and emit only source-declared ALLOWS_MCP and DEPENDS_ON_SKILL relationships whose endpoints were accepted by SKL-03. Hand the resulting candidate to the shared sealing and authorised publication path.

## Boundaries, inputs and outputs

Inputs are the pinned source manifest, SKL-02 field claims and diagnostics, SKL-03 identity and endpoint outcomes, and shared catalogue/publication contracts. Outputs are version-scoped Skill component facts, relationship claims, unresolved-reference summaries, source completeness state and source-to-fact trace data. This task does not own publication pointers, graph namespaces, refresh admission or user-facing endpoints.

## Technical steps

1. Map each resolved Skill occurrence to the shared version-scoped component representation using the oracle-provided durable identity.
2. Preserve name, description and optional metadata as field claims with source lineage; represent disagreement and absence explicitly rather than silently merging fields.
3. Emit only exact source-declared ALLOWS_MCP and DEPENDS_ON_SKILL claims with endpoint evidence, declaration location and same-publication scope.
4. Carry malformed, unresolved, ambiguous and excluded records into the candidate quality/completeness diagnostics, without converting incomplete input into an inferred deletion.
5. Reconcile candidate component, declaration, unresolved and quarantine counts against the source manifest before handing the candidate to CORE-04 sealing.
6. Supply source-to-catalogue trace samples that support the bounded authorised read contract without exposing raw source payload by default.

## Acceptance criteria

- [ ] Every admitted Skill fact and edge can be traced to a pinned source occurrence, field or declaration and to its resolution outcome.
- [ ] Component identity, field claims and relationship endpoints belong to the same candidate publication scope.
- [ ] Unresolved or ambiguous declarations are counted and disclosed as diagnostics; they do not become guessed endpoints or silent omissions.
- [ ] A missing or malformed source record cannot retire a previously published fact unless the shared complete-source and removal rules permit it.
- [ ] The Skills adapter produces no suitability score, access grant, execution assertion or inferred co-use edge.

## Meaningful verification cases

- A Skill with no declared relationships appears as a valid component with an explicit no-declarations result.
- A resolved Skill dependency is rendered with its declaration and endpoint-resolution evidence.
- A missing dependency target appears as incomplete evidence without revealing an unauthorised target identity.
- An interrupted or incomplete input candidate cannot replace the active publication through this adapter.
- Reordering source files preserves the same resolved Skill and edge facts for the same manifest.

## Evidence to attach

Attach the manifest-to-catalogue reconciliation, trace samples for a Skill and each edge type, unresolved/quarantine counts, candidate integrity report and handoff record to CORE-04.

## Blockers

This task requires approved resolver results and the shared catalogue/publication DTOs. It cannot activate or roll back a publication; those capabilities remain with CORE-04 and CORE-05.

## Out of scope

Shared graph writer implementation, publication activation, refresh workers, REST or UI work, semantic recommendation features and automatic dependency installation.

## New-build fallback

If CORE-01 cannot demonstrate the reusable prerequisites for this slice, stop treating its scheduled dates/estimate as a commitment. Record the missing capability, a new-build estimate and the dependent tasks affected. Joseph and the implementation lead must choose a revised scope/date before enablement; acceptance is not weakened to force a fit. External approval/reviewer waiting time is not included in engineering hours.

## Canonical dependency and completion rule

- [SKL-02](SKL-02.md) must finish its stated contract boundary before this task starts.
- [SKL-03](SKL-03.md) must finish its stated contract boundary before this task starts.
- [CORE-03](CORE-03.md) must finish its stated contract boundary before this task starts.
- [CORE-04](CORE-04.md) must finish its stated contract boundary before this task starts.

The dependency list in this section/frontmatter and the selected calendar is canonical; mentions of CORE-09 in a producer’s prose describe its later consumer, not a prerequisite. A mock-contract slice is not permission to enable an unqualified backend. No issue is completed solely because its planned due date arrives.

## Workstation context

Read [the architecture snapshot](../reference/ARCHITECTURE-CONTRACT.md) and [scope/capacity rules](../03-SCOPE-AND-CAPACITY.md). Relevant architecture anchors: `model`, `ingestion`, `publication`, `read-contract`, `validation-gates`. Record the current bank commit and exact file/route/schema map from CORE-01 before implementation. Do not invent imports, paths, framework dependencies, Jira fields or benchmark results. Preserve existing Postgres/FalkorDB products.
