"""The link port: traversal that never steps outside the caller's domains."""

from __future__ import annotations

import pytest
from sqlalchemy.exc import OperationalError

from kp.adapters.link_port import StoreLinkPort
from kp.domain import ItemRef, ItemType, LinkKind
from kp.tools import LinkStoreUnavailableError
from world_support import World

CLAUSE = ItemRef(item_type=ItemType.CLAUSE, key="2026.1:4.2.1")
PAYMENTS = frozenset({"payments"})


def _port(world: World) -> StoreLinkPort:
    return StoreLinkPort(world.application.database, world.application.clock)


def test_a_clause_reaches_its_requirement_and_schema_field_marked_stated(
    built_world: World,
) -> None:
    traversal = _port(built_world).traverse(CLAUSE, steps=3, domains=PAYMENTS)

    reached = {(item.item.item_type, item.kind) for item in traversal.items}
    assert (ItemType.REQUIREMENT, LinkKind.STATED) in reached
    assert (ItemType.SCHEMA_FIELD, LinkKind.STATED) in reached
    assert traversal.root_domain == "payments"
    assert traversal.filtered_out == 0


def test_code_and_tests_take_the_domain_of_what_they_were_reached_from(
    built_world: World,
) -> None:
    field = next(
        item
        for item in _port(built_world).traverse(CLAUSE, steps=1, domains=PAYMENTS).items
        if item.item.item_type is ItemType.SCHEMA_FIELD
    )

    assert field.domain == "payments"
    assert field.via == CLAUSE


def test_a_caller_outside_the_domain_sees_nothing_and_the_hidden_items_are_counted(
    built_world: World,
) -> None:
    traversal = _port(built_world).traverse(CLAUSE, steps=3, domains=frozenset({"cards"}))

    assert traversal.items == ()
    assert traversal.filtered_out > 0


def test_link_counts_cover_only_what_the_caller_may_follow(built_world: World) -> None:
    counts = _port(built_world).link_counts([CLAUSE], domains=PAYMENTS)
    hidden = _port(built_world).link_counts([CLAUSE], domains=frozenset({"cards"}))

    # Its requirement, its schema field and the spec a person merged for it.
    assert counts[CLAUSE].stated == 3
    assert counts[CLAUSE].guessed == 0
    assert hidden == {}


def test_an_unreadable_link_store_is_reported_as_unavailable(
    built_world: World, monkeypatch: pytest.MonkeyPatch
) -> None:
    def broken() -> None:
        raise OperationalError("select", {}, Exception("down"))

    monkeypatch.setattr(built_world.application.database, "transaction", broken)

    with pytest.raises(LinkStoreUnavailableError):
        _port(built_world).traverse(CLAUSE, steps=1, domains=PAYMENTS)
