"""US-23 through the application: a merged spec comes back as knowledge, on either publisher.

Everything here goes through :class:`kp.app.Application`, the object the command line uses:
sweep, draft and publish a spec, merge it, sweep again, and ask the questions the links answer.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy import select

from kp.clock import FixedClock
from kp.demo.reviewed_specs import person_edits_and_merges
from kp.domain import ItemType, Relation, SourceKind, SpecState
from kp.links import CoverageEvidence, LinkService
from kp.store import schema
from kp.sweep import LoadedSpec, SpecLoader
from kp.writeback import (
    CallContext,
    PublishSpecArguments,
    SpecNotDraftableError,
    SpecNotDraftedError,
    UpdateJiraArguments,
    draft_spec,
    resolve_git_binary,
)
from world_support import World, build_world

STORY = "PAY-101"
PERSON_STORY = "PAY-104"
SPEC = "spec-pay-101"
PERSON_SPEC = "spec-pay-104"
DAY = timedelta(days=1)


@pytest.fixture(params=["local_git", "dry_run"])
def world(
    request: pytest.FixtureRequest,
    committed_fixtures_dir: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> Iterator[World]:
    """A built platform, once with a git spec repository and once with the record file."""
    found = resolve_git_binary()
    if request.param == "local_git" and found is None:
        pytest.skip("no working git binary (set KP_GIT_BINARY)")
    monkeypatch.setattr(
        "kp.adapters.publishers.resolve_git_binary",
        lambda **_: found if request.param == "local_git" else None,
    )
    built = build_world(committed_fixtures_dir, tmp_path)
    yield built
    built.application.close()


def _clock(world: World) -> FixedClock:
    clock = world.application.clock
    assert isinstance(clock, FixedClock)
    return clock


def _open_links(world: World, spec: str) -> set[tuple[str, str, str]]:
    table = schema.link
    with world.application.database.transaction() as connection:
        rows = connection.execute(
            select(table).where(
                table.c.valid_to.is_(None),
                (table.c.source_key == spec) | (table.c.target_key == spec),
            )
        ).all()
    return {(row.source_key, row.relation, row.target_key) for row in rows}


def _spec_row(world: World, spec: str) -> tuple[str, bool, datetime | None] | None:
    with world.application.database.transaction() as connection:
        row = connection.execute(
            select(
                schema.spec.c.state, schema.spec.c.machine_authored, schema.spec.c.merged_at
            ).where(schema.spec.c.spec_id == spec)
        ).first()
    return None if row is None else (row.state, row.machine_authored, row.merged_at)


def _publish_and_merge(world: World) -> tuple[LoadedSpec, datetime]:
    application = world.application
    clock = _clock(world)
    report = draft_spec(
        STORY,
        runtime=application.draft_runtime(),
        publish=True,
        spec_type="functional",
        as_at=clock.today(),
    )
    assert report.published is not None
    merged = application.merge_spec(STORY)
    clock.set(clock.now() + DAY)
    summary = application.sweep([SourceKind.GITHUB])
    application.after_sweep()
    (loaded,) = (item for item in summary.loaded_specs if item.story_key == STORY)
    return loaded, merged.merged_at


def test_a_spec_waits_for_its_merge_before_it_is_knowledge(world: World) -> None:
    report = draft_spec(
        STORY,
        runtime=world.application.draft_runtime(),
        publish=True,
        spec_type="functional",
        as_at=_clock(world).today(),
    )

    swept = world.application.sweep([SourceKind.GITHUB])

    assert report.published is not None
    assert [item.story_key for item in swept.loaded_specs] == []
    drafted = _spec_row(world, SPEC)
    assert drafted is not None
    assert drafted[0] == SpecState.DRAFTED.value
    assert not any(rel == "specified_by" for _, rel, _ in _open_links(world, SPEC))


def test_a_merged_machine_spec_is_linked_and_does_not_ask_for_a_new_draft(world: World) -> None:
    loaded, merged_at = _publish_and_merge(world)

    assert loaded.spec_key == SPEC
    assert loaded.machine_authored is True
    assert loaded.triggers_draft is False
    assert loaded.clause_refs != ()
    links = _open_links(world, SPEC)
    assert (STORY, "specified_by", SPEC) in links
    for clause in loaded.clause_refs:
        assert (SPEC, "derived_from", clause) in links
    assert (SPEC, "uses_template", "functional-spec@1.0.0") in links
    state, machine_authored, recorded = _spec_row(world, SPEC) or ("", False, None)
    assert (state, machine_authored, recorded) == (SpecState.MERGED.value, True, merged_at)


def test_a_story_whose_spec_was_loaded_back_is_neither_drafted_nor_published_again(
    world: World,
) -> None:
    _publish_and_merge(world)
    runtime = world.application.draft_runtime()

    again = draft_spec(
        STORY,
        runtime=runtime,
        publish=True,
        spec_type="functional",
        as_at=_clock(world).today(),
    )

    assert again.skipped is not None
    assert (again.published, again.jira) == (None, None)
    tools = world.application.write_tools()
    context = CallContext(session_id="s", caller="c", agent="a", domains=("payments",))
    with pytest.raises(SpecNotDraftableError):
        tools.publish_spec(
            context,
            PublishSpecArguments(
                story_key=STORY,
                spec_markdown="# Spec\n",
                template_id="functional-spec",
                template_version="1.0.0",
            ),
        )
    with pytest.raises(SpecNotDraftedError):
        tools.update_jira(context, UpdateJiraArguments(story_key=STORY))


def test_loading_the_same_merged_spec_again_adds_nothing(world: World) -> None:
    _publish_and_merge(world)
    before = _open_links(world, SPEC)

    again = world.application.sweep([SourceKind.GITHUB])
    world.application.after_sweep()

    assert again.loaded_specs == ()
    assert _open_links(world, SPEC) == before


def test_a_persons_edit_replaces_the_machine_spec_from_the_merge_date(world: World) -> None:
    loaded, _ = _publish_and_merge(world)
    clock = _clock(world)
    clock.set(clock.now() + DAY)
    first = loaded.clause_refs[0]
    other = next(ref for ref in ("2026.1:4.2.2", "2026.1:4.2.3") if ref not in loaded.clause_refs)
    merge = world.application.merge_spec(STORY)

    edit = person_edits_and_merges(world.application, merge, replace=(first, other))
    clock.set(clock.now() + DAY)
    summary = world.application.sweep([SourceKind.GITHUB])
    world.application.after_sweep()

    (replaced,) = (item for item in summary.loaded_specs if item.story_key == STORY)
    assert replaced.machine_authored is False
    assert replaced.triggers_draft is False
    assert other in replaced.clause_refs
    assert first not in replaced.clause_refs
    links = _open_links(world, SPEC)
    assert (SPEC, "derived_from", other) in links
    assert (SPEC, "derived_from", first) not in links
    table = schema.link
    with world.application.database.transaction() as connection:
        closed = connection.execute(
            select(table.c.valid_to).where(
                table.c.source_key == SPEC,
                table.c.relation == Relation.DERIVED_FROM.value,
                table.c.target_key == first,
            )
        ).scalar_one()
        opened = connection.execute(
            select(table.c.valid_from).where(
                table.c.source_key == SPEC,
                table.c.relation == Relation.DERIVED_FROM.value,
                table.c.target_key == other,
            )
        ).scalar_one()
    assert closed == opened == edit.merged_at
    state, machine_authored, recorded = _spec_row(world, SPEC) or ("", True, None)
    assert (state, machine_authored, recorded) == (SpecState.MERGED.value, False, edit.merged_at)


def test_a_spec_only_a_person_wrote_blocks_a_draft_for_its_story(world: World) -> None:
    runtime = world.application.draft_runtime()

    report = draft_spec(
        PERSON_STORY,
        runtime=runtime,
        publish=True,
        spec_type="functional",
        as_at=_clock(world).today(),
    )

    assert report.skipped is not None
    assert (PERSON_STORY, "specified_by", PERSON_SPEC) in _open_links(world, PERSON_SPEC)
    with pytest.raises(SpecNotDraftableError, match="already has a merged spec"):
        world.application.write_tools().publish_spec(
            CallContext(session_id="s", caller="c", agent="a", domains=("payments",)),
            PublishSpecArguments(
                story_key=PERSON_STORY,
                spec_markdown="# Spec\n",
                template_id="functional-spec",
                template_version="1.0.0",
            ),
        )


def test_the_story_link_of_a_merged_spec_survives_the_tracker_being_read_again(
    world: World,
) -> None:
    before = _open_links(world, PERSON_SPEC)

    world.application.sweep([SourceKind.JIRA])
    world.application.after_sweep()

    assert (PERSON_STORY, "specified_by", PERSON_SPEC) in before
    assert _open_links(world, PERSON_SPEC) == before


def test_a_rule_with_a_test_leaves_the_untested_list_and_its_impact_reaches_the_whole_chain(
    world: World,
) -> None:
    application = world.application
    with application.database.transaction() as connection:
        service = LinkService(
            connection, thresholds=application.settings.thresholds, clock=application.clock
        )
        untested = service.rules_without_tests()
        covered = {rule.reference: rule for rule in service.coverage().with_tests}
        impact = service.impact("2026.1:4.2.1")

    assert "2026.1:4.2.1" not in {rule.reference for rule in untested.rules}
    assert covered["2026.1:4.2.1"].test_evidence is CoverageEvidence.STATED
    assert len(untested.rules) == untested.total_rules - 1
    assert {
        ItemType.REQUIREMENT,
        ItemType.SPEC,
        ItemType.STORY,
        ItemType.CODE,
        ItemType.TEST,
    } <= {item.ref.item_type for item in impact.items}
    assert impact.guessed_count == 0


def test_a_spec_that_is_no_longer_implemented_by_its_code_loses_the_test(world: World) -> None:
    application = world.application
    inbound = world.staged.code_repo / "src" / "payments" / "inbound.py"
    inbound.write_text(
        inbound.read_text(encoding="utf-8").replace(f"Implements spec {PERSON_SPEC}.", ""),
        encoding="utf-8",
    )

    application.after_sweep()

    with application.database.transaction() as connection:
        untested = LinkService(
            connection, thresholds=application.settings.thresholds, clock=application.clock
        ).rules_without_tests()
    assert untested.total_rules == len(untested.rules)


def test_a_register_row_is_found_by_its_whole_id_and_not_inside_a_longer_one(world: World) -> None:
    with world.application.database.transaction() as connection:
        loader = SpecLoader(connection)
        found = loader._cited_requirements(
            b"Covers REQ-001, and not REQ-0011. See requirements-register:Requirements:5."
        )

    assert found == ("requirements-register:Requirements:5",)
