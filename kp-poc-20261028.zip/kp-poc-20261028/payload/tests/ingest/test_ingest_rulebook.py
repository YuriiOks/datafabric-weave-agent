"""Rulebook parser: US-07 (clause references, TOC count, 20 random clauses at page and position)."""

from __future__ import annotations

import io
import random

import pypdf
import pytest

from ingest.ingest_support import damaged_copies
from kp.config import Thresholds
from kp.ingest import (
    RulebookParseError,
    StructureDecision,
    clause_source_text,
    extract_pdf_pages,
    parse_rulebook_markdown,
    parse_rulebook_pdf,
)
from kp.ingest.structure import classify
from kp.testing.dataset import SyntheticDataset
from kp.testing.rulebook import LONG_CLAUSE

EDITIONS = ("2025.2", "2026.1")
RANDOM_SEED = 20261027
SAMPLE_SIZE = 20


def _words(text: str) -> str:
    """Whitespace-normalised text, because the PDF wraps lines the ground truth does not."""
    return " ".join(text.split())


def _pdf(dataset: SyntheticDataset, label: str) -> bytes:
    return dataset.path(dataset.truth.edition(label).pdf_path).read_bytes()


def _markdown(dataset: SyntheticDataset, label: str) -> str:
    return dataset.path(dataset.truth.edition(label).markdown_path).read_text(encoding="utf-8")


@pytest.mark.parametrize("label", EDITIONS)
def test_us07_every_numbered_clause_has_reference_pdf(
    dataset: SyntheticDataset, thresholds: Thresholds, label: str
) -> None:
    truth = dataset.truth.edition(label)
    parsed = parse_rulebook_pdf(_pdf(dataset, label), default_edition=None, thresholds=thresholds)
    assert parsed.edition == label
    assert [clause.ref.number for clause in parsed.clauses] == [c.number for c in truth.clauses]
    assert all(clause.ref.edition == label for clause in parsed.clauses)
    assert parsed.clauses[0].ref.human() == f"{label} clause 1"
    assert {clause.title for clause in parsed.clauses} == {c.title for c in truth.clauses}


@pytest.mark.parametrize("label", EDITIONS)
def test_us07_every_numbered_clause_has_reference_markdown(
    dataset: SyntheticDataset, thresholds: Thresholds, label: str
) -> None:
    truth = dataset.truth.edition(label)
    parsed = parse_rulebook_markdown(
        _markdown(dataset, label), default_edition=None, thresholds=thresholds
    )
    assert [clause.ref.format() for clause in parsed.clauses] == [
        f"{label}:{c.number}" for c in truth.clauses
    ]


@pytest.mark.parametrize("label", EDITIONS)
def test_us07_clause_count_matches_toc_pdf(
    dataset: SyntheticDataset, thresholds: Thresholds, label: str
) -> None:
    truth = dataset.truth.edition(label)
    parsed = parse_rulebook_pdf(_pdf(dataset, label), default_edition=None, thresholds=thresholds)
    assert len(parsed.clauses) == len(parsed.toc) == truth.toc_clause_count
    assert parsed.toc_matches
    assert parsed.decision is StructureDecision.PROCEED
    assert parsed.structure_score >= thresholds.structure_proceed
    assert not parsed.anomalies


@pytest.mark.parametrize("label", EDITIONS)
def test_us07_clause_count_matches_toc_markdown(
    dataset: SyntheticDataset, thresholds: Thresholds, label: str
) -> None:
    truth = dataset.truth.edition(label)
    parsed = parse_rulebook_markdown(
        _markdown(dataset, label), default_edition=None, thresholds=thresholds
    )
    assert len(parsed.clauses) == len(parsed.toc) == truth.toc_clause_count
    assert parsed.toc_matches
    assert parsed.decision is StructureDecision.PROCEED


def test_us07_pdf_pages_match_ground_truth(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    truth = dataset.truth.edition("2026.1")
    parsed = parse_rulebook_pdf(
        _pdf(dataset, "2026.1"), default_edition=None, thresholds=thresholds
    )
    assert [clause.page for clause in parsed.clauses] == [c.page for c in truth.clauses]
    assert [_words(clause.text) for clause in parsed.clauses] == [
        _words(c.text) for c in truth.clauses
    ]


def test_us07_markdown_positions_equal_ground_truth(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    truth = dataset.truth.edition("2026.1")
    source = _markdown(dataset, "2026.1")
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    for clause, expected in zip(parsed.clauses, truth.clauses, strict=True):
        assert (clause.char_start, clause.char_end) == (
            expected.md_char_start,
            expected.md_char_end,
        )
        assert clause.text == expected.text == source[clause.char_start : clause.char_end]
        assert clause.page == expected.page


def test_us07_twenty_random_clauses_open_at_page_and_position(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    truth = dataset.truth.edition("2026.1")
    content = _pdf(dataset, "2026.1")
    parsed = parse_rulebook_pdf(content, default_edition=None, thresholds=thresholds)
    # Read the source again with pypdf directly, so the check does not rely on parser code.
    pages = [page.extract_text() for page in pypdf.PdfReader(io.BytesIO(content)).pages]
    truth_by_number = {c.number: c for c in truth.clauses}
    rng = random.Random(RANDOM_SEED)  # noqa: S311 - reproducible sampling, not security
    sample = rng.sample(parsed.clauses, SAMPLE_SIZE)

    matches = 0
    for clause in sample:
        page_text = pages[clause.page - 1]
        at_position = page_text[clause.char_start : clause.char_end]
        # A clause that continues on the next page is cut at the page end; what is on the
        # page must then be the start of the clause text.
        same = clause.text.startswith(at_position) and (
            at_position == clause.text or clause.char_end == len(page_text)
        )
        same = same and _words(clause.text) == _words(truth_by_number[clause.ref.number].text)
        matches += same
    assert matches == SAMPLE_SIZE


def test_us07_every_clause_text_found_in_its_source_page(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    content = _pdf(dataset, "2026.1")
    parsed = parse_rulebook_pdf(content, default_edition=None, thresholds=thresholds)
    pages = extract_pdf_pages(content)
    for clause in parsed.clauses:
        assert clause_source_text(pages, clause) == clause.text
        page_text = pages[clause.page - 1]
        assert clause.char_end <= len(page_text)
        assert clause.text.startswith(page_text[clause.char_start : clause.char_end])


def test_us07_clause_that_fits_its_page_is_the_exact_page_slice(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    content = _pdf(dataset, "2026.1")
    parsed = parse_rulebook_pdf(content, default_edition=None, thresholds=thresholds)
    pages = extract_pdf_pages(content)
    clause = next(c for c in parsed.clauses if c.ref.number == "4.2.1")
    assert pages[clause.page - 1][clause.char_start : clause.char_end] == clause.text
    assert "pounds sterling" in clause.text


def test_us07_long_clause_spanning_pages_keeps_its_full_text(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    content = _pdf(dataset, "2026.1")
    parsed = parse_rulebook_pdf(content, default_edition=None, thresholds=thresholds)
    pages = extract_pdf_pages(content)
    clause = next(c for c in parsed.clauses if c.ref.number == LONG_CLAUSE)
    expected = dataset.truth.edition("2026.1")
    expected_text = next(c.text for c in expected.clauses if c.number == LONG_CLAUSE)
    assert _words(clause.text) == _words(expected_text)
    assert clause.char_end == len(pages[clause.page - 1])
    assert len(clause.text) > clause.char_end - clause.char_start
    assert clause_source_text(pages, clause) == clause.text


def test_us07_parent_reference_is_the_enclosing_clause(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    parsed = parse_rulebook_pdf(
        _pdf(dataset, "2026.1"), default_edition=None, thresholds=thresholds
    )
    by_number = {clause.ref.number: clause for clause in parsed.clauses}
    assert by_number["4.2.1"].parent_ref is not None
    assert by_number["4.2.1"].parent_ref.format() == "2026.1:4.2"
    assert by_number["4"].parent_ref is None
    assert all(
        clause.parent_ref is None or clause.parent_ref.number in by_number
        for clause in parsed.clauses
    )


def test_us07_declared_edition_and_effective_date_are_read_from_the_document(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    pdf = parse_rulebook_pdf(_pdf(dataset, "2026.1"), default_edition=None, thresholds=thresholds)
    markdown = parse_rulebook_markdown(
        _markdown(dataset, "2026.1"), default_edition=None, thresholds=thresholds
    )
    assert pdf.declared_edition == markdown.declared_edition == "2026.1"
    assert pdf.declared_effective_date == markdown.declared_effective_date
    assert pdf.declared_effective_date is not None
    assert pdf.declared_effective_date.isoformat() == "2026-11-16"
    assert pdf.text_extractor.startswith("pypdf ")


def test_us07_expected_edition_is_authoritative_and_a_differing_document_is_held(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    # A copied document with a forgotten edition bump: the reviewed item says 2025.2, the
    # text still says 2026.1.
    for parsed in (
        parse_rulebook_markdown(
            _markdown(dataset, "2026.1"), default_edition="2025.2", thresholds=thresholds
        ),
        parse_rulebook_pdf(
            _pdf(dataset, "2026.1"), default_edition="2025.2", thresholds=thresholds
        ),
    ):
        assert parsed.edition == "2025.2"
        assert parsed.declared_edition == "2026.1"
        assert parsed.decision is StructureDecision.REVIEW
        assert any("2026.1" in anomaly and "2025.2" in anomaly for anomaly in parsed.anomalies)
        assert {clause.ref.edition for clause in parsed.clauses} == {"2025.2"}


def test_us07_matching_expected_edition_proceeds(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    parsed = parse_rulebook_markdown(
        _markdown(dataset, "2026.1"), default_edition="2026.1", thresholds=thresholds
    )
    assert parsed.decision is StructureDecision.PROCEED
    assert parsed.anomalies == ()


def test_us07_missing_edition_is_an_error(thresholds: Thresholds) -> None:
    with pytest.raises(RulebookParseError):
        parse_rulebook_markdown(
            "### 1 Scope\n\nText.\n", default_edition=None, thresholds=thresholds
        )


def test_us07_default_edition_is_used_when_the_document_states_none(
    thresholds: Thresholds,
) -> None:
    text = "## Contents\n\n- 1 Scope ... 1\n\n### 1 Scope\n\nText.\n"
    parsed = parse_rulebook_markdown(text, default_edition="9.9", thresholds=thresholds)
    assert parsed.clauses[0].ref.format() == "9.9:1"
    assert parsed.declared_edition is None


def test_us07_unreadable_files_are_typed_errors(thresholds: Thresholds) -> None:
    with pytest.raises(RulebookParseError):
        parse_rulebook_pdf(b"not a pdf", default_edition="1", thresholds=thresholds)
    with pytest.raises(RulebookParseError):
        parse_rulebook_markdown(b"\xff\xfe\x00", default_edition="1", thresholds=thresholds)


def test_us07_damaged_pdfs_give_the_typed_error_or_a_parse_and_nothing_else(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    failures = 0
    for damaged in damaged_copies(_pdf(dataset, "2026.1")):
        try:
            parse_rulebook_pdf(damaged, default_edition="2026.1", thresholds=thresholds)
        except RulebookParseError:
            failures += 1
    assert failures > 0


def _markdown_without(source: str, fragment: str) -> str:
    assert fragment in source
    return "\n".join(line for line in source.splitlines() if fragment not in line) + "\n"


def test_us07_clause_missing_from_the_toc_is_reported_and_cannot_proceed(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    source = _markdown_without(_markdown(dataset, "2026.1"), "- 4.2.4 Reference format")
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    assert not parsed.toc_matches
    assert len(parsed.clauses) == len(parsed.toc) + 1
    assert any("4.2.4" in anomaly for anomaly in parsed.anomalies)
    # One lost entry barely moves the score, but a count mismatch never proceeds.
    assert parsed.structure_score >= thresholds.structure_proceed
    assert parsed.decision is StructureDecision.REVIEW


def test_us07_clause_missing_from_the_body_is_reported(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    source = _markdown(dataset, "2026.1").replace("#### 4.2.2 Amount limits", "Amount limits")
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    assert not parsed.toc_matches
    assert "4.2.2" not in {clause.ref.number for clause in parsed.clauses}
    assert any("listed but not found" in anomaly for anomaly in parsed.anomalies)


def test_us07_missing_table_of_contents_cannot_proceed(
    dataset: SyntheticDataset, thresholds: Thresholds
) -> None:
    source = _markdown(dataset, "2026.1").replace("## Table of Contents", "## Overview")
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    assert not parsed.toc
    assert not parsed.toc_matches
    assert parsed.decision is StructureDecision.REVIEW
    assert "no table of contents found" in parsed.anomalies


def test_us07_scrambled_structure_scores_low_and_blocks(thresholds: Thresholds) -> None:
    source = (
        "Edition: 1.0\n\n## Table of Contents\n\n- 1 Alpha ... 1\n- 2 Beta ... 1\n"
        "- 3 Gamma ... 1\n\n### 1 Alpha\n\nText.\n\n### 7 Beta\n\nText.\n\n### 3 Gamma\n\nText.\n"
    )
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    assert parsed.structure_score < thresholds.structure_review
    assert parsed.decision is StructureDecision.BLOCK


def test_us07_no_headings_scores_zero_and_blocks(thresholds: Thresholds) -> None:
    parsed = parse_rulebook_markdown(
        "Edition: 1.0\n\nJust prose.\n", default_edition=None, thresholds=thresholds
    )
    assert parsed.clauses == ()
    assert parsed.structure_score == 0.0
    assert parsed.decision is StructureDecision.BLOCK
    assert "no numbered clause headings found" in parsed.anomalies


def test_us07_repeated_heading_is_ignored_and_reported(thresholds: Thresholds) -> None:
    source = (
        "Edition: 1.0\n\n## Contents\n\n- 1 Alpha ... 1\n\n### 1 Alpha\n\nFirst.\n\n"
        "### 1 Alpha\n\nSecond.\n"
    )
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    assert len(parsed.clauses) == 1
    assert parsed.clauses[0].text.startswith("First.")
    assert any("more than once" in anomaly for anomaly in parsed.anomalies)


def test_us07_heading_only_clause_has_an_empty_span(thresholds: Thresholds) -> None:
    source = (
        "Edition: 1.0\n\n## Contents\n\n- 1 Alpha ... 1\n- 1.1 Beta ... 1\n\n"
        "### 1 Alpha\n\n#### 1.1 Beta\n\nText.\n"
    )
    parsed = parse_rulebook_markdown(source, default_edition=None, thresholds=thresholds)
    alpha = parsed.clauses[0]
    assert alpha.text == ""
    assert alpha.char_start == alpha.char_end
    assert parsed.decision is StructureDecision.PROCEED


@pytest.mark.parametrize(
    ("score", "decision"),
    [
        (1.0, StructureDecision.PROCEED),
        (0.85, StructureDecision.PROCEED),
        (0.8499, StructureDecision.REVIEW),
        (0.60, StructureDecision.REVIEW),
        (0.5999, StructureDecision.BLOCK),
        (0.0, StructureDecision.BLOCK),
    ],
)
def test_us07_structure_thresholds(score: float, decision: StructureDecision) -> None:
    assert classify(score, Thresholds()) is decision


def test_us07_thresholds_come_from_settings() -> None:
    strict = Thresholds(structure_proceed=0.99, structure_review=0.9)
    assert classify(0.95, strict) is StructureDecision.REVIEW
