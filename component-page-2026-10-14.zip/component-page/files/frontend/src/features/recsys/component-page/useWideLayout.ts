import { useSyncExternalStore } from 'react'

/** At and above this width the page uses two columns; below it, one column. */
export const WIDE_QUERY = '(min-width: 900px)'

function canMatch(): boolean {
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function'
}

function subscribe(onChange: () => void): () => void {
  if (!canMatch()) return () => undefined
  const query = window.matchMedia(WIDE_QUERY)
  query.addEventListener('change', onChange)
  return () => query.removeEventListener('change', onChange)
}

function wideNow(): boolean {
  return canMatch() ? window.matchMedia(WIDE_QUERY).matches : true
}

/** Whether the viewport is wide enough for the two-column layout. */
export function useWideLayout(): boolean {
  return useSyncExternalStore(subscribe, wideNow, () => true)
}
