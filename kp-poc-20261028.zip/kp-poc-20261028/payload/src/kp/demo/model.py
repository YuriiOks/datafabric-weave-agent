"""Plain results of the demo: checks, the three "done when" lines and the whole outcome."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Final

DONE_WHEN: Final = {
    "W1": (
        "The payment rulebook, one requirements register and one project's stories are loaded, "
        "every rule clause can be referenced on its own, and drafts are excluded."
    ),
    "W2": (
        "A currency question returns the right clause with page and position, and "
        '"which rules have no test" and "this rule changed, what is affected" both return '
        "answers."
    ),
    "W3": "One story goes end to end to a reviewed spec, and a user without access is refused.",
}
LINE_TITLES: Final = {
    "W1": "Week 1: sources in",
    "W2": "Week 2: search and links",
    "W3": "Week 3: agent access and write-back",
}


@dataclass(frozen=True)
class Check:
    """One thing that was checked and what was seen."""

    name: str
    passed: bool
    evidence: str


@dataclass(frozen=True)
class LineResult:
    """One "done when" line: its words, its checks and the verdict."""

    line_id: str
    checks: tuple[Check, ...]

    @property
    def title(self) -> str:
        """The week and outcome."""
        return LINE_TITLES[self.line_id]

    @property
    def done_when(self) -> str:
        """The plan's words for this line."""
        return DONE_WHEN[self.line_id]

    @property
    def passed(self) -> bool:
        """True when there is at least one check and every check passed."""
        return bool(self.checks) and all(check.passed for check in self.checks)

    @property
    def summary(self) -> str:
        """The one-line verdict printed by the command."""
        passed = sum(1 for check in self.checks if check.passed)
        verdict = "PASS" if self.passed else "FAIL"
        return f"{self.line_id} {verdict} ({passed}/{len(self.checks)} checks): {self.done_when}"


@dataclass(frozen=True)
class CriterionRow:
    """One row of the connectivity exit-criteria table."""

    criterion_id: str
    title: str
    result: str
    detail: str


@dataclass(frozen=True)
class ConnectivityTable:
    """The connectivity job against the local stand-ins."""

    verdict: str
    rows: tuple[CriterionRow, ...]
    error: str | None = None


@dataclass(frozen=True)
class PipelineFacts:
    """What the build phases did, shown at the top of the report."""

    demo_date: str
    publisher: str
    steps: tuple[tuple[str, str], ...]
    publication: tuple[tuple[str, str, str], ...]


@dataclass(frozen=True)
class DemoOutcome:
    """Everything the demo produced."""

    lines: tuple[LineResult, ...]
    facts: PipelineFacts
    connectivity: ConnectivityTable
    notes: tuple[str, ...] = field(default=())

    @property
    def passed(self) -> bool:
        """True only if all three "done when" lines passed."""
        return len(self.lines) == len(DONE_WHEN) and all(line.passed for line in self.lines)
